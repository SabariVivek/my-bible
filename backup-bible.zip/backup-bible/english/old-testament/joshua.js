module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "The Lord's servant, Moses, had died. Then the Lord spoke to Joshua, son of Nun, who had helped Moses in his work."
    },
    {
      "verse": "2",
      "text": "The Lord said to Joshua, ‘Moses, my servant, is dead. Now you and all these people must get ready to cross the Jordan River. Lead the people of Israel into the land that I am giving to them."
    },
    {
      "verse": "3",
      "text": "I have given to you every part of the ground that you walk on. I promised Moses that I would do this."
    },
    {
      "verse": "4",
      "text": "You will have all the land from the desert in the south to the Lebanon mountains in the north. It will be from the river Euphrates to the Mediterranean Sea on the west. You will have all the land of the Hittite people."
    },
    {
      "verse": "5",
      "text": "No one can stop you from taking this land as long as you live. As I was with Moses, I will always be with you. I will never leave you alone."
    },
    {
      "verse": "6",
      "text": "Be strong and do not be afraid. You will lead these people to take the land. That is the land that I promised to give to their ancestors."
    },
    {
      "verse": "7",
      "text": "Be strong and do not be afraid. Be very careful to do all the things that Moses commanded you to do. Then everything will go well with you, everywhere that you go."
    },
    {
      "verse": "8",
      "text": "You must keep on speaking about the words of God's law. Think about what it says, all the time. Be careful to obey it. Then you will do well, and you will win."
    },
    {
      "verse": "9",
      "text": "Remember that I have told you this: Be strong and do not be afraid. Do not be weak but be brave. I, the Lord your God, will be with you, everywhere that you go. ’"
    },
    {
      "verse": "10",
      "text": "So Joshua commanded the leaders of the people,"
    },
    {
      "verse": "11",
      "text": "‘Go through all the places where the people live. Tell them to get food ready for a journey. In three days, you will cross the Jordan River. You will begin to take the land for yourselves. This is the land that the Lord your God is ready to give to you. ’"
    },
    {
      "verse": "12",
      "text": "Joshua said to the tribes of Reuben, Gad and half the tribe of Manasseh,"
    },
    {
      "verse": "13",
      "text": "‘Remember what Moses, the Lord's servant, told you. The Lord your God is giving to you a place to rest safely. He has given this land to you."
    },
    {
      "verse": "14",
      "text": "Your wives, children and animals can stay in this land that Moses gave to you, on the east side of the Jordan River. But your strong men must cross the river, with their weapons. They must go in front of the other Israelite tribes. You must help them"
    },
    {
      "verse": "15",
      "text": "until the Lord gives them a place to rest, as he has already given to you. When all the other tribes are safe in the land, you may return to the land east of the Jordan. Moses gave this land to you. ’"
    },
    {
      "verse": "16",
      "text": "The people said to Joshua, ‘We will do whatever you tell us. And we will go wherever you send us."
    },
    {
      "verse": "17",
      "text": "As we always obeyed Moses, so we will obey you. The Lord your God was with Moses. So we pray that the Lord will be with you too."
    },
    {
      "verse": "18",
      "text": "If anyone turns against you and he does not obey your commands, we will make sure that he dies. You must be very strong and brave. ’"
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Then Joshua sent two men to go out from Shittim. He sent them in secret to see what the land was like. He told them, ‘Go! Look at all the land. Look very carefully at Jericho city. ’When they came to Jericho city, they arrived at the house of a prostitute. Her name was Rahab. They stayed there. When they came to Jericho city, they arrived at the house of a prostitute. Her name was Rahab. They stayed there."
    },
    {
      "verse": "2",
      "text": "Some people told the king of Jericho, ‘Look! Some Israelite men have come here tonight to see what our land is like. ’"
    },
    {
      "verse": "3",
      "text": "So the king of Jericho sent a message to Rahab. He said, ‘Bring out the men who are staying in your house. They have come secretly to see what all our land is like! ’"
    },
    {
      "verse": "4",
      "text": "But Rahab had hidden the two men. She replied, ‘Yes, some men did come to me. I did not know where they had come from."
    },
    {
      "verse": "5",
      "text": "When it was nearly time to close the gate of the city for the night, they left. I do not know where they went. If you chase after them quickly, you may catch them. ’"
    },
    {
      "verse": "6",
      "text": "But she had taken the men up to the roof. She had hidden them under some straw that she had put there."
    },
    {
      "verse": "7",
      "text": "So the king's officers went out of the city to try to find the two Israelite men. They went along the road to the Jordan River, to the place where the road crosses the river. As soon as they had left, people shut the city gate."
    },
    {
      "verse": "8",
      "text": "Rahab went up to the roof of her house. She spoke to the men as they prepared to sleep."
    },
    {
      "verse": "9",
      "text": "She said to them, ‘I know that the Lord has given this land to you. Everyone here is afraid of you Israelites. Everyone who lives in this land is very frightened."
    },
    {
      "verse": "10",
      "text": "We heard how the Lord caused the water of the Red Sea to become dry. In that way he brought you out of Egypt. We heard what you did to Sihon and Og, the two kings of the Amorites. We heard how you destroyed them completely on the east side of the Jordan River."
    },
    {
      "verse": "11",
      "text": "When we heard what you had done, we were very frightened. We know that we are not strong enough to fight against you because the Lord, your God, is God. He rules everything in heaven and on earth."
    },
    {
      "verse": "12",
      "text": "Now, please use the Lord's name to make a strong promise. I have been kind to you. So promise me that you will be kind to my family. Show me that you will certainly do what you have promised."
    },
    {
      "verse": "13",
      "text": "When you attack this city, do not kill my family. Save the lives of my father, my mother, my brothers and sisters, and all their families. ’"
    },
    {
      "verse": "14",
      "text": "The men replied, ‘We promise to do that. If anyone kills you or your family, may we die too! Do not tell anyone about us. When the Lord gives us this land, we will be kind to you. We will save your lives. ’"
    },
    {
      "verse": "15",
      "text": "So Rahab put a rope out through the window of her house. (The house that she lived in was part of the city wall. ) The men climbed down the rope."
    },
    {
      "verse": "16",
      "text": "Rahab told them, ‘Go to the hills. The men who are chasing you will not find you there. Hide there for three days until they return to this city. Then you can go back to your people. ’"
    },
    {
      "verse": "17",
      "text": "The men said to her, ‘If you do what we say, we will do what we have promised."
    },
    {
      "verse": "18",
      "text": "We will soon attack this land. So tie this red string in the window that we came through. Bring your father, your mother, your brothers and sisters and all your family into your house."
    },
    {
      "verse": "19",
      "text": "If any of them leaves your house, they may die. If that happens, we will not be guilty. We will only be guilty if our soldiers hurt anyone who is in your house."
    },
    {
      "verse": "20",
      "text": "But if you tell anyone about us, we do not have to do what we have promised to you. ’"
    },
    {
      "verse": "21",
      "text": "Rahab said, ‘I agree with what you have said. ’ She sent the men away. When they had gone, she tied the red string in her window."
    },
    {
      "verse": "22",
      "text": "The two Israelite men went into the hills and they hid there. The king's officers looked along the road for them for three days. They did not find them, so they returned to Jericho."
    },
    {
      "verse": "23",
      "text": "Then the two men came down from the hills and they crossed the Jordan River. They went back to Joshua. They told him everything that had happened."
    },
    {
      "verse": "24",
      "text": "They said to him, ‘We are sure that the Lord has given us the whole land. All the people there are very frightened of us. ’"
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "Early the next morning, Joshua and all the Israelites left Shittim. They put up their tents beside the Jordan River. They waited to cross the river."
    },
    {
      "verse": "2",
      "text": "Three days later, the Israelite leaders went to every tent."
    },
    {
      "verse": "3",
      "text": "They commanded the people, ‘The Levite priests will carry the Covenant Box of the Lord your God. When you see them, you must leave here and you must follow them."
    },
    {
      "verse": "4",
      "text": "They will show you the way to go because you have never been here before. But do not go too near to the Covenant Box. Stay about 1, 000 metres behind it. ’"
    },
    {
      "verse": "5",
      "text": "Joshua said to the people, ‘Make yourselves ready to serve the Lord as his holy people. Tomorrow, the Lord will do great miracles among you. ’"
    },
    {
      "verse": "6",
      "text": "He said to the priests, ‘Pick up the Covenant Box, and carry it in front of the people. ’ So they picked it up, and they went on in front of the people."
    },
    {
      "verse": "7",
      "text": "Then the Lord said to Joshua, ‘Today I will begin to make all the Israelite people respect you. They will know that I am with you, in the same way that I was with Moses."
    },
    {
      "verse": "8",
      "text": "The priests that are carrying the Covenant Box must go to the shore of the Jordan River. Tell them to go into the water and to stand there. ’"
    },
    {
      "verse": "9",
      "text": "Joshua said to the Israelites, ‘Come here and listen to the words of the Lord your God."
    },
    {
      "verse": "10",
      "text": "The God who lives for ever is with you. He will certainly chase the Canaanites, Hittites, Hivites, Perizzites, Girgashites, Amorites and Jebusites out from this land. Then you will have their land. The Lord will show you that he will certainly do this."
    },
    {
      "verse": "11",
      "text": "Look now! The Covenant Box of the Lord of all the earth will go into the Jordan River in front of you."
    },
    {
      "verse": "12",
      "text": "men, one from each tribe of Israel's family."
    },
    {
      "verse": "13",
      "text": "Watch the priests who are carrying the Covenant Box. As soon as their feet touch the water of the river, you will see that the water stops running. It will rise up like a wall. ’"
    },
    {
      "verse": "14",
      "text": "So the Israelite people prepared to leave their tents. The priests carried the Covenant Box towards the Jordan River. The people followed them."
    },
    {
      "verse": "15",
      "text": "It was the time of the harvest and there was a lot of water coming down the river. But when the priests reached the shore of the river with the Covenant Box and their feet touched the water,"
    },
    {
      "verse": "16",
      "text": "the water stopped. It stopped a long way up the river, at a town called Adam. That is near Zarethan. The water going down to the Salt Sea stopped completely. So the people crossed the river near Jericho city."
    },
    {
      "verse": "17",
      "text": "The priests stood in the middle of the river on dry ground, with the Lord's Covenant Box. While they stood there, all the Israelite people walked across the river on dry ground. In that way, the whole nation arrived on the other side of the river."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "When the whole Israelite nation had crossed the Jordan River, the Lord spoke to Joshua."
    },
    {
      "verse": "2",
      "text": "He said, ‘Choose 12 men from the people, one from each tribe."
    },
    {
      "verse": "3",
      "text": "Tell them, “Pick up 12 stones from the middle of the river. Take them from the place where the priests are standing. Carry the stones with you to the shore. Put them in the place where you stay tonight. ” ’"
    },
    {
      "verse": "4",
      "text": "men that he had chosen, one from each Israelite tribe."
    },
    {
      "verse": "5",
      "text": "He said to them, ‘Go into the middle of the river, beyond the Lord's Covenant Box. Each of you must pick up a stone and put it on his shoulder. There will be one stone for each of the Israelite tribes."
    },
    {
      "verse": "6",
      "text": "The heap of stones will help you to remember what happened today. In future years, your children will ask you, “What do these stones mean? ”"
    },
    {
      "verse": "7",
      "text": "Then you will tell them that the water in the Jordan River stopped where the Lord's Covenant Box was. When the priests carried the Covenant Box into the river, the water stopped. These stones will help the people of Israel to remember this for ever. ’"
    },
    {
      "verse": "8",
      "text": "men obeyed Joshua's command. They took 12 stones from the middle of the Jordan River, as the Lord had told Joshua. There was one stone for each Israelite tribe. They carried the stones to the place where the people had put their tents. They put the stones down there."
    },
    {
      "verse": "9",
      "text": "stones in the middle of the Jordan River. He put them in the place where the priests with the Covenant Box had stood. Those stones are still there today."
    },
    {
      "verse": "10",
      "text": "The priests had carried the Covenant Box into the middle of the river. They stood there while the people did everything that the Lord had told Joshua. That is what Moses had also told Joshua. The people crossed over the river quickly."
    },
    {
      "verse": "11",
      "text": "As soon as everybody was on the other side, the priests also took the Covenant Box to the other side. The people watched them as they did this."
    },
    {
      "verse": "12",
      "text": "The tribes of Reuben, Gad and half the tribe of Manasseh led the people across. They were all ready to fight, as Moses had told them."
    },
    {
      "verse": "13",
      "text": "About 40, 000 men who had weapons crossed to the flat land near Jericho. They marched past the Lord's Covenant Box."
    },
    {
      "verse": "14",
      "text": "That day the Lord caused all the Israelite people to respect Joshua. They respected him all his life, as they had respected Moses."
    },
    {
      "verse": "15",
      "text": "Then the Lord said to Joshua,"
    },
    {
      "verse": "16",
      "text": "‘Tell the priests who are carrying the Covenant Box to come up out of the Jordan River. ’"
    },
    {
      "verse": "17",
      "text": "So Joshua told the priests, ‘Come up out of the Jordan. ’"
    },
    {
      "verse": "18",
      "text": "So the priests came up from the middle of the river. They were carrying the Lord's Covenant Box. As soon as their feet touched the dry ground on the shore, the water of the Jordan ran again. There was so much water that it made a flood, like before."
    },
    {
      "verse": "19",
      "text": "On the tenth day of the first month, the people left the shore of the Jordan River. They put up their tents at a place called Gilgal. That was on the east side of Jericho city."
    },
    {
      "verse": "20",
      "text": "At Gilgal, Joshua made a heap with the 12 stones that they had taken out of the Jordan River."
    },
    {
      "verse": "21",
      "text": "He said to the Israelite people, ‘In future years, your children will ask you, “What do these stones mean? ”"
    },
    {
      "verse": "22",
      "text": "Then you must tell them, “We Israelites went across the Jordan River on dry ground. ”"
    },
    {
      "verse": "23",
      "text": "Yes, you have seen what the Lord your God has done. He made the Jordan River become dry, so that you could cross over it. That was like he did to the Red Sea, so that we could cross it when we left Egypt."
    },
    {
      "verse": "24",
      "text": "The Lord has done this so that all the nations of the world can see how powerful he is. He did it so that you would always obey him, the Lord your God. ’"
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Many people heard how the Lord had caused the Jordan River to become dry. This included all the Amorite kings on the west side of the Jordan River, and all the Canaanite kings who lived near the sea. They heard how the Lord had made the river become dry until all the Israelites had crossed to the other side. So the kings became very afraid of the Israelite people. They felt too weak to fight against them."
    },
    {
      "verse": "2",
      "text": "The Lord said to Joshua at that time, ‘Make knives of stone and circumcise the Israelite men. ’"
    },
    {
      "verse": "3",
      "text": "So Joshua made the knives and he circumcised the men at Gibeath Haaraloth."
    },
    {
      "verse": "4",
      "text": "This is why Joshua had to circumcise them: All the men who were old enough to fight when they came out of Egypt had now died. They died in the desert as they travelled to Canaan."
    },
    {
      "verse": "5",
      "text": "All those men who came out of Egypt had already been circumcised. But all the sons who were born on the journey through the desert had not been circumcised."
    },
    {
      "verse": "6",
      "text": "years. But all the men who were old enough to fight when they left Egypt had now died. This happened because they had not obeyed the Lord. The Lord had promised to give to them the land of Canaan, a land where there is plenty of food and drink. But he made a strong promise that those men would not see that land, because they had turned against him."
    },
    {
      "verse": "7",
      "text": "Now Joshua circumcised their sons, who had taken their place. Their fathers had not circumcised them while they travelled in the desert."
    },
    {
      "verse": "8",
      "text": "All of the Israelite men were circumcised. Then they stayed there in Gilgal until they were strong again. So they called that place Gilgal, and it still has that name."
    },
    {
      "verse": "9",
      "text": "The Lord said to Joshua, ‘This shows that you are no longer ashamed to be slaves, as you were in Egypt. Today I have taken away your shame. ’So they called that place Gilgal, and it still has that name."
    },
    {
      "verse": "10",
      "text": "The Israelite people ate the Passover meal on the evening of the 14th day of that month. They did this while they were at Gilgal, near Jericho city."
    },
    {
      "verse": "11",
      "text": "The next day they ate food that had grown in Canaan. For the first time, they ate flat bread and grain that they cooked on a fire."
    },
    {
      "verse": "12",
      "text": "The manna that they had been eating no longer appeared. The Israelite people never ate manna again. Now they could eat the food that was grown in Canaan."
    },
    {
      "verse": "13",
      "text": "While Joshua was near Jericho, a man appeared to him. Joshua looked up and there he was! He stood in front of Joshua with a sword in his hand. Joshua went towards him. He asked the man, ‘Are you here to help us, or to help our enemies? ’"
    },
    {
      "verse": "14",
      "text": "The man answered, ‘Neither. I am the captain of the Lord's army. Now I am here! ’Joshua fell on the ground to worship the man and he said, ‘Sir, I am your servant. Tell me what I should do. ’ Joshua fell on the ground to worship the man and he said, ‘Sir, I am your servant. Tell me what I should do. ’"
    },
    {
      "verse": "15",
      "text": "The captain of the Lord's army said, ‘Remove your shoes from your feet. You are standing on holy ground. ’ Joshua did that."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "The people of Jericho had shut the gates of their city to make it safe. No one could go in or out of the city."
    },
    {
      "verse": "2",
      "text": "The Lord said to Joshua, ‘I will soon give Jericho to you. I will put its king and all its brave soldiers under your power."
    },
    {
      "verse": "3",
      "text": "You and all your soldiers must march round the city once each day, for six days."
    },
    {
      "verse": "4",
      "text": "Seven priests will walk in front of the Covenant Box. They will carry trumpets as they walk. On the seventh day, you and your soldiers must march round the city seven times. At the same time, the priests will blow into their trumpets."
    },
    {
      "verse": "5",
      "text": "Then they will make one long loud noise with their trumpets. As soon as you hear this, all the soldiers must give a loud shout. Then the city walls will fall down. The whole army will go straight into the city. ’"
    },
    {
      "verse": "6",
      "text": "Joshua called the priests to come to him. He told them, ‘Pick up the Lord's Covenant Box. Seven priests must march in front of it. They must hold seven trumpets, one each. ’"
    },
    {
      "verse": "7",
      "text": "Then Joshua told the people to start marching round the city. A group of soldiers should march in front of the Lord's Covenant Box."
    },
    {
      "verse": "8",
      "text": "Joshua finished speaking to the people. Then the seven priests carrying their trumpets marched in front of the Covenant Box. They made a noise on their trumpets as the Covenant Box followed them."
    },
    {
      "verse": "9",
      "text": "While the priests made a noise on the trumpets, some soldiers marched in front of them. Another group of soldiers followed behind the Covenant Box. The trumpets were making a noise all this time."
    },
    {
      "verse": "10",
      "text": "But Joshua had said to the people, ‘Do not shout or speak aloud. Do not say anything until I tell you. When the right day comes, I will tell you, “Now shout aloud to attack! ” When I tell you that, then shout! ’"
    },
    {
      "verse": "11",
      "text": "Joshua made them march round the city once with the Lord's Covenant Box. Then they returned to their tents, and slept there that night."
    },
    {
      "verse": "12",
      "text": "Joshua got up early the next morning, and the priests picked up the Lord's Covenant Box again."
    },
    {
      "verse": "13",
      "text": "The seven priests who carried the trumpets marched in front of the Covenant Box. They were making a noise with their trumpets. One group of soldiers marched in front of the priests. Another group of soldiers marched behind the Covenant Box. The trumpets made a noise all the time."
    },
    {
      "verse": "14",
      "text": "That is how they marched round the city on the second day. They marched round once and then they returned to their tents. They did the same thing for six days."
    },
    {
      "verse": "15",
      "text": "On the seventh day, they got up at dawn again. They marched round the city as they had done before. But this time they did it seven times."
    },
    {
      "verse": "16",
      "text": "The seventh time, the priests made a long, loud noise on their trumpets. Joshua told the people, ‘Shout aloud to attack! The Lord has given the city to you!"
    },
    {
      "verse": "17",
      "text": "The city and everything that is in it belongs to the Lord, so destroy it all. Only the prostitute Rahab and all the people who are with her in her house will live. This is because she hid the two men that we sent."
    },
    {
      "verse": "18",
      "text": "Be careful! Do not take for yourselves the valuable things that belong to the Lord. If you do that, you will cause bad trouble to come to the whole Israelite army. The Lord will destroy us all."
    },
    {
      "verse": "19",
      "text": "Everything that is made from silver, gold, bronze and iron belong to the Lord as his holy things. You must store them with his other valuable things. ’"
    },
    {
      "verse": "20",
      "text": "When the trumpets made a noise, all the people gave a loud shout to attack the city. When they did this, the walls of the city fell down. All the soldiers went up into the city. They went straight in and they took the city for themselves."
    },
    {
      "verse": "21",
      "text": "They destroyed everything that lived in the city, as a gift to the Lord. With their weapons, they killed men and women, young people and old people, as well as cows, sheep and donkeys."
    },
    {
      "verse": "22",
      "text": "Joshua said to the two men that Rahab had hidden, ‘Go into her house. Bring her out, with all her family who are there with her. That is what you promised to do for her. ’"
    },
    {
      "verse": "23",
      "text": "So the young men who had been to look at the city went to her house. They brought out Rahab and her whole family. That was her father and her mother, and her brothers and all who belonged to her. They took them to a place that was near the Israelite tents."
    },
    {
      "verse": "24",
      "text": "Then they burned the whole city and everything that was in it. They stored the gold, silver, bronze and iron things with the Lord's valuable things."
    },
    {
      "verse": "25",
      "text": "But Joshua kept Rahab safe, as well as her family and everyone who belonged to her. Rahab had hidden the men that Joshua sent to find out about Jericho city. Because she did that, her family still lives among the Israelites, even today."
    },
    {
      "verse": "26",
      "text": "At that time, Joshua made a strong promise. He said, ‘If anyone tries to build Jericho city again, the Lord will punish him as a guilty man. When he starts to build, his oldest son will die. When he puts up the city's gates, his youngest son will die. ’"
    },
    {
      "verse": "27",
      "text": "So the Lord was with Joshua to help him. Joshua became famous everywhere in the land."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "The Israelites did not obey what Joshua had said about the valuable things that belonged to God. Achan took some of these things for himself. He was Carmi's son, who was the son of Zimri, who was the son of Zerah. They were from the tribe of Judah. The Lord was very angry with the Israelites."
    },
    {
      "verse": "2",
      "text": "Joshua sent some men to go from Jericho to Ai. That is a city near to Beth Aven, and east of Bethel. He said to the men, ‘Go up and look at the land near there secretly. ’ So the men went to Ai to see what they could discover."
    },
    {
      "verse": "3",
      "text": "The men came back and they said to Joshua, ‘There are not many men in Ai. Do not send our whole army to attack it. 2, 000 or 3, 000 men will be enough to take the city. ’"
    },
    {
      "verse": "4",
      "text": "So about 3, 000 Israelite men went to attack Ai. But the men of Ai made them run away."
    },
    {
      "verse": "5",
      "text": "Israelite soldiers. They chased them down the hill as far as Shebarim. They killed the Israelites as they ran down the hill. When the people of Israel heard this, they became very frightened."
    },
    {
      "verse": "6",
      "text": "Joshua was so upset that he tore his clothes. He fell with his face to the ground in front of the Lord's Covenant Box. He stayed there until evening time, together with the Israelite leaders. They all put dirt on their heads."
    },
    {
      "verse": "7",
      "text": "Joshua said, ‘Almighty Lord, why did you ever bring us over the Jordan River? Did you bring us here so that the Amorites could destroy us? It would have been better for us to stay on the other side of the Jordan!"
    },
    {
      "verse": "8",
      "text": "Now our army has had to run away from our enemies! Lord, there is nothing more for me to say!"
    },
    {
      "verse": "9",
      "text": "The Canaanites and the other tribes who live in this land will hear about what has happened. They will come to attack us and they will completely destroy us all. If that happens, nobody will ever respect your great name again! ’"
    },
    {
      "verse": "10",
      "text": "The Lord said to Joshua, ‘Stand up! Why are you lying there on the ground?"
    },
    {
      "verse": "11",
      "text": "Israel has done a bad thing. They have not obeyed the command of the covenant that I made with them. That have taken for themselves some of the valuable things that belong to me. They have taken them and they have tried to deceive me. They have hidden them among their own things."
    },
    {
      "verse": "12",
      "text": "That is why the Israelites are running away from their enemies. They themselves must now be destroyed because they belong to me. If you want me to continue to help you, you must destroy everything that belongs to me. You should not have taken those valuable things for yourselves."
    },
    {
      "verse": "13",
      "text": "So stand up now! Tell the people to make themselves clean. Make yourselves ready! Tomorrow you will come to stand in front of me. I, the Lord God of Israel tell you, “Israelite people, you have kept some of the things that I told you to destroy. You will not win against your enemies until you have removed those things! ”"
    },
    {
      "verse": "14",
      "text": "In the morning, tell the Israelites to come to me, one tribe at a time. I will choose one tribe. The clans of that tribe will come in front of me, one clan at a time. I will choose one clan. Then the families of that clan will come in front of me, family by family. I will choose one family. Then the men of that family will come to stand in front of me, one by one."
    },
    {
      "verse": "15",
      "text": "Then I will show you which man has taken the things that belong to me. You must kill that man and burn his body. You must kill him and everything that he has, together with all his family. He has done a very bad thing that no Israelite should ever do. He has turned against the covenant that I made with my people. ’"
    },
    {
      "verse": "16",
      "text": "Early the next morning, Joshua told the tribes to come and stand in front of the Lord. They came one tribe at a time. The Lord chose the tribe of Judah."
    },
    {
      "verse": "17",
      "text": "Then clans of the tribe of Judah came, one clan at a time. The Lord chose Zerah's clan. Families from Zerah's clan then came, one family at a time. The Lord chose Zimri's family."
    },
    {
      "verse": "18",
      "text": "Joshua then made each man from Zimri's family come, one by one. The Lord chose Achan, son of Carmi, son of Zimri, son of Zerah, from the tribe of Judah."
    },
    {
      "verse": "19",
      "text": "Then Joshua said to Achan, ‘My son, tell the truth, to show that you respect the Lord, Israel's God. Tell me what you have done. Do not try to deceive me. ’"
    },
    {
      "verse": "20",
      "text": "Achan replied, ‘It is true! I have done a bad thing against the Lord, Israel's God. This is what I have done."
    },
    {
      "verse": "21",
      "text": "I found a beautiful coat from Babylon, and I found 200 silver coins, and a piece of gold that weighed half a kilogram. I wanted them so much that I took them for myself. I hid them in the ground in my tent. The silver coins are under the other things. ’"
    },
    {
      "verse": "22",
      "text": "So Joshua sent some men to go to Achan's tent. They ran there and they found the things that Achan had hidden. The silver coins were under the other things."
    },
    {
      "verse": "23",
      "text": "The men took the things out from the tent. They brought them to Joshua and all the other Israelites. They put them all on the ground in front of the Lord."
    },
    {
      "verse": "24",
      "text": "Then Joshua and all the people took Achan, the son of Zerah, and the silver coins, the coat, and the heavy piece of gold. They also took his sons, his daughters, and his cows, sheep and donkeys. They took all his things to Achor valley."
    },
    {
      "verse": "25",
      "text": "Joshua said, ‘Why did you cause so much trouble to come to us? The Lord will certainly give you trouble today! ’Then all the Israelites threw stones at him until he died. They also killed his family and they burned all the bodies."
    },
    {
      "verse": "26",
      "text": "They put a big heap of stones over him. They are still there today. That is why the place is still called ‘Trouble Valley’. Then the Lord was not angry with his people any more."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Then the Lord said to Joshua, ‘Do not be afraid. Continue to be brave! Take the whole army with you and go to attack Ai. This time, I will give the king and all his people to you. I will also give to you the city and its land."
    },
    {
      "verse": "2",
      "text": "You must destroy the city and its king as you destroyed Jericho and its king. But this time you may take their valuable things and their animals for yourselves. Hide some of your men behind the city, so that they are ready to attack. ’"
    },
    {
      "verse": "3",
      "text": "So Joshua and the whole army marched towards Ai. Joshua chose 30, 000 of the best soldiers and he sent some of them out at night time."
    },
    {
      "verse": "4",
      "text": "He said to them, ‘Listen carefully. Go and hide behind the city. Stay near to it. Be ready to attack!"
    },
    {
      "verse": "5",
      "text": "In the morning, I will march towards the city with our other soldiers. When we get near to the city, the enemy's men will come out of the city to fight against us, as they did before. Then we will turn round and we will run away."
    },
    {
      "verse": "6",
      "text": "They will chase us away from the city. They will say, “The Israelites are running away from us, as they did before. ” We will continue to run away from them."
    },
    {
      "verse": "7",
      "text": "Then you must leave the place where you have hidden. Go into the city and take it. The Lord your God will give it to you."
    },
    {
      "verse": "8",
      "text": "When you have taken the city, start to burn it. Do what the Lord has told you to do. Be sure that you obey my commands. ’"
    },
    {
      "verse": "9",
      "text": "Then Joshua sent the men away. They went and they hid on the west side of Ai, between Bethel and Ai. But Joshua stayed with his other soldiers that night."
    },
    {
      "verse": "10",
      "text": "Early the next morning, Joshua took the army to march towards Ai. He and the leaders of Israel marched in front."
    },
    {
      "verse": "11",
      "text": "The soldiers who were with Joshua marched up to the city. They stopped in front of it, on the north side. They put up their tents there, where there was a valley between them and the city."
    },
    {
      "verse": "12",
      "text": "Joshua had already sent about 5, 000 men to hide on the west side of the city, between Bethel and Ai."
    },
    {
      "verse": "13",
      "text": "The whole Israelite army was ready to fight. Most of them were with their tents on the north side of the city. The other soldiers were hiding on the west side of the city. That night Joshua went down into the valley."
    },
    {
      "verse": "14",
      "text": "The king of Ai saw that Israel's army had arrived. Early the next morning, the king and his army hurried out of the city. They wanted to fight against Israel's army at the same place as before, on the hill near the Jordan Valley. But the king of Ai did not know that some Israelite soldiers were hiding behind the city."
    },
    {
      "verse": "15",
      "text": "Joshua and his army let the men of Ai chase after them. They pretended to be afraid. They ran towards the desert."
    },
    {
      "verse": "16",
      "text": "The king told all the men who remained in the city to chase the Israelites. So they continued to chase after them, far away from their city."
    },
    {
      "verse": "17",
      "text": "No men remained in Ai or Bethel. They all chased after the Israelites. There was nobody left to keep the city safe."
    },
    {
      "verse": "18",
      "text": "Then the Lord said to Joshua, ‘Hold out the spear that is in your hand. Point it towards Ai. I am now giving the city to you. ’So Joshua held out his spear towards Ai. So Joshua held out his spear towards Ai."
    },
    {
      "verse": "19",
      "text": "As soon as he did this, the men who were hiding behind the city came out quickly. They ran into the city and they took it. Immediately, they used fire to burn it."
    },
    {
      "verse": "20",
      "text": "The men of Ai looked behind them and they saw smoke in the sky above the city. But they could do nothing to escape. The Israelites who had been running away from them now turned round to fight them."
    },
    {
      "verse": "21",
      "text": "Joshua and his army also saw the smoke. They knew that the other group of soldiers had taken the city. So they turned round and began to attack the men of Ai."
    },
    {
      "verse": "22",
      "text": "Now the Israelites who had gone into the city also came out to fight. So the men of Ai were in between the two groups of Israelite soldiers. The Israelites killed all the men of Ai."
    },
    {
      "verse": "23",
      "text": "Only the king of Ai was still alive. They caught him and they took him to Joshua."
    },
    {
      "verse": "24",
      "text": "The Israelites killed all the men who had lived in Ai. They killed them when they chased them towards the desert. Then the Israelite soldiers went back to Ai and they killed everyone there."
    },
    {
      "verse": "25",
      "text": "All the people of Ai died on that day. That was 12, 000 men and women."
    },
    {
      "verse": "26",
      "text": "Joshua continued to point his spear at Ai, until his army had killed every person who lived there."
    },
    {
      "verse": "27",
      "text": "But the Israelites took the valuable things and the animals for themselves. That was what the Lord had told Joshua."
    },
    {
      "verse": "28",
      "text": "Joshua burned the city and he broke down its walls. It is still like that today."
    },
    {
      "verse": "29",
      "text": "He hanged the king of Ai on a tree. He left his body there until evening. At sunset, Joshua told his men to cut the body down. They threw it on the ground outside the city's gate. They covered it with a heap of stones. Those stones are still there today."
    },
    {
      "verse": "30",
      "text": "Then Joshua built an altar on Ebal mountain, to worship the Lord, Israel's God."
    },
    {
      "verse": "31",
      "text": "He built it as the Lord's servant, Moses, had told the Israelites to do. Moses had written this on the scroll of God's laws. The law said, ‘You must build an altar with whole stones that you have not cut. Do not use any iron tools on them. ’ They made burnt offerings on the altar to worship the Lord. They also made sacrifices as friendship offerings."
    },
    {
      "verse": "32",
      "text": "The Israelites watched Joshua as he made a copy of God's Law on the stones. This was the Law that Moses had written."
    },
    {
      "verse": "33",
      "text": "All the Israelites stood on each side of the Covenant Box, with their faces towards the priests who carried it. The leaders, officers, and judges were there, as well as foreign people who lived with the Israelites. Half the people stood with their backs to Mount Gerizim. The other half stood with their backs to Mount Ebal. Moses had told them to stand like that when the Lord wanted to bless them."
    },
    {
      "verse": "34",
      "text": "Then Joshua read the whole Law aloud to them. He read the blessings and the curses, as they are written on the scroll of the Law."
    },
    {
      "verse": "35",
      "text": "Joshua read aloud every command that Moses had written. He read it to all the Israelite people. The women, children and the foreign people who lived with them also listened."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "All the kings who lived west of the Jordan River heard about what had happened at Ai. They were the kings who ruled in the hill country, in the low hills in the west, and all the coast of the Mediterranean Sea, as far as Lebanon. They were the kings of the Hittites, Amorites, Canaanites, Perizzites, Hivites and Jebusites."
    },
    {
      "verse": "2",
      "text": "They joined together to fight against Joshua and the Israelites."
    },
    {
      "verse": "3",
      "text": "Some Hivite people who lived in Gibeon heard how Joshua had won against Jericho and Ai."
    },
    {
      "verse": "4",
      "text": "So they had a clever idea. Some men took old bags of food and broken bags of wine that had holes in them. They put these things on their donkeys."
    },
    {
      "verse": "5",
      "text": "They wore old shoes on their feet, and they dressed themselves in old clothes. They took some bread that was old and dry."
    },
    {
      "verse": "6",
      "text": "They arrived at the tents of the Israelites in Gilgal. They said to Joshua and to the men of Israel, ‘We have come from a land that is very far away. Please let us make an agreement that we will not fight each other. ’"
    },
    {
      "verse": "7",
      "text": "But the men of Israel said to the Hivites, ‘Perhaps you live near to us. So we could not make a promise not to fight against you. ’"
    },
    {
      "verse": "8",
      "text": "The Hivites said to Joshua, ‘If you agree, we will become your servants. ’Joshua asked them, ‘Who are you? Where do you come from? ’ Joshua asked them, ‘Who are you? Where do you come from? ’"
    },
    {
      "verse": "9",
      "text": "They answered, ‘We, your servants, have come from a country that is very far away. We heard about the Lord, who is your God. We have heard about all the things that he did in Egypt."
    },
    {
      "verse": "10",
      "text": "We also heard what he did to the two kings of the Amorites. They ruled cities east of the Jordan: Sihon, king of Heshbon, and Og, king of Bashan, who lived in Ashtaroth."
    },
    {
      "verse": "11",
      "text": "Our leaders and all our people told us to come to meet you. Our leaders said, “Take food and drink for your journey. Go to meet them, and say to them, ‘We want to be your servants. Please promise not to fight against us. ’ ”"
    },
    {
      "verse": "12",
      "text": "We have come a very long way. This bread was warm when we put it in our bags on the day that we left home. But see how hard and dry it has become."
    },
    {
      "verse": "13",
      "text": "These bags of wine were new, but see how old and spoiled they are now. Our clothes and our shoes have become old as we made our long journey. ’"
    },
    {
      "verse": "14",
      "text": "The Israelite men tasted some of the Gibeonites' food, but they did not ask the Lord what they should do."
    },
    {
      "verse": "15",
      "text": "So Joshua agreed that they would not kill the people of Gibeon. The Israelite leaders also said that they would obey this agreement."
    },
    {
      "verse": "16",
      "text": "Three days after they made this agreement, the Israelites discovered that the Gibeonites lived near to them."
    },
    {
      "verse": "17",
      "text": "So the Israelites left Gilgal to find the cities where the Hivites lived. After three days they arrived at their cities: Gibeon, Kephirah, Beeroth and Kiriath-Jearim."
    },
    {
      "verse": "18",
      "text": "The Israelites did not attack them, because of the promise that their leaders had made. They had made a strong promise in the name of the Lord God of Israel that they would not kill the Gibeonites. The Israelite people were angry with their leaders, because of the agreement."
    },
    {
      "verse": "19",
      "text": "But all the leaders said to them, ‘We have made a strong promise to the Lord, Israel's God. So now we cannot hurt the Gibeonites."
    },
    {
      "verse": "20",
      "text": "But this is what we will do. We will let them live, because we made a strong promise to do that. Then God will not punish us."
    },
    {
      "verse": "21",
      "text": "We will let them live, but they will become our servants. They will cut wood and they will fetch water for all the Israelite people. ’ That is what the Israelite leaders decided to do."
    },
    {
      "verse": "22",
      "text": "Joshua called the Gibeonites to come to him. He asked them, ‘Why did you deceive us like that? You said that you lived far away from us. But you really live near to us."
    },
    {
      "verse": "23",
      "text": "Because you told lies to us, you will always have to be our servants. You will cut wood and you will fetch water to serve our God. ’"
    },
    {
      "verse": "24",
      "text": "The Gibeonites said to Joshua, ‘We heard about the command that the Lord your God had given to his servant, Moses. We know that he told Moses to take the whole of our land for you to live in. We know that you must kill all the people who live there now. Because of that, we were very afraid that you would kill us. That is why we did what we did."
    },
    {
      "verse": "25",
      "text": "Now we are under your power. You must decide what to do with us. Do whatever you think is right and good. ’"
    },
    {
      "verse": "26",
      "text": "So Joshua agreed. He did not let the Israelites kill the Gibeonites."
    },
    {
      "verse": "27",
      "text": "Instead, they made the Gibeonites cut wood and fetch water, as servants for the Israelite people. They would also do this for the priests who served the Lord at his altar. They are still doing this, at the place that the Lord has chosen for his altar."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "The king of Jerusalem was called Adoni-Zedek. He heard how Joshua had taken Ai city, as he had also taken Jericho city. He heard that Joshua had destroyed those cities and their kings. He also heard that the Israelites had made an agreement with the Gibeonites. They promised that they would not attack the Gibeonites. He knew that the Gibeonites now lived among the Israelites."
    },
    {
      "verse": "2",
      "text": "The king and the people of Jerusalem were very afraid, because Gibeon was a great city. It was bigger than Ai, like a city with a king. All its men were brave soldiers."
    },
    {
      "verse": "3",
      "text": "So King Adoni-Zedek asked some other kings to join with him to attack Gibeon. They were Hoham, king of Hebron, Piram, king of Jarmuth, Japhia, king of Lachish and Debir, king of Eglon."
    },
    {
      "verse": "4",
      "text": "Adoni-Zedek said to them, ‘The Gibeonites have made an agreement with Joshua and the Israelites not to fight them. So please come and help me to attack Gibeon. ’"
    },
    {
      "verse": "5",
      "text": "So the five Amorite kings with their armies met together. They were the kings of Jerusalem, Hebron, Jarmuth, Lachish and Eglon. They put their soldiers near Gibeon city, and they began to attack it."
    },
    {
      "verse": "6",
      "text": "The Gibeonites sent a message to Joshua at Gilgal. They said, ‘Please sir, do not refuse to help us! Come quickly and save us. All the Amorite kings from the hills have joined together to attack us. ’"
    },
    {
      "verse": "7",
      "text": "So Joshua took his whole army and they marched up from Gilgal. He had all his best soldiers with him."
    },
    {
      "verse": "8",
      "text": "The Lord said to Joshua, ‘Do not be afraid of them. I will cause you to win against their armies. They will not be strong enough to fight against you. ’"
    },
    {
      "verse": "9",
      "text": "The Israelite soldiers marched all night from Gilgal. When they reached Gibeon, they quickly attacked the Amorite armies by surprise."
    },
    {
      "verse": "10",
      "text": "The Lord caused the Amorites to become confused when they saw the Israelite army. So the Israelites won a great battle there at Gibeon. They chased their enemies along the road to Beth Horon. They continued to kill the Amorite soldiers as far as Azekah and Makkedah."
    },
    {
      "verse": "11",
      "text": "As the Amorites ran down the hill from Beth Horon, the Lord sent large stones of hail down from the sky. The hail killed them all the way to Azekah. More of the Amorite soldiers died because of the heavy stones of hail, than because the Israelite soldiers killed them."
    },
    {
      "verse": "12",
      "text": "So the Lord caused the Israelites to win the fight against the Amorites. After the battle that day, Joshua stood in front of Israel and he prayed to the Lord. He said, ‘Sun, stand still over Gibeon city. Moon, stand still over Aijalon valley. ’ ‘Sun, stand still over Gibeon city. Moon, stand still over Aijalon valley. ’"
    },
    {
      "verse": "13",
      "text": "So the sun stood still and the moon stopped moving across the sky. They stayed still while the Israelites punished their enemies. People wrote about this in the Scroll of Jashar. The sun stopped in the middle of the sky. It did not go down for about a whole day."
    },
    {
      "verse": "14",
      "text": "A day like that had never happened before, and it has not happened since then. The Lord answered the prayer of a man in such a great way! The Lord himself was fighting the battle on behalf of the Israelites!"
    },
    {
      "verse": "15",
      "text": "Then Joshua and all the Israelite army went back to their tents at Gilgal."
    },
    {
      "verse": "16",
      "text": "The five kings had run away from the Israelite soldiers. They had hidden in a cave at Makkedah."
    },
    {
      "verse": "17",
      "text": "Joshua heard that they were hiding there."
    },
    {
      "verse": "18",
      "text": "He said to his men, ‘Take some big stones and cover the front of the cave. Put some men there to watch the cave."
    },
    {
      "verse": "19",
      "text": "But you must continue to chase after your enemies. Do not stop now! Catch them! Do not let them reach their cities where they will be safe. Remember that the Lord your God has caused you to win against them. ’"
    },
    {
      "verse": "20",
      "text": "So Joshua and the Israelites destroyed nearly all the Amorite armies. But a few of the Amorites escaped and they reached their strong cities."
    },
    {
      "verse": "21",
      "text": "Then the whole Israelite army returned to Joshua at Makkedah. All the people in the land were too afraid to speak against the Israelites."
    },
    {
      "verse": "22",
      "text": "Then Joshua said to his men, ‘Take away the stones to open the cave where the five kings are. Bring them out here to me. ’"
    },
    {
      "verse": "23",
      "text": "So they brought the five kings to Joshua. They were the kings of Jerusalem, Hebron, Jarmuth, Lachish and Eglon."
    },
    {
      "verse": "24",
      "text": "When they had brought the kings to Joshua, he called the men of Israel to meet there. He said to the officers of his army, ‘Put your feet on the necks of these kings. ’ They did as he told them."
    },
    {
      "verse": "25",
      "text": "Joshua said to them, ‘Do not be afraid. Be very strong and brave. Look at these kings! This is what the Lord will do to all the enemies that you will fight against. ’"
    },
    {
      "verse": "26",
      "text": "Then Joshua killed the five kings with his sword. He hung their bodies on five trees. They remained there until evening time."
    },
    {
      "verse": "27",
      "text": "At sunset, Joshua told his men to take the kings down from the trees. They threw them into the cave where they had been hiding. They put big stones over the front of the cave. The stones are still there today."
    },
    {
      "verse": "28",
      "text": "That day, Joshua attacked Makkedah city. He took it, together with its king. He destroyed everyone who lived in it. He did not leave anyone alive. He did the same thing to the king of Makkedah as he had done to the king of Jericho."
    },
    {
      "verse": "29",
      "text": "After that, Joshua and his army marched from Makkedah to Libnah. They attacked Libnah city."
    },
    {
      "verse": "30",
      "text": "The Lord gave them power over that city and its king. Joshua destroyed the city and everyone who lived in it. He did not leave anyone alive. They did the same thing to Libnah's king as they had done to the king of Jericho."
    },
    {
      "verse": "31",
      "text": "After this, Joshua and all the Israelite army marched from Libnah to Lachish. They attacked Lachish city from all sides."
    },
    {
      "verse": "32",
      "text": "The Lord gave them power over the city. They fought for two days and then they took the city. They killed everyone who lived in it, as they had done at Libnah."
    },
    {
      "verse": "33",
      "text": "Then Horam, king of Gezer, came to help the people of Lachish. But Joshua's army fought against him and his army. He killed them all, with nobody left alive."
    },
    {
      "verse": "34",
      "text": "Then Joshua and his army marched from Lachish to Eglon. They attacked Eglon city from all sides."
    },
    {
      "verse": "35",
      "text": "They took it on the same day. They killed everyone who lived in that city, as they had done at Lachish."
    },
    {
      "verse": "36",
      "text": "After this, Joshua and all the Israelite army marched up from Eglon to Hebron. They attacked Hebron city."
    },
    {
      "verse": "37",
      "text": "They took the city and they killed its king. They killed all the people who lived there, and the people in the towns near to it. They destroyed the whole city, as they had done at Eglon. They did not leave anyone alive."
    },
    {
      "verse": "38",
      "text": "Then Joshua and his army turned round and they marched to Debir. They attacked Debir city."
    },
    {
      "verse": "39",
      "text": "They took the city, its king and all the towns near to it. They killed everyone who lived there. They did the same thing to Debir and its king as they had done to Hebron, and to Libnah and its king."
    },
    {
      "verse": "40",
      "text": "In that way, Joshua took the whole land and all the kings who ruled there. He took the hill country, the Negev in the south, the low hills in the west and the mountains in the east. He killed all the people who lived there. He did not leave anyone alive. The Lord God of Israel had told him to do this."
    },
    {
      "verse": "41",
      "text": "Joshua took the whole region, from Kadesh-Barnea in the south to Gaza near the sea. This included all of Goshen, as far as Gibeon in the north."
    },
    {
      "verse": "42",
      "text": "Joshua won all these battles in one long fight. He won against all these kings and their lands. He won because the Lord, Israel's God, was fighting on Israel's behalf."
    },
    {
      "verse": "43",
      "text": "After this, Joshua and all Israel's army went back to their tents at Gilgal."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "Jabin, king of Hazor, heard what had happened. So he sent a message to Jobab, king of Madon, and to the king of Shimron and the king of Acshaph."
    },
    {
      "verse": "2",
      "text": "He also sent a message to the kings of the hill country in the north, in the Jordan Valley, south of Galilee. He also sent a message to people in the low hills and Naphoth Dor in the west."
    },
    {
      "verse": "3",
      "text": "So Canaanite people came from the east and from the west. They were Amorites, Hittites, Perizzites and Jebusites who lived in the hills. They were also Hivites who lived near Hermon mountain, in the region of Mizpah."
    },
    {
      "verse": "4",
      "text": "All these kings came with their big armies. They had many horses and chariots. The soldiers were too many to count."
    },
    {
      "verse": "5",
      "text": "These kings all joined together to fight against the Israelites. They put up their tents near the water at Merom."
    },
    {
      "verse": "6",
      "text": "The Lord said to Joshua, ‘Do not be afraid of them. This time tomorrow they will all be dead! I will give all of them to you Israelites. You must cut the legs of their horses so that they cannot run well. You must also burn their chariots. ’"
    },
    {
      "verse": "7",
      "text": "So Joshua and his whole army went to attack them at the Waters of Merom. They quickly attacked them by surprise."
    },
    {
      "verse": "8",
      "text": "The Lord caused the Israelites to win against them. The Israelite soldiers chased them as far as Sidon, Misrephoth Maim and the valley of Mizpah in the east. They killed their enemies as they chased them, until they were all dead."
    },
    {
      "verse": "9",
      "text": "Joshua did what the Lord had commanded him to do. He cut their horses' legs and he burned their chariots."
    },
    {
      "verse": "10",
      "text": "At that time, Hazor was the most important city among all those kingdoms that fought against the Israelites. So Joshua turned back and attacked Hazor. He killed its king."
    },
    {
      "verse": "11",
      "text": "The Israelites killed everyone who lived there. Nothing in the city was left alive. They burned the city and destroyed it."
    },
    {
      "verse": "12",
      "text": "Joshua took all these cities and he killed all their kings. He destroyed them all, as the Lord's servant Moses had told him to do."
    },
    {
      "verse": "13",
      "text": "But the Israelites did not burn the cities that were built on small hills. Hazor was the only city like that which Joshua did burn."
    },
    {
      "verse": "14",
      "text": "The Israelites took for themselves all the animals and the valuable things from those cities. But they killed all the people. They did not let any of them live."
    },
    {
      "verse": "15",
      "text": "Moses had told all the Lord's commands to Joshua. Joshua obeyed all the Lord's commands. He did everything that the Lord had told Moses."
    },
    {
      "verse": "16",
      "text": "Joshua's army won against all the people who were living in the land. He took the hill country, the Negev in the south, and the land of Goshen. He took the low hills in the west and the Jordan Valley. He took the mountains and the hills of Israel."
    },
    {
      "verse": "17",
      "text": "The land went from Halak mountain near Edom country, to Baal Gad in the Lebanon valley, below Hermon mountain. He caught all the kings of those regions and he killed them all."
    },
    {
      "verse": "18",
      "text": "Joshua was fighting against those kings for a long time."
    },
    {
      "verse": "19",
      "text": "None of those kingdoms agreed not to fight against the Israelites, except the Hivites who lived in Gibeon. The Israelites fought battles against all the other kingdoms and they won."
    },
    {
      "verse": "20",
      "text": "The Lord had caused the minds of those people to become hard. So they all decided to fight against the Israelites. The Lord wanted the Israelites to destroy those people completely, as he had commanded Moses."
    },
    {
      "verse": "21",
      "text": "During that time, Joshua went to fight against the Anakites, who lived in the hill country. They lived in Hebron, Debir and Anab, and among the hills of Judah and Israel. Joshua destroyed them all, and all their towns."
    },
    {
      "verse": "22",
      "text": "So no Anakites remained in Israel, except for a few who lived in Gaza, Gath and Ashdod."
    },
    {
      "verse": "23",
      "text": "In that way, Joshua took the whole land. The Lord had promised Moses that he would give the land to his people. Joshua gave a part of the land to each tribe, for them to live in. After all that, the people did not have to fight any more."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "The Israelites killed these kings who ruled on the east side of the Jordan River. They destroyed them and they took their land. Their land went from the Arnon valley to Hermon mountain. It included all the land on the east side of the Jordan Valley."
    },
    {
      "verse": "2",
      "text": "They killed Sihon, king of the Amorites, who lived in Heshbon. He ruled half of the Gilead region. That is from Aroer that was on the edge of the Arnon valley, as far as the Jabbok river. The Ammonites had the land on the other side of the river."
    },
    {
      "verse": "3",
      "text": "King Sihon's land also went along the east side of the Jordan Valley from the sea of Galilee to the Salt Sea. His land went south to Beth Jeshimoth and as far as Pisgah mountain."
    },
    {
      "verse": "4",
      "text": "They killed Og, king of Bashan. He was one of the last Rephaites. He lived in Ashtaroth and in Edrei."
    },
    {
      "verse": "5",
      "text": "He ruled the land from Hermon mountain and Salecah in the north, and all of the Bashan region in the east. His land went as far as the borders of the kingdoms of Geshur and Maakah. He ruled half of the Gilead region, as far as the border of King Sihon of Heshbon."
    },
    {
      "verse": "6",
      "text": "The Lord's servant, Moses, and the Israelites won against these kings. Moses gave their land to the tribes of Reuben, Gad and half the tribe of Manasseh to live in."
    },
    {
      "verse": "7",
      "text": "Joshua and the Israelites killed these kings who ruled on the west side of the Jordan River. Joshua gave these kings' land to the Israelite tribes for them to live in. He gave a different piece of land to each tribe. Their land went from Baal Gad in the Lebanon valley to Halak mountain, which is near Seir. kings."
    },
    {
      "verse": "8",
      "text": "This included the hill country, the low hills in the west, the Jordan Valley, the mountains, the wilderness and the Negev. That was the land that belonged to the Hittites, Amorites, Canaanites, Perizzites, Hivites and Jebusites."
    },
    {
      "verse": "9",
      "text": "Joshua took the land of these kings: king of Jericho, king of Ai (near Bethel),"
    },
    {
      "verse": "10",
      "text": "king of Jerusalem, king of Hebron,"
    },
    {
      "verse": "11",
      "text": "king of Jarmuth, king of Lachish,"
    },
    {
      "verse": "12",
      "text": "king of Eglon, king of Gezer,"
    },
    {
      "verse": "13",
      "text": "king of Debir, king of Geder,"
    },
    {
      "verse": "14",
      "text": "king of Hormah, king of Arad,"
    },
    {
      "verse": "15",
      "text": "king of Libnah, king of Adullam,"
    },
    {
      "verse": "16",
      "text": "king of Makkedah, king of Bethel,"
    },
    {
      "verse": "17",
      "text": "king of Tappuah, king of Hepher,"
    },
    {
      "verse": "18",
      "text": "king of Aphek, king of Lasharon,"
    },
    {
      "verse": "19",
      "text": "king of Madon, king of Hazor,"
    },
    {
      "verse": "20",
      "text": "king of Shimron Meron, king of Acshaph,"
    },
    {
      "verse": "21",
      "text": "king of Taanach, king of Megiddo,"
    },
    {
      "verse": "22",
      "text": "king of Kedesh, king of Jokneam in Carmel,"
    },
    {
      "verse": "23",
      "text": "king of Dor in Naphoth Dor, king of Goyim in Gilgal,"
    },
    {
      "verse": "24",
      "text": "king of Tirzah. Joshua and the Israelites took the land of these 31 kings."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "Joshua had become a very old man. The Lord said to him, ‘You are now very old. There is still a lot of land that you have not yet taken."
    },
    {
      "verse": "2",
      "text": "This is the land left for you to take: All the land of the Philistines and the Geshurites."
    },
    {
      "verse": "3",
      "text": "Their land goes from the Shihor river on the east side of Egypt, to the border of Ekron's land. That part belongs to the Canaanites. The land of the Philistine rulers in Gaza, Ashdod, Ashkelon, Gath and Ekron. There is also the land of the Avvites in the south."
    },
    {
      "verse": "4",
      "text": "You must take all the land of the Canaanites, which goes from Arah in Sidon region, and continues to Aphek, as far as the border of the Amorites."
    },
    {
      "verse": "5",
      "text": "There is also the land of the Gebalites, and all of Lebanon in the east. That land goes from Baal Gad at the side of Hermon mountain, to Lebo-Hamath."
    },
    {
      "verse": "6",
      "text": "I myself will chase out all the people of Sidon in front of the Israelites. I will chase them out of the hill country, from Lebanon as far as Misrephoth Maim. You must give this land to the tribes of Israel, as I have already told you."
    },
    {
      "verse": "7",
      "text": "Each of the nine tribes, and the half tribe of Manasseh, must receive its own part of the land. ’"
    },
    {
      "verse": "8",
      "text": "Moses had already given land to the tribes of Reuben, Gad, and the other half of Manasseh. Their land was on the east side of the Jordan River. Moses, the Lord's servant, had given a piece of land to each tribe."
    },
    {
      "verse": "9",
      "text": "Their land went from Aroer, on the edge of the Arnon valley and the town in the middle of the valley. It included all the flat land of Medeba, as far as Dibon."
    },
    {
      "verse": "10",
      "text": "It included all the towns of Sihon, king of the Amorites, who ruled in Heshbon. It went to the border of the Amorites' land."
    },
    {
      "verse": "11",
      "text": "It included the land of Gilead, and the land of the Geshurites and Maakathites. It included all of Hermon mountain, and Bashan as far as Salecah."
    },
    {
      "verse": "12",
      "text": "(That was the kingdom of King Og in Bashan, who ruled in Ashtaroth and Edrei. He was one of the last of the Rephaites. ) Moses had won a fight against them and he had taken their land."
    },
    {
      "verse": "13",
      "text": "But the Israelites did not chase out the Geshurites and the Maakathites, so they still live there among the Israelites."
    },
    {
      "verse": "14",
      "text": "Moses had given no land to the tribe of Levi. This was because God had made the Levites a promise. He had made a rule that they would receive their food from the sacrifices and offerings that the other tribes gave to the Lord God of Israel. The Levites received that, instead of land for themselves."
    },
    {
      "verse": "15",
      "text": "This is the part of the land that Moses gave to the clans of Reuben's tribe."
    },
    {
      "verse": "16",
      "text": "He gave them the land from Aroer by the edge of the Arnon valley and the town in the middle of the valley. Moses gave these towns and their villages to the tribe of Reuben, family by family."
    },
    {
      "verse": "17",
      "text": "And he gave them all the flat land past Medeba in Heshbon. It included Dibon, Bamoth Baal, Beth Baal Meon,"
    },
    {
      "verse": "18",
      "text": "Jahaz and Kedemoth. It also included Mephaath,"
    },
    {
      "verse": "19",
      "text": "Kiriathaim, Sibmah and Zereth Shahar. Zereth was on a hill in the middle of the valley."
    },
    {
      "verse": "20",
      "text": "Their land included Beth Peor, and the sides of Pisgah mountain, and Beth Jeshimoth town."
    },
    {
      "verse": "21",
      "text": "Moses gave them all the towns on the flat land. He gave them all the land of Sihon, king of the Amorites. Sihon had ruled from Hebron. But Moses had won the fight against him and the Midianite kings, Evi, Rekem, Zur, Hur and Reba. These kings had ruled with Sihon and they lived in his land."
    },
    {
      "verse": "22",
      "text": "The Israelites had killed the prophet Balaam, son of Beor, when they killed soldiers in the battle. He had used magic to help Balak fight against Israel."
    },
    {
      "verse": "23",
      "text": "The border of Reuben's land was the Jordan River. Moses gave these towns and their villages to the tribe of Reuben, family by family."
    },
    {
      "verse": "24",
      "text": "This is the part of the land that Moses gave to the clans of Gad's tribe."
    },
    {
      "verse": "25",
      "text": "He gave them the land of Jazer, the towns of Gilead and half the land of the Ammonites. Their land went as far as Aroer, a town which was near Rabbah."
    },
    {
      "verse": "26",
      "text": "It went from Heshbon to Ramath Mizpah and Betonim, and from Mahanaim to the land of Debir."
    },
    {
      "verse": "27",
      "text": "Moses gave Gad these towns in the valley: Beth Haram, Beth Nimrah, Succoth and Zaphon. He gave them the rest of the land of Sihon, king of Heshbon. This was on the east side of the Jordan River, up to the edge of the sea of Galilee."
    },
    {
      "verse": "28",
      "text": "Moses gave these towns and their villages to the tribe of Gad, family by family."
    },
    {
      "verse": "29",
      "text": "This is the land that Moses gave to half the tribe of Manasseh, clan by clan."
    },
    {
      "verse": "30",
      "text": "He gave them the land from Mahanaim, the land of Bashan, all the land ruled by Og, king of Bashan. It included all the 60 towns of Jair in Bashan."
    },
    {
      "verse": "31",
      "text": "It included half of Gilead, Ashtaroth and Edrei. (These were the cities that belonged to King Og in Bashan. ) This land was for half the descendants of Makir, Manasseh's son, to live in, family by family."
    },
    {
      "verse": "32",
      "text": "Moses gave all that land to those tribes, while they were still on the east side of the Jordan River. They were in Moab, on the flat land near Jericho."
    },
    {
      "verse": "33",
      "text": "Moses gave no part of the land to Levi's tribe. The Lord himself, Israel's God, would be their part, as he had promised them."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "Eleazar the priest, Joshua son of Nun, and the leaders of the Israelite clans gave different parts of the land to each tribe of Israel. This tells about the land that each tribe received."
    },
    {
      "verse": "2",
      "text": "The leaders used lots to decide which parts of the land God had chosen for each of the 9½ tribes. This is what the Lord had told Moses to do."
    },
    {
      "verse": "3",
      "text": "Moses had already given land east of the Jordan River to the other 2½ tribes. But he had not given any land to the Levites."
    },
    {
      "verse": "4",
      "text": "The descendants of Joseph had now become two tribes, Manasseh and Ephraim. The leaders gave the Levites towns to live in, with enough land near them to feed their animals."
    },
    {
      "verse": "5",
      "text": "The leaders of the Israelites gave a part of the land to each tribe, as the Lord had told Moses to do."
    },
    {
      "verse": "6",
      "text": "Some of the men of Judah's tribe came to Joshua at Gilgal. Caleb spoke to Joshua. He was the son of Jephunneh, a Kenizzite man. Caleb said, ‘You know what the Lord said to Moses, the man of God, about you and me, at Kadesh-Barnea."
    },
    {
      "verse": "7",
      "text": "years old when Moses sent me from there to explore the land of Canaan. I brought back to him a true report. I was sure that we could take the land."
    },
    {
      "verse": "8",
      "text": "The other men who went with me made the people afraid. But I continued to trust the Lord my God."
    },
    {
      "verse": "9",
      "text": "So Moses made a promise to me on that day. He said, “The land that your feet have walked on will always belong to you and to your children. That is because you have trusted the Lord your God. ”"
    },
    {
      "verse": "10",
      "text": "years since Moses said this. During that time, the Israelites were travelling in the desert. Now I am 85 years old."
    },
    {
      "verse": "11",
      "text": "I am still as strong as I was on the day that Moses sent me out. I can fight as well now as I could then."
    },
    {
      "verse": "12",
      "text": "So please give to me this hill country that the Lord promised to me. You heard that the Anakites were living there then, in large, strong cities. But the Lord will help me to chase them out, as he has promised to do. ’"
    },
    {
      "verse": "13",
      "text": "Then Joshua blessed Caleb, Jephunneh's son. Joshua gave Hebron to him as his part of the land. After that, there were no more battles in Canaan."
    },
    {
      "verse": "14",
      "text": "So since that day, Hebron has belonged to Caleb, son of Jephunneh, the Kenizzite. He continued to trust the Lord, Israel's God. So Joshua gave him the land that he wanted."
    },
    {
      "verse": "15",
      "text": "(Before that, Hebron had been called ‘Kiriath Arba’. Arba was a famous Anakite. )After that, there were no more battles in Canaan."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "This is the land that Joshua gave to the tribe of Judah, clan by clan. Their land went south along the border of Edom, as far as the wilderness of Zin in the Negev."
    },
    {
      "verse": "2",
      "text": "The south border of Judah's land was from the south end of the Salt Sea."
    },
    {
      "verse": "3",
      "text": "It went across the south side of the Scorpion Hill, to Zin. From the south it went up to Kadesh-Barnea, as far as Hebron. Their border continued past Addar, and it turned towards Karka."
    },
    {
      "verse": "4",
      "text": "Then it went to Azmon and it continued to the Stream of Egypt. It finished at the sea. That was the south border of Judah's land."
    },
    {
      "verse": "5",
      "text": "Judah's east border went from the Salt Sea as far as the end of the Jordan River. Their north border started from the end of the Jordan at the Salt Sea."
    },
    {
      "verse": "6",
      "text": "From there it went to Beth Hoglah. Then it went north of Beth Arabah to the stone of Bohan. (Bohan was a son of Reuben. )"
    },
    {
      "verse": "7",
      "text": "The border went from the valley of Achor to Debir. Then it went north to Gilgal. Gilgal is opposite the Adummim hill, on the south side of the valley. Then it reached the springs of En Shemesh to En Rogel."
    },
    {
      "verse": "8",
      "text": "From there it went through the valley of Hinnom to the south side of a hill beside the Jebusite city of Jerusalem. Judah's border then continued to the top of the hill on the west side of the Hinnom valley. This was at the north end of the valley of the Rephaites."
    },
    {
      "verse": "9",
      "text": "From there it went to the springs of Nephtoah and onto the cities near Mount Ephron. It went towards Baalah (also called Kiriath-Jearim)."
    },
    {
      "verse": "10",
      "text": "It went round Baalah towards the hills of Edom. It went north of Jearim mountain (also called Kesalon) down to Beth Shemesh, and it continued on past Timnah."
    },
    {
      "verse": "11",
      "text": "Then it went out to the hills north of Ekron, and on towards Shikkeron. It went past Baalah mountain, as far as Jabneel. Judah's north border ended at the sea."
    },
    {
      "verse": "12",
      "text": "The west border of Judah's land was the Mediterranean Sea. Those were the borders of the land which Judah's tribe and its clans received. Those were the borders of the land which Judah's tribe and its clans received."
    },
    {
      "verse": "13",
      "text": "The Lord had told Joshua to give Kiriath Arba to Caleb, Jephunneh's son. That was the part of Judah's land that Caleb received. Arba was the father of Anak. Kiriath Arba was now called Hebron."
    },
    {
      "verse": "14",
      "text": "Caleb chased out the three sons of Anak from Hebron. Their names were Sheshai, Ahiman and Talmai."
    },
    {
      "verse": "15",
      "text": "From there he went to attack the people of Debir. (Debir had been called Kiriath Sepher)."
    },
    {
      "verse": "16",
      "text": "Caleb said, ‘If a brave man attacks and takes Kiriath Sepher, he can marry my daughter, Acsah. ’"
    },
    {
      "verse": "17",
      "text": "Othniel attacked the city and he took it. He was the son of Caleb's brother, Kenaz. So Caleb gave his daughter Acsah to Othniel, to be his wife."
    },
    {
      "verse": "18",
      "text": "After this, Acsah told Othniel that they should ask her father to give them some land. She went to see her father, Caleb. As she got off her donkey, Caleb asked her, ‘What would you like me to do for you? ’"
    },
    {
      "verse": "19",
      "text": "She said, ‘Please be kind and give me a special gift. You have given me some land in the Negev desert. Now please give me a place with springs so that I have water for the land. ’ So Caleb gave her some land with springs, on high land and on low land."
    },
    {
      "verse": "20",
      "text": "This is the land that Joshua gave to the clans of Judah's tribe."
    },
    {
      "verse": "21",
      "text": "These towns were in the south of Judah's land, near the border of Edom: Kabzeel, Eder, Jagur,"
    },
    {
      "verse": "22",
      "text": "Kinah, Dimonah, Adadah, towns with their villages."
    },
    {
      "verse": "23",
      "text": "Kedesh, Hazor, Ithnan,"
    },
    {
      "verse": "24",
      "text": "Ziph, Telem, and Bealoth."
    },
    {
      "verse": "25",
      "text": "Also Hazor Hadattah, Kerioth Hezron (that is, Hazor),"
    },
    {
      "verse": "26",
      "text": "Amam, Shema, Moladah,"
    },
    {
      "verse": "27",
      "text": "Hazar-Gaddah, Heshmon, Beth Pelet."
    },
    {
      "verse": "28",
      "text": "Also Hazar-Shual, Beersheba, Biziothiah,"
    },
    {
      "verse": "29",
      "text": "Baalah, Iim, Ezem,"
    },
    {
      "verse": "30",
      "text": "Eltolad, Kesil, Hormah,"
    },
    {
      "verse": "31",
      "text": "Ziklag, Madmannah, Sansannah,"
    },
    {
      "verse": "32",
      "text": "Lebaoth, Shilhim, Ain and Rimmon. That is 29 towns with their villages."
    },
    {
      "verse": "33",
      "text": "These towns were in the low hills in the west: Eshtaol, Zorah, Ashnah,"
    },
    {
      "verse": "34",
      "text": "Zanoah, En Gannim, Tappuah, Enam, towns and villages."
    },
    {
      "verse": "35",
      "text": "Jarmuth, Adullam, Socoh and Azekah."
    },
    {
      "verse": "36",
      "text": "Also he gave them Shaaraim, Adithaim and Gederah, (or Gederothaim). There were 14 towns and villages."
    },
    {
      "verse": "37",
      "text": "He gave them Zenan, Hadashah, Migdal Gad, towns and their villages."
    },
    {
      "verse": "38",
      "text": "Dilean, Mizpah, Joktheel,"
    },
    {
      "verse": "39",
      "text": "Lachish, Bozkath, Eglon,"
    },
    {
      "verse": "40",
      "text": "Cabbon, Lahmas, and Kitlish."
    },
    {
      "verse": "41",
      "text": "Also he gave them Gederoth, Beth Dagon, Naamah and Makkedah. There were 16 towns and their villages."
    },
    {
      "verse": "42",
      "text": "He also gave them Libnah, Ether, Ashan, There were nine towns with their villages."
    },
    {
      "verse": "43",
      "text": "Iphtah, Ashnah, Nezib,"
    },
    {
      "verse": "44",
      "text": "Keilah, Aczib and Mareshah. There were nine towns with their villages."
    },
    {
      "verse": "45",
      "text": "He also gave them Ekron with the houses and villages that belonged to it."
    },
    {
      "verse": "46",
      "text": "And he gave them all those towns west of Ekron, near to Ashdod with their villages."
    },
    {
      "verse": "47",
      "text": "And he gave them Ashdod and Gaza with their houses and villages. They had the land as far as the Stream of Egypt, and to the Mediterranean Sea."
    },
    {
      "verse": "48",
      "text": "These towns were in the hill country: Shamir, Jattir, Socoh,"
    },
    {
      "verse": "49",
      "text": "Dannah, Kiriath Sannah (that is, Debir), towns and their villages."
    },
    {
      "verse": "50",
      "text": "and Anab, Eshtemoh, Anim,"
    },
    {
      "verse": "51",
      "text": "Goshen, Holon and Giloh. There were 11 towns and their villages."
    },
    {
      "verse": "52",
      "text": "He also gave them Arab, Dumah, Eshan, There were nine towns and their villages."
    },
    {
      "verse": "53",
      "text": "Janim, Beth Tappuah, Aphekah,"
    },
    {
      "verse": "54",
      "text": "Humtah, Kiriath Arba (that is, Hebron) and Zior. There were nine towns and their villages."
    },
    {
      "verse": "55",
      "text": "Also Maon, Carmel, Ziph, Juttah, There were ten towns and their villages."
    },
    {
      "verse": "56",
      "text": "Jezreel, Jokdeam, Zanoah,"
    },
    {
      "verse": "57",
      "text": "Kain, Gibeah and Timnah. There were ten towns and their villages."
    },
    {
      "verse": "58",
      "text": "And he gave them Halhul, Beth Zur, Gedor, There were six towns and their villages."
    },
    {
      "verse": "59",
      "text": "Maarath, Beth Anoth and Eltekon. There were six towns and their villages."
    },
    {
      "verse": "60",
      "text": "And Kiriath Baal, (that is, Kiriath-Jearim) and Rabbah. There were two towns and their villages. There were two towns and their villages."
    },
    {
      "verse": "61",
      "text": "These towns were in the desert: Beth Arabah, Middin, Secacah,"
    },
    {
      "verse": "62",
      "text": "Nibshan, Salt city, and En Gedi. There were six towns and their villages. There were six towns and their villages."
    },
    {
      "verse": "63",
      "text": "But the men of Judah's tribe could not chase the Jebusites out of Jerusalem. As a result, the Jebusites still live there, together with the people of Judah."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "This is the land that Joshua gave to the descendants of Joseph. Their land went from the Jordan River at Jericho, and from there it went through the desert into the hills of Bethel."
    },
    {
      "verse": "2",
      "text": "The south border of their land went from Bethel, to Luz, and then to the land of the Arkites at Ataroth."
    },
    {
      "verse": "3",
      "text": "It continued to the west, to the land of the Japhletites as far as lower Beth Horon and Gezer. The border ended at the sea."
    },
    {
      "verse": "4",
      "text": "Joshua gave this land to Manasseh and Ephraim, the sons of Joseph. It was for them and their descendants."
    },
    {
      "verse": "5",
      "text": "Joshua gave this land to the tribe of Ephraim, clan by clan: The border of their land went from Ataroth Addar in the east to Beth Horon."
    },
    {
      "verse": "6",
      "text": "Then it continued west to the sea, with Micmethath on the north side of the border. East of Micmethath, the border went past Taanath Shiloh on the east and then to Janoah."
    },
    {
      "verse": "7",
      "text": "From there it went to Ataroth and Naarah and past Jericho to the Jordan River."
    },
    {
      "verse": "8",
      "text": "From Tappuah, the border continued to the west, to the stream of Kanah. From there, it continued to the sea. That is the land that Joshua gave to the families of the tribe of Ephraim."
    },
    {
      "verse": "9",
      "text": "They also received some towns and villages that were in Manasseh's land."
    },
    {
      "verse": "10",
      "text": "But the tribe of Ephraim did not chase out the Canaanite people who lived in Gezer. Canaanite people still live there with the people of Ephraim, but they have to work as their slaves."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "This is the land that Manasseh's tribe received. Manasseh was Joseph's firstborn son. Manasseh's firstborn son was Makir. He was the father of Gilead. Makir's descendants were brave soldiers. Because of that, Moses had already given Gilead and Bashan to them, east of the Jordan River."
    },
    {
      "verse": "2",
      "text": "The other families of Manasseh received land on the west side of the Jordan. They were the descendants of Abiezer, Helek, Asriel, Shechem, Hepher and Shemida. They were all sons of Manasseh, and leaders of their clans."
    },
    {
      "verse": "3",
      "text": "Zelophehad, son of Hepher, son of Gilead, son of Makir, son of Manasseh, had no sons. He had only daughters. Their names were Mahlah, Noah, Hoglah, Milcah and Tirzah."
    },
    {
      "verse": "4",
      "text": "They went to see Eleazar the priest, Joshua son of Nun, and the leaders. They said, ‘The Lord told Moses to give us part of the land. We must have land like the sons of other families. ’ Joshua agreed and he gave land to them, like the other families."
    },
    {
      "verse": "5",
      "text": "That is why Manasseh's tribe received ten parts of the land, as well as Gilead and Bashan on the east side of the Jordan."
    },
    {
      "verse": "6",
      "text": "The daughters of Manasseh received some land, as well as his sons. They gave the land of Gilead to the other families of Manasseh."
    },
    {
      "verse": "7",
      "text": "The border of Manasseh's land went from Asher to Micmethath, east of Shechem. It went south to include En Tappuah."
    },
    {
      "verse": "8",
      "text": "Manasseh received the land near Tappuah, but the town of Tappuah belonged to the tribe of Ephraim."
    },
    {
      "verse": "9",
      "text": "The border of Manasseh's land went down to Kanah valley and along its north side to the Mediterranean Sea. Some towns on the south of that valley belonged to Ephraim, but they were in Manasseh's land."
    },
    {
      "verse": "10",
      "text": "Ephraim's land was south of the river, and Manasseh's land was to the north. Manasseh's west border was the Mediterranean Sea. Asher's land was on the north side of Manasseh's land. Issachar's land was on the east side."
    },
    {
      "verse": "11",
      "text": "Some towns that were in the lands of Issachar and Asher belonged to Manasseh. They were Beth Shan, Ibleam and the people who lived in Dor, Endor, Taanach, and Megiddo. They included the villages near those towns."
    },
    {
      "verse": "12",
      "text": "But the men of Manasseh could not chase out the people who lived in those cities. So the Canaanite people continued to live there."
    },
    {
      "verse": "13",
      "text": "When the Israelites became stronger, they made the Canaanites work for them as slaves. But they never completely chased the Canaanites out from those towns."
    },
    {
      "verse": "14",
      "text": "Joseph's descendants asked Joshua, ‘Why have you given only one part of the land for us to live in? The Lord has blessed us with many children, so there are many people in our tribe. ’"
    },
    {
      "verse": "15",
      "text": "Joshua said to them, ‘Because there are so many of you, you may take more land. If the hill country of Ephraim is too small for you, move into the forest that belongs to the Perizzites and the Rephaites. Cut down trees there to make a place to live. ’"
    },
    {
      "verse": "16",
      "text": "They replied, ‘The hill country is certainly not big enough for us. But the Canaanites who live in Beth Shan and its villages, and in the valley of Jezreel, have iron chariots. ’"
    },
    {
      "verse": "17",
      "text": "Joshua said to the men from the tribes of Ephraim and Manasseh, ‘You have very many strong men who can fight. I will give you more land than the part that you have already received."
    },
    {
      "verse": "18",
      "text": "You may take the whole of the hill country as your land. You can cut down the trees of the forests and live there. It is true that the Canaanites are strong fighters and they have iron chariots. But you will be strong enough to chase them out. ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "All the Israelite people met together at Shiloh. There they put up the Tent of Meeting. They now ruled the whole land."
    },
    {
      "verse": "2",
      "text": "But there were still seven tribes that Joshua had not yet given a part of the land for themselves."
    },
    {
      "verse": "3",
      "text": "Joshua said to them, ‘The Lord, the God of your ancestors, has given you the land. How much longer will you wait before you take it?"
    },
    {
      "verse": "4",
      "text": "Choose three men from each tribe. I will send them to look at the whole land, to see what it is like. They must describe each part and then bring a report back to me."
    },
    {
      "verse": "5",
      "text": "You must make it into seven parts. Judah's tribe will keep the land in the south. Joseph's two tribes will keep their land in the north. Divide the rest of the land into seven parts."
    },
    {
      "verse": "6",
      "text": "See what the land is like and describe each of the seven parts. Bring your report to me. Then I will use lots to choose which tribe should receive each part of the land. The Lord our God will decide this."
    },
    {
      "verse": "7",
      "text": "The Levites will not have any land of their own. Their gift from the Lord is to serve him. Gad, Reuben and half the tribe of Manasseh already have their land on the east side of the Jordan River. The Lord's servant, Moses, gave it to them. ’"
    },
    {
      "verse": "8",
      "text": "Before the men left, Joshua said to them, ‘Go and look carefully at the land. Describe what you see. Then bring your report back to me here in Shiloh. I will use lots so that the Lord decides how to share the land between you. ’"
    },
    {
      "verse": "9",
      "text": "So the men left and they travelled through the land. They described the land and each town and they wrote it in a book. They wrote about each of the seven parts of the land. Then they went back to Joshua at Shiloh, where the Israelites had put up their tents."
    },
    {
      "verse": "10",
      "text": "There at Shiloh, Joshua used lots to see how the Lord wanted to divide the land. He told each of the seven Israelite tribes which part of the land they would receive."
    },
    {
      "verse": "11",
      "text": "The first part of the land was for Benjamin's tribe, clan by clan. Their land was between the land that Joshua had already given to the tribes of Judah and Joseph."
    },
    {
      "verse": "12",
      "text": "The north border of their land began at the Jordan River, and it went up the hills to the north of Jericho. From there it went west into the hills, to the desert of Beth Aven."
    },
    {
      "verse": "13",
      "text": "Then their border continued to the south of Luz (that is Bethel) and went down to Ataroth Addar. That is on the hill south of Lower Beth Horon."
    },
    {
      "verse": "14",
      "text": "From that hill, their west border went south to Kiriath Baal (that is Kiriath-Jearim). This town belonged to the people of Judah. That was the west border of Benjamin's land."
    },
    {
      "verse": "15",
      "text": "The south border went from the edge of Kiriath-Jearim to the springs of water at Nephtoah."
    },
    {
      "verse": "16",
      "text": "Then it went to the edge of the hill country, near Ben Hinnom valley. This was north of the Valley of the Rephaites. It continued down the Hinnom valley, south of the Jebusite city and then went on to En Rogel."
    },
    {
      "verse": "17",
      "text": "Then it went north to En Shemesh. It continued to Geliloth, opposite the valley of Adummim. Then it went to the great stone of Bohan, Reuben's son."
    },
    {
      "verse": "18",
      "text": "It continued to the north of Beth Arabah down into the Jordan Valley."
    },
    {
      "verse": "19",
      "text": "Then it went north of Ben Hoglah, to the north end of the Salt Sea, where the Jordan River ends. That was the south border of Benjamin's land."
    },
    {
      "verse": "20",
      "text": "The east border of their land was the Jordan River. Those are the borders of the land that Joshua gave to the families of Benjamin's tribe. Those are the borders of the land that Joshua gave to the families of Benjamin's tribe."
    },
    {
      "verse": "21",
      "text": "These are the cities that Joshua gave to the tribe of Benjamin: Jericho, Beth Hoglah, Emek Keziz,"
    },
    {
      "verse": "22",
      "text": "Beth Arabah, Zemaraim, Bethel, towns and their villages."
    },
    {
      "verse": "23",
      "text": "Avvim, Parah, Ophrah,"
    },
    {
      "verse": "24",
      "text": "Kephar, Ammoni, Ophni and Geba. There were 12 towns and their villages."
    },
    {
      "verse": "25",
      "text": "Gibeon, Ramah, Beeroth, towns and their villages. Joshua gave these cities to Benjamin's tribe, for each clan to live in."
    },
    {
      "verse": "26",
      "text": "Mizpah, Kephirah, Mozah,"
    },
    {
      "verse": "27",
      "text": "Rekem, Irpeel, Taralah,"
    },
    {
      "verse": "28",
      "text": "Zelah, Haeleph, the Jebusite city (that is, Jerusalem), Gibeah and Kiriath. There were 14 towns and their villages. Joshua gave these cities to Benjamin's tribe, for each clan to live in."
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "The second part of the land was for Simeon's tribe, clan by clan. Their land was in the middle of Judah's land."
    },
    {
      "verse": "2",
      "text": "It included these towns: Beersheba (also called Sheba), Moladah,"
    },
    {
      "verse": "3",
      "text": "Hazar-Shual, Balah, Ezem, towns and their villages."
    },
    {
      "verse": "4",
      "text": "Eltolad, Bethul, Hormah,"
    },
    {
      "verse": "5",
      "text": "Ziklag, Beth Marcaboth, Hazar-Susah,"
    },
    {
      "verse": "6",
      "text": "Beth Lebaoth and Sharuhen. There were 13 towns and their villages."
    },
    {
      "verse": "7",
      "text": "He also gave them Ain, Rimmon, Ether and Ashan. There were four towns and their villages."
    },
    {
      "verse": "8",
      "text": "This included all the villages near them as far as Baalath Beer (also called Ramah, in the Negev). That was the land that Joshua gave to the families of Simeon's tribe."
    },
    {
      "verse": "9",
      "text": "Because Judah had received more land than they needed, Joshua took some of their land for Simeon. So Simeon's tribe lived inside the land that Joshua had given to Judah."
    },
    {
      "verse": "10",
      "text": "The next part of the land was for Zebulun's tribe, clan by clan. The border of their land went as far as Sarid. towns and their villages."
    },
    {
      "verse": "11",
      "text": "Then it went west to Maralah, it touched Dabbesheth, and it went to the valley near Jokneam."
    },
    {
      "verse": "12",
      "text": "From Sarid their border went east to the land of Kisloth Tabor. Then it went to Daberath and it continued up to Japhia."
    },
    {
      "verse": "13",
      "text": "From there, it went east to Gath Hepher and Eth Kazin. It went on to Rimmon, and turned to go to Neah."
    },
    {
      "verse": "14",
      "text": "The border went north to Hannathon and stopped at the valley of Iphtah El."
    },
    {
      "verse": "15",
      "text": "Their land included these towns: Kattath, Nahalal, Shimron, Idalah and Bethlehem. There were 12 towns and their villages."
    },
    {
      "verse": "16",
      "text": "That was the land that Joshua gave to the families of Zebulun's tribe, as well as the towns and their villages."
    },
    {
      "verse": "17",
      "text": "The next part of the land was for Issachar's tribe, clan by clan. towns and their villages."
    },
    {
      "verse": "18",
      "text": "Their land included Jezreel, Kesulloth, Shunem,"
    },
    {
      "verse": "19",
      "text": "Hapharaim, Shion, Anaharath,"
    },
    {
      "verse": "20",
      "text": "Rabbith, Kishion, Ebez,"
    },
    {
      "verse": "21",
      "text": "Remeth, En Gannim, En Haddah and Beth Pazzez."
    },
    {
      "verse": "22",
      "text": "The border of their land touched Tabor, Shahazumah and Beth Shemesh. It ended at the Jordan River. There were 16 towns and their villages."
    },
    {
      "verse": "23",
      "text": "That was the land that Joshua gave to the families of Issachar's tribe, as well as the towns and their villages."
    },
    {
      "verse": "24",
      "text": "The next part of the land was for Asher's tribe, clan by clan."
    },
    {
      "verse": "25",
      "text": "Their land included Helkath, Hali, Beten, Acshaph,"
    },
    {
      "verse": "26",
      "text": "Allammelech, Amad and Mishal. The west border of their land touched Carmel and Shihor Libnath."
    },
    {
      "verse": "27",
      "text": "Then it went east towards Beth Dagon, to touch Zebulun and the valley of Iphtah El. Then their border went north to Beth Emek and Neiel. It continued to Cabul in the north."
    },
    {
      "verse": "28",
      "text": "It went to Abdon, Rehob, Hammon and Kanah, as far as Great Sidon."
    },
    {
      "verse": "29",
      "text": "Then the border turned towards Ramah, and it went as far as the strong city of Tyre. Then it turned to Hosah and it ended at the Mediterranean Sea. Their towns included Hebel, Aczib,"
    },
    {
      "verse": "30",
      "text": "Ummah, Aphek and Rehob. They received 22 towns and their villages."
    },
    {
      "verse": "31",
      "text": "That was the land that Joshua gave to the families of Asher's tribe, as well as the towns and their villages."
    },
    {
      "verse": "32",
      "text": "The sixth part of the land was for Naphtali's tribe, clan by clan."
    },
    {
      "verse": "33",
      "text": "The border of their land went from Heleph and the big oak tree in Zaanannim. It went to Adami Nekeb and Jabneel, and it continued to Lakkum. It ended at the Jordan River."
    },
    {
      "verse": "34",
      "text": "The border turned west to Aznoth Tabor and it continued to Hukkok. It touched Zebulun's land on its south side, Asher's land on its west side and the Jordan River on its east side."
    },
    {
      "verse": "35",
      "text": "Their land included these strong cities: Ziddim, Zer, Hammath, Rakkath and Kinnereth,"
    },
    {
      "verse": "36",
      "text": "Adamah, Ramah, Hazor,"
    },
    {
      "verse": "37",
      "text": "Kedesh, Edrei, En Hazor,"
    },
    {
      "verse": "38",
      "text": "Iron, Migdal El, Horem, Beth Anath and Beth Shemesh. They received 19 towns and their villages."
    },
    {
      "verse": "39",
      "text": "That was the land that Joshua gave to the families of Naphtali's tribe, as well as the towns and their villages."
    },
    {
      "verse": "40",
      "text": "The seventh part of the land was for Dan's tribe, clan by clan."
    },
    {
      "verse": "41",
      "text": "Their land included Zorah, Eshtaol, Ir Shemesh,"
    },
    {
      "verse": "42",
      "text": "Shaalabbin, Aijalon, Ithlah,"
    },
    {
      "verse": "43",
      "text": "Elon, Timnah, Ekron,"
    },
    {
      "verse": "44",
      "text": "Eltekeh, Gibbethon, Baalath,"
    },
    {
      "verse": "45",
      "text": "Jehud, Bene Berak, Gath-Rimmon,"
    },
    {
      "verse": "46",
      "text": "Me Jarkon and Rakkon. They also received land in front of Joppa."
    },
    {
      "verse": "47",
      "text": "(But later, the people of Dan failed to take their land and keep it. So they went to attack Leshem. They took the town and they killed its people. Then they lived there themselves. They called the city Dan, after their ancestor. )"
    },
    {
      "verse": "48",
      "text": "That was the land that Joshua gave to the families of Dan's tribe, as well as the towns and their villages."
    },
    {
      "verse": "49",
      "text": "When all the tribes had received their part of the land, the Israelites gave to Joshua, son of Nun, some land for himself."
    },
    {
      "verse": "50",
      "text": "This is what the Lord had told them to do. Joshua asked to have Timnah Serah in the hill country of Ephraim. So they gave it to him. He built up the town and he lived in it."
    },
    {
      "verse": "51",
      "text": "That is the list of all the pieces of land that each tribe received. Eleazar the priest, Joshua, son of Nun, and the Israelite leaders used lots to decide which part of the land was for each tribe. They did this in Shiloh, in front of the Tent of Meeting. The Lord was there with them. In that way, they finished giving each tribe a part of the land."
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "Then the Lord said to Joshua,"
    },
    {
      "verse": "2",
      "text": "‘Tell the Israelite people to choose special cities as safe places. I told Moses that you should do this."
    },
    {
      "verse": "3",
      "text": "Anyone can be safe in these cities if he has killed someone but he did not mean to kill. A person like that must run to one of these towns and he will be safe from the dead person's relative."
    },
    {
      "verse": "4",
      "text": "The person who killed someone must go to the special city. When he arrives, he must stand at the gate of the city. There he must tell the leaders what he has done. Then they must take him into the city. They must give him a place to stay so that he can live there."
    },
    {
      "verse": "5",
      "text": "The dead person's relative may chase after the killer. The leaders of the city must not let him hurt the killer. This is because the killer did not mean to kill."
    },
    {
      "verse": "6",
      "text": "The killer must stay inside that city. The judges there will decide if he is not guilty of murder. Then he must wait until the leader of the priests dies. After that, he is free to return to the town that he came from. ’"
    },
    {
      "verse": "7",
      "text": "So they chose these towns: Kedesh in Galilee (in the hill country of Naphtali), Shechem (in the hill country of Ephraim), and Kiriath Arba (that is Hebron, in the hill country of Judah)."
    },
    {
      "verse": "8",
      "text": "They also chose these towns beyond Jericho, on the east side of Jordan River: Bezer (in the flat desert land of Reuben), Ramoth in Gilead (on Gad's land), Golan in Bashan (on Manasseh's land)."
    },
    {
      "verse": "9",
      "text": "Any Israelite or foreign person living in Israel could run to these cities and be safe. They may have killed someone, but they did not mean to kill them. If they run to these cities, the dead person's relative could not kill them. The judges in the city had to decide whether a killer was guilty of murder. Nobody could kill them before the judges decided."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "The leaders of the Levite families came to speak to Joshua, son of Nun. Eleazar the priest and the leaders of the other tribes were also there."
    },
    {
      "verse": "2",
      "text": "They met at Shiloh in the land of Canaan. The Levites said, ‘The Lord told Moses that you must give us towns to live in, as well as land for our animals. ’"
    },
    {
      "verse": "3",
      "text": "So the Israelites did as the Lord had told them. They gave to the Levites towns to live in and land for their animals. They gave these from their own land."
    },
    {
      "verse": "4",
      "text": "They gave towns first to the clans of Kohath. They gave 13 towns from the tribes of Judah, Simeon and Benjamin. They gave these to Levites who were descendants of Aaron, the priest."
    },
    {
      "verse": "5",
      "text": "They also gave to the other descendants of Kohath, towns from the tribes of Ephraim, Dan and the west half of Manasseh."
    },
    {
      "verse": "6",
      "text": "towns to the descendants of Gershon. Those towns came from the tribes of Issachar, Asher, Naphtali and the east half of Manasseh in Bashan."
    },
    {
      "verse": "7",
      "text": "towns to the descendants of Merari. Those towns came from the tribes of Reuben, Gad and Zebulun."
    },
    {
      "verse": "8",
      "text": "In that way, the Israelites gave these towns to the Levites, as well as land for their animals. They used lots to do it. They did as the Lord had told Moses to do."
    },
    {
      "verse": "9",
      "text": "These are the names of the towns that the tribes of Simeon and Judah gave to the Levites."
    },
    {
      "verse": "10",
      "text": "The Kohathite clans who were descendants of Aaron received these towns, because God chose them first."
    },
    {
      "verse": "11",
      "text": "They received Kiriath Arba (or Hebron), with land near to it, in the hill country of Judah. Arba was the father of Anak."
    },
    {
      "verse": "12",
      "text": "But the fields and villages near Hebron belonged to Caleb, son of Jephunneh."
    },
    {
      "verse": "13",
      "text": "Hebron was one of the safe cities. The descendants of Aaron, the priest, received Hebron, Libnah,"
    },
    {
      "verse": "14",
      "text": "Jattir, Eshtemoa,"
    },
    {
      "verse": "15",
      "text": "Holon, Debir,"
    },
    {
      "verse": "16",
      "text": "Ain, Juttah and Beth Shemesh, as well as their fields. These two tribes gave them nine towns."
    },
    {
      "verse": "17",
      "text": "Benjamin's tribe also gave four towns to them: Gibeon, Geba,"
    },
    {
      "verse": "18",
      "text": "Anathoth and Almon, as well as their fields."
    },
    {
      "verse": "19",
      "text": "So the priests, descendants of Aaron, received 13 towns with their fields."
    },
    {
      "verse": "20",
      "text": "The tribe of Ephraim gave some towns to Levites from other clans of Kohath."
    },
    {
      "verse": "21",
      "text": "They gave them Shechem, a safe city, in the hill country of Ephraim, as well as Gezer,"
    },
    {
      "verse": "22",
      "text": "Kibzaim and Beth Horon, with their fields. That was four towns."
    },
    {
      "verse": "23",
      "text": "The tribe of Dan gave them Eltekeh, Gibbethon,"
    },
    {
      "verse": "24",
      "text": "Aijalon, and Gath-Rimmon. That was another four towns with their fields."
    },
    {
      "verse": "25",
      "text": "The west half tribe of Manasseh gave them Taanach and Gath-Rimmon, with their fields. That was two towns."
    },
    {
      "verse": "26",
      "text": "So these Kohathite clans received ten towns with their fields."
    },
    {
      "verse": "27",
      "text": "The Levites from the clans of Gershon received these towns. The east half tribe of Manasseh gave them Golan in Bashan, a safe city, and Be Eshtarah. That was two towns, as well as their fields."
    },
    {
      "verse": "28",
      "text": "The tribe of Issachar gave them Kishion, Daberath,"
    },
    {
      "verse": "29",
      "text": "Jarmuth and En Gannim, with their fields. That was another four towns."
    },
    {
      "verse": "30",
      "text": "The tribe of Asher gave them Mishal, Abdon,"
    },
    {
      "verse": "31",
      "text": "Helkath and Rehob, with their fields. That was four more towns."
    },
    {
      "verse": "32",
      "text": "The tribe of Naphtali gave them Kedesh in Galilee, a safe city, Hammoth Dor and Kartan, with their fields. That was three towns."
    },
    {
      "verse": "33",
      "text": "cities with their fields."
    },
    {
      "verse": "34",
      "text": "The other Levites were from the clan of Merari. The tribe of Zebulun gave them Jokneam, Kartah,"
    },
    {
      "verse": "35",
      "text": "Dimnah and Nahalal. That was four towns, as well as their fields."
    },
    {
      "verse": "36",
      "text": "The tribe of Reuben gave them Bezer, Jahaz,"
    },
    {
      "verse": "37",
      "text": "Kedemoth and Mephaath, with their fields. That was four towns."
    },
    {
      "verse": "38",
      "text": "The tribe of Gad gave them Ramoth in Gilead, a safe city, Mahanaim,"
    },
    {
      "verse": "39",
      "text": "Heshbon and Jazer, with their fields. That was four more towns."
    },
    {
      "verse": "40",
      "text": "towns. That was all the Levite clans."
    },
    {
      "verse": "41",
      "text": "towns in the land of the Israelite people."
    },
    {
      "verse": "42",
      "text": "Each of these towns had its own fields round it, for animals to eat the grass."
    },
    {
      "verse": "43",
      "text": "That is how the Lord gave the land to all the Israelite people. He had promised their ancestors that he would give the land to them. They took it from the people who had lived there, and then they lived there themselves."
    },
    {
      "verse": "44",
      "text": "The Lord let them live there safely, as he had promised to their ancestors. The Lord made them stronger than their enemies, so nobody could attack them."
    },
    {
      "verse": "45",
      "text": "The Lord did all the good things that he had promised to do for the people of Israel. He did not fail to do anything that he had promised."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "Then Joshua called together the tribes of Reuben, Gad and the half tribe of Manasseh."
    },
    {
      "verse": "2",
      "text": "Joshua said, ‘You have done everything that Moses, the Lord's servant, told you to do. You have also obeyed everything that I told you to do."
    },
    {
      "verse": "3",
      "text": "You have helped the other tribes for a long time now. You have stayed with them even until today. You have done all the work that the Lord your God gave you to do."
    },
    {
      "verse": "4",
      "text": "Now your brothers can live safely in the land, as the Lord promised them. So you can return to your homes on the other side of the Jordan River. Moses, the Lord's servant, gave that land to you."
    },
    {
      "verse": "5",
      "text": "But you must be very careful to obey the rules and the laws that Moses gave to you. You must love the Lord your God. You must obey the rules and commands that he has given to us. You must worship him and serve him with everything that you have. ’"
    },
    {
      "verse": "6",
      "text": "Joshua then blessed them and he sent them away to their homes."
    },
    {
      "verse": "7",
      "text": "(Moses had given land in Bashan to half the tribe of Manasseh. But Joshua had given land on the west side of the Jordan to the other half of the tribe, as he did for the other tribes. ) When Joshua sent the 2½ tribes home, he blessed them."
    },
    {
      "verse": "8",
      "text": "He said, ‘Go back to your homes with the valuable things that you took from your enemies. Take many animals with you. Take silver, gold, bronze and iron things, as well as beautiful clothes. Share these things with the other people of your tribes. ’"
    },
    {
      "verse": "9",
      "text": "So the tribes of Reuben, Gad and half the tribe of Manasseh left the other Israelites in Shiloh, in the land of Canaan. They returned to their own land in Gilead. Moses had given this land to them, as the Lord had told him."
    },
    {
      "verse": "10",
      "text": "The 2½ tribes came to Geliloth, near the Jordan River, in Canaan. They built a big altar there, beside the river."
    },
    {
      "verse": "11",
      "text": "The other Israelites heard this news: ‘Those 2½ tribes have built an altar on the border of Canaan, at Geliloth! They have built it on the west side of the Jordan River, our side! ’"
    },
    {
      "verse": "12",
      "text": "So the Israelites came together at Shiloh to fight against the other 2½ tribes."
    },
    {
      "verse": "13",
      "text": "The Israelites sent Phinehas, son of Eleazar the priest, to the land of Gilead. He went to meet with the 2½ tribes, Reuben, Gad and the half tribe of Manasseh."
    },
    {
      "verse": "14",
      "text": "Israelite leaders went with him, one man from each of their tribes. Each man was a leader of his own clan."
    },
    {
      "verse": "15",
      "text": "The Israelite leaders arrived in the land of Reuben, Gad and the half tribe of Manasseh, in Gilead."
    },
    {
      "verse": "16",
      "text": "They said, ‘You have not obeyed the Lord, Israel's God. All the people of Israel agree that you have done a bad thing. You have turned against the Lord. You should not have built this altar for yourselves."
    },
    {
      "verse": "17",
      "text": "We did something very bad at Peor. Even now, we have not made it right. The Lord brought a bad disease to punish us as his people."
    },
    {
      "verse": "18",
      "text": "Now you are doing another bad thing. You no longer want to obey the Lord. You are turning against him today. So tomorrow the Lord may punish us all!"
    },
    {
      "verse": "19",
      "text": "If your land here in Gilead is unclean, come back across the river to the Lord's own land. You can come and live among us, in the land where the Lord's tabernacle is. But do not turn against the Lord or against us. Do not build an altar for yourselves. The Lord our God already has his altar here."
    },
    {
      "verse": "20",
      "text": "Remember the time when Achan, son of Zerah, took things that belonged to God for himself. He refused to obey God's command about Jericho's valuable things. Then God became angry with all the people of Israel. Achan died because of his sin, but he was not the only one. ’"
    },
    {
      "verse": "21",
      "text": "Reuben, Gad and the half tribe of Manasseh answered the Israelite leaders."
    },
    {
      "verse": "22",
      "text": "They said, ‘God, the Lord, is the great God! God, the Lord knows what is true! So all Israel must also know! Punish us today if we have turned against the Lord. We have not refused to obey him."
    },
    {
      "verse": "23",
      "text": "We did not build our own altar to make burnt offerings or grain offerings or friendship offerings on it. If we have done that, the Lord himself should certainly punish us."
    },
    {
      "verse": "24",
      "text": "No! We had a very different idea. We were afraid that in the future, your descendants might say to our descendants, “You have nothing to do with the Lord, Israel's God."
    },
    {
      "verse": "25",
      "text": "The Lord put the Jordan River as a border between our tribes and your tribes. The tribes of Reuben and Gad cannot worship the Lord! ” In that way, your descendants might stop our descendants from serving the Lord."
    },
    {
      "verse": "26",
      "text": "That is why we decided to build this altar. It will not be an altar where we make sacrifices or burnt offerings."
    },
    {
      "verse": "27",
      "text": "But it will help us all, our descendants and your descendants, to remember to obey the Lord. We will go to worship him at his tabernacle. There we will bring to him our burnt offerings, our sacrifices and our friendship offerings. Then, in future years, your descendants will not say to our descendants, “You cannot worship the Lord with us. ”"
    },
    {
      "verse": "28",
      "text": "If they say that to us, we will reply, “Look at this altar that our ancestors built. It is a copy of the Lord's true altar. It is not for burnt offerings or sacrifices. They built it so that we would remember that we all belong to the Lord. ”"
    },
    {
      "verse": "29",
      "text": "We would never decide to turn against the Lord. We want to continue to obey him. We know that the only altar where we must make burnt offerings, sacrifices and friendship offerings is the true altar of the Lord our God. That altar stands in front of his tabernacle. ’"
    },
    {
      "verse": "30",
      "text": "Phinehas the priest and the Israelite leaders that were with him heard this. They were happy with what the people of Reuben, Gad and Manasseh had told them."
    },
    {
      "verse": "31",
      "text": "They said to them, ‘Now we know that the Lord is with us! You have not refused to obey the Lord. So we know that he will not punish us Israelites. ’"
    },
    {
      "verse": "32",
      "text": "Then Phinehas, the son of Eleazar the priest, and the leaders left Gilead and they went back to the land of Canaan. They told the Israelites in Canaan what the people of Reuben and Gad had said."
    },
    {
      "verse": "33",
      "text": "The Israelites were happy to hear their report. They thanked God. They did not think any more that they might attack the other tribes and destroy their land."
    },
    {
      "verse": "34",
      "text": "The people of Reuben and Gad gave their altar a name, because they wanted to remember that the Lord is their God. So they called the altar ‘Remember’."
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "Joshua became very old. The Lord had let the Israelite people live safely for many years. The other nations who lived near them did not attack them."
    },
    {
      "verse": "2",
      "text": "One day, Joshua called all the leaders to meet with him. They were the leaders of Israel's tribes and clans, the judges and the officers. He said to them, ‘I am now very old."
    },
    {
      "verse": "3",
      "text": "You yourselves have seen what the Lord has done to these other nations. It was the Lord who fought against them on your behalf."
    },
    {
      "verse": "4",
      "text": "Remember how I have given land to each of your tribes. The land is between the Jordan River in the east, and the Mediterranean Sea in the west. It is land that belonged to different nations. Some of those people we have chased away, but some of them still remain in the land."
    },
    {
      "verse": "5",
      "text": "The Lord himself will chase those people out of the land, so that you can live there. The Lord your God has promised you all this."
    },
    {
      "verse": "6",
      "text": "Be very strong. Be careful that you obey everything that Moses wrote in the Book of the Law. Do not turn away from any of those rules."
    },
    {
      "verse": "7",
      "text": "Do not become friends of the nations that live near you. Do not call out to their gods. Do not use the names of their gods to make a promise. You must not serve them or worship them."
    },
    {
      "verse": "8",
      "text": "But you must always serve the Lord your God, as you have until now."
    },
    {
      "verse": "9",
      "text": "The Lord has chased out in front of you nations that are great and strong. None of them has been strong enough to win against you."
    },
    {
      "verse": "10",
      "text": "Because the Lord your God fights on your behalf, one of you can chase away 1, 000 men! The Lord has promised to do this for you."
    },
    {
      "verse": "11",
      "text": "You must be very careful that you continue to love the Lord your God."
    },
    {
      "verse": "12",
      "text": "You must not turn away from him to join with the other nations that still live near you. Do not marry any of them. Do not live in the way that they live."
    },
    {
      "verse": "13",
      "text": "If you do that, the Lord your God will not chase them out in front of you any more. Instead, those nations will become a danger for you. They will be like a trap that catches you. They will be like sticks that beat your backs, and like sharp thorns in your eyes. They will bring trouble to you until none of you remain in this good land that the Lord your God has given to you."
    },
    {
      "verse": "14",
      "text": "I will soon die, as all men do. The Lord your God has done everything that he promised you he would do. Deep inside yourselves, you know that is true. He has not failed to do even one thing that he promised."
    },
    {
      "verse": "15",
      "text": "The Lord has given to you every good thing that he has promised. But if you refuse to obey him, he will also punish you in every way that he has promised. He will destroy you so that you no longer live in this good land that he has given to you."
    },
    {
      "verse": "16",
      "text": "You must obey the rules that he commanded you to obey in his covenant. You must not serve or worship other gods. If you turn against him, the Lord your God will be very angry with you. Then very soon none of you will remain in this good land that he has given to you. ’"
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "Joshua called all the Israelite tribes to meet together at Shechem. He called the leaders of clans, the rulers, the judges and the officers to stand in front of the tabernacle."
    },
    {
      "verse": "2",
      "text": "Joshua said to the people, ‘This is what the Lord, Israel's God, says:“A long time ago, your ancestors lived on the other side of the Euphrates river. They included Terah who was the father of Abraham and Nahor. They worshipped other gods."
    },
    {
      "verse": "3",
      "text": "But I took Abraham, your ancestor, away from that land beyond the Euphrates river. I brought him here and I led him through all the land of Canaan. I gave him many descendants. I gave him a son, Isaac."
    },
    {
      "verse": "4",
      "text": "I gave to Isaac two sons, Jacob and Esau. I gave to Esau the hills of Seir. But Jacob and his sons went down to live in Egypt."
    },
    {
      "verse": "5",
      "text": "I sent Moses and Aaron to lead the Israelites when they were in Egypt. I punished the people of Egypt, and I brought you out from there."
    },
    {
      "verse": "6",
      "text": "When I brought your ancestors out of Egypt, they reached the Red Sea. The Egyptians chased after them to the sea, with soldiers on horses and in chariots."
    },
    {
      "verse": "7",
      "text": "But your ancestors called to the Lord for help. He made the space between them and the Egyptians become dark. He caused the Egyptian soldiers to drown in the sea. Your ancestors saw what I did to the Egyptians with their own eyes. After that, they lived in the desert for a long time."
    },
    {
      "verse": "8",
      "text": "I brought you to the land of the Amorites, on the east side of the Jordan River. They fought against you, but I helped you to win the fight. I destroyed them in front of you, and you took their land."
    },
    {
      "verse": "9",
      "text": "The king of Moab, Zippor's son Balak, prepared to attack you. When he did this, he asked Balaam, son of Beor, to curse you."
    },
    {
      "verse": "10",
      "text": "But I would not listen to Balaam. So he could not curse you but he continued to bless you. In that way I saved you from Balak's power."
    },
    {
      "verse": "11",
      "text": "Then you went across the Jordan River and you came to Jericho city. The people of Jericho fought against you. So did the Amorites, Perizzites, Canaanites, Hittites, Girgashites, Hivites and Jebusites. I helped you to win against all those people."
    },
    {
      "verse": "12",
      "text": "I sent great fear on your enemies as you moved into the land. I chased them all away, as well as the two kings of the Amorites. You did not win because of your strong weapons, but because of me."
    },
    {
      "verse": "13",
      "text": "The land was a gift from me. I gave you a land where you had not worked in its fields. I gave you towns to live in that you did not build. You eat grapes and olives from trees that you did not plant. ” ’"
    },
    {
      "verse": "14",
      "text": "Joshua said to the people, ‘Now you must serve the Lord with fear. You must worship him. You must continue to trust him. Throw away the gods that your ancestors worshipped when they lived beyond the Euphrates river and in Egypt. Worship the Lord."
    },
    {
      "verse": "15",
      "text": "But if you refuse to serve the Lord, then you should choose another god to worship. Decide today! Will you serve the gods that your ancestors worshipped across the river? Will you serve the gods of the Amorites, in whose land you are now living? You choose! But as for me and my family, we will serve the Lord. ’"
    },
    {
      "verse": "16",
      "text": "The people answered Joshua, ‘We would never turn against the Lord to serve other gods!"
    },
    {
      "verse": "17",
      "text": "We and our fathers were slaves in Egypt. But the Lord our God brought us out from there. We saw the great miracles that he did there. He kept us safe all the time on our journey, as we travelled through other nations."
    },
    {
      "verse": "18",
      "text": "The Lord chased all the nations out as we moved into the land. He chased out the Amorites and the other people who lived in the land. So we too will serve the Lord, because he is our God. ’"
    },
    {
      "verse": "19",
      "text": "Joshua said to them, ‘The Lord is a holy God. You will not be able to serve him. He wants you to belong to him. If you turn against him or you do not obey him, he will not forgive you."
    },
    {
      "verse": "20",
      "text": "If you turn away from the Lord and you serve foreign gods, he will turn against you. He has been kind and he has helped you until now. But he will bring trouble to you and he will destroy you, if you turn away from him. ’"
    },
    {
      "verse": "21",
      "text": "The people said to Joshua, ‘Never! We will only serve the Lord. ’"
    },
    {
      "verse": "22",
      "text": "Joshua said to them, ‘You yourselves have chosen to serve the Lord. Agree now that you have done that. ’They replied, ‘Yes, we agree! ’ They replied, ‘Yes, we agree! ’"
    },
    {
      "verse": "23",
      "text": "Joshua said, ‘So now you must throw away the foreign gods that you still keep. Trust the Lord, Israel's God, and obey him. ’"
    },
    {
      "verse": "24",
      "text": "The people said to Joshua, ‘We will serve the Lord our God and we will obey him. ’"
    },
    {
      "verse": "25",
      "text": "That same day, Joshua made an agreement for the people to accept. There at Shechem, he made a list of rules and laws for them to obey."
    },
    {
      "verse": "26",
      "text": "Joshua wrote these things in the Book of God's Law. Then he took a big stone. He stood it there under the oak tree that was near the Lord's holy place."
    },
    {
      "verse": "27",
      "text": "Joshua said to all the people, ‘Look at this stone! It has heard everything that the Lord has said to us today! It will speak against you if you fail to obey your God! ’"
    },
    {
      "verse": "28",
      "text": "Then Joshua sent the people away. They went to the parts of the land that now belonged to each of them."
    },
    {
      "verse": "29",
      "text": "After this, the Lord's servant, Joshua, son of Nun, died at the age of 110."
    },
    {
      "verse": "30",
      "text": "The Israelites buried him in his own land that was at Timnah Serah. That was in the hill country of Ephraim, north of Mount Gaash."
    },
    {
      "verse": "31",
      "text": "The people of Israel continued to serve the Lord while Joshua and the old men were still alive. Joshua and those men had seen everything that the Lord had done to help Israel."
    },
    {
      "verse": "32",
      "text": "The Israelites had brought Joseph's bones up from Egypt, to bury him at Shechem. This land was in the field that Jacob had bought from the sons of Hamor, Shechem's father. Jacob had paid them 100 pieces of silver for the land. Now the land belonged to Joseph's descendants."
    },
    {
      "verse": "33",
      "text": "Aaron's son, Eleazar, also died. The people buried him at Gibeah, in the hill country of Ephraim. That land had been given to Eleazar's son Phinehas."
    }
  ]
};