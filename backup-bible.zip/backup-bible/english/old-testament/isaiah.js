module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This is a vision that God showed to Isaiah, the son of Amoz. It was a message about his country, Judah, and the city of Jerusalem. God showed it to Isaiah at the time when Uzziah, then Jotham, then Ahaz and then Hezekiah were kings of Judah."
    },
    {
      "verse": "2",
      "text": "Hear the Lord, those who live in heaven! Listen to him, you people on the earth! Listen carefully because the Lord has spoken! He says, ‘I have helped my children to grow. I took care of them but now they have turned against me!"
    },
    {
      "verse": "3",
      "text": "An ox knows its master. A donkey knows the place where its master feeds it. But Israel's people do not know me. My people do not understand me. ’"
    },
    {
      "verse": "4",
      "text": "Oh! Israel, you are a nation of people who do not obey me. The people are guilty of many evil things. Their sins are like a heavy weight on their backs. They are a family of people who do wicked things. They have turned away from the Lord, the Holy God of Israel. They have turned their backs against him."
    },
    {
      "verse": "5",
      "text": "You continue to fight against God. Why do you do that? God will continue to punish you. You are weak and you hurt all over. Your mind and your body have great pain."
    },
    {
      "verse": "6",
      "text": "From the bottom of your feet, to the top of your head, everywhere hurts! There are wounds all over your body that are still bleeding. Nobody has cleaned your wounds or covered them. Nobody has put olive oil on them to make them better."
    },
    {
      "verse": "7",
      "text": "Your land has become useless. Fire has destroyed your towns and cities. Foreign people have taken the crops from your fields, while you stood there and watched. Strangers have destroyed everything in your country."
    },
    {
      "verse": "8",
      "text": "Jerusalem is now like a hut in a vineyard or in a field of crops. It stands there alone, with its enemies all round it."
    },
    {
      "verse": "9",
      "text": "Unless the Lord Almighty had left some of us alive, we would have become like Sodom. We would have been completely destroyed, like Gomorrah."
    },
    {
      "verse": "10",
      "text": "Yes, you are like the rulers of Sodom, so listen to the Lord's message! You are no better than the people in Gomorrah! So listen to what our God is saying to you."
    },
    {
      "verse": "11",
      "text": "The Lord says, ‘All your sacrifices are not important to me. I have received too many sacrifices that you have burned as gifts to me. I have received too many sheep and fat animals. I do not want any more blood from bulls, goats and lambs that you have offered to me as sacrifices. They do not give me any pleasure."
    },
    {
      "verse": "12",
      "text": "You come to worship me in my temple. But are you doing what I want? Did I ask you to march round the temple yards with all your animals?"
    },
    {
      "verse": "13",
      "text": "Do not bring any more useless gifts to offer to me! I do not like your incense. You like to have feasts at new moons, or on Sabbath days. But because of your sins, I hate all your holy meetings."
    },
    {
      "verse": "14",
      "text": "I hate your new moon feasts and your holy meetings. They have become like a heavy load for me. I cannot carry it any longer!"
    },
    {
      "verse": "15",
      "text": "When you lift up your hands to pray to me, I have to look away. Even if you pray very many times to me, I do not listen to you, because your hands are full of blood."
    },
    {
      "verse": "16",
      "text": "Wash yourselves and make yourselves clean! Remove your sins, so that I no longer see them. Stop doing evil things!"
    },
    {
      "verse": "17",
      "text": "Instead, learn to do what is right. Be honest and fair in what you do. Help people who are in pain. Make sure that widows and children who have no family receive justice. ’"
    },
    {
      "verse": "18",
      "text": "The Lord says, ‘Please come, so that we talk about this together. Even if your sins are like a red stain, they will become as white as snow. Even if they are bright red, they will become like white wool."
    },
    {
      "verse": "19",
      "text": "I will forgive you if you agree to obey me. If you are ready to do that, you will again eat plenty of good food from the land. That is what the Lord himself has said."
    },
    {
      "verse": "20",
      "text": "But if you refuse to obey me and you turn against me, you will die in war. ’That is what the Lord himself has said."
    },
    {
      "verse": "21",
      "text": "Oh! Jerusalem! Once you loved the Lord, as a wife loves her husband. But now you have become like a prostitute! At one time, the city was full of justice, and honest people lived there. But now the city is full of murderers!"
    },
    {
      "verse": "22",
      "text": "Your pure silver has become dirt. You have mixed water with your best wine."
    },
    {
      "verse": "23",
      "text": "Your rulers have turned against God. They are friends of robbers. They all accept bribes and they love to receive gifts. But they do not help widows or children who have no family. They do not make sure that they receive justice."
    },
    {
      "verse": "24",
      "text": "So the Lord says this. He is the Lord Almighty, Israel's Mighty One. He says, ‘Oh! I will punish my enemies as they deserve. I will pay them back!"
    },
    {
      "verse": "25",
      "text": "I will turn against you, Jerusalem. I will make you pure again. But you will be like metal that burns in a very hot fire to remove all the dirt."
    },
    {
      "verse": "26",
      "text": "Then I will again give you honest judges, as you had a long time ago. I will also give you wise officers, as you had before. After that, you will be called “The Righteous City” and “The Faithful City”. ’"
    },
    {
      "verse": "27",
      "text": "God will use justice to make Zion free. He will do what is right for those who return to serve him."
    },
    {
      "verse": "28",
      "text": "But he will destroy people who turn against him, and those who continue to do wrong things. People who no longer trust the Lord will live no more."
    },
    {
      "verse": "29",
      "text": "You will become ashamed because you trusted special oak trees to help you. You worshipped idols in your special gardens, and you will be ashamed because of that."
    },
    {
      "verse": "30",
      "text": "You will be like an oak tree with leaves that have become dry. You will be like a garden that has no water."
    },
    {
      "verse": "31",
      "text": "Even your most powerful men will disappear. They will be like a piece of string that burns in a fire. Their sins will be the fire that destroys them. They and their sins will burn together, and nobody will put out the fire."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "This is the message that appeared to Amoz's son, Isaiah, about Judah and Jerusalem."
    },
    {
      "verse": "2",
      "text": "This is what will happen in the last days. The mountain where the Lord's temple is will continue to be there. It will be the most important mountain of all. It will be higher than all the hills around it. People from every nation will go there all the time."
    },
    {
      "verse": "3",
      "text": "As they come, people from many nations will say, ‘Come! We will go to the mountain of the Lord, Jacob's God. We will go to worship him at his temple. Then he will teach us how to live in a way that pleases him. We will be able to walk in his paths. ’At that time, Zion will be the place where people learn about what is right. Yes, in Jerusalem the Lord will teach people his message. At that time, Zion will be the place where people learn about what is right. Yes, in Jerusalem the Lord will teach people his message."
    },
    {
      "verse": "4",
      "text": "God will be the judge between different nations. When they argue together, he will say who is right. They will take their swords and they will make them into ploughs. Their spears will become knives to cut their vines. Nations will no longer need weapons to attack other nations. They will not prepare to fight wars any more."
    },
    {
      "verse": "5",
      "text": "Jacob's family, come now! We need to live in the light that the Lord gives to us."
    },
    {
      "verse": "6",
      "text": "Lord, you have gone away from your people. They are Jacob's descendants. They are full of ideas from countries in the east. They use magic to learn about future times, as the Philistines do. They join hands with foreign people."
    },
    {
      "verse": "7",
      "text": "They are very rich and their land is full of silver and gold. They have many horses, and more chariots than you can count. Lord, do not forgive them!"
    },
    {
      "verse": "8",
      "text": "But their land is also full of useless idols. They worship things that they have made with their own hands."
    },
    {
      "verse": "9",
      "text": "People bend down low in front of their idols. They even lie flat on the ground! Lord, do not forgive them!"
    },
    {
      "verse": "10",
      "text": "Go up to the rocks in the hills! Find a hole in the ground where you can hide! Hide from the Lord's great power, because he is coming to punish you! He rules with great authority!"
    },
    {
      "verse": "11",
      "text": "The Lord will bring proud people down low. People who boast will have to stop. On that day, people will see that only the Lord is great."
    },
    {
      "verse": "12",
      "text": "Yes! The Lord Almighty will choose his great day. On that day, he will judge all the proud people who think that they are great. He will bring them all down very low."
    },
    {
      "verse": "13",
      "text": "The Lord will cut down the great cedar trees in Lebanon, and the oak trees in Bashan."
    },
    {
      "verse": "14",
      "text": "He will bring down the high mountains and the highest hills."
    },
    {
      "verse": "15",
      "text": "He will knock down all the strong towers and walls."
    },
    {
      "verse": "16",
      "text": "He will destroy the great ships that travel across the seas, and all the beautiful boats."
    },
    {
      "verse": "17",
      "text": "Like that, the Lord will bring proud people down low. People who boast will have to stop. On that day, people will see that only the Lord is great."
    },
    {
      "verse": "18",
      "text": "All the useless idols will be there no more."
    },
    {
      "verse": "19",
      "text": "People will run away to the caves in the hills. They will try to hide in holes in the ground. They will try to escape from the great power of the Lord, when he comes to judge everyone. They will see that he rules with great authority. People will be very afraid when he comes to punish the people on earth."
    },
    {
      "verse": "20",
      "text": "At that time, people will throw away their silver idols and their gold idols. They made those idols so that they could worship them. But now they will throw them into caves where rats and bats live."
    },
    {
      "verse": "21",
      "text": "The people themselves will look for caves and holes in the rocks where they can hide. They will try to escape from the Lord's punishment. They will see that he rules with great authority. They will be afraid when he comes to judge the people on earth."
    },
    {
      "verse": "22",
      "text": "Do not trust people to help you. They are weak and they will all die one day. They are not strong enough to help you."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "Listen to this! I will show you what the Lord, the Almighty Lord, will do. He will remove from Jerusalem and Judah everything that people trust to help them. He will take away even their food and their water."
    },
    {
      "verse": "2",
      "text": "He will take awaythe brave men and the soldiers, the judges and the prophets, their leaders and the people who have visions of future things,"
    },
    {
      "verse": "3",
      "text": "the army officers and the city officers, the wise advisors, and those who use magic to do clever things."
    },
    {
      "verse": "4",
      "text": "The Lord says, ‘I will cause boys to become their leaders who will rule them badly."
    },
    {
      "verse": "5",
      "text": "People will be cruel to each other. Men will argue against one another and neighbours will fight each other. Young people will insult older people. And useless people will speak against people that they should respect."
    },
    {
      "verse": "6",
      "text": "A man will go to his father's house and he will take hold of his brother. The man will say to him, “Look, you have a coat. So you should be our leader! You can rule over the few buildings that remain in our city! ”"
    },
    {
      "verse": "7",
      "text": "But the brother will refuse. He will say, “I cannot make things any better! There is no food or clothes in my house. Do not choose me as a leader of people. ” ’"
    },
    {
      "verse": "8",
      "text": "Jerusalem is falling down! The towns of Judah are in trouble! The Lord hates the things that their people say and the things that they do. They have turned against the Lord and they insult him."
    },
    {
      "verse": "9",
      "text": "Their proud faces show that they are guilty. Their sins are as bad as the sins of Sodom's people. And they do not try to hide it! It will be very bad for them! They have caused great trouble for themselves."
    },
    {
      "verse": "10",
      "text": "Tell the righteous people that they are in a good place. They will enjoy the results of the good things that they have done."
    },
    {
      "verse": "11",
      "text": "But it will be very bad for the wicked people. They will receive the punishment that they deserve."
    },
    {
      "verse": "12",
      "text": "Now children are cruel to my people and women rule over them. My people, your leaders lead you in the wrong direction. They cannot show you what is right."
    },
    {
      "verse": "13",
      "text": "The Lord stands up to judge his people. He will decide how to punish them."
    },
    {
      "verse": "14",
      "text": "He comes to judge the leaders and rulers of his people. He says to them, ‘You have destroyed my vineyard. You have robbed the poor people and you have stored their things in your own houses."
    },
    {
      "verse": "15",
      "text": "What are you leaders doing? You should not hurt my people. You should not be cruel to the poor people, as if you are pushing their faces into the dirt. ’The Lord Almighty has said this. The Lord Almighty has said this."
    },
    {
      "verse": "16",
      "text": "The Lord says, ‘Zion's women are very proud. They walk with their heads up high. They turn their eyes towards the men and they have no shame. They like the men to look at them. They walk with small steps so that the rings on their ankles make a nice sound."
    },
    {
      "verse": "17",
      "text": "Because of that, the Lord God will give them sores on their heads. Those beautiful women will be bald! ’"
    },
    {
      "verse": "18",
      "text": "On that day, the Lord God will take away the beautiful rings that they wear on their ankles. He will remove all the valuable rings and bright stones that they wear on their heads, their necks, their ears, their arms, their fingers and their noses. He will take away their beautiful clothes, their belts, their perfumes and their magic rings."
    },
    {
      "verse": "19",
      "text": "He will remove all the valuable rings and bright stones that they wear on their heads, their necks, their ears, their arms, their fingers and their noses."
    },
    {
      "verse": "20",
      "text": "He will take away their beautiful clothes, their belts, their perfumes and their magic rings."
    },
    {
      "verse": "21",
      "text": "Instead of a nice smell of perfume, there will be a smell of dead animals."
    },
    {
      "verse": "22",
      "text": "Instead of a beautiful belt, they will tie a rope round themselves. Instead of lovely hair, they will be bald. They will wear rough sackcloth instead of beautiful dresses. They will have the mark of a prisoner on their skin, instead of beauty."
    },
    {
      "verse": "23",
      "text": "The men of your city will die in war. Yes, your strong brave men will die in battle."
    },
    {
      "verse": "24",
      "text": "Instead of a nice smell of perfume, there will be a smell of dead animals. Instead of a beautiful belt, they will tie a rope round themselves. Instead of lovely hair, they will be bald. They will wear rough sackcloth instead of beautiful dresses. They will have the mark of a prisoner on their skin, instead of beauty."
    },
    {
      "verse": "25",
      "text": "The men of your city will die in war. Yes, your strong brave men will die in battle."
    },
    {
      "verse": "26",
      "text": "The city's gates will see all this and they will weep! The city will be empty. Zion will be like a poor woman who sits on the ground, completely alone."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "In that day, seven women will catch one man and they will hold him. They will say, ‘Please take away our shame. We will buy our own food and we will wear our own clothes. But please, let us belong to you. ’"
    },
    {
      "verse": "2",
      "text": "In that day, the branch of the Lord will be great and beautiful. The land will give fruit and crops. Those people who remain in Israel will be proud and happy because of the food that the land supplies."
    },
    {
      "verse": "3",
      "text": "Everyone who remains in Zion and Jerusalem will be called holy. All their names will be on a list of Jerusalem's people who live there."
    },
    {
      "verse": "4",
      "text": "At that time, the Lord God will wash away the dirt from Zion's women. He will make Jerusalem clean from the blood that murderers have left. He will do that as judge, and he will punish people as with fire."
    },
    {
      "verse": "5",
      "text": "The Lord himself will be above all of Mount Zion, and over all the people who meet together there. There will be cloud and smoke over them during the day. There will be bright flames of fire at night. The Lord's glory will cover over them all."
    },
    {
      "verse": "6",
      "text": "During the day, it will give people shade from the sun's heat. It will also keep them safe from storms and heavy rain."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Now I will sing a song for the person that I love. I will sing to him about his vineyard. ‘The one that I love had a vineyard. It was on a hill where the soil is good. ‘The one that I love had a vineyard. It was on a hill where the soil is good."
    },
    {
      "verse": "2",
      "text": "He dug the ground and he removed the stones. He planted the best vines in it. He built a tower in the middle of the vineyardso that he could watch it. He built a place to squeeze the grapesto make wine. Then he waited for the vines to make sweet grapes. But the vines made only bitter grapes. ’ He planted the best vines in it. He built a tower in the middle of the vineyard so that he could watch it. He built a place to squeeze the grapes to make wine. Then he waited for the vines to make sweet grapes. But the vines made only bitter grapes. ’"
    },
    {
      "verse": "3",
      "text": "So now, listen to me, you people who live in Jerusalem and in Judah. You must be the judge! Who did what was right? Was it me or my vineyard? You decide!"
    },
    {
      "verse": "4",
      "text": "I did everything that I could to help my vineyard. I could have done no more! But when I waited to get sweet grapes from the vines, there were only bitter ones! Why was that?"
    },
    {
      "verse": "5",
      "text": "Now I will tell you what I will do to my vineyard. I will break down its walls, so that it becomes an open field. Then wild animals will go in and they will destroy the vines."
    },
    {
      "verse": "6",
      "text": "I will make the land become useless. Nobody will take care of the vines. Nobody will dig the ground. Weeds and thorn bushes will grow there. I will command the clouds, ‘Do not drop any rain on it. ’"
    },
    {
      "verse": "7",
      "text": "Israel's nation is like the vineyard of the Lord Almighty. Judah's people are his beautiful garden. But when the Lord looked there for justice, he found only murder! When he looked for people who were righteous, he saw that they were cruel."
    },
    {
      "verse": "8",
      "text": "It will be very bad for you people who buy many houses for yourselves. You also buy land to join to the land that you already have. Then there is no more land left for anyone else. You are the only people who remain on the land."
    },
    {
      "verse": "9",
      "text": "I have heard the Lord Almighty promise this: ‘All these great, beautiful houses will certainly become empty. There will be nobody to live in them."
    },
    {
      "verse": "10",
      "text": "Large vineyards will give only a few bottles of wine. If you plant ten bags of seed, you will only get one bag of grain as your harvest. ’"
    },
    {
      "verse": "11",
      "text": "It will be bad for you people who like to get up early to start drinking. You continue to drink late into the night, until you are very drunk."
    },
    {
      "verse": "12",
      "text": "You have wild parties with plenty of music and wine. You make music with your lyres, harps, tambourines and flutes. But you do not understand the things that the Lord is doing. You do not see the things that he has made."
    },
    {
      "verse": "13",
      "text": "Because of that, my people will go into exile in countries far away. They do not know God. Their leaders will die because they have nothing to eat. All the other people will have nothing to drink."
    },
    {
      "verse": "14",
      "text": "So the deep hole of death will be hungry! It will open wide to eat the people of Jerusalem. The leaders and the people will go down into it. It will eat up those who are happy at their wild parties in Jerusalem."
    },
    {
      "verse": "15",
      "text": "So the Lord will bring its people down low. Its proud people will become ashamed."
    },
    {
      "verse": "16",
      "text": "But the Lord Almighty will be lifted up high by his justice. People will know that he is holy when he comes as judge."
    },
    {
      "verse": "17",
      "text": "Then lambs will find good grass to eat, as they do in their own fields. Fat sheep will find food to eat among the stones of the old houses."
    },
    {
      "verse": "18",
      "text": "It will be very bad for you people who are always deceiving others. You cannot leave your sins behind, like someone who pulls a cart with a rope."
    },
    {
      "verse": "19",
      "text": "People like that laugh at God. They say, ‘The Lord should do something quickly! We want to see what he can do. The holy God of Israel should do what he has decided to do. Then we will really know what that is! ’"
    },
    {
      "verse": "20",
      "text": "It will be very bad for people who call evil things good. And they call good things evil. They say, ‘It is light’, when it is dark. And they say, ‘It is dark’, when it is light. They say that bitter things are sweet. And they say that sweet things are bitter."
    },
    {
      "verse": "21",
      "text": "It will be very bad for people who think that they are wise. They think that they are very clever."
    },
    {
      "verse": "22",
      "text": "It will be very bad for people who think that they are famous because they can drink a lot of wine. They think that they are very brave to mix strong drinks together."
    },
    {
      "verse": "23",
      "text": "If people like that receive a bribe, they will not say that wicked people are guilty. They also refuse to say that righteous people are not guilty."
    },
    {
      "verse": "24",
      "text": "Because of that, they will come to a bad end. It will be for them like a hot fire that destroys dry grass. Their roots will die and their flowers will blow away like dust. They have refused to obey the laws of the Lord Almighty. They have not listened to the message that the holy God of Israel has taught them."
    },
    {
      "verse": "25",
      "text": "So the Lord has become angry with his people. He is ready to punish them. He has lifted up his hand, so that the mountains shake. Dead bodies of people are lying all over the streets. But that is not enough! The Lord is still angry with them. His hand is ready to punish them even more."
    },
    {
      "verse": "26",
      "text": "The Lord will send a message to foreign nations to come and attack. He calls to nations that are far away, and now they are already coming! Their armies march quickly to Jerusalem."
    },
    {
      "verse": "27",
      "text": "None of their soldiers are tired. They do not fall down. Nobody rests. Nobody sleeps. They have tied their belts strongly. Their shoes do not break in pieces."
    },
    {
      "verse": "28",
      "text": "Their arrows are sharp. Their bows are ready to shoot. Their horses' feet are as hard as stones. The wheels of their chariots go round very fast."
    },
    {
      "verse": "29",
      "text": "As they march to fight, they roar like lions. They are like strong young lions that catch other animals to eat. They carry their prisoners away to places where nobody can rescue them."
    },
    {
      "verse": "30",
      "text": "On the day that they attack, the enemy will roar over the people that they catch. They will make a noise like a rough sea. If anyone looks across the land, it will be completely dark because of all the trouble. Clouds will make the light of day become dark."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "In the year when King Uzziah died, I saw the Lord God. He was sitting high up, on a throne. The ends of his long coat filled the temple."
    },
    {
      "verse": "2",
      "text": "Above him there were seraphs. Each one had six wings. Two wings covered the seraphs' faces. Two wings covered their feet. With the other two wings they were flying."
    },
    {
      "verse": "3",
      "text": "The seraphs called out to one another. They said, ‘Holy, holy, holy is the Lord Almighty! The whole earth is full of his great glory. ’"
    },
    {
      "verse": "4",
      "text": "When the seraphs spoke, the foundation of the temple shook. And the temple became full of smoke."
    },
    {
      "verse": "5",
      "text": "Then I said, ‘It is bad for me! My life is at an end! I have lips that are unclean. I live among people with lips that are unclean. With my own eyes I have seen the King, the Lord Almighty. ’"
    },
    {
      "verse": "6",
      "text": "Then one of the seraphs flew towards me. In his hand was a piece of burning coal. He had used a tool to take it from the altar."
    },
    {
      "verse": "7",
      "text": "He touched my mouth with the piece of coal. He said to me, ‘Look! This has touched your lips. It has taken away your sin. You are no longer guilty. ’"
    },
    {
      "verse": "8",
      "text": "Then I heard the voice of the Lord God. He said, ‘Is there anyone that I can send with my message? Who will go on our behalf? ’ I said, ‘I am here. Send me! ’"
    },
    {
      "verse": "9",
      "text": "The Lord said, ‘Go! Tell my message to those people:“You will continue to listen, but you will never understand! You will continue to look, but you will not see anything! ” “You will continue to listen, but you will never understand! You will continue to look, but you will not see anything! ”"
    },
    {
      "verse": "10",
      "text": "Make them refuse to understand. Cause their ears to be deaf and their eyes to be blind. If you do not do that, they might use their eyes to see. They might use their ears to listen. They might use their minds to understand. Then they might turn back to me so that I would make them well again. ’"
    },
    {
      "verse": "11",
      "text": "Then I asked the Lord, ‘For how long will this be, Lord God? ’He replied, ‘It must continue until enemies destroy their cities. Their houses will become a heap of stonesand nobody will live in them. Their land will become uselessand nothing will remain there. He replied, ‘It must continue until enemies destroy their cities. Their houses will become a heap of stones and nobody will live in them. Their land will become useless and nothing will remain there."
    },
    {
      "verse": "12",
      "text": "I will send all the people far away. The whole land will be empty and useless. The whole land will be empty and useless."
    },
    {
      "verse": "13",
      "text": "Even if only one tenth part of the people remain in the land, enemies will continue to destroy it. It will be like they are cutting down a great oak tree. But the base of the tree with its roots will still be there. From the part that remains, a holy branch will grow. ’"
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "Ahaz became the king of Judah. He was the son of Jotham. Jotham was the son of Uzziah. While Ahaz was Judah's king, King Rezin of Syria and Remaliah's son, King Pekah of Israel, attacked Jerusalem. But they could not get into the city."
    },
    {
      "verse": "2",
      "text": "People gave this news to Judah's royal family. They said, ‘The armies of Syria and Ephraim have joined together to attack you. ’ When they heard this, Ahaz and his people were very afraid. They shook with fear, like trees in the forest shake in the wind."
    },
    {
      "verse": "3",
      "text": "Then the Lord said to Isaiah, ‘Go out and meet Ahaz. Take your son, Shear-Jashub, with you. Go to meet Ahaz at the end of the water stream that comes from the higher pool. That is at the field where people wash clothes."
    },
    {
      "verse": "4",
      "text": "Say to Ahaz, “Be careful. Do not be upset or afraid. Do not let King Rezin, his people from Syria and Remaliah's son, King Pekah, make you afraid. They are very angry, but their power will soon be useless, like two bits of wood that remain after a fire."
    },
    {
      "verse": "5",
      "text": "The rulers of Syria and Ephraim, as well as Remaliah's son, have made plans to attack you."
    },
    {
      "verse": "6",
      "text": "They are saying, ‘We must attack Judah. We will frighten the people and we will take their country for ourselves. We will make the son of Tabeel rule there as king. ’"
    },
    {
      "verse": "7",
      "text": "But I, the Almighty Lord, say this: That will never happen!"
    },
    {
      "verse": "8",
      "text": "The capital city of Syria is Damascus. And the king of Damascus is Rezin. 65 years from now Ephraim will not even be a nation. There will be nothing left!"
    },
    {
      "verse": "9",
      "text": "The capital city of Ephraim is Samaria. And the king of Samaria is Remaliah's son. If you do not continue to trust me, you will not be strong enough to win. ” ’"
    },
    {
      "verse": "10",
      "text": "Isaiah also gave this message from the Lord to Ahaz."
    },
    {
      "verse": "11",
      "text": "He said, ‘Ask the Lord your God to do a miracle for you. That will show you that what he has said is true. Ask for anything, deep in the earth or high in the sky. ’"
    },
    {
      "verse": "12",
      "text": "But Ahaz said, ‘I will never ask the Lord to do that. I do not want to test him. ’"
    },
    {
      "verse": "13",
      "text": "So Isaiah replied, ‘Now listen, you royal family of David! You cause trouble for people like me. That is bad enough. But now you are trying to cause trouble for God himself."
    },
    {
      "verse": "14",
      "text": "So the Lord God himself will show you that he speaks a true message. Look, the young woman who has never had sex will become pregnant. She will give birth to a son. She will call his name Immanuel."
    },
    {
      "verse": "15",
      "text": "One day he will know how to choose good things and refuse to do evil things. By that time there will be cream and honey for him to eat."
    },
    {
      "verse": "16",
      "text": "Even before that, the two kings that you are now afraid of will have no power. Their land will be empty."
    },
    {
      "verse": "17",
      "text": "But the Lord will bring even greater trouble to you! It will be very bad for you, for the royal family, and for your people. Nothing as bad will have happened since Ephraim became separate from Judah. Yes, the Lord will bring the king of Assyria to attack you! ’"
    },
    {
      "verse": "18",
      "text": "At that time, the Lord will call the soldiers of Egypt to come and attack you. And they will come like a crowd of flies! He will call for soldiers to come from Assyria. And they will come like a crowd of bees!"
    },
    {
      "verse": "19",
      "text": "They will all come in great crowds. They will come into the valleys, the cliffs, the holes in the rocks, the thorn bushes and the pools of water."
    },
    {
      "verse": "20",
      "text": "At that time, the Lord will use the king of Assyria to bring trouble and pain. He will come from beyond the Euphrates river. He will be like a sharp knife that cuts off all your hair, the hair from your head, your legs and your beard."
    },
    {
      "verse": "21",
      "text": "At that time, a farmer will have only one young cow and two goats."
    },
    {
      "verse": "22",
      "text": "They will give him a lot of milk. So he will have butter and cream to eat. Everyone who remains in the land will have milk and honey as their food."
    },
    {
      "verse": "23",
      "text": "On that day, in every place where there had been 1, 000 valuable vines, there will now be only weeds and thorn bushes."
    },
    {
      "verse": "24",
      "text": "In the whole land there will be only weeds and thorn bushes. So men will go to shoot wild animals there with their bows and arrows."
    },
    {
      "verse": "25",
      "text": "Nobody will go to the fields in the hills, because only thorn bushes grow there. People will be afraid to go there. They will send their cows there to eat grass. Sheep will run over the fields."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "The Lord said to me, ‘Get a large board to write on. Then write clear words on it. Write this name: “Maher-Shalal-Hash-Baz. ”"
    },
    {
      "verse": "2",
      "text": "I will call Uriah the priest and Jeberekiah's son, Zechariah, to come to see this. They are honest people who will say what is true. ’"
    },
    {
      "verse": "3",
      "text": "Then I slept with my wife, the prophetess. She became pregnant and she gave birth to a son. The Lord said to me, ‘Call his name Maher-Shalal-Hash-Baz."
    },
    {
      "verse": "4",
      "text": "Before the child knows how to say “my father” or “my mother”, the king of Assyria will attack Damascus and Samaria. His army will carry away the valuable things from those cities. That is why your son's name must be Maher-Shalal-Hash-Baz. ’"
    },
    {
      "verse": "5",
      "text": "The Lord spoke to me again."
    },
    {
      "verse": "6",
      "text": "He said, ‘I have blessed my people, like the quiet stream of Shiloah. But they have not accepted my help. Instead, they are happy that King Rezin and Remaliah's son will help them."
    },
    {
      "verse": "7",
      "text": "So I will cause this to happen. I, the Lord God, will bring floods of water from the Euphrates river. That will be the king of Assyria and his powerful armies. They will come like a great river that rises high over its sides."
    },
    {
      "verse": "8",
      "text": "Its water will come as a flood into Judah. It will cover the land and it will rise as high as people's necks! He will make his wings very wide to cover all your land, Immanuel. ’"
    },
    {
      "verse": "9",
      "text": "You foreign nations must listen to this! Join together to fight. Shout as you go to battle. But you will never win! You people from countries that are far away, get ready for war. But you will be completely destroyed!"
    },
    {
      "verse": "10",
      "text": "Decide how you will fight the battle, but your plans will fail! What you decide to do will never happen. God is with us!"
    },
    {
      "verse": "11",
      "text": "Now the Lord spoke to me with great power. He warned me that I must not be like the other people in Judah. He said,"
    },
    {
      "verse": "12",
      "text": "‘Those people are talking about an agreement to turn against the rulers. But do not agree with what they say. Do not be afraid of the things that frighten them. Do not be afraid, as they are."
    },
    {
      "verse": "13",
      "text": "Instead, you should understand that the Lord Almighty has all authority. You should respect him as holy and be afraid of him."
    },
    {
      "verse": "14",
      "text": "He will be a safe place for you. But for both nations in Israel he will become like a stone that causes people to fall to the ground. He will be like a rock that makes them fall down. He will take hold of the people who live in Jerusalem, like a trap that catches a bird."
    },
    {
      "verse": "15",
      "text": "Many people will fall against that rock. They will fall to the ground and it will hurt them. They will become caught in a trap. ’"
    },
    {
      "verse": "16",
      "text": "Tie a string round the paper where I have written this. Keep it safe as a true message. Give it to my disciples, to teach them."
    },
    {
      "verse": "17",
      "text": "I will wait for the Lord to do what he says. He has turned away from the descendants of Jacob. But I will trust him to do what is right."
    },
    {
      "verse": "18",
      "text": "Look! Here I am, with the children that the Lord has given to me. We are messages from the Lord Almighty who lives on Mount Zion. We are messages to Israel's people."
    },
    {
      "verse": "19",
      "text": "They will say to you, ‘Go to the people who speak to the spirits of dead people. Go to the magicians who speak magic words. They will tell you what you should do. People should ask their gods and spirits to give them messages. People who are alive should ask the spirits of dead people to help them. ’"
    },
    {
      "verse": "20",
      "text": "When they say that to you, remember my teaching. Tell them what I have said will happen. People who talk like that are completely in the dark. There is no truth in what they say."
    },
    {
      "verse": "21",
      "text": "Then the people will travel through the land, and they will be sad and hungry. Because of their hunger they will become angry. They will curse their king and their God, as they look up to the sky."
    },
    {
      "verse": "22",
      "text": "They will look down at the earth, but they will only see trouble. Everywhere will be dark and people will have no hope. Then they will fall into complete darkness."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "But the darkness will not continue for ever. Those who had no hope will no longer be afraid. In past times, God let trouble happen to the land of Zebulun and the land of Naphtali. But in future years, he will cause the people of that region to be great. Those are the places near the sea, and those beyond the Jordan River, and Galilee region where people from other nations live."
    },
    {
      "verse": "2",
      "text": "The people who walk in the dark now see a bright light! Light is shining on those people who live in a land of complete darkness."
    },
    {
      "verse": "3",
      "text": "You, Lord, will make your nation stronger. You will cause your people to be very happy. They will be happy because you are with them. They will be like people who are happy at the time of harvest. They will be happy like soldiers who have won a battle, and who share their enemy's valuable things among themselves."
    },
    {
      "verse": "4",
      "text": "They are happy because you have removed the power of their cruel enemies. They no longer have to carry a heavy load, as slaves. You have rescued them from their enemies, in the same way that you won against Midian's army."
    },
    {
      "verse": "5",
      "text": "Fire will destroy every shoe that the soldiers wore to march into the battle. Their clothes which have the blood of war on them will also go into the fire."
    },
    {
      "verse": "6",
      "text": "Yes, your people are happy! A child has been born for us. We now have a son with the authority to rule. His names will be: Wonderful Advisor, Mighty God, Father for Ever, Ruler who brings Peace."
    },
    {
      "verse": "7",
      "text": "His authority to rule will be very great. The peace that he brings will never have an end. He will rule as king over David's kingdom. He will make it strong and safe, because he will do what is right and fair. He will rule like that now and for ever. The Lord Almighty will make those things happen, because he loves his people."
    },
    {
      "verse": "8",
      "text": "The Lord God has spoken a message to warn Jacob's descendants, the kingdom of Israel."
    },
    {
      "verse": "9",
      "text": "All the people who live in Ephraim and in the city of Samaria know about it. But they are proud and they boast,"
    },
    {
      "verse": "10",
      "text": "‘We built houses with bricks and they fell down. But we will build them again with strong stones. People have cut down our fig trees, but we will plant great cedar trees instead. ’"
    },
    {
      "verse": "11",
      "text": "But the Lord caused Rezin's enemies, and other nations to attack Israel. But the Lord is still angry. His hand is ready to hit them again."
    },
    {
      "verse": "12",
      "text": "Syria's army came from the east. The Philistines' army came from the west. They destroyed Israel's land, like a hungry animal. But the Lord is still angry. His hand is ready to hit them again."
    },
    {
      "verse": "13",
      "text": "The people did not turn back to the Lord Almighty, who had punished them. They did not ask for his help."
    },
    {
      "verse": "14",
      "text": "So, in one day, the Lord will destroy Israel, both its head and its tail. He will cut down both palm branch and reed."
    },
    {
      "verse": "15",
      "text": "The head is their leaders and important people. The tail is the prophets who teach lies."
    },
    {
      "verse": "16",
      "text": "The leaders of this nation lead them away from what is true. They confuse the people that they are leading. But the Lord is still angry. His hand is ready to hit them again."
    },
    {
      "verse": "17",
      "text": "So the Lord God is not pleased with their young men. He will not help their widows or their children who have no family. Nobody respects God and they all do evil things. They only speak about foolish things. But the Lord is still angry. His hand is ready to hit them again."
    },
    {
      "verse": "18",
      "text": "The evil things that the people do destroy everything. They are like a fire that destroys thorn bushes. They burn up all the bushes in the forest. Clouds of smoke rise up from a great fire."
    },
    {
      "verse": "19",
      "text": "The Lord Almighty is very angry. He punishes the land of Israel, like a fire that burns everything. The people are like wood that makes the fire burn well. None of them try to help each other."
    },
    {
      "verse": "20",
      "text": "People eat whatever food they can get, on their right side or their left side. But they are still hungry. They even eat their own family!"
    },
    {
      "verse": "21",
      "text": "Manasseh's tribe and Ephraim's tribe fight against each other. Then they join together to attack Judah. But the Lord is still angry. His hand is ready to hit them again."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "It will be very bad for people who make cruel laws that are not fair."
    },
    {
      "verse": "2",
      "text": "They stop poor people from receiving what they should have. They do not let helpless people receive justice. They rob widows of all their things. They take things that belong to children who have no family."
    },
    {
      "verse": "3",
      "text": "It will be bad for you on the day when God comes to judge people. You will not escape the punishment that he will bring from far away. There will be nobody to help you. There will be no safe place to hide your valuable things. But the Lord is still angry. His hand is ready to hit his people again."
    },
    {
      "verse": "4",
      "text": "You will have to join the people who are in prison. Or you will die with those that the enemy kills in war. But the Lord is still angry. His hand is ready to hit his people again."
    },
    {
      "verse": "5",
      "text": "It will be very bad for Assyria! I will use its army to punish my people, because I am angry with them. Assyria will be like a stick that I use to beat my people. That is how I will show them my anger."
    },
    {
      "verse": "6",
      "text": "I send Assyria's army against a nation that does not serve God. I command them to attack the people with whom I am angry. I tell them to take that nation's valuable things for themselves. I tell them to walk all over them, as if they were walking on dirt in the streets."
    },
    {
      "verse": "7",
      "text": "But Assyria's ruler has other ideas. He does not understand that he is my weapon. He wants his army to destroy many nations, so that they have no power."
    },
    {
      "verse": "8",
      "text": "He boasts, ‘All my army's officers are like kings!"
    },
    {
      "verse": "9",
      "text": "We destroyed Calno as we destroyed Carchemish. We destroyed Hamath as well as Arpad. We destroyed Samaria as well as Damascus."
    },
    {
      "verse": "10",
      "text": "The idols of those cities were greater than those in Jerusalem or Samaria. But we won against them all!"
    },
    {
      "verse": "11",
      "text": "So I will destroy Jerusalem and its idols, in the same way that I did to Samaria and its idols. ’"
    },
    {
      "verse": "12",
      "text": "The Lord God will come to punish Mount Zion and Jerusalem. But when he has done that, he says, ‘Now I will punish the king of Assyria. He boasts in his mind and his eyes show how proud he is. ’"
    },
    {
      "verse": "13",
      "text": "The king of Assyria says this:‘I have won these battles because of my own strength. I have been very wise and clever. I have marched into nations as if they had no borders. I have taken their valuable things for myself. Like a wild bull, I have removed kings from their thrones. ‘I have won these battles because of my own strength. I have been very wise and clever. I have marched into nations as if they had no borders. I have taken their valuable things for myself. Like a wild bull, I have removed kings from their thrones."
    },
    {
      "verse": "14",
      "text": "I robbed them of their riches, like a person who takes eggs from a bird's nest. I was able to bring all the nations under my power. None of them could stop me. No bird could shake its wing at me, or open its mouth to cry at me! ’ like a person who takes eggs from a bird's nest. I was able to bring all the nations under my power. None of them could stop me. No bird could shake its wing at me, or open its mouth to cry at me! ’"
    },
    {
      "verse": "15",
      "text": "The Lord says this:‘The axe has no more power than the person who uses it. A saw is not more important than the person who cuts with it. A stick cannot lift up the man who holds it. No, it is the man that lifts up the stick! ’ ‘The axe has no more power than the person who uses it. A saw is not more important than the person who cuts with it. A stick cannot lift up the man who holds it. No, it is the man that lifts up the stick! ’"
    },
    {
      "verse": "16",
      "text": "So the Lord, the Almighty Lord, will punish Assyria's soldiers. They are now fat and healthy, but they will become thin! It will be like a fire that burns them, with all their proud strength."
    },
    {
      "verse": "17",
      "text": "The holy God, who is the Light of Israel, will become like a fire. Assyria's soldiers will be like weeds and thorn bushes and the fire will destroy them in one day."
    },
    {
      "verse": "18",
      "text": "The Lord will completely destroy Assyria's great forests and its good fields. It will seem like a bad disease is taking away their life."
    },
    {
      "verse": "19",
      "text": "Only a few trees will remain in the forests. Even a child will be able to count them!"
    },
    {
      "verse": "20",
      "text": "At that time, only a few people will remain in Israel. Only a few descendants of Jacob will still be alive. They will no longer expect to receive help from a foreign ruler who is cruel to them. Instead, they will trust the Lord, the Holy God of Israel, to help them."
    },
    {
      "verse": "21",
      "text": "A few of Jacob's descendants will remain, and they will return to serve the mighty God."
    },
    {
      "verse": "22",
      "text": "Israel's people are now very many, as many as the sand on the shore of the sea. But only a few will remain to return. The Lord has decided to destroy you, people of Israel. His punishment is fair and right."
    },
    {
      "verse": "23",
      "text": "The Lord Almighty will destroy the whole land. He is ready to do that, as he has promised."
    },
    {
      "verse": "24",
      "text": "So this is what the Lord Almighty says: ‘My people who live in Zion, do not be afraid of the Assyrian army. They will hurt you, like someone who hits you with a heavy stick. They will be cruel to you like the people in Egypt were long ago."
    },
    {
      "verse": "25",
      "text": "But soon I will be angry with you no longer. Instead, I will be angry with the Assyrians, and I will be ready to destroy them. ’"
    },
    {
      "verse": "26",
      "text": "Yes, the Lord Almighty will punish the Assyrians, like someone who uses a whip to beat them. That is how he destroyed the Midianites at the Rock of Oreb. He will hold his stick over the sea. He will lift it up as he did in Egypt."
    },
    {
      "verse": "27",
      "text": "At that time, the Lord will remove the heavy load that is on your shoulders. He will destroy the yoke that is on your neck. You will no longer be their slaves. The Lord will bless you and make you fat."
    },
    {
      "verse": "28",
      "text": "Assyria's army attacks Aiath! It marches through Migron. They store their things at Michmash."
    },
    {
      "verse": "29",
      "text": "They go across the hills. They stay at Geba for a night. The people in Ramah are afraid! The people in Gibeah of Saul run away."
    },
    {
      "verse": "30",
      "text": "People in Gallim, shout for help! Listen carefully, people in Laishah. Answer them, people in Anathoth."
    },
    {
      "verse": "31",
      "text": "The people in Madmenah run away. Those who live in Gebim run to a safe place."
    },
    {
      "verse": "32",
      "text": "Today, the enemy has reached Nob and it stops there. He shakes his fist angrily at the people who live on Mount Zion in the city of Jerusalem."
    },
    {
      "verse": "33",
      "text": "But look! The Lord Almighty is ready to use his great power to destroy Assyria's strong army. He will cut it down, like a tall tree. He will cut off all the branches and knock all the trees down to the ground."
    },
    {
      "verse": "34",
      "text": "The Lord will take his axe and he will cut down the trees of that great forest. Even the best trees of Lebanon must fall down!"
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "A descendant of Jesse will appear, like a new branch that grows from a tree stump. The roots of the tree will give new fruit!"
    },
    {
      "verse": "2",
      "text": "The Spirit of the Lord will be with him. The Spirit will make him wise, so that he understands things. The Spirit will show him what is right, and he will have the power to do it. The Spirit will cause him to know the Lordand to serve him truly. The Spirit will make him wise, so that he understands things. The Spirit will show him what is right, and he will have the power to do it. The Spirit will cause him to know the Lord and to serve him truly."
    },
    {
      "verse": "3",
      "text": "To obey the Lord will make him very happy. He will not judge people because of what he sees with his eyes. He will not judge them because of what he hears about them with his ears."
    },
    {
      "verse": "4",
      "text": "But he will judge poor people with true justice. He will decide to do what is right for all the helpless people. He will have authority everywhere in the land. The words that he speaks will bring death to wicked people."
    },
    {
      "verse": "5",
      "text": "He will wear justice like a belt round his clothes. He will always be honest and true."
    },
    {
      "verse": "6",
      "text": "When he is king, wolves will live beside lambs! Leopards will lie down with young goats! Young cows and lions will feed together, and a young child will take care of them!"
    },
    {
      "verse": "7",
      "text": "Cows and bears will feed together. Even their children will lie down side by side. Lions will eat grass, as cows do."
    },
    {
      "verse": "8",
      "text": "If a baby plays near the hole where a snake lives, he will be safe. A young child may even put his hand into the hole of a dangerous snake."
    },
    {
      "verse": "9",
      "text": "Nothing will hurt or destroy anything else anywhere on my holy mountain. Instead, people will know the Lord all over the earth, as water fills the whole sea."
    },
    {
      "verse": "10",
      "text": "On that day, King David's descendant, the root of Jesse, will appear. He will be like a clear sign to all nations. They will come to him, so that he leads them. The place where he lives as king will be wonderful."
    },
    {
      "verse": "11",
      "text": "And on that day, the Lord God will bring his people back once again. He will lift up his powerful hand to rescue his people who are still alive. He will bring them back from Assyria, Egypt, Pathros, Cush, Elam, Babylonia, Hamath and from countries near the sea."
    },
    {
      "verse": "12",
      "text": "The Lord will lift up a clear sign for the nations to see. He will bring together Israel's people that their enemies took away. Yes, he will bring back Judah's exiles from all over the earth."
    },
    {
      "verse": "13",
      "text": "Ephraim will no longer be jealous of Judah. Judah will no longer be Ephraim's enemy."
    },
    {
      "verse": "14",
      "text": "But they will join together to attack the Philistines in the west. They will also attack the nations to the east of Israel. They will take their valuable things for themselves. They will win against the people of Edom and Moab. They will rule over the Ammonites."
    },
    {
      "verse": "15",
      "text": "The Lord will make the Sea of Egypt become dry. He will lift up his hand and he will send a strong wind to divide the Euphrates river. The river will become seven small streams. Then people can walk across it easily."
    },
    {
      "verse": "16",
      "text": "There will be a good road that comes from Assyria. The Lord's people who remain will travel back home on it. It will be like the road that Israel's people travelled on when they left Egypt."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "At that time, you will say, ‘I praise you, Lord. You were angry with me. But now, you are no longer angry. Now you have been kind to me. ‘I praise you, Lord. You were angry with me. But now, you are no longer angry. Now you have been kind to me."
    },
    {
      "verse": "2",
      "text": "Listen! God is the one who saves me! I will continue to trust him. I will not be afraid because the Lord himself makes me strong. He keeps me safe. He rescues us from our enemies. ’ I will continue to trust him. I will not be afraid because the Lord himself makes me strong. He keeps me safe. He rescues us from our enemies. ’"
    },
    {
      "verse": "3",
      "text": "When God does that, it will make you very happy. You will be safe, like someone who gets plenty of good water from a well to drink. You will be safe, like someone who gets plenty of good water from a well to drink."
    },
    {
      "verse": "4",
      "text": "At that time, you will say, ‘Praise the Lord! Thank him for his help! Tell all the nations about the great things that God has done. Tell them that he is very great! Thank him for his help! Tell all the nations about the great things that God has done. Tell them that he is very great!"
    },
    {
      "verse": "5",
      "text": "Sing songs to praise the Lord, because he has done wonderful things! Cause everyone in the world to know it! because he has done wonderful things! Cause everyone in the world to know it!"
    },
    {
      "verse": "6",
      "text": "Everyone who lives in Zion, shout aloud and sing with joy! The Holy God of Israel is great, and he lives among you. ’"
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "This is God's message about Babylon that he showed to Isaiah, the son of Amoz:"
    },
    {
      "verse": "2",
      "text": "Lift up a sign on an empty hill. Shout aloud for an army to attack! Wave your hand! Then they will go through the city gates into the rulers' palaces."
    },
    {
      "verse": "3",
      "text": "I, the Lord, have sent my special men. I am very angry. Those men are my brave soldiers who will punish Babylon on my behalf. They are proud because I have made them strong."
    },
    {
      "verse": "4",
      "text": "Listen to the loud noise of a big crowd on the mountains! It is the sound of large armies from many kingdoms as they march and shout. Nations are joining together to fight! The Lord Almighty is preparing an army ready for war."
    },
    {
      "verse": "5",
      "text": "People are coming from countries that are far away, from the ends of the earth. The Lord himself is coming with weapons for war, because he is angry. He will destroy the whole land."
    },
    {
      "verse": "6",
      "text": "Weep, because the day of the Lord is near. That is the time when God Almighty will destroy his enemies."
    },
    {
      "verse": "7",
      "text": "All the people will become weak with fear. They will no longer be brave."
    },
    {
      "verse": "8",
      "text": "They will be very afraid. Their bodies will hurt with great pain, like a woman who is giving birth. They will look at each other, as their faces show fear and pain."
    },
    {
      "verse": "9",
      "text": "Look! The day of the Lord will happen soon! It will be a cruel day. The Lord will punish his enemies with great anger. He will destroy the whole land, as well as all the sinners in it."
    },
    {
      "verse": "10",
      "text": "When he does that, the stars in the sky will give no light. When the sun rises in the morning, it will still be dark. The moon will no longer shine."
    },
    {
      "verse": "11",
      "text": "I, the Lord, will punish the world, because it is evil. I will punish wicked people for their sins. I will stop proud people from boasting. If strong people are cruel to others, I will bring them down low."
    },
    {
      "verse": "12",
      "text": "Very few people will remain after my punishment. Men and women will be more difficult to find than the best gold."
    },
    {
      "verse": "13",
      "text": "Then I will cause the sky to shake. The earth will move from its proper place. People will see how angry I am, when they see the great anger of the Lord Almighty."
    },
    {
      "verse": "14",
      "text": "Everyone will try to run away and escape. They will run anywhere, like a deer that runs away from a hunter. They will be like sheep with no shepherd to lead them. They will return to their own countries and homes."
    },
    {
      "verse": "15",
      "text": "The enemy soldiers will catch all those who do not escape. They will use their swords to kill everyone that they catch."
    },
    {
      "verse": "16",
      "text": "They will knock their children down in pieces while the parents watch. They will rob the people's homes. They will have sex with their wives."
    },
    {
      "verse": "17",
      "text": "Look! I will cause the Medes to come and attack Babylon. Their army has no interest in silver or gold, so nobody can pay them to stop."
    },
    {
      "verse": "18",
      "text": "Their arrows will kill Babylon's young men. They will not let babies or children go free."
    },
    {
      "verse": "19",
      "text": "Yes, God will destroy Babylon, as he did to Sodom and Gomorrah. Babylon has been a great and beautiful city. The people of the whole nation have been very proud of it. But God will still destroy it."
    },
    {
      "verse": "20",
      "text": "The people and their descendants will never live there again. No Arab will put his tent there. No shepherds will take their sheep there to rest."
    },
    {
      "verse": "21",
      "text": "Only wild animals will lie down there. Its old houses will be full of jackals. Ostriches will live there and wild goats will jump in it."
    },
    {
      "verse": "22",
      "text": "Wild dogs and hyenas will cry out in its towers and palaces. Enemies will soon destroy Babylon! Only a few days remain."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "The Lord will once again be kind to Jacob's descendants. He will choose to help the Israelite people again, as his own people. He will put them back in their land. Foreign people will join them and they will become a part of Jacob's family."
    },
    {
      "verse": "2",
      "text": "People of other nations will help Israel's people to return to their own country. When they are living again in the land that the Lord gave to them, foreign people will become their servants, both men and women. In that way, the people who made the Israelites prisoners will be prisoners themselves! The Israelites will rule over the people who had been cruel to them."
    },
    {
      "verse": "3",
      "text": "At that time, the Lord will let you live safely, without trouble and without pain. You will no longer have to work for cruel people, as their slaves."
    },
    {
      "verse": "4",
      "text": "Then you will laugh at the king of Babylon. You will say to him, ‘Now you cannot be cruel to us any more! Your power to cause trouble has finished!"
    },
    {
      "verse": "5",
      "text": "The Lord has destroyed the authority of wicked rulers like you."
    },
    {
      "verse": "6",
      "text": "You used your power to attack people all the time. In your anger, you ruled over other nations, and you never stopped being cruel to them."
    },
    {
      "verse": "7",
      "text": "But now there is peace in the whole world. People can live safely. Everyone is so happy that they are singing!"
    },
    {
      "verse": "8",
      "text": "Even the pine trees and the cedar trees in Lebanon are happy because your power has finished. They say to you, “Now God has knocked you down. So nobody will come again to cut us down! ”"
    },
    {
      "verse": "9",
      "text": "The deep hole of death below the earth is ready to receive you! People there want to meet you. The spirits of those who ruled on the earth have heard that you are coming. They are standing up from their thrones."
    },
    {
      "verse": "10",
      "text": "All of them will say to you, “Now you have become as weak as we are! You are weak like us! ”"
    },
    {
      "verse": "11",
      "text": "Your great power has now come down low, into the deep hole of death. People no longer praise you with their harps. Now you will lie on a bed of maggots. A blanket of worms will cover you."
    },
    {
      "verse": "12",
      "text": "Look at you! You have fallen from heaven! You shine like the bright morning star! You have won against many nations, but now you have come down very low! You shine like the bright morning star! You have won against many nations, but now you have come down very low!"
    },
    {
      "verse": "13",
      "text": "You said to yourself, “I will go up into heaven. I will put my throne above the stars of God. I will rule as king on the mountain in the far north, where the gods of the nations meet together. I will put my throne above the stars of God. I will rule as king on the mountain in the far north, where the gods of the nations meet together."
    },
    {
      "verse": "14",
      "text": "I will go up above the tops of the clouds. I will become like the Most High God. ” I will become like the Most High God. ”"
    },
    {
      "verse": "15",
      "text": "But instead of that, you have come down into the deep hole of death. You have fallen to the deepest place under the earth. You have fallen to the deepest place under the earth."
    },
    {
      "verse": "16",
      "text": "In that deep place, people will look at you carefully. They will be very surprised. They will think, “This is the man who caused the earth to shake. He caused kingdoms to shake with fear. Is that really true?"
    },
    {
      "verse": "17",
      "text": "Is this really the man who made the world become like a desert? He destroyed its cities. He did not let his prisoners go back to their homes. ”"
    },
    {
      "verse": "18",
      "text": "All the kings of all the nations lie down there, with all their valuable things. Each king lies in his own grave."
    },
    {
      "verse": "19",
      "text": "But as for you, Babylon's king, they have thrown you out! You have no grave! You are like a branch that has broken off. You lie among the dead bodies of soldiers that their enemies have killed with their swords. They have thrown your body into a big hole in the rocks, and they have walked over it."
    },
    {
      "verse": "20",
      "text": "They will not bury you with those other kings, because you destroyed your land and you killed your people. Nobody will ever remember the family of a wicked person like you."
    },
    {
      "verse": "21",
      "text": "Prepare to kill this king's children, because of the sins of their ancestors. Then his children will not rule the world. They will not build cities everywhere. ’"
    },
    {
      "verse": "22",
      "text": "This is what the Lord Almighty says, ‘I will attack Babylon and I will destroy it. I will leave nothing that people can remember. No people or their descendants will remain. ’"
    },
    {
      "verse": "23",
      "text": "The Lord Almighty says, ‘I will make Babylon a place where wild animals live. There will be pools of bad water. I will sweep everything away, like someone who sweeps dirt away with a brush. ’"
    },
    {
      "verse": "24",
      "text": "The Lord Almighty promises this: ‘It will happen exactly as I have decided. Yes, it will really happen like that."
    },
    {
      "verse": "25",
      "text": "I will destroy the Assyrians who are in my land. I will knock them down on my mountains. They will no longer be cruel to my people. My people will not be their slaves any more."
    },
    {
      "verse": "26",
      "text": "That is what I have decided for the whole earth. I am ready to show my power against all the nations. ’"
    },
    {
      "verse": "27",
      "text": "Yes, the Lord Almighty has decided what he will do. Nobody can change it. He is ready to show his power. Nobody can stop it."
    },
    {
      "verse": "28",
      "text": "In the year that King Ahaz died, God showed this message to Isaiah:"
    },
    {
      "verse": "29",
      "text": "Do not feel happy, you Philistine people. God has destroyed the king who was attacking you. That king hit you with a big stick, but a dangerous snake will follow! And that snake will give birth to an even more dangerous snake that moves very fast."
    },
    {
      "verse": "30",
      "text": "The Lord will give food to the poorest of his people. The weak and helpless people will live safely. But you Philistine people will die from famine. I will destroy you all, so that nobody remains."
    },
    {
      "verse": "31",
      "text": "Gate of the city, weep! City, cry out in pain! You Philistine people should be very afraid! See that cloud of smoke in the north! It is the dust of an army that is marching towards you. Their soldiers are ready to fight, and none of them is afraid."
    },
    {
      "verse": "32",
      "text": "When a foreign nation sends a message, what should we say? Say that the Lord has made Zion very strong. When his people have trouble, they will be safe there."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "This is a message about Moab: In one night an enemy has destroyed Ar. In one night they have destroyed Kir. Those towns in Moab are now a heap of stones! In one night an enemy has destroyed Ar. In one night they have destroyed Kir. Those towns in Moab are now a heap of stones!"
    },
    {
      "verse": "2",
      "text": "The people in Dibon have gone up to their temple to weep. They have gone up to the altars where they worship their gods. Moab's people are weeping because of what has happened at Nebo and Medeba. They are so upset that they have cut off their hair and their beards."
    },
    {
      "verse": "3",
      "text": "They are wearing rough sackcloth in the streets. On the roofs of their houses and in the open places in their towns, they are weeping. They fall to the ground as they weep."
    },
    {
      "verse": "4",
      "text": "The people in Heshbon and Elealeh cry aloud. People as far as Jahaz hear the sound of their voices! The soldiers of Moab cry aloud because they are afraid. They are shaking with fear."
    },
    {
      "verse": "5",
      "text": "I am very upset because of what is happening to Moab's people. They are running away, as far as Zoar and Eglath-Shelishiyah. They weep while they climb up the hill to Luhith. On the road to Horonaim they shout aloud, ‘An enemy has destroyed us! ’ They weep while they climb up the hill to Luhith. On the road to Horonaim they shout aloud, ‘An enemy has destroyed us! ’"
    },
    {
      "verse": "6",
      "text": "Streams in Nimrim valley have become dry. The grass has died. No green plants remain. The grass has died. No green plants remain."
    },
    {
      "verse": "7",
      "text": "So Moab's people are leaving. They are going across Willow stream. They are carrying away their thingsand the food that they had stored. They are going across Willow stream. They are carrying away their things and the food that they had stored."
    },
    {
      "verse": "8",
      "text": "Everywhere in Moab's country the people are calling out for help. The noise of their sad songs has reached Eglaim and Beer-Elim. The noise of their sad songs has reached Eglaim and Beer-Elim."
    },
    {
      "verse": "9",
      "text": "Blood fills the streams of Dimon. But I, the Lord, will cause even more trouble to happen there. A lion is ready to attack! Those who are trying to escape will die, as well as those who remain in the land."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "We must send sheep as gifts to the ruler of our land. Send them from Sela across the desert. Send them to Mount Zion in Jerusalem."
    },
    {
      "verse": "2",
      "text": "Moab's women are standing at the shore of Arnon river. They want to go across. They are like birds that people have chased out of their nests."
    },
    {
      "verse": "3",
      "text": "The Moabites say, ‘Tell us what we should do! Help us in our troubles! Give us some shade in the middle of the day! Hide the people who are escaping! Our enemies are chasing us. Do not let them find us."
    },
    {
      "verse": "4",
      "text": "Let us escape from Moab and come to live among you. Our enemy wants to destroy us. Please keep us safe! ’Yes, one day, the cruel enemy will have gone. He will no longer attack the land and destroy it."
    },
    {
      "verse": "5",
      "text": "One of David's descendants will rule as king. He will be true and honest. He will judge people in a fair way. He will quickly bring justice among his people."
    },
    {
      "verse": "6",
      "text": "The people of Judah say, ‘We know how proud Moab's people are. We have heard how they boast about themselves. They think that they can do anything that they want. But all their pride is empty and useless! ’"
    },
    {
      "verse": "7",
      "text": "Because of their troubles, Moab's people weep. They are all very upset. They are sad because there are no more sweet raisins from Kir-Hareseth!"
    },
    {
      "verse": "8",
      "text": "Yes, nothing grows in Heshbon's fields. There are no grapes on Sibmah's vines. The rulers of other nations have destroyed the vineyards. The branches of those vines reached as far as Jazer, and the desert. They even grew to go across the sea."
    },
    {
      "verse": "9",
      "text": "Because of that, I weep for the vines of Sibmah, as Jazer weeps. I pour out my tears all over you, Heshbon and Elealeh. Your people no longer sing because they are happy at harvest time. There is no more fruit on your trees or crops in your fields."
    },
    {
      "verse": "10",
      "text": "Nobody is happy in the fields. Nobody sings or shouts with joy in the vineyards. Nobody squeezes the grapes to make wine. I have caused all the happy noise to stop."
    },
    {
      "verse": "11",
      "text": "So I cry deep inside me for Moab. I cry like the sad music of a harp. I am very upset for Kir-Hareseth."
    },
    {
      "verse": "12",
      "text": "Moab's people go to their altars and temples to pray for help from their gods. But they will only become tired. Their prayers will be useless."
    },
    {
      "verse": "13",
      "text": "That is the message that the Lord has already spoken about Moab."
    },
    {
      "verse": "14",
      "text": "But now the Lord says, ‘In three years' time, all Moab's glory will have gone. Count every day of those years, as if you are working to receive money. After that, there will only be a few of Moab's people who are still alive. Now they are many and they are strong. But by then they will be few and weak. ’"
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "This is a message about Damascus:‘Look! Damascus is no longer a city! It has become a heap of stones. ‘Look! Damascus is no longer a city! It has become a heap of stones."
    },
    {
      "verse": "2",
      "text": "Nobody lives in the cities of Aroer. Sheep and goats can safely go there to eat. They can lie down there and nobody will chase them away. That is what the Lord Almighty says."
    },
    {
      "verse": "3",
      "text": "There will be no strong cities in Ephraim. No king will rule in Damascus. The few people who remain in Syria are no longer great, like Israel's people! ’That is what the Lord Almighty says."
    },
    {
      "verse": "4",
      "text": "‘At that time, Israel will no longer be great. It will be like a rich, fat person who becomes weak and hungry."
    },
    {
      "verse": "5",
      "text": "Israel will be like a field of grain in Rephaim valley after the harvest. The workers have cut down the crops. They have picked up the grain from the ground. That is what the Lord God of Israel says."
    },
    {
      "verse": "6",
      "text": "There will be only a few people that remain in Israel. They will be like a few olives that remain on a tree after the harvest. Perhaps two or three olives are still there on the highest branches. Four or five olives may remain on the other branches. ’That is what the Lord God of Israel says."
    },
    {
      "verse": "7",
      "text": "At that time, people will turn back to their Maker. They will trust the Holy God of Israel to help them."
    },
    {
      "verse": "8",
      "text": "They will no longer trust their idols to help them. They made altars for themselves, where they worshipped their gods. They worshipped Asherah at special poles. They made altars where they burned incense. But they will not do those things any more."
    },
    {
      "verse": "9",
      "text": "At that time, Israel's strong cities will be empty. People will run away from those cities, as the Amorites ran away from the hills when the Israelites attacked them. Israel's strong cities will become heaps of stones."
    },
    {
      "verse": "10",
      "text": "That will happen because you have forgotten the God who rescues you. He is the Rock where you can safely hide, but you have turned away from him. Instead, you plant the best plants and vines in your gardens. You buy them from foreign countries for a lot of money."
    },
    {
      "verse": "11",
      "text": "You take care of them so that they grow quickly. They may even make flowers on the same morning that you plant them! But you will never have any fruit from them. You will only get trouble and pain that will never go away."
    },
    {
      "verse": "12",
      "text": "It will be very bad for the armies of other nations! They are making a noise like the sea in a storm! They are as loud as powerful waves!"
    },
    {
      "verse": "13",
      "text": "But it does not matter how much noise they make. Those people may roar like powerful waves, but the Lord will shout at them to stop. Then they will run far away! They will run like the wind as it blows chaff across the hills. It will be like a strong storm that carries away dead weeds!"
    },
    {
      "verse": "14",
      "text": "Look at what happens! In the evening the enemy attacks, and we are very afraid. But by the morning they have disappeared! That is what happens to people who attack us. Anyone who tries to take away our valuable things for themselves will fail."
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "It will be very bad for that land beyond the rivers of Cush. Their ships seem to have wings and fly everywhere! Go now! Take a message quickly. Go to a country where the people are tall and their skin has no hair. Everyone is afraid of that nation's people. They are a powerful and strong nation. Many rivers cross their land."
    },
    {
      "verse": "2",
      "text": "They send messages over the sea in boats that they make from reeds. Their boats sail quickly on the water. Go now! Take a message quickly. Go to a country where the people are talland their skin has no hair. Everyone is afraid of that nation's people. They are a powerful and strong nation. Many rivers cross their land."
    },
    {
      "verse": "3",
      "text": "All you people who live in the world, listen to this! You will see a battle flag on the mountains. You will hear the sound of a trumpet."
    },
    {
      "verse": "4",
      "text": "This is what the Lord said to me: ‘I will watch quietly from my place. I will work quietly, like the heat that comes from the sun. I will be as quiet as the mist that comes at harvest time. ’"
    },
    {
      "verse": "5",
      "text": "Then, when the grapes on the vines are nearly ready for harvest, the Lord will cut them off! He will use his knife to cut off the branches."
    },
    {
      "verse": "6",
      "text": "Like those branches, the dead bodies of the soldiers will lie in the fields. The wild animals and the vultures will come to eat them. The vultures will feed on them all through the summer. The wild animals will eat them all through the winter."
    },
    {
      "verse": "7",
      "text": "At that time, the Lord Almighty will receive gifts from the people of that land. Many rivers cross that land. Its people are tall and their skin has no hair. Everyone is afraid of them. Their nation is strong and powerful. Those people will bring their gifts to Mount Zion. That is the place that the Lord Almighty has chosen for people to worship him there."
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "This is a message about Egypt. Look! The Lord is coming to Egypt! He is riding quickly on a cloud and he will soon arrive! The idols of Egypt will shake with fear when he comes. All the people in Egypt will be very afraid. Look! The Lord is coming to Egypt! He is riding quickly on a cloud and he will soon arrive! The idols of Egypt will shake with fear when he comes. All the people in Egypt will be very afraid."
    },
    {
      "verse": "2",
      "text": "‘I will cause Egypt's people to fight against each other. People will fight against their own family. They will fight against their neighbours. Cities and kingdoms will fight against each other. That is what the Lord, the Almighty Lord."
    },
    {
      "verse": "3",
      "text": "The Egyptians will become afraid, so that they do not know what to do. They will ask for help from their idols. They will ask the spirits of dead people to tell them what to do. They will ask magicians to talk to those spirits on their behalf."
    },
    {
      "verse": "4",
      "text": "I will cause a cruel master to have power over Egypt. A powerful king will rule over its people. ’That is what the Lord, the Almighty Lord."
    },
    {
      "verse": "5",
      "text": "The water of the sea will become dry. The Nile river will also become dry and it will have no water in it."
    },
    {
      "verse": "6",
      "text": "The streams will have a bad smell. All the streams and rivers will slowly become dry. The reeds and the river grasses will die."
    },
    {
      "verse": "7",
      "text": "The plants beside the river will die, as well as the crops in the fields along the shore. Everything will become dry and the wind will blow it all away."
    },
    {
      "verse": "8",
      "text": "The people who catch fish in the Nile river will be very sad. Yes, everyone who throws a hook into the river will cry. The people who throw nets into the river will not catch any fish."
    },
    {
      "verse": "9",
      "text": "The people who make linen cloth will not know what to do. There will be no flax for them to use."
    },
    {
      "verse": "10",
      "text": "They will be very upset. All the people who work to get money will be sad."
    },
    {
      "verse": "11",
      "text": "The royal officers in Zoan are fools! Pharaoh's wise leaders tell him to do stupid things! They should not boast to Pharaoh that they are wise. They should not say that they are descendants of wise kings from long ago."
    },
    {
      "verse": "12",
      "text": "Pharaoh, where have your wise men gone? Call them to come! Ask them to tell you what the Lord Almighty has decided to do against Egypt."
    },
    {
      "verse": "13",
      "text": "The officers in Zoan are fools. The officers in Memphis have confused each other. The leaders of Egypt's clans have led their people in the wrong direction."
    },
    {
      "verse": "14",
      "text": "The Lord has sent among the people in Egypt a spirit that confuses them. They go the wrong way in everything that they do. They are like drunk people who have been sick. They cannot walk in a straight line."
    },
    {
      "verse": "15",
      "text": "Nobody in Egypt will be able to do anything. They may be Egypt's head or its tail, a palm branch or a reed. There is nothing that anyone can do."
    },
    {
      "verse": "16",
      "text": "At that time, the Egyptians will be weak, like women. They will shake with fear because the Lord Almighty is ready to punish them."
    },
    {
      "verse": "17",
      "text": "The people of Judah will frighten the Egyptians very much. If anyone says Judah's name, everyone who hears it will be afraid. They will be very afraid of the punishment that the Lord Almighty will bring to them."
    },
    {
      "verse": "18",
      "text": "At that time, five cities in Egypt will speak the language of Canaan. The people in those cities will promise to obey the Lord Almighty. One of the cities will have the name ‘Sun City’."
    },
    {
      "verse": "19",
      "text": "At that time, there will be an altar in the middle of Egypt's land, where people will worship the Lord. There will also be a tall stone for the Lord at Egypt's border."
    },
    {
      "verse": "20",
      "text": "Those two things will be signs to tell everyone in Egypt about the Lord Almighty. Because of those signs, the Egyptians will remember that the Lord is powerful. When their enemies are cruel to them, they will call out to the Lord for help. Then he will send a strong saviour to rescue them."
    },
    {
      "verse": "21",
      "text": "The Lord will cause the Egyptians to know him. They will agree to serve him. They will worship the Lord with sacrifices and offerings. They will make promises to the Lord, and they will do what they have promised to do."
    },
    {
      "verse": "22",
      "text": "The Lord himself will punish the Egyptians. But after that, they will turn to the Lord. He will answer their prayers, and he will make them well again."
    },
    {
      "verse": "23",
      "text": "At that time, there will be a road from Egypt to Assyria. People from Assyria will travel to Egypt and Egyptians will travel to Assyria. Egyptians and Assyrians will worship together."
    },
    {
      "verse": "24",
      "text": "At that time, Israel will join Egypt and Assyria as a third important nation. They will bring blessing to the whole world."
    },
    {
      "verse": "25",
      "text": "The Lord Almighty will bless them all. He will say, ‘I will bless Egypt, who are now my people. I will bless Assyria, the people that I have made. And I will bless Israel, the people that I have chosen to belong to me. ’"
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "One year, Sargon, the king of Assyria, sent the leader of his army to attack Ashdod. His army fought against Ashdod and they took the city."
    },
    {
      "verse": "2",
      "text": "At that time, the Lord gave this message to Isaiah, the son of Amoz. He said, ‘Go and remove the rough clothes that you are wearing. Take your shoes off your feet. ’ Isaiah did what the Lord told him to do. He walked about without clothes and without shoes."
    },
    {
      "verse": "3",
      "text": "After three years, the Lord said, ‘My servant Isaiah has walked without clothes and without shoes for three years. That is a sign to warn Egypt and Cush about what will happen to them."
    },
    {
      "verse": "4",
      "text": "The king of Assyria will take away people from Egypt as prisoners. He will do the same thing to the people of Cush. Young people and old people will go as prisoners to Assyria. They will not wear any clothes or shoes. People will see their bare bodies. The Egyptians will be very ashamed."
    },
    {
      "verse": "5",
      "text": "Anyone who trusted that Cush or Egypt would be strong enough to save them will be ashamed. They will be afraid."
    },
    {
      "verse": "6",
      "text": "At that time, the people who live on this coast will say, “Look! This has happened to the people that we trusted to help us. We thought that they would rescue us from the king of Assyria. Now we will never escape from his power. ” ’"
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "This is a message about the desert near the sea. Trouble is coming from the desert, like a strong wind that blows from the south. It comes from a land of great fear. Trouble is coming from the desert, like a strong wind that blows from the south. It comes from a land of great fear."
    },
    {
      "verse": "2",
      "text": "The Lord showed me a vision of terrible things. ‘People are deceiving one another! People are destroying one another! Elam, go to attack Babylon! People from Media, attack all round the city! I will stop all the tears that Babylon's armies have caused. ’ ‘People are deceiving one another! People are destroying one another! Elam, go to attack Babylon! People from Media, attack all round the city! I will stop all the tears that Babylon's armies have caused. ’"
    },
    {
      "verse": "3",
      "text": "Because of that vision, I am very upset. Bad pains attack me, like the pains of a woman who is giving birth. My body hurts because of the things that I have heard. I am afraid to look!"
    },
    {
      "verse": "4",
      "text": "It confuses my mind. I shake with fear. I wanted a quiet evening, but instead there is terror."
    },
    {
      "verse": "5",
      "text": "Look! They are preparing a feast. They put down carpets for people to sit on. They are eating and they are drinking. Officers, stand up! Make your shields ready for battle!"
    },
    {
      "verse": "6",
      "text": "This is what the Lord God has said to me:‘Go! Put someone on the city wall to watch. Tell him to report what he sees. ‘Go! Put someone on the city wall to watch. Tell him to report what he sees."
    },
    {
      "verse": "7",
      "text": "If he sees chariots that two horses are pulling, or riders on donkeys, or riders on camels, he must watch very carefully. ’ or riders on donkeys, or riders on camels, he must watch very carefully. ’"
    },
    {
      "verse": "8",
      "text": "Then the guard shouted, ‘Lord God, I am standing every day on the tower where I watch. I stand at my place every night."
    },
    {
      "verse": "9",
      "text": "And look! Something is coming! It is a chariot that two horses are pulling! ’ The rider reports, ‘An enemy has completely destroyed Babylon! All the idols of its people's gods lie in pieces on the ground! ’"
    },
    {
      "verse": "10",
      "text": "Yes, my people, Babylon's army has hurt you very much. But now I have reported to you the message from the Lord Almighty, Israel's God."
    },
    {
      "verse": "11",
      "text": "This is a message about Dumah. Someone is shouting to me from Seir. They are asking, ‘Guard, how soon will the night finish? Please tell me. ’ Someone is shouting to me from Seir. They are asking, ‘Guard, how soon will the night finish? Please tell me. ’"
    },
    {
      "verse": "12",
      "text": "The guard replies, ‘The morning will come soon. But the night will quickly follow. If you want to ask again, then come back. Come and ask! ’"
    },
    {
      "verse": "13",
      "text": "This is a message about Arabia. Traders from Dedan, you put up your tents in Arabia's wilderness."
    },
    {
      "verse": "14",
      "text": "You must bring some water for the thirsty people to drink. You people who live in Tema, bring food to give to the hungry people who are running away from danger."
    },
    {
      "verse": "15",
      "text": "They are running away from the weapons of war. They are running from the swords, bows and arrows of a dangerous battle."
    },
    {
      "verse": "16",
      "text": "This is what the Lord God has said to me: ‘In one year's time, all Kedar's glory will have gone. Count every day, as if you are working to receive money. That is what the Lord, Israel's God, has said."
    },
    {
      "verse": "17",
      "text": "Only a few of Kedar's brave soldiers will remain, with their bows and arrows. ’That is what the Lord, Israel's God, has said."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "This is a message about the city that is called ‘Vision Valley’. What are you doing? You have all climbed up on the roofs of your houses! What are you doing? You have all climbed up on the roofs of your houses!"
    },
    {
      "verse": "2",
      "text": "Your city is full of the noise of parties, and people are shouting. It was not war that killed the people who are lying in your streets. They did not die in a battle."
    },
    {
      "verse": "3",
      "text": "When the enemy came, all your leaders ran far away. The enemy caught all your people. They caught them all and they did not need to shoot any arrows!"
    },
    {
      "verse": "4",
      "text": "So I say, ‘Leave me alone! Let me weep with many tears. The enemy has killed many of my people, so do not try to comfort me. ’"
    },
    {
      "verse": "5",
      "text": "The Lord, the Almighty Lord, has decided to bring great trouble to Vision Valley. It is a day of fear. People run here and there because they do not know what to do. The enemy knocks down the city's walls. People shout to the hills for help."
    },
    {
      "verse": "6",
      "text": "Elam's soldiers came with bows and arrows. They came with chariots and riders on horses. Kir's soldiers prepared their shields to fight."
    },
    {
      "verse": "7",
      "text": "So your beautiful valleys were full of chariots. Soldiers on horses prepared to attack your city's gates."
    },
    {
      "verse": "8",
      "text": "The enemy destroyed Judah's strong places where people could be safe. In that day, you looked for weapons in the House of the Forest."
    },
    {
      "verse": "9",
      "text": "You saw that there were many holes in the walls of the City of David. You stored water in the Lower Pool."
    },
    {
      "verse": "10",
      "text": "You counted the houses in Jerusalem and you knocked down some of them. You used the stones to make the city's wall stronger."
    },
    {
      "verse": "11",
      "text": "You built a place between the city's walls to store water from the Old Pool. But you did not trust the One who made the city. You did not think about the One who decided to build it a long time ago."
    },
    {
      "verse": "12",
      "text": "At that time, the Lord Almighty told you to be very sad and weep. He told you to cut all the hair off your heads and to wear rough clothes."
    },
    {
      "verse": "13",
      "text": "But instead, you are happy and you dance! You kill cows and sheep for a feast! You eat lots of meat and you drink lots of wine. You say, ‘We will have a big feast today, because tomorrow we will be dead! ’"
    },
    {
      "verse": "14",
      "text": "But the Lord Almighty has told me this: ‘I will never forgive this sin of my people for as long as they live. ’That is what the Lord, the Almighty Lord has said. That is what the Lord, the Almighty Lord has said."
    },
    {
      "verse": "15",
      "text": "This is what the Lord Almighty says: ‘Now go and speak to Shebna, the officer with authority in the king's palace."
    },
    {
      "verse": "16",
      "text": "Say to him, “You should not be here in the palace. You have cut a grave in the rock here for yourself, but you do not have the authority to do that! You have made a beautiful grave high up on the hill, as if you belong with the kings."
    },
    {
      "verse": "17",
      "text": "But look! The Lord will catch you and he will throw you out! You are just a man. He will take hold of you with all his strength."
    },
    {
      "verse": "18",
      "text": "He will hold you in his hand like a ball and he will throw you far away. You will die in that large, open country. Your great chariots will be useless there with you. You have brought shame to your master's family. ”"
    },
    {
      "verse": "19",
      "text": "I will remove you from your job. You will no longer be an important officer in the palace."
    },
    {
      "verse": "20",
      "text": "At that time, I will call my servant Eliakim, the son of Hilkiah, to come."
    },
    {
      "verse": "21",
      "text": "I will put on him your special clothes. I will tie your belt round him. I will give your authority to him. Then Eliakim will become like a father to the people in Jerusalem and the people in Judah."
    },
    {
      "verse": "22",
      "text": "I will give the key of David's royal family to him. He will have complete authority. Any door that he opens, nobody may close it. Any door that he closes, nobody may open it."
    },
    {
      "verse": "23",
      "text": "I will fix him strongly in his place, like a peg in a strong wall. Because of him, people will respect and praise his father's family."
    },
    {
      "verse": "24",
      "text": "His children and his family will become more important because of him. They will be like bowls, cups and jars that hang on him as the strong peg. ’"
    },
    {
      "verse": "25",
      "text": "The Lord Almighty says, ‘When the time comes, the strong peg will fall out of the wall. I will cut it down and it will fall. Then all the things that hang on it will fall down as well. ’That is what the Lord has said."
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "This is a message about Tyre. Weep aloud, you people in the great ships of Tarshish. An enemy has destroyed the port and the houses of Tyre. They heard this news in Cyprus. Weep aloud, you people in the great ships of Tarshish. An enemy has destroyed the port and the houses of Tyre. They heard this news in Cyprus."
    },
    {
      "verse": "2",
      "text": "Weep quietly, you people who live on the coast of the sea. Yes, weep, you traders of Sidon city. Your sailors travelled across the sea and you became rich."
    },
    {
      "verse": "3",
      "text": "They brought grain to you from Shihor region in Egypt. You received crops that had grown beside the Nile river. Tyre became an important city where traders from many nations came."
    },
    {
      "verse": "4",
      "text": "Be ashamed, you people in Sidon. You have become strong because of the sea. But the sea now speaks against you! It says, ‘I have not given birth to any children. I have not taken care of any sons or daughters as a parent should do. ’"
    },
    {
      "verse": "5",
      "text": "When the people in Egypt hear the news about Tyre, they will be very sad and upset."
    },
    {
      "verse": "6",
      "text": "Travel to Tarshish! Weep aloud, you people who live on the coast of the sea."
    },
    {
      "verse": "7",
      "text": "Tyre is a city where you had many parties. It has been there since long ago. People from this city went to live in foreign countries far away."
    },
    {
      "verse": "8",
      "text": "It is a royal city and its traders are princes. They are famous everywhere on earth. So who decided to destroy it?"
    },
    {
      "verse": "9",
      "text": "The Lord Almighty did that! He decided to show that the pride of those people is useless. He decided to bring all those famous people down low."
    },
    {
      "verse": "10",
      "text": "People of Tarshish, now you will have to grow your own crops. Grow them like they do beside the Nile river. Traders no longer come to Tyre to sell their things."
    },
    {
      "verse": "11",
      "text": "The Lord has lifted his hand up over the sea. He has made kingdoms shake with fear. He has given his command against Canaan, to destroy all its strong places."
    },
    {
      "verse": "12",
      "text": "He says to Sidon's people, ‘Your parties have finished! Now it will be a time of pain for you. Move away, if you can! Travel to Cyprus. But you will still not be safe there. ’"
    },
    {
      "verse": "13",
      "text": "Look at what happened in Babylonia. Its people have disappeared! The Assyrian army has made it a place for wild animals to live in. Their soldiers built hills of earth against the city's walls. They climbed over and they destroyed its strong buildings. Babylon's buildings became heaps of stones."
    },
    {
      "verse": "14",
      "text": "So weep aloud, you great ships of Tarshish. Enemies have destroyed your strong place."
    },
    {
      "verse": "15",
      "text": "years. That is how long one king lives. At the end of 70 years, there will be a change in Tyre. It will happen to them like the song about the prostitute:"
    },
    {
      "verse": "16",
      "text": "‘Prostitute that people have forgotten, walk about the city with your harp. Play it well. Sing many songs. Then people will remember you again. ’ walk about the city with your harp. Play it well. Sing many songs. Then people will remember you again. ’"
    },
    {
      "verse": "17",
      "text": "years, the Lord will be kind to Tyre. People from all the nations of the world will come to Tyre to buy things. Tyre will receive their money, like the prostitute in the song."
    },
    {
      "verse": "18",
      "text": "But the money that Tyre receives will belong to the Lord. Tyre's traders will not hide their riches or store them. Their money will buy plenty of food and beautiful clothes for people who worship the Lord."
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "Understand this! The Lord is ready to destroy the earth. It will become a desert. He will spoil the ground. He will chase away all the people who live on it."
    },
    {
      "verse": "2",
      "text": "It will be the same for all people: priests as well as ordinary people, masters as well as their servants, rich ladies as well as their servant girls, sellers as well as buyers, people who lend money as well as those who borrow it, rich people as well as poor people."
    },
    {
      "verse": "3",
      "text": "The whole earth will become empty. Nothing will remain. The Lord has said that this punishment will certainly happen."
    },
    {
      "verse": "4",
      "text": "The earth becomes dry and all the plants die. The whole world becomes weak and helpless. Its important people also become weak."
    },
    {
      "verse": "5",
      "text": "The people who live on the earth have caused it to become unclean. They have not obeyed God's laws. They have turned against his teaching. They have not obeyed the covenant that God made with them for ever. They have not obeyed God's laws. They have turned against his teaching. They have not obeyed the covenant that God made with them for ever."
    },
    {
      "verse": "6",
      "text": "That is why a curse is destroying the land. The people who live on it are guilty and God is punishing them. They become fewer and fewer. Only a very few of them remain."
    },
    {
      "verse": "7",
      "text": "There is no new wine and the vines are dying. The people who were happy to drink the wine are now sad."
    },
    {
      "verse": "8",
      "text": "The happy sound of tambourines has stopped. The noise from parties has finished. The harps no longer make any happy music."
    },
    {
      "verse": "9",
      "text": "People cannot drink wine, so they do not sing. When people drink beer, it seems bitter."
    },
    {
      "verse": "10",
      "text": "The city has become so spoiled that it is useless. People have locked their houses so that nobody can go in."
    },
    {
      "verse": "11",
      "text": "They shout in the streets because they have no wine. Nobody is happy any more, anywhere on the earth."
    },
    {
      "verse": "12",
      "text": "The city has become a heap of stones. Its gates lie in pieces on the ground."
    },
    {
      "verse": "13",
      "text": "This is what will happen among all the nations on the earth. Only a few people will remain, like a few olives that remain on a tree after the harvest. After people have picked the grapes off a vine, there are only a few that remain."
    },
    {
      "verse": "14",
      "text": "Those people who are still alive sing aloud because they are happy. People who live in the west praise the Lord because he is great. But I say, ‘I have become very weak and thin! It will be very bad for me! Evil people are turning against their friends. They deceive people more and more! ’"
    },
    {
      "verse": "15",
      "text": "So people who live in the east should praise the Lord too. People who live on the coast of the sea will also praise the name of the Lord, Israel's God."
    },
    {
      "verse": "16",
      "text": "From every part of the earth, we hear songs. People sing to praise the Righteous One. But I say, ‘I have become very weak and thin! It will be very bad for me! Evil people are turning against their friends. They deceive people more and more! ’"
    },
    {
      "verse": "17",
      "text": "People everywhere on the earth, terror is ready to catch you! You will fall into a deep hole, and a trap will catch you!"
    },
    {
      "verse": "18",
      "text": "Anyone who runs away from the sound of the terror will fall into the deep hole. The trap will catch anyone who climbs out of the big hole. God has opened the windows of the sky. He has caused the foundations of the earth to shake."
    },
    {
      "verse": "19",
      "text": "The earth has become broken into many pieces. It has torn apart. It is shaking powerfully."
    },
    {
      "verse": "20",
      "text": "The earth is like a drunk man. It cannot walk in a straight line. It moves in all directions, like a tent in a storm. The people's sins are like a heavy weight on the earth. It cannot carry them and it will fall. It will never be able to get up again."
    },
    {
      "verse": "21",
      "text": "At that time, the Lord will punish the powerful beings in the skies above. He will punish the kings who rule on the earth below."
    },
    {
      "verse": "22",
      "text": "He will bring them together like prisoners in a deep hole. That will be their prison. They will be there for a time, and then he will come to punish them."
    },
    {
      "verse": "23",
      "text": "The moon will hide its face in shame. The bright light of the sun will become dark. Yes, the Lord Almighty will become king on Mount Zion. He will rule with great power in Jerusalem. The leaders of the people will see his great glory."
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "Lord, you are my God! I will praise youbecause your name is great. You have done wonderful things. You decided a long time ago what you would do. And you have done exactly what you promised to do. I will praise you because your name is great. You have done wonderful things. You decided a long time ago what you would do. And you have done exactly what you promised to do."
    },
    {
      "verse": "2",
      "text": "You have destroyed citiesso that they become a heap of stones. You have destroyed the strongest cities. The beautiful palaces in foreign lands have disappeared. Nobody will build them again. so that they become a heap of stones. You have destroyed the strongest cities. The beautiful palaces in foreign lands have disappeared. Nobody will build them again."
    },
    {
      "verse": "3",
      "text": "So people of strong nations will praise you. The people of cruel nations will be afraid of you. The people of cruel nations will be afraid of you."
    },
    {
      "verse": "4",
      "text": "You Lord have been a safe place for poor people. When helpless people were in trouble, you have kept them safe. You were a place for them to hide from the storm. You gave them shade from the heat. Yes, cruel people attack themlike a storm that hits against a wall. When helpless people were in trouble, you have kept them safe. You were a place for them to hide from the storm. You gave them shade from the heat. Yes, cruel people attack them like a storm that hits against a wall."
    },
    {
      "verse": "5",
      "text": "and like strong heat in the desert. You Lord stopped the proud noise of foreign people. Like the shadow of a cloud that stops the heat of the sun, you stopped our cruel enemy's songs. You stopped them as they boasted of their strength. You Lord stopped the proud noise of foreign people. Like the shadow of a cloud that stops the heat of the sun, you stopped our cruel enemy's songs. You stopped them as they boasted of their strength."
    },
    {
      "verse": "6",
      "text": "The Lord Almighty will prepare a feast on this mountain. It will be a feast for all the nations of the world. It will be a great feast, with plenty of meat and wine. The best meat and the best wine will be there. It will be a feast for all the nations of the world. It will be a great feast, with plenty of meat and wine. The best meat and the best wine will be there."
    },
    {
      "verse": "7",
      "text": "On this mountain the Lord will take away the thingsthat make all people sad. He will remove the cloththat covers the people of all nations. that make all people sad. He will remove the cloth that covers the people of all nations."
    },
    {
      "verse": "8",
      "text": "The Almighty Lord will destroy death for ever. He will clean away the tears in everyone's eyes. His people will not feel ashamed any more. Nobody in all the world will ever insult them again. That is what the Lord has said. He will clean away the tears in everyone's eyes. His people will not feel ashamed any more. Nobody in all the world will ever insult them again. That is what the Lord has said."
    },
    {
      "verse": "9",
      "text": "At that time, people will say, ‘Look! This is our God! We trusted him to keep us safe, and he rescued us. Yes, this is the Lord! We trusted him to keep us safe. We will sing with joy, because he has saved us. ’ ‘Look! This is our God! We trusted him to keep us safe, and he rescued us. Yes, this is the Lord! We trusted him to keep us safe. We will sing with joy, because he has saved us. ’"
    },
    {
      "verse": "10",
      "text": "The Lord's power will bless this mountain. He will knock down Moab's peopleand he will walk all over them. He will walk on them, as if they are straw in a heap of dung. He will knock down Moab's people and he will walk all over them. He will walk on them, as if they are straw in a heap of dung."
    },
    {
      "verse": "11",
      "text": "Moab's people will try to escape from that punishment. They will push with their hands as they try to swim out! But the Lord will make their proud strength useless, whatever they do to escape. They will push with their hands as they try to swim out! But the Lord will make their proud strength useless, whatever they do to escape."
    },
    {
      "verse": "12",
      "text": "He will knock down the high walls of Moab's city. He will completely destroy their strong place. It will all fall down into the dust on the ground."
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "At that time, people will sing this song in Judah: We have a strong city, where we are safe. The Lord has made it safe, like strong walls that protect us all round. We have a strong city, where we are safe. The Lord has made it safe, like strong walls that protect us all round."
    },
    {
      "verse": "2",
      "text": "Open the gates of the city, so that the righteous nation can come in. They are the people who continue to be faithful. so that the righteous nation can come in. They are the people who continue to be faithful."
    },
    {
      "verse": "3",
      "text": "Lord, you keep those people safewho continue to trust in you. You give them peace in their minds, because they believe in you. who continue to trust in you. You give them peace in their minds, because they believe in you."
    },
    {
      "verse": "4",
      "text": "Trust in the Lord now and for ever! The Almighty Lord will always be our strong Rock. The Almighty Lord will always be our strong Rock."
    },
    {
      "verse": "5",
      "text": "He brings down low the proud people who live in high places. He destroys their cities. He knocks down their citiesso that they fall to the ground and become dust. He destroys their cities. He knocks down their cities so that they fall to the ground and become dust."
    },
    {
      "verse": "6",
      "text": "The poor people and the helpless peoplewill walk all over it. will walk all over it."
    },
    {
      "verse": "7",
      "text": "Righteous people walk on a path that is flat. You make their path straight, Lord."
    },
    {
      "verse": "8",
      "text": "Yes, Lord, as we follow the path of your justice, we wait for you to help us. We really want people to know that you are great. We want them to praise your name."
    },
    {
      "verse": "9",
      "text": "During the night, I think about you a lot. When morning arrives, I want to be near to you in my spirit. When you come to judge people on the earth, then people will understand your justice."
    },
    {
      "verse": "10",
      "text": "If you are kind to wicked people, they will never learn to do what is right. They continue to do wrong things, even in a land where people are honest. They do not see that you are great, Lord."
    },
    {
      "verse": "11",
      "text": "Lord, you are ready to punish them, but they do not realize that. Make them see that you love your own people. Then they will become ashamed. In your anger, punish them with fire, as your enemies deserve."
    },
    {
      "verse": "12",
      "text": "Lord, you will give us peace. Everything that we have done, you have done on our behalf."
    },
    {
      "verse": "13",
      "text": "Lord, our God, other lords have ruled over us. But you are the only one that we worship."
    },
    {
      "verse": "14",
      "text": "Those other lords are dead. They will not live again. Their spirits will not rise up again. You punished them and you destroyed them. Nobody remembers them any more."
    },
    {
      "verse": "15",
      "text": "Lord, you have made our nation larger. You have made our nation larger and you have shown how great you are. You have made all the borders of our land grow bigger."
    },
    {
      "verse": "16",
      "text": "Lord, when your people had trouble, they came to you for help. When you punished them, they turned to you and they prayed."
    },
    {
      "verse": "17",
      "text": "Because of your punishment, Lord, we had much pain. We were like a woman who is giving birth and she cries out with pain."
    },
    {
      "verse": "18",
      "text": "Yes, it seemed like we were pregnant and ready to give birth. But we could only give birth to wind! We could not do anything to make the land safe. We have no descendants who will bring new life to the world."
    },
    {
      "verse": "19",
      "text": "But Lord, your people who have died will live again. Their bodies will rise up from their graves. You people who live in the ground, wake up! Shout because you are happy. You bring new life to the earth, like dew that comes in the morning. Dead people will come up from the earth and they will live again."
    },
    {
      "verse": "20",
      "text": "My people, go into your homes. Shut the doors and hide yourselves for a short time. Wait there until the Lord is not angry any more."
    },
    {
      "verse": "21",
      "text": "Look! Now the Lord is coming from the place where he lives. He is coming to punish the people who live on the earth for their sins. The earth will clearly show the blood that murderers poured out on it. Murderers will no longer be able to hide the people that they have killed."
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "At that time, the Lord will punish Leviathan. The Lord will use his great and powerful sword to destroy that monster. Leviathan is a snake that moves very fast in the sea and it turns in every direction. But the Lord will kill it."
    },
    {
      "verse": "2",
      "text": "At that time, sing a song about a beautiful vineyard!"
    },
    {
      "verse": "3",
      "text": "I, the Lord, keep it safe. I will continue to put water on it. I will guard it night and day, so that nobody can hurt it."
    },
    {
      "verse": "4",
      "text": "I am not angry now. If there were thorn bushes or weeds in my vineyard, I would attack them. I would burn them all."
    },
    {
      "verse": "5",
      "text": "But my enemies should turn to me for help. They should agree to live in peace with me. Yes, that is what they should do."
    },
    {
      "verse": "6",
      "text": "The time will come when Jacob will grow well, like a strong plant in the ground. Yes, Israel will make flowers and branches. Their fruit will fill all the world."
    },
    {
      "verse": "7",
      "text": "The Lord did not punish Israel's people as much as he punished their enemies. He did not kill them as much as he killed their enemies."
    },
    {
      "verse": "8",
      "text": "But Lord you sent your people to a land far away. That is how you punished them. You blew them away with a storm that came from the east."
    },
    {
      "verse": "9",
      "text": "In that way the Lord punished Jacob's descendants for their sins. They are no longer guilty. This will be the result when God has taken away Jacob's sin completely: All the stones in their altars will become small pieces of chalk. There will be no Asherah pole or altars for incense that continue to stand."
    },
    {
      "verse": "10",
      "text": "The strong city will become empty. Nobody will live there any more. It will be like an empty desert. Young cows will eat the grass there, and they will lie down there. They will eat all the leaves on the branches of the tree."
    },
    {
      "verse": "11",
      "text": "When the branches become dry, they break off the tree. Women will take the sticks and they will make fires with them. That is what these people are like. They do not understand anything. So their Maker will not help them or be kind to them."
    },
    {
      "verse": "12",
      "text": "At that time, the Lord will shake the tree! He will do that to his people everywhere from the River Euphrates to the Stream of Egypt. Then he will bring together all of you, one by one, you Israelite people."
    },
    {
      "verse": "13",
      "text": "At that time, they will hear the sound of a loud trumpet. Then people who were dying in exile in Assyria will come. People who went away into Egypt will also come. They will worship the Lord on his holy hill in Jerusalem."
    }
  ],
  "28": [
    {
      "verse": "1",
      "text": "It will be very bad for Ephraim's beautiful city, Samaria! The people who live there drink too much wine and they become drunk. They are proud of their great city. It is on a hill above a valley where many good things grow. It is like a beautiful flower, but it will be beautiful no more and it will die."
    },
    {
      "verse": "2",
      "text": "Look! The Lord God is sending a strong and powerful army to attack it. It comes like a strong storm of ice. Its wind destroys everything. It is like rain that pours down and causes a flood. He will knock down Ephraim's great city to the ground with his great power!"
    },
    {
      "verse": "3",
      "text": "The drunk people of Samaria think that their city is great. But their enemies will knock it down and walk all over it."
    },
    {
      "verse": "4",
      "text": "The city is like a beautiful flower that will soon die. It is on a hill above a valley where many good things grow. But it will be like a fig on a tree. It is ready to eat before the harvest time. When someone sees it, he will quickly pick it. And he will eat it!"
    },
    {
      "verse": "5",
      "text": "At that time. the Lord Almighty will be a great leader of his people. He will be like a beautiful crown for his people who still remain alive."
    },
    {
      "verse": "6",
      "text": "He will help judges to decide what is right. He will give strength to the people who keep the city safe from those who attack it."
    },
    {
      "verse": "7",
      "text": "But now wine causes the leaders in Ephraim to become drunk. They cannot walk in a straight line because they drink too much beer. Beer causes the priests and the prophets to fall over. Wine confuses their minds. When they see visions, they cannot understand them. When they judge people, they cannot decide what is right."
    },
    {
      "verse": "8",
      "text": "They are sick over all their tables. Everywhere is covered with dirt."
    },
    {
      "verse": "9",
      "text": "They say, ‘Why does the Lord try to teach us like that? Who does he think that we are? He speaks to us as if we are babies! He thinks that we have just left our mother's breast!"
    },
    {
      "verse": "10",
      "text": "He teaches us one rule at a time, one line at a time. He says it several times, a little bit here, a little bit there. ’"
    },
    {
      "verse": "11",
      "text": "So now the Lord will use foreign enemies to speak to these people. He will speak to them in a strange language."
    },
    {
      "verse": "12",
      "text": "In the past, he said to them, ‘This is a place where you can rest when you are tired. It is a place where you can be safe. ’ But his people refused to listen."
    },
    {
      "verse": "13",
      "text": "So the Lord's message will seem to them like, ‘One rule at a time, one line at a time, a little bit here, a little bit there. ’ So as they try to move forward, they will fall over. An enemy will hurt them, and he will catch them in a trap."
    },
    {
      "verse": "14",
      "text": "So listen to the Lord's message, you leaders in Jerusalem who rule these people. Do not laugh at what the Lord is doing."
    },
    {
      "verse": "15",
      "text": "You boast, ‘We have made a covenant with death. Yes, we have made an agreement with Sheol. When trouble comes to our city like a deep flood of water, we will be safe. We trust in our lies to keep us safe. ’"
    },
    {
      "verse": "16",
      "text": "So the Almighty Lord says this:‘Look! I am putting a special stone in Zion. It is a valuable stone, because it makes a strong foundation at the corner of my building. Anyone who trusts in that foundation will never be disappointed. ‘Look! I am putting a special stone in Zion. It is a valuable stone, because it makes a strong foundation at the corner of my building. Anyone who trusts in that foundation will never be disappointed."
    },
    {
      "verse": "17",
      "text": "Justice and righteousness will make that foundation strong and true. But if you trust in lies, a storm of ice will destroy your safe place. A flood of water will destroy the place where you are hiding."
    },
    {
      "verse": "18",
      "text": "I will stop your covenant with death. Your agreement with Sheol will not continue. When trouble comes like a deep flood of water, it will drown you."
    },
    {
      "verse": "19",
      "text": "A flood of punishment will come again and again, and it will carry you away. It will come every morning, and all through the day and the night. ’When you understand this message from the Lord, you will be very afraid."
    },
    {
      "verse": "20",
      "text": "You will not be able to rest, like a tall person who tries to sleep on a short bed. Your blanket will not cover your whole body."
    },
    {
      "verse": "21",
      "text": "But the Lord will do a great thing, like he did at Mount Perazim. He will be very angry, as he was in the Gibeon Valley. He will do something that is very wonderful and strange."
    },
    {
      "verse": "22",
      "text": "So do not laugh at me when I warn you. If you do not listen, your punishment will become even worse. The Lord Almighty has told me what he has decided. He has decided to destroy the whole land."
    },
    {
      "verse": "23",
      "text": "So listen carefully to my message. Hear what I am saying!"
    },
    {
      "verse": "24",
      "text": "A farmer ploughs the ground because he wants to plant seeds in it. He does not continue to plough for ever."
    },
    {
      "verse": "25",
      "text": "When he has prepared the ground, he plants many different seeds. He plants dill and cummin. He plants wheat, barley and different grains in their proper places."
    },
    {
      "verse": "26",
      "text": "God teaches the farmer and he tells him the right thing to do."
    },
    {
      "verse": "27",
      "text": "After the harvest, the farmer knows how to remove seeds from dill or from cummin. He will not pull a heavy iron weight over dill. He will not run the wheels of a cart over cummin. Instead, he will hit them with a light stick."
    },
    {
      "verse": "28",
      "text": "When he crushes grain to make flour for bread, he does not do it for a long time. He drives the wheels of his cart over the grain, but he does not let his horses crush it."
    },
    {
      "verse": "29",
      "text": "The Lord Almighty causes farmers to know all that. His ideas are very wise, and he shows us how to live in a wise way."
    }
  ],
  "29": [
    {
      "verse": "1",
      "text": "It will be very bad for Ariel, the city where David lived. Continue to have your usual feasts every year, but trouble will come!"
    },
    {
      "verse": "2",
      "text": "I will bring trouble to Ariel. The people there will be very sad and they will weep. Ariel will become like my altar for burnt offerings."
    },
    {
      "verse": "3",
      "text": "I will bring an army to attack you. There will be soldiers all round the city so that nobody can leave. I will build strong towers against the city's walls."
    },
    {
      "verse": "4",
      "text": "Then you will fall down to the ground. While you lie there, you will speak. Your words will come quietly from deep down in the dirt. It will seem like the voice of a dead person's spirit. You will sound like a magician who is speaking magic words."
    },
    {
      "verse": "5",
      "text": "Your enemies will be like an army of dust. The wind will blow away that crowd of cruel men as if they are chaff. That will all happen very suddenly!"
    },
    {
      "verse": "6",
      "text": "The Lord Almighty will come with great power. He will come with thunder, earthquake and a loud noise. There will be a great storm with strong winds and a fire that burns up everything."
    },
    {
      "verse": "7",
      "text": "The great crowd of armies from all the nations that attack Ariel will quickly disappear. They will soon come to an end, like a dream that someone sees in the night. All the weapons that they bring to attack the city's walls will disappear!"
    },
    {
      "verse": "8",
      "text": "A hungry man may dream that he is eating a big meal. But as soon as he wakes up, he knows that he is still hungry! A thirsty man may dream that he is drinking. But as soon as he wakes up, he knows that he is still weak and thirsty. That is what it will be like for the great armies from all the nations that have come to attack Mount Zion."
    },
    {
      "verse": "9",
      "text": "You are so surprised that you do not believe what I say. You have become completely blind. You are stupid, like people who are drunk, but not from wine! You fall over, but not because you have drunk too much beer!"
    },
    {
      "verse": "10",
      "text": "It is the Lord who has caused you to be like that. He has caused you to be completely asleep. He has shut the eyes of your prophets and he has covered the heads of your seers."
    },
    {
      "verse": "11",
      "text": "You do not understand this vision that the Lord has given to me. It is like the words in a closed book. Give the book to someone who can read. Say to him, ‘Read this, please. ’ But he will answer, ‘I cannot read it, because someone has closed it. ’"
    },
    {
      "verse": "12",
      "text": "Give the book to someone who cannot read and tell them, ‘Read it, please. ’ But he will answer, ‘I do not know how to read. ’"
    },
    {
      "verse": "13",
      "text": "The Lord God says, ‘These people open their mouths to worship me. They use their lips to say that I am great. But they are not really thinking about me. When they worship me, they use rules that people have taught them."
    },
    {
      "verse": "14",
      "text": "So now I will surprise these people again. I will surprise them with great miracles! Wise people will not seem wise any more. Clever people will no longer seem to be clever. ’"
    },
    {
      "verse": "15",
      "text": "It will be very bad for people who try to deceive the Lord. They try to hide their thoughts from him. They secretly decide to do evil things. They boast and they say, ‘Nobody can see us. Nobody knows what we are doing. ’"
    },
    {
      "verse": "16",
      "text": "Your minds are really confused! You think that the clay is more important than the person who uses it to make pots! A bowl cannot say to its maker, ‘You did not make me! ’ A pot cannot say to the potter, ‘You do not know what you are doing! ’"
    },
    {
      "verse": "17",
      "text": "Very soon, Lebanon's forest will become a field of fruit trees. And the field of fruit trees will seem like a forest."
    },
    {
      "verse": "18",
      "text": "At that time, deaf people will be able to hear when someone is reading words from a book. Blind people who have been living in a dark place will be able see what is happening."
    },
    {
      "verse": "19",
      "text": "And the Lord will make weak people happy again. Poor people will sing with joy, because of what the Holy God of Israel has done."
    },
    {
      "verse": "20",
      "text": "Cruel people will disappear. Proud people who insult others will no longer be there. There will be no more people who love to do evil things."
    },
    {
      "verse": "21",
      "text": "It will be the same for people who tell lies in court. They deceive the judge at the city gate. They say false things against good people to make them guilty. People who are like that will have gone!"
    },
    {
      "verse": "22",
      "text": "So this is what the Lord says to Jacob's descendants. He is the one who rescued Abraham. He says, ‘Jacob's descendants will no longer be ashamed. Their faces will show their shame no more."
    },
    {
      "verse": "23",
      "text": "They will see that I have blessed them so that they have many children. Then they will agree that I am great. They will praise me, the Holy God of Jacob. They will respect me, Israel's God."
    },
    {
      "verse": "24",
      "text": "At that time, people with minds that are confused will understand what is right. And people who like to complain will accept my teaching. ’"
    }
  ],
  "30": [
    {
      "verse": "1",
      "text": "The Lord says, ‘It will be very bad for you, my children who have turned against me. You have decided what to do, but you did not ask me about it. You have made an agreement with Egypt, but without my Spirit's help. In that way, you continue to do more and more sins."
    },
    {
      "verse": "2",
      "text": "Your leaders travel to Egypt to ask for Pharaoh's help to keep them safe. But they did not ask me what I think about it. They think that Egypt has the power to protect them."
    },
    {
      "verse": "3",
      "text": "But Pharaoh's help will only make you ashamed. If you trust in Egypt's power, that will bring you down low."
    },
    {
      "verse": "4",
      "text": "Judah's officers have arrived in Zoan, and some of them have gone to Hanes."
    },
    {
      "verse": "5",
      "text": "But the people of Egypt will not be able to help you. So everyone in Judah will become ashamed. If you trust in Egypt, they will give you shame instead of help. ’"
    },
    {
      "verse": "6",
      "text": "Here is a message about the animals that travel in the Negev desert: It is a place where there is trouble and danger. There are dangerous lions there, both male and female. There are different kinds of dangerous snakes. People are carrying their valuable things on the backs of donkeys and camels. They are taking their riches as gifts to a nation that cannot help them!"
    },
    {
      "verse": "7",
      "text": "Help from Egypt is useless! So I call Egypt ‘Rahab who does nothing. ’"
    },
    {
      "verse": "8",
      "text": "Go and write this message down for them to see. Yes, write it in a book so that it will always be there to read. In the future, it will always show what is true."
    },
    {
      "verse": "9",
      "text": "These people have turned against the Lord. They are his children but they love to tell lies. They do not want to obey his law."
    },
    {
      "verse": "10",
      "text": "They say to the seers, ‘Do not see any more visions! ’ They say to the prophets, ‘Do not tell us messages about what is right! Tell us nice things, even if they are not true."
    },
    {
      "verse": "11",
      "text": "Leave this path. Get out of our way! Stop telling us about the Holy God of Israel. ’"
    },
    {
      "verse": "12",
      "text": "Because of that, this is what the Holy God of Israel says:‘You have not accepted my message. Instead, you like to be cruel and to deceive people. You believe that it will help you. ‘You have not accepted my message. Instead, you like to be cruel and to deceive people. You believe that it will help you."
    },
    {
      "verse": "13",
      "text": "So your sin will cause you to fall down. You will be like a high wall that has a weak place. It is not safe and it will bend and fall down. Very suddenly it will fall with a great bang!"
    },
    {
      "verse": "14",
      "text": "That wall will break into pieces, like the pieces of a pot. It will be completely broken so that it is all useless. There will be no piece that is big enough to carry coal from a fire, or water from a well. ’"
    },
    {
      "verse": "15",
      "text": "The Almighty Lord, Israel's Holy God says this:‘Turn back to me and wait for me to help you. Be quiet and trust in me. Then you will be safe and you will be strong again. ’But you do not want to trust in God. ‘Turn back to me and wait for me to help you. Be quiet and trust in me. Then you will be safe and you will be strong again. ’"
    },
    {
      "verse": "16",
      "text": "Instead, you say, ‘No! We will run away on horses and we will escape. ’ Yes, you will run away! You say, ‘Our horses will run very fast! ’ But your enemies who chase you will also be very fast!"
    },
    {
      "verse": "17",
      "text": "When one soldier from your enemy chases after you, one thousand of your men will run away from him! Five of them will chase away your whole army! Only a few of you will remain, like a stick with a flag on the top of a hill."
    },
    {
      "verse": "18",
      "text": "So the Lord is waiting for the right time to be kind to you. He is ready to show his great love for you. The Lord God does what is right and fair. Everyone who waits for him to come and help them is a happy person!"
    },
    {
      "verse": "19",
      "text": "People will live in Zion again. You people who live in Jerusalem will not weep any longer. When you call to the Lord for help, he will be kind to you. When he hears you, he will answer you."
    },
    {
      "verse": "20",
      "text": "The Lord God has given trouble to you, like bread that you must eat. He has given pain to you, as water that you must drink. But he will no longer hide himself from you. He will be with you, to teach you and to be your guide."
    },
    {
      "verse": "21",
      "text": "You will hear his voice behind you. When you turn off the path, to the right or to the left, it will say, ‘This is the right way. Walk in it. ’"
    },
    {
      "verse": "22",
      "text": "Then you will destroy your idols and your images of false gods. You used silver or gold to make them beautiful. But now you will throw them away like a piece of dirty cloth. You will tell them, ‘Go away! ’"
    },
    {
      "verse": "23",
      "text": "The Lord will send rain for the seeds that you have planted. The ground will give you plenty of good food. At that time, your cows will have lots of grass to eat in wide fields."
    },
    {
      "verse": "24",
      "text": "The bulls and the donkeys that work on your farms will eat the best food. They will eat the same grain that people eat."
    },
    {
      "verse": "25",
      "text": "Streams of water will pour down from every tall mountain and every high hill. That will happen at the time when your enemies are destroyed. Their strong towers will fall down."
    },
    {
      "verse": "26",
      "text": "At that time, the moon will shine as bright as the sun. Light from the sun will be seven times brighter. It will be like the light of seven days at the same time! At that time, the Lord will make the wounds of his people better. He has hurt them, but now he will make them better."
    },
    {
      "verse": "27",
      "text": "Look! The Lord is coming with his great power from a place that is far away. He is very angry. Thick clouds of smoke are all round him. He speaks angry words that destroy like fire."
    },
    {
      "verse": "28",
      "text": "His breath is like a flood of water that pours out over his enemies. The water reaches as high as their necks. He shakes the nations in a sieve to destroy the bad parts. He leads them away from their bad ways, like a man who leads a horse with a rope."
    },
    {
      "verse": "29",
      "text": "Then you, the Lord's people, will sing! It will be like the happy songs that you sing in the evening at your special feasts. You will be very happy. It will seem like you are making music as you go up to Mount Zion to worship the Lord there. He is the Rock where Israel can be safe."
    },
    {
      "verse": "30",
      "text": "Then the Lord will shout with royal authority. People will know that he has come with great power to punish his enemies. His anger will be like a fire that burns everything. He will come with a great storm of rain, thunder and hail that destroys everything."
    },
    {
      "verse": "31",
      "text": "When the Lord shouts, his command will destroy the Assyrian army. He will knock them down with his heavy stick."
    },
    {
      "verse": "32",
      "text": "He will punish them with a big stick. He will use his weapons to attack them. As he does that, there will be happy music from harps and tambourines!"
    },
    {
      "verse": "33",
      "text": "The Lord has already prepared a place to burn the bodies of the dead people. It is ready for the king of Assyria! There is a place for him that is deep and wide. There is plenty of wood for the fire. The Lord's breath will be like a stream of hot sulphur. He will breathe out on the heap of wood and the fire will burn!"
    }
  ],
  "31": [
    {
      "verse": "1",
      "text": "It will be very bad for those people who expect that Egypt will help them. They think that Egypt's many horses and chariots will keep them safe. They trust the power of Egypt's strong soldiers who ride on horses. But those people do not trust the Holy God of Israel. They do not ask the Lord to help them."
    },
    {
      "verse": "2",
      "text": "But the Lord is very wise. He will bring trouble to people, as he has promised. He will not change his mind. He will punish wicked people, as well as those who help them to do evil things."
    },
    {
      "verse": "3",
      "text": "The men in Egypt are human. They are not God. Their horses are weak animals, not powerful spirits. When the Lord lifts up his hand to punish them, the strong helpers will not be able to stand. The people who expected them to help will fall down too. They will all come to an end together."
    },
    {
      "verse": "4",
      "text": "This is what the Lord said to me:‘The Lord Almighty will come down to fight on Mount Zion and on its hill. He will come like a strong young lion that roars when it has caught a lamb to eat. Even if a whole crowd of shepherds come to chase it away, their shouts will not make the lion afraid."
    },
    {
      "verse": "5",
      "text": "The Lord Almighty will make Jerusalem safe. He will protect it like a bird that protects its nest. He will pass over the city and he will rescue it."
    },
    {
      "verse": "6",
      "text": "Israelite people, you have turned completely against the Lord. Now turn back to him!"
    },
    {
      "verse": "7",
      "text": "The time will come when everyone must throw away their gold and silver idols. It was a sin for you to make them for yourselves."
    },
    {
      "verse": "8",
      "text": "The Assyrian soldiers will die in battle. But humans did not make the sword that will kill them. It is God's sword that will destroy them. The Assyrians will run away from that sword. But their strong young men will have to do hard work as slaves. That is what the Lord says. His fire is in Zion. Yes, his hot oven is in Jerusalem."
    },
    {
      "verse": "9",
      "text": "Their strongest soldiers will run away because they are afraid. The officers of their army will be afraid when they see the Lord's battle flag. ’That is what the Lord says. His fire is in Zion. Yes, his hot oven is in Jerusalem."
    }
  ],
  "32": [
    {
      "verse": "1",
      "text": "Look! A king is coming who will rule in a right and fair way. Honest leaders will rule under his authority. Honest leaders will rule under his authority."
    },
    {
      "verse": "2",
      "text": "Each leader will be like a safe place to hidefrom strong winds and storms. He will be like streams of water in a desert. And he will be like the shadow of a great rock in a hot, dry land. from strong winds and storms. He will be like streams of water in a desert. And he will be like the shadow of a great rock in a hot, dry land."
    },
    {
      "verse": "3",
      "text": "At that time, everyone who has eyes will be able to see clearly. Everyone who has ears will be able to listen well. Everyone who has ears will be able to listen well."
    },
    {
      "verse": "4",
      "text": "People who do things too quickly will stop and think first. Those who cannot speak well will be able to talk clearly. Those who cannot speak well will be able to talk clearly."
    },
    {
      "verse": "5",
      "text": "Nobody will praise a stupid person. Nobody will respect people who cheat others. Nobody will respect people who cheat others."
    },
    {
      "verse": "6",
      "text": "Stupid people say silly things. They think of evil things that they can do. They live in a way that does not respect God. The things that they teach about the Lord are false. They keep food away from hungry people. They give no drink to thirsty people. They think of evil things that they can do. They live in a way that does not respect God. The things that they teach about the Lord are false. They keep food away from hungry people. They give no drink to thirsty people."
    },
    {
      "verse": "7",
      "text": "Cruel people do evil things to deceive others. They think of ways that they can cheat their friends. They tell lies to give trouble to poor people. So poor people do not receive the justice that they deserve. They think of ways that they can cheat their friends. They tell lies to give trouble to poor people. So poor people do not receive the justice that they deserve."
    },
    {
      "verse": "8",
      "text": "But good people think of ways that they can be kind to others. They do the good things that they have decided to do. They do the good things that they have decided to do."
    },
    {
      "verse": "9",
      "text": "You women, listen carefully to what I say to you! You think that you have no problems. You feel very safe. But listen to me! You think that you have no problems. You feel very safe. But listen to me!"
    },
    {
      "verse": "10",
      "text": "Now, you think that you are safe, but in one year's time, you will shake with fear. There will be no grapes at harvest time. You will pick no fruit from your trees. but in one year's time, you will shake with fear. There will be no grapes at harvest time. You will pick no fruit from your trees."
    },
    {
      "verse": "11",
      "text": "You think that you have no problems, but you should be afraid. Yes, shake with fear! Take off all your beautiful clothes. Tie rough cloth round your legs instead. but you should be afraid. Yes, shake with fear! Take off all your beautiful clothes. Tie rough cloth round your legs instead."
    },
    {
      "verse": "12",
      "text": "Weep and hit your breasts, because your good fields have no crops, and your vines have no grapes. because your good fields have no crops, and your vines have no grapes."
    },
    {
      "verse": "13",
      "text": "Weep because of what has happened to my people's land. Only thorn bushes and weeds grow there. Weep because there are no longer any happy homes. There are no more parties in the city. Only thorn bushes and weeds grow there. Weep because there are no longer any happy homes. There are no more parties in the city."
    },
    {
      "verse": "14",
      "text": "Nobody will remain in the king's great palace. The city that is now full of people will be empty. The city's hill and its strong buildingswill become heaps of stones for ever. Wild donkeys will play in those places, and sheep will find grass to eat. The city that is now full of people will be empty. The city's hill and its strong buildings will become heaps of stones for ever. Wild donkeys will play in those places, and sheep will find grass to eat."
    },
    {
      "verse": "15",
      "text": "It will be like that until God pours a new spirit on us from heaven. Then, deserts will become fields of fruit trees. And fields of fruit trees will seem like forests. Then, deserts will become fields of fruit trees. And fields of fruit trees will seem like forests."
    },
    {
      "verse": "16",
      "text": "Everywhere, people will be honest and fair, in the deserts as well as in the fields. in the deserts as well as in the fields."
    },
    {
      "verse": "17",
      "text": "People will do things that are right, so there will be peace. People will always be safe. so there will be peace. People will always be safe."
    },
    {
      "verse": "18",
      "text": "My people will live safely and quietly in their homes. They will not be afraid of trouble. They will not be afraid of trouble."
    },
    {
      "verse": "19",
      "text": "A storm of hail may destroy the forest. The buildings in the city may all fall down too. The buildings in the city may all fall down too."
    },
    {
      "verse": "20",
      "text": "But still the Lord will bless you. You will plant your seeds beside streams of water. You will send your cows and donkeys into the fields, and they will have plenty of grass to eat."
    }
  ],
  "33": [
    {
      "verse": "1",
      "text": "It will be very bad for you who destroy other nations. No other nation has destroyed you yet. It will be very bad for you who deceive other nations. No other nation has deceived you yet. But in the end, when you stop destroying, others will destroy you. When you stop deceiving, other nations will deceive you. No other nation has destroyed you yet. It will be very bad for you who deceive other nations. No other nation has deceived you yet. But in the end, when you stop destroying, others will destroy you. When you stop deceiving, other nations will deceive you."
    },
    {
      "verse": "2",
      "text": "Lord, please be kind to us. We wait for you to help us. Make us strong every day. Rescue us when trouble happens. We wait for you to help us. Make us strong every day. Rescue us when trouble happens."
    },
    {
      "verse": "3",
      "text": "When they hear the noise of battle, the nations run away. When you go to war, they run in every direction! the nations run away. When you go to war, they run in every direction!"
    },
    {
      "verse": "4",
      "text": "You nations, after the battle your valuable things will quickly disappear! It will seem like locusts have eaten them all. Yes, we will take it all, like a hungry crowd of locusts. It will seem like locusts have eaten them all. Yes, we will take it all, like a hungry crowd of locusts."
    },
    {
      "verse": "5",
      "text": "The Lord is greater than all others. He lives high above the earth. He will cause Zion's people to do what is right and fair. He lives high above the earth. He will cause Zion's people to do what is right and fair."
    },
    {
      "verse": "6",
      "text": "Whatever happens, he will cause you to be strong. He will always keep you safe, and he will make you wise, so that you understand things. Respect the Lord with fear, and he will do all this for you. He will always keep you safe, and he will make you wise, so that you understand things. Respect the Lord with fear, and he will do all this for you."
    },
    {
      "verse": "7",
      "text": "Look! Our brave soldiers are calling out in the streets. The people that we sent to make peace with our enemies are weeping. The people that we sent to make peace with our enemies are weeping."
    },
    {
      "verse": "8",
      "text": "The big roads are empty. Nobody is travelling anywhere. People spoil agreements that they have made. They do not believe what people promise. They do not respect anyone. Nobody is travelling anywhere. People spoil agreements that they have made. They do not believe what people promise. They do not respect anyone."
    },
    {
      "verse": "9",
      "text": "The land itself is dry and useless. Lebanon's forest is dying. Sharon has become like a desert. The trees in Bashan and Carmel have no leaves. Lebanon's forest is dying. Sharon has become like a desert. The trees in Bashan and Carmel have no leaves."
    },
    {
      "verse": "10",
      "text": "The Lord says, ‘Now I will stand up to do something. I will show that I am great and powerful. I will show that I am great and powerful."
    },
    {
      "verse": "11",
      "text": "My enemies, everything that you want to do will be useless. Your thoughts are like dry grass and straw. Your own breath will destroy you, like a fire that burns dry grass. Your thoughts are like dry grass and straw. Your own breath will destroy you, like a fire that burns dry grass."
    },
    {
      "verse": "12",
      "text": "Your people will be like wood for the fire, and only ashes will remain. They will burn as easily as thorn bushesthat people cut down and throw on the fire. and only ashes will remain. They will burn as easily as thorn bushes that people cut down and throw on the fire."
    },
    {
      "verse": "13",
      "text": "You people who live far away, listen to what I have done! You people who are near, understand that I am very strong. ’ listen to what I have done! You people who are near, understand that I am very strong. ’"
    },
    {
      "verse": "14",
      "text": "The sinners who live in Zion are afraid. The people who do not respect God shake with fear. They ask, ‘Who among us can stay alive? This is a fire that burns everything. Nobody can stop it from burning! ’ The people who do not respect God shake with fear. They ask, ‘Who among us can stay alive? This is a fire that burns everything. Nobody can stop it from burning! ’"
    },
    {
      "verse": "15",
      "text": "But some people can still live! Those who are honest in what they doand fair in what they say. Those who refuse to cheat other peopleso that they can become rich. Those who refuse to accept bribes. Those who will not listen to murderers, and who will not think about evil things. Those who are honest in what they do and fair in what they say. Those who refuse to cheat other people so that they can become rich. Those who refuse to accept bribes. Those who will not listen to murderers, and who will not think about evil things."
    },
    {
      "verse": "16",
      "text": "People who are like that will live in a safe place. Danger will not reach them among the high rocks. They will always have food to eat, and plenty of water to drink. Danger will not reach them among the high rocks. They will always have food to eat, and plenty of water to drink."
    },
    {
      "verse": "17",
      "text": "With your own eyes, you will see the king. He will be great and beautiful. You will see the land that he rules. It will reach far and wide. He will be great and beautiful. You will see the land that he rules. It will reach far and wide."
    },
    {
      "verse": "18",
      "text": "Then you will think about the time when you were afraid. You will say, ‘Where is the enemy's important officer? Where is the officer that we paid taxes to? Where is the officer who counted our strong buildings? They are no longer here to give us trouble! ’ You will say, ‘Where is the enemy's important officer? Where is the officer that we paid taxes to? Where is the officer who counted our strong buildings? They are no longer here to give us trouble! ’"
    },
    {
      "verse": "19",
      "text": "You will never see those cruel people again. You could not understand their language. They laughed at you with strange words. You could not understand their language. They laughed at you with strange words."
    },
    {
      "verse": "20",
      "text": "Now, look at Zion, the city where we have our festivals. Yes, you will see Jerusalem. It will be a place that is quiet and safe. It will be like a tent that people will never move. They will never pull up its pegs. They will never break its ropes. Yes, you will see Jerusalem. It will be a place that is quiet and safe. It will be like a tent that people will never move. They will never pull up its pegs. They will never break its ropes."
    },
    {
      "verse": "21",
      "text": "The Lord will rule there as our powerful God. Rivers and wide streams will run through it. Our enemies will not be able to bring their ships there to attack us. Rivers and wide streams will run through it. Our enemies will not be able to bring their ships there to attack us."
    },
    {
      "verse": "22",
      "text": "The Lord will keep us safe. He is our judge, our ruler and our king. He is our judge, our ruler and our king."
    },
    {
      "verse": "23",
      "text": "At this time, your ship is not ready to go anywhere. You have not tied the ropes. There is nowhere to hang the sails. But then, you will take many valuable things from your enemies. You will share them after the battle. Even people who cannot walk wellwill carry away what they want! You have not tied the ropes. There is nowhere to hang the sails. But then, you will take many valuable things from your enemies. You will share them after the battle. Even people who cannot walk well will carry away what they want!"
    },
    {
      "verse": "24",
      "text": "Nobody who lives in Zion will say, ‘I am ill. ’And God will forgive their sins."
    }
  ],
  "34": [
    {
      "verse": "1",
      "text": "Come near to me, people of all nations. Listen carefully, everyone! All the earth, and everything that is in it, listen to me! Yes, the whole world, and all who live in it, listen carefully! Listen carefully, everyone! All the earth, and everything that is in it, listen to me! Yes, the whole world, and all who live in it, listen carefully!"
    },
    {
      "verse": "2",
      "text": "The Lord is angry against all the nationsand all their armies. He has decided to destroy them, and that is what he will do. and all their armies. He has decided to destroy them, and that is what he will do."
    },
    {
      "verse": "3",
      "text": "Nobody will bury the dead bodiesof those who have died in battle. The smell of their dead bodies will be everywhere. Their blood will pour down the mountains. of those who have died in battle. The smell of their dead bodies will be everywhere. Their blood will pour down the mountains."
    },
    {
      "verse": "4",
      "text": "The stars in the sky will slowly disappear. The sky will close up like a book. All the stars will fall, like dry leaves that fall from a vine. They will drop like figs from a fig tree, when they become dry. The sky will close up like a book. All the stars will fall, like dry leaves that fall from a vine. They will drop like figs from a fig tree, when they become dry."
    },
    {
      "verse": "5",
      "text": "The Lord says, ‘My sword has finished its work in the skies. Now it will come to punish Edom. Those are the people that I have decided to destroy. ’ ‘My sword has finished its work in the skies. Now it will come to punish Edom. Those are the people that I have decided to destroy. ’"
    },
    {
      "verse": "6",
      "text": "The Lord's sword has blood all over it! It is the blood of young sheep and goats. It has the fat of meat on it. It is the fat from sheep's kidneys. Yes! The Lord is killing animals for a sacrifice in Bozrah. He will kill many people in Edom. It is the blood of young sheep and goats. It has the fat of meat on it. It is the fat from sheep's kidneys. Yes! The Lord is killing animals for a sacrifice in Bozrah. He will kill many people in Edom."
    },
    {
      "verse": "7",
      "text": "He will kill their wild oxenand their young bulls. Blood will pour over Edom's land. Fat will feed their soil. and their young bulls. Blood will pour over Edom's land. Fat will feed their soil."
    },
    {
      "verse": "8",
      "text": "The Lord has chosen a day for punishment. It will be a time when he punishes Zion's enemies, because they have attacked his people. It will be a time when he punishes Zion's enemies, because they have attacked his people."
    },
    {
      "verse": "9",
      "text": "The water in Edom's streams will become tar. Its soil will become sulphur. Its whole land will become tar that is burning. Its soil will become sulphur. Its whole land will become tar that is burning."
    },
    {
      "verse": "10",
      "text": "That fire will burn through the days and the nights. Its smoke will always continue to rise up. The land will be empty from one century to the next. Nobody will ever travel through it again. Its smoke will always continue to rise up. The land will be empty from one century to the next. Nobody will ever travel through it again."
    },
    {
      "verse": "11",
      "text": "Owls, hawks and hedgehogs will live there, as well as all kinds of wild animals and wild birds. The Lord will carefully measure the whole land, so that he can destroy it. It will become like an empty desert. as well as all kinds of wild animals and wild birds. The Lord will carefully measure the whole land, so that he can destroy it. It will become like an empty desert."
    },
    {
      "verse": "12",
      "text": "There will be no kingdom left for anyone to rule. Edom's leaders and officers will all disappear. Edom's leaders and officers will all disappear."
    },
    {
      "verse": "13",
      "text": "Thorn bushes will grow over its palaces. Bushes and weeds will grow over its strong cities. Jackals and ostriches will make their homes in the land. Bushes and weeds will grow over its strong cities. Jackals and ostriches will make their homes in the land."
    },
    {
      "verse": "14",
      "text": "Wild animals and hyenas will meet there. Wild goats will call out to each other. The night monster will come there, and she will find a place to stay. Wild goats will call out to each other. The night monster will come there, and she will find a place to stay."
    },
    {
      "verse": "15",
      "text": "Owls will build their nests there. They will take care of their eggsuntil the baby birds come out. They will keep their babies safe under their wings. Hawks will meet there too. They will be together in pairs, male and female. They will take care of their eggs until the baby birds come out. They will keep their babies safe under their wings. Hawks will meet there too. They will be together in pairs, male and female."
    },
    {
      "verse": "16",
      "text": "Read the Lord's book very carefully:‘All these animals and birds will be there. They will all be together in pairs. The Lord himself has commanded what must happen. His Spirit brings them all together. ’ ‘All these animals and birds will be there. They will all be together in pairs. The Lord himself has commanded what must happen. His Spirit brings them all together. ’"
    },
    {
      "verse": "17",
      "text": "The Lord has decided where each one will live. He measures a place for every kind of animal and bird. The land will always belong to them to live in. It will be their home from one century to the next."
    }
  ],
  "35": [
    {
      "verse": "1",
      "text": "The desert and the dry land will be happy! The wilderness will be happy too, and beautiful flowers will grow there. The wilderness will be happy too, and beautiful flowers will grow there."
    },
    {
      "verse": "2",
      "text": "Yes, there will be lots of flowers! The land will sing and shout with joy! The desert will be as beautiful as Lebanon. It will seem like lovely places in Carmel and in Sharon. In those places, people will see the Lord's glory. They will see that our God is very great. The land will sing and shout with joy! The desert will be as beautiful as Lebanon. It will seem like lovely places in Carmel and in Sharon. In those places, people will see the Lord's glory. They will see that our God is very great."
    },
    {
      "verse": "3",
      "text": "If your hands feel weak, now be strong! If your knees are shaking, now be brave! now be strong! If your knees are shaking, now be brave!"
    },
    {
      "verse": "4",
      "text": "Say this to people who are afraid:‘Be strong! Do not be afraid! Your God is coming now. He is coming to punish his enemiesfor the bad things that they have done. He is coming to rescue you! ’ ‘Be strong! Do not be afraid! Your God is coming now. He is coming to punish his enemies for the bad things that they have done. He is coming to rescue you! ’"
    },
    {
      "verse": "5",
      "text": "At that time, he will open the eyes of blind people. Deaf people will hear again. Deaf people will hear again."
    },
    {
      "verse": "6",
      "text": "People with weak legs will jump like deer. People who cannot speak now will shout with joy. Water will pour from springs in the desert. Streams of water will run in the wilderness. People who cannot speak now will shout with joy. Water will pour from springs in the desert. Streams of water will run in the wilderness."
    },
    {
      "verse": "7",
      "text": "The hot earth will become a pool of water. The dry ground will have springs of water. In the places where jackals made their homes, there will now be grasses and reeds. The dry ground will have springs of water. In the places where jackals made their homes, there will now be grasses and reeds."
    },
    {
      "verse": "8",
      "text": "There will be a great road there. It will be called ‘The Holy Way’. People who are unclean will not travel on it. It will be for those people who know God's way. Evil fools will not walk on it. It will be called ‘The Holy Way’. People who are unclean will not travel on it. It will be for those people who know God's way. Evil fools will not walk on it."
    },
    {
      "verse": "9",
      "text": "No lions will be there. No dangerous wild animals will come onto it. They will not come near to it. It is the people that the Lord has rescuedwho will travel on that road. No dangerous wild animals will come onto it. They will not come near to it. It is the people that the Lord has rescued who will travel on that road."
    },
    {
      "verse": "10",
      "text": "He has paid the price to rescue them, and they will return home along it. They will be happy and they will sing, as they go into Zion city. They will be very happy for ever. They will never again be sad or upset. All the time they will be completely happy."
    }
  ],
  "36": [
    {
      "verse": "1",
      "text": "years, King Sennacherib of Assyria attacked Judah with his army. He took all the strong cities in Judah for himself."
    },
    {
      "verse": "2",
      "text": "Then the king of Assyria sent his army officer from Lachish to Jerusalem, to speak to King Hezekiah. The officer took a large army with him. He stopped at the stream of water that came from the higher pool. It was on the road to the field where people washed clothes."
    },
    {
      "verse": "3",
      "text": "These people came out to meet him: Hilkiah's son Eliakim, who was the most important officer in the king's palace. Shebna, a government officer. Asaph's son, Joah, the king's secretary."
    },
    {
      "verse": "4",
      "text": "The Assyrian army officer said to them, ‘Tell Hezekiah that the great king, the king of Assyria, says this to him:“Why are you so sure that someone will rescue you from our power?"
    },
    {
      "verse": "5",
      "text": "You say that you have good plans. You say that your army is strong. But those are only useless words! You have turned against me, so who are you trusting to save you?"
    },
    {
      "verse": "6",
      "text": "Yes, you think that Egypt is strong enough to help you. But you should not trust Pharaoh, the king of Egypt. He is like a weak stick. If you use it to walk with, it will break! A broken piece of stick will make a hole through your hand and give you much pain! That is the trouble that the king of Egypt brings to everyone who trusts him to help them."
    },
    {
      "verse": "7",
      "text": "Maybe you will say to me, ‘We are trusting the Lord our God to help us. ’ But it was your king, Hezekiah, who removed the altars and the special places where you worship your God. He told the people of Judah and Jerusalem, ‘You must worship God only at the altar here in Jerusalem. ’ ”"
    },
    {
      "verse": "8",
      "text": "So you should make an agreement with my master, the king of Assyria. I will give you 2, 000 horses, if you have enough riders to put on them."
    },
    {
      "verse": "9",
      "text": "You cannot refuse what I offer to you! And I am only an unimportant officer who serves my master. You are hoping that Egypt will give you chariots and men to ride on horses. But you will never be strong enough to win a battle against us."
    },
    {
      "verse": "10",
      "text": "You should also understand this: It was the Lord himself who commanded me to bring my army here and attack Jerusalem. He said to me, “Attack this country and destroy it! ” ’"
    },
    {
      "verse": "11",
      "text": "Then Eliakim, Shebna and Joah said to the leader of the Assyrian army, ‘Please sir, speak to us in the Aramaic language. We can understand it. Do not speak to us in the Hebrew language, because all the people who are on the wall of the city will understand it. ’"
    },
    {
      "verse": "12",
      "text": "But the Assyrian army leader replied, ‘My master did not send me here to give this message only to your king and to you. The men who are sitting on the city wall also need to hear my master's message. Like you, they will soon have to eat their own dung and drink their own urine. ’"
    },
    {
      "verse": "13",
      "text": "Then the Assyrian army leader stood there and he shouted in the Hebrew language, ‘Listen to this message from the great king, the king of Assyria!"
    },
    {
      "verse": "14",
      "text": "This is what the king says to you:“Do not let Hezekiah deceive you. He cannot save you from my power."
    },
    {
      "verse": "15",
      "text": "Do not believe Hezekiah when he tells you that you can trust the Lord to help you. He says, ‘The Lord will surely rescue us. He will not let the king of Assyria take this city for himself. ’"
    },
    {
      "verse": "16",
      "text": "Do not believe what Hezekiah says! ”This is what the king of Assyria says to you: “Show me that you accept my offer of peace and come out of your city. Then you will all live safely in your homes. You will eat the fruit from your own vines and fig trees. You will drink the water from your own wells."
    },
    {
      "verse": "17",
      "text": "Later, I will come to Jerusalem. I will take you away to a country that is like your own land here. There will be plenty of grain and new wine for you in that country. There will be bread and there will be vineyards."
    },
    {
      "verse": "18",
      "text": "Do not let Hezekiah deceive you when he says, ‘The Lord will rescue us. ’ No god of any nation has ever saved his country from the king of Assyria's power."
    },
    {
      "verse": "19",
      "text": "The gods of Hamath and Arpad could not help their people. The gods of Sepharvaim could not help their people either. No god was able to rescue Samaria from my power."
    },
    {
      "verse": "20",
      "text": "No god among all the gods of those countries could save their people from my power. So do not think that the Lord can save Jerusalem from my power. ” ’"
    },
    {
      "verse": "21",
      "text": "When the people who were sitting on the wall heard this, they were quiet. They did not reply, because King Hezekiah had said, ‘Do not answer him. ’"
    },
    {
      "verse": "22",
      "text": "Then King Hezekiah's three officers, Eliakim, Shebna and Joah, went back to Hezekiah. They had torn their clothes because they were very upset. They told the king what the Assyrian officer had said."
    }
  ],
  "37": [
    {
      "verse": "1",
      "text": "When King Hezekiah heard the report of his officers, he tore his clothes. Then he put on rough sackcloth and he went into the Lord's temple."
    },
    {
      "verse": "2",
      "text": "He sent Eliakim, Shebna and the leaders of the priests to Amoz's son, Isaiah the prophet. Eliakim was the most important officer in the king's palace. Shebna was a government officer. They were all wearing sackcloth."
    },
    {
      "verse": "3",
      "text": "They told Hezekiah's message to Isaiah:‘This is a time of great trouble. Assyria has insulted us to make us ashamed. Our nation is like a woman who is ready to give birth, but she is too weak to push the child out."
    },
    {
      "verse": "4",
      "text": "The Assyrian officer has brought a message from his king to insult the God who lives for ever. Maybe the Lord your God has heard that message. He should punish the officer for his wicked message. So please pray for the people who remain in Jerusalem. ’"
    },
    {
      "verse": "5",
      "text": "When King Hezekiah's officers told their message to Isaiah,"
    },
    {
      "verse": "6",
      "text": "Isaiah said to them, ‘Tell your master that the Lord says this: “Do not let the words that you have heard make you afraid. The servants of the king of Assyria have insulted me, the Lord."
    },
    {
      "verse": "7",
      "text": "Listen to me! I will put a spirit into the king of Assyria's mind. He will hear a report which will cause him to return to his own country. There, in his own land, I will cause someone to kill him with a sword. ” ’"
    },
    {
      "verse": "8",
      "text": "At that time, the king of Assyria had left Lachish city. When the Assyrian officer heard that news, he left Jerusalem. He went to meet the king at Libnah, where the king was now fighting a battle."
    },
    {
      "verse": "9",
      "text": "Then the king of Assyria heard a report about Tirhakah, the king of Ethiopia. People told him, ‘He has brought his army from Ethiopia to fight against you. ’When the king of Assyria heard that news, he sent another message to Hezekiah in Jerusalem."
    },
    {
      "verse": "10",
      "text": "This was his message to King Hezekiah of Judah: ‘You are hoping that your God will help you. Your God may say that the king of Assyria will not destroy Jerusalem. But do not let him deceive you."
    },
    {
      "verse": "11",
      "text": "You have heard how the kings of Assyria have completely destroyed all other countries. So do not think that your God will rescue you."
    },
    {
      "verse": "12",
      "text": "The gods of those other countries did not save them. Our kings destroyed the nations of Gozan, Haran and Rezeph. They killed the people of Eden who lived in Tel Assar."
    },
    {
      "verse": "13",
      "text": "The kings of Hamath and Arpad have gone. The king of Sepharvaim city has gone. The kings of Hena and Ivvah have also gone. ’"
    },
    {
      "verse": "14",
      "text": "When Hezekiah received the letter with this message, he read it. Then he went up to the Lord's temple. He put the letter there, in front of the Lord."
    },
    {
      "verse": "15",
      "text": "Hezekiah prayed to the Lord. He said:"
    },
    {
      "verse": "16",
      "text": "‘Lord Almighty, you are Israel's God. You sit on your throne between the cherubs. Only you are the God who rules all the kingdoms in the world. You have made the heavens and the earth."
    },
    {
      "verse": "17",
      "text": "Lord, please listen carefully to me. Lord, look carefully at this letter. Listen to Sennacherib's message. He is insulting you, the God who lives for ever."
    },
    {
      "verse": "18",
      "text": "It is true, Lord, that the kings of Assyria have destroyed all these people and their lands."
    },
    {
      "verse": "19",
      "text": "They threw the gods of these nations into the fire. Those idols are not really gods. People used wood and stone to make them. So the Assyrians could destroy them."
    },
    {
      "verse": "20",
      "text": "So now, Lord, you are our God! Save us from the power of Sennacherib! Then all the kingdoms in the world will know that you alone are the Lord. ’"
    },
    {
      "verse": "21",
      "text": "Then Amoz's son, Isaiah, sent this message to Hezekiah: ‘The Lord, Israel's God, says, “You have prayed to me about Sennacherib, the king of Assyria. ” “The holy people of Zion laugh at you! They think that you are useless. Yes, the people of Jerusalem shake their heads as you run away."
    },
    {
      "verse": "22",
      "text": "This is the Lord's reply. The Lord says this about King Sennacherib:“The holy people of Zion laugh at you! They think that you are useless. Yes, the people of Jerusalem shake their headsas you run away."
    },
    {
      "verse": "23",
      "text": "Who do you think it is that you have insulted? Who have you shouted at? Who have you looked at so proudly? The answer is the Holy God of Israel! Who have you shouted at? Who have you looked at so proudly? The answer is the Holy God of Israel!"
    },
    {
      "verse": "24",
      "text": "You have sent your servantsto insult the Lord God. You have said, ‘I have taken all my chariotsand I have gone up high mountains, the highest mountains in Lebanon. I have cut down its tall cedar trees, and I have cut down its best pine trees. I went up to its highest places, and I went far into its forests. to insult the Lord God. You have said, ‘I have taken all my chariots and I have gone up high mountains, the highest mountains in Lebanon. I have cut down its tall cedar trees, and I have cut down its best pine trees. I went up to its highest places, and I went far into its forests."
    },
    {
      "verse": "25",
      "text": "I dug wells and they gave me water to drink. My army marched through all the rivers in Egypt, and the rivers became dry. ’ My army marched through all the rivers in Egypt, and the rivers became dry. ’"
    },
    {
      "verse": "26",
      "text": "You said that, but now listen to this! You must surely have heard it already. I decided what to do a long time ago! Now I am causing it to happen. I decided that you would destroy strong citiesso that they became heaps of stones. You must surely have heard it already. I decided what to do a long time ago! Now I am causing it to happen. I decided that you would destroy strong cities so that they became heaps of stones."
    },
    {
      "verse": "27",
      "text": "The people of those cities have no power. They are afraid and they are confused. They are like plants in a field, that cannot live for a long time. They are like fresh green grass, or grass that grows on the roof of a house. When a hot wind blows on them, it burns them and they die. They are afraid and they are confused. They are like plants in a field, that cannot live for a long time. They are like fresh green grass, or grass that grows on the roof of a house. When a hot wind blows on them, it burns them and they die."
    },
    {
      "verse": "28",
      "text": "I know everything about you. I know where you live. I know when you go out. And I know when you return home. I know how much you shout against me, when you are angry. I know where you live. I know when you go out. And I know when you return home. I know how much you shout against me, when you are angry."
    },
    {
      "verse": "29",
      "text": "Yes, you do shout at me! And I have heard all your proud noise. So I will put my hook in your nose. I will tie a rope to your mouth. Then I will pull you back homeby the same way that you came. ” And I have heard all your proud noise. So I will put my hook in your nose. I will tie a rope to your mouth. Then I will pull you back home by the same way that you came. ”"
    },
    {
      "verse": "30",
      "text": "King Hezekiah, this is how you will know that I have spoken a true message from the Lord. This year, you will eat crops that grow by themselves. And next year you will eat what grows from the same seeds. But in the third year you will plant seeds for yourselves, and they will give you a harvest of crops. You will plant vines again and you will eat grapes from them."
    },
    {
      "verse": "31",
      "text": "The people who remain in Judah will be like strong plants that put their roots down into the ground. Their branches will give lots of fruit."
    },
    {
      "verse": "32",
      "text": "A small number of people will still be alive in Jerusalem. They will leave Mount Zion and they will go to other places. The great love that the Lord Almighty has for his people will cause that to happen!"
    },
    {
      "verse": "33",
      "text": "This is what the Lord says about the king of Assyria:“His army will not come into this city. His soldiers will not shoot any arrows here. They will not attack the city as they hold their shields. They will not build heaps of earth against the city's walls. “His army will not come into this city. His soldiers will not shoot any arrows here. They will not attack the city as they hold their shields. They will not build heaps of earth against the city's walls."
    },
    {
      "verse": "34",
      "text": "No! The king will return home by the way that he came. He will not come into this city. ”That is what the Lord says. He will not come into this city. ” That is what the Lord says."
    },
    {
      "verse": "35",
      "text": "“I will make this city safe and I will rescue it. I will do that to show that I am great. I promised my servant David that I would do it. So I will do it. ” ’ I will do that to show that I am great. I promised my servant David that I would do it. So I will do it. ” ’"
    },
    {
      "verse": "36",
      "text": "Then the Lord's angel went to the camp of the Assyrian army. He killed 185, 000 of their soldiers. When people got up in the morning, they saw all those dead bodies!"
    },
    {
      "verse": "37",
      "text": "So King Sennacherib of Assyria took his army away. He returned to Assyria and he lived in Nineveh."
    },
    {
      "verse": "38",
      "text": "One day, Sennacherib was worshipping his god Nisrok, in Nisrok's temple. Two of Sennacherib's sons, Adrammelech and Sharezer, went in and they killed him with their swords. Then they ran away to the region of Ararat. Sennacherib's son, Esarhaddon, now ruled Assyria as king."
    }
  ],
  "38": [
    {
      "verse": "1",
      "text": "At that time, Hezekiah became very ill. He nearly died. Then Amoz's son, Isaiah the prophet, went to Hezekiah. He said to Hezekiah, ‘This is what the Lord says: “You will soon die. You will not get better. So you must tell your family what to do after your death. ” ’"
    },
    {
      "verse": "2",
      "text": "Then Hezekiah turned his face towards the wall and he prayed to the Lord."
    },
    {
      "verse": "3",
      "text": "He prayed, ‘Lord, please remember that I have served you well. I have always obeyed you. You could trust me to do the things that you told me to do. ’ Hezekiah wept very much."
    },
    {
      "verse": "4",
      "text": "Then the Lord said to Isaiah,"
    },
    {
      "verse": "5",
      "text": "‘Go and say this to Hezekiah: “This is what the Lord says, the God that your ancestor David worshipped. I have heard your prayer and I have seen your tears. So I will let you live for 15 more years."
    },
    {
      "verse": "6",
      "text": "I will rescue you and this city from the power of the king of Assyria. I will keep Jerusalem safe. ” ’"
    },
    {
      "verse": "7",
      "text": "Isaiah said, ‘The Lord will do what he has promised to do for you. This is how you will know that it will really happen."
    },
    {
      "verse": "8",
      "text": "You can see the sun's shadow when it falls on the stairs that King Ahaz built. The Lord will cause the shadow to go back ten steps on these stairs. ’ Then the shadow did go back ten steps!"
    },
    {
      "verse": "9",
      "text": "When Hezekiah became better from his disease, he wrote this song:"
    },
    {
      "verse": "10",
      "text": "I thought that I might die in the middle of my life. I thought that I would go into the deep hole of death, before I had lived all the years of my life. I thought that I would go into the deep hole of death, before I had lived all the years of my life."
    },
    {
      "verse": "11",
      "text": "I thought, ‘I will not see the Lord again, while I live in this world. I will no longer see the people who live in the world. I will no longer live among them. ’ while I live in this world. I will no longer see the people who live in the world. I will no longer live among them. ’"
    },
    {
      "verse": "12",
      "text": "My home here has gone, as easily as they pull down a shepherd's tent. God has cut off my life, like a piece of cloth that they have just made. They cut it off and they roll it up. As quickly as day becomes night, God brings my life to an end. as easily as they pull down a shepherd's tent. God has cut off my life, like a piece of cloth that they have just made. They cut it off and they roll it up. As quickly as day becomes night, God brings my life to an end."
    },
    {
      "verse": "13",
      "text": "I waited until morning would come. It seemed like God was breaking all my bones, like a lion does. As quickly as day becomes night, God brings my life to an end. It seemed like God was breaking all my bones, like a lion does. As quickly as day becomes night, God brings my life to an end."
    },
    {
      "verse": "14",
      "text": "I cry like a swallow. I make a sad noise like a dove. My eyes are weak as I look up to heaven for help. Lord God, save me from my trouble! I make a sad noise like a dove. My eyes are weak as I look up to heaven for help. Lord God, save me from my trouble!"
    },
    {
      "verse": "15",
      "text": "I do not know what I can say. The Lord has told me what must happen. He has done what he decided to do. I will live quietly for the rest of my life, because I am very sad and upset. The Lord has told me what must happen. He has done what he decided to do. I will live quietly for the rest of my life, because I am very sad and upset."
    },
    {
      "verse": "16",
      "text": "Lord God, your promises give life to people. May they give life to my spirit. Please make me well again and let me live. May they give life to my spirit. Please make me well again and let me live."
    },
    {
      "verse": "17",
      "text": "Yes, it was good for me to have this trouble. You rescued me from the deep hole of death. You removed my sins, and you put them behind your back. You rescued me from the deep hole of death. You removed my sins, and you put them behind your back."
    },
    {
      "verse": "18",
      "text": "Dead people in their graves cannot praise you. They cannot sing to thank you. People who go down into the deep hole of deathcannot trust you to help them. They cannot sing to thank you. People who go down into the deep hole of death cannot trust you to help them."
    },
    {
      "verse": "19",
      "text": "It is those people who are alive that can thank you. And I am doing it today. Fathers tell their children that they can trust you. And I am doing it today. Fathers tell their children that they can trust you."
    },
    {
      "verse": "20",
      "text": "The Lord will now save me from death. We will sing to thank the Lord in his temple. We will sing with happy music every day of our lives. We will sing to thank the Lord in his temple. We will sing with happy music every day of our lives."
    },
    {
      "verse": "21",
      "text": "Now Isaiah had said this: ‘Take some figs to make a medicine and put it on Hezekiah's boil. Then he will get better. ’"
    },
    {
      "verse": "22",
      "text": "Hezekiah had asked, ‘What will show me that I will be able to go up to the Lord's temple? ’"
    }
  ],
  "39": [
    {
      "verse": "1",
      "text": "At that time, Baladan's son, Merodach-Baladan, was the king of Babylon. Merodach-Baladan sent letters and a gift to Hezekiah. He had heard the news that Hezekiah had been ill, but he was now better."
    },
    {
      "verse": "2",
      "text": "Hezekiah was happy to meet the officers who came from the king of Babylon. Hezekiah showed them the places where he stored his valuable things. He showed them all his silver and gold things, his spices and very valuable olive oil. He also showed them all his weapons. Hezekiah showed them all his valuable things. There was nothing in his palace or in his whole kingdom that he did not show to the king of Babylon's officers."
    },
    {
      "verse": "3",
      "text": "Then Isaiah the prophet went to King Hezekiah. Isaiah asked the king, ‘What did those men say? Where did they come from? ’ Hezekiah replied, ‘They came to me from Babylon, far away. ’"
    },
    {
      "verse": "4",
      "text": "Isaiah asked, ‘What did they see in your palace? ’ Hezekiah said, ‘They saw everything that is in my palace. I showed all my valuable things to them. ’"
    },
    {
      "verse": "5",
      "text": "Then Isaiah said to Hezekiah, ‘Listen to this message from the Lord Almighty:"
    },
    {
      "verse": "6",
      "text": "“Understand this! One day, soldiers from Babylon will carry away all your valuable things. Everything that you and your ancestors have stored here until now will go to Babylon. They will leave nothing here."
    },
    {
      "verse": "7",
      "text": "Some of your own descendants will also go to Babylon. Soldiers from Babylon will take them away from here. Your descendants will become eunuchs in the king of Babylon's palace. ” That is what the Lord says. ’"
    },
    {
      "verse": "8",
      "text": "Hezekiah said to Isaiah, ‘The Lord's message that you have spoken to me is good. ’But he was thinking, ‘While I am still alive, people will live safely without any trouble. ’"
    }
  ],
  "40": [
    {
      "verse": "1",
      "text": "Your God says, ‘Comfort my people. Yes, comfort them. Yes, comfort them."
    },
    {
      "verse": "2",
      "text": "Speak kindly to the people in Jerusalem. Tell them that their time of trouble has now finished. Their punishment has been enough. The Lord has made them pay for their sins. He has made them pay twice. ’ Tell them that their time of trouble has now finished. Their punishment has been enough. The Lord has made them pay for their sins. He has made them pay twice. ’"
    },
    {
      "verse": "3",
      "text": "Somebody's voice is shouting, ‘Prepare a way in the wilderness for the Lord. Make a straight road in the desert for our God. ‘Prepare a way in the wilderness for the Lord. Make a straight road in the desert for our God."
    },
    {
      "verse": "4",
      "text": "Raise up every valley, and bring down every mountain and hill. The rough ground and the ground that has rockswill become flat. and bring down every mountain and hill. The rough ground and the ground that has rocks will become flat."
    },
    {
      "verse": "5",
      "text": "Then the great glory of the Lord will appear! All people will see it at the same time. The Lord himself has promised this. ’ All people will see it at the same time. The Lord himself has promised this. ’"
    },
    {
      "verse": "6",
      "text": "A voice is saying, ‘Shout! ’But I say, ‘What should I shout? ’‘Shout that all people are like grass. Their promises are like the flowers in a field. But I say, ‘What should I shout? ’ ‘Shout that all people are like grass. Their promises are like the flowers in a field."
    },
    {
      "verse": "7",
      "text": "Grass quickly dies, and flowers fall to the ground. The Lord causes this to happen, when he sends a wind to blow on them. It is true. People are like grass. and flowers fall to the ground. The Lord causes this to happen, when he sends a wind to blow on them. It is true. People are like grass."
    },
    {
      "verse": "8",
      "text": "Grass quickly dies, and flowers fall to the ground. But God's promise will be true for ever. ’ and flowers fall to the ground. But God's promise will be true for ever. ’"
    },
    {
      "verse": "9",
      "text": "Zion, you have good news to tell to people! So go up onto a high mountain. Yes, Jerusalem, shout the good news! Shout aloud, and do not be afraid. Say to the towns in Judah, ‘Here is your God! ’ So go up onto a high mountain. Yes, Jerusalem, shout the good news! Shout aloud, and do not be afraid. Say to the towns in Judah, ‘Here is your God! ’"
    },
    {
      "verse": "10",
      "text": "Look! The Almighty Lord is coming with power. He will use his great strength to rule the people. Look again! He is bringing his gifts with him. He brings the prize that he has won in battle. He will use his great strength to rule the people. Look again! He is bringing his gifts with him. He brings the prize that he has won in battle."
    },
    {
      "verse": "11",
      "text": "He takes care of his people, like a shepherd who takes care of his sheep. He picks up the young lambsand he carries them near to his heart. He carefully leads the mother sheep that have lambs. like a shepherd who takes care of his sheep. He picks up the young lambs and he carries them near to his heart. He carefully leads the mother sheep that have lambs."
    },
    {
      "verse": "12",
      "text": "Nobody has done what God has done! He measured all the water of the seas in one hand. He used his hand to measure the whole sky. He carefully weighed the soil of the earth. He carefully weighed the mountains in his scales, and the hills too. He measured all the water of the seas in one hand. He used his hand to measure the whole sky. He carefully weighed the soil of the earth. He carefully weighed the mountains in his scales, and the hills too."
    },
    {
      "verse": "13",
      "text": "Nobody understands the mind of the Lord. Nobody can be his advisor, to tell him what he should do. Nobody can be his advisor, to tell him what he should do."
    },
    {
      "verse": "14",
      "text": "He does not ask anyone to be his guide. Nobody can teach him the proper way to do things. Nobody can give him knowledge. Nobody can teach him how to understand things. Nobody can teach him the proper way to do things. Nobody can give him knowledge. Nobody can teach him how to understand things."
    },
    {
      "verse": "15",
      "text": "The Lord looks at the nationsas if they are a little bit of water in a bucket. They are like dust on his scales. He weighs the islands as he would weigh dust. as if they are a little bit of water in a bucket. They are like dust on his scales. He weighs the islands as he would weigh dust."
    },
    {
      "verse": "16",
      "text": "All the trees from Lebanon's forests are not enoughto make a fire for his altar. All its animals are not enough to offer to himas burnt offerings. to make a fire for his altar. All its animals are not enough to offer to him as burnt offerings."
    },
    {
      "verse": "17",
      "text": "All the nations in the world are not important to the Lord. He sees them as empty and useless. He sees them as empty and useless."
    },
    {
      "verse": "18",
      "text": "You cannot find anyone else who is like God. There is no image that you can make to be like him. There is no image that you can make to be like him."
    },
    {
      "verse": "19",
      "text": "A worker may use special skill to make an idol. Another worker may cover it with gold. He may use silver chains to make it beautiful. Another worker may cover it with gold. He may use silver chains to make it beautiful."
    },
    {
      "verse": "20",
      "text": "A poor person may choose special wood for his idol. He chooses wood that will not quickly become spoiled. Then he finds a worker to make an idol for him. He makes it so that it will not fall over! He chooses wood that will not quickly become spoiled. Then he finds a worker to make an idol for him. He makes it so that it will not fall over!"
    },
    {
      "verse": "21",
      "text": "You must surely know what is true! You must have heard about it. Somebody must have told you these thingsfrom the beginning. You should have understood it allsince the time that God made the earth. You must have heard about it. Somebody must have told you these things from the beginning. You should have understood it all since the time that God made the earth."
    },
    {
      "verse": "22",
      "text": "God sits high above on his thronewhere the earth and the sky meet. The people on the earth seem like grasshoppers to him. He hangs out the sky like a curtain. He makes it like a tent for him to live in. where the earth and the sky meet. The people on the earth seem like grasshoppers to him. He hangs out the sky like a curtain. He makes it like a tent for him to live in."
    },
    {
      "verse": "23",
      "text": "He takes away the power of kings. He causes the rulers of the world to be useless. He causes the rulers of the world to be useless."
    },
    {
      "verse": "24",
      "text": "They are like plants that soon disappear. Somebody plants them in the ground. But while their roots are still growing into the soil, God blows on them and they become dry. Then the wind carries them away like straw. Somebody plants them in the ground. But while their roots are still growing into the soil, God blows on them and they become dry. Then the wind carries them away like straw."
    },
    {
      "verse": "25",
      "text": "The Holy God says, ‘You cannot find anyone who is like me. Nobody is the same as me. ’ ‘You cannot find anyone who is like me. Nobody is the same as me. ’"
    },
    {
      "verse": "26",
      "text": "Look up at the sky! Think about the one who made all the stars. God is the one who brought together that great army! He knows how many they areand he knows each of their names! When he calls them, each one is there, because he is so strong and powerful. Think about the one who made all the stars. God is the one who brought together that great army! He knows how many they are and he knows each of their names! When he calls them, each one is there, because he is so strong and powerful."
    },
    {
      "verse": "27",
      "text": "You Israelites, descendants of Jacob, say, ‘The Lord does not know about our troubles. He does not bring justice to us. ’Why do you say that? ‘The Lord does not know about our troubles. He does not bring justice to us. ’ Why do you say that?"
    },
    {
      "verse": "28",
      "text": "You must surely know what is true! You must have heard about it. The Lord is the God who lives for ever. He made the whole earth, near and far. He never becomes tired or weak. He knows and he understands everything. You must have heard about it. The Lord is the God who lives for ever. He made the whole earth, near and far. He never becomes tired or weak. He knows and he understands everything."
    },
    {
      "verse": "29",
      "text": "He makes tired people strong again. When people have become weak, he gives them more strength. When people have become weak, he gives them more strength."
    },
    {
      "verse": "30",
      "text": "Even young people become tired and weak. Even strong young men may slip and fall down. Even strong young men may slip and fall down."
    },
    {
      "verse": "31",
      "text": "But people who wait for the Lord to help themwill receive new strength. They will rise up high, as if they have the wings of eagles. They will run and they will not become tired. They will walk and they will not become weak."
    }
  ],
  "41": [
    {
      "verse": "1",
      "text": "‘You islands, be quiet as you listen to me. The nations need to come and stand in front of me. So they must be brave and speak to me. We must meet together to decide who is right. The nations need to come and stand in front of me. So they must be brave and speak to me. We must meet together to decide who is right."
    },
    {
      "verse": "2",
      "text": "Tell me, who has woken up that king in the east? Who has chosen that king to serve him? He has given that king power over many nations, so that the kings of those nations must obey him. He uses that king's weapons to destroy other nations. He blows them away like dust or straw. Who has chosen that king to serve him? He has given that king power over many nations, so that the kings of those nations must obey him. He uses that king's weapons to destroy other nations. He blows them away like dust or straw."
    },
    {
      "verse": "3",
      "text": "That king chases quickly after them, and nothing hurts him. His feet do not seem to touch the ground! and nothing hurts him. His feet do not seem to touch the ground!"
    },
    {
      "verse": "4",
      "text": "Tell me, who has caused these things to happen? Who has decided what should happen, from the beginning, century after century? It is I, the Lord! I was there at the beginning, and I will always be there, through to the end. Who has decided what should happen, from the beginning, century after century? It is I, the Lord! I was there at the beginning, and I will always be there, through to the end."
    },
    {
      "verse": "5",
      "text": "The people on the islands see what I am doing, and they are afraid. People all over the world shake with fear. They join together and they come near. and they are afraid. People all over the world shake with fear. They join together and they come near."
    },
    {
      "verse": "6",
      "text": "They help each other, and they say to one another, “Be strong! ” ’ and they say to one another, “Be strong! ” ’"
    },
    {
      "verse": "7",
      "text": "The man who makes things with wood speaks to the man who works with gold and the man who works with iron. They help each other to work well. They say, ‘We have done a good job. ’ Then they use nails to fix the idol that they have made, so that it does not fall over!"
    },
    {
      "verse": "8",
      "text": "‘But you, Israel, are my servant. Yes, I have chosen you, descendants of Jacob. You are descendants of my friend, Abraham. Yes, I have chosen you, descendants of Jacob. You are descendants of my friend, Abraham."
    },
    {
      "verse": "9",
      "text": "I led you back from the ends of the earth. I called you to come from places far away. I have said to you, “You are my servant. I have chosen you. I have not thrown you away. I called you to come from places far away. I have said to you, “You are my servant. I have chosen you. I have not thrown you away."
    },
    {
      "verse": "10",
      "text": "I am with you, so do not be afraid. I am your God, so do not be upset. I will make you strongand I will help you. My powerful right hand will keep you safe. ” so do not be afraid. I am your God, so do not be upset. I will make you strong and I will help you. My powerful right hand will keep you safe. ”"
    },
    {
      "verse": "11",
      "text": "Listen to this! Everyone who has been angry with youwill now become completely ashamed. Those who have attacked you will disappear and die. will now become completely ashamed. Those who have attacked you will disappear and die."
    },
    {
      "verse": "12",
      "text": "Even if you look for your enemies, you will not find them. They will all disappear! you will not find them. They will all disappear!"
    },
    {
      "verse": "13",
      "text": "Yes, I am the Lord, your God. I will hold on to your right hand. I say to you, “Do not be afraid. I will help you. ” I will hold on to your right hand. I say to you, “Do not be afraid. I will help you. ”"
    },
    {
      "verse": "14",
      "text": "Do not be afraid, you Israelites, descendants of Jacob. You may seem unimportant, like a worm, but I myself will help you. ’That is what the Lord says. He is your Redeemer, the Holy God of Israel. You may seem unimportant, like a worm, but I myself will help you. ’ That is what the Lord says. He is your Redeemer, the Holy God of Israel."
    },
    {
      "verse": "15",
      "text": "‘Look at this! I will cause you to destroy your enemies, like a heavy weight that threshes grain. You will have new sharp metal points that are like teeth. You will thresh the mountainsand you will break them into pieces. You will make the hills become like straw. like a heavy weight that threshes grain. You will have new sharp metal points that are like teeth. You will thresh the mountains and you will break them into pieces. You will make the hills become like straw."
    },
    {
      "verse": "16",
      "text": "You will throw them into the air, and the wind will blow them away in all directions! You will be happy with what the Lord has done for you. You will boast that the Holy God of Israel is your God. and the wind will blow them away in all directions! You will be happy with what the Lord has done for you. You will boast that the Holy God of Israel is your God."
    },
    {
      "verse": "17",
      "text": "Poor and helpless people look for water to drink, but there is none. They are so thirsty that their tongues are dry. But I, the Lord, will answer their prayers. I, the God of Israel, will not leave them alone. but there is none. They are so thirsty that their tongues are dry. But I, the Lord, will answer their prayers. I, the God of Israel, will not leave them alone."
    },
    {
      "verse": "18",
      "text": "I will make rivers run over the dry hills. I will make springs of water in the valleys. I will make pools of water in the desert. The dry land will become a place of streams. I will make springs of water in the valleys. I will make pools of water in the desert. The dry land will become a place of streams."
    },
    {
      "verse": "19",
      "text": "Many trees will grow in the wilderness. Cedar, acacia, myrtle and olive trees will grow there. In the dry valleysthere will be pine, fir and cypress trees. Cedar, acacia, myrtle and olive trees will grow there. In the dry valleys there will be pine, fir and cypress trees."
    },
    {
      "verse": "20",
      "text": "I will do this so that people see it happen. They will watch carefully and they will understand. They will know that the Lord's powerhas caused it to happen. They will know that the Holy God of Israelhas created it. ’ They will watch carefully and they will understand. They will know that the Lord's power has caused it to happen. They will know that the Holy God of Israel has created it. ’"
    },
    {
      "verse": "21",
      "text": "The Lord, Israel's King, says, ‘Come and show me what you can do! Tell me clearly what power you have! ‘Come and show me what you can do! Tell me clearly what power you have!"
    },
    {
      "verse": "22",
      "text": "Bring your idols into court. Let them tell us what will happen in future years. Let them tell us what happened in the past. Then we can think about those things. We will understand what happened in the end. Or ask them to tell us about future events! Let them tell us what will happen in future years. Let them tell us what happened in the past. Then we can think about those things. We will understand what happened in the end. Or ask them to tell us about future events!"
    },
    {
      "verse": "23",
      "text": "If they can tell us what will happen in future years, we will know that they really are gods. Tell them to do something, a good thing or a bad thing. That would really surprise us, or even frighten us! we will know that they really are gods. Tell them to do something, a good thing or a bad thing. That would really surprise us, or even frighten us!"
    },
    {
      "verse": "24",
      "text": "But no! Your idols are useless. There is nothing that they can do. Anybody who chooses to worship themhas turned against God! There is nothing that they can do. Anybody who chooses to worship them has turned against God!"
    },
    {
      "verse": "25",
      "text": "I have woken up a ruler, who is coming with his army from the north. He comes from a land in the east, where the sun rises, and he will use my name to call to me. He will walk over rulers of other nationsas if they are mud. He will push them down with his feet, like a potter who prepares his clay. who is coming with his army from the north. He comes from a land in the east, where the sun rises, and he will use my name to call to me. He will walk over rulers of other nations as if they are mud. He will push them down with his feet, like a potter who prepares his clay."
    },
    {
      "verse": "26",
      "text": "Tell me, who decided in the beginning, that all these things must happen? Who told us about them before they happened? Then we could say, “He was right! ”None of your idols said anything about it! Nobody heard them say a word! that all these things must happen? Who told us about them before they happened? Then we could say, “He was right! ” None of your idols said anything about it! Nobody heard them say a word!"
    },
    {
      "verse": "27",
      "text": "I, the Lord, was the first personto tell the good news to Zion. I sent someone to Jerusalem to say, “Look, they have arrived! ” to tell the good news to Zion. I sent someone to Jerusalem to say, “Look, they have arrived! ”"
    },
    {
      "verse": "28",
      "text": "I looked among your idols, to see who might be a good advisor. But none of them could help. None of them could answer my questions. to see who might be a good advisor. But none of them could help. None of them could answer my questions."
    },
    {
      "verse": "29",
      "text": "Look! All the idols are useless. They can do nothing. Their images are as weak as a breath of wind. ’"
    }
  ],
  "42": [
    {
      "verse": "1",
      "text": "‘Here is my servant. I give him strength. I have chosen him. He makes me very happy. I have put my Spirit on him. He will bring justice to the nations. I give him strength. I have chosen him. He makes me very happy. I have put my Spirit on him. He will bring justice to the nations."
    },
    {
      "verse": "2",
      "text": "He will not cry out. He will not shout. He will not speak loudly in the streets. He will not shout. He will not speak loudly in the streets."
    },
    {
      "verse": "3",
      "text": "He will not hurt weak people, like someone who breaks a weak reed. He will not destroy helpless people, like someone who puts out a weak flame. He will be kind to people, and he will judge them in a fair way. like someone who breaks a weak reed. He will not destroy helpless people, like someone who puts out a weak flame. He will be kind to people, and he will judge them in a fair way."
    },
    {
      "verse": "4",
      "text": "He will remain strong and brave, until he brings justice to the whole world. People who are in lands far awaywill wait for him to teach them. ’ until he brings justice to the whole world. People who are in lands far away will wait for him to teach them. ’"
    },
    {
      "verse": "5",
      "text": "The Lord is God. He is the God who created the sky. He hung it up like a curtain. He created the earth and everything that lives on it. He gives life and breath to all the people who live on it. The Lord says to his servant:"
    },
    {
      "verse": "6",
      "text": "‘I have chosen you to bring righteousness. I will take hold of your hand, and I will keep you safe. Through you, I will make a covenant with my people, and you will bring light to the other nations. I will take hold of your hand, and I will keep you safe. Through you, I will make a covenant with my people, and you will bring light to the other nations."
    },
    {
      "verse": "7",
      "text": "You will cause blind people to see. You will cause prisoners to be free. You will bring out into the openpeople who sit in dark prisons. You will cause prisoners to be free. You will bring out into the open people who sit in dark prisons."
    },
    {
      "verse": "8",
      "text": "I am the Lord. That is my name. I will not let anyone else share my glory. I will not let people praise idols. I am the only one that they must praise. I will not let anyone else share my glory. I will not let people praise idols. I am the only one that they must praise."
    },
    {
      "verse": "9",
      "text": "Everything that I promised in the past has happenedas I said that it would happen. Now I will tell you about new things. Before they start to happen, I will tell you about them. ’ as I said that it would happen. Now I will tell you about new things. Before they start to happen, I will tell you about them. ’"
    },
    {
      "verse": "10",
      "text": "Sing a new song to the Lord! All over the earth, people should praise him. Praise him, you people who travel over the seaand everything that lives in the sea. Praise him, you people who live in lands far away. All over the earth, people should praise him. Praise him, you people who travel over the sea and everything that lives in the sea. Praise him, you people who live in lands far away."
    },
    {
      "verse": "11",
      "text": "People who live in the towns of the desertshould shout aloud to praise him. Kedar's people should praise himin the places where they live. The people who live in Sela should sing aloud with joy. They should shout from the tops of the mountains. should shout aloud to praise him. Kedar's people should praise him in the places where they live. The people who live in Sela should sing aloud with joy. They should shout from the tops of the mountains."
    },
    {
      "verse": "12",
      "text": "They should all honour the Lordas he deserves. Those who live in lands far awayshould praise him for what he has done. as he deserves. Those who live in lands far away should praise him for what he has done."
    },
    {
      "verse": "13",
      "text": "The Lord marches out to battle, like a brave soldier. He is angry with his enemies, and he is ready to attack them. He shouts loudly as he attacks, and he shows his power over them. like a brave soldier. He is angry with his enemies, and he is ready to attack them. He shouts loudly as he attacks, and he shows his power over them."
    },
    {
      "verse": "14",
      "text": "The Lord says, ‘I have been quiet for a long time. I have held back my anger. But now I am ready to deliver! I will cry out and shout and groan, like a woman who is ready to give birth. ‘I have been quiet for a long time. I have held back my anger. But now I am ready to deliver! I will cry out and shout and groan, like a woman who is ready to give birth."
    },
    {
      "verse": "15",
      "text": "I will destroy the mountains and the hills. I will cause the plants that grow on them to die. I will cause the rivers to become dry islands. I will cause the pools of water to become dry. I will cause the plants that grow on them to die. I will cause the rivers to become dry islands. I will cause the pools of water to become dry."
    },
    {
      "verse": "16",
      "text": "I will lead my blind peoplealong ways that they did not know before. I will be their guide, as they walk along paths that are new to them. I will change the dark places that are in front of them, so that they become places with light. And I will cause the rough ground to become flat. Those are the things that I will do for them. I will not leave my people alone. along ways that they did not know before. I will be their guide, as they walk along paths that are new to them. I will change the dark places that are in front of them, so that they become places with light. And I will cause the rough ground to become flat. Those are the things that I will do for them. I will not leave my people alone."
    },
    {
      "verse": "17",
      "text": "But I will push away people who trust idols to help them. Those people will become ashamed. They say to images that they have made, “You are our gods. ” Those people will become ashamed. They say to images that they have made, “You are our gods. ”"
    },
    {
      "verse": "18",
      "text": "Listen to me, you deaf people! Look at this, you blind people! Look at this, you blind people!"
    },
    {
      "verse": "19",
      "text": "Who is blind? Nobody is as blind as my servant. Who is deaf? Nobody is as deaf as the one who takes my message. The people that I agreed a covenant with are blind! Yes, the servant of the Lord is truly blind! Nobody is as blind as my servant. Who is deaf? Nobody is as deaf as the one who takes my message. The people that I agreed a covenant with are blind! Yes, the servant of the Lord is truly blind!"
    },
    {
      "verse": "20",
      "text": "You Israelites have seen many things, but you do not understand them. You have opened your ears to listen, but you have not really heard anything. ’ but you do not understand them. You have opened your ears to listen, but you have not really heard anything. ’"
    },
    {
      "verse": "21",
      "text": "The Lord always does what is right. So he has made his law great and important. He is happy when people respect his law."
    },
    {
      "verse": "22",
      "text": "But enemies have robbed God's people and they have taken away all their valuable things. Their enemies have caught them in traps and they have made them prisoners. There is nobody who will rescue them. Their enemies have stored them safely, and nobody says, ‘Send them back. ’"
    },
    {
      "verse": "23",
      "text": "Will any of you listen to my message? Will you think carefully about it in the future? Will you think carefully about it in the future?"
    },
    {
      "verse": "24",
      "text": "Who put Jacob's descendantsunder the power of their enemies? Who gave the Israelitesto people who would rob them? It was the Lord! He is the one that we have not obeyed. His people did not live in the way that he wanted. They did not obey his law. under the power of their enemies? Who gave the Israelites to people who would rob them? It was the Lord! He is the one that we have not obeyed. His people did not live in the way that he wanted. They did not obey his law."
    },
    {
      "verse": "25",
      "text": "So the Lord was very angry with them. He punished them with a cruel war. His anger was like a fire all round them, but they did not understand what he was doing. His anger burned them, but they did not learn their lesson."
    }
  ],
  "43": [
    {
      "verse": "1",
      "text": "Israelites, descendants of Jacob, the Lord created you, and he made you who you are. Now he says this to you:‘Do not be afraid, I have rescued you to belong to me. I have called you by your name, so now you are mine. ‘Do not be afraid, I have rescued you to belong to me. I have called you by your name, so now you are mine."
    },
    {
      "verse": "2",
      "text": "When you go through deep water, I will be with you. When you cross dangerous rivers, you will not drown. When you walk through fire, it will not burn you. The flames will not destroy you. I will be with you. When you cross dangerous rivers, you will not drown. When you walk through fire, it will not burn you. The flames will not destroy you."
    },
    {
      "verse": "3",
      "text": "I am the Lord, your God, so I will rescue you. I am Israel's Holy God, your Saviour. I gave Egypt as the price to buy you back. I gave Ethiopia and Seba to their enemies, so that you could be free. so I will rescue you. I am Israel's Holy God, your Saviour. I gave Egypt as the price to buy you back. I gave Ethiopia and Seba to their enemies, so that you could be free."
    },
    {
      "verse": "4",
      "text": "You are very valuable to me. You are my special people, and I love you. So I will give other people to their enemies, to keep your lives safe. Other nations will pay the price, instead of you. You are my special people, and I love you. So I will give other people to their enemies, to keep your lives safe. Other nations will pay the price, instead of you."
    },
    {
      "verse": "5",
      "text": "I am with you, so do not be afraid. I will bring your descendants from the east. I will also bring you together from the west. so do not be afraid. I will bring your descendants from the east. I will also bring you together from the west."
    },
    {
      "verse": "6",
      "text": "I will say to people in the north, “Give them back! ”And I will say to people in the south, “Do not stop them! ”Bring my sons from places that are far away. Bring my daughters from the ends of the earth. “Give them back! ” And I will say to people in the south, “Do not stop them! ” Bring my sons from places that are far away. Bring my daughters from the ends of the earth."
    },
    {
      "verse": "7",
      "text": "Bring back everyone who belongs to me. I created them, so that they would bring honour to me. I made them who they are. Yes, I made them! I created them, so that they would bring honour to me. I made them who they are. Yes, I made them!"
    },
    {
      "verse": "8",
      "text": "So bring the people to me. They have eyes, but they are blind! They have ears, but they are deaf! They have eyes, but they are blind! They have ears, but they are deaf!"
    },
    {
      "verse": "9",
      "text": "Tell the people of all nations to come together. Did any of their gods tell us what would happen? If anyone heard them speak the truth, they should bring those people to this court. Then they can tell us that they were right. People could say, “They spoke the truth. ” ’ Did any of their gods tell us what would happen? If anyone heard them speak the truth, they should bring those people to this court. Then they can tell us that they were right. People could say, “They spoke the truth. ” ’"
    },
    {
      "verse": "10",
      "text": "The Lord says to his people, ‘You are the people who must say that I am right. I have chosen you as my servant. I chose you so that you may know me, and also believe in me. Then you would understand that I am the true God. There has never been any other god except me, and there never will be. ‘You are the people who must say that I am right. I have chosen you as my servant. I chose you so that you may know me, and also believe in me. Then you would understand that I am the true God. There has never been any other god except me, and there never will be."
    },
    {
      "verse": "11",
      "text": "I am the Lord, I alone. There is no other saviour, except me. There is no other saviour, except me."
    },
    {
      "verse": "12",
      "text": "I promised to save you, and I did what I said I would do. I told everyone what I had done. There was no foreign god among you, who did that for you. So you are the people who must saythat I am the only true God. ’That is what the Lord says. and I did what I said I would do. I told everyone what I had done. There was no foreign god among you, who did that for you. So you are the people who must say that I am the only true God. ’ That is what the Lord says."
    },
    {
      "verse": "13",
      "text": "‘Today and every day, I am God. If I hold you in my hand, nobody can take you away from my power. When I do something, nobody can change it. ’ If I hold you in my hand, nobody can take you away from my power. When I do something, nobody can change it. ’"
    },
    {
      "verse": "14",
      "text": "The Lord is your Redeemer, Israel's Holy God. He says this:‘I will send an army to attack Babylon, so that you, my people, will be safe. I will cause all the Babylonians to run away. They were proud of their great ships, but now they will use them to escape from their enemies. ‘I will send an army to attack Babylon, so that you, my people, will be safe. I will cause all the Babylonians to run away. They were proud of their great ships, but now they will use them to escape from their enemies."
    },
    {
      "verse": "15",
      "text": "I am the Lord, your Holy God. I am the one who created Israel. I am your King. ’ I am the one who created Israel. I am your King. ’"
    },
    {
      "verse": "16",
      "text": "The Lord is the one who made a road through the sea for you to cross. You went on a dry path in the middle of the deep water."
    },
    {
      "verse": "17",
      "text": "He led the enemy's great army, with their chariots and their horses, to chase you. They all fell down and the water drowned them. Their lives finished, like the flame of a lamp that stops burning."
    },
    {
      "verse": "18",
      "text": "The Lord did all that for you, but now he says, ‘Forget those things that happened a long time ago. Do not think about past events. ‘Forget those things that happened a long time ago. Do not think about past events."
    },
    {
      "verse": "19",
      "text": "Look! Now I will do something that is new! It is already beginning to happen. Surely, you can recognize it. Yes, I will make a road through the desert. I will make streams in the wilderness. It is already beginning to happen. Surely, you can recognize it. Yes, I will make a road through the desert. I will make streams in the wilderness."
    },
    {
      "verse": "20",
      "text": "The wild animals in the desert praise me, including the jackals and the owls. They praise me because I put water in the desert, and streams in the wilderness. I am giving water to the people that I have chosen, so that they will not be thirsty. including the jackals and the owls. They praise me because I put water in the desert, and streams in the wilderness. I am giving water to the people that I have chosen, so that they will not be thirsty."
    },
    {
      "verse": "21",
      "text": "They are the people that I made for myself, so that they would praise me aloud. so that they would praise me aloud."
    },
    {
      "verse": "22",
      "text": "But you Israelites, Jacob's descendants, you did not call to me to help you. You became tired of serving me. you did not call to me to help you. You became tired of serving me."
    },
    {
      "verse": "23",
      "text": "You did not bring sheep to me as burnt offerings. You did not make sacrifices to me, to show that you respect me. I did not make it difficult for you, when I asked you to bring offerings to me. When I asked you to burn incense to worship me, that should not have made you tired. You did not make sacrifices to me, to show that you respect me. I did not make it difficult for you, when I asked you to bring offerings to me. When I asked you to burn incense to worship me, that should not have made you tired."
    },
    {
      "verse": "24",
      "text": "You did not buy any spicesto offer them to me. You did not bring me the fat from your sacrificesto make me happy. Instead, you have made it difficult for me, because of all your sins. All the evil things that you dohave caused me to become very tired. to offer them to me. You did not bring me the fat from your sacrifices to make me happy. Instead, you have made it difficult for me, because of all your sins. All the evil things that you do have caused me to become very tired."
    },
    {
      "verse": "25",
      "text": "But I am the one who removes your sinswhen you do not obey me. I, the Lord, do that, because of who I am. I do not hold your sins in my mind. when you do not obey me. I, the Lord, do that, because of who I am. I do not hold your sins in my mind."
    },
    {
      "verse": "26",
      "text": "So let us talk together about what has happened. Show me why you think that you are right! Show me why you think that you are right!"
    },
    {
      "verse": "27",
      "text": "Your first ancestor did not obey me. Your leaders and teachers turned against me. Your leaders and teachers turned against me."
    },
    {
      "verse": "28",
      "text": "So I caused the priests of your templeto become ashamed. I caused enemies to destroy Israel. I let them insult Jacob's descendants. ’"
    }
  ],
  "44": [
    {
      "verse": "1",
      "text": "‘Israelites, Jacob's descendants, listen to me! I have chosen you to be my servant. ’ I have chosen you to be my servant. ’"
    },
    {
      "verse": "2",
      "text": "The Lord created you. Before you were born, he was already taking care of you. He will continue to help you. He says to you, ‘Do not be afraid, my servant, Jacob. I call you “Jeshurun”, and I have chosen you to belong to me. ‘Do not be afraid, my servant, Jacob. I call you “Jeshurun”, and I have chosen you to belong to me."
    },
    {
      "verse": "3",
      "text": "I will pour water onto land that is thirsty. I will pour streams of water on the dry ground. I will pour out my Spirit on your descendants, and I will bless them. I will pour streams of water on the dry ground. I will pour out my Spirit on your descendants, and I will bless them."
    },
    {
      "verse": "4",
      "text": "They will grow up like fresh grass in a field. They will grow like willow trees beside a river. They will grow like willow trees beside a river."
    },
    {
      "verse": "5",
      "text": "Someone will say, “I belong to the Lord. ”Another person will call himself by the name “Jacob”. Someone else will write on his hand, “I am the Lord's”, and he will call himself “Israel”. ’ Another person will call himself by the name “Jacob”. Someone else will write on his hand, “I am the Lord's”, and he will call himself “Israel”. ’"
    },
    {
      "verse": "6",
      "text": "The Lord is Israel's King and Redeemer. He is the Lord Almighty. He says, ‘I am the first and I am the last. There is no God, except me. ‘I am the first and I am the last. There is no God, except me."
    },
    {
      "verse": "7",
      "text": "Is there anyone like me? If there is, he should say so! He must tell me why he thinks he is so great. Long ago I made my people become a nation. Let him say what he has done since then! Let him tell us what will happen in future years! He must tell me why he thinks he is so great. Long ago I made my people become a nation. Let him say what he has done since then! Let him tell us what will happen in future years!"
    },
    {
      "verse": "8",
      "text": "My people, do not shake with fear. Long ago I told you about things that would happen. You can tell people the truth about me. You know that I am the only true God. There is no other Rock to keep you safe. There surely is no other God except me. ’ Long ago I told you about things that would happen. You can tell people the truth about me. You know that I am the only true God. There is no other Rock to keep you safe. There surely is no other God except me. ’"
    },
    {
      "verse": "9",
      "text": "All the people who make idols are fools. The images which make them so happy are useless. Those who worship idols cannot see the truth. They do not understand what they are doing, and they will be ashamed. The images which make them so happy are useless. Those who worship idols cannot see the truth. They do not understand what they are doing, and they will be ashamed."
    },
    {
      "verse": "10",
      "text": "Only a fool makes an idol and thinks that it is his god. An image cannot help him. An image cannot help him."
    },
    {
      "verse": "11",
      "text": "Those who work with him will all be ashamed. Those workers with special skills are only human. They should come together, and they should stand in front of me. That will make them very frightened. They will realize how foolish they are! Those workers with special skills are only human. They should come together, and they should stand in front of me. That will make them very frightened. They will realize how foolish they are!"
    },
    {
      "verse": "12",
      "text": "This is how they make their idols: A man who works with iron takes his tool. He makes the metal hot in the fire. Then he uses hammers to hit it with his strong arms. He hits it so that it has the right shape. But then he becomes hungry. He is too weak to work any more. He does not drink any water and so he feels tired. A man who works with iron takes his tool. He makes the metal hot in the fire. Then he uses hammers to hit it with his strong arms. He hits it so that it has the right shape. But then he becomes hungry. He is too weak to work any more. He does not drink any water and so he feels tired."
    },
    {
      "verse": "13",
      "text": "A carpenter measures a piece of wood. Then he draws a shape for the image. He uses his tools to cut the wood. He carefully makes it have the right shape. He makes the image have the shape of a human. It looks like a beautiful person. Now it is ready to go in its special room."
    },
    {
      "verse": "14",
      "text": "He may cut down cedar trees to make something. He may cut down a cypress tree, or an oak tree. He takes these trees from the forest. Or he may plant his own pine tree, so that the rain helps it to grow well."
    },
    {
      "verse": "15",
      "text": "He uses some of the wood to burn. He makes himself warm beside the fire. He may light a fire and then he may bake bread on it. Then he uses some of the wood to make a god that he will worship! Yes, he makes an idol, and he bends down in front of it."
    },
    {
      "verse": "16",
      "text": "Half of the wood he burns in the fire. He uses it to cook his meat, and he eats plenty of food. He makes himself warm and he says, ‘Good! Now I am warm as I look at the fire. ’"
    },
    {
      "verse": "17",
      "text": "He uses the rest of the wood to make an idol to be his god. He bends down in front of it and he worships it. He prays to it and he says, ‘Save me, because you are my god! ’"
    },
    {
      "verse": "18",
      "text": "People like that are stupid. They do not understand anything. They cannot see the truth, as if they are blind. Their minds cannot think properly."
    },
    {
      "verse": "19",
      "text": "None of them think carefully about what they are doing. They do not say to themselves, ‘I burned half of the wood in the fire. I even baked bread and I cooked meat on it. It gave me food to eat. Then I used the rest of the wood to make a useless idol! I took a piece of wood and I worshipped it! Why did I do that? ’"
    },
    {
      "verse": "20",
      "text": "Someone like that is stupid enough to eat ashes. His mind has deceived him. He cannot save himself from his lies. He will not say to himself, ‘This thing that I hold in my right hand is completely false! ’"
    },
    {
      "verse": "21",
      "text": "The Lord says:‘Jacob's descendants, remember these things, because you, Israel, are my servant. I created you to be my servant. Israel, I will not forget you. ‘Jacob's descendants, remember these things, because you, Israel, are my servant. I created you to be my servant. Israel, I will not forget you."
    },
    {
      "verse": "22",
      "text": "I have removed the guilt of your sins, like the wind blows away a cloud. When you turned against me, I have quickly forgiven you. Return to me now, because I have rescued you. ’ like the wind blows away a cloud. When you turned against me, I have quickly forgiven you. Return to me now, because I have rescued you. ’"
    },
    {
      "verse": "23",
      "text": "Sing aloud with joy, you heavens above us, because the Lord has done it! Shout as loudly as you can, places deep below the earth. You mountains, sing with joy, and you forests and trees as well! Be happy, because the Lord has redeemed his people. He has rescued the Israelites, Jacob's descendants, to show how great he is. because the Lord has done it! Shout as loudly as you can, places deep below the earth. You mountains, sing with joy, and you forests and trees as well! Be happy, because the Lord has redeemed his people. He has rescued the Israelites, Jacob's descendants, to show how great he is."
    },
    {
      "verse": "24",
      "text": "The Lord is your Redeemer. He took care of you before you were born. He says, ‘I am the Lord. I made everything. I alone hung up the sky like a curtain. I made the whole earth by myself. ‘I am the Lord. I made everything. I alone hung up the sky like a curtain. I made the whole earth by myself."
    },
    {
      "verse": "25",
      "text": "I show that the false prophets speak useless messages. I show that those who use magic to say what will happen are fools. I cause the ideas of wise people to become useless. People think that their advice is foolish. I show that those who use magic to say what will happen are fools. I cause the ideas of wise people to become useless. People think that their advice is foolish."
    },
    {
      "verse": "26",
      "text": "But I do the things that my servants say will happen. I show that my prophets' messages are true. I say about Jerusalem, “People will live there again. ”I say about the towns in Judah, “I will cause people to build them again, so that they are no longer heaps of stones. ” I show that my prophets' messages are true. I say about Jerusalem, “People will live there again. ” I say about the towns in Judah, “I will cause people to build them again, so that they are no longer heaps of stones. ”"
    },
    {
      "verse": "27",
      "text": "I say to the deep sea, “Become dry! ”and its streams become dry. and its streams become dry."
    },
    {
      "verse": "28",
      "text": "I say about King Cyrus, “He is my shepherd. He will do what I want him to do. ”He will give a command about Jerusalem. He will say, “Build the city again! ”He will say about the temple, “Build its foundation. ” ’"
    }
  ],
  "45": [
    {
      "verse": "1",
      "text": "The Lord says this to Cyrus, the king that he has chosen to serve him:‘I hold your right hand. I give you power over other nations, to take away the weapons of their kings. I will open the gates of cities in front of you, and they will stay open. ‘I hold your right hand. I give you power over other nations, to take away the weapons of their kings. I will open the gates of cities in front of you, and they will stay open."
    },
    {
      "verse": "2",
      "text": "I will go in front of you, and I will make the mountains flat. I will break bronze gates into pieces, and I will cut through iron bars. and I will make the mountains flat. I will break bronze gates into pieces, and I will cut through iron bars."
    },
    {
      "verse": "3",
      "text": "I will take valuable things that people have stored in secret places, and I will give them to you. Then you will know that I am the Lord, Israel's God. I am the one who calls you by your name. and I will give them to you. Then you will know that I am the Lord, Israel's God. I am the one who calls you by your name."
    },
    {
      "verse": "4",
      "text": "I have called you on behalf of my people, to help my servant, Jacob's descendants. They are Israel's people, that I have chosen for myself. You do not know me as your God, but I have given to you an important name. to help my servant, Jacob's descendants. They are Israel's people, that I have chosen for myself. You do not know me as your God, but I have given to you an important name."
    },
    {
      "verse": "5",
      "text": "I am the Lord and there is nobody else like me. There is no other God, except me. You do not know me as your God, but I will make you strong to fight battles. There is no other God, except me. You do not know me as your God, but I will make you strong to fight battles."
    },
    {
      "verse": "6",
      "text": "Then all over the world, from east to west, people will know that there is no other God. Yes, I am the Lordand there is nobody else like me. people will know that there is no other God. Yes, I am the Lord and there is nobody else like me."
    },
    {
      "verse": "7",
      "text": "I make light and I also make darkness. I make peace as well as trouble. I am the Lord. I do all these things. I make peace as well as trouble. I am the Lord. I do all these things."
    },
    {
      "verse": "8",
      "text": "Let justice pour down from the sky like rain! Let the earth be ready to receive it! Then salvation and righteousness will grow together, like strong plants. I am the Lord, and I will cause it to happen. ’ Let the earth be ready to receive it! Then salvation and righteousness will grow together, like strong plants. I am the Lord, and I will cause it to happen. ’"
    },
    {
      "verse": "9",
      "text": "It will be very bad for people who quarrel with their Maker. They are like pieces of a pot that are lying on the ground among all the other pieces. The clay does not say to the potter, ‘What do you think you are you making? ’ The pot does not say to the potter, ‘Your work is useless! ’"
    },
    {
      "verse": "10",
      "text": "It will be very bad for people who say to their fathers, ‘What kind of child have you become a father to? ’ And it will be bad for people who say to their mothers, ‘What kind of baby are you giving birth to? ’"
    },
    {
      "verse": "11",
      "text": "The Lord is Israel's Holy God. He is the one who created Israel. He says this about the things that will happen:‘You should not ask me questions about my children. You should not tell me what to dowith the people that I have made ‘You should not ask me questions about my children. You should not tell me what to do with the people that I have made"
    },
    {
      "verse": "12",
      "text": "It is I who made the earth. I created the people who live on it. I hung up the sky like a curtain. I did that with my own hands! I put all the stars in their places. I created the people who live on it. I hung up the sky like a curtain. I did that with my own hands! I put all the stars in their places."
    },
    {
      "verse": "13",
      "text": "Now I have woken up Cyrusto do for me things that are right. I will make all his paths easy to travel on. He will build again my city, and he will make my people free to return home. Nobody will have to pay him any moneyor give him a bribe to do that. ’That is what the Lord Almighty says. to do for me things that are right. I will make all his paths easy to travel on. He will build again my city, and he will make my people free to return home. Nobody will have to pay him any money or give him a bribe to do that. ’ That is what the Lord Almighty says."
    },
    {
      "verse": "14",
      "text": "This is what the Lord says to his people:‘I promise you that you will rule Egypt and Ethiopia, and also those tall people from Seba. They will bring to you the things that they buy and sell. Those valuable things will belong to you. They will walk behind you in chains, as your slaves. They will bend down low in front of you, and they will even pray to you. They will agree, “Surely God is with you. There is nobody else like him. There is no other God. ” ’ ‘I promise you that you will rule Egypt and Ethiopia, and also those tall people from Seba. They will bring to you the things that they buy and sell. Those valuable things will belong to you. They will walk behind you in chains, as your slaves. They will bend down low in front of you, and they will even pray to you. They will agree, “Surely God is with you. There is nobody else like him. There is no other God. ” ’"
    },
    {
      "verse": "15",
      "text": "Yes, you are a God who hides yourself! You are Israel's God, our Saviour! You are Israel's God, our Saviour!"
    },
    {
      "verse": "16",
      "text": "People who make idols will all become ashamed. People will insult them as they leave together. People will insult them as they leave together."
    },
    {
      "verse": "17",
      "text": "The Lord will make Israel safe. Israel will be safe and free for ever. You will never be ashamed again. People will never insult you again. Israel will be safe and free for ever. You will never be ashamed again. People will never insult you again."
    },
    {
      "verse": "18",
      "text": "The Lord created the heavens. He is the true God. He created the earth and he put it in its place. He built it to be strong. He did not create it as an empty place. He made it for people to live there. He says, ‘I am the Lord. There is nobody else who is like me. ‘I am the Lord. There is nobody else who is like me."
    },
    {
      "verse": "19",
      "text": "I have not spoken secretly, as I hid in a dark place. I did not say to Jacob's descendants, “Look for me, but you will not find me. ”I am the Lord. I speak what is right. My message is true. as I hid in a dark place. I did not say to Jacob's descendants, “Look for me, but you will not find me. ” I am the Lord. I speak what is right. My message is true."
    },
    {
      "verse": "20",
      "text": "So come, you people of the nations, you who have escaped from war. Bring yourselves in front of me together! People who carry wooden idols are fools! They pray to gods who cannot rescue them. you who have escaped from war. Bring yourselves in front of me together! People who carry wooden idols are fools! They pray to gods who cannot rescue them."
    },
    {
      "verse": "21",
      "text": "Now decide together what you will say in court! Tell me what you think! Who said a long time ago what would happen? Who spoke about it long before it happened? It was I, the Lord! There is nobody else like me. There is no other God, except me. I am a righteous God and I save my people. There is no other God. Tell me what you think! Who said a long time ago what would happen? Who spoke about it long before it happened? It was I, the Lord! There is nobody else like me. There is no other God, except me. I am a righteous God and I save my people. There is no other God."
    },
    {
      "verse": "22",
      "text": "So turn to me and I will make you safe. I say that to everybody all over the world. Turn to me, because I am God. There is nobody else like me. I say that to everybody all over the world. Turn to me, because I am God. There is nobody else like me."
    },
    {
      "verse": "23",
      "text": "This is my promise that I say is true. I have spoken it honestly and I will not change it. I promise this: Everybody will go down on their knees in front of me. Everybody will promise to serve me. I have spoken it honestly and I will not change it. I promise this: Everybody will go down on their knees in front of me. Everybody will promise to serve me."
    },
    {
      "verse": "24",
      "text": "They will all say this about me:“The Lord alone is true and strong. ” ’Everybody who has been angry with God will come to him. They will be ashamed that they were angry. “The Lord alone is true and strong. ” ’ Everybody who has been angry with God will come to him. They will be ashamed that they were angry."
    },
    {
      "verse": "25",
      "text": "The Lord will bring justicefor all the descendants of Israel. They will say that the Lord is great!"
    }
  ],
  "46": [
    {
      "verse": "1",
      "text": "Bel bends down to the ground. Nebo lies down low. Their images are heavy loads on the backs of animals. The animals become tired and weak as they carry them away. Nebo lies down low. Their images are heavy loads on the backs of animals. The animals become tired and weak as they carry them away."
    },
    {
      "verse": "2",
      "text": "Those gods fall down and they lie together on the ground! They have no power to rescue their images. The gods themselves go as prisoners to a foreign land, together with their images. They have no power to rescue their images. The gods themselves go as prisoners to a foreign land, together with their images."
    },
    {
      "verse": "3",
      "text": "The Lord says, ‘Listen to me, you family of Jacob. Yes, listen to me, all you Israelites who are still alive. I have taken care of you since you first became a nation. I have carried you since you were born. ‘Listen to me, you family of Jacob. Yes, listen to me, all you Israelites who are still alive. I have taken care of you since you first became a nation. I have carried you since you were born."
    },
    {
      "verse": "4",
      "text": "I will continue to take care of you until you are old, until your hair becomes grey. I made you who you are, and I will supply everything that you need. I will carry you, and I will save you. until your hair becomes grey. I made you who you are, and I will supply everything that you need. I will carry you, and I will save you."
    },
    {
      "verse": "5",
      "text": "You know that there is no God like me! You cannot say about any god, that he is the same as me. You cannot say about any god, that he is the same as me."
    },
    {
      "verse": "6",
      "text": "Some people make idols for themselves. They pour out gold coins from their purse. They weigh silver on their scales. They pay a worker with special skill to use the silver and the goldto make a god. Then they bend down low in front of it, and they worship it! They pour out gold coins from their purse. They weigh silver on their scales. They pay a worker with special skill to use the silver and the gold to make a god. Then they bend down low in front of it, and they worship it!"
    },
    {
      "verse": "7",
      "text": "They lift the idol onto their shouldersand they carry it home. They put it in its place and it stands there. It cannot move anywhere else. If someone calls out to it for help, it does not answer. It cannot save anyone from their trouble. and they carry it home. They put it in its place and it stands there. It cannot move anywhere else. If someone calls out to it for help, it does not answer. It cannot save anyone from their trouble."
    },
    {
      "verse": "8",
      "text": "Remember this, you people who do not obey me. Think about it carefully. Think about it carefully."
    },
    {
      "verse": "9",
      "text": "Remember all the things that I did a long time ago. I am God. There is nobody else like me. There is no other God, except me. I am God. There is nobody else like me. There is no other God, except me."
    },
    {
      "verse": "10",
      "text": "From the beginning, I say what will happen at the end. Long ago, I spoke about future things that have not yet happened. I say this: “My purpose will not change. I will do everything that I want to do. ” Long ago, I spoke about future things that have not yet happened. I say this: “My purpose will not change. I will do everything that I want to do. ”"
    },
    {
      "verse": "11",
      "text": "Now I will call somebody to come from the east. He will come down quickly, like an eagle that catches small birds to eat. He will come from a country that is far away. He will do for me what I want to do. Yes, I will surely do what I have decided to do. I have given the command, and I will cause it to happen. He will come down quickly, like an eagle that catches small birds to eat. He will come from a country that is far away. He will do for me what I want to do. Yes, I will surely do what I have decided to do. I have given the command, and I will cause it to happen."
    },
    {
      "verse": "12",
      "text": "Listen to me, you people who refuse to obey me. You choose not to do anything that is right. You choose not to do anything that is right."
    },
    {
      "verse": "13",
      "text": "But now I am ready to rescue you, and I will show you what is right. This will soon happen! I will save the people in Zion. I will make Israel great and beautiful. ’"
    }
  ],
  "47": [
    {
      "verse": "1",
      "text": "‘Babylon, get down on the ground, and sit in the dirt! Come down off your throne, young lady! In the past, nobody has touched you, but people will no longer say that you are so pretty. Come down off your throne, young lady! In the past, nobody has touched you, but people will no longer say that you are so pretty."
    },
    {
      "verse": "2",
      "text": "Use heavy stones to make grain into flour. Take the veil off your face. Lift up your skirt. Walk through streams of water with bare legs. Take the veil off your face. Lift up your skirt. Walk through streams of water with bare legs."
    },
    {
      "verse": "3",
      "text": "Stand there with your body completely bare! Everybody will see your great shame. I will punish you for your sins, and nobody will escape. ’ Everybody will see your great shame. I will punish you for your sins, and nobody will escape. ’"
    },
    {
      "verse": "4",
      "text": "This is what the Lord Almighty says. He is our Redeemer, Israel's Holy God."
    },
    {
      "verse": "5",
      "text": "‘You city of the Babylonians, sit there quietly! Go and hide in a dark place. People will no longer call you the queen of all kingdoms. Go and hide in a dark place. People will no longer call you the queen of all kingdoms."
    },
    {
      "verse": "6",
      "text": "I was angry with my own people. They belonged to me as my special people, but I punished them like ordinary people. I gave you the power to hurt them, and you were not kind to them. You were very cruel to old people. They belonged to me as my special people, but I punished them like ordinary people. I gave you the power to hurt them, and you were not kind to them. You were very cruel to old people."
    },
    {
      "verse": "7",
      "text": "You boasted, “I will rule other nations as queen for ever! ”But you did not think about what you were doing. You did not think about what would happen in the end. “I will rule other nations as queen for ever! ” But you did not think about what you were doing. You did not think about what would happen in the end."
    },
    {
      "verse": "8",
      "text": "So listen to me, Babylon! You love to enjoy expensive things. You think that you are strong and safe. You say to yourself, “Here I am! There is nobody as good as I am. I will never be alone as a widow. I will never lose my children. ” You love to enjoy expensive things. You think that you are strong and safe. You say to yourself, “Here I am! There is nobody as good as I am. I will never be alone as a widow. I will never lose my children. ”"
    },
    {
      "verse": "9",
      "text": "But both of those things will happen to you! They will happen suddenly, in only one day. You will lose your childrenand you will become a widow. All these troubles will come to hurt you. You can use all your powerful magicbut you will not stop this trouble! They will happen suddenly, in only one day. You will lose your children and you will become a widow. All these troubles will come to hurt you. You can use all your powerful magic but you will not stop this trouble!"
    },
    {
      "verse": "10",
      "text": "You thought that your evil deeds would keep you safe. You said, “Nobody sees me! ”You think that you are very wiseand that you know everything. But your wisdom has deceived you. You say, “Here I am! There is nobody as good as I am. ” You said, “Nobody sees me! ” You think that you are very wise and that you know everything. But your wisdom has deceived you. You say, “Here I am! There is nobody as good as I am. ”"
    },
    {
      "verse": "11",
      "text": "But trouble will suddenly come to you. Your magic words will not stop it. Trouble will come and destroy you. You cannot pay anyone to take it away. It will suddenly hit you, before you even recognize it. Your magic words will not stop it. Trouble will come and destroy you. You cannot pay anyone to take it away. It will suddenly hit you, before you even recognize it."
    },
    {
      "verse": "12",
      "text": "So continue with your magic, if you want to. Say your magic words. You have always used that magic, since you were young. Perhaps your magic will help you. Perhaps you will frighten your enemies! Say your magic words. You have always used that magic, since you were young. Perhaps your magic will help you. Perhaps you will frighten your enemies!"
    },
    {
      "verse": "13",
      "text": "You receive a lot of advice, and it has made you become tired. Let your advisors come and stand there. They study the sky and the stars to decide what will happen. They say what will happen each month. So let them come and help you! See if they can rescue you from the trouble that is coming! and it has made you become tired. Let your advisors come and stand there. They study the sky and the stars to decide what will happen. They say what will happen each month. So let them come and help you! See if they can rescue you from the trouble that is coming!"
    },
    {
      "verse": "14",
      "text": "But they are as useless as strawthat quickly burns in a fire. They cannot save themselves, because the fire is too hot! This is not a nice fire to sit beside and enjoy the heat. that quickly burns in a fire. They cannot save themselves, because the fire is too hot! This is not a nice fire to sit beside and enjoy the heat."
    },
    {
      "verse": "15",
      "text": "You have worked with those magicians since you were young, but you will have no help from them now. They have gone their own separate ways. There is nobody left who can save you. ’"
    }
  ],
  "48": [
    {
      "verse": "1",
      "text": "Listen to this, family of Jacob. You are called ‘Israel’, and you are Judah's descendants. You use the name of the Lord when you make promises. You pray to Israel's God. But you do not do those things honestly and fairly."
    },
    {
      "verse": "2",
      "text": "Your people are proud to say that they live in the holy city. They trust in Israel's God, whose name is the Lord Almighty."
    },
    {
      "verse": "3",
      "text": "The Lord says to his people, ‘I already spoke about things that would happen at a future time. A long time ago I told you what would happen. Then I suddenly did my work, and I caused those things to happen! ‘I already spoke about things that would happen at a future time. A long time ago I told you what would happen. Then I suddenly did my work, and I caused those things to happen!"
    },
    {
      "verse": "4",
      "text": "I did it because I know what you are like. You refuse to obey me. You do not want to change the way that you live. Your neck is like iron and it will not bend! Your head is as hard as bronze! You refuse to obey me. You do not want to change the way that you live. Your neck is like iron and it will not bend! Your head is as hard as bronze!"
    },
    {
      "verse": "5",
      "text": "So I told you about these things a long time ago. Before they happened, I told you about them. Then you could not say, “My idol did them. Yes, my wooden image and my idol made of metaldecided that these things would happen. ” Before they happened, I told you about them. Then you could not say, “My idol did them. Yes, my wooden image and my idol made of metal decided that these things would happen. ”"
    },
    {
      "verse": "6",
      "text": "You heard what I said would happen, and now you have seen it happen. Agree that what I say is true! Now I will tell you about new things that will happen. They are secret things that you do not yet know about. and now you have seen it happen. Agree that what I say is true! Now I will tell you about new things that will happen. They are secret things that you do not yet know about."
    },
    {
      "verse": "7",
      "text": "They are not things that started long ago. I am causing them to happen now. You did not hear about them before today. So you cannot say, “Yes, I already knew about them. ” I am causing them to happen now. You did not hear about them before today. So you cannot say, “Yes, I already knew about them. ”"
    },
    {
      "verse": "8",
      "text": "You have not heard about them before. You know nothing about them. From long ago you refused to listen to me. I know that you are never honest. Since you first became a nation, you have refused to obey me. You know nothing about them. From long ago you refused to listen to me. I know that you are never honest. Since you first became a nation, you have refused to obey me."
    },
    {
      "verse": "9",
      "text": "Because of who I am, I will keep my anger until later. I will not destroy you now, so that people will praise my name. I will keep my anger until later. I will not destroy you now, so that people will praise my name."
    },
    {
      "verse": "10",
      "text": "Listen! I have made you pure. But I have not done it in the way that people make silver pure. Instead, I have sent pain and trouble to you. That is how I make you pure. But I have not done it in the way that people make silver pure. Instead, I have sent pain and trouble to you. That is how I make you pure."
    },
    {
      "verse": "11",
      "text": "I do these things to show who I am. That is why I do it! I will not let people insult my good name. I will not let anyone else share my glory. That is why I do it! I will not let people insult my good name. I will not let anyone else share my glory."
    },
    {
      "verse": "12",
      "text": "So listen to me, descendants of Jacob! I called you to belong to me, you Israelite people. I am the only One. I am the first, and I am also the last. I called you to belong to me, you Israelite people. I am the only One. I am the first, and I am also the last."
    },
    {
      "verse": "13",
      "text": "I created the earth with my own hand. With my right hand, I hung up the sky like a curtain. When I call to the stars, they all appear in their places. With my right hand, I hung up the sky like a curtain. When I call to the stars, they all appear in their places."
    },
    {
      "verse": "14",
      "text": "All of you, come together and listen to me. Not one of your idols has saidwhat will happen now. I, the Lord, have chosen a friend to attack Babylon. He will do what I want. He will have the power to punish the Babylonians. Not one of your idols has said what will happen now. I, the Lord, have chosen a friend to attack Babylon. He will do what I want. He will have the power to punish the Babylonians."
    },
    {
      "verse": "15",
      "text": "Yes, that is what I have commanded. I have called him to do this work. I have shown him what he must do, and he will do it! I have called him to do this work. I have shown him what he must do, and he will do it!"
    },
    {
      "verse": "16",
      "text": "Come near to me! Listen to my message! From the beginning, I have not spoken secretly. When these things happen, I will already be there. ’Now the Almighty Lord has sent me, with the power of his Spirit. From the beginning, I have not spoken secretly. When these things happen, I will already be there. ’ Now the Almighty Lord has sent me, with the power of his Spirit."
    },
    {
      "verse": "17",
      "text": "The Lord is your Redeemer, Israel's Holy God. He says, ‘I am the Lord your God. I teach you what will be good for you. I lead you along a good path in life. ‘I am the Lord your God. I teach you what will be good for you. I lead you along a good path in life."
    },
    {
      "verse": "18",
      "text": "You should have obeyed my commands. Then you would have had peace in your lives, like a river that runs quietly. You would have been safe and well, like the strong waves in the sea. Then you would have had peace in your lives, like a river that runs quietly. You would have been safe and well, like the strong waves in the sea."
    },
    {
      "verse": "19",
      "text": "You would have had many descendants, as much as the sand on the shore of the sea. I would not need to destroy them. Their family name would continue for ever. ’ as much as the sand on the shore of the sea. I would not need to destroy them. Their family name would continue for ever. ’"
    },
    {
      "verse": "20",
      "text": "Now leave Babylon as free people! No longer serve the Babylonians! Shout the news with joy! Tell everyone about it, all over the world. Tell them that the Lord has redeemed his people, his servants, the Israelites. No longer serve the Babylonians! Shout the news with joy! Tell everyone about it, all over the world. Tell them that the Lord has redeemed his people, his servants, the Israelites."
    },
    {
      "verse": "21",
      "text": "When he led them through the desert, they did not become thirsty. He broke open a rock for them, so that water poured out. They could drink as much as they needed. they did not become thirsty. He broke open a rock for them, so that water poured out. They could drink as much as they needed."
    },
    {
      "verse": "22",
      "text": "But the Lord says, ‘Wicked people will have no peace in their lives. ’"
    }
  ],
  "49": [
    {
      "verse": "1",
      "text": "Listen to me, you islands. Listen carefully, you people who live far away. The Lord called me to serve himbefore I was born. Before my mother gave birth, he used my name to speak to me. Listen carefully, you people who live far away. The Lord called me to serve him before I was born. Before my mother gave birth, he used my name to speak to me."
    },
    {
      "verse": "2",
      "text": "The message that he gave me to speakwas like a sharp sword. He kept me safe in his hand. He made me like a sharp arrowthat he keeps safe and ready to use. was like a sharp sword. He kept me safe in his hand. He made me like a sharp arrow that he keeps safe and ready to use."
    },
    {
      "verse": "3",
      "text": "He said to me, ‘You are my servant, Israel. Because of you, I will cause people to know that I am great. ’ Because of you, I will cause people to know that I am great. ’"
    },
    {
      "verse": "4",
      "text": "I said, ‘My work has been useless. I have worked hard with no results. ’But the Lord will do what is right for me. He will give me what I deserve for my work. I have worked hard with no results. ’ But the Lord will do what is right for me. He will give me what I deserve for my work."
    },
    {
      "verse": "5",
      "text": "The Lord chose me to be his servant, even before I was born. He chose me to bring Jacob's descendants back to himself. He chose me to bring Israel's people together to serve him. As a result, the Lord will honour me. He is the one who makes me strong. The Lord, my God, says,"
    },
    {
      "verse": "6",
      "text": "‘As my servant, I have a greater job for you to do. It will not only be to make Jacob's tribes strong again. It will not only be to bring back Israel's people that I have kept safe. It will also be your jobto bring light to the other nations. You will show people all over the worldthat I have the power to save them. ’ It will not only be to make Jacob's tribes strong again. It will not only be to bring back Israel's people that I have kept safe. It will also be your job to bring light to the other nations. You will show people all over the world that I have the power to save them. ’"
    },
    {
      "verse": "7",
      "text": "The Lord is Israel's Redeemer, their Holy God. Nations refuse to accept his servant. Their people hate him and their rulers have made him their slave. The Lord says to his servant, ‘Kings will see you and they will rise up to respect you. Princes will bend down low in front of you. They will see that the Lord is faithful. He is Israel's Holy God, who has chosen you to serve him. ’ ‘Kings will see you and they will rise up to respect you. Princes will bend down low in front of you. They will see that the Lord is faithful. He is Israel's Holy God, who has chosen you to serve him. ’"
    },
    {
      "verse": "8",
      "text": "This is what the Lord says:‘I will answer your prayersat the time that I have chosen to help you. Yes, I will come to save you on that day. I will keep you safe, so that I can make a covenant with people through you. You will make the land safe again. People will return to live there, in places that had become empty. ‘I will answer your prayers at the time that I have chosen to help you. Yes, I will come to save you on that day. I will keep you safe, so that I can make a covenant with people through you. You will make the land safe again. People will return to live there, in places that had become empty."
    },
    {
      "verse": "9",
      "text": "You will say to the prisoners, “Come out! ”You will say to people who are in dark prisons, “Come outside! ”Then they will be free to find food for themselves. They will eat along the road and on the tops of the hills. “Come out! ” You will say to people who are in dark prisons, “Come outside! ” Then they will be free to find food for themselves. They will eat along the road and on the tops of the hills."
    },
    {
      "verse": "10",
      "text": "They will not be hungry or thirsty. The strong heat of the sun will not hurt them. The one who loves them will be their guide. He will lead them to drink from springs of water. The strong heat of the sun will not hurt them. The one who loves them will be their guide. He will lead them to drink from springs of water."
    },
    {
      "verse": "11",
      "text": "I will make all my mountains become roads. I will build good roads for my people to travel on. I will build good roads for my people to travel on."
    },
    {
      "verse": "12",
      "text": "Look! People will return to the landfrom places that are far away. Yes, some of them will come from the north and from the west. And some will come from the land of Sinim. ’ from places that are far away. Yes, some of them will come from the north and from the west. And some will come from the land of Sinim. ’"
    },
    {
      "verse": "13",
      "text": "Shout with joy, everything in the sky! Be happy, everything on the earth! Sing loudly, you mountains! Be happy, because the Lord comforts his people. He will be kind to his people who have trouble and pain. Be happy, everything on the earth! Sing loudly, you mountains! Be happy, because the Lord comforts his people. He will be kind to his people who have trouble and pain."
    },
    {
      "verse": "14",
      "text": "But Zion's people said, ‘The Lord has left us alone. The Lord God has forgotten about us. ’ ‘The Lord has left us alone. The Lord God has forgotten about us. ’"
    },
    {
      "verse": "15",
      "text": "The Lord replies, ‘Can a mother forget the babywho drinks milk at her breast? Can she refuse to be kind to the childthat she has given birth to? Perhaps those mothers might forget their children. But I would not ever forget you, Zion. ‘Can a mother forget the baby who drinks milk at her breast? Can she refuse to be kind to the child that she has given birth to? Perhaps those mothers might forget their children. But I would not ever forget you, Zion."
    },
    {
      "verse": "16",
      "text": "Look! I have written your name on my own hand. I always see the walls of your city in my mind. I always see the walls of your city in my mind."
    },
    {
      "verse": "17",
      "text": "Your children will hurry back to you, to build you again. The enemies who destroyed you will go away. to build you again. The enemies who destroyed you will go away."
    },
    {
      "verse": "18",
      "text": "Look all round you! See all your people as they return together. ’The Lord says, ‘I tell you clearly, as the God who lives, you will be happy with your people. They will make you beautiful again, like a bride with her beautiful jewels. See all your people as they return together. ’ The Lord says, ‘I tell you clearly, as the God who lives, you will be happy with your people. They will make you beautiful again, like a bride with her beautiful jewels."
    },
    {
      "verse": "19",
      "text": "Enemies have destroyed your land. Its towns have become heaps of stones. But soon your land will be too small for all your people to live in. The enemies who destroyed you will be far away from you. Its towns have become heaps of stones. But soon your land will be too small for all your people to live in. The enemies who destroyed you will be far away from you."
    },
    {
      "verse": "20",
      "text": "The children who were born in a foreign landwill return to you. You will hear them say, “This place is too small for us. Find more room for us to live in. ” will return to you. You will hear them say, “This place is too small for us. Find more room for us to live in. ”"
    },
    {
      "verse": "21",
      "text": "Then you will think, “Who gave me all these children? Who is their father? I was alone, with no husband. They killed my childrenor they took them away to a foreign land. I could no longer give birth. So where did all these children come from? ” ’ Who is their father? I was alone, with no husband. They killed my children or they took them away to a foreign land. I could no longer give birth. So where did all these children come from? ” ’"
    },
    {
      "verse": "22",
      "text": "The Almighty Lord says, ‘Look! I will lift up my hand, to call the nations. I will raise up a flagas a sign to those people. Then they will bring back your sons and your daughters. They will carry them in their arms and on their shoulders. ‘Look! I will lift up my hand, to call the nations. I will raise up a flag as a sign to those people. Then they will bring back your sons and your daughters. They will carry them in their arms and on their shoulders."
    },
    {
      "verse": "23",
      "text": "The kings of those nations will take care of your children. The kings' daughters will feed them. The rulers will bend down low in front of you, so that their faces touch the ground. They will taste the dirt by your feet. Then you will know that I am the Lord. I will not disappoint people who wait for me to help them. The kings' daughters will feed them. The rulers will bend down low in front of you, so that their faces touch the ground. They will taste the dirt by your feet. Then you will know that I am the Lord. I will not disappoint people who wait for me to help them."
    },
    {
      "verse": "24",
      "text": "Can anyone rob a brave soldier? Can anyone rescue prisoners from a cruel ruler? ’ Can anyone rescue prisoners from a cruel ruler? ’"
    },
    {
      "verse": "25",
      "text": "But the Lord says, ‘Yes! One day the brave soldier's prisoners will be free. One day the cruel ruler will lose the valuable things that he has taken for himself. I myself will fight against your enemies. I will rescue your children. ‘Yes! One day the brave soldier's prisoners will be free. One day the cruel ruler will lose the valuable things that he has taken for himself. I myself will fight against your enemies. I will rescue your children."
    },
    {
      "verse": "26",
      "text": "I will cause your cruel enemies to destroy themselves. There will be so much blood that it will seem like wine. They will seem like people who have become drunk. Then people everywhere will recognize that I am the Lord. They will know that I am your Saviour and your Redeemer, and I am the Mighty One of Jacob. ’"
    }
  ],
  "50": [
    {
      "verse": "1",
      "text": "This is what the Lord says to his people:‘Did I send your mother away, like a man sends away his wife? Where is the paper to saywhy I have sent her away? Did I sell you to pay people that I was in debt to? Where is the paper that showsthe reason for my debt? Listen! I sold you because of your sins. I sent your mother awaybecause you have not obeyed me. ‘Did I send your mother away, like a man sends away his wife? Where is the paper to say why I have sent her away? Did I sell you to pay people that I was in debt to? Where is the paper that shows the reason for my debt? Listen! I sold you because of your sins. I sent your mother away because you have not obeyed me."
    },
    {
      "verse": "2",
      "text": "Nobody was there to meet me, when I came to help you. When I called out to you, nobody answered me. Do you think that my arm is too weak to rescue you? Am I not strong enough to save you? Look! I can speak to the sea so that it becomes dry! I can cause rivers to become deserts. Then the fish die because they have no water. when I came to help you. When I called out to you, nobody answered me. Do you think that my arm is too weak to rescue you? Am I not strong enough to save you? Look! I can speak to the sea so that it becomes dry! I can cause rivers to become deserts. Then the fish die because they have no water."
    },
    {
      "verse": "3",
      "text": "I can cause the sky to become dark, as if I have covered it with sackcloth. ’ as if I have covered it with sackcloth. ’"
    },
    {
      "verse": "4",
      "text": "‘The Almighty Lord has given his message to me, his servant. I speak it on his behalf. I know what to say to help weak and tired people. The Lord wakes me up every morningso that I can learn something. I listen carefully to him, as a student listens to his teacher. I speak it on his behalf. I know what to say to help weak and tired people. The Lord wakes me up every morning so that I can learn something. I listen carefully to him, as a student listens to his teacher."
    },
    {
      "verse": "5",
      "text": "The Almighty Lord has spoken clearly to me. I have accepted his message, and I have not turned back. I have accepted his message, and I have not turned back."
    },
    {
      "verse": "6",
      "text": "I offered my backto the people who hit me. I offered my faceto the people who pulled out my beard. When they insulted me and they spat at me, I did not hide my face from them. to the people who hit me. I offered my face to the people who pulled out my beard. When they insulted me and they spat at me, I did not hide my face from them."
    },
    {
      "verse": "7",
      "text": "The Almighty Lord helps me, so I will not be ashamed. I have decided to stand and be strong, because I know that I will not be ashamed. so I will not be ashamed. I have decided to stand and be strong, because I know that I will not be ashamed."
    },
    {
      "verse": "8",
      "text": "God is the one who says that I am right, and he stands beside me. So who will accuse me that I have done something wrong? We should meet in court! Anyone who accuses me should come and speak! and he stands beside me. So who will accuse me that I have done something wrong? We should meet in court! Anyone who accuses me should come and speak!"
    },
    {
      "verse": "9",
      "text": "Look! The Almighty Lord himself helps me. So nobody can say that I am guilty. All the people who accuse me will soon disappear. They will spoil like old clothes that moths have eaten! ’ So nobody can say that I am guilty. All the people who accuse me will soon disappear. They will spoil like old clothes that moths have eaten! ’"
    },
    {
      "verse": "10",
      "text": "Do any of you respect the Lord with fear? Do any of you obey his servant's message? Are you walking in a place that is completely dark, where there is no light? Then you should trust in the Lordas the God who will help you. Do any of you obey his servant's message? Are you walking in a place that is completely dark, where there is no light? Then you should trust in the Lord as the God who will help you."
    },
    {
      "verse": "11",
      "text": "But no! You have lit your own fires. You have burned branches to give yourselves light. So now you must walk in the light of the fires that you have lit. And this is what I will do for you: I will punish you with great pain!"
    }
  ],
  "51": [
    {
      "verse": "1",
      "text": "‘Listen to me, you people who want to do what is right. You people who want to serve the Lord, listen to me! Think about the rock that you are a part of. Think about the ground that they dug you out from. you people who want to do what is right. You people who want to serve the Lord, listen to me! Think about the rock that you are a part of. Think about the ground that they dug you out from."
    },
    {
      "verse": "2",
      "text": "You all started from your ancestor Abraham, and his wife Sarah. When I first spoke to Abraham, he had no children. But I blessed him, so that he had many descendants. ’ and his wife Sarah. When I first spoke to Abraham, he had no children. But I blessed him, so that he had many descendants. ’"
    },
    {
      "verse": "3",
      "text": "Surely, the Lord will comfort Zion's people. He will take care of the buildingsthat enemies have destroyed. Zion's land that is now a wildernesswill become like the beautiful Garden of Eden. It will be the Lord's own garden! People will be happy again in Zion. They will sing with joy to thank God. He will take care of the buildings that enemies have destroyed. Zion's land that is now a wilderness will become like the beautiful Garden of Eden. It will be the Lord's own garden! People will be happy again in Zion. They will sing with joy to thank God."
    },
    {
      "verse": "4",
      "text": "‘Listen to me, my people. Listen carefully, my nation. I will tell all people about my laws. I will cause my justice to be like a light to all nations. Listen carefully, my nation. I will tell all people about my laws. I will cause my justice to be like a light to all nations."
    },
    {
      "verse": "5",
      "text": "I am ready to do what is right for them. I am ready to save them. I will judge all the nations fairly. Lands that are far away will wait for me to help them. They wait for me to come and rule them all with power. I am ready to save them. I will judge all the nations fairly. Lands that are far away will wait for me to help them. They wait for me to come and rule them all with power."
    },
    {
      "verse": "6",
      "text": "Look up at the sky! Look down at the earth below! One day, the sky will disappearlike smoke that blows away. The earth will become useless, like old clothes. The people who live on it will die. They will fall like flies. But I will keep my people safe for ever. I will always rule with righteousness. Look down at the earth below! One day, the sky will disappear like smoke that blows away. The earth will become useless, like old clothes. The people who live on it will die. They will fall like flies. But I will keep my people safe for ever. I will always rule with righteousness."
    },
    {
      "verse": "7",
      "text": "Listen to me, you people who know what is right. You people who think carefully about my law, listen to me. When people speak against you, do not be afraid. Do not be upset, when they insult you. you people who know what is right. You people who think carefully about my law, listen to me. When people speak against you, do not be afraid. Do not be upset, when they insult you."
    },
    {
      "verse": "8",
      "text": "Those people will soon disappear, like clothes that moths have eaten, like wool that worms have eaten. But I will always rule with righteousness. I will keep my people safe for ever. ’ like clothes that moths have eaten, like wool that worms have eaten. But I will always rule with righteousness. I will keep my people safe for ever. ’"
    },
    {
      "verse": "9",
      "text": "Wake up, Lord! Get ready to show your strength! Do great things, as you did in past days, when our ancestors were alive. Remember how you cut the monster, Rahab, into pieces. Get ready to show your strength! Do great things, as you did in past days, when our ancestors were alive. Remember how you cut the monster, Rahab, into pieces."
    },
    {
      "verse": "10",
      "text": "You made the sea become dry, so that there was a path through the deep water. The slaves that you rescuedcould then cross over. so that there was a path through the deep water. The slaves that you rescued could then cross over."
    },
    {
      "verse": "11",
      "text": "The people that the Lord has rescuedwill return from exile. They will sing with joywhile they go into Zion city. Their joy will be like a crownthat they wear on their heads for ever. They will continue to be very happy. They will never be sad or weep again. will return from exile. They will sing with joy while they go into Zion city. Their joy will be like a crown that they wear on their heads for ever. They will continue to be very happy. They will never be sad or weep again."
    },
    {
      "verse": "12",
      "text": "‘I am the Lord who comforts you. You do not need to be afraid of people who are only human. Remember that they will all die one day, like grass that only lives for a short time. You do not need to be afraid of people who are only human. Remember that they will all die one day, like grass that only lives for a short time."
    },
    {
      "verse": "13",
      "text": "Do not forget about the Lord who made you! I hung up the sky like a curtain. I made the foundation of the earth. So why are you always shaking with fear? Do not be afraid when your enemy is angry, and he is ready to attack you. Your enemy's anger is useless! I hung up the sky like a curtain. I made the foundation of the earth. So why are you always shaking with fear? Do not be afraid when your enemy is angry, and he is ready to attack you. Your enemy's anger is useless!"
    },
    {
      "verse": "14",
      "text": "The people who have trouble and painwill soon become free. They will not stay in the prison of death. They will have all the food that they need. will soon become free. They will not stay in the prison of death. They will have all the food that they need."
    },
    {
      "verse": "15",
      "text": "Remember that I am the Lord your God. I shake the sea so that its waves roar! My name is the Lord Almighty. I shake the sea so that its waves roar! My name is the Lord Almighty."
    },
    {
      "verse": "16",
      "text": "I have given you my messageto speak on my behalf. I have kept you safe in my hand. I hung up the sky like a curtain, and I made the foundation of the earth. I say to Zion, “You are my people. ” ’ to speak on my behalf. I have kept you safe in my hand. I hung up the sky like a curtain, and I made the foundation of the earth. I say to Zion, “You are my people. ” ’"
    },
    {
      "verse": "17",
      "text": "Wake up, people in Jerusalem! Get ready! The Lord has been angry with you, and he has punished you. You had to receive all of his anger, like you were drinking strong wine from a cup. Now that you have drunk it all, you cannot stand up straight! The Lord has been angry with you, and he has punished you. You had to receive all of his anger, like you were drinking strong wine from a cup. Now that you have drunk it all, you cannot stand up straight!"
    },
    {
      "verse": "18",
      "text": "Among all of Jerusalem's people, there was nobody left to be your leader. There was nobody who could take care of you. there was nobody left to be your leader. There was nobody who could take care of you."
    },
    {
      "verse": "19",
      "text": "War and famine have destroyed you. Both those terrible things have happened to you. Who feels sorry for you? Who is there to comfort you? Both those terrible things have happened to you. Who feels sorry for you? Who is there to comfort you?"
    },
    {
      "verse": "20",
      "text": "Your children have become weak, and they lie on the ground at the side of every street. They are like deer that a trap has caught. The anger of the Lord your God has made them helpless. He has warned them loudly. and they lie on the ground at the side of every street. They are like deer that a trap has caught. The anger of the Lord your God has made them helpless. He has warned them loudly."
    },
    {
      "verse": "21",
      "text": "So listen to this, you people who are in trouble. You walk like drunk people, but wine has not done that to you. You walk like drunk people, but wine has not done that to you."
    },
    {
      "verse": "22",
      "text": "The Lord God who is your Lord stands beside his people. He says, ‘Look! Now I have taken the cup of my punishment out of your hand. You will no longer have to drink the strong wine of my angerthat makes you drunk. ‘Look! Now I have taken the cup of my punishment out of your hand. You will no longer have to drink the strong wine of my anger that makes you drunk."
    },
    {
      "verse": "23",
      "text": "Instead, I will give it to your cruel enemiesto punish them. They said to you, “Lie down on the ground, so that we can walk over you. ”You made your backs become like the ground. You became like a street for your enemies to walk on. ’"
    }
  ],
  "52": [
    {
      "verse": "1",
      "text": "Wake up, Zion! Be ready to show your strength! Jerusalem, God's holy city, Put on your beautiful clothes! Foreign people who do not serve Godwill not attack your city again. Be ready to show your strength! Jerusalem, God's holy city, Put on your beautiful clothes! Foreign people who do not serve God will not attack your city again."
    },
    {
      "verse": "2",
      "text": "Shake off the dirt, Jerusalem! Get up and sit on your throne. People of Zion, you are no longer prisoners, so take the chains off your neck. Get up and sit on your throne. People of Zion, you are no longer prisoners, so take the chains off your neck."
    },
    {
      "verse": "3",
      "text": "This is what the Lord says to you:‘I received no money when I sold you. And I will not pay anything to make you free again. ’ ‘I received no money when I sold you. And I will not pay anything to make you free again. ’"
    },
    {
      "verse": "4",
      "text": "The Almighty Lord says, ‘Long ago, my people went to live for some time in Egypt. At a later time, Assyria's army was cruel to them. ‘Long ago, my people went to live for some time in Egypt. At a later time, Assyria's army was cruel to them."
    },
    {
      "verse": "5",
      "text": "But now, what is happening? An enemy has taken my people away as slaves, for no good reason. Their leaders boast loudly, and they insult me all the time. An enemy has taken my people away as slaves, for no good reason. Their leaders boast loudly, and they insult me all the time."
    },
    {
      "verse": "6",
      "text": "So I will cause my people to know my name. When all this happens, they will knowthat I am the God who speaks to them. I tell them that I am with them. ’ When all this happens, they will know that I am the God who speaks to them. I tell them that I am with them. ’"
    },
    {
      "verse": "7",
      "text": "Somebody is coming across the mountainsto bring good news to us! It is a beautiful thing to see him run towards us! He has come to tell us that there will be peace, because God will save our city. He says to Zion, ‘Your God rules as king! ’ to bring good news to us! It is a beautiful thing to see him run towards us! He has come to tell us that there will be peace, because God will save our city. He says to Zion, ‘Your God rules as king! ’"
    },
    {
      "verse": "8",
      "text": "Listen! The guards on the city's walls are shouting! They all shout together with joy! They can see for themselvesthat the Lord is returning to Zion. They all shout together with joy! They can see for themselves that the Lord is returning to Zion."
    },
    {
      "verse": "9",
      "text": "Jerusalem, your buildings have become heaps of stones, but now you can all shout together with joy! Sing aloud, because the Lord has comforted his people. He has made Jerusalem safe again. but now you can all shout together with joy! Sing aloud, because the Lord has comforted his people. He has made Jerusalem safe again."
    },
    {
      "verse": "10",
      "text": "The Lord has shown all the nations how strong he is. They can all see his holy power. People all over the world will knowthat our God has rescued his people. They can all see his holy power. People all over the world will know that our God has rescued his people."
    },
    {
      "verse": "11",
      "text": "Leave! Leave! Go out from there. Do not touch anything that is unclean. Leave that foreign place! The people who carry the Lord's special thingsmust keep themselves pure. Do not touch anything that is unclean. Leave that foreign place! The people who carry the Lord's special things must keep themselves pure."
    },
    {
      "verse": "12",
      "text": "But you will not have to hurry and run away. No, the Lord, Israel's God, will keep you safe. He will lead you at the front, and he will be your guard at the back. No, the Lord, Israel's God, will keep you safe. He will lead you at the front, and he will be your guard at the back."
    },
    {
      "verse": "13",
      "text": "Look! My servant will do well. He will move up to a high placewhere people will honour him as great. He will move up to a high place where people will honour him as great."
    },
    {
      "verse": "14",
      "text": "At one time, when people saw him, they were very upset. His body became completely spoiled, so that he no longer seemed to be a man. He did not seem to have a human body. they were very upset. His body became completely spoiled, so that he no longer seemed to be a man. He did not seem to have a human body."
    },
    {
      "verse": "15",
      "text": "But now, he will cause the people in many nationsto be very surprised! Kings will have nothing to saywhen they see how great he is. They will see something newthat nobody had told them about. They will understand new thingsthat they had not heard about before."
    }
  ],
  "53": [
    {
      "verse": "1",
      "text": "Will anyone believethe news that we have to tell people? Will anyone understandhow the Lord has used his great power? the news that we have to tell people? Will anyone understand how the Lord has used his great power?"
    },
    {
      "verse": "2",
      "text": "God's servant grew up in front of him, like a young, green plant, with its roots in dry ground. He was not handsome. He did not seem like a great king. We did not see him as a special person. There was nothing to seethat would make us want to be with him. like a young, green plant, with its roots in dry ground. He was not handsome. He did not seem like a great king. We did not see him as a special person. There was nothing to see that would make us want to be with him."
    },
    {
      "verse": "3",
      "text": "People did not respect him. They refused to accept him. He was a man who received much pain. He knew what it felt like to be weak and ill. People did not even want to look at him. They did not respect him. We decided that he was worth nothing. They refused to accept him. He was a man who received much pain. He knew what it felt like to be weak and ill. People did not even want to look at him. They did not respect him. We decided that he was worth nothing."
    },
    {
      "verse": "4",
      "text": "But he took away all our weakness! He carried our pain for us. We thought that he was receiving punishment for his own sins. We thought that God was causing him to suffer. He carried our pain for us. We thought that he was receiving punishment for his own sins. We thought that God was causing him to suffer."
    },
    {
      "verse": "5",
      "text": "But it was our sins that caused his wounds. The bad things that we had done crushed him. The punishment that he receivedhas brought peace to us. The wounds that he receivedhave made us well. The bad things that we had done crushed him. The punishment that he received has brought peace to us. The wounds that he received have made us well."
    },
    {
      "verse": "6",
      "text": "We have all turned away, like sheep that take the wrong path. Each of us has turned to follow our own way. But the Lord has taken all our sinsand put the punishment on him. like sheep that take the wrong path. Each of us has turned to follow our own way. But the Lord has taken all our sins and put the punishment on him."
    },
    {
      "verse": "7",
      "text": "People were cruel to him, and he received much pain. But he did not say anything to complain. He was like a lamb that people were leading away to kill. He was like a sheep when they are cutting off its wool, but it makes no noise. In the same way, he did not say anything. and he received much pain. But he did not say anything to complain. He was like a lamb that people were leading away to kill. He was like a sheep when they are cutting off its wool, but it makes no noise. In the same way, he did not say anything."
    },
    {
      "verse": "8",
      "text": "They spoke lies to accuse him in court. Then they led him away to kill him. And nobody at that time said that it was wrong. His life in this world quickly came to an end. And it was the sins of our own people that caused him to die. Then they led him away to kill him. And nobody at that time said that it was wrong. His life in this world quickly came to an end. And it was the sins of our own people that caused him to die."
    },
    {
      "verse": "9",
      "text": "They decided to bury him with wicked people. But his body was put in a rich man's grave. He had not done anything to hurt anyone. He had not told lies to deceive people. But his body was put in a rich man's grave. He had not done anything to hurt anyone. He had not told lies to deceive people."
    },
    {
      "verse": "10",
      "text": "But it was the Lord who chose to hurt his servant. He caused his servant to receive much pain. His servant died to remove people's guilt. As a result, God will bless him with many descendants, and he will have a long life. What the Lord wants will happen, because of what his servant does. He caused his servant to receive much pain. His servant died to remove people's guilt. As a result, God will bless him with many descendants, and he will have a long life. What the Lord wants will happen, because of what his servant does."
    },
    {
      "verse": "11",
      "text": "When God's servant sees the result of his pain, he will understand what he has done. And he will be happy. The Lord says, ‘My righteous servant will cause many people to be “not guilty”, because he will take the punishment for all their sins. he will understand what he has done. And he will be happy. The Lord says, ‘My righteous servant will cause many people to be “not guilty”, because he will take the punishment for all their sins."
    },
    {
      "verse": "12",
      "text": "So I will put him in a place of honour, as a great person deserves. He will share the good things that powerful men receivewhen they have won a battle. He deserves this, because he agreed to die as a sacrifice. People thought that he himself was a sinnerwhen he took away the sins of many people. He prayed that God would forgive sinners. ’"
    }
  ],
  "54": [
    {
      "verse": "1",
      "text": "‘Sing with joy, you woman who could not give birth to any children. You have never known the pain of a child's birth, but now shout loudly with joy. Be happy, because the woman who is alonewill have many children. She will have more children than the woman who has a husband. ’That is what the Lord says. you woman who could not give birth to any children. You have never known the pain of a child's birth, but now shout loudly with joy. Be happy, because the woman who is alone will have many children. She will have more children than the woman who has a husband. ’ That is what the Lord says."
    },
    {
      "verse": "2",
      "text": "Make your tent bigger! You need more room to live in. Yes, do it! Make the tent's ropes longer! Make the pegs that hold it stronger! You need more room to live in. Yes, do it! Make the tent's ropes longer! Make the pegs that hold it stronger!"
    },
    {
      "verse": "3",
      "text": "The borders of your land will be wider in all directions. Your descendants will take land from other nations. They will live in the cities that had become empty. Your descendants will take land from other nations. They will live in the cities that had become empty."
    },
    {
      "verse": "4",
      "text": "Do not be afraid. You will not be ashamed again. Do not be frightened of shame. Nobody will make you ashamed. You will forget the shamewhich you had when you were young. You will forget that you were ashamed to be alone, like a widow. You will not be ashamed again. Do not be frightened of shame. Nobody will make you ashamed. You will forget the shame which you had when you were young. You will forget that you were ashamed to be alone, like a widow."
    },
    {
      "verse": "5",
      "text": "Now your Maker is your husband. His name is the Lord Almighty. Israel's Holy God is your Redeemer. He is called, ‘The God who rules the whole earth’. His name is the Lord Almighty. Israel's Holy God is your Redeemer. He is called, ‘The God who rules the whole earth’."
    },
    {
      "verse": "6",
      "text": "‘The Lord will now call you to come back to him. You have been like a wife who was very upset, because her husband has left her. You have been like a wife who married when she was young, and her husband sent her away. ’That is what your God says. You have been like a wife who was very upset, because her husband has left her. You have been like a wife who married when she was young, and her husband sent her away. ’ That is what your God says."
    },
    {
      "verse": "7",
      "text": "‘For a short time I went away from you. But now I will bring you back to myself, because I feel very sorry for you. But now I will bring you back to myself, because I feel very sorry for you."
    },
    {
      "verse": "8",
      "text": "For a moment I became very angry with you, and I turned away from you. But now I will be kind to you, because my love for you continues for ever. ’That is what the Lord, your Redeemer, says. and I turned away from you. But now I will be kind to you, because my love for you continues for ever. ’ That is what the Lord, your Redeemer, says."
    },
    {
      "verse": "9",
      "text": "‘This is like what I did in Noah's time. At that time, I promised that a flood of water would never again destroy the earth. Now, at this time, I have promised that I will not be angry with you again. I will not speak against you again. At that time, I promised that a flood of water would never again destroy the earth. Now, at this time, I have promised that I will not be angry with you again. I will not speak against you again."
    },
    {
      "verse": "10",
      "text": "The mountains may shake to pieces, and the hills may disappear. But I will never take my love away from you. My covenant that brings peace between us will never finish. ’That is what the Lord who is very kind to you says. and the hills may disappear. But I will never take my love away from you. My covenant that brings peace between us will never finish. ’ That is what the Lord who is very kind to you says."
    },
    {
      "verse": "11",
      "text": "‘My city, enemies attacked you, like a strong storm. Nobody was there to help you. Look! Now I will use beautiful jewels to build you again. I will build your foundation with blue sapphires. like a strong storm. Nobody was there to help you. Look! Now I will use beautiful jewels to build you again. I will build your foundation with blue sapphires."
    },
    {
      "verse": "12",
      "text": "I will build your strong towers with rubies. I will build your gates with valuable jewels, and I will build your walls with beautiful stones. I will build your gates with valuable jewels, and I will build your walls with beautiful stones."
    },
    {
      "verse": "13",
      "text": "I, the Lord, will teach your children, and peace will fill their lives. and peace will fill their lives."
    },
    {
      "verse": "14",
      "text": "You will have a strong foundation of righteousness. Your cruel enemies will be far away. You will have nothing to be afraid of. No trouble will come near to frighten you. Your cruel enemies will be far away. You will have nothing to be afraid of. No trouble will come near to frighten you."
    },
    {
      "verse": "15",
      "text": "If anyone comes to attack you, I will not have sent them. You will win against anyone who tries to attack you. I will not have sent them. You will win against anyone who tries to attack you."
    },
    {
      "verse": "16",
      "text": "Look! I myself created the workerwho knows how to use iron to make things. He makes his fire very hot, and he makes weapons from the iron. He makes weapons that are strong to fight with. I also created the armieswho use their weapons to destroy people. who knows how to use iron to make things. He makes his fire very hot, and he makes weapons from the iron. He makes weapons that are strong to fight with. I also created the armies who use their weapons to destroy people."
    },
    {
      "verse": "17",
      "text": "But nobody can make a weapon that will beat you, when your enemies attack you. If people accuse you of bad things, you will show that they are wrong. That is what the Lord will doas a gift for his servants. Yes, I will show that they are right. ’That is what the Lord says."
    }
  ],
  "55": [
    {
      "verse": "1",
      "text": "‘Listen! All of you who are thirsty, come here for water to drink! You may have no money, but come here and buy food to eat! Come and buy wine and milk! You do not need to pay any money. It is free! come here for water to drink! You may have no money, but come here and buy food to eat! Come and buy wine and milk! You do not need to pay any money. It is free!"
    },
    {
      "verse": "2",
      "text": "Do not spend money on anything that is not real food. You work hard for your money, so do not spend it on things which do not help you. Listen carefully to me. Eat something that will make you strong! Enjoy the best food! You work hard for your money, so do not spend it on things which do not help you. Listen carefully to me. Eat something that will make you strong! Enjoy the best food!"
    },
    {
      "verse": "3",
      "text": "Come to me and listen carefully. If you accept my teaching, you will have real life! Then I will make a covenant with you, to be my people. My promise will continue for ever, like the promise that I made to King David. If you accept my teaching, you will have real life! Then I will make a covenant with you, to be my people. My promise will continue for ever, like the promise that I made to King David."
    },
    {
      "verse": "4",
      "text": "So look! I chose Davidto show my power to other people. I made him a leader to rule the people of the nations. to show my power to other people. I made him a leader to rule the people of the nations."
    },
    {
      "verse": "5",
      "text": "Now you will call other nations to come to you. They will be nations that you did not know before. Nations that did not know you beforewill now run quickly to you. They will come to you, because they see that you are great. The Lord your God, Israel's Holy God, will make people honour you. ’ They will be nations that you did not know before. Nations that did not know you before will now run quickly to you. They will come to you, because they see that you are great. The Lord your God, Israel's Holy God, will make people honour you. ’"
    },
    {
      "verse": "6",
      "text": "Come to serve the Lord now, while he lets you find him. Call out to him for help, while he is near you. while he lets you find him. Call out to him for help, while he is near you."
    },
    {
      "verse": "7",
      "text": "Wicked people need to change the way that they live. Evil people must stop thinking their evil thoughts. They must turn back to the Lord our God, because he will be kind to them. Yes, God will completely forgive them, if they turn back to him. Evil people must stop thinking their evil thoughts. They must turn back to the Lord our God, because he will be kind to them. Yes, God will completely forgive them, if they turn back to him."
    },
    {
      "verse": "8",
      "text": "The Lord says, ‘Remember! My thoughts are not the same as your thoughts. The way that you do things is not the same as the way that I do things. ‘Remember! My thoughts are not the same as your thoughts. The way that you do things is not the same as the way that I do things."
    },
    {
      "verse": "9",
      "text": "The sky is far higher than the earth. In the same way, I do things in a much better way than you do. Also, my thoughts are much higher than your thoughts. In the same way, I do things in a much better way than you do. Also, my thoughts are much higher than your thoughts."
    },
    {
      "verse": "10",
      "text": "The rain and the snow come down from the sky, and they do not immediately return there. Instead, they give water to the earth, so that crops will grow there. Then the farmer has seeds to plant, and people have food to eat. and they do not immediately return there. Instead, they give water to the earth, so that crops will grow there. Then the farmer has seeds to plant, and people have food to eat."
    },
    {
      "verse": "11",
      "text": "It is the same when I give my word to people. It will not return to me without any result. No! My word does what I want it to do. What I promise to do will certainly happen. ’ It will not return to me without any result. No! My word does what I want it to do. What I promise to do will certainly happen. ’"
    },
    {
      "verse": "12",
      "text": "You will leave that foreign land with joy! You will travel home with peace in your minds. The mountains and the hills will sing with joyas you travel past. The trees in the fields will clap their hands together! You will travel home with peace in your minds. The mountains and the hills will sing with joy as you travel past. The trees in the fields will clap their hands together!"
    },
    {
      "verse": "13",
      "text": "Where thorn bushes have been growing, pine trees will grow instead. Myrtle bushes will grow where there are weeds now. Those things will show everyone that the Lord is great. It will be a sign to people for ever."
    }
  ],
  "56": [
    {
      "verse": "1",
      "text": "This is what the Lord says:‘Always be fair and do what is right. Soon I will come to rescue you. I will do what is right for my people. ‘Always be fair and do what is right. Soon I will come to rescue you. I will do what is right for my people."
    },
    {
      "verse": "2",
      "text": "God will bless the people who do what is right. They must be careful to obey my laws. They must respect the rules for the Sabbath dayand keep it special. They must refuse to do anything that is evil. They must be careful to obey my laws. They must respect the rules for the Sabbath day and keep it special. They must refuse to do anything that is evil."
    },
    {
      "verse": "3",
      "text": "When a foreigner decides to serve the Lord, he should not say, “The Lord will keep me separate from his own people. ” A eunuch should not say, “I am no better than a dead tree. ” ’"
    },
    {
      "verse": "4",
      "text": "The Lord says this:‘I will bless eunuchs who obey my laws. They must respect the rules for Sabbath days. They must choose to do what pleases me. They must always obey my covenant with my people. ‘I will bless eunuchs who obey my laws."
    },
    {
      "verse": "5",
      "text": "If they do that, I will give them a special place in my temple. It will cause people to remember them. Their name will continue in a better waythan through sons and daughters. People will always honour their name. Nobody will cut it off. It will cause people to remember them. Their name will continue in a better way than through sons and daughters. People will always honour their name. Nobody will cut it off."
    },
    {
      "verse": "6",
      "text": "I will also bless foreigners who decide to serve me. They must be faithful to me as my servants. They must respect the rules for the Sabbath day and keep it special. They must always obey my covenant."
    },
    {
      "verse": "7",
      "text": "Then I will bring them to my holy mountain. I will make them happy in my house, where people pray to me. I will accept their burnt offerings and sacrifices, when they offer them to me on my altar. People will call my temple, “A house where people from all nations may pray. ” ’ when they offer them to me on my altar. People will call my temple, “A house where people from all nations may pray. ” ’"
    },
    {
      "verse": "8",
      "text": "The Almighty Lord is the one who brings together all the Israelite people who are in exile. He says, ‘I will continue to bring more people to join with them. ’"
    },
    {
      "verse": "9",
      "text": "‘Come here, you wild animals! Come, you wild animals that live in the forest! Come and eat my people! Come, you wild animals that live in the forest! Come and eat my people!"
    },
    {
      "verse": "10",
      "text": "Israel's guards are blind! They do not see what is happening. They are all like dogs that cannot make a noise. They cannot warn people about danger. They love to lie on the groundand they dream while they sleep. They do not see what is happening. They are all like dogs that cannot make a noise. They cannot warn people about danger. They love to lie on the ground and they dream while they sleep."
    },
    {
      "verse": "11",
      "text": "They are like dogs who are always hungry. They eat a lot but they never have enough. They are like shepherdswho do not understand what to do. They do whatever they want to do, so that it will help them get what they want. They eat a lot but they never have enough. They are like shepherds who do not understand what to do. They do whatever they want to do, so that it will help them get what they want."
    },
    {
      "verse": "12",
      "text": "They say to each other, “Come! We must go and find more wine to drink! We can drink as much beer as we want! Tomorrow we can do it all again! It might be even better than today! ” ’"
    }
  ],
  "57": [
    {
      "verse": "1",
      "text": "When somebody who worships God dies, nobody else may think much about it. An honest person may suddenly die. Nobody really understands what is happening. God takes away his servants, so that evil things will not hurt them any more. nobody else may think much about it. An honest person may suddenly die. Nobody really understands what is happening. God takes away his servants, so that evil things will not hurt them any more."
    },
    {
      "verse": "2",
      "text": "When somebody who has lived in a good way dies, he goes to a place where there is peace. In death, people like that rest on their beds. he goes to a place where there is peace. In death, people like that rest on their beds."
    },
    {
      "verse": "3",
      "text": "The Lord says, ‘But you magicians, come here! You use magic to learn about future times. You are the family of an adulteress and a prostitute. ‘But you magicians, come here! You use magic to learn about future times. You are the family of an adulteress and a prostitute."
    },
    {
      "verse": "4",
      "text": "Who do you think you are laughing at? Who are you insulting? Who are you pointing at with your tongue? You are people who have turned against God. You love to tell lies. Who are you insulting? Who are you pointing at with your tongue? You are people who have turned against God. You love to tell lies."
    },
    {
      "verse": "5",
      "text": "You worship your idols among the big trees, and you have sex at the same time. You kill your children as sacrifices to your false gods. You do that beside streamsand in caves among the rocks. and you have sex at the same time. You kill your children as sacrifices to your false gods. You do that beside streams and in caves among the rocks."
    },
    {
      "verse": "6",
      "text": "You take big stones from the streams, and they become your idols. They are the gods that you love to worship. You pour drink offerings over them. You offer grain to them. Because of what you do, should I not punish you? and they become your idols. They are the gods that you love to worship. You pour drink offerings over them. You offer grain to them. Because of what you do, should I not punish you?"
    },
    {
      "verse": "7",
      "text": "You go up to the tops of high hills, and you lie down there to have sex. You go there to offer sacrifices to your gods. and you lie down there to have sex. You go there to offer sacrifices to your gods."
    },
    {
      "verse": "8",
      "text": "You put your images behind the doors of your rooms. Then you turn your backs to me, and you get into bed with your false gods. You have made an agreement with them. You pay money to have sex with your lovers. You love to see their bare bodies. Then you turn your backs to me, and you get into bed with your false gods. You have made an agreement with them. You pay money to have sex with your lovers. You love to see their bare bodies."
    },
    {
      "verse": "9",
      "text": "You take olive oil as a gift to your king, and also many perfumes. You send your people far awayto get news of other gods. You even talk to the spirits of dead people. and also many perfumes. You send your people far away to get news of other gods. You even talk to the spirits of dead people."
    },
    {
      "verse": "10",
      "text": "You become very tired, because you travel so far. But you would never say, “This is useless! ”Instead, you find new strength, and you do not stop. because you travel so far. But you would never say, “This is useless! ” Instead, you find new strength, and you do not stop."
    },
    {
      "verse": "11",
      "text": "What idol are you so afraid of, that you choose to deceive me? You seem to have forgotten about me. You do not think about me at all. Have I been silent for too long? Is that why you no longer respect me? that you choose to deceive me? You seem to have forgotten about me. You do not think about me at all. Have I been silent for too long? Is that why you no longer respect me?"
    },
    {
      "verse": "12",
      "text": "Now I will speak against the things that you do. You think that they are good and right, but those things will not help you. You think that they are good and right, but those things will not help you."
    },
    {
      "verse": "13",
      "text": "Shout for help, if you like. See if your group of idols can help you! The wind will blow them all away. Even a breath will carry them away. But if people trust me to help them, this land will belong to them. They will worship me on my holy mountain. ’ See if your group of idols can help you! The wind will blow them all away. Even a breath will carry them away. But if people trust me to help them, this land will belong to them. They will worship me on my holy mountain. ’"
    },
    {
      "verse": "14",
      "text": "The Lord says, ‘Build a road! Make it ready for my people to travel on! Remove everything that would cause them to fall. ’ ‘Build a road! Make it ready for my people to travel on! Remove everything that would cause them to fall. ’"
    },
    {
      "verse": "15",
      "text": "The Mighty God is far higher than all others. He rules from above and he lives for ever. His name is holy. He says, ‘I live in a high and holy place. But I am also with anyone who is humbleand who is sorry when he does wrong things. I will comfort people who are like that, and I will give them hope. ‘I live in a high and holy place. But I am also with anyone who is humble and who is sorry when he does wrong things. I will comfort people who are like that, and I will give them hope."
    },
    {
      "verse": "16",
      "text": "I will not always speak against my people. I will not be angry with them for ever. I do not want them to lose hope completely. I myself gave life to them. I will not be angry with them for ever. I do not want them to lose hope completely. I myself gave life to them."
    },
    {
      "verse": "17",
      "text": "I was angry with them because they were greedy, which was a sin. So I punished them. I was angry and I turned away from them. But they still refused to obey me. They continued to do what they wanted to do. which was a sin. So I punished them. I was angry and I turned away from them. But they still refused to obey me. They continued to do what they wanted to do."
    },
    {
      "verse": "18",
      "text": "I have seen what they are doing. But I will make them well again. I will be a guide for them, and I will comfort them again. Then people who are sad and they are weeping But I will make them well again. I will be a guide for them, and I will comfort them again. Then people who are sad and they are weeping"
    },
    {
      "verse": "19",
      "text": "will sing songs to praise me! I will give them a reason to do that. I will bring peace to all my people, those who are far away, and those who are near. Yes, I will make them completely well again. ’That is what the Lord says. I will give them a reason to do that. I will bring peace to all my people, those who are far away, and those who are near. Yes, I will make them completely well again. ’ That is what the Lord says."
    },
    {
      "verse": "20",
      "text": "‘But wicked people are like a rough seawith dangerous waves. It cannot stay still. Its waves throw up mud and dirt. with dangerous waves. It cannot stay still. Its waves throw up mud and dirt."
    },
    {
      "verse": "21",
      "text": "There will never be peace for wicked people. ’That is what my God says."
    }
  ],
  "58": [
    {
      "verse": "1",
      "text": "The Lord says, ‘Shout out! Shout as loudly as you can! Make as much noise as a trumpet makes! Tell my people that they have not obeyed me. Tell the family of Jacob about their sins. ‘Shout out! Shout as loudly as you can! Make as much noise as a trumpet makes! Tell my people that they have not obeyed me. Tell the family of Jacob about their sins."
    },
    {
      "verse": "2",
      "text": "Every day my people come to worship me. It seems that they want to know my ways. They seem like a nation of peoplewho are doing the right things. They seem to be obeying the law of their God. They ask me to decide things fairly. Yes, they seem to want to be near to me. It seems that they want to know my ways. They seem like a nation of people who are doing the right things. They seem to be obeying the law of their God. They ask me to decide things fairly. Yes, they seem to want to be near to me."
    },
    {
      "verse": "3",
      "text": "They say to me, “We have fasted to please you, but you do not see it. We make ourselves humbleand you do not even look. ”Listen to me! Yes you fast, but you do it to please yourselves. At the same time as you are fasting, you are being cruel to the people who work for you. but you do not see it. We make ourselves humble and you do not even look. ” Listen to me! Yes you fast, but you do it to please yourselves. At the same time as you are fasting, you are being cruel to the people who work for you."
    },
    {
      "verse": "4",
      "text": "Yes! While you are fasting, you are also quarrelling and you are fighting. You hit each other with your fists. If you want your prayers to reach me in heaven, you cannot continue to fast in the way that you do today. you are also quarrelling and you are fighting. You hit each other with your fists. If you want your prayers to reach me in heaven, you cannot continue to fast in the way that you do today."
    },
    {
      "verse": "5",
      "text": "The way that you fast does not please me at all: You make yourselves humble for a day. You bend down your head, like a piece of weak grass. You lie down on sackcloth and ashes. Do you think that you are really fasting when you do that? Do you think that it pleases me, the Lord? You make yourselves humble for a day. You bend down your head, like a piece of weak grass. You lie down on sackcloth and ashes. Do you think that you are really fasting when you do that? Do you think that it pleases me, the Lord?"
    },
    {
      "verse": "6",
      "text": "This is the way that I want you to fast: You must remove the chainsfrom prisoners who should not be in prison. You must stop being cruelto the people who work for you. You must let people who are in pain go free. You must break the yokeof work that is too hard for weak people. You must remove the chains from prisoners who should not be in prison. You must stop being cruel to the people who work for you. You must let people who are in pain go free. You must break the yoke of work that is too hard for weak people."
    },
    {
      "verse": "7",
      "text": "Instead, share your food with hungry people. Give a place in your hometo poor people who have no home. Give clothes to people who have nothing to wear. If people in your own family need help, do not refuse to help them. Give a place in your home to poor people who have no home. Give clothes to people who have nothing to wear. If people in your own family need help, do not refuse to help them."
    },
    {
      "verse": "8",
      "text": "Then God's light will shine on you, like the sun's light at dawn. Very soon, your troubles will go away. The good things that you do to help otherswill be clear for everyone to see. And the Lord will use his great powerto keep you safe. like the sun's light at dawn. Very soon, your troubles will go away. The good things that you do to help others will be clear for everyone to see. And the Lord will use his great power to keep you safe."
    },
    {
      "verse": "9",
      "text": "Then you will ask the Lord for helpand he will answer you. When you call out to him, he will say, “Here I am. ”But you must stop being cruel to other people. Do not accuse people, and do not say bad things about them. and he will answer you. When you call out to him, he will say, “Here I am. ” But you must stop being cruel to other people. Do not accuse people, and do not say bad things about them."
    },
    {
      "verse": "10",
      "text": "If people are hungry, share your own food with them. Help those people who are in pain. Then your help to them will be like a lightthat shines in a dark place. You will no longer live in darkness, but you will have light as bright as the sun at noon. share your own food with them. Help those people who are in pain. Then your help to them will be like a light that shines in a dark place. You will no longer live in darkness, but you will have light as bright as the sun at noon."
    },
    {
      "verse": "11",
      "text": "The Lord will always be your guide. He will give you plenty to eat, even when the ground is dry. He will make your bodies strong. You will be like a garden that has plenty of water. You will be like a spring of waterthat never becomes dry. He will give you plenty to eat, even when the ground is dry. He will make your bodies strong. You will be like a garden that has plenty of water. You will be like a spring of water that never becomes dry."
    },
    {
      "verse": "12",
      "text": "You will build again the citieswhich became heaps of stones a long time ago. You will build your houses on the old foundations. People will call you, “Builders who mend the walls and the streets with their houses. ” which became heaps of stones a long time ago. You will build your houses on the old foundations. People will call you, “Builders who mend the walls and the streets with their houses. ”"
    },
    {
      "verse": "13",
      "text": "So remember to obey the rules for the Sabbath day. That is my holy day, so do not just try to please yourselves. Enjoy the Sabbath day, and respect it as the Lord's holy day. Do not do your usual work on that day. Do not do things or speak about things, only to make yourself happy. That is my holy day, so do not just try to please yourselves. Enjoy the Sabbath day, and respect it as the Lord's holy day. Do not do your usual work on that day. Do not do things or speak about things, only to make yourself happy."
    },
    {
      "verse": "14",
      "text": "If you do those things, you will be happyas you serve me, the Lord. I will give you all the things that you need. I will cause crops to growon the land that I gave to your ancestor Jacob. ’That is the Lord's message."
    }
  ],
  "59": [
    {
      "verse": "1",
      "text": "Listen! The Lord's hand is not too weak to save you. His ear is not too deaf to hear you. His ear is not too deaf to hear you."
    },
    {
      "verse": "2",
      "text": "But the wrong things that you have donehave made you separate from your God. Your sins have caused him to turn away from you, so that he does not listen to your prayers. have made you separate from your God. Your sins have caused him to turn away from you, so that he does not listen to your prayers."
    },
    {
      "verse": "3",
      "text": "Your hands are dirty with the blood of murder. They are dirty with all the bad things that you do. Your mouth tells lies, and it says wicked things about other people. They are dirty with all the bad things that you do. Your mouth tells lies, and it says wicked things about other people."
    },
    {
      "verse": "4",
      "text": "When people accuse somebody in court, the truth is not important. They tell lies and they deceive the judge, so that they will win. They decide how they can cause trouble, and then they do wicked things. the truth is not important. They tell lies and they deceive the judge, so that they will win. They decide how they can cause trouble, and then they do wicked things."
    },
    {
      "verse": "5",
      "text": "Their thoughts are like the eggs of a snake. If anyone eats those eggs, they will die! When an egg breaks open, a dangerous snake is born! They like to catch people, like a spider that makes a web. If anyone eats those eggs, they will die! When an egg breaks open, a dangerous snake is born! They like to catch people, like a spider that makes a web."
    },
    {
      "verse": "6",
      "text": "Their webs are useless to make clothes. They cannot cover themselves with them. The things that they do are useless like that. They do only wicked things. They use their strength only to hurt people. They cannot cover themselves with them. The things that they do are useless like that. They do only wicked things. They use their strength only to hurt people."
    },
    {
      "verse": "7",
      "text": "They rush to do evil things. They hurry to kill people who have not done anything wrong. They think only about sin. They only want to be cruel and to hurt people. They hurry to kill people who have not done anything wrong. They think only about sin. They only want to be cruel and to hurt people."
    },
    {
      "verse": "8",
      "text": "They do not know how to live in peace. They cannot be honest and fair. Their way of life is all wrong. Nobody who lives like that will have peace. They cannot be honest and fair. Their way of life is all wrong. Nobody who lives like that will have peace."
    },
    {
      "verse": "9",
      "text": "Because of that, God's justice is far away from us. He has not come to save us. We look for light to come to us, but everything is dark. We need some light in our lives, but all we have is darkness. He has not come to save us. We look for light to come to us, but everything is dark. We need some light in our lives, but all we have is darkness."
    },
    {
      "verse": "10",
      "text": "Like blind people, we touch the wall to find our way. It seems that we have no eyes to see with. Even at midday, we trip and we fall down, as if it was dark. We are like dead peoplewho live among strong people. we touch the wall to find our way. It seems that we have no eyes to see with. Even at midday, we trip and we fall down, as if it was dark. We are like dead people who live among strong people."
    },
    {
      "verse": "11",
      "text": "We all make a noise, like hungry bears. We make sad noises, like doves. We are waiting for God to bring justice to us, but nothing is happening. We look for his salvation, but it is still far away. We make sad noises, like doves. We are waiting for God to bring justice to us, but nothing is happening. We look for his salvation, but it is still far away."
    },
    {
      "verse": "12",
      "text": "Lord, you see all the bad things that we have done. Our many sins show that we are wrong. We know about the wrong things that we have done. We agree that our sins are many. Our many sins show that we are wrong. We know about the wrong things that we have done. We agree that our sins are many."
    },
    {
      "verse": "13",
      "text": "We have turned against the Lord. We have refused to obey him. We have chosen to be cruel to other people, and we have turned against the truth. We think about the lies that we can tell, and we use them to deceive people. We have refused to obey him. We have chosen to be cruel to other people, and we have turned against the truth. We think about the lies that we can tell, and we use them to deceive people."
    },
    {
      "verse": "14",
      "text": "Judges do not decide in a fair way. Nobody tries to do what is right. There is no place for truth on the streets of our towns. Honest people have to leave. Nobody tries to do what is right. There is no place for truth on the streets of our towns. Honest people have to leave."
    },
    {
      "verse": "15",
      "text": "Nobody can speak the truth. If anyone tries to stop doing evil things, other people will attack him. The Lord saw how his people were living. He saw that there was no justice. It made him very sad. If anyone tries to stop doing evil things, other people will attack him. The Lord saw how his people were living. He saw that there was no justice. It made him very sad."
    },
    {
      "verse": "16",
      "text": "He saw that there was nobody who would help, and he was very upset. So he used his own strength to help. Because he had to do what was right, he made his people safe. and he was very upset. So he used his own strength to help. Because he had to do what was right, he made his people safe."
    },
    {
      "verse": "17",
      "text": "He always does what is right, like a soldier who always puts on his armour. His power to save peopleis like the helmet that he wears. He is angry against people who do evil things, and he works hard to punish them. That is like the clothes that he wears. like a soldier who always puts on his armour. His power to save people is like the helmet that he wears. He is angry against people who do evil things, and he works hard to punish them. That is like the clothes that he wears."
    },
    {
      "verse": "18",
      "text": "He will punish his enemiesfor the bad things that they have done. He will be very angry with them. He will punish all his enemies, even those who live in lands far away. for the bad things that they have done. He will be very angry with them. He will punish all his enemies, even those who live in lands far away."
    },
    {
      "verse": "19",
      "text": "Then people who live in the westwill respect the Lord's name. And people who live in the eastwill see how great he is. The Lord will attack them like a fast river. He will blow them away with a strong wind. will respect the Lord's name. And people who live in the east will see how great he is. The Lord will attack them like a fast river. He will blow them away with a strong wind."
    },
    {
      "verse": "20",
      "text": "The Lord says, ‘A Redeemer will come to Zion. He will come to save Jacob's peoplewho turn away from their sins. ’ ‘A Redeemer will come to Zion. He will come to save Jacob's people who turn away from their sins. ’"
    },
    {
      "verse": "21",
      "text": "The Lord says, ‘This is the covenant that I make with those people. My Spirit is now with you, and he will not leave you. I have put my words into your mouth, and they will always be with you. They will continue to be in the mouths of your children, and your descendants for ever. ’That is what the Lord says."
    }
  ],
  "60": [
    {
      "verse": "1",
      "text": "Stand up! Shine brightly! Now your light has come! The Lord's glory has risen to shine on you. Now your light has come! The Lord's glory has risen to shine on you."
    },
    {
      "verse": "2",
      "text": "Look! Darkness covers all the earth and its people. But the Lord shines his light on you, so that his glory appears over you. But the Lord shines his light on you, so that his glory appears over you."
    },
    {
      "verse": "3",
      "text": "People of other nations will come to your light. Kings will come to see the light of a new day that shines on you. Kings will come to see the light of a new day that shines on you."
    },
    {
      "verse": "4",
      "text": "Look all round you! All your people are coming together to return to you. Your sons are coming from far away, and they carry your daughters in their arms. All your people are coming together to return to you. Your sons are coming from far away, and they carry your daughters in their arms."
    },
    {
      "verse": "5",
      "text": "As you see this, your eyes will shine with joy. Your hearts will beat fast, and you will be proud to see them. Traders will bring valuable things to youfrom lands across the seas. The riches of other nations will come to you. Your hearts will beat fast, and you will be proud to see them. Traders will bring valuable things to you from lands across the seas. The riches of other nations will come to you."
    },
    {
      "verse": "6",
      "text": "Traders will bring things on their camelsso that your roads are full. Young camels will come from Midianand from Ephah. People will come from Sheba. They will bring gold and incense. They will sing aloud to praise the Lord. so that your roads are full. Young camels will come from Midian and from Ephah. People will come from Sheba. They will bring gold and incense. They will sing aloud to praise the Lord."
    },
    {
      "verse": "7",
      "text": "All the sheep and goats in Kedar will come to you. They will give you sheep from Nebaioth, and I will accept them as sacrifices on my altar. I will make my temple great and beautiful. They will give you sheep from Nebaioth, and I will accept them as sacrifices on my altar. I will make my temple great and beautiful."
    },
    {
      "verse": "8",
      "text": "See those ships that sail along like clouds! They come like doves that are flying to their homes. They come like doves that are flying to their homes."
    },
    {
      "verse": "9",
      "text": "People from lands across the seas are coming to find me. Their big ships are leading them. They are bringing your children from far away, as well as silver and gold. They come to give honour to the name of the Lord your God. He is Israel's Holy God. They come here because he has shown that you are great. Their big ships are leading them. They are bringing your children from far away, as well as silver and gold. They come to give honour to the name of the Lord your God. He is Israel's Holy God. They come here because he has shown that you are great."
    },
    {
      "verse": "10",
      "text": "Foreign people will build your walls again. Their kings will be your servants. I punished you when I was angry with you. But now I will show my graceand I will be kind to you. Their kings will be your servants. I punished you when I was angry with you. But now I will show my grace and I will be kind to you."
    },
    {
      "verse": "11",
      "text": "The gates of your city will always be open. People will never close them, during the day or during the night. Then other nations will bring their riches to you, and their kings will lead them. People will never close them, during the day or during the night. Then other nations will bring their riches to you, and their kings will lead them."
    },
    {
      "verse": "12",
      "text": "Any nation or kingdom that refuses to serve youwill come to an end. Enemies will completely destroy those nations. will come to an end. Enemies will completely destroy those nations."
    },
    {
      "verse": "13",
      "text": "The beautiful things of Lebanon will come to you. They will bring you its pine trees, its fir trees and its cypress trees. The wood will make my temple beautiful. I will cause my home on earth to be great! They will bring you its pine trees, its fir trees and its cypress trees. The wood will make my temple beautiful. I will cause my home on earth to be great!"
    },
    {
      "verse": "14",
      "text": "The descendants of your cruel enemies will come to you. They will bend down low in front of you. Everybody who insulted you beforewill now give you honour. They will call you, ‘The City of the Lord, Zion that is home for Israel's Holy God. ’ They will bend down low in front of you. Everybody who insulted you before will now give you honour. They will call you, ‘The City of the Lord, Zion that is home for Israel's Holy God. ’"
    },
    {
      "verse": "15",
      "text": "At one time, people kept away from you, and they hated you. Nobody travelled through you. But now I will make you a great city, so that people will be proud of you for ever. Your people and their descendants will be very happy. and they hated you. Nobody travelled through you. But now I will make you a great city, so that people will be proud of you for ever. Your people and their descendants will be very happy."
    },
    {
      "verse": "16",
      "text": "Other nations and their kingswill give you everything that you need. They will be like motherswho feed their babies with their milk. Then you will know that I, the Lord, have made you safe. You will know that I am your Redeemer, the Mighty One of Jacob. will give you everything that you need. They will be like mothers who feed their babies with their milk. Then you will know that I, the Lord, have made you safe. You will know that I am your Redeemer, the Mighty One of Jacob."
    },
    {
      "verse": "17",
      "text": "I will bring you gold instead of bronze. I will bring you silver instead of iron. I will give you bronze to use, instead of wood. I will give you iron instead of stones. I will cause peace to be your city's leader. Righteousness will rule over you. I will bring you silver instead of iron. I will give you bronze to use, instead of wood. I will give you iron instead of stones. I will cause peace to be your city's leader. Righteousness will rule over you."
    },
    {
      "verse": "18",
      "text": "You will not hear the noise of violence in your land any more. Inside its borders, nobody will fight wars or destroy things. You will call your city's walls ‘Salvation’, and you will call your city's gates ‘Praise’. Inside its borders, nobody will fight wars or destroy things. You will call your city's walls ‘Salvation’, and you will call your city's gates ‘Praise’."
    },
    {
      "verse": "19",
      "text": "You will no longer need the sunto give you light in the day again. You will not need the moon to shine at night. Instead, the Lord will be the lightthat shines on you for ever. Yes, your God will be the lightthat brings you honour. to give you light in the day again. You will not need the moon to shine at night. Instead, the Lord will be the light that shines on you for ever. Yes, your God will be the light that brings you honour."
    },
    {
      "verse": "20",
      "text": "Your sun will never go down againand your moon will never disappear. That is because the Lord will be the lightthat shines on you for ever. Then your sad days will come to an end. and your moon will never disappear. That is because the Lord will be the light that shines on you for ever. Then your sad days will come to an end."
    },
    {
      "verse": "21",
      "text": "All your people will be righteous. The land will belong to them for ever. I myself will plant them in the groundlike a young plant. As they grow, they will show how great I am. The land will belong to them for ever. I myself will plant them in the ground like a young plant. As they grow, they will show how great I am."
    },
    {
      "verse": "22",
      "text": "The least important person among youwill become a great family. The smallest person will become a large nation. I am the Lord. When the right time comes, I will cause it to happen quickly!"
    }
  ],
  "61": [
    {
      "verse": "1",
      "text": "The Spirit of the Almighty Lord is on me, because he has chosen me to serve him. He has sent me to tell good news to poor people. He has sent me to comfort people who are very upset. He has sent me to tell prisoners that they are now free. They can go out of their prisons! because he has chosen me to serve him. He has sent me to tell good news to poor people. He has sent me to comfort people who are very upset. He has sent me to tell prisoners that they are now free. They can go out of their prisons!"
    },
    {
      "verse": "2",
      "text": "He has sent me to say, ‘This is the year when the Lord will be kind to his people. ’It is the time when our God will punish our enemies. He has sent me to comfort people who are weepingbecause they are sad. ‘This is the year when the Lord will be kind to his people. ’ It is the time when our God will punish our enemies. He has sent me to comfort people who are weeping because they are sad."
    },
    {
      "verse": "3",
      "text": "In that way, the people in Zion who are sadwill become strong again. They will not put ashes on their heads any more. Instead, they will wear beautiful hats. Instead of weeping, they will have olive oil to show their joy. They will not feel upset, but they will sing happy songs to praise God. People will call them ‘Strong trees that show God's righteousness’. They will be like trees that the Lord himself has plantedto show how great he is. will become strong again. They will not put ashes on their heads any more. Instead, they will wear beautiful hats. Instead of weeping, they will have olive oil to show their joy. They will not feel upset, but they will sing happy songs to praise God. People will call them ‘Strong trees that show God's righteousness’. They will be like trees that the Lord himself has planted to show how great he is."
    },
    {
      "verse": "4",
      "text": "God's people will build again their townsthat became heaps of stones a long time ago. Once again, they will live in the citiesthat have been empty for so long. that became heaps of stones a long time ago. Once again, they will live in the cities that have been empty for so long."
    },
    {
      "verse": "5",
      "text": "The Lord says to his people, ‘Foreign people will take care of your sheep for you. They will work on your farms, and they will take care of your vines. ‘Foreign people will take care of your sheep for you. They will work on your farms, and they will take care of your vines."
    },
    {
      "verse": "6",
      "text": "People will call you“The Lord's priests who are servants of our God”. You will enjoy valuable things from other nations. You will boast about all the richesthat you receive from them. “The Lord's priests who are servants of our God”. You will enjoy valuable things from other nations. You will boast about all the riches that you receive from them."
    },
    {
      "verse": "7",
      "text": "You will not be ashamed any more. Instead, you will receive twice as much blessing. People will not say that you are useless. Instead, you will live happily on your own land. Yes, my people will have twice the crops from their land, And so they will always be very happy. Instead, you will receive twice as much blessing. People will not say that you are useless. Instead, you will live happily on your own land. Yes, my people will have twice the crops from their land, And so they will always be very happy."
    },
    {
      "verse": "8",
      "text": "I, the Lord, love justice. I hate it when people rob others, or they do other wrong things. Because I am faithful, I will give help to my people. I will make a covenant with themthat will continue for ever. I hate it when people rob others, or they do other wrong things. Because I am faithful, I will give help to my people. I will make a covenant with them that will continue for ever."
    },
    {
      "verse": "9",
      "text": "Their descendants will be famousamong the other nations. Everyone who sees them will knowthat the Lord has blessed them. ’ among the other nations. Everyone who sees them will know that the Lord has blessed them. ’"
    },
    {
      "verse": "10",
      "text": "I am very happy, because of what the Lord, my God, has done. I have so much joy! He has given salvation to me, like clothes that I can wear all the time. I have his righteousness as my coat! He makes me handsome, like a bridegroom who wears a priest's hat. He makes me beautiful, like a bride who wears her jewels. because of what the Lord, my God, has done. I have so much joy! He has given salvation to me, like clothes that I can wear all the time. I have his righteousness as my coat! He makes me handsome, like a bridegroom who wears a priest's hat. He makes me beautiful, like a bride who wears her jewels."
    },
    {
      "verse": "11",
      "text": "The Almighty Lord will cause his righteousnessto grow everywhere. It will grow like crops in the fields, and like plants that grow in a garden. Then his people will praise him, and all the nations will see it!"
    }
  ],
  "62": [
    {
      "verse": "1",
      "text": "Because I love Zion, I will not be quiet. I cannot stay quiet, because Jerusalem is in trouble. I will continue to speak until she is safe again. I want her righteousness to shinelike the sun at dawn. I want her salvation to be a bright light in the dark. I will not be quiet. I cannot stay quiet, because Jerusalem is in trouble. I will continue to speak until she is safe again. I want her righteousness to shine like the sun at dawn. I want her salvation to be a bright light in the dark."
    },
    {
      "verse": "2",
      "text": "Jerusalem, the nations will see your righteousness. All their kings will see how great you are. People will call you by a new name, which the Lord himself will give to you. All their kings will see how great you are. People will call you by a new name, which the Lord himself will give to you."
    },
    {
      "verse": "3",
      "text": "The Lord your God will hold you in his hand, and you will bring him honour. You will be like his beautiful crown! and you will bring him honour. You will be like his beautiful crown!"
    },
    {
      "verse": "4",
      "text": "They will no longer call you by the name ‘Alone’. They will not call your land ‘Empty place’. Instead, they will call you ‘The one that makes God happy’. The name of your land will be ‘Married’. Yes, the Lord will be very happy with you. Your land will be his bride. They will not call your land ‘Empty place’. Instead, they will call you ‘The one that makes God happy’. The name of your land will be ‘Married’. Yes, the Lord will be very happy with you. Your land will be his bride."
    },
    {
      "verse": "5",
      "text": "As a young man marries a pure young woman, so your sons will marry you, Jerusalem. Your God will be very happy that you belong to him, as a bridegroom is happy with his new wife. so your sons will marry you, Jerusalem. Your God will be very happy that you belong to him, as a bridegroom is happy with his new wife."
    },
    {
      "verse": "6",
      "text": "I have put guards on your walls, Jerusalem. They should never be quiet, during the day and during the night. You people who cause the Lord to remember his promises, never stop and rest! They should never be quiet, during the day and during the night. You people who cause the Lord to remember his promises, never stop and rest!"
    },
    {
      "verse": "7",
      "text": "Do not give the Lord a chance to rest, until he has made Jerusalem strong again. Continue to pray until he makes it a famous citythat the whole world will praise. until he has made Jerusalem strong again. Continue to pray until he makes it a famous city that the whole world will praise."
    },
    {
      "verse": "8",
      "text": "The Lord makes a strong promise, and he has the power to make it happen. He says:‘I will never again take away your grain, and give it to your enemies for food. Foreign soldiers will not drink your winethat you have worked very hard to make. and he has the power to make it happen. He says: ‘I will never again take away your grain, and give it to your enemies for food. Foreign soldiers will not drink your wine that you have worked very hard to make."
    },
    {
      "verse": "9",
      "text": "Instead, the people who pick the grain at harvest timeare the people who will eat it. And they will praise the Lord for it. The people who pick the grapeswill drink the wine. They will drink it in the yards of my temple. ’ are the people who will eat it. And they will praise the Lord for it. The people who pick the grapes will drink the wine. They will drink it in the yards of my temple. ’"
    },
    {
      "verse": "10",
      "text": "Pass through the gates! Pass through the gates! Prepare the way for the people to travel on. Build up the road! Make it strong! Remove the stones! Lift up a flag, so that the nations can see the way to go. Prepare the way for the people to travel on. Build up the road! Make it strong! Remove the stones! Lift up a flag, so that the nations can see the way to go."
    },
    {
      "verse": "11",
      "text": "Look! The Lord has this message for the whole earth:‘Say to the people of Zion, “Look! Your Saviour is coming! Look again! He is bringing his gifts with him. He brings the prize that he has won. ” ’ ‘Say to the people of Zion, “Look! Your Saviour is coming! Look again! He is bringing his gifts with him. He brings the prize that he has won. ” ’"
    },
    {
      "verse": "12",
      "text": "Their name will be ‘God's holy People’, and ‘The People that the Lord has redeemed’. And Jerusalem's name will be ‘The City where people are happy’, and ‘The City that is full of people’."
    }
  ],
  "63": [
    {
      "verse": "1",
      "text": "Who is this who is coming from Edom? He is coming from Bozrahand his clothes are bright red. He wears beautiful royal clothes, and he marches forward with great strength. He says, ‘It is me! I, the Lord, tell you that I have won the fight! I have the power to save you. ’ He is coming from Bozrah and his clothes are bright red. He wears beautiful royal clothes, and he marches forward with great strength. He says, ‘It is me! I, the Lord, tell you that I have won the fight! I have the power to save you. ’"
    },
    {
      "verse": "2",
      "text": "But why are your clothes red? You look like someone who has walked on grapes, and you have squeezed them to make wine. You look like someone who has walked on grapes, and you have squeezed them to make wine."
    },
    {
      "verse": "3",
      "text": "He says, ‘I have walked on the grapes alone. Nobody from the nations came to help me. I walked on them because I was angry. I squeezed them to pieces in my anger. Their blood splashed on my clothes, and it made all my clothes dirty. Nobody from the nations came to help me. I walked on them because I was angry. I squeezed them to pieces in my anger. Their blood splashed on my clothes, and it made all my clothes dirty."
    },
    {
      "verse": "4",
      "text": "I decided that it was time to punish my enemies. Then I would save my people from their power. Then I would save my people from their power."
    },
    {
      "verse": "5",
      "text": "I looked for somebody to give help, but there was nobody. I was very upset, because nobody was there to help. So I used my own strength to rescue my people. My anger helped me to be strong. but there was nobody. I was very upset, because nobody was there to help. So I used my own strength to rescue my people. My anger helped me to be strong."
    },
    {
      "verse": "6",
      "text": "Because I was angry, I walked on the nations to punish them. My anger was like strong wine that made them drunk. I poured their blood onto the ground. ’ I walked on the nations to punish them. My anger was like strong wine that made them drunk. I poured their blood onto the ground. ’"
    },
    {
      "verse": "7",
      "text": "I will speak about all the good things that the Lord does because he loves his people. We should praise him for everything that he does for us. He has done many good things for us, Israel's family. He helps us because he loves us very much, and he is very kind."
    },
    {
      "verse": "8",
      "text": "The Lord said, ‘Surely, they are my own people. As my children, they will not turn against me. ’ So he became their Saviour."
    },
    {
      "verse": "9",
      "text": "When his people suffered, he also had pain. He sent his own angel to go and save them. Because he loved them and he was kind to them, he redeemed them. He lifted them up and he carried them, through all the years long ago."
    },
    {
      "verse": "10",
      "text": "But they turned against him. They made his Holy Spirit angry. So he then became their enemy. He fought against them."
    },
    {
      "verse": "11",
      "text": "Then they remembered past years, when Moses led their ancestors out of Egypt. They said, ‘Where is the Lord now, when we need him? He brought his people safely through the sea, with Moses as their leader. He caused his Holy Spirit to work among them. Yes, Lord, you were your people's guide. In that way, you made your name great."
    },
    {
      "verse": "12",
      "text": "He caused his power to be with Moses, as Moses raised his arm over the sea. He caused the waters to become separate so that his people could go across. In that way, he caused his name always to be famous."
    },
    {
      "verse": "13",
      "text": "He led them through the deep water of the sea. They ran across like horses on open ground, and they did not fall."
    },
    {
      "verse": "14",
      "text": "The Lord's Spirit led them to a place of rest, like cows that go down to a quiet valley. ’Yes, Lord, you were your people's guide. In that way, you made your name great."
    },
    {
      "verse": "15",
      "text": "So now, do something to help us! Look down from your beautiful, holy home in heaven. Use your power to show that we are your special people. Have you forgotten how to be kind to us?"
    },
    {
      "verse": "16",
      "text": "Remember that you are our Father. Maybe our ancestor Abraham does not recognize us. Even Israel himself may not recognize us. But you, Lord, are our Father. Since times long ago, your name has been our Redeemer."
    },
    {
      "verse": "17",
      "text": "Lord, why do you cause us to turn away from your ways? You make our minds become hard, so that we do not obey you. Please come back to help us, because we are your servants. We are the tribes that you have chosen for yourself!"
    },
    {
      "verse": "18",
      "text": "For only a short time, the holy place belonged to us, your special people. Then our enemies knocked down your temple."
    },
    {
      "verse": "19",
      "text": "It seems that we have not belonged to you for a long time. You no longer rule over us or take care of us."
    }
  ],
  "64": [
    {
      "verse": "1",
      "text": "Please Lord, break open the skiesand come down to help us! That would make the mountains shake! and come down to help us! That would make the mountains shake!"
    },
    {
      "verse": "2",
      "text": "You would come like a fire that burns up wood, and it causes water to boil. The nations would shake with fear. Your enemies would know why your name is so great. and it causes water to boil. The nations would shake with fear. Your enemies would know why your name is so great."
    },
    {
      "verse": "3",
      "text": "In the past, you did great things, and they surprised us. You came down and the mountains shook with fear. and they surprised us. You came down and the mountains shook with fear."
    },
    {
      "verse": "4",
      "text": "From the beginning, nobody has heard of any God like you. You come to help those people who trust in you. Nobody has ever seen or heard of a God like you! You come to help those people who trust in you. Nobody has ever seen or heard of a God like you!"
    },
    {
      "verse": "5",
      "text": "You help people who are happy when they do what is right. People like that obey your commands. But we continued to do wrong things, even when you were angry with us. We have done bad things for a long time, so will you ever come to save us? People like that obey your commands. But we continued to do wrong things, even when you were angry with us. We have done bad things for a long time, so will you ever come to save us?"
    },
    {
      "verse": "6",
      "text": "Our sins have made us all like unclean people, who cannot worship you. Even the good things that we try to doare like dirty bits of cloth. Our sins will blow us all away, as the wind blows away dead leaves. who cannot worship you. Even the good things that we try to do are like dirty bits of cloth. Our sins will blow us all away, as the wind blows away dead leaves."
    },
    {
      "verse": "7",
      "text": "Nobody prays in your name, or calls out to you to help them. It seems that you have turned away from us. You have left us for our sins to rule us. or calls out to you to help them. It seems that you have turned away from us. You have left us for our sins to rule us."
    },
    {
      "verse": "8",
      "text": "But Lord, you are still our Father. We are like clay that you have used. You are like the potter who has made us into pots. You made us all with your own hands. We are like clay that you have used. You are like the potter who has made us into pots. You made us all with your own hands."
    },
    {
      "verse": "9",
      "text": "Lord, please do not be too angry with us. Do not hold our sins in your mind for ever. Do not forget us! We are your people, all of us! Do not hold our sins in your mind for ever. Do not forget us! We are your people, all of us!"
    },
    {
      "verse": "10",
      "text": "Your holy cities are as empty as a desert. Yes, Zion has become a desert. Jerusalem is just a heap of stones. Yes, Zion has become a desert. Jerusalem is just a heap of stones."
    },
    {
      "verse": "11",
      "text": "Our ancestors praised youhere in your temple. It was a beautiful place that we were proud of. But now fire has destroyed it. All our beautiful things are completely spoiled. here in your temple. It was a beautiful place that we were proud of. But now fire has destroyed it. All our beautiful things are completely spoiled."
    },
    {
      "verse": "12",
      "text": "Lord, see what is happening and do something! Will you continue to keep quiet? Will you continue to give us so much trouble?"
    }
  ],
  "65": [
    {
      "verse": "1",
      "text": "The Lord says, ‘I was ready to answer, even when my people did not ask me anything. I showed myself to peoplewho were not even looking for me. I said, “Look! Here I am! ” to a nationwho did not even use my name to pray. ‘I was ready to answer, even when my people did not ask me anything. I showed myself to people who were not even looking for me. I said, “Look! Here I am! ” to a nation who did not even use my name to pray."
    },
    {
      "verse": "2",
      "text": "All the time, I have been ready to help my people, even though they turned against me. But they continue to live in a way that is not good. They do whatever they want to do. even though they turned against me. But they continue to live in a way that is not good. They do whatever they want to do."
    },
    {
      "verse": "3",
      "text": "They continue to make me angry, as they insult me without shame. They offer sacrifices to their idols in their gardens. They burn incense to themon altars that are made from bricks. as they insult me without shame. They offer sacrifices to their idols in their gardens. They burn incense to them on altars that are made from bricks."
    },
    {
      "verse": "4",
      "text": "They sit among the gravesand they hide in caves. They eat meat from pigs. They use unclean meat to make their soup. and they hide in caves. They eat meat from pigs. They use unclean meat to make their soup."
    },
    {
      "verse": "5",
      "text": "They say to each other, “Keep away from me! Do not come near me! I am too holy for you! ”These people are like smoke in my nose! They are like a fire that burns all day. ’ “Keep away from me! Do not come near me! I am too holy for you! ” These people are like smoke in my nose! They are like a fire that burns all day. ’"
    },
    {
      "verse": "6",
      "text": "The Lord says, ‘Look! I have decided what I will do, and I have written it down: I will not keep quiet. I will punish them completely. I will give them everything that they deserve, ‘Look! I have decided what I will do, and I have written it down: I will not keep quiet. I will punish them completely. I will give them everything that they deserve,"
    },
    {
      "verse": "7",
      "text": "as punishment for their sinsand for the sins of their ancestors. They burned incense to their idols on the mountains, and they insulted me on the hills. So I will punish them completely, as much as they deserve. ’ and for the sins of their ancestors. They burned incense to their idols on the mountains, and they insulted me on the hills. So I will punish them completely, as much as they deserve. ’"
    },
    {
      "verse": "8",
      "text": "This is what the Lord says:‘If grapes still have some juice in them, someone will say, “Do not destroy them. There is some juice there that we can use. ”I will do the same thing for my servants. I will not destroy them all. ‘If grapes still have some juice in them, someone will say, “Do not destroy them. There is some juice there that we can use. ” I will do the same thing for my servants. I will not destroy them all."
    },
    {
      "verse": "9",
      "text": "I will cause Jacob's family to have descendants. There will be people of Judah's familywho will live on my mountains. The land will belong to the people that I have chosen. My servants will live there. There will be people of Judah's family who will live on my mountains. The land will belong to the people that I have chosen. My servants will live there."
    },
    {
      "verse": "10",
      "text": "Sharon will become a field where sheep safely eat grass. Cows will rest in the Valley of Achor. Those places will belong to my people, those who want to serve me. Cows will rest in the Valley of Achor. Those places will belong to my people, those who want to serve me."
    },
    {
      "verse": "11",
      "text": "But punishment will cometo those people who turn away from the Lord. You forget to worship me on my holy mountain. Instead, you prepare food and wineto offer to your false gods called “Luck” and “Fate”. to those people who turn away from the Lord. You forget to worship me on my holy mountain. Instead, you prepare food and wine to offer to your false gods called “Luck” and “Fate”."
    },
    {
      "verse": "12",
      "text": "So this will be your fate: a sword will kill you. You will all bend down low for someone to kill you. This will happen because you did not answer mewhen I spoke to you. You did not even listen to my words. You did evil things against me. You chose to do things that I would hate. ’ a sword will kill you. You will all bend down low for someone to kill you. This will happen because you did not answer me when I spoke to you. You did not even listen to my words. You did evil things against me. You chose to do things that I would hate. ’"
    },
    {
      "verse": "13",
      "text": "So the Almighty Lord says this:‘Look! My servants will eat, but you will be hungry. Look! My servants will drink, but you will be thirsty. Look! My servants will be happy, but you will be ashamed. ‘Look! My servants will eat, but you will be hungry. Look! My servants will drink, but you will be thirsty. Look! My servants will be happy, but you will be ashamed."
    },
    {
      "verse": "14",
      "text": "Yes, my servants will sing with joybecause they are so happy. But you will cry aloudbecause you are so sad. You will weepbecause you are very upset. because they are so happy. But you will cry aloud because you are so sad. You will weep because you are very upset."
    },
    {
      "verse": "15",
      "text": "My own people will use your names when they curse others. The Almighty Lord will kill you, but he will give to his servants another name. The Almighty Lord will kill you, but he will give to his servants another name."
    },
    {
      "verse": "16",
      "text": "People in the land will use the name of the true God, when they want to say a blessing. People in the land who want to make a strong promisewill also use the name of the true God. I will forget the troubles that happened in past years. I will no longer even think about them. when they want to say a blessing. People in the land who want to make a strong promise will also use the name of the true God. I will forget the troubles that happened in past years. I will no longer even think about them."
    },
    {
      "verse": "17",
      "text": "Listen! I will createnew heavens and a new earth. People will not remember what things were like before. Those thoughts will not be in their minds at all. new heavens and a new earth. People will not remember what things were like before. Those thoughts will not be in their minds at all."
    },
    {
      "verse": "18",
      "text": "But be happy about what I will create! Be happy for ever! I will create Jerusalem as a happy place. The people who live there will be full of joy. Be happy for ever! I will create Jerusalem as a happy place. The people who live there will be full of joy."
    },
    {
      "verse": "19",
      "text": "And Jerusalem will cause me to be happy. My people will give me joy. There will be no noise of people who are weeping. People will not be sad in Jerusalem again. My people will give me joy. There will be no noise of people who are weeping. People will not be sad in Jerusalem again."
    },
    {
      "verse": "20",
      "text": "Never again will there be a babywho only lives for a few days. Old men will continue to live a long life. People will live until they are 100 years oldand they will still seem young. If anyone dies before he is 100 years old, people will think that God has cursed him. who only lives for a few days. Old men will continue to live a long life. years old and they will still seem young. years old, people will think that God has cursed him."
    },
    {
      "verse": "21",
      "text": "My people will build housesand they will live in them. They will plant vineyardsand they will eat the fruit from them. and they will live in them. They will plant vineyards and they will eat the fruit from them."
    },
    {
      "verse": "22",
      "text": "They will no longer build housesand then other people live in them. They will not plant treesand then other people to eat the fruit. My people will have long lives, as long as trees live. My own people will live to enjoy the thingsthat they have worked hard to get. and then other people live in them. They will not plant trees and then other people to eat the fruit. My people will have long lives, as long as trees live. My own people will live to enjoy the things that they have worked hard to get."
    },
    {
      "verse": "23",
      "text": "Their work will not be useless. They will not give birth to childrenwho will live in fear. Instead, the Lord will bless their children. He will bless themand their descendants with them. They will not give birth to children who will live in fear. Instead, the Lord will bless their children. He will bless them and their descendants with them."
    },
    {
      "verse": "24",
      "text": "Before they call to me for help, I will answer them. While they are still praying, I will hear them. I will answer them. While they are still praying, I will hear them."
    },
    {
      "verse": "25",
      "text": "At that time, wolves and lambs will eat together. Lions will eat straw like cows. A snake's food will be dirt. Nothing will hurt or destroy anything elseanywhere on my holy mountain. ’That is what the Lord says."
    }
  ],
  "66": [
    {
      "verse": "1",
      "text": "This is what the Lord says:‘Heaven is my throne. The earth is the place where I put my feet. So you could not build a house for me to live in. Where would I lie down to rest? ‘Heaven is my throne. The earth is the place where I put my feet. So you could not build a house for me to live in. Where would I lie down to rest?"
    },
    {
      "verse": "2",
      "text": "I made all these things with my own hands. That is how everything began. ’The Lord says, ‘I am pleased with people who are humble. Those people are sorry when they do wrong things. They respect my teaching. That is how everything began. ’ The Lord says, ‘I am pleased with people who are humble. Those people are sorry when they do wrong things. They respect my teaching."
    },
    {
      "verse": "3",
      "text": "You may kill a bull as a sacrifice to me, but you might also kill a man. You may offer a lamb to me as a sacrifice, but you might also break a dog's neck to offer to your idols. You may give me a grain offering, but you also offer pigs' blood. You may burn incense to worship mebut you also worship false gods. Yes, these people have chosen how they want to live. They love to do these disgusting things. but you might also kill a man. You may offer a lamb to me as a sacrifice, but you might also break a dog's neck to offer to your idols. You may give me a grain offering, but you also offer pigs' blood. You may burn incense to worship me but you also worship false gods. Yes, these people have chosen how they want to live. They love to do these disgusting things."
    },
    {
      "verse": "4",
      "text": "So I will cause great trouble to come to them. It will be the trouble that they are so afraid of. When I called out to them, nobody answered me. When I spoke to them, nobody listened. They did evil things against me. They chose to do things that I would hate. ’ It will be the trouble that they are so afraid of. When I called out to them, nobody answered me. When I spoke to them, nobody listened. They did evil things against me. They chose to do things that I would hate. ’"
    },
    {
      "verse": "5",
      "text": "Hear this message from the Lord, you people who respect his teaching. Some of your own people hate you. They throw you out, because you are faithful to me. They laugh at you and they say, ‘Let the Lord show how great he is! We want to see him make you happy! ’But it is those people who will be ashamed. But it is those people who will be ashamed."
    },
    {
      "verse": "6",
      "text": "Listen to the loud noise that is coming from the city! It is a noise that comes from the temple. The Lord is punishing his enemies as they deserve. That is what is making the noise!"
    },
    {
      "verse": "7",
      "text": "What is happening? Zion is giving birth to a son before she has her birth pains!"
    },
    {
      "verse": "8",
      "text": "Nobody has ever heard of anything like that. Nobody has ever seen that happen before. Can a country be born in just one day? Can a nation be born in a moment? But as soon as Zion's birth pains begin, she has already given birth to her children!"
    },
    {
      "verse": "9",
      "text": "The Lord your God says, ‘When I bring a baby to the moment of birth, the child is always born. I do not stop its birth. ’"
    },
    {
      "verse": "10",
      "text": "All you people who love Jerusalem, join together with its people and be happy. You have been sad to see what has happened to the city, but now you should shout with joy!"
    },
    {
      "verse": "11",
      "text": "Jerusalem will take care of you like a mother. She will give you all that you need, like a mother that feeds her baby with milk. The great blessing that comes from her full breasts will make you very happy."
    },
    {
      "verse": "12",
      "text": "The Lord says, ‘Look! I will give peace to Jerusalem, like a great river. Riches from other nations will pour into the city, like a stream that is full of water. Jerusalem will take care of you like a mother that feeds her baby. She will carry you in her arms, and she will hold you on her knees. ‘Look! I will give peace to Jerusalem, like a great river. Riches from other nations will pour into the city, like a stream that is full of water. Jerusalem will take care of you like a mother that feeds her baby. She will carry you in her arms, and she will hold you on her knees."
    },
    {
      "verse": "13",
      "text": "I will comfort you, as a mother comforts her child. As you live in Jerusalem, you will be happy again. ’ as a mother comforts her child. As you live in Jerusalem, you will be happy again. ’"
    },
    {
      "verse": "14",
      "text": "And when you see these things happen, you will feel very happy! You will become strong and healthy, like fresh grass. The Lord's servants will know that he is there to bless them. But his enemies will see that he is angry with them."
    },
    {
      "verse": "15",
      "text": "Look! The Lord is coming with fire. His chariots will blow in like a strong storm. People will see his great anger, as he comes to punish his enemies with flames of fire."
    },
    {
      "verse": "16",
      "text": "The Lord will use fire and his sword to judge all people. The Lord will kill many people."
    },
    {
      "verse": "17",
      "text": "The Lord says, ‘I will destroy people who prepare themselves to worship their false gods. They make themselves clean and they follow one another into their special gardens. They eat unclean meat from pigs and rats and other disgusting animals. They will all come to their deaths together."
    },
    {
      "verse": "18",
      "text": "I know everything that they do and everything that they think. So I will come. I will bring together the people from all nations and those who speak all languages. I will show them how great I am."
    },
    {
      "verse": "19",
      "text": "I will do a great thing among them, to show them my power. I will send some of the people who are still alive to other nations. They will go to: Tarshish, Libya, Lydia (where their soldiers shoot arrows very well), Tubal, Greece, and lands far away, where people have never heard about me and they do not know how great I am. Those people will tell other nations about my great glory. ’ Those people will tell other nations about my great glory. ’"
    },
    {
      "verse": "20",
      "text": "The Lord says, ‘They will bring back all your relatives who still live in other countries. They will bring them to my holy hill in Jerusalem, as a gift to me, the Lord. They will come on horses, in chariots, in carts, on mules and on camels. They will bring them in the way that the Israelites bring grain offerings to me in my temple. They bring their offerings in holy dishes. ’"
    },
    {
      "verse": "21",
      "text": "The Lord says, ‘I will choose some of them to be priests. And I will choose some of them to serve me as Levites. ’"
    },
    {
      "verse": "22",
      "text": "The Lord says, ‘The new heavens and the new earth that I will make will always be there. In the same way, your descendants and your family name will always continue. ’"
    },
    {
      "verse": "23",
      "text": "The Lord says, ‘Everybody will come to worship me. They will come at each New Moon and on every Sabbath day."
    },
    {
      "verse": "24",
      "text": "When they go out of the city, they will see the dead bodies of the people who turned against me. In that heap of bodies, the worms never die and the fire never stops burning. Everybody will see that it is disgusting. ’"
    }
  ]
};
