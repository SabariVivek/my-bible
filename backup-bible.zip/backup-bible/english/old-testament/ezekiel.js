module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "It was the 30th year. God spoke to me on the fifth day of the fourth month. I was among the prisoners from Judah at the side of the Kebar river. At that time the skies opened and I saw visions from God."
    },
    {
      "verse": "2",
      "text": "King Jehoiachin of Judah had been a prisoner in Babylon for five years. On the fifth day of the month,"
    },
    {
      "verse": "3",
      "text": "the Lord spoke to Ezekiel, the priest. He was the son of Buzi. He was standing beside the River Kebar in Babylon. While Ezekiel was there, the Lord came to him with power."
    },
    {
      "verse": "4",
      "text": "As I looked, I saw a great storm that was coming from the north. It was a large cloud, with bright lightning. Light shone all around the cloud. It was like a fire that had bright metal in the centre of it."
    },
    {
      "verse": "5",
      "text": "I could see something like four living things in the middle of the fire. Each of them had the shape of a human."
    },
    {
      "verse": "6",
      "text": "But each of them had four faces and four wings."
    },
    {
      "verse": "7",
      "text": "Their legs were straight. Their feet were like the feet of young cows. They shone like bright bronze."
    },
    {
      "verse": "8",
      "text": "They had human hands under their wings on the four sides. Each of these four living things had faces and wings that were like this:"
    },
    {
      "verse": "9",
      "text": "Their wings touched each other. All the living things moved forward together. They did not turn as they moved."
    },
    {
      "verse": "10",
      "text": "This is what their faces looked like: Each of the living things had four faces. There was a human face at the front. There was a lion's face on the right side. There was a bull's face on the left side. Each of them also had the face of an eagle."
    },
    {
      "verse": "11",
      "text": "Their wings waved up above them. Two wings of each living thing touched the wings of the living things on each side of them. Each living thing covered its body with its other two wings."
    },
    {
      "verse": "12",
      "text": "The living things each moved forward, in the direction that the spirit wanted them to go. They did not turn as they moved."
    },
    {
      "verse": "13",
      "text": "In the middle of the living things was a fire. It looked like coals that were burning, or like bright flames. The fire moved around among the living things. It shone brightly, with lightning coming out from it."
    },
    {
      "verse": "14",
      "text": "The living things moved around very quickly, as fast as lightning."
    },
    {
      "verse": "15",
      "text": "I continued to look at the four living things. Each of them had a wheel on the ground at its side."
    },
    {
      "verse": "16",
      "text": "The four wheels all looked the same. They shone like bright jewels. The wheels were made like this: Each wheel had another wheel that went across the middle of it."
    },
    {
      "verse": "17",
      "text": "They moved forward in the same direction that the living things moved. They did not turn in any other direction."
    },
    {
      "verse": "18",
      "text": "The wheels had high edges. Eyes completely covered the edges of all the wheels."
    },
    {
      "verse": "19",
      "text": "When the living things moved, the wheels moved with them. If the living beings rose up from the ground, the wheels rose with them."
    },
    {
      "verse": "20",
      "text": "The living things went wherever the spirit wanted them to go. The wheels would also go with them. That was because the spirit of the living things was in each wheel."
    },
    {
      "verse": "21",
      "text": "When the living things moved, the wheels also moved. When the living things stopped, the wheels stopped moving too. When the living things rose up from the ground, the wheels went up at their side. That happened because the spirit of the living things was in each wheel."
    },
    {
      "verse": "22",
      "text": "I saw something over the heads of the living things. It looked like a high roof that shone brightly like ice."
    },
    {
      "verse": "23",
      "text": "The living things all stood under the roof. Each of them stood with its wings held out towards the living things on each side of it. They covered their bodies with their other two wings."
    },
    {
      "verse": "24",
      "text": "When they moved, I could hear the sound of their wings. They made a noise like lots of water that pours along a river. It was also like the voice of the Almighty God, or the noise of a great army. When the living things stopped moving, they put their wings down at their sides."
    },
    {
      "verse": "25",
      "text": "While they stood with their wings down at their sides, I heard a voice. It came from above the roof over their heads. When I saw this, I bent down low with my face on the ground. I heard a voice that was speaking to me."
    },
    {
      "verse": "26",
      "text": "Above the roof, there was something that looked like a throne. It was made of a blue jewel called sapphire. On the throne, high above, I saw something that looked like the shape of a man."
    },
    {
      "verse": "27",
      "text": "The top part of his body shone like a fire with bright metal in the centre of it. The lower part of his body looked like flames of fire. All around the human shape, there was a very bright light."
    },
    {
      "verse": "28",
      "text": "It shone with the colours of a rainbow in the clouds when there is rain. This bright light showed the glory of the Lord, who was there. When I saw this, I bent down low with my face on the ground. I heard a voice that was speaking to me."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "The voice said to me, ‘Son of man, you must stand up on your feet. Then I will speak to you. ’"
    },
    {
      "verse": "2",
      "text": "A spirit came into me while he spoke. He made me stand up and I heard him speak to me."
    },
    {
      "verse": "3",
      "text": "He said, ‘Son of man, I am sending you to Israel's people. They are a nation of people who have turned against me. They and their ancestors have refused to obey me, even until today."
    },
    {
      "verse": "4",
      "text": "I am sending you to speak to these people. They do not accept my authority and they refuse to change. But you must say to them, “This is what the Almighty Lord says. ”"
    },
    {
      "verse": "5",
      "text": "The Israelites may listen to what you say, or they may not listen. They do not want to obey me. But they will know that I have sent a prophet to them."
    },
    {
      "verse": "6",
      "text": "You must not be afraid of them, son of man. Do not be afraid of their words either. It may seem that you are living with thorn bushes all around you. You may think that they can hurt you like dangerous scorpions. But do not be afraid of what they say to you, or how they look at you. Remember that they refuse to obey me."
    },
    {
      "verse": "7",
      "text": "You must speak my words to them, whether they listen to you or not. They are people who refuse to obey me."
    },
    {
      "verse": "8",
      "text": "But you must listen to what I say to you, son of man. Do not refuse to obey me, as those people refuse to obey me. Open your mouth and eat what I will give to you. ’"
    },
    {
      "verse": "9",
      "text": "When I looked, I saw a hand! It held out a scroll towards me."
    },
    {
      "verse": "10",
      "text": "He opened the scroll so that I could see inside it. I saw words that were written on both sides of the scroll. There were sad funeral songs, and words about great trouble that make you weep."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "He said to me, ‘Son of man, eat what you can see in front of you. Eat this scroll with words on it. Then go and speak to the Israelites. ’"
    },
    {
      "verse": "2",
      "text": "So I opened my mouth and he gave me the scroll to eat."
    },
    {
      "verse": "3",
      "text": "He said, ‘Son of man, I am giving you this scroll. Eat it all and fill your stomach with it. ’ So I ate it. It had a sweet taste like honey in my mouth."
    },
    {
      "verse": "4",
      "text": "Then he said to me, ‘Son of man, now go to Israel's people and speak my words to them."
    },
    {
      "verse": "5",
      "text": "I am not sending you to a people whose words you cannot understand. They do not speak a difficult language. No, I am sending you to Israel's people."
    },
    {
      "verse": "6",
      "text": "I am not sending you to people who speak many different languages that you cannot understand. If I did send you to people like that, I am sure that they would listen to you."
    },
    {
      "verse": "7",
      "text": "But Israel's people will not agree to listen to you. That is because they refuse to listen to me. All the Israelites have decided not to obey me, and they will not change."
    },
    {
      "verse": "8",
      "text": "But I will make you as strong in your mind as they are. You will not change what you think."
    },
    {
      "verse": "9",
      "text": "You will be as strong as the strongest stone that nobody can break. Do not be afraid of them. Do not be afraid of how they look at you. Remember that they are people who refuse to obey me. ’"
    },
    {
      "verse": "10",
      "text": "Then he said to me, ‘Son of man, listen carefully to all the words that I say to you. Remember them."
    },
    {
      "verse": "11",
      "text": "Now you must go to the Israelites who are prisoners in Babylon. They are your own people. Give my message to them and say, “This is what the Almighty Lord says. ” They may listen to you or they may refuse to listen. But you must still give them my message. ’"
    },
    {
      "verse": "12",
      "text": "Then a spirit lifted me up. I heard a loud noise like thunder behind me. It was the sound of the Lord's great glory as it rose up from its place!"
    },
    {
      "verse": "13",
      "text": "I heard the sound of the living things' wings as they touched each other. I also heard the loud noise of the wheels that were at the side of the living things. It was like the noise of thunder."
    },
    {
      "verse": "14",
      "text": "Then a spirit lifted me up and he took me away. I was angry and upset in my mind. But the Lord gave me great power and strength."
    },
    {
      "verse": "15",
      "text": "I came to Tel Abib near the Kedar river, where the Israelite prisoners lived. I stayed with them for seven days. I was very upset as I sat among them."
    },
    {
      "verse": "16",
      "text": "When the seven days were finished, the Lord gave this message to me:"
    },
    {
      "verse": "17",
      "text": "‘Son of man, I have made you a guard to warn Israel's people about danger. You must listen to the messages that I will give to you. Then you must use my messages to warn the Israelites."
    },
    {
      "verse": "18",
      "text": "I may say to a wicked person, “Your punishment will be death. ” Then you must warn that person. You must tell him to stop doing wicked things so that he may save his life. If you do not tell the wicked person this, he will die because of his sins. But I will say that you are guilty, as if you had killed him yourself."
    },
    {
      "verse": "19",
      "text": "So you must warn the wicked person. If you warn him, he still may not stop doing wicked things. Then that wicked person will die because of his sins. But you will have saved your own life."
    },
    {
      "verse": "20",
      "text": "A righteous person may stop doing things that are right. He may start to do bad things. Then I will put him in danger. He will die as punishment for his sins. I will not remember the good things that he did. But if you have not warned him of the danger, I will say that you are guilty. It is as if you killed him yourself."
    },
    {
      "verse": "21",
      "text": "But if you do warn that righteous person to stop doing bad things, he may agree. Then he will continue to live, because you warned him. You also will have saved your own life. ’"
    },
    {
      "verse": "22",
      "text": "The Lord continued to give me strength. He said to me, ‘Stand up now! Go out into the valley and I will speak to you there. ’"
    },
    {
      "verse": "23",
      "text": "So I got up and I went out to the valley. I saw the glory of the Lord in that place. It was like the glory that I had seen beside the Kebar river. I bent down low, with my face to the ground."
    },
    {
      "verse": "24",
      "text": "Then a spirit came into me. He lifted me up and he made me stand on my feet. The Lord said to me, ‘Go into your house and shut the door."
    },
    {
      "verse": "25",
      "text": "Son of man, people will tie you with ropes so that you cannot move. You will not be able to go out among the people."
    },
    {
      "verse": "26",
      "text": "I will also stop your tongue from moving so that you cannot speak. You will not be able to warn the Israelites. They are people who refuse to obey me."
    },
    {
      "verse": "27",
      "text": "But sometimes I will speak to you. Then you will be able to open your mouth and give them my message. You must tell them, “This is what the Almighty Lord says. ” Some of them will listen to my message. But other people will refuse to listen. They are a nation of people who refuse to obey me. ’"
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "‘Son of man, take a large brick and put it in front of you. On the brick, draw a picture of the city, Jerusalem."
    },
    {
      "verse": "2",
      "text": "Show that soldiers are ready to attack the city. Build heaps of earth around it so that nobody can escape. Put heavy pieces of wood around the city that the enemy could use to break its walls."
    },
    {
      "verse": "3",
      "text": "Then you must do this. Take a flat plate of iron and put it between you and the brick. It will be like a wall between you and the city. Look towards the city. Show that soldiers are around the city and they are ready to attack it. Nobody can escape. This will be a picture to show Israel's people what will happen to them."
    },
    {
      "verse": "6",
      "text": "After you have finished all those days, lie down again. This time, lie down on your right side for 40 days. You will suffer like that to show the punishment for the sins of Judah's people. Each day will show one year of their punishment."
    },
    {
      "verse": "7",
      "text": "Continue to look towards the brick which has the picture of Jerusalem on it. Show that you are ready to attack it, like soldiers all around it. Speak my message to warn the city."
    },
    {
      "verse": "8",
      "text": "Listen! I will use ropes to tie around you. You will not be able to turn from one side to another. You will lie on one side until you have finished all the days to attack the city."
    },
    {
      "verse": "9",
      "text": "You must take some grains like wheat and barley, and different kinds of beans. Then put them all into a jar. Use them to make bread for yourself. You must eat this for 390 days while you lie on your left side."
    },
    {
      "verse": "10",
      "text": "grams of food each day. Eat it at the same time each day."
    },
    {
      "verse": "11",
      "text": "You must measure the water that you drink each day. You may drink two cups at the same times each day."
    },
    {
      "verse": "12",
      "text": "Prepare your food like a cake that is made from barley. Bake it on a fire that you have made with human dung. Do this where the people can see you. ’"
    },
    {
      "verse": "13",
      "text": "The Lord also said, ‘I will send Israel's people away to live in foreign lands. Then they will have to eat unclean food, as you will do now. ’"
    },
    {
      "verse": "14",
      "text": "Then I said, ‘No, Almighty Lord, I could not use human dung. It would make me unclean. Since I was a child I have never eaten any food that would make me unclean. I have never eaten meat from a dead animal that people have found. I have not eaten meat from an animal that wild animals have killed. ’"
    },
    {
      "verse": "15",
      "text": "So God said to me, ‘I will allow you to use dung from cows instead of from humans. You may use that to make the fire to cook your bread. ’"
    },
    {
      "verse": "16",
      "text": "Then God said to me, ‘Son of man, I will soon take away the bread in Jerusalem. The people will have to measure the food that they eat. And they will have to measure the water that they drink. They will worry and be afraid."
    },
    {
      "verse": "17",
      "text": "They will not have enough food or water. Everyone will be very upset. Their bodies will become very thin when I punish them for their sins. ’"
    },
    {
      "verse": "4",
      "text": "Then lie down on your left side. Show that you are receiving the punishment for the sins of the Israelites. You will suffer like that for 390 days."
    },
    {
      "verse": "5",
      "text": "It will show the number of years that I have decided to punish Israel's people. Each day that you suffer will show one year of their punishment."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "‘Son of man, take a sharp sword. Use it like a knife to cut off your hair and your beard. Then use some scales to weigh the hair. Put it into three separate parts that are the same weight."
    },
    {
      "verse": "2",
      "text": "Wait until all the days when you are lying on your side have finished. Take one part of your hair and burn it on the brick which has the picture of Jerusalem. Take another part and use a sword to cut it into small pieces. Let the pieces fall all around the brick which shows the city. Then take the third part and throw the hairs into the wind. I will run after them with a sword."
    },
    {
      "verse": "3",
      "text": "But keep a few of your hairs. Tie them into the edge of your clothes."
    },
    {
      "verse": "4",
      "text": "Finally, take out some of these hairs. Throw them into the fire and burn them. This fire will grow so that it reaches all Israel's people."
    },
    {
      "verse": "5",
      "text": "I, the Almighty Lord, say this: This shows what will happen to Jerusalem. I have put the city in the centre of all the nations. It has countries all around it."
    },
    {
      "verse": "6",
      "text": "But Jerusalem's people have refused to obey my rules and my commands. They have become more wicked than the nations and countries around them. They have not obeyed my laws."
    },
    {
      "verse": "7",
      "text": "So this is what the Almighty Lord says: You people of Jerusalem have done worse things than any of the nations around you. You have not obeyed my rules or my laws. You have not even obeyed the laws of the nations around you."
    },
    {
      "verse": "8",
      "text": "So this is what the Almighty Lord says: I myself have become your enemy, people of Jerusalem. I will punish you while the other nations watch."
    },
    {
      "verse": "9",
      "text": "I will punish you for all the disgusting things that you have done. I have never punished anyone like that before. And I will never do it again."
    },
    {
      "verse": "10",
      "text": "When I punish you like that, you will have no food to eat. Parents will be so hungry that they will eat their children. Children will eat their parents. I will chase away those few people who are still alive. They will go to all parts of the earth."
    },
    {
      "verse": "11",
      "text": "The Almighty Lord says this: I promise you as surely as I live that I will remove you. You have made my holy place unclean. You have put your disgusting idols in my house. You have done wicked things there. Because of that I will not be sorry for you. I will not save you."
    },
    {
      "verse": "12",
      "text": "Illness or famine will kill one third of your people inside the city. The soldiers who are around the city will kill a third of your people. And I will chase away a third of them to all parts of the earth. I will cause their enemies to run after them with their swords."
    },
    {
      "verse": "13",
      "text": "When I have done all that to them, I will not be angry any longer. I will not punish them any more, because it is enough. When I have finished, they will know that I, the Lord, have spoken to them. I have been angry with them because they have not been faithful to me."
    },
    {
      "verse": "14",
      "text": "I will cause your city to become a heap of stones. People of the other nations around you will laugh at you when they see what has happened to you."
    },
    {
      "verse": "15",
      "text": "They will all laugh at you and insult you. They will see that I was very angry with you and I punished you. Then they will be afraid of my great anger. I, the Lord, say this!"
    },
    {
      "verse": "16",
      "text": "I will take away your bread so that famine kills more and more of you. It will seem that I am shooting arrows at you to destroy you."
    },
    {
      "verse": "17",
      "text": "Famine or wild animals will kill you. Your children will no longer live. Illness and war will destroy you. I will send soldiers to attack you. I, the Lord, say this! ’"
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, look towards the mountains of Israel. Tell them my message to warn them."
    },
    {
      "verse": "3",
      "text": "Say, “You mountains of Israel, listen to this message from the Almighty Lord. This is what the Almighty Lord says to the mountains, the hills and the valleys: I am coming here to attack you. I will destroy the places where you worship false gods."
    },
    {
      "verse": "4",
      "text": "I will destroy your altars for sacrifices and your altars for incense. I will kill the people who worship there and put them in front of their idols."
    },
    {
      "verse": "5",
      "text": "The dead bodies of you people of Israel will lie in front of your idols. I will cause soldiers to throw your bones on the ground around the altars."
    },
    {
      "verse": "6",
      "text": "In all the places that you live, soldiers will destroy your towns. They will also destroy the places where you worship false gods. They will break down the altars so that they become heaps of stones. They will break your idols into pieces. They will destroy the altars where you burn incense. They will remove all those things that you have made."
    },
    {
      "verse": "7",
      "text": "Dead bodies will lie on the ground everywhere that you live. Then you will know that I am the Lord."
    },
    {
      "verse": "8",
      "text": "But I will allow some of you to live. Those people will escape when the enemy army attacks. They will run away to live in foreign countries."
    },
    {
      "verse": "9",
      "text": "When they are living as prisoners among those other nations, they will remember me. They will realize that they made me very sad because they were not faithful to me. They stopped worshipping me. Instead, they chose to worship idols. Then they will be ashamed of themselves, because of all the disgusting things which they have done."
    },
    {
      "verse": "10",
      "text": "They will know that I am the Lord. They will know that it was true when I promised to bring this terrible trouble to them. ” ’"
    },
    {
      "verse": "11",
      "text": "This is what I, the Almighty Lord, say to you, Ezekiel: ‘Clap your hands together. Stamp on the ground with your feet. Show that you are very upset because of all the disgusting, evil things that Israel's people have done. War, famine and disease will kill them."
    },
    {
      "verse": "12",
      "text": "Illness will kill the people who live far away. Enemy soldiers will kill those who live near to the city. Famine will kill those people who are still alive. Because I am very angry with them, I will punish them very much."
    },
    {
      "verse": "13",
      "text": "Then they will know that I am the Lord. They will see the dead bodies of their own people. The bodies will be lying among the idols that they worshipped. They will be lying around the altars of their false gods, on every high hill and mountain. The dead bodies will lie under the big trees where they offered incense to all their idols."
    },
    {
      "verse": "14",
      "text": "I will punish them very much. I will destroy their land from the desert in the south as far as Diblah. I will make it a place where nobody can live. Then they will know that I am the Lord. ’"
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, this is what I, the Almighty Lord, say to the land of Israel: The end is now here! I will soon destroy the whole land."
    },
    {
      "verse": "3",
      "text": "The time has come for your final punishment! You will know that I am very angry with you. I will punish you because of the bad way that you have lived. You will receive the punishment that you deserve for all the disgusting things that you have done."
    },
    {
      "verse": "4",
      "text": "I will not be sorry for you. I will not be kind to you. I will punish you as you deserve. You have done disgusting things. So I will punish you and you will know that I am the Lord."
    },
    {
      "verse": "5",
      "text": "This is what the Almighty Lord says: Terrible trouble is coming to you! It will be worse than any other trouble."
    },
    {
      "verse": "6",
      "text": "The end has now come! It is finally here to destroy you! Look out!"
    },
    {
      "verse": "7",
      "text": "You people who live in the land will now receive terrible punishment. The day for that to happen is very near. There will be no more sound of happy parties on the mountains. Instead there will be shouts of fear."
    },
    {
      "verse": "8",
      "text": "Very soon, I will punish you because of my great anger. You will know how angry I am. I will judge you for the way that you have lived. I will punish you as you deserve for the disgusting things that you have done."
    },
    {
      "verse": "9",
      "text": "I will not be sorry for you. I will not be kind to you. I will punish you as you deserve, because of the disgusting things that you have done. Then you will know that I, the Lord, am causing you pain."
    },
    {
      "verse": "10",
      "text": "Yes, the day of your punishment is here! Terrible trouble is coming to you! Like a tree that is ready to make flowers, your proud and wicked acts are ready for punishment."
    },
    {
      "verse": "11",
      "text": "You use violence to help you to do wicked things. None of all those people will escape. None of their riches or valuable things will remain."
    },
    {
      "verse": "12",
      "text": "The day of punishment has now come! The person who buys things will no longer be happy. Nor will the person who sells things. My anger will bring pain to all of them."
    },
    {
      "verse": "13",
      "text": "Any man who sells his land will never get it back as long as he lives. God has shown what he will do to all those people. He will not change his mind. Each one will lose his life because of their sins."
    },
    {
      "verse": "14",
      "text": "The soldiers make a noise with trumpets to prepare for war. But nobody goes out to fight a battle because my anger has brought punishment for all the people."
    },
    {
      "verse": "15",
      "text": "The enemy is ready to attack outside the city. Inside the city, there is disease and famine. Enemy soldiers will kill the people who are in the country. Famine and disease will kill everyone who is in the city."
    },
    {
      "verse": "16",
      "text": "Those who remain alive will escape. They will run to the mountains. They will be like doves that hunters have chased out of the valleys. They will cry aloud because of their sins."
    },
    {
      "verse": "17",
      "text": "Their hands will be weak. Their knees will shake."
    },
    {
      "verse": "18",
      "text": "They will wear sackcloth. They will be very afraid. Their faces will show that they are ashamed. They will cut all the hair from their heads."
    },
    {
      "verse": "19",
      "text": "They will throw their silver away in the streets. They will think that their gold has no value, like dirt. Their silver and their gold will not be able to save them on the day of the Lord's great anger. When they are hungry, their money will not buy them any food. It is their riches that have caused them to do wicked things."
    },
    {
      "verse": "20",
      "text": "They were proud of their beautiful jewels. They used them to make disgusting idols and images. That is why I, the Lord, have made them hate their valuable things."
    },
    {
      "verse": "21",
      "text": "I will allow foreigners and wicked people to take those things from them. They will use those valuable things in a disgusting way."
    },
    {
      "verse": "22",
      "text": "Those foreigners and robbers will go into my holy temple. They will cause it to become unclean. But I will look away and I will allow them to do that."
    },
    {
      "verse": "23",
      "text": "Prepare chains to tie my people. The whole land is full of murder and violence."
    },
    {
      "verse": "24",
      "text": "I will bring the most wicked people from other nations to attack. They will take the houses of my people and they will live in them. The strong men among my people will no longer boast. Enemies will spoil the holy places where my people worshipped."
    },
    {
      "verse": "25",
      "text": "Terrible trouble is coming to my people! When they are afraid, they will look for peace. But they will not find it. I will punish them as they deserve for the way that they have lived. I will judge them in the same way that they have judged other people. Then they will know that I am the Lord. ’"
    },
    {
      "verse": "26",
      "text": "Many troubles will happen, one after another. There will be lots of news about terrible things. People will ask the prophets to tell them what will happen. The priests will not have anything to teach the people. The leaders will not have any good advice."
    },
    {
      "verse": "27",
      "text": "The king will be very sad. His son will not hope for anything good to happen. The people will shake with fear. I will punish them as they deserve for the way that they have lived. I will judge them in the same way that they have judged other people. Then they will know that I am the Lord. ’"
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "On the fifth day of the sixth month of the sixth year, I was sitting in my house. The leaders of Judah were sitting in front of me. While I sat there, the Almighty Lord took hold of me with great power."
    },
    {
      "verse": "2",
      "text": "I looked up and I saw something that looked like a man. The lower part of his body looked like fire. Above that, his body looked like bright metal."
    },
    {
      "verse": "3",
      "text": "He put out something in the shape of a hand. He took hold of the hair on my head. Then the Spirit lifted me up, high in the sky, and took me to Jerusalem. This happened in the vision which God gave to me. I came to the north gate of the temple's inside yard. In that place there was a disgusting idol that made God very angry."
    },
    {
      "verse": "4",
      "text": "Then I saw that the bright glory of Israel's God was there. It was like the glory that I had seen beside the River Kebar."
    },
    {
      "verse": "5",
      "text": "Then the Lord said to me, ‘Son of man, look up towards the north. ’ When I looked, I saw the disgusting idol. It stood at the entrance, on the north side of the altar gate."
    },
    {
      "verse": "6",
      "text": "He said to me, ‘Son of man, look at what they are doing! Israel's people are doing very disgusting things here. They are chasing me far away from my holy temple. But you will see even worse things than these. ’"
    },
    {
      "verse": "7",
      "text": "Then the Lord took me to the entrance of the temple's yard. As I looked, I saw a hole in the wall."
    },
    {
      "verse": "8",
      "text": "He said to me, ‘Son of man, make a hole through the wall here. ’ So I dug into the wall. I found a door in it."
    },
    {
      "verse": "9",
      "text": "He said to me, ‘Go in there. Look at the wicked things that they are doing in this place. ’"
    },
    {
      "verse": "10",
      "text": "So I went in and I looked. I saw pictures of many things on the walls all around. There were pictures of snakes and other disgusting animals. There were also images of the things that Israel's people were worshipping."
    },
    {
      "verse": "11",
      "text": "of Israel's leaders were there. Shaphan's son Jaazaniah, was also among them. Each of them held a pot to burn incense. The smell of the incense rose up above them."
    },
    {
      "verse": "12",
      "text": "The Lord said, ‘Son of man, look at the wicked things that Israel's leaders are doing! They are doing them secretly in the dark. Each of them has a room where they worship their images of idols. They say, “The Lord does not see us! The Lord has gone away from our land! ” ’"
    },
    {
      "verse": "13",
      "text": "The Lord said to me, ‘You will see even worse things that they are doing. ’"
    },
    {
      "verse": "14",
      "text": "Then he took me to entrance at the north gate of the temple. I saw some women who were sitting there. They were weeping because the god Tammuz was dead."
    },
    {
      "verse": "15",
      "text": "He said to me, ‘Son of man, look at that! But you will see even worse things than these. ’"
    },
    {
      "verse": "16",
      "text": "Then the Lord took me to the inside yard of his temple. I could see about 25 men who were standing between the altar and the front of the temple. Their backs were turned towards the Lord's temple. Their faces looked towards the east. They were bending down low to worship the sun that was rising in the east!"
    },
    {
      "verse": "17",
      "text": "The Lord said to me, ‘Son of man, look at that! The people of Judah are doing these disgusting things here in my temple! That is a terrible thing! And they are also doing violent things everywhere in their land. They continue to make me angry all the time. Look at them! They insult me as much as they can!"
    },
    {
      "verse": "18",
      "text": "So now I will punish them in my great anger. I will not be sorry for them. I will not be kind to them. They may shout at me for help, but I will not listen to them. ’"
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "I heard the Lord shout loudly, ‘Bring here the men who will punish the people of this city! Tell the guards to bring their weapons with them. ’"
    },
    {
      "verse": "2",
      "text": "Then I looked and I saw six men. They were coming from the higher gate that is on the north side of the temple. Each man carried his weapon and he was ready to kill. A man who was wearing white linen clothes was among them. At his side he had a small box with pens in it. They came in and they stood next to the bronze altar."
    },
    {
      "verse": "3",
      "text": "The bright glory of Israel's God then moved up from above the cherubs where it had been. It moved to the entrance of the temple. Then the Lord called to the man who was wearing linen clothes."
    },
    {
      "verse": "4",
      "text": "He said, ‘Go everywhere in the city of Jerusalem. Find the people who are very sad because of the disgusting things that people are doing in the city. Use your pens to put a mark on those people. Put the mark on the front of their heads. ’"
    },
    {
      "verse": "5",
      "text": "While I listened, the Lord said to the other men, ‘Follow that man through the city. Kill people who do not have his mark on their heads. Do not be sorry for them. Do not be kind to them. So the men started to kill. The first people that they killed were the city's leaders who were in front of the temple."
    },
    {
      "verse": "6",
      "text": "Kill the old men, young men and girls. Kill the women and the children. Destroy them all! But do not touch anyone who has the mark on their head. ’So the men started to kill. The first people that they killed were the city's leaders who were in front of the temple."
    },
    {
      "verse": "7",
      "text": "The Lord said to them, ‘Fill the yards of the temple with dead bodies! Make the temple an unclean place! Go and do it now! ’ So they went out and they started to kill people everywhere in the city."
    },
    {
      "verse": "8",
      "text": "I was alone while they were doing this. I bent down low with my face towards the ground. I called out, ‘Almighty Lord! Will you destroy all Israel's people who are still alive? Are you so angry with the people of Jerusalem that you will do that? ’"
    },
    {
      "verse": "9",
      "text": "He answered me, ‘The sins of the people of Israel and Judah are very great. They murder people everywhere in the land. In the city, nobody does what is right. They say, “The Lord has gone away from our land! The Lord does not see what we are doing! ”"
    },
    {
      "verse": "10",
      "text": "So I will not be sorry for them. I will not be kind to them. Now I will punish them as they deserve for the things that they have done. ’"
    },
    {
      "verse": "11",
      "text": "Then I saw again the man who was wearing linen clothes, with the box of pens. He brought this message to the Lord: ‘I have done what you commanded me to do. ’"
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "In the vision, I saw something that looked like a throne. It was made from a blue jewel called sapphire. It was above the roof and it was high over the heads of the cherubs."
    },
    {
      "verse": "2",
      "text": "The Lord said to the man who was wearing linen clothes, ‘Go between the wheels that are under the cherubs. Pick up some of the hot coals that are burning among the cherubs. Fill your hands with them. Then throw them everywhere over the city. ’ Then the man did this, as I watched him."
    },
    {
      "verse": "3",
      "text": "The cherubs stood at the south side of the temple when the man went in among them. A cloud filled the inside yard of the temple."
    },
    {
      "verse": "4",
      "text": "Then the Lord's bright glory rose up. It went up from above the cherubs. It moved to the entrance of the temple. The cloud filled the temple. The bright glory of the Lord's shone everywhere in the yard."
    },
    {
      "verse": "5",
      "text": "The noise of the cherubs' wings was very loud. It reached as far as the outside yard. The noise was like the voice of Almighty God when he speaks."
    },
    {
      "verse": "6",
      "text": "The Lord gave a command to the man who was wearing linen clothes. He said, ‘Go in among the cherubs. Take coals of fire from between the wheels. ’ So the man went in and he stood beside one of the wheels."
    },
    {
      "verse": "7",
      "text": "Then one of the cherubs put his hand towards the fire which was among the cherubs. He took some coals from the fire. He put them into the hands of the man who was wearing linen clothes. The man took the coals and he went out."
    },
    {
      "verse": "8",
      "text": "(Under the wings of the cherubs I could see something that looked like human hands. )"
    },
    {
      "verse": "9",
      "text": "In the vision, I saw four wheels beside the cherubs. There was one wheel at the side of each cherub. The wheels shone like bright jewels."
    },
    {
      "verse": "10",
      "text": "All the four wheels looked the same. Each wheel had another wheel that went across the middle of it."
    },
    {
      "verse": "11",
      "text": "When the cherubs moved, they could go forward in any of the four directions. They did not have to turn as they moved. When the head turned in a certain direction, they would move that way. They did not need to turn."
    },
    {
      "verse": "12",
      "text": "Eyes completely covered their bodies. This included their backs, their hands and their wings. Eyes also covered the edges of all the wheels."
    },
    {
      "verse": "13",
      "text": "I heard someone call the wheels, ‘wheels that turn very fast’."
    },
    {
      "verse": "14",
      "text": "Each of the cherubs had four faces. One face was the face of a bull. The second face was the face of a man. The third face was a lion's face. And the fourth face was an eagle's face."
    },
    {
      "verse": "15",
      "text": "The cherubs rose up into the air. They were the same as the living things that I had seen beside the River Kebar."
    },
    {
      "verse": "16",
      "text": "When they moved, the wheels that were beside them also moved. When the cherubs lifted up their wings to fly into the air, the wheels moved beside them."
    },
    {
      "verse": "17",
      "text": "When the cherubs stood still, the wheels also stood still. And when the cherubs rose in the air, the wheels also rose with them. This was because the spirit of the living things was in the wheels."
    },
    {
      "verse": "18",
      "text": "Then the glory of the Lord moved away from the entrance of the temple. It stopped at a place above the cherubs."
    },
    {
      "verse": "19",
      "text": "Then the cherubs lifted up their wings and they rose up from the ground. The wheels also moved with them. I watched them do this. They stopped by the east gate of the Lord's temple. The glory of Israel's God stayed above them."
    },
    {
      "verse": "20",
      "text": "They were the same living things that I had seen beside the Kebar River when they were under Israel's God. I realized that they were cherubs."
    },
    {
      "verse": "21",
      "text": "Each of them had four faces and four wings. They had something with the shape of human hands under their wings."
    },
    {
      "verse": "22",
      "text": "They had the same four faces that I had seen beside the River Kebar. Each of them moved forward and they did not turn."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "Then a spirit lifted me up and took me to the east gate of the Lord's temple. When I was there, near the entrance of the gate, I could see 25 men. Azzur's son Jaazaniah and Benaiah's son Pelatiah were among them. They were leaders of the people."
    },
    {
      "verse": "2",
      "text": "The Lord said to me. ‘Son of man, these are the men who decide to do evil things in this city. They also give wicked advice to the people."
    },
    {
      "verse": "3",
      "text": "They say, “It is not the right time now to build houses. This city is like a pot to cook meat on a fire. We are like the meat in that pot. ”"
    },
    {
      "verse": "4",
      "text": "Son of man, you must speak my message to warn them. ’"
    },
    {
      "verse": "5",
      "text": "Then the Lord's Spirit took hold of me. He said to me, ‘This is the Lord's message to the people: Tell them, “People of Israel, I know what you are saying. I know the thoughts that you have in your minds."
    },
    {
      "verse": "6",
      "text": "You have killed many people in this city. The streets are full of the dead bodies of people that you have killed. ”"
    },
    {
      "verse": "7",
      "text": "So this is what the Almighty Lord says: “The dead bodies that you have put in this city are the meat. And the city is the pot to cook them in. But as for you, I will remove you from it!"
    },
    {
      "verse": "8",
      "text": "You are afraid that an enemy will attack you. So I will bring an army to attack you. ” That is what the Almighty Lord says."
    },
    {
      "verse": "9",
      "text": "“I will remove you from this city. I will put you under the power of a foreign army. I will use them to punish you."
    },
    {
      "verse": "10",
      "text": "Enemy soldiers will use their swords to kill you. I will punish you in your own country. Then you will know that I am the Lord."
    },
    {
      "verse": "11",
      "text": "This city will not be like a pot where you can be safe. You will not be like the meat in that pot. I will punish you while you are still inside Israel."
    },
    {
      "verse": "12",
      "text": "Then you will know that I am the Lord. You have not obeyed my rules or my laws. Instead, you have lived in the same wicked way as the nations around you. ” ’"
    },
    {
      "verse": "13",
      "text": "While I was speaking the Lord's message, Benaiah's son Pelatiah died. Then I bent down low with my face towards the ground. I shouted, ‘Almighty Lord, do not do this! You will completely destroy all Israel's people who remain! ’"
    },
    {
      "verse": "14",
      "text": "Then the Lord gave this message to me:"
    },
    {
      "verse": "15",
      "text": "‘Son of man, listen to what the people of Jerusalem are saying about you, your brothers and your relatives. They say this about all the people of Israel who are now in Babylon. They are saying, “Those people have gone far away from the Lord. So now this land belongs to us and we can keep it. ”"
    },
    {
      "verse": "16",
      "text": "So say this: “This is what the Almighty Lord says. I removed my people from their own land and I sent them far away. I sent them to live among other nations and in other countries. But I am still near to them in the countries where they have gone. ”"
    },
    {
      "verse": "17",
      "text": "Then say, “This is what the Almighty Lord says. I will fetch you from the places where you have been living. I will bring you back together from those countries. I will give the land of Israel back to you. ”"
    },
    {
      "verse": "18",
      "text": "The people will return to their land. Then they will destroy their idols and other disgusting things."
    },
    {
      "verse": "19",
      "text": "I will give them new thoughts so that they will choose to worship only me. I will put a new spirit in them. They will no longer refuse to change their way of life. Instead, I will help them to want to obey me."
    },
    {
      "verse": "20",
      "text": "Then they will know my rules and my laws. They will be careful to obey them. They will be my people and I will be their God."
    },
    {
      "verse": "21",
      "text": "But it will be different for those who continue to worship their disgusting idols. I will punish them as they deserve because of the evil things that they have done. That is what the Almighty Lord says. ’"
    },
    {
      "verse": "22",
      "text": "Then the cherubs lifted up their wings to fly. The wheels were at their sides. And the bright glory of Israel's God was above them."
    },
    {
      "verse": "23",
      "text": "The glory of the Lord rose up and it went away from the city. It stopped over a mountain on the east side of the city."
    },
    {
      "verse": "24",
      "text": "In the vision, a spirit lifted me up and took me back to Babylon. I returned to the Israelites who were prisoners there. That was the end of the vision."
    },
    {
      "verse": "25",
      "text": "I told the Israelites everything that the Lord had shown me in the vision."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, you are living among a people who refuse to obey me. They have eyes, but they do not see anything. They have ears, but they do not hear anything. They refuse to listen to me."
    },
    {
      "verse": "3",
      "text": "Because of that, son of man, pretend that you are going away as a prisoner. During the day, prepare your things for the journey. While people are watching, prepare to leave your home and go to another place. The people refuse to obey me, but perhaps they will understand what you are doing."
    },
    {
      "verse": "4",
      "text": "Bring out the things that you have prepared for your journey. Do that during the day while the people are watching you. Then leave your home in the evening while they are watching you. Go away like someone who is travelling to a far country as a prisoner."
    },
    {
      "verse": "5",
      "text": "While the people are watching, dig a hole in the wall of your house. Go out through the hole and carry your things with you."
    },
    {
      "verse": "6",
      "text": "Put your bag of things on your shoulder while the people watch you. Carry it out when it starts to become dark. Cover your face so that you cannot see the ground. I want you to do this so that it warns Israel's people about danger. ’"
    },
    {
      "verse": "7",
      "text": "So I did what the Lord had told me to do. I carried out a bag of my things to show that I was going on a journey. I prepared these things during the day. Then in the evening I used my hands to dig a hole in the wall of my house. When it became dark, I went out. I carried my bag of things on my shoulder. The people watched me do all this."
    },
    {
      "verse": "8",
      "text": "In the morning, the Lord gave this message to me:"
    },
    {
      "verse": "9",
      "text": "‘Son of man, listen to Israel's people who refuse to obey me. They have asked you, “What are you doing? ”"
    },
    {
      "verse": "10",
      "text": "Say to them, “This is what the Almighty Lord says: This is a message about the prince who rules in Jerusalem and all the Israelites who are there. ”"
    },
    {
      "verse": "11",
      "text": "Tell them, “I am teaching you a lesson to warn you about what will happen to you. ” As you have done, the people will have to go as prisoners to another country."
    },
    {
      "verse": "12",
      "text": "Their king will leave Jerusalem when it starts to become dark. He will carry his things on his shoulder as he goes out. They will dig a hole in the wall for him to go through. He will cover his face so that he cannot see the land."
    },
    {
      "verse": "13",
      "text": "I will throw my net over him and I will catch him in my trap. I will take him to Babylon city, in the land of the Chaldeans. But he will not see that land. He will die there."
    },
    {
      "verse": "14",
      "text": "I will cause all his officers and soldiers to run away in different directions. Then their enemies will chase after them, to kill them with their swords."
    },
    {
      "verse": "15",
      "text": "I will send the people away from their homes to other countries. They will have to live among foreign people. Then they will know that I am the Lord."
    },
    {
      "verse": "16",
      "text": "But I will save a few of them. War, famine and disease will not kill all of them. When they live among those other nations, they will realize that they have done many disgusting things. And they will know that I am the Lord. ’"
    },
    {
      "verse": "17",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "18",
      "text": "‘Son of man, shake with fear while you eat your food or you drink your water."
    },
    {
      "verse": "19",
      "text": "Then say to the people of Israel, “This is what the Almighty Lord says about the people who live in Jerusalem and in all the land of Israel: They will be afraid while they eat their food. They will shake with fear when they drink their water. An enemy will destroy their land so that nothing remains in it. This will happen because all the people who live there have done violent things."
    },
    {
      "verse": "20",
      "text": "The towns where people live will become heaps of stones. An enemy will destroy the whole land. Then you will know that I am the Lord. ” ’"
    },
    {
      "verse": "21",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "22",
      "text": "‘Son of man, you have this proverb in the land of Israel: “A long time passes and visions never truly happen. ”"
    },
    {
      "verse": "23",
      "text": "But you must say to them, “This is what the Almighty Lord says: I will soon stop you from saying the words of that proverb. ” Instead, say to them “The time will soon be here when every vision will truly happen."
    },
    {
      "verse": "24",
      "text": "Israel's people will no longer have visions that are false. Nobody will prophesy things that deceive people."
    },
    {
      "verse": "25",
      "text": "But I, the Lord, will speak. Whatever I say will certainly happen. It will happen very soon. Understand this, you people who refuse to obey me. I will do this while you are still alive. I will do all the things that I have said. That is what the Almighty Lord says. ” ’"
    },
    {
      "verse": "26",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "27",
      "text": "‘Son of man, listen to what Israel's people are saying about you! They say, “The things that you see in your vision will not happen for many years. It will be a long time before his messages become true. ”"
    },
    {
      "verse": "28",
      "text": "So say to them, “This is what the Almighty Lord says: I will not wait any longer to do what I have said. I will do everything that I have told you. That is what the Almighty Lord says. ” ’"
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "Then the Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, speak my message to warn Israel's prophets. They are prophesying but they teach only their own ideas. Say to them, “Listen to this message from the Lord."
    },
    {
      "verse": "3",
      "text": "This is what the Almighty Lord says: Terrible trouble will come to those foolish prophets. They have not seen any vision from me but they tell people their own ideas."
    },
    {
      "verse": "4",
      "text": "People of Israel, your prophets have become like wild dogs that live among heaps of stones."
    },
    {
      "verse": "5",
      "text": "They have not helped you to mend the broken walls of your city. The walls will not be strong enough to keep Israel's people safe on the day of the Lord. That is when I will allow your enemies to attack you."
    },
    {
      "verse": "6",
      "text": "The visions that these prophets see are false. They tell lies about what will happen. They say, ‘The Lord says this, ’ when I have not sent them with any message. But they still think that what they say will really happen."
    },
    {
      "verse": "7",
      "text": "Yes, you prophets have seen false visions. You tell lies when you say, ‘The Lord says this. ’ You say that, but I have not spoken any message to you!"
    },
    {
      "verse": "8",
      "text": "So this is what I, the Almighty Lord, say to them: I am now your enemy because of your lies. You deceive people when you tell them what will happen. Yes, I have become your enemy. That is what the Almighty Lord says."
    },
    {
      "verse": "9",
      "text": "I will punish the prophets who see false visions and who tell lies. They will not be among the leaders of my people. They will not be on the list of people who are true Israelites. They will not even return to the land of Israel. Then you will know that I am the Almighty Lord."
    },
    {
      "verse": "10",
      "text": "Those prophets have deceived my people. They say that there will be peace. But there is no peace for my people. They are like men who build a wall without any mortar. They paint it white to make it look nice."
    },
    {
      "verse": "11",
      "text": "So tell those prophets that their paint is useless. The wall will soon fall down. There will be a lot of rain, hail and strong winds that knock it down."
    },
    {
      "verse": "12",
      "text": "After the wall has fallen down, people will say, ‘That white paint was useless! ’"
    },
    {
      "verse": "13",
      "text": "So this is what I, the Almighty Lord, say: Because I am angry with you, I will send strong winds to destroy your wall. I will send a lot of rain and hail."
    },
    {
      "verse": "14",
      "text": "I will break down your wall with its white paint. I will knock it down to the ground and leave only its foundation. It will fall on you and it will destroy you. Then you will know that I am the Lord."
    },
    {
      "verse": "15",
      "text": "I will show you that I am very angry. I will destroy the wall and the prophets who painted it white. Then I will say to you, ‘The wall is no longer there. The prophets who painted it are no longer alive."
    },
    {
      "verse": "16",
      "text": "They were prophets of Israel who told lies. They promised that Jerusalem would have peace. But there was really no peace. ’ That is what the Almighty Lord says. ”"
    },
    {
      "verse": "17",
      "text": "Now, son of man, you must warn the women among your people who use their own ideas to prophesy. Tell them my message to warn them."
    },
    {
      "verse": "18",
      "text": "Say, “This is what the Almighty Lord says: Terrible trouble will come to those women who make pieces of cloth which they say have magic power. People tie them around their arms and their heads. Those women want to have power over people's lives. They think they can have power over other people's lives but they themselves will be safe."
    },
    {
      "verse": "19",
      "text": "You have made people give you a little bit of barley or bread to eat. That is how they pay you to insult my name! You tell lies to my people, and they listen to you! As a result, you cause people to die who do not deserve to die. And people who do not deserve to live continue to live."
    },
    {
      "verse": "20",
      "text": "So this is what the Almighty Lord says to those women: I hate your pieces of cloth. You use them to catch people in traps, like you catch birds. But I will pull those cloths off your arms. Then those people that you like to catch will become free."
    },
    {
      "verse": "21",
      "text": "I will pull the cloths off your heads. That will rescue my people from your power. You will no longer be able to catch them. Then you will know that I am the Lord."
    },
    {
      "verse": "22",
      "text": "You have used lies to make righteous people stop being strong. But I did not want to hurt those people. You have also helped wicked people to continue to do evil things. You did not want them to change and save their lives."
    },
    {
      "verse": "23",
      "text": "So you women will not see any more false visions. You will no longer pretend that you know future events. I will rescue my people from your power. Then you will know that I am the Lord. ” ’"
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "Some of the leaders of Israel came to talk to me. They sat down in front of me."
    },
    {
      "verse": "2",
      "text": "Then the Lord gave this message to me:"
    },
    {
      "verse": "3",
      "text": "‘Son of man, these men like to worship idols. They allow those idols to cause them to do wicked things. So I should not allow them to ask me anything."
    },
    {
      "verse": "4",
      "text": "You must speak to them. Say, “This is what the Almighty Lord says: One of these men who like to worships idols may want to ask me something. Those men allow their idols to cause them to do wicked things. So if one of them goes to a prophet to find out something, I will give him an answer! I will give him the answer that he deserves because of his many idols!"
    },
    {
      "verse": "5",
      "text": "Israel's people have turned away from me because of their idols. So I will give them an answer that will bring them back to worship me. ”"
    },
    {
      "verse": "6",
      "text": "Say to Israel's people, “This is what the Almighty Lord says: Turn back to me and stop worshipping idols. Stop doing the disgusting things that you have been doing. ”"
    },
    {
      "verse": "7",
      "text": "An Israelite or a foreigner who lives in Israel may not want to serve me. He may choose to worship idols and do wicked things. If anyone like that goes to a prophet to find out something from me, I will answer him. Yes, I myself, the Lord, will answer him!"
    },
    {
      "verse": "8",
      "text": "I will be that person's enemy. I will punish him to make him an example to others. Other people will see that he is not good. I will not allow him to belong to my people. Then you will know that I am the Lord."
    },
    {
      "verse": "9",
      "text": "I will also punish the prophet himself if he gives a false message. I, the Lord, have deceived him to show that he is a fool. And I will punish him. I will remove him from among my people, Israel's people."
    },
    {
      "verse": "10",
      "text": "I will punish both the prophet and the person who asked him for a message. They will both have the same punishment."
    },
    {
      "verse": "11",
      "text": "I will do that to bring back Israel's people to serve me. They will not continue to make themselves unclean because of all their sins. They will be my people and I will be their God. That is what the Almighty Lord says. ’"
    },
    {
      "verse": "12",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "13",
      "text": "‘Son of man, the people of a whole nation may choose not to obey me. Then I would punish them because of their sins. I might stop the people getting any food to eat. Then there would be a famine that kills both people and animals."
    },
    {
      "verse": "14",
      "text": "If that happens, I would only save the righteous people who lived there. If men like Noah, Daniel and Job lived there, I would save them. But nobody else would escape. That is what the Almighty Lord says."
    },
    {
      "verse": "15",
      "text": "Or I might send wild animals to kill the people of that nation. Nobody would travel through that place. The wild animals would make it too dangerous to travel there."
    },
    {
      "verse": "16",
      "text": "I promise you this, as surely as I live: if those three righteous men lived there, they would only save themselves. They could not even save the lives of their own children. The whole land would become an empty place. That is what the Almighty Lord says."
    },
    {
      "verse": "17",
      "text": "Or I might bring an enemy to attack that nation. I would say, “Soldiers with swords should destroy the whole land. ” I would cause them to kill both people and animals."
    },
    {
      "verse": "18",
      "text": "I promise you this, as surely as I live: if those three righteous men lived there, they would only save themselves. They could not even save the lives of their own children. That is what the Almighty Lord says."
    },
    {
      "verse": "19",
      "text": "Or I might punish that nation with a terrible disease. Because I am very angry with those people, I would cause people and animals to die in that place."
    },
    {
      "verse": "20",
      "text": "I promise you this, as surely as I live: if Noah, Daniel and Job lived there, they would only save themselves because they are righteous people. They could not save the lives even of their own children. That is what the Almighty Lord says."
    },
    {
      "verse": "21",
      "text": "This is what the Almighty Lord says: It will be terrible for Jerusalem's people when I punish them in all these four ways. I will send enemy soldiers with swords. I will send famine. I will send wild animals. And I will send disease. That will cause both people and animals to die."
    },
    {
      "verse": "22",
      "text": "But some people will still be alive. Some sons and daughters will come out from the city. They will come to you here in Babylon. You will see the way that those people have lived. You will see the things that they have done. Then you will not be upset that I have punished Jerusalem in all these ways."
    },
    {
      "verse": "23",
      "text": "Yes, when you see what they are like, you will no longer be upset. You will know that I have punished the people of Jerusalem as they deserved. That is what the Almighty Lord says. ’"
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, the wood of a vine is no better than the wood of any other tree that grows in the forest."
    },
    {
      "verse": "3",
      "text": "Nobody can use its wood to make anything that is useful. They cannot even make pegs to hang clothes on!"
    },
    {
      "verse": "4",
      "text": "You can throw it on a fire to make the fire burn. But after the fire has finished, only a useless black piece of vine remains."
    },
    {
      "verse": "5",
      "text": "It was useless before you put it on the fire. It is even more useless after the fire has burnt it. You cannot make anything with it."
    },
    {
      "verse": "6",
      "text": "So this is what the Almighty Lord says: Among the trees of the forest, I have provided the wood of vines to burn on a fire. In the same way, I will take the people of Jerusalem to punish them."
    },
    {
      "verse": "7",
      "text": "I will become their enemy. They may have escaped from the fire once, but soon the fire will destroy them. When I punish them like that, then you will know that I am the Lord."
    },
    {
      "verse": "8",
      "text": "They have not served me faithfully. So I will destroy their land. That is what the Almighty Lord says. ’"
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, warn Jerusalem's people about the disgusting things that they do."
    },
    {
      "verse": "3",
      "text": "Say to them, “This is what the Almighty Lord says to Jerusalem's people: You were born in the land of Canaan. That is where you came from. Your father was an Amorite and your mother was a Hittite."
    },
    {
      "verse": "4",
      "text": "They did not take proper care of you on the day that you were born. They did not wash you properly. They did not cut your cord. They did not put salt or oil on your skin. They did not put cloths around you."
    },
    {
      "verse": "5",
      "text": "Nobody was kind enough to do any of these things for you. Instead, they threw you out into a field. Nobody loved you on the day that you were born."
    },
    {
      "verse": "6",
      "text": "Then I saw you as I went that way. You were lying there on the ground in your blood. You were trying to move. While you lay there, I said to you, ‘Stay alive. ’"
    },
    {
      "verse": "7",
      "text": "I made you grow well, like the plants in a field. You became tall and beautiful, like a bright jewel. Your breasts grew and your hair became long. But you still had no clothes to cover your bare body."
    },
    {
      "verse": "8",
      "text": "Later, I saw you again as I went that way. I saw that you had become a woman who was old enough to marry. So I covered your bare body with my coat. I promised to marry you. I made a covenant with you so that you became my wife. That is what the Almighty Lord says."
    },
    {
      "verse": "9",
      "text": "Then I washed your body with water. I washed away the blood and I put sweet oil on your body."
    },
    {
      "verse": "10",
      "text": "I put a beautiful dress on you. I put the best leather shoes on your feet. I dressed you with clothes made from linen and other expensive cloths."
    },
    {
      "verse": "11",
      "text": "I put beautiful jewels on you. I put rings on your hands and a necklace around your neck."
    },
    {
      "verse": "12",
      "text": "I put a gold ring in your nose. I put rings in your ears. And I put a beautiful crown on your head."
    },
    {
      "verse": "13",
      "text": "I used gold and silver to make you beautiful. I gave you expensive clothes that were made of linen and other pretty cloth. I gave you good food to eat, flour, honey and olive oil. You became a very beautiful woman. You even became a queen."
    },
    {
      "verse": "14",
      "text": "The people of other nations heard news about your beauty. That was because of all the good things that I had given you to make you very beautiful. That is what the Almighty Lord says."
    },
    {
      "verse": "15",
      "text": "But you trusted your beauty to give you what you wanted. Because you were famous, you lived like a prostitute. You had sex with any man that you liked. They all enjoyed your beautiful body."
    },
    {
      "verse": "16",
      "text": "You used some of your clothes to give honour to idols. You made their altars beautiful. You had sex with those men there on your beautiful cloths. Those things should never happen!"
    },
    {
      "verse": "17",
      "text": "You took your beautiful gold and silver rings and your jewels. You used them to make images of male idols for yourself. You worshipped them instead of me."
    },
    {
      "verse": "18",
      "text": "You put your beautiful clothes on them. You gave them my oil and my incense as an offering."
    },
    {
      "verse": "19",
      "text": "You also offered to those idols the food that I had given to you, the good flour, the olive oil and the honey. You wanted to please your idols with sweet smells. Yes, that is what happened! That is what the Almighty Lord says."
    },
    {
      "verse": "20",
      "text": "You also offered your sons and your daughters as sacrifices to those idols. They were my children too! But you offered them as food to your idols. Like a prostitute, you were not faithful to me."
    },
    {
      "verse": "21",
      "text": "But you did an even worse thing. You killed my children. You offered them as sacrifices to idols!"
    },
    {
      "verse": "22",
      "text": "You forgot what you were like when I first found you. At that time you had no clothes to cover your bare body. You lay on the ground in your own blood. You did not remember this. Instead, you chose to do disgusting things and live as a prostitute."
    },
    {
      "verse": "23",
      "text": "Terrible trouble will come to you! That is what the Almighty Lord says. You did even more wicked things than these."
    },
    {
      "verse": "24",
      "text": "In the public places of every town you built huts to worship your idols."
    },
    {
      "verse": "25",
      "text": "You built these high places at the end of every street. There you made your beauty a disgusting thing. You offered your body to anyone who went past. Everyone knew that you were a prostitute."
    },
    {
      "verse": "26",
      "text": "You had sex with the Egyptians, who lived near to you. They were ready to have sex with you at any time. So you lived as a prostitute more and more and you made me very angry."
    },
    {
      "verse": "27",
      "text": "So I decided to punish you. I took from you things that belonged to you. I gave your enemies, the Philistines, power over you. Even they were ashamed because of the disgusting things that you were doing."
    },
    {
      "verse": "28",
      "text": "You had sex with the Assyrians, too. You wanted more and more sex! You sold yourself to them, but you still wanted more"
    },
    {
      "verse": "29",
      "text": "You also had sex with the traders from Babylon. Like a prostitute, you sold yourself to more and more people. But they could still not make you happy."
    },
    {
      "verse": "30",
      "text": "The Almighty Lord says this: Your mind no longer knows what is right. You do disgusting things, like a prostitute who is not ashamed."
    },
    {
      "verse": "31",
      "text": "You built places to worship your idols on every street. You offered yourself to people, like a prostitute. But you did not want them to pay you anything, as a prostitute would do."
    },
    {
      "verse": "32",
      "text": "You are like a wife who is not faithful. You want to have sex with strangers more than with your own husband!"
    },
    {
      "verse": "33",
      "text": "Prostitutes receive money when they have sex with someone. Instead, you give gifts to all the men who have sex with you. You pay them to come from many different places to have sex with you."
    },
    {
      "verse": "34",
      "text": "Those men did not come and ask you to have sex with them. So you are different from other prostitutes. You paid money to those men. They did not pay money to you. So you are very different from those other women!"
    },
    {
      "verse": "35",
      "text": "So listen to Lord's message, you prostitute!"
    },
    {
      "verse": "36",
      "text": "This is what the Almighty Lord says: You wanted to have sex with many men. You offered your bare body to them, like a prostitute. You have worshipped disgusting idols. You have killed your own children as sacrifices to those idols."
    },
    {
      "verse": "37",
      "text": "So listen to me! I will bring all those men that you had sex with. You liked some of them and you hated others. I will bring all of them to stand around you. Then I will remove all your clothes and they will all see your completely bare body."
    },
    {
      "verse": "38",
      "text": "I will punish you as you deserve, because you are an adulteress and a murderer. I am very angry with you because you have not been faithful to me. So my punishment will destroy you."
    },
    {
      "verse": "39",
      "text": "I will put you under the power of those men that you gave yourself to. They will destroy the places that you built for your idols. They will remove all your clothes. They will take your beautiful jewels. Then they will leave you with nothing, completely bare."
    },
    {
      "verse": "40",
      "text": "They will bring a crowd of people to attack you. They will throw stones at you. They will cut you in pieces with their swords."
    },
    {
      "verse": "41",
      "text": "They will use fire to destroy your houses. Many women will watch while those people punish you. I will stop you from having sex as a prostitute. You will no longer pay men to have sex with you."
    },
    {
      "verse": "42",
      "text": "I will continue to punish you until I am no longer angry with you. I will not be upset or angry any more."
    },
    {
      "verse": "43",
      "text": "The Almighty Lord says this: I am punishing you as you deserve for all the things that you have done. You have forgotten how I helped you when you were young. You have done many disgusting things and you have also lived like a prostitute."
    },
    {
      "verse": "44",
      "text": "Look! Everyone says that this proverb is true about you: A daughter will do the same things that her mother does."
    },
    {
      "verse": "45",
      "text": "Yes, you are a true daughter of your mother! Your mother hated her husband and her children. And you are the same as your sisters too. They also hated their husbands and their children. Your mother was a Hittite and your father was an Amorite."
    },
    {
      "verse": "46",
      "text": "Your older sister was Samaria. She and her daughters lived north of you. Your younger sister was Sodom. She and her daughters lived south of you."
    },
    {
      "verse": "47",
      "text": "You lived like them and you did all the same disgusting things that they did. But you quickly became even worse than them."
    },
    {
      "verse": "48",
      "text": "Your sister Sodom and her daughters never did such wicked things as you and your daughters have done. That is true as surely as I live, says the Almighty Lord."
    },
    {
      "verse": "49",
      "text": "Listen to me! This is the wicked thing that your sister Sodom did: She and her daughters were very proud. They had plenty of food to eat and they enjoyed life. But they did not help people who were poor and weak."
    },
    {
      "verse": "50",
      "text": "They were proud and they did whatever they wanted to do. When I saw the disgusting things that they were doing, I removed them."
    },
    {
      "verse": "51",
      "text": "Samaria's people did less than half as many sins as you have done. You have done many more disgusting things than they did. The many wicked things that you have done make your sisters seem righteous!"
    },
    {
      "verse": "52",
      "text": "So now you must accept that you are guilty. You have done such wicked things that your sisters think that they are good people. You have done much worse things than they ever did. I must punish you even more than I punished them. So you should be ashamed and you should accept your punishment. You have made your sisters seem to be righteous."
    },
    {
      "verse": "53",
      "text": "But one day I will cause Sodom and her daughters to enjoy life again. I will also cause Samaria and her daughters to enjoy life again. And I will also do that for you, Jerusalem."
    },
    {
      "verse": "54",
      "text": "You will be sorry and ashamed that you did such wicked things. Your sisters will be happy that their punishment was less than yours."
    },
    {
      "verse": "55",
      "text": "Sodom and her daughters will become as happy as they were before. Samaria and her daughters will become as happy as they were before. And you and your daughters will also become as happy as you were before."
    },
    {
      "verse": "56",
      "text": "In the days when you were proud of yourselves, you did not respect your sister Sodom."
    },
    {
      "verse": "57",
      "text": "But now everyone can see how wicked you are. So the other nations around you laugh at you. The people of Syria and Philistia and the nations near to them all insult you."
    },
    {
      "verse": "58",
      "text": "You must accept your punishment because of the disgusting things that you have done. You have not been faithful to me. That is what the Almighty Lord says."
    },
    {
      "verse": "59",
      "text": "This is what the Almighty Lord says: You have not done the things that you promised to do when I made a covenant with you. So I will punish you as you deserve."
    },
    {
      "verse": "60",
      "text": "But I will remember the covenant that I made with you when you were still young. I will make that covenant strong and it will continue for ever."
    },
    {
      "verse": "61",
      "text": "Then you will remember the wicked things that you have done and you will be ashamed. You will welcome again your sisters, Sodom and Samaria. I will make them like daughters for you. But they will not share in the same covenant that I make with you."
    },
    {
      "verse": "62",
      "text": "I will cause the covenant that I make with you to be strong. Then you will know that I am the Lord."
    },
    {
      "verse": "63",
      "text": "I will forgive you for your sins so that you are no longer guilty. Then you will remember your sins. You will be too ashamed to say anything. That is what the Almighty Lord says. ” ’"
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, I want you to tell a story to Israel's people. It tells about them."
    },
    {
      "verse": "3",
      "text": "Say to them, “The Almighty Lord says this: There was a great eagle that had strong wings. Its feathers were long and beautiful, with many colours. The eagle came to Lebanon and he took hold of the top of a cedar tree."
    },
    {
      "verse": "4",
      "text": "He broke off the top branch of the tree. He took it to a country where there were many traders who buy and sell things. He planted the branch in a city there."
    },
    {
      "verse": "5",
      "text": "The eagle also took a seed from Israel's land. He planted it in a good field, like a willow tree near to plenty of water."
    },
    {
      "verse": "6",
      "text": "The seed made a plant that grew well. It became a vine that grew near to the ground. The vine's branches turned up towards the eagle. Its roots went down into the ground. The vine grew with many new branches and leaves."
    },
    {
      "verse": "7",
      "text": "There was also another great eagle. It had strong wings and many feathers. Now the vine turned its roots and its branches towards this eagle. It wanted to get more water in the ground where it was growing."
    },
    {
      "verse": "8",
      "text": "But the vine was already growing in a good field where there was plenty of water. It could grow very well in that place, with new branches. It could become a beautiful vine and make grapesthere. ”"
    },
    {
      "verse": "9",
      "text": "Then say to Israel's people, “The Almighty Lord says this: Do you think that the vine will continue to grow well? No, the first eagle will surely pull its roots out of the ground! He will destroy its grapes. All its leaves and branches will become dry and die. It would be easy to pull it out of the ground. It would not need a strong man or a large army to do that."
    },
    {
      "verse": "10",
      "text": "Yes the plant is in the ground, but will it continue to grow? When the hot wind from the east blows on it, it will become completely dry. It will die in the same good field where it had been growing. ” ’"
    },
    {
      "verse": "11",
      "text": "Then the Lord gave this message to me:"
    },
    {
      "verse": "12",
      "text": "‘Israel's people have turned against me. Say to them, “Surely you must understand the meaning of this story. ” Then say to them, “Listen! The king of Babylon came to Jerusalem. He took away Israel's king and his officers. He took them with him as his prisoners to Babylon."
    },
    {
      "verse": "13",
      "text": "He made an agreement with one man from the king of Israel's family. He made that man promise to serve Babylon's king. Then he could rule as king in Jerusalem. The king of Babylon also took away the leaders of Jerusalem as his prisoners."
    },
    {
      "verse": "14",
      "text": "He wanted to make their kingdom weak. He did not want it to become strong enough to fight against him. He wanted them to obey his agreement with him."
    },
    {
      "verse": "15",
      "text": "But the man from the king's family did turn against the king of Babylon. He sent his officers with a message to Egypt. He asked them to send a large army with horses to save Jerusalem. But that will not help him to be safe! He did not obey his agreement with the king of Babylon, so he will not escape!"
    },
    {
      "verse": "16",
      "text": "I promise you this, as surely as I live, says the AlmightyLord. That man that the king of Babylon made king in Jerusalem will die! He will die in Babylon because he did not obey the agreement he had made with the king of Babylon. He thought that his promise was not important."
    },
    {
      "verse": "17",
      "text": "The king of Egypt has a great army and many soldiers. But he still will not be able to help him to fight against Babylon's army. Babylon's soldiers will build heaps of earth against Jerusalem's walls. They will attack the walls and go into the city. They will kill many people in Jerusalem."
    },
    {
      "verse": "18",
      "text": "Judah's king did not obey his agreement with the king of Babylon. He had promised to serve Babylon's king but instead he turned against him. He did not do what he had promised to do, so he will not escape."
    },
    {
      "verse": "19",
      "text": "So this is what the Almighty Lord says: I promise you this, as surely as I live. I will certainly punish Judah's king for what he has done. He did not respect the promise that he made in my name. He did not obey the agreement that he made."
    },
    {
      "verse": "20",
      "text": "I will throw a net over him and I will catch him in my trap. I will take him to Babylon and I will judge him there. I will punish him because he was not faithful to me."
    },
    {
      "verse": "21",
      "text": "All the brave soldiers in his army will die in the battle. The soldiers who escape will run away in all directions. Then you will know that I, the Lord, have spoken this message."
    },
    {
      "verse": "22",
      "text": "The Almighty Lord says this: I myself will take a new branch from the top of a tall cedar tree. I will break off one of its small fresh branches. Then I will plant it on the top of a high mountain. I, the Lord, have said this and I will surely do it. ” ’"
    },
    {
      "verse": "23",
      "text": "I will plant it on a high mountain in Israel. There it will grow and make branches and fruit. It will become a beautiful cedar tree. Many kinds of birds will live under the tree's branches. They will be safe in its shadow."
    },
    {
      "verse": "24",
      "text": "Then all the trees of the forest will know that I am the Lord. I cause tall trees to fall down. I cause small trees to grow tall. I cause green trees to become dry. I cause dry trees to make fresh leaves. I, the Lord, have said this and I will surely do it. ” ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘You say this proverb about Israel: “The fathers have eaten bitter fruit, but it causes their children's teeth to hurt. ” Why do you say that?"
    },
    {
      "verse": "3",
      "text": "Now I, the Lord God, tell you this: You will no longer say that proverb in Israel!"
    },
    {
      "verse": "4",
      "text": "Everyone who lives belong to me. I have authority over the life of the father and over the life of the son. It is the people who do wrong things who will die because of their sins."
    },
    {
      "verse": "5",
      "text": "There may be a truly good man who does what is right and fair. A man like that is righteous. He will continue to live. That is what the Almighty Lord says."
    },
    {
      "verse": "6",
      "text": "He does not go up the mountains and eat the food of idols. He does not pray to the idols that other Israelites worship. He does not have sex with another man's wife. He does not have sex with a woman when she is unclean."
    },
    {
      "verse": "7",
      "text": "He is not cruel to other people. When he lends money to someone, he gives back anything that he has taken as a guarantee. He does not take things that belong to other people. He gives food to hungry people. He gives clothes to poor people."
    },
    {
      "verse": "8",
      "text": "He does not lend money to someone and then ask to receive more money back. He refuses to do anything that is wrong. He helps people in a way that is right and fair."
    },
    {
      "verse": "9",
      "text": "He faithfully obeys my laws and my rules. A man like that is righteous. He will continue to live. That is what the Almighty Lord says."
    },
    {
      "verse": "10",
      "text": "But that man may have a son who is cruel and violent. He may kill other people. He may do those bad things that his father never did. A man like that will not continue to live! He will certainly die, because he himself has done all these disgusting things. He is guilty, so he himself must die as his punishment."
    },
    {
      "verse": "11",
      "text": "He may go up the mountains and eat the food of idols. He might have sex with another man's wife."
    },
    {
      "verse": "12",
      "text": "He might be cruel to people who are poor and weak. He might take things that belong to other people. He might not give back things that he took as a guarantee. He prays to idols. He does disgusting things."
    },
    {
      "verse": "13",
      "text": "When he lends money to people, he wants them to pay back a lot more money to him. A man like that will not continue to live! He will certainly die, because he himself has done all these disgusting things. He is guilty, so he himself must die as his punishment."
    },
    {
      "verse": "14",
      "text": "But this wicked man might have a son himself. The son sees all the sins that his father has done. He thinks about them. Then he decides that he will not live as his father has lived."
    },
    {
      "verse": "15",
      "text": "He does not go up the mountains to eat the food of idols. He does not pray to the idols that other Israelites worship. He does not have sex with another man's wife."
    },
    {
      "verse": "16",
      "text": "He is not cruel to anyone. He does not keep anything that he has taken from someone as a guarantee. He does not rob other people. But he gives food to hungry people. He gives clothes to poor people."
    },
    {
      "verse": "17",
      "text": "He refuses to do anything that is wrong. When he lends money to people, he does not take more back money back from them. He obeys my rules and my laws. This man will certainly continue to live. He will not die because of his father's sins."
    },
    {
      "verse": "18",
      "text": "But his father will die as punishment for his own sins. He cheated people. He robbed people. He did evil things among his own people. So he will die because of his own sins."
    },
    {
      "verse": "19",
      "text": "You should not say, “Surely the son should receive punishment because of his father's sins. ” If the son does what is good and right, and he obeys my laws and my rules, he will continue to live."
    },
    {
      "verse": "20",
      "text": "It is the person who does wrong things who will die. A son will not receive punishment because of his father's sins. And a father will not receive punishment because of his son's sins. Righteous people will receive the good things that they deserve for the good things that they have done. But wicked people will receive the punishment that they deserve for the wicked things that they have done."
    },
    {
      "verse": "21",
      "text": "But a wicked person might turn away from the sins that he has been doing. He might decide to obey my laws and do things that are right and good. If he does that, he will certainly continue to live. He will not die as his punishment."
    },
    {
      "verse": "22",
      "text": "I would no longer say that he is guilty because of the sins that he has done. Instead, he will continue to live, because he has done things that are right."
    },
    {
      "verse": "23",
      "text": "It does not make me happy when a wicked person dies. I want wicked people to stop doing wicked things. Then I am happy because they will continue to live. That is what the Almighty Lord says."
    },
    {
      "verse": "24",
      "text": "A righteous person may stop doing things that are good and right. He may start to do the same disgusting things that wicked people do. Then he will not continue to live. I will not remember any of the good things that he did. Instead, I will punish him because of the sins that he has done. He has not been faithful to me, so he will die."
    },
    {
      "verse": "25",
      "text": "But you say, “The Lord is not doing what is right! ” So listen to me, Israel's people. It is you who are not doing what is right! It is not me!"
    },
    {
      "verse": "26",
      "text": "If a righteous person stops doing good things and he does bad things instead, he will die. Yes, he will die because of the wrong things that he has done."
    },
    {
      "verse": "27",
      "text": "And if a wicked person stops doing wicked things and he does things that are right, he will continue to live."
    },
    {
      "verse": "28",
      "text": "That wicked person realized that he was doing bad things. So he turned away from his sins. Because of that he will certainly continue to live. He will not die."
    },
    {
      "verse": "29",
      "text": "But you, Israel's people, say, “The Lord is not doing what is right! ” Do you really think that is true? No, you are the people who do not do what is right, you Israelites!"
    },
    {
      "verse": "30",
      "text": "The Almighty Lord says this to you, Israel's people: I will judge each of you as you deserve for the way that you live. So change how you live! Turn away from all the wicked things that you do. Then your sins will not finally destroy you."
    },
    {
      "verse": "31",
      "text": "Stop doing all the sins that you have been doing. Instead, think with new thoughts. Live with a new spirit inside you. You do not need to die, Israel's people!"
    },
    {
      "verse": "32",
      "text": "It does not make me happy when anyone has to die. Turn away from your sins so that you continue to live! That is what the Almighty Lord says. ’"
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "‘Sing this sad funeral song for the leaders of Israel."
    },
    {
      "verse": "2",
      "text": "Say this:“Your mother was like a great lion among the other lions. She lay among strong young lions. She helped her children to grow safely. “Your mother was like a great lion among the other lions. She lay among strong young lions. She helped her children to grow safely."
    },
    {
      "verse": "3",
      "text": "She taught one of her children to catch animals for food. As he grew, he started to eat people. As he grew, he started to eat people."
    },
    {
      "verse": "4",
      "text": "The people of other nations heard about him. They dug a hole and they caught him in their trap. They put hooks in him and they took him to Egypt. They dug a hole and they caught him in their trap. They put hooks in him and they took him to Egypt."
    },
    {
      "verse": "5",
      "text": "His mother waited for him to return home. He did not come and she stopped hoping for him. She helped another of her sons to become a strong young lion. He did not come and she stopped hoping for him. She helped another of her sons to become a strong young lion."
    },
    {
      "verse": "6",
      "text": "He grew to be strong among the other lions. He learned to catch wild animals and to eat them. He also learned to eat people. He learned to catch wild animals and to eat them. He also learned to eat people."
    },
    {
      "verse": "7",
      "text": "He attacked their strong buildings and he destroyed their cities. When he roared, the noise frightened everyone in the land. When he roared, the noise frightened everyone in the land."
    },
    {
      "verse": "8",
      "text": "Men from other nations near there came to attack him. They threw a net over him. They caught him in their trap. They threw a net over him. They caught him in their trap."
    },
    {
      "verse": "9",
      "text": "They tied hooks around his neck. They took him to the king of Babylon. There they put him in prison to stop him roaring. The people on the hills of Israel could not hear his voice any longer. They took him to the king of Babylon. There they put him in prison to stop him roaring. The people on the hills of Israel could not hear his voice any longer."
    },
    {
      "verse": "10",
      "text": "Your mother was like a vine that was growing near a stream. It grew well because there was plenty of water there. It made many branches and it had a lot of fruit. It grew well because there was plenty of water there. It made many branches and it had a lot of fruit."
    },
    {
      "verse": "11",
      "text": "Its branches became big and strong. They were strong enough to make a ruler's stick of authority. The vine grew taller than all the other trees around it. Everyone could see that it was very tall and strong. They were strong enough to make a ruler's stick of authority. The vine grew taller than all the other trees around it. Everyone could see that it was very tall and strong."
    },
    {
      "verse": "12",
      "text": "But the Lord became angry with that vine. He pulled up its roots and he threw it down to the ground. The east wind made it dry and destroyed its fruit. Its strong branches broke and they became useless. Fire destroyed them. He pulled up its roots and he threw it down to the ground. The east wind made it dry and destroyed its fruit. Its strong branches broke and they became useless. Fire destroyed them."
    },
    {
      "verse": "13",
      "text": "Now that vine is growing in a desert. It is in a hot, dry place where there is no water. It is in a hot, dry place where there is no water."
    },
    {
      "verse": "14",
      "text": "Fire started to burn its strongest branch. From there the fire destroyed its other branches and its fruit. No strong branch remained in the vine. Now there was nothing to make a ruler's stick of authority. ”This is a funeral song. It tells a very sad story. ’"
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "On the tenth day of the fifth month some of Israel's leaders came to me. That was in the seventh year that we had been prisoners in Babylon. The leaders sat in front of me. They wanted me to ask for a message from the Lord."
    },
    {
      "verse": "2",
      "text": "Then the Lord gave this message to me:"
    },
    {
      "verse": "3",
      "text": "‘Son of man, speak to the leaders of Israel. Tell them, “This is what the Almighty Lord says: You say that you want a message from me. I promise you this, as surely as I live: I will not allow you to come to me like that. ”"
    },
    {
      "verse": "4",
      "text": "Son of man, you must warn them. Are you ready to do that? Make them remember all the disgusting things that their ancestors did."
    },
    {
      "verse": "5",
      "text": "Say to them, “This is what the Almighty Lord says: On the day that I chose Israel's people to belong to me, I made a promise to all Jacob's descendants. In the land of Egypt, I showed them who I am. I promised them, ‘I am the Lord your God. ’"
    },
    {
      "verse": "6",
      "text": "On that day, I promised them that I would bring them out of Egypt. I promised to take them to a land that I had chosen for them. That land would give them plenty of good food and drink, enough for everyone. It was more beautiful than any other land."
    },
    {
      "verse": "7",
      "text": "I said to them, ‘You must each destroy the disgusting idols that you worship. Those are the idols of Egypt and they cause you to be unclean. Remember that I am the Lord your God. ’"
    },
    {
      "verse": "8",
      "text": "But your ancestors did not obey me. They refused to listen to me. None of them destroyed their disgusting idols. They continued to worship the idols of Egypt. So I decided to show them that I was very angry. I said that I would punish them there in Egypt."
    },
    {
      "verse": "9",
      "text": "But I did not want the people of other nations to insult my name. I had promised Israel's people that I would bring them out of Egypt. The nations near where the Israelites were living knew this."
    },
    {
      "verse": "10",
      "text": "So I brought my people out of Egypt. I led them into the wilderness."
    },
    {
      "verse": "11",
      "text": "I gave them my laws and my commands. Anyone who obeyed them would enjoy a good life."
    },
    {
      "verse": "12",
      "text": "I also gave them Sabbath days when they would rest. It would help them to remember that they belong to me. They would know that I, the Lord, have made them my holy people."
    },
    {
      "verse": "13",
      "text": "But when Israel's people were in the wilderness, they turned against me. They did not obey my laws or my commands. (But anyone who did obey them would enjoy a good life. ) They did not obey my rules for Sabbath days. So I was very angry with them. I decided to destroy them there in the wilderness."
    },
    {
      "verse": "14",
      "text": "But I did not want the people of other nations to insult my name. They had seen me bring Israel's people out of Egypt."
    },
    {
      "verse": "15",
      "text": "So I made a strong promise to my people in the wilderness. I said that I would not take them to the land that I had chosen for them. It was a very beautiful land with plenty of food and drink for everyone."
    },
    {
      "verse": "16",
      "text": "I refused to take them there because they had not obeyed my laws and my commands. They did not obey my rules for Sabbath says. Instead, they liked to worship their idols."
    },
    {
      "verse": "17",
      "text": "But I chose to be kind to them. I did not completely destroy them in the wilderness."
    },
    {
      "verse": "18",
      "text": "I said to their children in the wilderness, ‘Do not live in the bad way that your fathers did. Do not obey their rules. Do not worship their idols and make yourselves unclean."
    },
    {
      "verse": "19",
      "text": "Remember that I am the Lord your God. So be careful to obey my laws and my commands."
    },
    {
      "verse": "20",
      "text": "Make Sabbath days special to show that you belong to me. Then you will know that I am the Lord your God. ’"
    },
    {
      "verse": "21",
      "text": "But their children also turned against me. They were not careful to obey my laws and my commands. (But anyone who obeyed them would enjoy a good life. ) They did not obey my rules about Sabbath days. So I was very angry with them. I was ready to destroy them there in the wilderness."
    },
    {
      "verse": "22",
      "text": "But I did not want the people of other nations to insult my name. They had seen me bring Israel's people out of Egypt. So I could not destroy my people."
    },
    {
      "verse": "23",
      "text": "There in the wilderness I made a strong promise to them. I promised to send them to many different places where they would live among other nations."
    },
    {
      "verse": "24",
      "text": "This was because they had not obeyed my laws and my commands. They had not obeyed my rules about Sabbath days. Instead, they worshipped the same idols that their ancestors worshipped."
    },
    {
      "verse": "25",
      "text": "So I let them obey rules that were not good. They were laws that would not help them to enjoy a good life."
    },
    {
      "verse": "26",
      "text": "I let them make themselves unclean because of the offerings that they made. They burned their firstborn children in fire as sacrifices. I did that to make them afraid. I wanted them to know that I am the Lord. ”"
    },
    {
      "verse": "27",
      "text": "So, son of man, you must speak to Israel's people. Tell them, “This is what the Almighty Lord says: Your ancestors insulted me when they did not serve me faithfully."
    },
    {
      "verse": "28",
      "text": "I took them to the land which I had promised to give to them. But when they were there, they continued to offer sacrifices to idols. They did this on every high hill or under every green tree that they saw! They burned sweet incense and they poured out wine as offerings in all those places. That made me very angry."
    },
    {
      "verse": "29",
      "text": "I asked them, ���Why do you go to these high places? ’ ” (That is why people still call them “high places”. )"
    },
    {
      "verse": "30",
      "text": "So say this to Israel's people. “This is what the Almighty Lord says: Will you continue to make yourselves unclean in the way that your ancestors did? You are not faithful to me. Instead, you worship disgusting idols."
    },
    {
      "verse": "31",
      "text": "You make yourselves unclean when you offer sacrifices to your idols. You burn your sons in fire as offerings. You still continue to do that! So should I allow you to come to me for help? I promise you this, as surely as I live: I will not allow you to come to me! That is what the Almighty Lord says."
    },
    {
      "verse": "32",
      "text": "You think, ‘We want to live like the people of other nations and clans. They worship idols that are made from wood and stone. ’ But these thoughts will never happen."
    },
    {
      "verse": "33",
      "text": "The Almighty Lord says, I promise you this, as surely as I live: I will use my great power and authority to rule you as your King. You will know how angry I am!"
    },
    {
      "verse": "34",
      "text": "I will bring you back from the nations where I sent you to live. I will bring you back from all those different places. I will use my great power to do this and you will know that I am very angry with you."
    },
    {
      "verse": "35",
      "text": "I will bring you to a wilderness with other nations all around it. I will meet with you there and I will show that you are guilty."
    },
    {
      "verse": "36",
      "text": "I judged your fathers in the wilderness when they came out of Egypt. I will punish you in the same way. That is what the Almighty Lord says."
    },
    {
      "verse": "37",
      "text": "I will count you one by one, as a shepherd counts his sheep. I will cause you to obey the rules of my covenant with you."
    },
    {
      "verse": "38",
      "text": "I will remove from among you those who refuse to obey me. I will bring them out from the country where they have been living. But they will not go into the land of Israel. Then you will know that I am the Lord."
    },
    {
      "verse": "39",
      "text": "Israel's people, this is what the Almighty Lord says to you: Now, every one of you, go to serve your idols! But after that, you will listen to me. You will no longer insult my holy name. You will no longer give gifts to your idols."
    },
    {
      "verse": "40",
      "text": "All of Israel's people will serve me on my holy mountain, Israel's great mountain. There I will accept them as my people. That is what the Almighty Lord says. I will receive your offerings, your gifts and all your holy sacrifices."
    },
    {
      "verse": "41",
      "text": "I will bring you home from the nations and all the places where you have been living. Then I will welcome you, like sweet incense that pleases me. When I am among you, I will show all the other nations that I am holy."
    },
    {
      "verse": "42",
      "text": "I will bring you into the land of Israel. That is the land that I promised to give to your ancestors. Then you will know that I am the Lord."
    },
    {
      "verse": "43",
      "text": "You will remember all the wrong things that you did which made you unclean. You will be ashamed of yourselves because of all the evil things that you have done."
    },
    {
      "verse": "44",
      "text": "At that time, I will help you. I will not punish you as you deserve for your wicked and evil acts. Instead, I will do things that bring honour to my name. Then, Israel's people, you will know that I am the Lord. That is what the Almighty Lord says. ” ’"
    },
    {
      "verse": "45",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "46",
      "text": "‘Son of man, look towards the south. Speak my message to the people there. Warn the forests in the dry land of the south."
    },
    {
      "verse": "47",
      "text": "Say to those forests, “Listen to this message from the Lord. This is what the Almighty Lord says: Listen! I will start a fire to burn you. The fire will destroy all the green trees and all the dry trees. Nobody will be able to stop that fire. From the dry land in the south, all the way to the north, the fire will burn everything."
    },
    {
      "verse": "48",
      "text": "Everyone will see that I, the Lord, started the fire. Nobody will be able to stop it burning. ” ’"
    },
    {
      "verse": "49",
      "text": "Then I said, ‘Almighty Lord, “The people are already saying that my stories make them confused. ” ’"
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, look towards Jerusalem. Speak about the things in my holy place that are wrong. Speak my message to warn the people of Israel."
    },
    {
      "verse": "3",
      "text": "Say to them, “This is what the Lord says: I am now your enemy. I will take my sword in my hand. I will use it to kill both righteous people and wicked people."
    },
    {
      "verse": "4",
      "text": "I will remove righteous people and wicked people from among you. So I will use my sword to attack everyone in the land, from the north to the south."
    },
    {
      "verse": "5",
      "text": "Then all the people will know that I am the Lord. I am the one who is punishing them with my sword. And I will not put it back in its place. ”"
    },
    {
      "verse": "6",
      "text": "So now, son of man, cry aloud. Let the people see how sad and upset you are."
    },
    {
      "verse": "7",
      "text": "They will ask you, “Why are you so sad? ” Then you will say, “I am sad because of the news that will soon come. Every one of you will be very afraid. Your hands will be weak and your knees will shake. ” You can be sure that this will happen very soon. That is what the Almighty Lord says. ’"
    },
    {
      "verse": "8",
      "text": "The Lord gave this message to me: Look at my sword! It is sharp and it shines brightly."
    },
    {
      "verse": "9",
      "text": "‘Son of man, speak my message to the people. Say, “This is what the Lord says: Look at my sword! It is sharp and it shines brightly."
    },
    {
      "verse": "10",
      "text": "It is sharp and it is ready to kill people. It shines as bright as lightning! Should we trust in the power of our king? No! This sword does not respect any kingdom. It shines as bright as lightning! Should we trust in the power of our king? No! This sword does not respect any kingdom."
    },
    {
      "verse": "11",
      "text": "Now it is sharp and it shines. It is ready for someone to take in their hand. It is ready for the killer to use it. ” It is ready for someone to take in their hand. It is ready for the killer to use it. ”"
    },
    {
      "verse": "12",
      "text": "Cry aloud, son of man! This sword is ready to attack my people. It will attack all the leaders of Israel. It will destroy my people and their leaders. Because of that, show that you are very upset. This sword is ready to attack my people. It will attack all the leaders of Israel. It will destroy my people and their leaders. Because of that, show that you are very upset."
    },
    {
      "verse": "13",
      "text": "I am ready to test my people. My sword does not respect the power of any king. So my people will not escape punishment. That is what the Almighty Lord says. My sword does not respect the power of any king. So my people will not escape punishment. That is what the Almighty Lord says."
    },
    {
      "verse": "14",
      "text": "So speak my message to warn my people, son of man. Then clap your hands together. My sword must attack them many times. It is ready to kill many people. It will attack them from all directions. Then clap your hands together. My sword must attack them many times. It is ready to kill many people. It will attack them from all directions."
    },
    {
      "verse": "15",
      "text": "So people will shake with fear. Many of them will fall down. My sword is ready to kill them at every gate of the city. It shines like lightning. It is ready to kill! My sword is ready to kill them at every gate of the city. It shines like lightning. It is ready to kill!"
    },
    {
      "verse": "16",
      "text": "My sword, attack quickly on your right side! Now turn and attack on your left side! Attack in every direction that you turn! Now turn and attack on your left side! Attack in every direction that you turn!"
    },
    {
      "verse": "17",
      "text": "Then I, too, will clap my hands together. Finally, my anger will finish. I, the Lord, have spoken. ’ Finally, my anger will finish. I, the Lord, have spoken. ’"
    },
    {
      "verse": "18",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "19",
      "text": "‘Son of man, make a mark on two roads for the king of Babylon to follow with his army. Both these roads must start from the same country. Put a sign at the place where the two roads go in separate directions."
    },
    {
      "verse": "20",
      "text": "Show the two places that the roads go to. One road goes to Rabbah, the big city of the Ammonites. The other road goes to Judah and its strong city, Jerusalem."
    },
    {
      "verse": "21",
      "text": "The king of Babylon will arrive at the place where the road goes in separate directions. He will try to decide which way to go. He will use magic to ask his gods to tell him. He will shake arrows in his hands. He will pray to his idols. He will look at the livers of animals."
    },
    {
      "verse": "22",
      "text": "The arrow in his right hand shows him that he should go to Jerusalem. He will command his army to go and kill the people there. His soldiers will use heavy pieces of wood to knock down the walls and gates of the city. They will shout as they attack the city. They will build heaps of earth against the city's walls."
    },
    {
      "verse": "23",
      "text": "The people in Jerusalem had promised to serve the king of Babylon. So they think that he will not attack them. But he will tell them about the wrong things that they have done. Because of that he will take them as his prisoners."
    },
    {
      "verse": "24",
      "text": "So this is what the Almighty Lord says: You have shown everyone that you are guilty of many sins. Everything that you do shows your sins very clearly. Because you are guilty, your enemies will take you as their prisoners."
    },
    {
      "verse": "25",
      "text": "I say this to you, wicked king of Israel. The time for your final punishment has now arrived. Take off the special cloth from the king's head. Remove his crown! Everything will change! Give honour to humble people! Make proud people ashamed!"
    },
    {
      "verse": "26",
      "text": "This is what the Almighty Lord says: Take off the special cloth from the king's head. Remove his crown! Everything will change! Give honour to humble people! Make proud people ashamed!"
    },
    {
      "verse": "27",
      "text": "I will cause your city to become a heap of stones. I will destroy the kingdom. This will happen when my chosen man comes. I have chosen him to punish the city. Then I will give him authority over the city, because it belongs to him. I will destroy the kingdom. This will happen when my chosen man comes. I have chosen him to punish the city. Then I will give him authority over the city, because it belongs to him."
    },
    {
      "verse": "28",
      "text": "You, son of man, must speak my message about the Ammonites. They have insulted Israel. This is what the Almighty Lord says: A sword is ready to destroy them. It shines brightly like lightning and it is ready to kill. A sword is ready to destroy them. It shines brightly like lightning and it is ready to kill."
    },
    {
      "verse": "29",
      "text": "Their visions about the battle have deceived them. What they think will happen is only lies. The sword will punish wicked people with death. The time for their final punishment has now arrived. What they think will happen is only lies. The sword will punish wicked people with death. The time for their final punishment has now arrived."
    },
    {
      "verse": "30",
      "text": "Now put the sword back in its place! I will judge you in your own land, in the place where you were born. I will judge you in your own land, in the place where you were born."
    },
    {
      "verse": "31",
      "text": "I will punish you very strongly, because I am so angry with you. I will put you under the power of cruel menwho know how to destroy people. because I am so angry with you. I will put you under the power of cruel men who know how to destroy people."
    },
    {
      "verse": "32",
      "text": "You will be like wood that helps a fire to burn. You will die a violent death in your own land. Nobody will remember you any more. I, the Lord, have said this. ’"
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, you must warn the people in this city about their punishment. The people are murderers. They have done many disgusting things. Are you ready to tell them that?"
    },
    {
      "verse": "3",
      "text": "Say to them, “This is what the Almighty Lord says: Because you murder people, you have caused your punishment to come. You make idols for yourselves, and that has made you unclean."
    },
    {
      "verse": "4",
      "text": "Because you have murdered people and you have made disgusting idols, you are now guilty. This has brought the time of your punishment very near. Your years of power have come to an end. I will cause the people of other nations to laugh at you. They will all insult you."
    },
    {
      "verse": "5",
      "text": "The people of countries that are near to you will laugh at you. Those who live far away will also laugh at you. You will no longer receive any honour because your city is full of trouble."
    },
    {
      "verse": "6",
      "text": "Each ruler of Israel that lives in you, Jerusalem, has been a murderer. Each one has used his power to kill people."
    },
    {
      "verse": "7",
      "text": "The people in the city do not respect their parents. They have been cruel to the foreigners who live among you. They have cheated widows and children who have no family."
    },
    {
      "verse": "8",
      "text": "You have not respected my holy things. You have not made my Sabbath days special."
    },
    {
      "verse": "9",
      "text": "There are men among you who tell lies so that they can kill other people. There are people who eat the food of idols on the mountains. They do disgusting things among you."
    },
    {
      "verse": "10",
      "text": "Some men have sex with their father's wife. Some men have sex with a woman at the time when she bleeds each month and she is unclean."
    },
    {
      "verse": "11",
      "text": "One man has sex with another man's wife. Another man has sex with his son's wife. Another man among you has sex with the daughter of his own father. These are disgusting things to do."
    },
    {
      "verse": "12",
      "text": "People among you accept bribes to kill somebody. When some of you lend money to people, you make them pay more money back to you. Some of you use your power to make people give you money. You people of Jerusalem have forgotten me. That is what the Lord says."
    },
    {
      "verse": "13",
      "text": "Listen to me! I will show you that I am angry with you. You have cheated people and taken their money. You have murdered people who live among you."
    },
    {
      "verse": "14",
      "text": "When I have punished you, you will no longer feel brave or strong. I, the Lord, have said what I will do. And I will do it."
    },
    {
      "verse": "15",
      "text": "I will send you away to live among many other nations. I will stop you doing evil things."
    },
    {
      "verse": "16",
      "text": "All the other nations will see that you are useless. Then you will know that I am the Lord. ” ’"
    },
    {
      "verse": "17",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "18",
      "text": "‘Son of man, Israel's people have become like dirt to me. They are like useless bits of metal that remain after silver is made pure in a hot oven."
    },
    {
      "verse": "19",
      "text": "So this is what the Lord God says: All of you have become like useless dirt. So listen to me! I will bring you all together into the middle of Jerusalem."
    },
    {
      "verse": "20",
      "text": "It will be like a hot oven that I put you in. It will be like an oven where men cause different metals to melt to make them pure. Because I am very angry with you, I will bring you into the city to punish you there."
    },
    {
      "verse": "21",
      "text": "I will put you in my oven, Jerusalem. And I will burn you with my hot anger."
    },
    {
      "verse": "22",
      "text": "My great anger will cause you to melt, like men cause silver to melt in a hot oven. Then you will know that I am the Lord. And you will know that I have punished you with my anger. ’"
    },
    {
      "verse": "23",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "24",
      "text": "‘Son of man, say to the land of Israel, “I am angry with you. Because of that, you will receive no rain to make you clean. ”"
    },
    {
      "verse": "25",
      "text": "The rulers in the land hurt people, like strong lions that tear animals in pieces. They use their power to destroy people. They take for themselves riches and valuable things that belong to other people. They have killed many men so that there are now many widows in the land."
    },
    {
      "verse": "26",
      "text": "The priests in the land do not obey my law. They do not respect my holy things. They do not think that holy things are different from ordinary things. They say that unclean things and clean things are the same. They refuse to make my Sabbath days special. Because of this, people do not give me any honour."
    },
    {
      "verse": "27",
      "text": "The officers in the land are like wolves that catch other animals and tear them into pieces. They use their power to murder people so that they can take their money for themselves."
    },
    {
      "verse": "28",
      "text": "The prophets in the land give false messages. They say that bad things are good. They see false visions. They tell lies about what will happen. They say, “This is what the Almighty Lord says. ” But I, the Lord, have not spoken to them."
    },
    {
      "verse": "29",
      "text": "The people in the land make people give them money. They rob people. They are cruel to poor people and to weak people. They cheat foreign people who live among them. They do not allow them to have justice."
    },
    {
      "verse": "30",
      "text": "I looked among the people for a man who would make the land safe. He would make it a good, strong place again, with nothing bad in it. Then I would not destroy it. But I could not find anyone like that."
    },
    {
      "verse": "31",
      "text": "So I will certainly destroy them. I will punish them with my great anger, like a fire that burns them completely. I will now punish them as they deserve for their sins. That is what the Almighty Lord says. ’"
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, there were two sisters who had the same mother."
    },
    {
      "verse": "3",
      "text": "They were prostitutes in Egypt, from the time that they were both young women. Men touched their breasts and made love to them."
    },
    {
      "verse": "4",
      "text": "The older sister was called Oholah. The younger one was called Oholibah. In this story, Oholah is Samaria. Oholibah is Jerusalem. They became my wives, and later they gave birth to sons and daughters for me."
    },
    {
      "verse": "5",
      "text": "Oholah was my wife but she continued to live as a prostitute. She wanted men from Assyria to be her lovers."
    },
    {
      "verse": "6",
      "text": "Her lovers were soldiers who wore blue clothes. Some of them were army officers and leaders. They were all strong young men. Some of them rode on horses."
    },
    {
      "verse": "7",
      "text": "Oholah gave herself to them as a prostitute. She had sex with all the important young men of Assyria. She did these disgusting things with anyone that she wanted. She worshipped their idols and she made herself unclean."
    },
    {
      "verse": "8",
      "text": "She had lived as a prostitute in Egypt when she was young. Men had sex with her. They touched her breasts and they enjoyed her body for themselves. She continued to do that with the Assyrian men."
    },
    {
      "verse": "9",
      "text": "She wanted the Assyrian men to be her lovers. Because of that I put her under their power."
    },
    {
      "verse": "10",
      "text": "They removed her clothes to make her ashamed. They took away her sons and daughters. They attacked her and they killed her. Because of her punishment, women everywhere talked about her."
    },
    {
      "verse": "11",
      "text": "Ohalah's sister, Oholibah, saw this, but she did even worse things than her sister. She wanted other lovers even more than her sister did."
    },
    {
      "verse": "12",
      "text": "She, too, wanted Assyrian men to be her lovers. They were army officers and leaders. They were brave soldiers in beautiful clothes. Some of them rode on horses. They were all strong young men."
    },
    {
      "verse": "13",
      "text": "I saw that she was living in the same way that her sister had done. Like her sister, she made herself unclean."
    },
    {
      "verse": "14",
      "text": "But Oholibah did even worse things, as a prostitute does. She saw pictures of men on the walls. They were bright red pictures that people had made of Babylonian men."
    },
    {
      "verse": "15",
      "text": "The men wore belts around their bodies. They wore large cloths around their heads. They looked like Babylonian army officers who came from Chaldea."
    },
    {
      "verse": "16",
      "text": "When Oholibah saw these pictures, she wanted the men to be her lovers. She sent messages to them in Babylonia."
    },
    {
      "verse": "17",
      "text": "The Babylonian soldiers came to have sex with her. They did many disgusting things with her so that she was unclean. After they had done this to her, she became upset. She turned away from them."
    },
    {
      "verse": "18",
      "text": "She was not ashamed to have sex with many other men. Everyone knew that she lived as a prostitute. So I was very upset. I turned away from her, as I had turned away from her sister."
    },
    {
      "verse": "19",
      "text": "But she wanted more and more men to be her lovers. She remembered how she had lived as a prostitute in Egypt when she was a young woman."
    },
    {
      "verse": "20",
      "text": "She wanted those strong men to be her lovers. They had sex in a strong way, like donkeys or horses."
    },
    {
      "verse": "21",
      "text": "Yes, Oholibah, you thought about the disgusting ways that you had sex when you were young. You wanted men to touch your breasts and make love to you as the Egyptian men had done."
    },
    {
      "verse": "22",
      "text": "So this is what the Almighty Lord says to you, Oholibah: “Listen to me! I will cause your lovers to become angry with you. The lovers that you turned away from will come to attack you. I will bring them from every direction to attack you."
    },
    {
      "verse": "23",
      "text": "The soldiers from Babylon and from Chaldea will come. Men from Pekod, Shoa and Koa will come. All the Assyrian soldiers will come with them. They will be beautiful young men, army officers, leaders and important men. They will all ride on horses."
    },
    {
      "verse": "24",
      "text": "They will attack you with their weapons, their chariots and with a large army of soldiers. They will come together all around you, on every side. They will have different kinds of shields. They will wear helmets on their heads. I will give them authority to judge you. They will punish you in the way that they choose."
    },
    {
      "verse": "25",
      "text": "You have not been faithful to me, so I am very angry with you. I will cause these men to punish you in cruel ways. They will cut off your noses and your ears. They will use their swords to kill any men who remain. They will take away your sons and daughters. Fire will destroy any of your people who remain."
    },
    {
      "verse": "26",
      "text": "They will pull off your clothes. They will take away your beautiful jewels."
    },
    {
      "verse": "27",
      "text": "That is how I will stop you living in a disgusting way. You will no longer live as a prostitute, in the way that you lived in Egypt. You will not want to live in that way again. You will not think about how you lived in Egypt any more. ”"
    },
    {
      "verse": "28",
      "text": "This is what the Almighty Lord says: “Listen! I will put you under the power of people that you hate. Those were the people that you turned away from because you were upset."
    },
    {
      "verse": "29",
      "text": "They will be cruel to you. They will take away everything that you worked hard to get. When they leave you, you will have no clothes to wear. You will be ashamed. Everyone will see that you have lived as a prostitute and you have done disgusting things."
    },
    {
      "verse": "30",
      "text": "I am punishing you in this way because you were not faithful to me. You wanted other nations to be your lovers. You became unclean because you worshipped their idols."
    },
    {
      "verse": "31",
      "text": "You have lived in the same bad way that your sister lived. So I will punish you as I punished her. ”"
    },
    {
      "verse": "32",
      "text": "This is what the Lord God says:“You will drink from the same cup of punishment that I gave to your sister. It is a cup that holds a lot of punishment. People will laugh at you and they will insult you. “You will drink from the same cup of punishment that I gave to your sister. It is a cup that holds a lot of punishment. People will laugh at you and they will insult you."
    },
    {
      "verse": "33",
      "text": "You will suffer very much. You will be drunk and very sad. The cup of your punishment will destroy you. Like your sister Samaria, nothing will remain in you. You will be drunk and very sad. The cup of your punishment will destroy you. Like your sister Samaria, nothing will remain in you."
    },
    {
      "verse": "34",
      "text": "You will have to drink all the punishment that is in that cup! Then you will break the cup into pieces. You will cut your breasts to show that you are very upset. I, the Almighty Lord, have said this. ” Then you will break the cup into pieces. You will cut your breasts to show that you are very upset. I, the Almighty Lord, have said this. ”"
    },
    {
      "verse": "35",
      "text": "This is what the Almighty Lord says: “You have forgotten me. You have not been faithful to me. You have lived as a prostitute and you have done disgusting things. So now you must receive the punishment that you deserve. ” ’"
    },
    {
      "verse": "36",
      "text": "The Lord said to me, ‘Son of man, you must judge Oholah and Oholibah. Warn them that they have done disgusting things."
    },
    {
      "verse": "37",
      "text": "They have not been faithful to me. They have murdered people. They have worshipped idols. They have not been faithful to me as their husband. They have even offered their children as food to their idols. Those were my children that they burned with fire."
    },
    {
      "verse": "38",
      "text": "Also, they have done these things against me: They made my holy place unclean. At the same time, they did not obey my rules for Sabbath days."
    },
    {
      "verse": "39",
      "text": "They offered their sons as sacrifices to their idols. Then, on the same day, they came into my temple! That is how they made my own special house unclean."
    },
    {
      "verse": "40",
      "text": "The two sisters sent messages to men in places far away. When the men came to visit them, the sisters washed themselves. Yes, you made your eyes beautiful with paint. You wore beautiful jewels."
    },
    {
      "verse": "41",
      "text": "You sat on a beautiful bed with a table in front of it. On the table you put incense and olive oil that I had given to you."
    },
    {
      "verse": "42",
      "text": "There was a crowd of happy men around them. They included men who came from the desert and who were drunk. They put rings on the sisters' hands and beautiful crowns on their heads."
    },
    {
      "verse": "43",
      "text": "I said this about the woman who had become tired of having sex with so many men: “They will continue to have sex with her, as she is a prostitute. ”"
    },
    {
      "verse": "44",
      "text": "So the men had sex with her, as men have sex with prostitutes. That is how they had sex with Oholah and Oholibah, those two prostitutes."
    },
    {
      "verse": "45",
      "text": "But good men will say that those women are guilty. They will punish them as they deserve, because they have not been faithful to me. They have also murdered people."
    },
    {
      "verse": "46",
      "text": "This is what the Almighty Lord says: Bring an army to attack those women. Make them very afraid. Take away their valuable things."
    },
    {
      "verse": "47",
      "text": "The army will throw stones at them and cut them with their swords. They will kill their sons and daughters. They will destroy their houses with fire."
    },
    {
      "verse": "48",
      "text": "That is how I will stop the people of this land from doing disgusting things. All the women will see what has happened to Oholah and Oholibah. They will not do the same disgusting things themselves."
    },
    {
      "verse": "49",
      "text": "And you, Oholah and Oholibah, will receive the punishment that you deserve. You have lived as prostitutes, and you have not been faithful to me. Instead, you have worshipped idols. So I will punish you. Then you will know that I am the Almighty Lord. ’"
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me on the tenth day of the tenth month in the ninth year: Put the pot on the fire. Put it there now. Pour some water into the pot."
    },
    {
      "verse": "2",
      "text": "‘Son of man, remember this day. Write it down. On this day, the king of Babylon is starting to attack Jerusalem."
    },
    {
      "verse": "3",
      "text": "Tell a story to these people who refuse to obey me. Say to them, “This is what the Almighty Lord says: Put the pot on the fire. Put it there now. Pour some water into the pot."
    },
    {
      "verse": "4",
      "text": "Put the pieces of meat into it. Put in all the good pieces of meat. Put in the leg and the shoulder. Fill it with all the best bones. Put in all the good pieces of meat. Put in the leg and the shoulder. Fill it with all the best bones."
    },
    {
      "verse": "5",
      "text": "Use meat and bones from the best sheep. Put more wood on the fire under the pot. Cause the water in the pot to boil well. Cook the bones and the meat. Put more wood on the fire under the pot. Cause the water in the pot to boil well. Cook the bones and the meat."
    },
    {
      "verse": "6",
      "text": "This is what the Almighty Lord says: Terrible trouble will come to the city that is full of murderers! It is like a pot that has become dirty. Nobody has tried to clean it. Take out each piece of meat, one by one. No piece is special. Terrible trouble will come to the city that is full of murderers! It is like a pot that has become dirty. Nobody has tried to clean it. Take out each piece of meat, one by one. No piece is special."
    },
    {
      "verse": "7",
      "text": "You can see the blood of people that men killed in the city. It lies on the rocks where everyone can see it. Those murderers did not leave the blood on the ground, where dirt would hide it. It lies on the rocks where everyone can see it. Those murderers did not leave the blood on the ground, where dirt would hide it."
    },
    {
      "verse": "8",
      "text": "I have put the blood on the rocks where everyone can see it. Nothing will be able to hide it. When I see it, I am very angry. I will punish the people of that city as they deserve. Nothing will be able to hide it. When I see it, I am very angry. I will punish the people of that city as they deserve."
    },
    {
      "verse": "9",
      "text": "So this is what the Almighty Lord says: Terrible trouble will come to the city that is full of murderers! I will put more wood on the fire to destroy it. Terrible trouble will come to the city that is full of murderers! I will put more wood on the fire to destroy it."
    },
    {
      "verse": "10",
      "text": "Yes, make a big heap of wood. Make the fire burn hot! Cook the meat well! Mix in some spices! Let the bones burn. Make the fire burn hot! Cook the meat well! Mix in some spices! Let the bones burn."
    },
    {
      "verse": "11",
      "text": "Then put the empty pot on the coals of the fire. Make the pot very hot, so that its metal is bright red. Burn all the dirt to remove it. Make the pot clean again! Make the pot very hot, so that its metal is bright red. Burn all the dirt to remove it. Make the pot clean again!"
    },
    {
      "verse": "12",
      "text": "Yes, I have tried to make it clean. But the disgusting dirt is still there. So throw the pot and all its dirt on the fire! But the disgusting dirt is still there. So throw the pot and all its dirt on the fire!"
    },
    {
      "verse": "13",
      "text": "The dirt on the pot shows the disgusting things that you do. I tried to remove those wicked things to make you clean, but you would not let me do that. So I will punish you until I am no longer angry with you. You will not be clean until that happens."
    },
    {
      "verse": "14",
      "text": "I, the Lord have said what I will do. Now I will do it! The time for your punishment has come! I will not change my mind. I will not be kind to you. I will not be sorry for you. I will judge you as you deserve for the things that you have done. That is what the Almighty Lord says. ” ’"
    },
    {
      "verse": "15",
      "text": "The Lord gave me this message:"
    },
    {
      "verse": "16",
      "text": "‘Son of man, I will suddenly take away from you the one person who makes you happy. But you must not weep. Do not let people see that you are sad."
    },
    {
      "verse": "17",
      "text": "Cry inside yourself but do not cry aloud. Do not show that you are sad because someone has died. Do not remove the cloth from your head. Keep your shoes on your feet. Do not cover the lower part of your face. Do not eat the food that people eat at funerals. ’"
    },
    {
      "verse": "18",
      "text": "That morning I spoke to the people. In the evening of that day, my wife died. The next morning I did what the Lord had told me to do."
    },
    {
      "verse": "19",
      "text": "Then the people said to me, ‘Please tell us why you are doing these things. What are you trying to show us? ’"
    },
    {
      "verse": "20",
      "text": "So I said to them, ‘The Lord gave this message to me:"
    },
    {
      "verse": "21",
      "text": "Say to Israel's people, “This is what the Almighty Lord says: Listen! I will now make my holy place become unclean. It is the place that makes you very proud. You love it because it is so beautiful. But now enemy soldiers will kill your sons and daughters that you left in Jerusalem."
    },
    {
      "verse": "22",
      "text": "Then you will do the same things that I have done. You will not cover the lower part of your face. You will not eat special food that people eat at funerals."
    },
    {
      "verse": "23",
      "text": "You will still wear your cloths on your heads. You will wear your shoes on your feet. You will not cry aloud or weep. You will suffer and you will be weak because of the punishment for your sins. You will cry quietly among yourselves."
    },
    {
      "verse": "24",
      "text": "Ezekiel is an example to you. You must do the same as he has done when his wife died. When this happens, you will know that I am the Almighty Lord. ”"
    },
    {
      "verse": "25",
      "text": "Son of man, I will soon take away from them Jerusalem's great temple. It is the beautiful place that has made them very happy. They are very proud of it. They love to look at it. I will also take away their sons and daughters."
    },
    {
      "verse": "26",
      "text": "On the day when that happens, a man will run away from the battle in Jerusalem. He will come here to tell you the news."
    },
    {
      "verse": "27",
      "text": "At that time, you will be able to speak again. You will talk with that man. You will no longer have to be quiet. You will be an example to the people, and they will know that I am the Lord. ’"
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, look towards the people in Ammon. You must tell them my message to warn them."
    },
    {
      "verse": "3",
      "text": "Say to them, “Listen to this message from the Almighty Lord. This is what he says: You shouted happily when enemies made my holy place unclean. You were happy when the land of Israel became an empty place. And you were happy when Judah's people went away as prisoners to a foreign country."
    },
    {
      "verse": "4",
      "text": "So listen to me! I will give you to the people in the east to be their slaves. Their soldiers will come and they will put their tents among you. They will live among you. They will eat your fruit and they will drink your milk."
    },
    {
      "verse": "5",
      "text": "I will make Rabbah a place where camels eat grass. I will make Ammon a place where sheep rest. Then you will know that I am the Lord."
    },
    {
      "verse": "6",
      "text": "This is what the Almighty Lord says: You were happy when I punished Israel. You clapped your hands together. You stamped your feet on the ground."
    },
    {
      "verse": "7",
      "text": "So listen! I will now use my power to punish you. I will allow other nations to take all your valuable things. I will completely remove you so that you will not be a nation any longer. I will destroy you. Then you will know that I am the Lord. ”"
    },
    {
      "verse": "8",
      "text": "The Almighty Lord says this: The people in Moab and Seir said, “Judah's people have become the same as all the other nations. ”"
    },
    {
      "verse": "9",
      "text": "So listen! I will let enemies attack the towns on the border of Moab. I will destroy their greatest cities, Beth Jeshimoth, Baal Meon and Kiriathaim."
    },
    {
      "verse": "10",
      "text": "I will give Moab's people to the people in the east as their slaves, together with the Ammonites. The other nations will not remember the Ammonites any more."
    },
    {
      "verse": "11",
      "text": "I will also punish Moab's people. Then they will know that I am the Lord."
    },
    {
      "verse": "12",
      "text": "The Almighty Lord says this: Edom's people were cruel to Judah's people when they wanted to punish them. They are guilty because of what they did to Judah's people."
    },
    {
      "verse": "13",
      "text": "So the Almighty Lord God says this: I will use my power to punish Edom. I will destroy Edom's people and animals. Edom will become an empty place. Enemy soldiers will use their swords to kill the people, everywhere from Teman to Dedan."
    },
    {
      "verse": "14",
      "text": "I will use my people, the Israelites, to punish Edom. The Edomites will know that I am very angry with them. They will know that their punishment comes from me. That is what the Almighty Lord says."
    },
    {
      "verse": "15",
      "text": "The AlmightyLord says this: The Philistines were cruel to Judah's people when they wanted to punish them. They hated Judah's people and they wanted to destroy them. They would not stop attacking them."
    },
    {
      "verse": "16",
      "text": "So this is what the Almighty Lord says: Listen! I will use my power to punish the Philistines. I will kill the Kerethites. I will destroy the people who remain on the coast of the sea."
    },
    {
      "verse": "17",
      "text": "I will punish them very much because of the things that they have done. I will show them that I am very angry with them. When and I punish them as they deserve, they will know that I am the Lord. ’"
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me on the first day of the month, in the 11th year:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, Tyre's people have said, “Good! An enemy has destroyed Jerusalem! Traders from that city went out to many nations. Now we will do that instead of them. We will become rich because Jerusalem is no longer a strong city. ”"
    },
    {
      "verse": "3",
      "text": "So this is what the Almighty Lord says: Listen! I have become your enemy, Tyre. I will bring many nations to attack you. They will be like the waves of the sea as they hit you."
    },
    {
      "verse": "4",
      "text": "They will destroy the walls of Tyre. They will knock down its strong towers. I will then remove all the stones that remain. The city will become a rock with nothing on it."
    },
    {
      "verse": "5",
      "text": "On that rock, in the middle of the sea, men will dry the nets that they use to catch fish. That is what I say, says the Almighty Lord. Armies from other nations will take Tyre's valuable things for themselves."
    },
    {
      "verse": "6",
      "text": "Soldiers will use their swords to kill people in the small towns on the coast near Tyre. Then people will know that I am the Lord."
    },
    {
      "verse": "7",
      "text": "This is what the Almighty Lord says: Listen! I will bring King Nebuchadnezzar of Babylon to attack Tyre from the north. He is a powerful king. He will bring his great army with soldiers on horses and chariots."
    },
    {
      "verse": "8",
      "text": "His soldiers will destroy your towns and villages on the coast. They will build heaps of earth around your walls. They will hold up their shields like a wall as they attack you."
    },
    {
      "verse": "9",
      "text": "They will use heavy pieces of wood to knock down the city's walls. They will use their weapons to knock down the strong towers."
    },
    {
      "verse": "10",
      "text": "King Nebuchadnezzar's army will have many horses. As they attack you, the dirt from their feet will cover you. The noise of the riders on the horses and the chariots' wheels will cause the city's walls to shake. They will break through the city's gates and walls."
    },
    {
      "verse": "11",
      "text": "The horses will run along all the streets. The soldiers will kill your people with their swords. The strong pillars of your buildings will fall to the ground."
    },
    {
      "verse": "12",
      "text": "The soldiers will take your riches and valuable things for themselves. They will break down your walls. They will destroy your beautiful homes. They will throw into the sea all the wood and stones that remain from your buildings."
    },
    {
      "verse": "13",
      "text": "I will stop the noise of your songs. Nobody will hear the sound of your harps any longer."
    },
    {
      "verse": "14",
      "text": "Tyre will be a rock in the sea with no buildings on it. Men will dry their nets on it. Nobody will never build the city again. That is what I, the Almighty Lord, have said. So it will certainly happen!"
    },
    {
      "verse": "15",
      "text": "This is what the Almighty Lord says to Tyre: All the people who live on the coast of the sea will hear the news. When they know that you have fallen to the ground, they will shake with fear. They will hear the loud cries of your people when they die in the battle. “City that was famous for your great sailors, now your power has gone! In the past, you made many people afraid, as your brave men travelled across the sea."
    },
    {
      "verse": "16",
      "text": "Then the rulers of the towns on the coast of the sea will be very sad. They will no longer sit on their thrones. They will remove their beautiful royal clothes. They will sit on the ground as they shake with fear. They will not stop shaking when they hear what has happened to you."
    },
    {
      "verse": "17",
      "text": "Then they will sing this funeral song about you:“City that was famous for your great sailors, now your power has gone! In the past, you made many people afraid, as your brave men travelled across the sea."
    },
    {
      "verse": "18",
      "text": "Now you have fallen to the groundand people who live on the coast shake with fear. Now your power has goneand those people are very afraid. ” and people who live on the coast shake with fear. Now your power has gone and those people are very afraid. ”"
    },
    {
      "verse": "19",
      "text": "This is what the Almighty Lord says: I will make you an empty place, like cities where nobody lives. The great waves of the sea will completely cover you."
    },
    {
      "verse": "20",
      "text": "Then I will cause you to you to fall deep down into the earth. You will be part of the world of dead people who lived a long time ago. You will join other cities that became heaps of stones long ago. You will remain there. You will never again be a city in the world where people are alive."
    },
    {
      "verse": "21",
      "text": "I will cause terrible things to happen to you. You will come to a complete end. People will look for you, but they will never find you. That is what the Almighty Lord says. ’"
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me: “Tyre, you say that you are completely beautiful."
    },
    {
      "verse": "2",
      "text": "‘Son of man, sing a funeral song about Tyre."
    },
    {
      "verse": "3",
      "text": "Tyre is a city on the coast of the sea. From there, traders go across the sea to sell things to people in many other countries. This is what the Almighty Lord says to Tyre:“Tyre, you say that you are completely beautiful."
    },
    {
      "verse": "4",
      "text": "Your borders reached into the middle of the sea. Your builders made you like a great ship. Your builders made you like a great ship."
    },
    {
      "verse": "5",
      "text": "They used wood from the pine trees of Senir. They used a cedar tree from Lebanon to make your mast. They used a cedar tree from Lebanon to make your mast."
    },
    {
      "verse": "6",
      "text": "They used oak trees from Bashan to make your oars. They used pine wood from the coasts of Cyprus to make your deck. They made it beautiful with ivory. They used pine wood from the coasts of Cyprus to make your deck. They made it beautiful with ivory."
    },
    {
      "verse": "7",
      "text": "They used good linen from Egypt to make your sail. They made it pretty with many colours. The sail was like a flag that everyone could see. They made tents of cloth to cover your deck. It was blue and purple cloth that came from Cyprus island. They made it pretty with many colours. The sail was like a flag that everyone could see. They made tents of cloth to cover your deck. It was blue and purple cloth that came from Cyprus island."
    },
    {
      "verse": "8",
      "text": "Men from Sidon and Arvad used the oars to move the ship. Your own clever men from Tyre were your sailors. Your own clever men from Tyre were your sailors."
    },
    {
      "verse": "9",
      "text": "Leaders from Gebal went with you. They brought men who knew how to mend the ship. Sailors of ships from many countriescame to buy things from you. They brought men who knew how to mend the ship. Sailors of ships from many countries came to buy things from you."
    },
    {
      "verse": "10",
      "text": "There were brave soldiers from Persia, Lydia and Libya in your army. They hung their shields and their helmets on your walls. They caused people to give you honour. They hung their shields and their helmets on your walls. They caused people to give you honour."
    },
    {
      "verse": "11",
      "text": "Men from Arvad and Helech were guards who stood on your walls. Soldiers from Gammad were in your strong towers. They hung their weapons on your walls. They made you look very beautiful. Soldiers from Gammad were in your strong towers. They hung their weapons on your walls. They made you look very beautiful."
    },
    {
      "verse": "12",
      "text": "You had many valuable things to sell. So traders came from Tarshish to buy things from you. They brought silver and other good metals to pay for those things."
    },
    {
      "verse": "13",
      "text": "Traders from Greece, Tubal and Meshech also came to buy things from you. They paid you with slaves and with things made of bronze."
    },
    {
      "verse": "14",
      "text": "Men from Beth Togarmah came. They paid you with horses to use in war or for work, and also with mules."
    },
    {
      "verse": "15",
      "text": "Traders came to you from Rhodes and from other countries beside the sea. They paid you with ivory and with ebony wood."
    },
    {
      "verse": "16",
      "text": "Because you had so many things to sell, traders came to you from Syria. They paid you with different jewels, with valuable purple cloth, with other beautiful cloth and with good linen."
    },
    {
      "verse": "17",
      "text": "Traders came to you from Judah and Israel. They paid you with wheat from Minnith, with figs, with honey, with olive oil and with medicine."
    },
    {
      "verse": "18",
      "text": "Traders from Damascus came to you because you had many valuable things to sell. They sold you wine from Helbon and white wool from Zahar."
    },
    {
      "verse": "19",
      "text": "Greek men from Uzal came to buy your things. They paid you with iron and different spices."
    },
    {
      "verse": "20",
      "text": "Traders from Dedan sold you blankets for your horses."
    },
    {
      "verse": "21",
      "text": "Men from Arabia and the rulers of Kedar came to buy your things. They brought lambs, male sheep and goats to sell to you."
    },
    {
      "verse": "22",
      "text": "Traders from Sheba and Raamah came to buy things from you. They brought the best kinds of spices, jewels and gold to sell to you."
    },
    {
      "verse": "23",
      "text": "Traders came to you from Haran, Canneh and Eden, as well as from Sheba, Asshur and Kilmad. You, Tyre, were like a great ship in the middle of the sea. You were full with a heavy load of many things."
    },
    {
      "verse": "24",
      "text": "They brought beautiful clothes made with expensive cloth. They also brought carpets that were made with threads of many different colours. And they brought strong ropes. They brought these things to sell in your markets."
    },
    {
      "verse": "25",
      "text": "Big ships from Tarshish carried your valuable things across the sea. You, Tyre, were like a great ship in the middle of the sea. You were full with a heavy load of many things."
    },
    {
      "verse": "26",
      "text": "Your sailors took you into the great waves of the sea. There, a strong east wind has caused you to break into small pieces. There, a strong east wind has caused you to break into small pieces."
    },
    {
      "verse": "27",
      "text": "All your valuable things and your riches will fall into the deep sea. All your sailors, your captains, your traders and your soldierswill also fall into the sea. Yes, everyone in you will drown in the seaon that day when you break into pieces. All your sailors, your captains, your traders and your soldiers will also fall into the sea. Yes, everyone in you will drown in the sea on that day when you break into pieces."
    },
    {
      "verse": "28",
      "text": "When your sailors call out for help, the cities on the coast of the sea will shake. the cities on the coast of the sea will shake."
    },
    {
      "verse": "29",
      "text": "All the sailors of other ships will leave their ships. The sailors and their captains will stand on the shore of the sea. The sailors and their captains will stand on the shore of the sea."
    },
    {
      "verse": "30",
      "text": "They will weep loudly because they are very upset about you. They will throw dirt on their heads. They will lie down in ashes. They will throw dirt on their heads. They will lie down in ashes."
    },
    {
      "verse": "31",
      "text": "They will cut all the hair off their heads. They will wear sackcloth. They will weep and be very upsetbecause of the terrible thing that has happened to you. They will wear sackcloth. They will weep and be very upset because of the terrible thing that has happened to you."
    },
    {
      "verse": "32",
      "text": "As they weep, they will sing this funeral song about you:‘Tyre was the greatest city. But now it lies at the bottom of the seaand nobody knows that it is there. ’ ‘Tyre was the greatest city. But now it lies at the bottom of the sea and nobody knows that it is there. ’"
    },
    {
      "verse": "33",
      "text": "Your valuable things went to many peoplein nations across the sea. People were happy with the things that they received from you. Even kings in far places became rich because of you. in nations across the sea. People were happy with the things that they received from you. Even kings in far places became rich because of you."
    },
    {
      "verse": "34",
      "text": "Now the sea has broken you into pieces. You have fallen to the bottom of the deep sea. All your valuable things and the people who worked in youlie at the bottom of the sea. You have fallen to the bottom of the deep sea. All your valuable things and the people who worked in you lie at the bottom of the sea."
    },
    {
      "verse": "35",
      "text": "The people who live on the coast of the sea are afraid, because of what has happened to you. Their kings shake with fear. Their faces look very sad. because of what has happened to you. Their kings shake with fear. Their faces look very sad."
    },
    {
      "verse": "36",
      "text": "Traders from other nations keep away from you. A terrible thing has happened to you. It will be the end of you for ever. ” ’"
    }
  ],
  "28": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me: You are a very proud man. You say, ‘I am a god and Tyre is my throne. I rule over all the seas around me. ’ But, whatever you think, you are only a man. You are not a god."
    },
    {
      "verse": "2",
      "text": "‘Son of man, say this to the ruler of Tyre. “This is what the Almighty Lord says: You are a very proud man. You say, ‘I am a god and Tyre is my throne. I rule over all the seas around me. ’But, whatever you think, you are only a man. You are not a god."
    },
    {
      "verse": "3",
      "text": "You think that you are wiser than Daniel, and that you know all secrets. and that you know all secrets."
    },
    {
      "verse": "4",
      "text": "You have been wise and clever enough to make yourself rich. You have stored much gold and silver in your palace. You have stored much gold and silver in your palace."
    },
    {
      "verse": "5",
      "text": "Because you are a clever trader, you have become even richer. And because of your riches, you have become very proud. you have become even richer. And because of your riches, you have become very proud."
    },
    {
      "verse": "6",
      "text": "So this is what the Almighty Lord says: You think that you are as wise as a god. You think that you are as wise as a god."
    },
    {
      "verse": "7",
      "text": "So listen! I will bring a foreign army to attack you. They will be a very cruel enemy. They will use their swords to destroy your beautiful city. They will spoil the beautiful things that you have used your wisdom to get for yourselves. They will be a very cruel enemy. They will use their swords to destroy your beautiful city. They will spoil the beautiful things that you have used your wisdom to get for yourselves."
    },
    {
      "verse": "8",
      "text": "They will kill you violently in battle, and the sea will become your grave. and the sea will become your grave."
    },
    {
      "verse": "9",
      "text": "When your enemies attack you, you will no longer say, ‘I am a god. ’When they are ready to kill you, you will know that you are only human. you will no longer say, ‘I am a god. ’ When they are ready to kill you, you will know that you are only human."
    },
    {
      "verse": "10",
      "text": "Foreign people will kill you. You will die like people who do not belong to me. I, the Almighty Lord have said this. ” ’ You will die like people who do not belong to me. I, the Almighty Lord have said this. ” ’"
    },
    {
      "verse": "11",
      "text": "The Lord gave this message to me: At one time, you were the example of a good man. You were completely wise and beautiful."
    },
    {
      "verse": "12",
      "text": "‘Son of man, sing this funeral song about the king of Tyre. Tell him, “This is what the Almighty Lord says: At one time, you were the example of a good man. You were completely wise and beautiful."
    },
    {
      "verse": "13",
      "text": "You lived in God's beautiful garden, Eden. You wore valuable jewels on your clothes. The jewels were ruby, topaz, emerald, chrysolite, onyx, jasper, sapphire, turquoise and beryl. They were fixed to pieces of gold. They were ready for you to wear on the day that you were born. You wore valuable jewels on your clothes. The jewels were ruby, topaz, emerald, chrysolite, onyx, jasper, sapphire, turquoise and beryl. They were fixed to pieces of gold. They were ready for you to wear on the day that you were born."
    },
    {
      "verse": "14",
      "text": "I put you there with a cherub to be your guard. You lived on my holy mountain. You walked among the stones that burned with fire. You lived on my holy mountain. You walked among the stones that burned with fire."
    },
    {
      "verse": "15",
      "text": "Everything that you did was completely goodfrom the day that you were born. But later, you started to do wicked things. from the day that you were born. But later, you started to do wicked things."
    },
    {
      "verse": "16",
      "text": "As a trader, you bought and sold many things. As a result, you became violent and you did evil things. So I sent you away in shame. I would not allow you to remain on my mountain. The cherub that had been your guard chased you out. You could no longer walk among the stones that burned with fire. As a result, you became violent and you did evil things. So I sent you away in shame. I would not allow you to remain on my mountain. The cherub that had been your guard chased you out. You could no longer walk among the stones that burned with fire."
    },
    {
      "verse": "17",
      "text": "But because you were so beautiful, you were very proud. You used your wisdom to do bad things, because you loved to have beautiful things. So I threw you down to the ground. I let other kings see what had happened to you. You used your wisdom to do bad things, because you loved to have beautiful things. So I threw you down to the ground. I let other kings see what had happened to you."
    },
    {
      "verse": "18",
      "text": "As a trader, you did many wrong things to cheat people. Your holy places became unclean. So I caused fire to completely destroy your city. Everyone could see that only ashes remained on the ground. Your holy places became unclean. So I caused fire to completely destroy your city. Everyone could see that only ashes remained on the ground."
    },
    {
      "verse": "19",
      "text": "All the people of other nations who knew you are very afraid. They have seen the terrible thing that has happened to you. You have come to a complete end and you will never return. ” ’ They have seen the terrible thing that has happened to you. You have come to a complete end and you will never return. ” ’"
    },
    {
      "verse": "20",
      "text": "The Lord gave this message to me: Listen! I have become your enemy, Sidon. I will show your people how great I am. Then they will know that I am the Lord. I will punish your people for their sins so that they know that I am a holy God."
    },
    {
      "verse": "21",
      "text": "‘Son of man, turn and look towards Sidon. Tell them my message to warn them."
    },
    {
      "verse": "22",
      "text": "Say, “This is what the Almighty Lord says: Listen! I have become your enemy, Sidon. I will show your people how great I am. Then they will know that I am the Lord. I will punish your people for their sinsso that they know that I am a holy God."
    },
    {
      "verse": "23",
      "text": "I will cause disease to kill people in the city. Enemies will attack from all around the city, and people will die in the streets. Then they will know that I am the Lord. Enemies will attack from all around the city, and people will die in the streets. Then they will know that I am the Lord."
    },
    {
      "verse": "24",
      "text": "Israel will no longer suffer because of the nations that are around them. Those nations will not be like sharp thorns that give the Israelites pain. They will not insult the Israelites any more. Then they will know that I am the Almighty Lord."
    },
    {
      "verse": "25",
      "text": "This is what the Almighty Lord says: I will bring Israel's people back from the countries where I sent them to live. Then all the nations will see that I am a holy God for my people. My people will live in their own land that I gave to my servant, Jacob."
    },
    {
      "verse": "26",
      "text": "They will live there safely. They will build houses and they will plant vineyards. I will punish all the nations around them who have insulted them. Then my people will live safely in their homes. And they will know that I am the Lord their God. ” ’"
    }
  ],
  "29": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me on the 12th day of the 10th month of the 10th year: Listen, Pharaoh, king of Egypt, I have become your enemy. You are like the great monster that lies in Egypt's streams. You say, ‘The Nile river belongs to me! I made it for myself. ’"
    },
    {
      "verse": "2",
      "text": "‘Son of man, turn and look towards Pharaoh, the king of Egypt. You must speak my message to warn him and all Egypt's people."
    },
    {
      "verse": "3",
      "text": "Tell them, “The Almighty Lord says this: Listen, Pharaoh, king of Egypt, I have become your enemy. You are like the great monster that lies in Egypt's streams. You say, ‘The Nile river belongs to me! I made it for myself. ’"
    },
    {
      "verse": "4",
      "text": "But I will put hooks into your mouth and catch you. I will cause the fish in your streams to hang on your scales. I will pull you out from the streams with all those fish on you. I will cause the fish in your streams to hang on your scales. I will pull you out from the streams with all those fish on you."
    },
    {
      "verse": "5",
      "text": "I will leave you in the wilderness with all your fish. You will lie on the ground in the open fields. Nobody will pick you up or take care of you. I will give you to the wild animals and birds to be their food. You will lie on the ground in the open fields. Nobody will pick you up or take care of you. I will give you to the wild animals and birds to be their food."
    },
    {
      "verse": "6",
      "text": "Then all the people who live in Egypt will know that I am the Lord. Israel's people thought that you would help them. But you were only like a weak stick for them."
    },
    {
      "verse": "7",
      "text": "When they wanted you to hold them up, you broke into pieces. Your sharp pieces tore their shoulders. When they held on to you, you caused their legs to shake."
    },
    {
      "verse": "8",
      "text": "So this is what the Almighty Lord says: I will bring am army to attack you. I will use them to kill all your men and your animals."
    },
    {
      "verse": "9",
      "text": "The land of Egypt will become an empty place. Then they will know that I am the Lord. You said, ‘The Nile river belongs to me. I made it for myself. ’"
    },
    {
      "verse": "10",
      "text": "Because of that, I have become the enemy of you and your streams. I will destroy the land of Egypt. It will be an empty place, and its buildings will become heaps of stones. I will do that everywhere, from Migdol to Aswan and as far as Ethiopia's border."
    },
    {
      "verse": "11",
      "text": "No men or animals will walk through that land. Nobody will live there for 40 years."
    },
    {
      "verse": "12",
      "text": "Egypt will become like a desert among empty lands. Its cities will be empty for 40 years, among cities that have become heaps of stones. I will cause the Egyptians to go and live among other nations in places far away."
    },
    {
      "verse": "13",
      "text": "But this is what the Almighty Lord says: After 40 years, I will bring the Egyptians back from the places where I sent them."
    },
    {
      "verse": "14",
      "text": "I will bring them back home to live in peace. I will bring them to Pathros, the land of their ancestors. There they will be a weak kingdom."
    },
    {
      "verse": "15",
      "text": "Egypt will be the least important of all kingdoms. It will never again have power over other nations. I will make it too weak to rule over other nations."
    },
    {
      "verse": "16",
      "text": "Israel will never again hope that Egypt has the power to help them. Instead, Egypt will cause Israel's people to remember their sin. Their sin was to ask Egypt for help. Then they will know that I am the Almighty Lord. ” ’"
    },
    {
      "verse": "17",
      "text": "The Lord gave this message to me on the first day of the first month of the 27th year:"
    },
    {
      "verse": "18",
      "text": "‘Son of man, King Nebuchadnezzar of Babylon attacked the city of Tyre with his army. His soldiers had to work very hard. They carried heavy loads so that it hurt their heads and their shoulders. They had a lot of pain. But they did not get anything valuable from Tyre, even though they worked so hard."
    },
    {
      "verse": "19",
      "text": "So this is what the Almighty Lord says: Listen! I will give the land of Egypt to King Nebuchadnezzar of Babylon. He will take away all its riches and its valuable things. He will take all those things to pay the soldiers of his army."
    },
    {
      "verse": "20",
      "text": "I will give Egypt to him to pay him for his work. When his army attacked Tyre, they did that work for me. That is what the Almighty Lord says."
    },
    {
      "verse": "21",
      "text": "At that time, I will make Israel a powerful nation again. Then I will give you a message to speak to them, Ezekiel. They will listen to what you say. Then they will know that I am the Lord. ’"
    }
  ],
  "30": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me: Weep and cry aloud, ‘Help! The day of great trouble is coming! ’"
    },
    {
      "verse": "2",
      "text": "‘Son of man, prophesy to the people. Say to them, “This is what the Almighty Lord says: Weep and cry aloud, ‘Help! The day of great trouble is coming! ’"
    },
    {
      "verse": "3",
      "text": "Yes, that day will be very soon. It is the day of the Lord. It will be a day of dark clouds, when the Lord will punish the nations. It will be a day of dark clouds, when the Lord will punish the nations."
    },
    {
      "verse": "4",
      "text": "An enemy army will attack Egypt. The people of Ethiopia will be afraid. Many people in Egypt will die in the battle. Enemies will carry away Egypt's riches. They will knock down Egypt's buildings. The people of Ethiopia will be afraid. Many people in Egypt will die in the battle. Enemies will carry away Egypt's riches. They will knock down Egypt's buildings."
    },
    {
      "verse": "5",
      "text": "Soldiers from other nations will also die in the battle. They are soldiers from Ethiopia, Put, Lydia, Libya, and Arabia, as well as men who belong to my own people. They are soldiers from Ethiopia, Put, Lydia, Libya, and Arabia, as well as men who belong to my own people."
    },
    {
      "verse": "6",
      "text": "This is what the Lord says: All the people who help Egypt will die in the battle. Egypt will no longer be proud of her great power. Egypt's soldiers will die everywhere, from Migdol to Aswan. That is what the Almighty Lord says. All the people who help Egypt will die in the battle. Egypt will no longer be proud of her great power. Egypt's soldiers will die everywhere, from Migdol to Aswan. That is what the Almighty Lord says."
    },
    {
      "verse": "7",
      "text": "Egypt will become like a desert among other deserts. Its cities will become heaps of stones. Its cities will become heaps of stones."
    },
    {
      "verse": "8",
      "text": "I will burn Egypt with fire. I will destroy all those who fight to help Egypt. Then they will know that I am the Lord. I will destroy all those who fight to help Egypt. Then they will know that I am the Lord."
    },
    {
      "verse": "9",
      "text": "At that time, I will send messengers in ships to Ethiopia. I will stop the Ethiopian people being proud of their power. Instead, the news about Egypt's trouble will make them very afraid. That day is coming soon! Be careful!"
    },
    {
      "verse": "10",
      "text": "This is what the Almighty Lord says: I will use King Nebuchadnezzar of Babylon to destroy Egypt's army. I will use King Nebuchadnezzar of Babylon to destroy Egypt's army."
    },
    {
      "verse": "11",
      "text": "The king and his army will come to destroy the land. They are a nation of cruel people. They will attack Egypt's people with their swords. They will fill the land with dead bodies. They are a nation of cruel people. They will attack Egypt's people with their swords. They will fill the land with dead bodies."
    },
    {
      "verse": "12",
      "text": "I will cause the Nile river to become dry. I will put the land under the power of evil men. Foreigners will destroy the land of Egyptand everything that is in it. That is what I, the Lord, say. I will put the land under the power of evil men. Foreigners will destroy the land of Egypt and everything that is in it. That is what I, the Lord, say."
    },
    {
      "verse": "13",
      "text": "The Almighty Lord says this: I will destroy Egypt's idols and the false gods in Memphis. Egypt will no longer have its own ruler. I will cause Egypt's people to be very afraid. I will destroy Egypt's idols and the false gods in Memphis. Egypt will no longer have its own ruler. I will cause Egypt's people to be very afraid."
    },
    {
      "verse": "14",
      "text": "I will make Pathros a desert. I will burn Zoan with fire. I will punish the city of Thebes. I will burn Zoan with fire. I will punish the city of Thebes."
    },
    {
      "verse": "15",
      "text": "I will punish Egypt's strong city of Pelusium. I will show the people there that I am very angry. I will destroy all the soldiers in Thebes. I will show the people there that I am very angry. I will destroy all the soldiers in Thebes."
    },
    {
      "verse": "16",
      "text": "Yes, I will destroy all of Egypt with fire! The people of Pelusium will suffer with great pain. Enemies will knock down the walls of Thebes. The people of Memphis will live in fear every day. The people of Pelusium will suffer with great pain. Enemies will knock down the walls of Thebes. The people of Memphis will live in fear every day."
    },
    {
      "verse": "17",
      "text": "The young men of Heliopolis and Bubastis will die in the war. Enemies will take the other people from those cities as their prisoners. Enemies will take the other people from those cities as their prisoners."
    },
    {
      "verse": "18",
      "text": "It will be a very dark day in Tahpanheswhen I destroy Egypt's strength. Egypt will not be proud of her great power any more. A dark cloud will cover the land. Enemies will take away the people from Egypt's villages as prisoners. when I destroy Egypt's strength. Egypt will not be proud of her great power any more. A dark cloud will cover the land. Enemies will take away the people from Egypt's villages as prisoners."
    },
    {
      "verse": "19",
      "text": "That is how I will punish Egypt. Then they will know that I am the Lord. ” ’ Then they will know that I am the Lord. ” ’"
    },
    {
      "verse": "20",
      "text": "The Lord gave this message to me on the 7th day of the first month, in the 11th year:"
    },
    {
      "verse": "21",
      "text": "‘Son of man, I have removed the strength of Pharaoh, king of Egypt. It is as if I have broken his arm and nobody has helped it to mend. He will never again have the power to fight battles."
    },
    {
      "verse": "22",
      "text": "So this is what the Almighty Lord says: Listen! I have become the enemy of Pharaoh, king of Egypt. I will make him like a man with two broken arms. I will break his strong arm and his broken arm. He will not be able to fight at all!"
    },
    {
      "verse": "23",
      "text": "I will cause the Egyptian people to run away to live in foreign countries."
    },
    {
      "verse": "24",
      "text": "I will make the king of Babylon powerful, to fight battles on my behalf. But I will cause Pharaoh to be weak. He will cry in pain when the king of Babylon attacks. He will receive wounds that cause him to die."
    },
    {
      "verse": "25",
      "text": "Yes, I will make the king of Babylon strong. But Pharaoh, king of Egypt, will become weak. I will give the king of Babylon power to fight on my behalf. He will use that power to attack Egypt. Then they will know that I am the Lord."
    },
    {
      "verse": "26",
      "text": "I will send the Egyptian people away to many different countries. They will live among other nations. Then they will know that I am the Lord. ’"
    }
  ],
  "31": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me on the first day of the 3rd month, in the 11th year: “You think that you are as powerful as any other country!"
    },
    {
      "verse": "2",
      "text": "‘Son of man, say this to Pharaoh, king of Egypt, and all his people:“You think that you are as powerful as any other country!"
    },
    {
      "verse": "3",
      "text": "Think about how powerful Assyria was. At one time, it was as strong as a great cedar tree in Lebanon. It had beautiful branches that gave shade in the forest. It was very tall. Its top reached up to the clouds. At one time, it was as strong as a great cedar tree in Lebanon. It had beautiful branches that gave shade in the forest. It was very tall. Its top reached up to the clouds."
    },
    {
      "verse": "4",
      "text": "Springs of water from under the ground helped it to grow very tall. Rivers passed around the place where the tree was. Streams from there gave water to all the trees in the forest. Rivers passed around the place where the tree was. Streams from there gave water to all the trees in the forest."
    },
    {
      "verse": "5",
      "text": "So this cedar tree grew taller than all the other trees. Its branches became large and very long. It grew very well because it had plenty of water. Its branches became large and very long. It grew very well because it had plenty of water."
    },
    {
      "verse": "6",
      "text": "All kinds of birds built their nests among its leaves. Under its branches, the wild animals gave birth. All the great nations lived in its shade. Under its branches, the wild animals gave birth. All the great nations lived in its shade."
    },
    {
      "verse": "7",
      "text": "It was great and beautiful, with long branches. Its roots went down deep into the groundand they drank plenty of water. Its roots went down deep into the ground and they drank plenty of water."
    },
    {
      "verse": "8",
      "text": "The cedar trees in God's garden were not as beautiful. The branches of the pine trees were not as strong. No other tree in God's garden was nearly as great or as beautiful. The branches of the pine trees were not as strong. No other tree in God's garden was nearly as great or as beautiful."
    },
    {
      "verse": "9",
      "text": "I made that tree beautiful, with all its strong branches. All the trees in Eden, God's garden, were jealous of that tree. All the trees in Eden, God's garden, were jealous of that tree."
    },
    {
      "verse": "10",
      "text": "So this is what the Almighty Lord says: That great tree, Assyria, was very tall. Its top reached up to the clouds. It was very proud because it was so great."
    },
    {
      "verse": "11",
      "text": "Because of that, I put it under the power of the ruler of the nations. He has punished it as it deserved for its sins. In that way, I have removed it."
    },
    {
      "verse": "12",
      "text": "Foreigners from cruel nations have cut it down. They have left it on the ground. Its broken branches lie on the mountains and in the valleys. The people of other nations no longer live in its shade. They have gone away."
    },
    {
      "verse": "13",
      "text": "Now the birds go and sit on the bits of the tree that remain. The wild animals walk over its branches."
    },
    {
      "verse": "14",
      "text": "Because of that, no tree will ever grow as tall again. Even if it receives plenty of water, no tree will grow so tall that its top reaches up to the clouds. All trees will die and fall to the ground. Like people, they must die and go into their graves, under the ground."
    },
    {
      "verse": "15",
      "text": "This is what the Almighty Lord says: This tree has died and it has gone down into its grave. When that happened, I caused people to be very sad. I caused the springs of water to stop. There were no longer streams with plenty of water. I caused the mountains of Lebanon to become dark. All the trees in the forest became dry."
    },
    {
      "verse": "16",
      "text": "The other nations shook when they heard that great tree fall. I had caused it to go down into its grave, deep under the ground, as all people must die. The other strong trees saw what had happened to the great cedar tree. They were the trees of Eden and the best trees of Lebanon that had received plenty of water. They were pleased to see that the great cedar tree had fallen down."
    },
    {
      "verse": "17",
      "text": "The trees that had lived in the great tree's shade also fell and went into their graves. Those are the nations that had helped the great tree to fight its battles. They went to join other soldiers who had died in war."
    },
    {
      "verse": "18",
      "text": "Yes, Egypt is very strong, like the great trees of Eden. You are as great and powerful as any nation. But you will fall to the ground and go into your grave. It happened to Assyria and the other nations, and it will happen to you. You will lie under the ground among people who do not belong to me and who have died in war. This is a picture of what will happen to Pharaoh and all his people. That is what the Almighty Lord says. ” ’"
    }
  ],
  "32": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me on the first day of the 12th month, in the 12th year: “You have shown your power among the nations, like a strong lion. But really you are a monster who lives in the sea. You live in the rivers of your country. You beat the water with your feet. The water of your streams becomes dirty."
    },
    {
      "verse": "2",
      "text": "‘Son of man, sing a funeral song about Pharaoh, king of Egypt. Say this to him:“You have shown your power among the nations, like a strong lion. But really you are a monster who lives in the sea. You live in the rivers of your country. You beat the water with your feet. The water of your streams becomes dirty."
    },
    {
      "verse": "3",
      "text": "This is what the Almighty Lord says: I will bring a big crowd of people togetherto catch you in my net. They will use my net to pull you out of the water. I will bring a big crowd of people together to catch you in my net. They will use my net to pull you out of the water."
    },
    {
      "verse": "4",
      "text": "I will throw you onto dry groundand I will leave you there. I will bring the birds to fly down from the skyand sit on you. I will bring the wild animals to feed themselves on you, and eat as much as they want. and I will leave you there. I will bring the birds to fly down from the sky and sit on you. I will bring the wild animals to feed themselves on you, and eat as much as they want."
    },
    {
      "verse": "5",
      "text": "I will put the meat of your body on the mountains. Your bones will fill the valleys. Your bones will fill the valleys."
    },
    {
      "verse": "6",
      "text": "I will make the ground wet with your blood. It will pour out of you, up to the mountains. And it will fill the deep valleys. It will pour out of you, up to the mountains. And it will fill the deep valleys."
    },
    {
      "verse": "7",
      "text": "When I completely destroy you, I will cover the sky and make the stars become dark. I will cover the sun with a cloud. The moon will no longer give any light. I will cover the sky and make the stars become dark. I will cover the sun with a cloud. The moon will no longer give any light."
    },
    {
      "verse": "8",
      "text": "I will make the sky over you become dark, with no lights in it. Your whole country will become dark. That is what the Almighty Lord says. with no lights in it. Your whole country will become dark. That is what the Almighty Lord says."
    },
    {
      "verse": "9",
      "text": "When many other nations know that I have destroyed you, they will be afraid. Foreign nations that you do not know will be very upset. they will be afraid. Foreign nations that you do not know will be very upset."
    },
    {
      "verse": "10",
      "text": "The people of many countries will be afraidwhen they see what I have done to you. Their kings will shake with fear. When I wave my sword in front of them, they will not stop shaking! At the time that your life finishes, they will also fear death. when they see what I have done to you. Their kings will shake with fear. When I wave my sword in front of them, they will not stop shaking! At the time that your life finishes, they will also fear death."
    },
    {
      "verse": "11",
      "text": "This is what the Almighty Lord says: The king of Babylon will attack you with his army. The king of Babylon will attack you with his army."
    },
    {
      "verse": "12",
      "text": "His brave soldiers will fight against you. I will cause them to destroy your army. They are the most cruel of all the nations. They will stop Egypt's people being proud of their power. They will destroy all Egypt's armies. I will cause them to destroy your army. They are the most cruel of all the nations. They will stop Egypt's people being proud of their power. They will destroy all Egypt's armies."
    },
    {
      "verse": "13",
      "text": "I will destroy all Egypt's cows that live beside its great rivers. So no people or animals will walk in the water any more. They will not cause the water to become dirty. So no people or animals will walk in the water any more. They will not cause the water to become dirty."
    },
    {
      "verse": "14",
      "text": "Then I will cause the water in the rivers to be clean again. The water will move freely like olive oil. That is what the Almighty Lord says. The water will move freely like olive oil. That is what the Almighty Lord says."
    },
    {
      "verse": "15",
      "text": "I will cause Egypt to become an empty place. I will remove everything that grows on the land. I will kill all the people who live there. Then they will know that I am the Lord. ” I will remove everything that grows on the land. I will kill all the people who live there. Then they will know that I am the Lord. ”"
    },
    {
      "verse": "16",
      "text": "That is the funeral song that they will sing about Egypt. Women of many nations will sing it. They will sing it because of the death of Egypt and all her people. That is what the Almighty Lord says. ’"
    },
    {
      "verse": "17",
      "text": "In the 12th year, the Lord gave this message to me on the 15th day of the month:"
    },
    {
      "verse": "18",
      "text": "‘Son of man, weep for the many people of Egypt. Send them down to the place of dead people, deep under the ground. They will be there in their graves with the people of other powerful nations."
    },
    {
      "verse": "19",
      "text": "Say to them, “You think you are more beautiful than the people of other nations. But you too must go down to lie in your graves among those who do not belong to God. ”"
    },
    {
      "verse": "20",
      "text": "An enemy has come to attack Egypt! Many of its people will die among the soldiers who die in battle. The enemy will take many of Egypt's people away as their prisoners."
    },
    {
      "verse": "21",
      "text": "In the place of dead people, brave soldiers will welcome the people of Egypt and those who helped them. They will say, “They have come down to join us who do not belong to God. They have died in battle and now they lie in their graves. ”"
    },
    {
      "verse": "22",
      "text": "The people of Assyria and its whole army are there in their graves! All of them died in battle."
    },
    {
      "verse": "23",
      "text": "Their graves are in the deepest parts of the deep hole of death. Soldiers who fought with them lie all around. They were very cruel to people when they were alive. But they died in battle and now they lie in their graves."
    },
    {
      "verse": "24",
      "text": "The people of Elam and its whole army are also there! All of them died in battle too. They were cruel to many people when they were alive. Now they have gone down deep below the ground, as people who do not belong to God. They are ashamed to join with other people in the deep hole of death."
    },
    {
      "verse": "25",
      "text": "Elam lies there on a bed that people have prepared for her. All Elam's soldiers lie around its grave. None of them belongs to God and they have all died in battle. When they were alive, they made people very afraid. But now they are ashamed, as they lie in their graves among other dead people in the deep hole of death."
    },
    {
      "verse": "26",
      "text": "Meshech and Tubal are also there in their graves, with their soldiers all around. When they were alive, they made people very afraid. Now they have all died in battle and none of them belongs to God."
    },
    {
      "verse": "27",
      "text": "They do not lie with the brave dead soldiers of long ago. Those men went down into their graves with honour. People buried them with their weapons. They put their swords under their heads. When those brave men were alive, they caused people to be very afraid of them."
    },
    {
      "verse": "28",
      "text": "You too, Egypt, will lie in your grave among those who do not belong to God. You will lie beside other people who died in battle."
    },
    {
      "verse": "29",
      "text": "Edom is there, too, with its kings and leaders. They were powerful, but now they lie in their graves, among those who have died in battle. They have gone down into the deep hole of death with those who do not belong to God."
    },
    {
      "verse": "30",
      "text": "All the rulers of the north are there, as well as all the people of Sidon. They used their power to make people very afraid. But now they are ashamed, like other people who have gone down into the deep hole of death. They lie in their graves with those who have died in battle, and they do not belong to God."
    },
    {
      "verse": "31",
      "text": "The Almighty Lord says this: Pharaoh will not feel so sad when he sees all these other dead people in their graves. He and his whole army will know that they are not the only people to have died in battle."
    },
    {
      "verse": "32",
      "text": "When he was alive, I caused him to make people very afraid. But Pharaoh and all his great army will lie in their graves among other people who died in battle. They will lie with people who do not belong to God. That is what I, the Almighty Lord, have said. ’"
    }
  ],
  "33": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, speak to your people. Say to them, “Think about what might happen if I send an army to attack a country. The people of that country might choose one of their own men to be a guard to warn them about danger."
    },
    {
      "verse": "3",
      "text": "Then, if the guard sees that enemy soldiers are ready to attack, he must blow a trumpet to warn his people."
    },
    {
      "verse": "4",
      "text": "Someone might hear the sound of the trumpet, but he does nothing to keep himself safe. If enemy soldiers then come and kill that person, he is guilty of his own death."
    },
    {
      "verse": "5",
      "text": "He deserves to die because he heard the sound of the trumpet, but he did nothing. When the trumpet warned him of danger, he should have got ready. If he had done that, he would have saved his life."
    },
    {
      "verse": "6",
      "text": "But the guard might not blow the trumpet when he sees the enemy. He might not warn his people that the enemy is ready to attack them. Then enemy soldiers might kill some of his people. Those people will die because of their sins. But the guard will be guilty of their death, because he did not warn them of danger. ”"
    },
    {
      "verse": "7",
      "text": "Son of man, I have chosen you to be a guard for Israel's people. You must listen to the messages that I give you. Then you must use what I say to warn the Israelites."
    },
    {
      "verse": "8",
      "text": "I might say to a wicked person, “You will certainly die because of your sins. ” Then you must warn that wicked person to stop doing wicked things. If you do not warn him, he will die because of his sins. But I will say that you are guilty of his death."
    },
    {
      "verse": "9",
      "text": "If you do warn him and he refuses to change, he will die because of his sins. But you will have saved your own life."
    },
    {
      "verse": "10",
      "text": "Son of man, give Israel's people this message: “You are saying, ‘The punishment for our sins is too much for us. We are dying because of all the bad things that we have done. What should we do so that we can continue to live? ’ ”"
    },
    {
      "verse": "11",
      "text": "Tell them, “It does not make me happy to punish wicked people with death. I, the Almighty Lord, promise you this, as surely as I live. I want wicked people to stop doing wrong things so that they may continue to live. So stop doing evil things! Israel's people, you do not have to die. Turn back to me! ”"
    },
    {
      "verse": "12",
      "text": "Son of man, you must say to your people, “If a righteous person refuses to obey me, I will punish him. The good things that he has done will not save him. And if a wicked person stops doing bad things, he will no longer be guilty. Righteous people will not continue to live if they start to do bad things. ”"
    },
    {
      "verse": "13",
      "text": "I may say to righteous people that they will certainly continue to live. But then they may trust in the good things that they have done. They may think that I will not punish them if they start to do evil things. But if they do that, I will destroy them because of their sins. I will not even think about the good things that they did at an earlier time."
    },
    {
      "verse": "14",
      "text": "Also, I may say to wicked people, “You will certainly die because of your sins. ” But then they may stop doing bad things. They may start to do things that are good and right."
    },
    {
      "verse": "15",
      "text": "For example, a wicked person might give back something that he has taken from someone as a guarantee. Or he might give back things that he has robbed from people. A wicked person might start to obey the laws that give life. He might stop doing evil things. If wicked people change like that, then they will continue to live. They will not die as punishment for their sins."
    },
    {
      "verse": "16",
      "text": "I will not think about the sins that they have done. Now that they have started to do things that are good and right, they will certainly continue to live."
    },
    {
      "verse": "17",
      "text": "Your people, the Israelites, are saying: “The Lord is not fair in the things that he does! ” But it is the people themselves who live in a way that is not fair."
    },
    {
      "verse": "18",
      "text": "If a righteous person stops doing good things and he starts to do evil things, he will die. He deserves to die because of his sins."
    },
    {
      "verse": "19",
      "text": "Also, if a wicked person stops doing bad things and he starts to do things that are good and right, he will continue to live. He deserves to live because he has changed."
    },
    {
      "verse": "20",
      "text": "But you Israelites continue to say, “The Lord is not fair! ” But I will judge each of you in a way that you deserve for the things that you have done. ’"
    },
    {
      "verse": "21",
      "text": "years after we had come to Babylon as prisoners. It was on the 5th day of the 10th month of that year. A man who had escaped from Jerusalem came to me in Babylon. He said, ‘Enemies have taken Jerusalem for themselves. ’"
    },
    {
      "verse": "22",
      "text": "Before that man arrived, the Lord had taken hold of me in the night. He had opened my mouth so that I was able to speak again."
    },
    {
      "verse": "23",
      "text": "Then the Lord gave this message to me:"
    },
    {
      "verse": "24",
      "text": "‘Son of man, there are people who continue to live in the places in Israel that have become heaps of stones. Those Israelites are saying, “Abraham was only one man, but God gave him the whole land of Israel. We are many people. So we can be sure that the land now belongs to us. ”"
    },
    {
      "verse": "25",
      "text": "Because they say that, you must tell them, “This is what the Almighty Lord says: You eat meat which still has blood in it. You worship your idols. You also murder people. So you do not deserve to have the land for yourselves."
    },
    {
      "verse": "26",
      "text": "You use violence to get the things that you want. You do disgusting things. You have sex with other men's wives. So you should certainly not have the land! ”"
    },
    {
      "verse": "27",
      "text": "Say to them, “This is what the Almighty Lord says: I promise you this, as surely as I live. Soldiers will kill the people who live among the heaps of stones. I will cause wild animals to eat the people who live in the fields. Diseases will kill the people who hide in strong buildings and in caves."
    },
    {
      "verse": "28",
      "text": "I will make the land become empty, like a desert. You will no longer be proud of your power. Israel's mountains will become empty places that nobody travels through."
    },
    {
      "verse": "29",
      "text": "I will cause the land to become heaps of stones where nobody lives. I will do that to punish the people for the disgusting things that they have done. Then they will know that I am the Lord. ”"
    },
    {
      "verse": "30",
      "text": "Son of man, the Israelites who are here with you in Babylon are talking about you. They meet together near the walls of the city and at the doors of their houses. They are saying to each other, “Come and hear the message that has come from the Lord. ”"
    },
    {
      "verse": "31",
      "text": "They are my people and they come as a crowd to listen to you. They sit and they listen to your words. But they do not obey what you say. They say that they love me. But really they like to cheat people to get things for themselves."
    },
    {
      "verse": "32",
      "text": "They like to hear your voice. For them, you are like someone who sings beautiful songs about love. They listen to your words but they do not obey them."
    },
    {
      "verse": "33",
      "text": "All these things that I have said will certainly happen. When my people see them happen, they will know that a prophet has lived among them. ’"
    }
  ],
  "34": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, you must speak my message to the shepherds of Israel to warn them. Tell them, “This is what the Almighty Lord says: Terrible trouble will come to you shepherds of Israel who only think about yourselves. Shepherds should take care of the sheep and feed them."
    },
    {
      "verse": "3",
      "text": "You drink their milk and you use their wool to make clothes for yourselves. You kill the best animals to eat. But you do not take care of the sheep!"
    },
    {
      "verse": "4",
      "text": "You have not helped the weak sheep to be strong. You have not made the sick sheep well. Nor have you covered their wounds. You have not looked for lost sheep and brought them back. Instead, you have ruled my people in a cruel way."
    },
    {
      "verse": "5",
      "text": "So my sheep ran away to different places because they did not have a shepherd to take care of them. Then the wild animals found them and ate them."
    },
    {
      "verse": "6",
      "text": "My sheep went over all the mountains and the high hills. They went to places everywhere on the earth. And nobody went to look for them and bring them back again."
    },
    {
      "verse": "7",
      "text": "So, you shepherds, listen to the Lord's message."
    },
    {
      "verse": "8",
      "text": "My sheep do not have any shepherds to take care of them. So they are not safe from danger. They have become food for all the wild animals. You, my shepherds, have not gone to look for the sheep that were lost. You only wanted to help yourselves instead of my sheep. So I, the Almighty Lord, promise you this, as surely as I live."
    },
    {
      "verse": "9",
      "text": "You shepherds, listen to the Lord's message!"
    },
    {
      "verse": "10",
      "text": "The Almighty Lord says this: I have become the shepherds' enemy. I will take my sheep away from them. I will no longer allow them to be shepherds. They will not be able to kill my sheep to feed themselves. I will rescue my sheep, so that the shepherds cannot eat them."
    },
    {
      "verse": "11",
      "text": "So this is what the Almighty Lord says: I myself will go and look for my sheep to bring them back."
    },
    {
      "verse": "12",
      "text": "I will be like a shepherd who looks everywhere to find his lost sheep. I will find them and I will rescue them. I will bring them back from the places that they have run away to. It was a dark day with many clouds when they ran away."
    },
    {
      "verse": "13",
      "text": "They have been living in foreign countries among other people. I will bring them back to live in their own land. I will feed them on the mountains of Israel. They will eat beside its rivers and in all the places where people live."
    },
    {
      "verse": "14",
      "text": "I will feed them in fields on Israel's mountains where grass grows. They will lie down in the good fields. They will eat the green grass that grows on the mountains."
    },
    {
      "verse": "15",
      "text": "I myself will take care of my sheep. I will give them safe places to lie down and rest. I, the Almighty Lord, say this."
    },
    {
      "verse": "16",
      "text": "I will find the lost sheep and I will bring them back. I will cover their wounds. I will help those who are weak to become strong. But I will destroy those who are fat and powerful. I will give them justice as their food!"
    },
    {
      "verse": "17",
      "text": "This is what I, the Almighty Lord, say to you, my sheep: I will judge you. I will decide which of you are good and which of you are bad. I will judge between male sheep and goats."
    },
    {
      "verse": "18",
      "text": "You bad sheep make sure that you have plenty of good grass to eat. But then you spoil the other grass so that no other sheep can eat it. You have clean water to drink. But then you spoil the water which remains. It is too dirty for other sheep to drink."
    },
    {
      "verse": "19",
      "text": "Because of that, my sheep eat grass that you have spoiled. They drink water that you have made dirty with your feet."
    },
    {
      "verse": "20",
      "text": "So this is what I, the Almighty Lord, say to the sheep: I myself will judge between the fat sheep and the thin sheep."
    },
    {
      "verse": "21",
      "text": "You fat sheep use your shoulders to push the other sheep away. You attack the weak sheep with your horns so that they run away."
    },
    {
      "verse": "22",
      "text": "Because you do this, I will rescue my sheep. They will no longer be in danger from other animals. I will judge between one sheep and another sheep."
    },
    {
      "verse": "23",
      "text": "Then I will choose one shepherd to lead them. He is my servant, David. He will take care of them as their shepherd."
    },
    {
      "verse": "24",
      "text": "I, the Lord, will be their God. My servant David will be their ruler. I, the Lord, have said this."
    },
    {
      "verse": "25",
      "text": "I will make an agreement with them, that I will give them peace. I will remove the dangerous wild animals from the land. Then they can live there safely, even in the wilderness. They will not be afraid when they sleep in the forests."
    },
    {
      "verse": "26",
      "text": "I will bless them with many good things as they live around my holy hill. I will send rain at the proper time each year. The rain will bring my blessings to them."
    },
    {
      "verse": "27",
      "text": "The trees in the fields will give them fruit to eat. Crops of food will grow in the ground. The people will live safely in their land. I will take away the power of those who were cruel to them. I will rescue them from the people who made them their slaves. Then they will know that I am the Lord."
    },
    {
      "verse": "28",
      "text": "They will no longer be in danger from other nations. Wild animals will no longer eat them. They will live safely and nobody will cause them to be afraid."
    },
    {
      "verse": "29",
      "text": "I will give them a land that is famous for its good crops. So famine will never cause them to suffer in that land. Other nations will no longer insult them."
    },
    {
      "verse": "30",
      "text": "Then they will know that I, the Lord their God, am with them. They will know that they are my people, the Israelites. That is what the Almighty Lord says."
    },
    {
      "verse": "31",
      "text": "You are my people and I take care of you, as a shepherd takes care of his sheep. You are my people and I am your God. That is what the Almighty Lord says. ” ’"
    }
  ],
  "35": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, look towards Mount Seir. Then speak my message to warn it."
    },
    {
      "verse": "3",
      "text": "Say to it, “This is what the Almighty Lord says: Listen! I am your enemy, Mount Seir. I will attack you, so that you become like a desert."
    },
    {
      "verse": "4",
      "text": "I will destroy your towns. They will become heaps of stones where nobody lives. Then you will know that I am the Lord."
    },
    {
      "verse": "5",
      "text": "You have always hated Israel's people. Because of that, you did not help them when their enemy attacked them and killed them. They were in great trouble when I punished them for their sins."
    },
    {
      "verse": "6",
      "text": "So I, the Almighty Lord, promise you this, as surely as I live. I will allow your enemies to kill you. If you run away from them, they will chase you and kill you. You were happy to see an enemy kill my people, so an enemy will kill you also."
    },
    {
      "verse": "7",
      "text": "I will make Mount Seir become like a desert where nobody lives. I will destroy anyone who travels through that place."
    },
    {
      "verse": "8",
      "text": "Dead bodies will lie all over your mountains. The bodies of men who have died in battle will lie on your hills and in your valleys."
    },
    {
      "verse": "9",
      "text": "I will make you a desert for ever and nobody will live in your towns. Then you will know that I am the Lord."
    },
    {
      "verse": "10",
      "text": "You said, ‘We will take these two nations for ourselves. Israel and Judah will belong to us. ’ You said that when I, the Lord, was there with them."
    },
    {
      "verse": "11",
      "text": "So I promise that I will punish you, as surely as I live. That is what the Almighty Lord says. Because you were angry and jealous, you hated my people, So I will punish you as you deserve. When I judge you, my people will know who I am."
    },
    {
      "verse": "12",
      "text": "Then you will know that I, the Lord, have heard you. You have insulted the mountains of Israel. You said, ‘Those mountains have become a desert. So we can take them for ourselves. ’"
    },
    {
      "verse": "13",
      "text": "You said many proud things to insult me. You thought that you were greater than me. I heard everything that you said!"
    },
    {
      "verse": "14",
      "text": "So this is what the Almighty Lord says: I will make your land become a desert. All the people in the world will be very happy when they see this."
    },
    {
      "verse": "15",
      "text": "You were happy when you saw me punish Israel's people so that their land became a desert. Because you were happy, I will punish you as you deserve. Mount Seir and all the land of Edom will become an empty desert. Then Edom's people will know that I am the Lord. ” ’"
    }
  ],
  "36": [
    {
      "verse": "1",
      "text": "The Lord said, ‘Son of man, speak my message to the mountains of Israel. Say to them: “Listen to the Lord's message, you mountains of Israel."
    },
    {
      "verse": "2",
      "text": "This is what the Almighty Lord says: Your enemies have laughed at you. They have said, ‘The old mountains now belong to us! ’ ”"
    },
    {
      "verse": "3",
      "text": "So now prophesy to those mountains. Tell them, “This is what the Almighty Lord says: Your enemies attacked you from every side. They won against you, so that you belonged to other nations. People talked about you and they insulted you."
    },
    {
      "verse": "4",
      "text": "Because of this, mountains of Israel, listen to this message from me, the Almighty Lord. I say this to the hills, the mountains and the valleys. I say this to the empty places and the towns that have become heaps of stones where nobody lives. This has caused the nations around you to laugh at you and insult you."
    },
    {
      "verse": "5",
      "text": "So this is what the Almighty Lord says: I am very angry with those nations and I will punish them. I am even more angry with the people of Edom because they insulted my people. They were happy to take my land for themselves so that their animals could eat the grass. ”"
    },
    {
      "verse": "6",
      "text": "So prophesy to the hills and mountains of Israel, and to its valleys. Tell them, “This is what the Almighty Lord says: I am very angry because the nations around you have caused you to be ashamed."
    },
    {
      "verse": "7",
      "text": "So this is what I, the Almighty Lord, say: I make a strong promise that those nations will soon be ashamed themselves."
    },
    {
      "verse": "8",
      "text": "But I say this to you mountains of Israel. Trees will grow on you again and crops will provide much food for my people. My people will soon come home."
    },
    {
      "verse": "9",
      "text": "I am your friend and I will take care of you. Men will plough your ground and they will plant seeds in it."
    },
    {
      "verse": "10",
      "text": "I will cause more and more Israelite people to live on you, and in all the land. They will live in the towns and they will repair the broken buildings."
    },
    {
      "verse": "11",
      "text": "I will make more and more people and animals live on you. They will give birth to many young ones, so that they grow in number. I will cause many people to live on you, as they did a long time ago. I will help you with more good things than you had when you first became a land for my people. Then you will know that I am the Lord."
    },
    {
      "verse": "12",
      "text": "I will cause my people, the Israelites, to walk on you. You will belong to them as the place where they and their descendants live. You will never again cause their children to die."
    },
    {
      "verse": "13",
      "text": "This is what the Almighty Lord says: People are saying to you, Israel's land, ‘You destroy people. You take away the nation's children. ’"
    },
    {
      "verse": "14",
      "text": "So now I, the Almighty Lord, tell you this: You will no longer destroy people or take away the nation's children."
    },
    {
      "verse": "15",
      "text": "People from other nations will no longer insult you or laugh at you. You will no longer cause your nation to suffer. That is what the Almighty Lord says. ” ’"
    },
    {
      "verse": "16",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "17",
      "text": "‘Son of man, Israel's people made their own land unclean when they lived there. They lived in a bad way and they did bad things. It made them unclean, like a woman when she bleeds each month."
    },
    {
      "verse": "18",
      "text": "So I punished them with my great anger. I punished them because they murdered people on their land. And they made the land unclean with idols that they worshipped."
    },
    {
      "verse": "19",
      "text": "I sent them to live among people of other nations in foreign countries. I punished them as they deserved for the bad things that they did."
    },
    {
      "verse": "20",
      "text": "But among the nations where they went, they continued to bring shame to my holy name. People said, “These are the Lord's people, but they had to leave the land that he gave to them. ”"
    },
    {
      "verse": "21",
      "text": "I wanted them to give honour to my holy name. Instead, Israel's people brought me shame among the nations where they went."
    },
    {
      "verse": "22",
      "text": "So you must say to Israel's people, “This is what the Almighty Lord says: I will help you, Israel's people. But it is not because you deserve it. I will do it so that people give honour to my holy name. You brought me shame among the nations where you went."
    },
    {
      "verse": "23",
      "text": "Now I will show them that my name is great and holy. You brought shame to my name. But I will help you so that the nations can see that I am great. When I do that, they will know that I am the Lord. That is what I, the Almighty Lord, say."
    },
    {
      "verse": "24",
      "text": "I will take you out from the nations and all the foreign countries where you have been living. I will bring you back to your own land."
    },
    {
      "verse": "25",
      "text": "You will become pure, as if I splash you with clean water. I will remove all the things that make you unclean. I will take away the idols that you worship."
    },
    {
      "verse": "26",
      "text": "I will give you new thoughts. I will put a new spirit in you. You will no longer refuse to obey me. Instead, you will want to please me."
    },
    {
      "verse": "27",
      "text": "I will put my Spirit in you, so that you obey my commands. You will be careful to obey my laws."
    },
    {
      "verse": "28",
      "text": "At that time, you will live in the land that I gave to your ancestors. You will be my people and I will be your God."
    },
    {
      "verse": "29",
      "text": "I will save you from all the things that made you unclean. I will cause the land to give you plenty of grain to eat. You will no longer have any famines."
    },
    {
      "verse": "30",
      "text": "The trees will provide plenty of fruit. And crops will grow well in the fields. Other nations will no longer make you feel ashamed because you have no food to eat."
    },
    {
      "verse": "31",
      "text": "Then you will remember the evil way that you lived. You will remember the bad things that you did. You will be ashamed of yourselves because of the sins and the disgusting things that you did."
    },
    {
      "verse": "32",
      "text": "I want you to know that I am not doing this because you deserve it. You should be ashamed, Israel's people. You should feel sorry for the things that you have done. That is what the Almighty Lord says."
    },
    {
      "verse": "33",
      "text": "This is what the Almighty Lord says: At that time, I will make you clean from all your sins. When I do that, I will send you back to live in your towns. You will build your houses again that had become heaps of stones."
    },
    {
      "verse": "34",
      "text": "You will plough the empty land again to provide food. People who travel there will no longer think that the land is useless."
    },
    {
      "verse": "35",
      "text": "They will say, ‘This land was like a desert, but now it is like the Garden of Eden. People now live in the cities that had become heaps of stones. The cities now have strong walls. ’"
    },
    {
      "verse": "36",
      "text": "Then the nations that still live around you will see what has happened. They will know that I, the Lord, have mended the broken cities. They will know that I have planted crops again in the fields that were empty. I, the Lord, have said this, and I will do it! ”"
    },
    {
      "verse": "37",
      "text": "This is what the Almighty Lord says: I will listen to what Israel's people are asking me to do for them. I will allow them to grow in number, like a big crowd of sheep. They will be as many as the sheep that people brought to Jerusalem as offerings at a festival."
    },
    {
      "verse": "38",
      "text": "I will fill the broken cities with crowds of people, as many as those sheep. Then they will know that I am the Lord. ’."
    }
  ],
  "37": [
    {
      "verse": "1",
      "text": "The Lord took hold of me with great power. In a vision, the Lord's Spirit took me to the middle of a valley. Bones covered all the ground there."
    },
    {
      "verse": "2",
      "text": "The Lord made me walk up and down among the bones. I could see many bones there, on the ground in the valley. They were completely dry."
    },
    {
      "verse": "3",
      "text": "He asked me, ‘Son of man, can these bones become alive again? ’I said, ‘Almighty Lord, only you know the answer. ’ I said, ‘Almighty Lord, only you know the answer. ’"
    },
    {
      "verse": "4",
      "text": "Then he said to me, ‘Prophesy to these bones. Say to them, “Dry bones, listen to the Lord's message!"
    },
    {
      "verse": "5",
      "text": "This is what the Almighty Lord says to you bones: Listen! I will put breath into you and you will become alive."
    },
    {
      "verse": "6",
      "text": "I will join you together and I will put meat on you. I will cover you with skin. I will put breath into you and you will become alive. Then you will know that I am the Lord. ” ’"
    },
    {
      "verse": "7",
      "text": "So I prophesied, as the Lord had commanded me to do. While I was still speaking, there was a noise. It was the sound of the bones as they knocked against each other when they joined together."
    },
    {
      "verse": "8",
      "text": "While I watched, I saw meat come and join to the bones. Then skin covered them. But there was no breath in them yet."
    },
    {
      "verse": "9",
      "text": "Then the Lord said to me, ‘Prophesy to the wind, son of man. Speak my message to the wind. Say, “This is what the Almighty Lord says: Blow from all directions and put breath into these dead bodies! Cause them to become alive again. ” ’"
    },
    {
      "verse": "10",
      "text": "So I spoke the message that the Lord had commanded me to speak. Breath went into those dead bodies and they became alive. They stood up on their feet. They were as many as a great army."
    },
    {
      "verse": "11",
      "text": "Then the Lord said to me, ‘Son of man, these bones are a picture of all Israel's people. The Israelites are saying, “Our bones are dead and dry. There are no good things that we can hope for. We have come to an end. ”"
    },
    {
      "verse": "12",
      "text": "So prophesy and say to them, “This is what the Almighty Lord says: Listen, my people! I will soon open up your graves. I will bring you out of your graves. I will bring you back to the land of Israel."
    },
    {
      "verse": "13",
      "text": "When that happens to you, my people, you will know that I am the Lord."
    },
    {
      "verse": "14",
      "text": "I will put the breath of my Spirit in you, and you will become alive. I will let you live safely in your own land. Then you will know that I, the Lord, have spoken. You will know that I have done what I said I would do. That is what the Lordsays. ” ’"
    },
    {
      "verse": "15",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "16",
      "text": "‘Son of man, take a stick and write on it, “This stick belongs to Judah and the Israelite tribes that are with him. ” Then take another stick and write on it, “This stick belongs to Joseph's son Ephraim and the Israelite tribes that are with him. ”"
    },
    {
      "verse": "17",
      "text": "Make the two sticks join together to become one stick in your hand."
    },
    {
      "verse": "18",
      "text": "Your people will ask you, “Please tell us what this means. ”"
    },
    {
      "verse": "19",
      "text": "When they ask that, say to them, “This is what the Almighty Lord says: I will take Joseph's stick that belongs to Ephraim and the Israelite tribes that are with him. I will cause it to join together with Judah's stick. I will make them become one stick in my hand. ”"
    },
    {
      "verse": "20",
      "text": "Hold the two sticks that you have written words on. Hold them in your hand for the people to see."
    },
    {
      "verse": "21",
      "text": "Say to the people, “This is what the Almighty Lord says: I will take Israel's people out from among the nations where they have gone. I will bring them back together from all those foreign countries. I will bring them to their own land."
    },
    {
      "verse": "22",
      "text": "In that land, I will make them become one nation. They will live on Israel's mountains. They will have one king to rule over them all. They will never again become two nations or two separate kingdoms."
    },
    {
      "verse": "23",
      "text": "They will no longer worship their disgusting idols and make themselves unclean. They will not refuse to obey me. They have turned away from me and done bad things. But I will save them from all their sins. I will make them clean. They will be my people and I will be their God."
    },
    {
      "verse": "24",
      "text": "My servant David will be their king. There will be one shepherd who takes care of them all. They will carefully obey my rules and my laws."
    },
    {
      "verse": "25",
      "text": "They will live in the land that I gave to my servant Jacob. It is the land where your ancestors lived. My people, their children and their grandchildren will live there. They will live there for ever. My servant David will rule over them for ever."
    },
    {
      "verse": "26",
      "text": "I will make a covenant with them to give them peace. It is a promise to my people that will continue for ever. I will cause them to live safely in their land. I will cause them to grow in number. I will put my temple among them, to be with them for ever."
    },
    {
      "verse": "27",
      "text": "I will make my home with them. I will be their God and they will be my people."
    },
    {
      "verse": "28",
      "text": "Then the nations will know that I, the Lord, have chosen the Israelites as my own people. The nations will see that I have put my temple among my people for ever. ” ’"
    }
  ],
  "38": [
    {
      "verse": "1",
      "text": "The Lord gave this message to me:"
    },
    {
      "verse": "2",
      "text": "‘Son of man, turn and look towards Gog, in the land of Magog. He is the most important prince of Meshech and Tubal. Speak my message to warn him."
    },
    {
      "verse": "3",
      "text": "Say, “This is what the Almighty Lord says: I am your enemy, Gog, prince of Meshech and Tubal."
    },
    {
      "verse": "4",
      "text": "I will turn you around. I will put hooks into your mouth and catch you. I will take hold of you and your great army, with its horses and their riders. I will take hold of all your soldiers, who are ready to fight with their swords and their shields. I will pull them all away."
    },
    {
      "verse": "5",
      "text": "Soldiers from Persia, Ethiopia and Libya will be there with your army. They all have shields and helmets."
    },
    {
      "verse": "6",
      "text": "All the soldiers from Gomer will join you. An army from Beth Togarmah will also come with all its soldiers from far away in the north. So armies from many nations will be with you. ”"
    },
    {
      "verse": "7",
      "text": "Say to Gog, “Prepare to fight! You must be ready to command all the armies that are with you."
    },
    {
      "verse": "8",
      "text": "After many days you will have to bring your soldiers together to fight a battle. In the years at the end of time, you will go to attack the land of Israel. It will be a land that has become strong again after war. The people there will have returned from other nations. They will all be living safely in that land that had become heaps of stones. They will all be together on Israel's mountains."
    },
    {
      "verse": "9",
      "text": "Then you will attack them. You, with your armies and all the people with you, will attack them like a great storm. You will be like a dark cloud that covers the land."
    },
    {
      "verse": "10",
      "text": "This is what the Almighty Lord says: On that day you will have evil thoughts. You will decide to do a wicked thing."
    },
    {
      "verse": "11",
      "text": "You will say: ‘We will attack a land where the villages have no walls around them. The people are living quietly in peace and we will attack them. They have no walls or strong gates to keep them safe."
    },
    {
      "verse": "12",
      "text": "We will fight them and take their things for ourselves. The people there have come back from other nations where they lived. They are living in their homes which had become heaps of stones. Now they have got many animals and valuable things. Their land has become an important place in the middle of everywhere. ’"
    },
    {
      "verse": "13",
      "text": "The people of Sheba and Dedan, and the traders and leaders of Tarshish will ask you questions. They will say, ‘Why have you brought all your armies together? Have you come to attack Israel and take away their valuable things for yourselves? Will you take away their silver and their gold? Will you take their animals and all their things? Will you carry away such a great load of things for yourselves? ’ ”"
    },
    {
      "verse": "14",
      "text": "So, son of man, you must prophesy to Gog. Say to him, “This is what the Almighty Lord says: That is what you will decide to do at that time. You will do it when you see that my people, the Israelites, are living safely."
    },
    {
      "verse": "15",
      "text": "You will come from your country far away in the north. You will bring many soldiers with you. All of them will be riding on horses. They will be a great army of many soldiers."
    },
    {
      "verse": "16",
      "text": "Your army will be like a cloud that covers the land when you attack my people, the Israelites. In the days at the end of time I will bring you to attack my land. Yes, Gog, I will use you to show the nations that I am holy. Then they will know who I am."
    },
    {
      "verse": "17",
      "text": "This is what the Almighty Lord says: In years long ago, I gave my servants, the prophets of Israel, messages about you. At that time they prophesied that I would bring you to attack my people."
    },
    {
      "verse": "18",
      "text": "I, the Almighty Lord, say this: On the day that Gog attacks the land of Israel, I will become more and more angry."
    },
    {
      "verse": "19",
      "text": "I promise you this, because I am so very angry. On that day, there will be a great earthquake in the land of Israel."
    },
    {
      "verse": "20",
      "text": "Everything that lives will shake with fear when they see what I am doing. The fish in the sea, the birds in the sky, the wild animals, the small animals that move along the ground and all the people on earth will be very afraid. I will make the mountains and hills break into pieces. All the walls in the cities will fall down."
    },
    {
      "verse": "21",
      "text": "I will command the soldiers on all the mountains of my land to attack Gog. That is what I, the Almighty Lord, say. Gog's soldiers will fight against each other with their swords."
    },
    {
      "verse": "22",
      "text": "I will judge Gog. I will punish his men with disease and death. I will send storms of rain, hail, fire and sulphur. They will pour down from the sky on him and on his armies."
    },
    {
      "verse": "23",
      "text": "I will show all the nations that I am great and I am holy. Then they will know that I am the Lord. ” ’"
    }
  ],
  "39": [
    {
      "verse": "1",
      "text": "‘Son of man, you must tell my message to Gog to warn him. Say to him, “This is what the Almighty Lord says: Listen! I am your enemy, Gog, prince of Meshech and Tubal."
    },
    {
      "verse": "2",
      "text": "I will turn you around and I will pull you along. I will bring you from the far away places in the north to attack the mountains of Israel."
    },
    {
      "verse": "3",
      "text": "Then I will knock your bow out of your left hand. I will cause your arrows to fall out of your right hand."
    },
    {
      "verse": "4",
      "text": "You will fall to the ground on Israel's mountains. You, your soldiers and the people who are with you will all die there. Vultures and wild animals will eat your dead bodies."
    },
    {
      "verse": "5",
      "text": "Your bodies will lie in the fields. I, the Almighty Lord, have said that this will happen."
    },
    {
      "verse": "6",
      "text": "I will send fires to burn in Magog. They will burn the people who live safely in towns on the coast of the sea. Then they will know that I am the Lord."
    },
    {
      "verse": "7",
      "text": "My people, Israel will know that my name is holy. No longer will I let them say bad things about me. And the nations round you will know that I, the Lord am the holy God in Israel. I told you that this day would come."
    },
    {
      "verse": "8",
      "text": "I promise that I will cause this to happen. You can be sure that this day will come, says the Lord God. I told you that this day would come."
    },
    {
      "verse": "9",
      "text": "Then those who live in Israel's towns will go out. They will pick up the weapons and they will burn them. They will burn the small and large shields, the heavy sticks, the throwing sticks and the sharp pointed sticks (swords). They will use them to make their fires. They will have enough wood for seven years of fires."
    },
    {
      "verse": "10",
      "text": "They will not have to go into the fields or forests to find wood. They will take away the things from those who took their things, says the Lord God."
    },
    {
      "verse": "11",
      "text": "They will bury Gog in the valley east of the sea. They will bury Gog and all his armies there. So men will not be able to walk through this valley. They will call it the valley of Hamon Gog (Gog's army)."
    },
    {
      "verse": "12",
      "text": "Israel's people will need seven months to bury all the dead bodies. Then the land will be clean."
    },
    {
      "verse": "13",
      "text": "All the people in the country will bury the dead bodies. They will always remember that day, the day that I won the fight. They will give me glory, says the Lord God."
    },
    {
      "verse": "14",
      "text": "They will choose some men to clean the land. They will travel through all the country. Other men will bury the dead bodies that remain on the ground. They will begin to do this at the end of the seven months."
    },
    {
      "verse": "15",
      "text": "The men who walk through the country will find dead men's bones. They will put a sign by each one. Then the men who bury the bodies will bury them in the valley of Hamon Gog."
    },
    {
      "verse": "16",
      "text": "(A town called Hamonah is also there. ) That is how they will make the land clean. ”"
    },
    {
      "verse": "17",
      "text": "Son of man, this is what the Lord God says: Shout to all kinds of birds and wild animals, “Come here from all the country to eat the meal that I have prepared for you. It is a great sacrifice on Israel's mountains. There you will eat meat and you will drink blood."
    },
    {
      "verse": "18",
      "text": "You will eat the meat of great men and you will drink the blood of kings. You will eat them like the fat sheep, cows and animals from Bashan that you eat."
    },
    {
      "verse": "19",
      "text": "At this sacrifice, you will eat so much fat that you cannot eat any more. You will drink so much blood that you become drunk."
    },
    {
      "verse": "20",
      "text": "I will give you horses and their riders to eat. I will give you great men and many kinds of soldiers to eat, ” says the Lord God."
    },
    {
      "verse": "21",
      "text": "I will show my glory to all the nations. They will see that I can punish people. And they will know that I decide how and when to punish them."
    },
    {
      "verse": "22",
      "text": "From that time and for all the time after that, Israel's people will know that I am the Lord their God."
    },
    {
      "verse": "23",
      "text": "And the nations will know that I sent Israel's people away from their country. They will know that I punished my people because of their sin. They had not been faithful to me so I turned away from them. I let their enemies take them and kill them with swords."
    },
    {
      "verse": "24",
      "text": "I punished them because they had not kept themselves clean from sin. I hid myself from them because they had done so many evil things. ’"
    },
    {
      "verse": "25",
      "text": "So this is what the Lord God says. ‘Now I will bring back Jacob (Israel) from the countries where his people are prisoners. I will be kind to all Israel's people. And I will make them see that I am holy."
    },
    {
      "verse": "26",
      "text": "They will forget that they were ashamed. They will forget that they failed to keep their promises to me. That was when they lived in a safe country. In that country, nobody made them afraid."
    },
    {
      "verse": "27",
      "text": "I will bring them back from the lands where their enemies took them. The nations will see what I have done. So all the nations will know that I am holy."
    },
    {
      "verse": "28",
      "text": "Then Israel will know that I am the Lord their God. I sent my people away to far countries. But I will bring them all back to their own country. I will not leave any behind."
    },
    {
      "verse": "29",
      "text": "No longer will I turn away from them. I will pour my Spirit over Israel's people, says the Lord God. ’"
    }
  ],
  "40": [
    {
      "verse": "1",
      "text": "In the 25th year that we had been prisoners in Babylon, the Lord took hold of me with great power. It happened on the tenth day of the first month of the year. It was 14 years since Babylonian soldiers had destroyed the city of Jerusalem. In a vision, the Lord took me there."
    },
    {
      "verse": "2",
      "text": "In the vision, he took me to the land of Israel. He put me on a very high mountain. When I looked towards the south, I saw a group of buildings that looked like a city."
    },
    {
      "verse": "3",
      "text": "The Lord took me there. Then I saw a man who shone brightly like bronze. He was standing at the entrance of a building. He held a linen rope and a stick in his hand. He used them to measure things."
    },
    {
      "verse": "4",
      "text": "The man said to me, ‘Son of man, watch and listen carefully to me. Remember everything that I will show you. God has brought you here so that I can show these things to you. Tell Israel's people about everything that you see. ’"
    },
    {
      "verse": "5",
      "text": "I saw a wall all the way round the place where the temple was. The stick in the man's hand was 3 metres long. He used it to measure the wall. The wall was 3 metres wide and 3 metres high."
    },
    {
      "verse": "6",
      "text": "Then he went to the gate on the east side. He climbed its steps and he measured the size of the entrance. It was 3 metres deep."
    },
    {
      "verse": "7",
      "text": "Beyond this was a passage with three rooms on each side. They were rooms for the guards. Each of these rooms was 3 metres long and 3 metres wide. The walls between the rooms were 2½ metres thick. Beyond them was a passage that was 3 metres long. This went to an entrance room to the yard of the temple."
    },
    {
      "verse": "8",
      "text": "The man measured the entrance room at the end of the passage."
    },
    {
      "verse": "9",
      "text": "metres long. It had pillars that were 1 metre thick. It was the nearest part of the gate to the temple."
    },
    {
      "verse": "10",
      "text": "The three rooms on each side of the passage at the east gate were all the same size. The walls that were between each room were also the same size."
    },
    {
      "verse": "11",
      "text": "Then the man measured the passage that went through the gate's entrance. The passage was 6½ metres wide. The gate's entrance itself was 5 metres wide."
    },
    {
      "verse": "12",
      "text": "There was a low wall in front of the rooms on each side of the passage. It was ½ metre high. The rooms were 3 metres square."
    },
    {
      "verse": "13",
      "text": "The man also measured between the back wall of one room and the back wall of the room opposite. It was 12½ metres from one wall to the other wall, across the passage."
    },
    {
      "verse": "14",
      "text": "metres high. The yard was all around three sides of the room."
    },
    {
      "verse": "15",
      "text": "metres long, from the gate at the front to the entrance room into the yard."
    },
    {
      "verse": "16",
      "text": "The rooms for the guards all had small windows in their outside walls. The walls between the rooms also had small windows. The entrance room to the yard also had windows of the same kind. Men had cut pictures of palm trees on the inside walls of the passage."
    },
    {
      "verse": "17",
      "text": "The man took me through the entrance gate into the outside yard of the temple. I saw 30 rooms there, all along the wall of the yard. A path of flat stones was in front of the rooms."
    },
    {
      "verse": "18",
      "text": "The path went all around the yard and it covered the space between the gates. It was called the lower path."
    },
    {
      "verse": "19",
      "text": "The man measured across the outside yard. He measured from the lower gate to the higher gate that went into the inside yard. The man measured 50 metres between the two gates."
    },
    {
      "verse": "20",
      "text": "Then the man measured the gate on the north side of the outside yard."
    },
    {
      "verse": "21",
      "text": "He measured the three rooms on each side of the passage and the walls between them. He also measured the entrance room itself. They all measured the same as those in the east gate. The whole entrance was 25 metres long and it was 12½ metres wide."
    },
    {
      "verse": "22",
      "text": "The entrance room, the windows and the pictures of palm trees were the same as those in the east gate. Seven steps went up to the north gate. The entrance room into the yard was at the end of the passage."
    },
    {
      "verse": "23",
      "text": "Opposite this gate, across the yard, was the gate to the inside yard. It was the same as on the east side. The man measured 50 metres between the two gates."
    },
    {
      "verse": "24",
      "text": "Next, the man took me to the south side of the yard. I saw another gate there. The man measured the walls and the rooms in that entrance. They were the same size as the other walls and rooms."
    },
    {
      "verse": "25",
      "text": "The rooms in this entrance had windows that were the same as those in the other entrances. The whole entrance was 25 metres long and it was 12½ metres wide."
    },
    {
      "verse": "26",
      "text": "Seven steps went up to it. The entrance room to the yard was at the end of the passage. There were pictures of palm trees on the inside walls of the passage."
    },
    {
      "verse": "27",
      "text": "The inside yard of the temple also had a gate on the south side. The man measured 50 metres between the two gates."
    },
    {
      "verse": "28",
      "text": "The man took me through the south gate into the inside yard. He measured the gate. It was the same size as the gates in the outside wall."
    },
    {
      "verse": "29",
      "text": "The rooms for the guards, the walls between them and theentrance room were the same size as the ones at the other gates. There were windows along its walls and in the entrance room. As at the other gates, the whole entrance was 25 metres long and 12½ metres wide."
    },
    {
      "verse": "30",
      "text": "The entrance rooms around the inside yard were 12½ metres wide and 2½ metres long."
    },
    {
      "verse": "31",
      "text": "The entrance room of this gate opened towards the outside yard. There were pictures of palm trees on the walls of the passage. Eight steps went up to this gate."
    },
    {
      "verse": "32",
      "text": "The man took me to the east side the inside yard. He measured the gate. It was the same size as the other gates."
    },
    {
      "verse": "33",
      "text": "The rooms for the guards, the walls between them and theentrance room were the same size as the ones at the other gates. There were windows along its walls and in the entrance room. The whole entrance was 25 metres long and 12½ metres wide."
    },
    {
      "verse": "34",
      "text": "The entrance room of this gate opened towards the outside yard. There were pictures of palm trees on the walls of the passage. Eight steps went up to this gate."
    },
    {
      "verse": "35",
      "text": "Then the man took me to the north gate. He measured it. It was the same size as the other gates,"
    },
    {
      "verse": "36",
      "text": "with rooms for the guards, their walls and an entrance room with windows. The whole entrance was 25 metres long and 12½ metres wide."
    },
    {
      "verse": "37",
      "text": "The door of the entrance room opened towards the outside yard. There were pictures of palm trees on the walls of the passage, on both sides. Eight steps went up to this gate."
    },
    {
      "verse": "38",
      "text": "There was a small building joined to the entrance room of the north gate. There was a door between this building and the entrance room. In that building, the priests washed the dead bodies of animals for burnt offerings."
    },
    {
      "verse": "39",
      "text": "In the entrance room there were four tables, two on each side of the room. They killed the animals for sacrifices on these tables. They were animals for burnt offerings and also for sin offerings and for guilt offerings."
    },
    {
      "verse": "40",
      "text": "There were four more tables outside the entrance room of the north gate. Two tables were on each side of the steps at the entrance."
    },
    {
      "verse": "41",
      "text": "So there were eight tables on which they killed animals for sacrifices. Four tables were in the yard outside the entrance. Four tables were inside the entrance room."
    },
    {
      "verse": "42",
      "text": "They had used stone to make four tables for the burnt offerings. These tables were 50 centimetres high. Their tops were 75 centimetres square. They put the knives and the other tools that they used to kill the animals on these tables."
    },
    {
      "verse": "43",
      "text": "They put the meat for the offerings on the stone tables. There were hooks all around the inside walls of the room. Each hook was 7½ centimetres long."
    },
    {
      "verse": "44",
      "text": "There were two rooms for singers that had doors to the inside yard. One was beside the north gate and its door opened towards the south. The other room was beside the south gate and its door opened towards the north."
    },
    {
      "verse": "45",
      "text": "The man said to me, ‘The room beside the north gate is for the priests who take care of the temple."
    },
    {
      "verse": "46",
      "text": "The room beside the south gate is for the priests who serve God at the altar. These priests are descendants of Zadok. They are the only descendants of Levi who may come near to the Lord to serve him. ’"
    },
    {
      "verse": "47",
      "text": "The man measured the inside yard. It was square, 50 metres long and 50 metres wide. There was an altar in front of the temple."
    },
    {
      "verse": "48",
      "text": "The man took me into the entrance room of the temple building. He measured the walls on each side of the entrance. They were 2½ metres thick. The entrance was 7 metres wide. The walls on each side of the entrance were 1½ metres wide."
    },
    {
      "verse": "49",
      "text": "metres wide and 6 metres long. Steps went up to the entrance room. There were two pillars, one on each side of the entrance."
    }
  ],
  "41": [
    {
      "verse": "1",
      "text": "Then the man took me into the big hall of the temple. He measured the walls on each side of the entrance. They were 3 metres thick."
    },
    {
      "verse": "2",
      "text": "metres wide. The walls on each side were 2½ metres wide. The big hall was 20 metres long and 10 metres wide."
    },
    {
      "verse": "3",
      "text": "Then he went into the inside room. He measured the walls at the entrance. They were 1 metre thick. The entrance was 3 metres wide. The walls on each side were 3½ metres wide."
    },
    {
      "verse": "4",
      "text": "He measured the inside room. It was 10 metres long and 10 metres wide. It was at the back of the big hall. The man said to me, ‘This is the Most Holy Place. ’"
    },
    {
      "verse": "5",
      "text": "Then the man measured the wall of the temple. It was 3 metres thick. There were small rooms along the outside of the wall, all around the temple. Each room was 2 metres wide."
    },
    {
      "verse": "6",
      "text": "The side rooms were on three levels. Each level had 30 rooms. The temple's wall at each level was less thick than the wall below. So the wall itself held up each level of rooms. They did not have to fix the side rooms into the temple's wall."
    },
    {
      "verse": "7",
      "text": "The side rooms at each level were wider than the rooms on the level below them, because the temple's wall was less thick. There was a set of stairs that went from the lowest level to the middle level and up to the top level."
    },
    {
      "verse": "8",
      "text": "I saw that there was a stone base all around the temple. The side rooms stood on this base as their foundation. It was 3 metres high."
    },
    {
      "verse": "11",
      "text": "There were two doors for the side rooms. One door opened towards the north. The other door opened towards the south. They opened into a space that was 2½ metres wide."
    },
    {
      "verse": "12",
      "text": "There was a large building at the west side of the temple yard. It was 37 metres wide and 47 metres long. Its walls were 2½ metres thick."
    },
    {
      "verse": "13",
      "text": "Then the man measured the outside of the temple building. It was 50 metres long. He measured from the back of the temple across the open space to the back wall of the large building. That was also 50 metres."
    },
    {
      "verse": "14",
      "text": "He measured the front of the temple building and the open space on each side. That was 50 metres too."
    },
    {
      "verse": "15",
      "text": "He measured the building at the back of the temple yard, on the west side. That was also 50 metres, including the side rooms at each end. Wooden boards covered the walls of the big hall, the inside room and the entrance room of the temple."
    },
    {
      "verse": "16",
      "text": "The boards covered the walls from the floor up to the windows, and above the windows. They used wood to make the edges of the windows. They also covered the windows."
    },
    {
      "verse": "19",
      "text": "A human face looked towards the palm tree on one side. A lion's face looked towards the palm tree on the other side. Workers had cut these pictures on the walls around the inside of the whole temple building."
    },
    {
      "verse": "20",
      "text": "The pictures of cherubs and palm trees covered all the walls, from the floor up to above the doors."
    },
    {
      "verse": "21",
      "text": "There were square posts on each side of the entrance to the temple's big hall. The entrance to the Most Holy Place seemed the same."
    },
    {
      "verse": "22",
      "text": "There was an altar that was made of wood. It was 1½ metres high and 1 metre wide on each side. Its corners, its sides and its base were all made of wood. The man said to me, ‘This is the table that stands here in front of the Lord. ’"
    },
    {
      "verse": "23",
      "text": "The big hall of the temple and the Most Holy Place both had doors that were in two parts."
    },
    {
      "verse": "24",
      "text": "The doors were fixed on both sides of each entrance and they opened in the middle."
    },
    {
      "verse": "25",
      "text": "Workers had cut pictures on the doors of the big hall. They were pictures of palm trees and cherubs, like the pictures on the walls. There was a roof over the outside of the door to the entrance room. It was made of wood."
    },
    {
      "verse": "26",
      "text": "The entrance room had narrow windows in the walls on each side. The windows had pictures of palm trees on each side. Workers had cut shapes of palm trees on its walls. The side rooms around the temple also had roofs over the outside of their doors."
    },
    {
      "verse": "9",
      "text": "The outside wall of the side rooms was 2½ metres thick. There was an open space between these rooms and the rooms that the priests used."
    },
    {
      "verse": "10",
      "text": "It was 10 metres wide, all around the temple building."
    },
    {
      "verse": "17",
      "text": "Workers had cut pictures in the wood above the doors and all over the walls. They were pictures of palm trees and cherubs. There was a picture of a palm tree between each cherub."
    },
    {
      "verse": "18",
      "text": "They covered all the inside walls of the temple. Each cherub had two faces."
    }
  ],
  "42": [
    {
      "verse": "1",
      "text": "Then the man took me out through the north gate of the inside yard of the temple. We went into the outside yard. We arrived at a building that was in the north wall of the inside yard."
    },
    {
      "verse": "2",
      "text": "metres long and 25 metres wide. Its entrance was towards the north."
    },
    {
      "verse": "3",
      "text": "metre space between one side of this building and the temple in the inside yard. The building's other side was opposite the path in the outside yard. It had three levels of rooms in two rows that were opposite each other."
    },
    {
      "verse": "4",
      "text": "A path went between the two rows of rooms. It was 50 metres long and 5 metres wide. The entrances to the rooms were on the north side."
    },
    {
      "verse": "5",
      "text": "The rooms at the top level were not as wide as the rooms below them. And the rooms at the middle level were not as wide as the rooms at the lowest level. This was because the higher rooms needed more space in front of them."
    },
    {
      "verse": "6",
      "text": "They did not have pillars to hold them up as other rooms in the temple yards did. Instead, the walls of the lower rooms held up the rooms above them. So the rooms of each level were smaller than the rooms below them."
    },
    {
      "verse": "7",
      "text": "There was a wall that went across the outside yard in front of the lowest rooms. The wall was 25 metres long."
    },
    {
      "verse": "8",
      "text": "metres long. But the other row of rooms in the inside yard, opposite the temple, was 50 metres long."
    },
    {
      "verse": "9",
      "text": "The lowest level of rooms had an entrance from the outside yard at the east end of the building."
    },
    {
      "verse": "10",
      "text": "This entrance was at the end of the wall in the outside yard. There was another building like this one on the south side of the temple. It was opposite the other building and it also had two rows of rooms."
    },
    {
      "verse": "11",
      "text": "There was path between the two rows. They looked the same as the rooms on the north side. The size of the rooms and the entrances were the same as those of the other building."
    },
    {
      "verse": "12",
      "text": "There was an entrance in the wall opposite the doors of the inside row of rooms. There was also an entrance at the east end of the path between the rows of rooms."
    },
    {
      "verse": "13",
      "text": "Then the man said to me, ‘These rooms that are on the north and south sides of the temple's inside yard are holy. They are for the priests who serve the Lord in his temple. In these rooms, the priests will eat the most holy sacrifices that they offer to the Lord. They will put the most holy offerings there. It is where they will put the grain offerings, the sin offerings and the guilt offerings. The priests will do that because the rooms are holy."
    },
    {
      "verse": "14",
      "text": "When the priests go into the holy place of the temple, they must not leave until they change their clothes. Before they go into the outside yard, they must take off the special clothes that they wear to serve the Lord. Those clothes are holy, so they must put on other clothes. Then they can go out to the places where the people meet. ’"
    },
    {
      "verse": "15",
      "text": "The man finished measuring everything inside the place where the temple was. Then he took me out through the east gate. He measured all around the outside of the temple yards."
    },
    {
      "verse": "16",
      "text": "He used his stick to measure the wall on the east side. It was 250 metres."
    },
    {
      "verse": "20",
      "text": "So the wall made a square around the place where the temple was. Each side was 250 metres. The wall made the holy place separate from the ordinary places around it."
    },
    {
      "verse": "17",
      "text": "Then he measured the north side and the south side and the west side."
    },
    {
      "verse": "18",
      "text": "Each side measured the same as the east side."
    },
    {
      "verse": "19",
      "text": "."
    }
  ],
  "43": [
    {
      "verse": "1",
      "text": "Then the man brought me to the east gate."
    },
    {
      "verse": "2",
      "text": "There I suddenly saw the bright glory of the God of Israel as it came from the east. His voice was like the noise of lots of water that pours along a river. The land around shone with the bright light of his glory."
    },
    {
      "verse": "3",
      "text": "I had seen a vision like this when I was beside the Kebar River. I had also seen a vision like this when God came to destroy Jerusalem. I bent down low with my face on the ground."
    },
    {
      "verse": "4",
      "text": "The Lord's bright glory went through the east gate into the temple."
    },
    {
      "verse": "5",
      "text": "Then a spirit lifted me up and took me into the temple's inside yard. As I watched, the Lord's glory filled the temple."
    },
    {
      "verse": "6",
      "text": "While the man stood beside me, I heard a voice come from inside the temple."
    },
    {
      "verse": "7",
      "text": "The Lord said to me, ‘Son of man, this is the place where I sit on my throne. It is my home where I will live among Israel's people. Israel's people and their kings will never again spoil the honour of my holy name. They will not turn away from me and worship other gods. They will not put the graves of their kings in this place."
    },
    {
      "verse": "8",
      "text": "Their kings built their palaces too near to my holy temple. There was only a wall between me and them. They did many disgusting things that spoiled the honour of my holy name. As a result, I became very angry with them and I destroyed them."
    },
    {
      "verse": "9",
      "text": "Now they must be faithful to me. They must no longer worship other gods. The must not give honour to the graves of their kings. If they stop doing these things, I will live among them for ever."
    },
    {
      "verse": "10",
      "text": "Son of man, you must describe the temple to Israel's people. It should make them ashamed of their sins. They must study the plan of the temple."
    },
    {
      "verse": "11",
      "text": "Then they will be ashamed of everything that they have done. Explain the temple's plan to them. Describe its shape, its entrances, and everything about it. Explain its rules and its laws. You must write all this down while they watch you. Then they can study the temple's plan and they can obey its rules."
    },
    {
      "verse": "12",
      "text": "This is the most important law about the temple: All the top of the mountain around the temple will be most holy."
    },
    {
      "verse": "13",
      "text": "This is the size of the altar. There is a hole, 50 centimetres deep and 50 centimetres wide, all around the altar. There is a border around its outside edge, 25 centimetres high."
    },
    {
      "verse": "14",
      "text": "The lowest part of the altar, from its base up, is 1 metre high. The part above that is 2 metres high. It is 50 centimetres smaller than the part below it, all around. The top part of the altar is also 50 centimetres smaller than the middle part."
    },
    {
      "verse": "15",
      "text": "metres high. They burn the sacrifices on this top part. Its four corners have points like horns that go up."
    },
    {
      "verse": "16",
      "text": "The top of the altar is square, with each side 6 metres long."
    },
    {
      "verse": "17",
      "text": "The middle part is also square, with each side 7 metres long. It has a border around its edge that is 25 centimetres high. There is a hole all around that is 50 centimetres wide. There are steps up to the top of the altar on the east side. ’"
    },
    {
      "verse": "18",
      "text": "Then he said to me, ‘Son of man, this is what the Almighty Lord says: These are the rules about the altar. On the day that it is ready to use, the priests will offer burnt offerings on it. They will alsosplash blood from the sacrifices on it."
    },
    {
      "verse": "19",
      "text": "You must give a young bull to the priests to offer as a sacrifice to me. The priests must belong to Zadok's family in the tribe of Levi. They are the only men who can come near to me to serve me. That is what I, the Almighty Lord, say."
    },
    {
      "verse": "20",
      "text": "You will take some of the bull's blood and put it on the four horns on the top of the altar. Also put some blood on the corners of the middle part of the altar. And put some on the border around the edge of the altar. Do that to make the altar clean and pure for me."
    },
    {
      "verse": "21",
      "text": "You must take the bull to burn as a sin offering. Burn it in the proper place in the temple yard, outside the temple building."
    },
    {
      "verse": "22",
      "text": "The next day, choose a male goat that has nothing wrong with it. Offer it as a sin offering. Use its blood to make the altar clean and pure, as you did with the bull's blood."
    },
    {
      "verse": "23",
      "text": "After you have done that, choose a young bull and a male sheep that have nothing wrong with them."
    },
    {
      "verse": "24",
      "text": "Bring them to me, the Lord. The priests will throw salt on them. Then they will offer them to me as a burnt offering."
    },
    {
      "verse": "25",
      "text": "Each day for seven days, you must offer a male goat as a sin offering. You must also choose a young bull and a male sheep each day as sacrifices. They must all have nothing wrong with them."
    },
    {
      "verse": "26",
      "text": "The priests will make the altar clean and pure on each of those seven days. That will make it ready for holy use."
    },
    {
      "verse": "27",
      "text": "When the seven days have finished, the priests can begin to offer burnt offerings and peace offerings on the altar. They can do this for you on the eighth day and after that. Then I will accept you as my own people. That is what I, the Almighty Lord, say. ’"
    }
  ],
  "44": [
    {
      "verse": "1",
      "text": "Then the man brought me back to the outside gate on the east side of the temple yard. But the gate was shut."
    },
    {
      "verse": "2",
      "text": "The Lord said to me, ‘This gate must stay shut. Nobody may go through it. Nobody may open it again. The Lord, Israel's God, has gone through it. So it must stay shut."
    },
    {
      "verse": "3",
      "text": "Only Israel's ruler is allowed to sit in the gate's entrance. He may sit there to eat a holy meal in front of the Lord. He may only go in and out through the entrance room of that gate. ’"
    },
    {
      "verse": "4",
      "text": "Then the man took me through the north gate of the temple yard. We went to the front of the temple building. As I watched, I saw that the Lord's glory filled his temple. I bent down low with my face on the ground."
    },
    {
      "verse": "5",
      "text": "The Lord said to me, ‘Son of man, listen to what I tell you. Think carefully about it. These are the rules and laws about the Lord's temple. Understand about its entrances and the people who are allowed to go in and out of the temple."
    },
    {
      "verse": "6",
      "text": "Israel's people refuse to obey me. Say to them, “This is what the Almighty Lord says: Israel's people, you have done too many disgusting things!"
    },
    {
      "verse": "7",
      "text": "You brought foreigners into my temple. They were not circumcised and they did not want to belong to me. In that way, you made my own temple unclean. You did that when you offered food, fat and blood to me there. You did not obey my covenant with you, when you did all these disgusting things."
    },
    {
      "verse": "8",
      "text": "You did not take care of my holy things yourselves. Instead you chose foreigners to take care of my holy place on your behalf."
    },
    {
      "verse": "9",
      "text": "This is what the Almighty Lord God says: No foreigner may go into my holy place if he is not circumcised and he does not want to obey me. Even if that foreigner lives among my people, the Israelites, he must not go in there."
    },
    {
      "verse": "10",
      "text": "As well as other Israelites, some Levite men turned away from me to worship idols. I will punish them as they deserve for their sin."
    },
    {
      "verse": "11",
      "text": "But they may continue to serve me in the work of the temple. They can be guards at the temple gates. They can kill the animals that people bring for burnt offerings and other sacrifices. They can help the people who come to worship me."
    },
    {
      "verse": "12",
      "text": "But I promise that I will punish them as they deserve for their sin. That is because they helped the people to worship their idols. In that way, they caused Israel's people to do bad things. I, the Almighty Lord, promise that I will punish them."
    },
    {
      "verse": "13",
      "text": "They must not come near to me to serve me as the priests do. They must not touch any of my holy things or the most holy offerings. Instead, they must be ashamed of the disgusting things that they have done."
    },
    {
      "verse": "14",
      "text": "But I will allow them to take care of the temple and all the ordinary work that is done there."
    },
    {
      "verse": "15",
      "text": "Only the priests who are descendants of Zadok, the Levite, may come near to me and serve me. When Israel's people turned away from me, only the priests of Zadok's family faithfully served me in my temple. So now Zadok's descendants may offer to me the fat and the blood of sacrifices. That is what the Almighty Lord says."
    },
    {
      "verse": "16",
      "text": "Only they can come into my holy place and serve me at the altar. They will do what I tell them to do."
    },
    {
      "verse": "17",
      "text": "When they come through the gates into the inside yard, they must wear linen clothes. The clothes that they wear while they serve me must not have any wool in them. They must wear linen clothes when they work at the gates of the inside yard or in the temple."
    },
    {
      "verse": "18",
      "text": "They must wear linen cloths around their heads. The trousers that they wear next to their skin must also be made of linen. They must not tie anything around their body that makes them sweat."
    },
    {
      "verse": "19",
      "text": "Before they go out to the outside yard to meet the ordinary people, they must take off their special clothes. They must leave the clothes that they wore when they were serving me in one of the rooms in the holy place. They must put on other clothes before they go out. Then their special clothes will not touch the people and make them holy."
    },
    {
      "verse": "20",
      "text": "The priests must not cut all the hair off their heads. They must not let it grow long either. They must keep their hair short."
    },
    {
      "verse": "21",
      "text": "When a priest goes into the inside yard of the temple, he must not drink anywine."
    },
    {
      "verse": "22",
      "text": "Priests must not marry a widow, or a woman whose husband has sent her away. They may only marry Israelite women who have never had sex. Or they may marry a widow whose husband had been a priest."
    },
    {
      "verse": "23",
      "text": "They must teach my people that holy things are different from ordinary things. They must also show them how to know if something is clean or unclean."
    },
    {
      "verse": "24",
      "text": "If people have an argument, the priests must be their judges. They must use my laws to decide who is right. They must obey the rules about my special festivals. They must respect Sabbath days as holy."
    },
    {
      "verse": "25",
      "text": "A priest must not go near to a dead person. It would make him unclean. But if the dead person is his father, his mother, his son, his daughter, his brother or his sister who has not married, he may go near them. It makes him unclean but he may do that."
    },
    {
      "verse": "26",
      "text": "After this, he must make himself clean. Then he must wait seven days."
    },
    {
      "verse": "27",
      "text": "Then he can go into the inside yard of the temple to serve me there. On the day that he goes back there, he must make a sin offering for himself. That is what the Almighty Lord says."
    },
    {
      "verse": "28",
      "text": "Do not give the priests their own land in Israel to keep for their descendants. I myself will be the gift that they receive. I will take care of them and their families."
    },
    {
      "verse": "29",
      "text": "They will receive the grain offerings, the sin offerings and the guilt offerings. They are allowed to eat some of those offerings that the people bring. All the special things that people give to the Lord will belong to the priests."
    },
    {
      "verse": "30",
      "text": "The best of all the first crops from people's land and all their special gifts will belong to the priests. You must also give to the priests the first flour that you make from your grain. Then I will bless the people who live in your house."
    },
    {
      "verse": "31",
      "text": "The priests must not eat any bird or any animal that people find dead. They must not eat anything that a wild animal has killed. ” ’"
    }
  ],
  "45": [
    {
      "verse": "1",
      "text": "‘You must divide the land into different parts to belong to each tribe. When you do this, you must give one part to the Lord. It will belong to the Lord as a holy piece of land. It will be 12½ kilometres long and 10 kilometres wide. All of this land will be holy."
    },
    {
      "verse": "2",
      "text": "Part of this land will be for the temple. It will be 250 metres long and 250 metres wide. Keep an empty space 25 metres wide all around this piece of land."
    },
    {
      "verse": "3",
      "text": "Inside the holy piece of land, measure a part that is 12½ kilometres long and 5 kilometres wide. This part will contain the temple, the most holy place."
    },
    {
      "verse": "4",
      "text": "The priests will have this holy part of the land. They are the men who work in the temple and come near to the Lord to serve him. The priests' houses will be there, as well as the temple."
    },
    {
      "verse": "5",
      "text": "The other half of the holy piece of land will be for the Levites, who work in the temple. They will have towns there to live in. Their land will be 12½ kilometres long and 5 kilometres wide."
    },
    {
      "verse": "6",
      "text": "There will also be a piece of land for the city, 12½ kilometres long and 2½ kilometres wide. It will be beside the holy piece of land. Any of Israel's people may live there."
    },
    {
      "verse": "7",
      "text": "There will be two pieces of land for the ruler. One piece will be on the east side of the holy piece of land and the land for the city. The other piece will be on the west side. The piece on the west side will go as far as the sea. The piece on the east side will go as far as the border of the land. So his land will be as long as a part of the land that belongs to each tribe."
    },
    {
      "verse": "8",
      "text": "This will be the part of Israel's land that belongs to the ruler. Because my rulers will have their own land, they will no longer need to make my people suffer. They will give to each tribe a part of the land that will belong to them."
    },
    {
      "verse": "9",
      "text": "The Almighty Lord says this: Rulers of Israel, stop cheating my people and making them suffer! You have done enough bad things! Instead, do things that are right and fair. Stop chasing my people off their land. That is what the Almighty Lord says."
    },
    {
      "verse": "10",
      "text": "You must use correct measures for size and for weight."
    },
    {
      "verse": "11",
      "text": "The ephah that you use to measure dry things must be the same measure that you use for wet things. Ten ephahs will be equal to one homer."
    },
    {
      "verse": "12",
      "text": "gerahs will be equal to one shekel. 60 shekels will be equal to one mina."
    },
    {
      "verse": "13",
      "text": "This is the offering that you must give. Take from your harvest one homer from every 60 homers of wheat or barley."
    },
    {
      "verse": "14",
      "text": "litres."
    },
    {
      "verse": "15",
      "text": "sheep that feed on the grass in Israel. These gifts will be for grain offerings, for burnt offerings and for friendship offerings. These offerings will cause me to forgive you for your sins. I, the Almighty Lord, tell you to do this."
    },
    {
      "verse": "16",
      "text": "All Israel's people must bring these offerings to the ruler of Israel."
    },
    {
      "verse": "17",
      "text": "The ruler must provide the animals for the burnt offerings. He must provide the grain for the grain offerings and the wine for the wine offerings. He must provide these things for the holy festivals that I have chosen for Israel's people. Those include feasts for the new moon and for the Sabbath days. He must provide these things for the sin offerings, the grain offerings, the burnt offerings and the friendship offerings. They will cause me to forgive the sins of Israel's people."
    },
    {
      "verse": "18",
      "text": "This is what the Almighty Lord says: Each year, on the first day of the first month, you must offer a young bull as a sacrifice. It must not have anything wrong with it. This sacrifice will cause the temple to be clean."
    },
    {
      "verse": "19",
      "text": "The priest will take some of the blood of this sin offering and he will put it on the posts of the temple doors. He must also put some of the blood on the four corners on the top of the altar. He must also put some blood on the gate posts at the entrance to the inside yard of the temple."
    },
    {
      "verse": "20",
      "text": "You must also do this on the seventh day of the first month. That will cause me to forgive anyone who has done a wrong thing by mistake. Perhaps they did not know that it was a sin. In this way you will make the temple a clean place for me."
    },
    {
      "verse": "21",
      "text": "Each year, on the 14th day of the first month, you must start the Passover festival. The festival will continue for seven days. During that time you must not eat any bread that has yeast in it."
    },
    {
      "verse": "22",
      "text": "On the first day of the festival, the ruler must provide a bull as a sin offering. It is an offering for himself and for all the people of Israel."
    },
    {
      "verse": "23",
      "text": "Every day of the feast he must provide seven young bulls and seven male sheep for burnt offerings to the Lord. The animals must have nothing wrong with them. Each day of the festival, he must also give a male goat as a sin offering."
    },
    {
      "verse": "24",
      "text": "With each bull and each sheep, the ruler must also provide an ephah of grain. He must provide a hin of olive oil with each ephah of grain."
    },
    {
      "verse": "25",
      "text": "You will have another festival that starts on the 15th day of the 7th month. It will continue for seven days. Each day, the ruler must provide the same things for sin offerings, burnt offerings and grain offerings, as well as the olive oil. ’"
    }
  ],
  "46": [
    {
      "verse": "1",
      "text": "‘This is what the Almighty Lord says: The gate of the temple's inside yard that opens to the east must stay shut for the six days that you work. You must only open it on each Sabbath day and on the day of each new moon."
    },
    {
      "verse": "2",
      "text": "On those days, the ruler will go through the entrance room for this gate. It is his way in from the outside yard. He must stand beside the posts of the gate. The priests will then offer the ruler's burnt offering and his friendship offerings. The ruler will bend down low to worship me while he stands at the gate. Then he will go out. But they must not shut the gate until the evening."
    },
    {
      "verse": "3",
      "text": "On Sabbath days and on new moon days, the people must stand in front of the east gate. They will bend down low to worship me, the Lord."
    },
    {
      "verse": "4",
      "text": "Every Sabbath day, the ruler will bring six lambs and a male sheep as a burnt offering to the Lord. These animals must have nothing wrong with them."
    },
    {
      "verse": "5",
      "text": "The ruler will also bring grain offerings. He will offer an ephah of grain with the male sheep. For each of the lambs, he may give as much grain as he chooses. For each ephah of grain, he will offer a hin of olive oil."
    },
    {
      "verse": "6",
      "text": "On the day of the new moon the ruler must offer a young bull, six lambs and a male sheep. These animals must have nothing wrong with them."
    },
    {
      "verse": "7",
      "text": "He will also bring grain offerings. He will offer an ephah of grain with the bull and an ephah with the sheep. For each of the lambs, he may give as much grain as he chooses. For each ephah of grain, he will offer a hin of olive oil."
    },
    {
      "verse": "8",
      "text": "When the ruler goes in, he must go through the gate's entrance room. And he must go out the same way."
    },
    {
      "verse": "9",
      "text": "The people will come to the temple to worship the Lord at the times of the festivals. If they come in through the north gate they must go out through the south gate. And if they come in through the south gate they must go out through the north gate. Nobody may go out of the gate through which he came in. He must go out by the opposite gate."
    },
    {
      "verse": "10",
      "text": "When the people go in, the ruler will go in with them. When the people go out, the ruler will also go out."
    },
    {
      "verse": "11",
      "text": "At the times of festivals and on other special days, the grain offering with each bull and each sheep will be an ephah. For each of the lambs, a person may give as much grain as they choose. They will give a hin of olive oil with each ephah of grain."
    },
    {
      "verse": "12",
      "text": "The ruler may choose to make a special gift to the Lord. It may be a burnt offering or a friendship offering. They must open the east gate of the inside yard for the ruler. He will make his offering at the gate, as he does on Sabbath days. Then he must go out. After he has left, they will shut the gate."
    },
    {
      "verse": "13",
      "text": "Every day, you must provide a lamb that is one year old and that has nothing wrong with it. Offer it to the Lord as a burnt offering. You must do that every morning, day after day."
    },
    {
      "verse": "14",
      "text": "With the lamb, you must give a grain offering. It will be one sixth of an ephah of grain. Mix a third of a hin of olive oil with the flour. This rule about the grain offering to the Lord will never change."
    },
    {
      "verse": "15",
      "text": "You must offer the lamb, with the grain offering and the olive oil, for a burnt offering every morning."
    },
    {
      "verse": "16",
      "text": "This is what the Almighty Lord says: The ruler may choose to give some of his land as a gift to one of his sons. If he does that, the land will belong to his son and to his descendants. It will always belong to their family."
    },
    {
      "verse": "17",
      "text": "The king may also choose to give some of his land to one of his servants. If he does that, the servant can keep the land until the year of Jubilee. After that, the land will belong to the ruler again. The ruler's land will always belong to the ruler and to his descendants."
    },
    {
      "verse": "18",
      "text": "The king must not take for himself any land that belongs to the people. He must not take them away from their own land. He can only give his own land to his sons. Nobody may take any of my people away from the land that belongs to them. ’"
    },
    {
      "verse": "19",
      "text": "The man took me through the entrance beside the gate. We came to the holy rooms that belong to the priests. These rooms opened to the north. He showed me a place at the west end of these rooms."
    },
    {
      "verse": "20",
      "text": "He said to me, ‘This is the place where the priests will cook the meat for the sin offerings and for the guilt offerings. They will bake the grain offerings here, too. In this way, they will not have to take these holy things into the outside yard. If they did that, someone might touch them and become holy. ’"
    },
    {
      "verse": "21",
      "text": "Then the man took me to the outside yard. He took me around the yard to see its four corners. In each corner I saw that there was a small yard"
    },
    {
      "verse": "22",
      "text": "metres long and 15 metres wide. They were all the same size."
    },
    {
      "verse": "23",
      "text": "They had stone walls around them. At the bottom of the walls they had made places for fires to burn."
    },
    {
      "verse": "24",
      "text": "The man said to me, ‘The temple servants will use these kitchens to cook meat that the people bring for sacrifices. ’"
    }
  ],
  "47": [
    {
      "verse": "1",
      "text": "The man brought me back to the entrance of the temple. There I saw water that was pouring out from under the entrance. It was pouring towards the east. (The front entrance of the temple opened towards the east. ) The river of water came from under the south side of the temple. It went past the south side of the altar."
    },
    {
      "verse": "2",
      "text": "The man took me out through the north gate of the temple. We went around the outside to the gate that opens towards the east. There I saw a small stream of water. It was coming out from the south side of the gate."
    },
    {
      "verse": "3",
      "text": "The man went towards the east. He measured 500 metres in that direction. He took me through the water there. The water was as high as my ankles."
    },
    {
      "verse": "4",
      "text": "metres along the stream. He took me through the water again. Here, the water was as high as my knees. He measured another 500 metres. He took me through the water and it was now as high as my belt."
    },
    {
      "verse": "5",
      "text": "metres. Here the water had become a deep river. It was too deep for me to go across. Nobody could walk through it. They would need to swim."
    },
    {
      "verse": "6",
      "text": "The man said to me, ‘Son of man, you must remember what you have seen. ’Then he took me back to the river's edge."
    },
    {
      "verse": "7",
      "text": "When I got there, I saw very many trees. They were on each side of the river."
    },
    {
      "verse": "8",
      "text": "He said to me, ‘This river of water goes towards the land in the east. It goes into the valley of the Jordan River. Then the water goes into the Salt Sea. When it goes into the sea there, the water becomes pure instead of salty."
    },
    {
      "verse": "9",
      "text": "Wherever the river goes, many kinds of animals and fish will live. There will be lots of fish in the Salt Sea because the water that goes in there will make it pure. There will be many living things in places where the river goes."
    },
    {
      "verse": "10",
      "text": "Men will stand on the edge of the sea to catch fish. They will use their nets to catch fish, all the way from En-Gedi to En-Eglaim. They will catch many kinds of fish, like the fish of the Mediterranean Sea."
    },
    {
      "verse": "11",
      "text": "But the water in the pools and the wet places around the Salt Sea will not become pure. There will still be salt for people there."
    },
    {
      "verse": "12",
      "text": "All kinds of fruit trees will live on each side of the river. Their leaves will never become dry. They will always give fruit every month. This is because the water that feeds them comes from the holy temple. The fruit from these trees will provide food. And their leaves will make sick people well. ’"
    },
    {
      "verse": "13",
      "text": "This is what the Almighty Lord says: ‘This is the land that you will share among Israel's 12 tribes. Give one part to each tribe, but Joseph's descendants will have two parts."
    },
    {
      "verse": "14",
      "text": "Share the land in equal parts for each tribe. I promised your ancestors that I would give them this land to live in. So now it will belong to you and your descendants."
    },
    {
      "verse": "15",
      "text": "These will be the borders of your land: The north border goes from the Mediterranean Sea to the city of Hethlon. It continues to go east, past Lebo-Hamath and to Zedad."
    },
    {
      "verse": "16",
      "text": "From there, it continues through Berothah and Sibraim. Those towns are on the border between Damascus and Hamath. Then it goes as far as Hazer-Hattikon, which is on the border of Hauran."
    },
    {
      "verse": "17",
      "text": "The border goes from the Mediterranean Sea to Hazar-Enan. The border of Hamath is on the north side and the border of Damascus is on the south side. That is the north border of your land."
    },
    {
      "verse": "18",
      "text": "On the east side, the border of your land is the Jordan River. It starts between Hauran and Damascus. It goes between the region of Gilead and Israel's land, past the Salt Sea as far as Tamar. That is the east border."
    },
    {
      "verse": "19",
      "text": "On the south side, the border goes from Tamar to the springs of water near Meribath Kadesh. Then it goes along the Stream at Egypt's border to the Mediterranean Sea. That is the south border."
    },
    {
      "verse": "20",
      "text": "On the west side, the Mediterranean Sea is the border of your land. It goes north to a place on the west side of Lebo-Hamath. That is the north border of your land."
    },
    {
      "verse": "21",
      "text": "You must share this land among yourselves so that each tribe of Israel receives a part. That is what the Almighty Lord says."
    },
    {
      "verse": "22",
      "text": "Each part that you receive will belong to you and to the foreigners who live among you. Those foreigners have given birth to their own children among you. Accept them as if they were born as Israelites. They must receive land for themselves among Israel's tribes."
    },
    {
      "verse": "23",
      "text": "Give them land among the tribe where they have decided to live. ’That is what the Almighty Lord says."
    }
  ],
  "48": [
    {
      "verse": "1",
      "text": "‘This is the list of Israel's tribes, with the land that each tribe will receive: Dan will receive land at the north border of Israel. Their north border goes east from the Mediterranean Sea along the road to Hethlon, as far as Lebo-Hamath. From there, it goes to Hazar-Enan, on the border between Damascus and Hamath. Dan's part of the land goes all the way from Israel's border in the east to the Mediterranean Sea in the west. Dan will receive land at the north border of Israel. Their north border goes east from the Mediterranean Sea along the road to Hethlon, as far as Lebo-Hamath. From there, it goes to Hazar-Enan, on the border between Damascus and Hamath."
    },
    {
      "verse": "2",
      "text": "South of Dan's land will be the land for Asher."
    },
    {
      "verse": "3",
      "text": "South of Asher's land will be the land for Naphtali."
    },
    {
      "verse": "4",
      "text": "South of Naphtali's land will be the land for Manasseh."
    },
    {
      "verse": "5",
      "text": "South of Manasseh's land will be the land for Ephraim."
    },
    {
      "verse": "6",
      "text": "South of Ephraim's land will be the land for Reuben."
    },
    {
      "verse": "7",
      "text": "South of Reuben's land will be the land for Judah."
    },
    {
      "verse": "8",
      "text": "South of Judah's land will be a special part of the land, with the temple in the middle of it. From east to west, it will be the same size as the parts of the land for Israel's tribes. From north to south, it will be 12½ kilometres."
    },
    {
      "verse": "9",
      "text": "The part that belongs to the Lord for his temple will be 12½ kilometres long and 10 kilometres wide."
    },
    {
      "verse": "10",
      "text": "The priests will have a part of this holy land. Their part will measure 12½ kilometres from east to west. It will measure 5 kilometres from north to south. The Lord's temple will be in the middle of this part."
    },
    {
      "verse": "11",
      "text": "This holy part of the land will belong to the priests who are descendants of Zadok. They are the priests who served me faithfully. They did not turn away from me as the other Levites did when Israel's people did not obey me."
    },
    {
      "verse": "12",
      "text": "So the priests will have that special part of the land, next to the part for the Levites. The priests' part will be the most holy part of the land."
    },
    {
      "verse": "13",
      "text": "The Levites will also have a special part, south of the part for the priests. It will be the same size. It will measure 12½ kilometres from east to west, and 5 kilometres from north to south. So the land for the priests and for the Levites will be 12½ kilometres from east to west and 10 kilometres from north to south."
    },
    {
      "verse": "14",
      "text": "The special part of the land that belongs to the Lord is the best of the whole land. You must not give his land to anyone else or sell it to anyone else. It is holy and it belongs to the Lord."
    },
    {
      "verse": "15",
      "text": "The other part of the special land is 12½ kilometres from east to west and 2½ kilometres from north to south. That part is not holy. Ordinary people may use it. They may live there and use the fields. There will be a city in the middle of it."
    },
    {
      "verse": "16",
      "text": "The city will be square, 2, 250 metres long on each side."
    },
    {
      "verse": "17",
      "text": "metres wide on each side of the city."
    },
    {
      "verse": "18",
      "text": "There will be two other pieces of land south of the special holy land. There will be a piece 2. 5 kilometres wide on the east side of the city and a piece 2. 5 kilometres wide on the west side. People who live in the city may use these pieces of land to grow crops."
    },
    {
      "verse": "19",
      "text": "There will be people from the different tribes of Israel who live in the city. Any of them may use the land to grow things."
    },
    {
      "verse": "20",
      "text": "The whole of the special land, including the holy part and the part for the city, will be a square. Each side will be 12½ kilometres."
    },
    {
      "verse": "21",
      "text": "The parts of land on each side of the square will belong to the ruler. The part on the east side will go as far as Israel's border in the east. The part on the west side will go as far as the Mediterranean Sea. The holy part of land where the temple is will be in the middle, between them."
    },
    {
      "verse": "22",
      "text": "The land that belongs to the Levites and the priests, as well as the city, will be between the two parts of land that belong to the ruler. The land for Judah will be on the north side of these lands. The land for Benjamin's will be on the south side."
    },
    {
      "verse": "23",
      "text": "The other tribes will each have a part of the land that is south of this special part. The land for each of these tribes will go all the way from Israel's border in the east to the Mediterranean Sea in the west. South of the special land will be the land for Benjamin."
    },
    {
      "verse": "24",
      "text": "South of the Benjamin's land will be the land for Simeon."
    },
    {
      "verse": "25",
      "text": "South of Simeon's land will be the land for Issachar."
    },
    {
      "verse": "26",
      "text": "South of Issachar's land will be the land for Zebulun."
    },
    {
      "verse": "27",
      "text": "South of Zebulun's land will be the land for Gad."
    },
    {
      "verse": "28",
      "text": "The border on the south side of Gad's land goes from Tamar to the springs of water near Meribath Kadesh. From there, it goes along the stream at Egypt's border to the Mediterranean Sea."
    },
    {
      "verse": "29",
      "text": "That is how you must share the land among Israel's tribes. Each part will belong to one tribe and their descendants. I, the Almighty Lord, say this."
    },
    {
      "verse": "30",
      "text": "These will be the entrance gates on each side of the city. The wall on the north side of the city will be 2, 250 metres long. From that time on, the name of the city will be, “The Lord is there. ” ’"
    },
    {
      "verse": "31",
      "text": "There will be three gates on that side. Each gate will have the name of one of Israel's tribes, one for Reuben, the next for Judah, and the next for Levi."
    },
    {
      "verse": "32",
      "text": "The wall on the east side will also be 2, 250 metres long. The three gates on that side will be for Joseph, for Benjamin and for Dan."
    },
    {
      "verse": "33",
      "text": "The wall on the south side will also be 2, 250 metres long. The three gates on that side will be for Simeon, for Issachar and for Zebulun."
    },
    {
      "verse": "34",
      "text": "The wall on the west side will also be 2, 250 metres long. The three gates on that side will be for Gad, for Asher and for Naphtali."
    },
    {
      "verse": "35",
      "text": "So the walls all around the city will measure 9, 000 metres. From that time on, the name of the city will be, “The Lord is there. ” ’"
    }
  ]
};