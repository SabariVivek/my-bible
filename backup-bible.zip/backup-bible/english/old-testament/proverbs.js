module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "These are the proverbs of Solomon, David's son, king of Israel."
    },
    {
      "verse": "2",
      "text": "These are proverbs that will make you wise. They will help you to learn things and to understand good teaching."
    },
    {
      "verse": "3",
      "text": "They will help you to understand how to live a good life. They will teach you how to live as a person who is good, honest and fair."
    },
    {
      "verse": "4",
      "text": "They can cause even silly people to become clever. They teach young people what they should know, so that they can live well."
    },
    {
      "verse": "5",
      "text": "Wise people should also listen carefully, so that they learn something new. And people with clever minds can learn to live in a good way."
    },
    {
      "verse": "6",
      "text": "People will learn to understand what proverbs and picture stories mean. They will understand the teaching and clever messages of wise people."
    },
    {
      "verse": "7",
      "text": "If you want to know how to live in a good way, you must first learn to respect the Lord with fear. Fools refuse to listen to wise teaching."
    },
    {
      "verse": "8",
      "text": "Listen, my child, when your father shows you what is right. And do not forget what your mother has taught you."
    },
    {
      "verse": "9",
      "text": "Their teaching will bring you honour, like a beautiful crown or a valuable necklace."
    },
    {
      "verse": "10",
      "text": "My child, if sinners want you to join with them, do not agree!"
    },
    {
      "verse": "11",
      "text": "They may say, ‘Come with us. We will find someone to murder. We will attack any helpless person that we choose."
    },
    {
      "verse": "12",
      "text": "We will send them quickly to their graves. They may be strong and healthy, but they will soon be under the earth."
    },
    {
      "verse": "13",
      "text": "We will take all their valuable things for ourselves. We will fill our houses with lots of good things."
    },
    {
      "verse": "14",
      "text": "So come and join us! We will share with each other everything that we rob from other people. ’"
    },
    {
      "verse": "15",
      "text": "My child, do not go along with people like that. Stay away from them."
    },
    {
      "verse": "16",
      "text": "They are in a hurry to do evil things. They cannot wait to murder someone!"
    },
    {
      "verse": "17",
      "text": "Think about it! If you put a trap where the birds can see it, you will never catch anything."
    },
    {
      "verse": "18",
      "text": "These wicked men hide to attack someone. They are ready to kill someone, but they destroy their own lives!"
    },
    {
      "verse": "19",
      "text": "That is what happens to those who cheat other people to become rich themselves. The riches that they have taken from others will destroy their own lives."
    },
    {
      "verse": "20",
      "text": "Listen! Wisdom is like a woman who shouts in the streets. She speaks loudly in the market places."
    },
    {
      "verse": "21",
      "text": "She shouts above the noise in the city's streets. She calls aloud at its gates. This is what she says:"
    },
    {
      "verse": "22",
      "text": "‘Listen to me! Will you silly people continue to be so silly? You people who laugh at God, will you always be like that? Will fools always refuse to learn anything? Will you silly people continue to be so silly? You people who laugh at God, will you always be like that? Will fools always refuse to learn anything?"
    },
    {
      "verse": "23",
      "text": "Listen to me as I warn you of danger! Then I will let you know my thoughts. I will let you hear my message. Then I will let you know my thoughts. I will let you hear my message."
    },
    {
      "verse": "24",
      "text": "I called out to you, but you refused to listen. I reached out to you, but you turned your backs to me. I reached out to you, but you turned your backs to me."
    },
    {
      "verse": "25",
      "text": "You would not accept my teaching. When I warned you, you did nothing. When I warned you, you did nothing."
    },
    {
      "verse": "26",
      "text": "So, when trouble comes to you, I will laugh. I will laugh at you when you are afraid. I will laugh at you when you are afraid."
    },
    {
      "verse": "27",
      "text": "Fear may hit you like a strong wind. Trouble may knock you down, like a storm. Your problems may make you very afraid. But I will laugh at you. Trouble may knock you down, like a storm. Your problems may make you very afraid. But I will laugh at you."
    },
    {
      "verse": "28",
      "text": "Foolish people will call to me for help, but I will not answer. They will look for me everywhere, but they will not find me. They will look for me everywhere, but they will not find me."
    },
    {
      "verse": "29",
      "text": "They have refused to learn what is right. They have refused to respect the Lord. They have refused to respect the Lord."
    },
    {
      "verse": "30",
      "text": "They have not agreed to my advice. When I warned them, they turned away. When I warned them, they turned away."
    },
    {
      "verse": "31",
      "text": "So now they will receive the trouble that they deserve. Their own wicked ideas will make them sick. Their own wicked ideas will make them sick."
    },
    {
      "verse": "32",
      "text": "Silly people have turned away from me, and that will kill them. Fools like an easy life, and that will destroy them. Fools like an easy life, and that will destroy them."
    },
    {
      "verse": "33",
      "text": "But whoever listens to me, Wisdom, will live safely. That person will have peace in his mind. He will not be afraid of trouble. ’"
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "My child, listen to my teaching. Think about my commands."
    },
    {
      "verse": "2",
      "text": "Listen carefully, so that you understand what wisdom really is."
    },
    {
      "verse": "3",
      "text": "Yes, always try to learn what is right. Never stop trying to understand."
    },
    {
      "verse": "4",
      "text": "Look for wisdom as carefully as you would look for silver, or valuable jewels."
    },
    {
      "verse": "5",
      "text": "Then you will understand how to respect the Lord with fear. You will learn all about God."
    },
    {
      "verse": "6",
      "text": "It is the Lord who gives wisdom to people. He teaches us to understand things, so that we know what is true."
    },
    {
      "verse": "7",
      "text": "He helps good people to be wise in how they live. And he keeps honest people safe."
    },
    {
      "verse": "8",
      "text": "He protects the lives of righteous people. He takes care of people who serve him faithfully."
    },
    {
      "verse": "9",
      "text": "So learn from God. Then you will understand what is right, true and fair. You will know the best way to live."
    },
    {
      "verse": "10",
      "text": "You will become wise in your thoughts. Your knowledge of what is right will make you happy."
    },
    {
      "verse": "11",
      "text": "You will know the right thing to do, and that will keep you safe."
    },
    {
      "verse": "12",
      "text": "You will not join with wicked people. You will keep away from those who speak false things."
    },
    {
      "verse": "13",
      "text": "Those people no longer follow honest ways. They live in dark places."
    },
    {
      "verse": "14",
      "text": "They enjoy doing wicked and evil things."
    },
    {
      "verse": "15",
      "text": "They only do wrong things. They are always deceiving others."
    },
    {
      "verse": "16",
      "text": "If you have wisdom, you will not listen to the sweet words of a prostitute. A woman who likes to have sex with many men will not deceive you."
    },
    {
      "verse": "17",
      "text": "That kind of woman leaves her own husband. She married him when she was young. Now she forgets what she promised to God at the time of her marriage."
    },
    {
      "verse": "18",
      "text": "Do not go into her house! If you do, you will be on the road to death. If you follow her, you will arrive at the home of the spirits of dead people."
    },
    {
      "verse": "19",
      "text": "Anybody who visits her will never return. He will never find the way back to a good life."
    },
    {
      "verse": "20",
      "text": "If you have wisdom, you will enjoy life, as good people do. You will live as righteous people live."
    },
    {
      "verse": "21",
      "text": "Good and honest people will continue to live in our land."
    },
    {
      "verse": "22",
      "text": "But God will remove wicked people from the land. He will throw out all those who are not faithful."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "My child, do not forget what I teach you. Always think carefully about my commands."
    },
    {
      "verse": "2",
      "text": "If you obey them, you will live a long life. You will have peace in your mind. and you will enjoy your life."
    },
    {
      "verse": "3",
      "text": "Keep hold of faithful love. That will be like a beautiful necklace that you always wear. Think about what it means to love other people."
    },
    {
      "verse": "4",
      "text": "If you do that, you will make God happy. People will also be pleased and they will respect you."
    },
    {
      "verse": "5",
      "text": "Trust in the Lord completely. Do not think that you understand things well enough for yourself."
    },
    {
      "verse": "6",
      "text": "Whatever you are doing, remember that the Lord is with you. Then he will show you the right way to go."
    },
    {
      "verse": "7",
      "text": "Do not think that you are already wise enough. Obey the Lord and refuse to do evil things."
    },
    {
      "verse": "8",
      "text": "If you do that, it will make you healthy and strong."
    },
    {
      "verse": "9",
      "text": "Show that you respect the Lord in the way that you use your money. Offer the first part of the harvest from your farm to him."
    },
    {
      "verse": "10",
      "text": "If you do that, you will store more food than you need for yourself. You will have more wine than you can drink."
    },
    {
      "verse": "11",
      "text": "My child, if the Lord warns you that you have done something wrong, accept it. Do not be upset if he warns you."
    },
    {
      "verse": "12",
      "text": "He is doing it because he loves you. When a father loves his son very much, he warns him when he does something wrong."
    },
    {
      "verse": "13",
      "text": "Anyone who finds wisdom is in a happy place! So is the person who has learned to understand things."
    },
    {
      "verse": "14",
      "text": "Wisdom helps people better than silver or gold will ever help them."
    },
    {
      "verse": "15",
      "text": "Wisdom is more valuable than the most expensive jewels. Nothing that you might want for yourself is as good as wisdom. Nothing that you might want for yourself is as good as wisdom."
    },
    {
      "verse": "16",
      "text": "Wisdom is ready to give you a long life. She will also give you riches and honour."
    },
    {
      "verse": "17",
      "text": "Wisdom will be your guide through a happy life. She will lead you in ways that keep you safe."
    },
    {
      "verse": "18",
      "text": "Wisdom is like a tree with fruits that give life to the people who pick them. The Lord blesses everyone who keeps hold of wisdom."
    },
    {
      "verse": "19",
      "text": "The Lord used wisdom to create the earth. He understood the right way to create the heavens."
    },
    {
      "verse": "20",
      "text": "He used his knowledge to pour water from under the earth into the rivers and seas. He caused the clouds to send down rain."
    },
    {
      "verse": "21",
      "text": "My child, always keep hold of wisdom and a good mind. Make sure that you keep them safe."
    },
    {
      "verse": "22",
      "text": "They will give you strength in life. You will enjoy life, like a beautiful necklace that you wear."
    },
    {
      "verse": "23",
      "text": "You will be safe as you travel through life. There will be no danger to make you fall down."
    },
    {
      "verse": "24",
      "text": "When you lie down to sleep, you will not be afraid. You will sleep well with peace in your mind."
    },
    {
      "verse": "25",
      "text": "You will not be frightened of any trouble that might surprise you. Trouble may destroy wicked people, but you will know that you are safe."
    },
    {
      "verse": "26",
      "text": "The Lord is the one who will take care of you. He will protect you, so that no danger can hurt you."
    },
    {
      "verse": "27",
      "text": "Do not refuse to help those people who need help. If you are able to help them, do it!"
    },
    {
      "verse": "28",
      "text": "If you can give your neighbour the help that he needs, do not say to him, ‘Go away! Come back tomorrow, and then I will help you. ’"
    },
    {
      "verse": "29",
      "text": "Do not think of ways to hurt your neighbour. You should help him to trust you."
    },
    {
      "verse": "30",
      "text": "Do not quarrel with other people if they have done nothing to hurt you. You have no reason to accuse them of anything wrong."
    },
    {
      "verse": "31",
      "text": "Do not be jealous of cruel people. Do not try to copy the things that they do."
    },
    {
      "verse": "32",
      "text": "The Lord hates wicked people. But he makes righteous people his friends."
    },
    {
      "verse": "33",
      "text": "The Lord curses the homes of wicked people, but he blesses the homes of righteous people."
    },
    {
      "verse": "34",
      "text": "The Lord laughs at proud people who laugh at other people. But he is kind to humble people."
    },
    {
      "verse": "35",
      "text": "Wise people will receive honour. But fools will only have shame."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "My children, listen to what your father teaches you. Listen carefully so that you understand what is right."
    },
    {
      "verse": "2",
      "text": "My teaching will help you, so do not refuse it."
    },
    {
      "verse": "5",
      "text": "Learn to be wise and to understand things properly. Do not forget my teaching or turn away from it. Do not forget my teaching or turn away from it."
    },
    {
      "verse": "6",
      "text": "If you keep hold of wisdom, she will keep you safe. She will protect you if you love her. She will protect you if you love her."
    },
    {
      "verse": "7",
      "text": "Learn to be wise, because wisdom is the most important thing to have. Make sure that you learn to understand things well. Make sure that you learn to understand things well."
    },
    {
      "verse": "8",
      "text": "Respect wisdom as very valuable, then she will make you great. If you make her your friend, she will give you honour. If you make her your friend, she will give you honour."
    },
    {
      "verse": "9",
      "text": "Wisdom will bless you, as if you are wearing a beautiful crown on your head. ’"
    },
    {
      "verse": "10",
      "text": "So listen to me, my child, and accept my teaching. If you do, the years of your life will be many."
    },
    {
      "verse": "11",
      "text": "I am teaching you to be wise, so that you will know the right way to live."
    },
    {
      "verse": "12",
      "text": "As you walk through life, nothing will stop you. Even when you run, you will not fall."
    },
    {
      "verse": "13",
      "text": "Keep hold of my teaching. Do not forget it. Keep it safe because it will give you a good life."
    },
    {
      "verse": "14",
      "text": "Do not join with wicked or evil people. Do not do the things that they do."
    },
    {
      "verse": "15",
      "text": "Keep away from them! Be sure to keep to your own good way of life."
    },
    {
      "verse": "16",
      "text": "Wicked people have to do evil things. They cannot go to sleep unless they have been cruel to someone that day."
    },
    {
      "verse": "17",
      "text": "Evil acts are their food. Violence is their drink."
    },
    {
      "verse": "18",
      "text": "The life of righteous people is like the sun at dawn. It gets brighter and brighter until midday."
    },
    {
      "verse": "19",
      "text": "But the life of wicked people is like a very dark road. They cannot even see what causes them to fall."
    },
    {
      "verse": "20",
      "text": "My child, listen carefully to my teaching and to everything that I tell you."
    },
    {
      "verse": "21",
      "text": "Never forget my words. Keep them safe in your mind."
    },
    {
      "verse": "22",
      "text": "They will give true life to anyone who takes hold of them. They will give health to your whole body."
    },
    {
      "verse": "23",
      "text": "Be very careful to keep your mind safe. The thoughts that you think make you the person that you are."
    },
    {
      "verse": "24",
      "text": "Never tell lies or try to deceive other people."
    },
    {
      "verse": "25",
      "text": "Look straight in front of you to see clearly where you are going."
    },
    {
      "verse": "26",
      "text": "Decide carefully where you are going in life. Then you will be on a good, safe path."
    },
    {
      "verse": "27",
      "text": "Do not walk off your path, to the right side or the left side. Keep away from everything that is evil."
    },
    {
      "verse": "3",
      "text": "My father taught me when I was a little boy. My mother loved me as her only child. My father said to me, ‘Think carefully about what I tell you."
    },
    {
      "verse": "4",
      "text": "If you obey my commands, you will live well. ‘Think carefully about what I tell you. If you obey my commands, you will live well."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "My child, listen carefully to the wisdom that I teach you. I will teach you how to understand things well."
    },
    {
      "verse": "2",
      "text": "If you learn this, you will choose to do the right things in life. Your words will show that you are wise."
    },
    {
      "verse": "3",
      "text": "Do not listen to the words of an adulteress. She promises something as sweet as honey and as beautiful as olive oil."
    },
    {
      "verse": "4",
      "text": "But in the end, she gives you bitter food, like poison. She gives you pain like a sharp sword."
    },
    {
      "verse": "5",
      "text": "She will lead you down to the place of death. You will follow her to your grave!"
    },
    {
      "verse": "6",
      "text": "She does not think about the way that leads to true life. She has lost the right road but she does not understand what she is doing."
    },
    {
      "verse": "7",
      "text": "So listen to me, my children. Never forget what I am telling you."
    },
    {
      "verse": "8",
      "text": "Keep far away from a woman like that! Do not even go near the door of her house."
    },
    {
      "verse": "9",
      "text": "If you go with her, you will lose your honour. A cruel person will rob you of the best years of your life."
    },
    {
      "verse": "10",
      "text": "Strangers will take all your money. The good things that you have worked for will belong to someone else."
    },
    {
      "verse": "11",
      "text": "At the end of your life, you will weep with pain. Your body will be sick and weak."
    },
    {
      "verse": "12",
      "text": "You will say, ‘I should have listened when people warned me that I was doing bad things."
    },
    {
      "verse": "13",
      "text": "I did not listen to my teachers. I refused to obey them."
    },
    {
      "verse": "14",
      "text": "Now I will be completely ashamed when I meet together with all the people. ’"
    },
    {
      "verse": "15",
      "text": "You should enjoy your own wife, as you enjoy clean water to drink."
    },
    {
      "verse": "16",
      "text": "You would not pour your good water onto the streets. So do not waste your love on other women."
    },
    {
      "verse": "17",
      "text": "Keep it for you and your wife. Do not share it with other women."
    },
    {
      "verse": "18",
      "text": "Enjoy sex with your own wife. May the wife that you married when you were young continue to give you joy."
    },
    {
      "verse": "19",
      "text": "May she be as pretty and beautiful as a young deer. May her breasts always make you happy. May she love you in a way that gives you joy."
    },
    {
      "verse": "20",
      "text": "So my son, do not let an adulteress deceive you. Do not enjoy the body of another man's wife."
    },
    {
      "verse": "21",
      "text": "The Lord sees everything that a person does. He knows every path that you go along."
    },
    {
      "verse": "22",
      "text": "The sins of a wicked person will be the trap that catches him. They will hold him like strong ropes."
    },
    {
      "verse": "23",
      "text": "He cannot control his sins, so he will die. He will become lost, because he does such stupid things."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "My child, be careful not to promise more than you can really do. You may have promised to pay the debts of a friend or of a stranger."
    },
    {
      "verse": "2",
      "text": "Then what you have promised to do may become a trap that catches you."
    },
    {
      "verse": "3",
      "text": "Now you need to escape from your problem. Your friend has got power over you. So you must be humble. Go quickly to him and ask him to forgive the debt."
    },
    {
      "verse": "4",
      "text": "Do not let yourself sleep or even stop to rest until you have met with him."
    },
    {
      "verse": "5",
      "text": "You must make yourself free from the trap. Escape quickly, like a bird or a deer that runs away from a hunter."
    },
    {
      "verse": "6",
      "text": "Learn a lesson from the ants, you lazy person! See how hard they work."
    },
    {
      "verse": "7",
      "text": "They have no leader or ruler,"
    },
    {
      "verse": "8",
      "text": "but they get their food during the summer. At the time of harvest they store food to prepare for winter."
    },
    {
      "verse": "9",
      "text": "But you, you lazy man, you lie in bed too long! Will you never get up to work?"
    },
    {
      "verse": "10",
      "text": "You say, ‘I will have a short sleep. I will rest quietly for a while. ’"
    },
    {
      "verse": "11",
      "text": "But while you sleep you will suddenly become poor. You will have nothing, as if someone has robbed you."
    },
    {
      "verse": "12",
      "text": "A useless, wicked person is always deceiving people."
    },
    {
      "verse": "13",
      "text": "He sends secret messages with his eyes, his feet or his fingers."
    },
    {
      "verse": "14",
      "text": "He uses evil thoughts to decide how he will hurt people. Wherever he goes, there is trouble."
    },
    {
      "verse": "15",
      "text": "Because of this, trouble will suddenly happen to him. It will knock him down and he will never get up again."
    },
    {
      "verse": "16",
      "text": "There are six things that the Lord hates, or even seven things:"
    },
    {
      "verse": "17",
      "text": "Eyes that show how proud a person is. A mouth that speaks lies. Hands that kill people who have done nothing wrong."
    },
    {
      "verse": "18",
      "text": "A mind that chooses to do wicked things. Feet that hurry to do evil things."
    },
    {
      "verse": "19",
      "text": "A person who tells lies in court. A person who causes trouble in a family."
    },
    {
      "verse": "20",
      "text": "My child, obey your father's commands. Do not forget what your mother has taught you."
    },
    {
      "verse": "21",
      "text": "Keep their teaching in your thoughts. Keep it as near to you as a necklace that you wear."
    },
    {
      "verse": "22",
      "text": "Wherever you go in life, their words will be your guide. They will keep you safe while you sleep. When you wake up, they will teach you."
    },
    {
      "verse": "23",
      "text": "Their commands and their teaching are like a lamp that gives you light. When they warn you that you are doing wrong things, that helps you to live well."
    },
    {
      "verse": "24",
      "text": "They will keep you safe from any bad woman, so that the sweet words of an adulteress will not deceive you."
    },
    {
      "verse": "25",
      "text": "Do not keep thinking how beautiful her body is. Do not let her use her eyes like a trap to catch you."
    },
    {
      "verse": "26",
      "text": "If you sleep with a prostitute, that may cost the price of a meal. But if you sleep with another man's wife, you may pay with your life."
    },
    {
      "verse": "27",
      "text": "You cannot carry fire next to your body and not burn your clothes."
    },
    {
      "verse": "28",
      "text": "You cannot walk over hot pieces of coal and not burn your feet."
    },
    {
      "verse": "29",
      "text": "It is the same when a man has sex with another man's wife. Anyone who does that will receive punishment that hurts him."
    },
    {
      "verse": "30",
      "text": "People may excuse someone who steals food because he is hungry."
    },
    {
      "verse": "31",
      "text": "But if someone catches him, he must pay back seven times what he took. He may lose everything that he has in his house."
    },
    {
      "verse": "32",
      "text": "But a man who sleeps with another man's wife is stupid. He is destroying his own life."
    },
    {
      "verse": "33",
      "text": "He deserves his punishment and shame. He will never stop being ashamed."
    },
    {
      "verse": "34",
      "text": "The woman's husband will be jealous, and he will become very angry. He will want the man to receive full punishment."
    },
    {
      "verse": "35",
      "text": "He will not accept any money or bribe to pay the debt, even if it is a lot of money."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "My child, remember what I say. Keep my commands in your mind."
    },
    {
      "verse": "2",
      "text": "Obey my commands, so that you live well. Keep my teaching safe. It is as valuable as your own eyes."
    },
    {
      "verse": "3",
      "text": "Keep it always in front of you. Think about my message all the time, as if you have written it on your heart."
    },
    {
      "verse": "4",
      "text": "Love wisdom in the same way that you love your sister. Be very careful to understand what is right."
    },
    {
      "verse": "5",
      "text": "If you do that, it will keep you safe from sin. You will not agree to sleep with an adulteress or a prostitute when she speaks sweet words to you."
    },
    {
      "verse": "6",
      "text": "Once I was looking out through the window of my house."
    },
    {
      "verse": "7",
      "text": "I saw a group of silly young men. One of them was not wise at all."
    },
    {
      "verse": "8",
      "text": "He was walking along the street near the house of a bad woman."
    },
    {
      "verse": "9",
      "text": "It was in the evening after it had become dark."
    },
    {
      "verse": "10",
      "text": "Then the woman came out to meet him! She was wearing the clothes of a prostitute. She knew what she wanted to do."
    },
    {
      "verse": "11",
      "text": "This was a woman who did not respect anyone. She was not ashamed of the bad things that she did. She never stayed at her home."
    },
    {
      "verse": "12",
      "text": "Instead she would stand in the streets and in the market place. She would wait at the corners of the streets to find a man."
    },
    {
      "verse": "13",
      "text": "Now she took hold of the young man and she kissed him. She looked into his eyes without any shame."
    },
    {
      "verse": "14",
      "text": "She said to him, ‘I offered a sacrifice to God today and I have the meat at my home."
    },
    {
      "verse": "15",
      "text": "That is why I came out to meet you. I was looking for you, and now I have found you!"
    },
    {
      "verse": "16",
      "text": "I have covered my bed with beautiful blankets and with valuable cloths from Egypt."
    },
    {
      "verse": "17",
      "text": "I have splashed many kinds of perfume on my bed, like myrrh, aloes and cinnamon."
    },
    {
      "verse": "18",
      "text": "So come and join me for the night. We can lie in each other's arms. All night, we can enjoy as much sex as we like."
    },
    {
      "verse": "19",
      "text": "My husband is not at home. He has gone away on a long journey."
    },
    {
      "verse": "20",
      "text": "He took a big bag of money with him. He will not come back until later this month. ’"
    },
    {
      "verse": "21",
      "text": "With those sweet words she deceived the young man. She made him want to be with her."
    },
    {
      "verse": "22",
      "text": "Suddenly he hurried to follow her! He went like an ox that men are leading to its death. He went like a deer that is running towards a trap."
    },
    {
      "verse": "23",
      "text": "Then an arrow will go straight into its body and kill it! The young man was like a bird that is flying into a trap. He did not know that his life was in danger."
    },
    {
      "verse": "24",
      "text": "So listen to me, my sons. Listen carefully to what I am saying."
    },
    {
      "verse": "25",
      "text": "Do not let that kind of woman spoil your mind. Do not let her lead you away from what is right."
    },
    {
      "verse": "26",
      "text": "She has caused many men to fall. Because of her, too many men have thrown away their lives."
    },
    {
      "verse": "27",
      "text": "If you go to her house, you are on the road to death. You will soon be in your grave."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Listen! Wisdom is calling out. She wants you to understand what is right, so she speaks in a loud voice."
    },
    {
      "verse": "2",
      "text": "She stands where people will hear her, on the hills along the road. She stands where different paths meet."
    },
    {
      "verse": "3",
      "text": "She stands near the gates where people go into the city. This is what she says:"
    },
    {
      "verse": "4",
      "text": "‘I call out to all of you, wherever you live on earth."
    },
    {
      "verse": "5",
      "text": "You who are silly, learn to be wise! You who are fools, learn to understand what is right. You who are fools, learn to understand what is right."
    },
    {
      "verse": "6",
      "text": "Listen! I have important things to tell you. Everything that I will speak is right. Everything that I will speak is right."
    },
    {
      "verse": "7",
      "text": "I say only things that are true. I hate all wicked lies. I hate all wicked lies."
    },
    {
      "verse": "8",
      "text": "Everything that I say is right and true. I say nothing that will deceive you. I say nothing that will deceive you."
    },
    {
      "verse": "9",
      "text": "If you understand what is right, you will understand all my words. If you have knowledge, you will know that they are true. If you have knowledge, you will know that they are true."
    },
    {
      "verse": "10",
      "text": "Receive my wise teaching and knowledge as valuable things. They are more valuable than silver or the best gold. They are more valuable than silver or the best gold."
    },
    {
      "verse": "11",
      "text": "Wisdom is more valuable than jewels. Nothing that you might ever want is equal to it. Nothing that you might ever want is equal to it."
    },
    {
      "verse": "12",
      "text": "I, wisdom, live with an honest mind as my friend. I have knowledge and I understand what is right. I have knowledge and I understand what is right."
    },
    {
      "verse": "13",
      "text": "If you respect the Lord with fear, then you will hate anything that is evil. I hate proud people who boast. I hate people who live evil lives. I hate people who say things to deceive others. I hate proud people who boast. I hate people who live evil lives. I hate people who say things to deceive others."
    },
    {
      "verse": "14",
      "text": "I tell people how to do wise things that are right. I understand what is right and I am strong. I understand what is right and I am strong."
    },
    {
      "verse": "15",
      "text": "I help kings to rule well. I help rulers to make fair laws. I help rulers to make fair laws."
    },
    {
      "verse": "16",
      "text": "I help leaders, officers and all judges to lead people in a good way."
    },
    {
      "verse": "17",
      "text": "I love those people who love me. Whoever looks for me will find me. Whoever looks for me will find me."
    },
    {
      "verse": "18",
      "text": "I am able to give people riches and honour. I help people to use their money well and to do what is right. I help people to use their money well and to do what is right."
    },
    {
      "verse": "19",
      "text": "What you receive from me is better than the best gold. It is better than the best silver. It is better than the best silver."
    },
    {
      "verse": "20",
      "text": "I walk along the way that is righteous. I follow the path of justice. I follow the path of justice."
    },
    {
      "verse": "21",
      "text": "In that way, people who love me will receive riches. I fill their houses with valuable things. I fill their houses with valuable things."
    },
    {
      "verse": "22",
      "text": "The Lord created me as the first thing that he did. That was the first of his acts long ago. That was the first of his acts long ago."
    },
    {
      "verse": "23",
      "text": "He chose me as his servant from the beginning of time. That was before the world began. That was before the world began."
    },
    {
      "verse": "24",
      "text": "I was born before the deep seas were there. There were not yet springs that poured out water. There were not yet springs that poured out water."
    },
    {
      "verse": "25",
      "text": "I was born before the mountains or the hills appeared in their places."
    },
    {
      "verse": "26",
      "text": "I was born before the Lord made the earth and its fields, before there was soil on the earth. before there was soil on the earth."
    },
    {
      "verse": "27",
      "text": "I was there when he put the heavens in their place. I was there when he made the border of the sea where it meets the sky. I was there when he made the border of the sea where it meets the sky."
    },
    {
      "verse": "28",
      "text": "I was there when he put the clouds in the sky. I was there when he made streams of water fill the seas. I was there when he made streams of water fill the seas."
    },
    {
      "verse": "29",
      "text": "He gave his command to the seas, that they should obey him. The waters of the sea must stay inside its borders. I was there when he built the foundations of the earth. The waters of the sea must stay inside its borders. I was there when he built the foundations of the earth."
    },
    {
      "verse": "30",
      "text": "When the Lord made all that happen, I was beside him as his faithful helper. I pleased him every day, and I was happy to be with him. I was beside him as his faithful helper. I pleased him every day, and I was happy to be with him."
    },
    {
      "verse": "31",
      "text": "The world that he had made gave me great joy. The people who lived on it made me happy. The people who lived on it made me happy."
    },
    {
      "verse": "32",
      "text": "So listen to me, my children. Anyone who obeys my teaching will be happy. Anyone who obeys my teaching will be happy."
    },
    {
      "verse": "33",
      "text": "Listen when I tell you what is right for you to do. Then you will be wise. Do not forget what I tell you. Then you will be wise. Do not forget what I tell you."
    },
    {
      "verse": "34",
      "text": "Anyone who listens to me is in a happy place. You can wait outside my home each day, and I will teach you. You can wait outside my home each day, and I will teach you."
    },
    {
      "verse": "35",
      "text": "Anyone who finds me, wisdom, finds true life. The Lord will bless that person. The Lord will bless that person."
    },
    {
      "verse": "36",
      "text": "But anyone who does not find me brings trouble on himself. Everybody who hates me loves death. ’"
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "The woman who is called ‘Wisdom’ has built her house with seven pillars to make it strong."
    },
    {
      "verse": "2",
      "text": "She has killed an animal for a big meal. She has mixed her wine. She has also prepared her table."
    },
    {
      "verse": "3",
      "text": "She has sent her servants to shout a message from the highest places in the town."
    },
    {
      "verse": "4",
      "text": "She says to foolish people, ‘Come here to me. ’She says to people who do not understand what is right,"
    },
    {
      "verse": "5",
      "text": "‘Come here and eat my food. Drink the wine that I have mixed."
    },
    {
      "verse": "6",
      "text": "Leave foolish ways so that you may live. Learn to understand what is right, so that you can do it. ’"
    },
    {
      "verse": "7",
      "text": "If you warn a person who is proud, he will insult you. If you tell a wicked person that he is wrong, he will hurt you."
    },
    {
      "verse": "8",
      "text": "So do not warn proud people. They will only hate you. But if you warn a wise person, he will love you."
    },
    {
      "verse": "9",
      "text": "If you teach a wise person, he will become even more wise. If you teach a righteous person, he will learn whatever you tell him."
    },
    {
      "verse": "10",
      "text": "If you want to be wise in the way that you live, first you must respect the Lord with fear. If you know God, the Holy One, you will understand what is right."
    },
    {
      "verse": "11",
      "text": "Wisdom will add more days and years to your life."
    },
    {
      "verse": "12",
      "text": "If you are wise, it will help you in many ways. But if you think that you do not need wisdom, you will bring trouble on yourself."
    },
    {
      "verse": "13",
      "text": "The woman who is called ‘Fool’ speaks in a loud voice. She is silly and she does not know anything."
    },
    {
      "verse": "14",
      "text": "She sits at the door of her house. She also has a seat at the highest part of the city."
    },
    {
      "verse": "15",
      "text": "She shouts her message to people as they pass along the road to do their work."
    },
    {
      "verse": "16",
      "text": "She says to people who do not understand what is right, ‘Anyone who is foolish should come in here."
    },
    {
      "verse": "17",
      "text": "If you drink water that belongs to someone else, it tastes very sweet! If you eat food secretly, it tastes better than anything! So come and enjoy my meal! ’"
    },
    {
      "verse": "18",
      "text": "But those foolish people do not realize that her home is a place for dead people. Her visitors are already in their graves."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "These are the proverbs of Solomon. A wise child makes his father happy. But a foolish child causes his mother to be sad. A wise child makes his father happy. But a foolish child causes his mother to be sad."
    },
    {
      "verse": "2",
      "text": "If you are not honest, your money will not help you. But if you are righteous, it will save you from death. But if you are righteous, it will save you from death."
    },
    {
      "verse": "3",
      "text": "The Lord will not let righteous people be hungry. But he will not let bad people get what they want. But he will not let bad people get what they want."
    },
    {
      "verse": "4",
      "text": "If a man is lazy, he will soon be poor. But if he works hard, he will become rich. But if he works hard, he will become rich."
    },
    {
      "verse": "5",
      "text": "A wise man cuts his crops at harvest time and he stores them. But anyone who does no work at harvest time brings shame. But anyone who does no work at harvest time brings shame."
    },
    {
      "verse": "6",
      "text": "God blesses righteous people. But the words of wicked people hide their anger. But the words of wicked people hide their anger."
    },
    {
      "verse": "7",
      "text": "It is a pleasure to remember righteous people. But when wicked people die, people soon forget their name. But when wicked people die, people soon forget their name."
    },
    {
      "verse": "8",
      "text": "Wise people accept good teaching. But people who talk in a foolish way destroy themselves. But people who talk in a foolish way destroy themselves."
    },
    {
      "verse": "9",
      "text": "If people are honest, their lives are safe. But those who are not honest will receive punishment. But those who are not honest will receive punishment."
    },
    {
      "verse": "10",
      "text": "Someone who deceives his friends causes trouble. And someone who speaks in foolish ways will destroy himself. And someone who speaks in foolish ways will destroy himself."
    },
    {
      "verse": "11",
      "text": "The teaching of righteous people gives life, like a spring of water. But the words of wicked people hide their anger. But the words of wicked people hide their anger."
    },
    {
      "verse": "12",
      "text": "When people hate others, it causes arguments. But love covers over all sins. But love covers over all sins."
    },
    {
      "verse": "13",
      "text": "People who understand what is right speak wise words. But silly people receive the punishment that they deserve. But silly people receive the punishment that they deserve."
    },
    {
      "verse": "14",
      "text": "Wise people store knowledge in their minds. But when foolish people speak, trouble is near. But when foolish people speak, trouble is near."
    },
    {
      "verse": "15",
      "text": "Money keeps rich people safe, like a strong city. But poor people die because they have no one to help them. But poor people die because they have no one to help them."
    },
    {
      "verse": "16",
      "text": "Righteous people receive life as their wages. Wicked people receive only punishment. Wicked people receive only punishment."
    },
    {
      "verse": "17",
      "text": "People who listen when people warn them are on the road to life. But those who refuse to listen are on a different road. But those who refuse to listen are on a different road."
    },
    {
      "verse": "18",
      "text": "If you hate somebody but you try to hide it, you are telling lies. And if you say false things about other people, you are a fool. And if you say false things about other people, you are a fool."
    },
    {
      "verse": "19",
      "text": "If you talk too much, you will soon do something wrong. But if you are wise, you will stop talking. But if you are wise, you will stop talking."
    },
    {
      "verse": "20",
      "text": "The words of righteous people are as valuable as the best silver. But the thoughts of wicked people are useless. But the thoughts of wicked people are useless."
    },
    {
      "verse": "21",
      "text": "The teaching of righteous people will help many people. But foolish people die because they are so stupid. But foolish people die because they are so stupid."
    },
    {
      "verse": "22",
      "text": "If the Lord blesses you, you are really rich. Hard work will not make you any richer. Hard work will not make you any richer."
    },
    {
      "verse": "23",
      "text": "A foolish person is happy when he does wicked things. But a wise person enjoys doing things that are right. But a wise person enjoys doing things that are right."
    },
    {
      "verse": "24",
      "text": "The trouble that wicked people are afraid of will certainly happen to them. But righteous people will receive the things that they want. But righteous people will receive the things that they want."
    },
    {
      "verse": "25",
      "text": "When the storm has finished, wicked people are no longer there. But righteous people are still standing safely. But righteous people are still standing safely."
    },
    {
      "verse": "26",
      "text": "Do not send a lazy person with a message. He will bring you pain, like the taste of bitter wine, or like smoke in your eyes. He will bring you pain, like the taste of bitter wine, or like smoke in your eyes."
    },
    {
      "verse": "27",
      "text": "If you respect and obey the Lord, you will live longer. But wicked people will die before they are old. But wicked people will die before they are old."
    },
    {
      "verse": "28",
      "text": "What good people hope to receive causes them to be happy. But wicked people never receive what they hope for. But wicked people never receive what they hope for."
    },
    {
      "verse": "29",
      "text": "The Lord keeps honest people safe. But he punishes people who do wrong things. But he punishes people who do wrong things."
    },
    {
      "verse": "30",
      "text": "Righteous people will always have a safe place to live. But wicked people will not continue to live in the land. But wicked people will not continue to live in the land."
    },
    {
      "verse": "31",
      "text": "Righteous people speak wise words. But those who speak evil things will lose their tongues! But those who speak evil things will lose their tongues!"
    },
    {
      "verse": "32",
      "text": "Righteous people say kind things. But wicked people say things that hurt others."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "The Lord hates traders who do not use true weights. He is happy when they are honest and they use true weights. He is happy when they are honest and they use true weights."
    },
    {
      "verse": "2",
      "text": "If people are proud, they will soon become ashamed. But if people are humble, they become wise. But if people are humble, they become wise."
    },
    {
      "verse": "3",
      "text": "Good people are honest, and that shows them the right way to live. But wicked people are not honest, and that destroys them. But wicked people are not honest, and that destroys them."
    },
    {
      "verse": "4",
      "text": "When it is time for God to punish you, money will not help you to escape. But if you are righteous, that will save you from death. But if you are righteous, that will save you from death."
    },
    {
      "verse": "5",
      "text": "An honest man who is righteous has a straight path to walk on. But the sins of a wicked person will cause him to fall down. But the sins of a wicked person will cause him to fall down."
    },
    {
      "verse": "6",
      "text": "When honest people are righteous, that will keep them safe. But the bad things that wicked people want will catch them in a trap. But the bad things that wicked people want will catch them in a trap."
    },
    {
      "verse": "7",
      "text": "When a wicked person dies, he has no hope for anything good. Everything that he hoped his strength would give him disappears! Everything that he hoped his strength would give him disappears!"
    },
    {
      "verse": "8",
      "text": "Righteous people escape from trouble. The trouble happens to wicked people instead. The trouble happens to wicked people instead."
    },
    {
      "verse": "9",
      "text": "People who do not respect God say things that destroy their friends. But the knowledge that righteous people have keeps them safe. But the knowledge that righteous people have keeps them safe."
    },
    {
      "verse": "10",
      "text": "When righteous people do well, everyone in the city is happy. And people shout with joy when wicked people die. And people shout with joy when wicked people die."
    },
    {
      "verse": "11",
      "text": "A city becomes great when honest men bring God's blessing to it. But when wicked people give bad advice, they will destroy the city. But when wicked people give bad advice, they will destroy the city."
    },
    {
      "verse": "12",
      "text": "When someone insults his neighbour, it shows that he is foolish. But a wise person stays quiet. But a wise person stays quiet."
    },
    {
      "verse": "13",
      "text": "If a person talks too much about other people, he will soon tell their secrets. But someone that you can trust will not tell your secrets to other people. But someone that you can trust will not tell your secrets to other people."
    },
    {
      "verse": "14",
      "text": "A nation will fall if it has no wise leaders. But it will do well if there are people who give good advice. But it will do well if there are people who give good advice."
    },
    {
      "verse": "15",
      "text": "If you promise to pay a stranger's debt, you will be sorry. You will be safe if you do not agree to do that. You will be safe if you do not agree to do that."
    },
    {
      "verse": "16",
      "text": "A kind woman receives honour, but cruel men only get riches for themselves. but cruel men only get riches for themselves."
    },
    {
      "verse": "17",
      "text": "A faithful person helps himself with good things, but a cruel person brings trouble on himself. but a cruel person brings trouble on himself."
    },
    {
      "verse": "18",
      "text": "A wicked person gets riches that soon disappear. But someone who lives in a good way will surely receive good things. But someone who lives in a good way will surely receive good things."
    },
    {
      "verse": "19",
      "text": "If someone continues to do what is right, he will live. But if someone loves to do evil things, he will die. But if someone loves to do evil things, he will die."
    },
    {
      "verse": "20",
      "text": "The Lord hates people who have wrong thoughts. But he is pleased with people who live in an honest way. But he is pleased with people who live in an honest way."
    },
    {
      "verse": "21",
      "text": "Be sure about this: Evil people will receive the punishment that they deserve. But people who are righteous will escape. But people who are righteous will escape."
    },
    {
      "verse": "22",
      "text": "A beautiful woman who turns away from wisdomis like a gold ring in a pig's nose. is like a gold ring in a pig's nose."
    },
    {
      "verse": "23",
      "text": "Righteous people want good things to happen. Wicked people only hope to cause anger. Wicked people only hope to cause anger."
    },
    {
      "verse": "24",
      "text": "Somebody may share his things with other people, but he still becomes richer. Somebody else may keep the things that he should give to others, but he still becomes poor. but he still becomes richer. Somebody else may keep the things that he should give to others, but he still becomes poor."
    },
    {
      "verse": "25",
      "text": "If you help other people with your money, you will do well. If you give water to thirsty people, you will not be thirsty yourself. If you give water to thirsty people, you will not be thirsty yourself."
    },
    {
      "verse": "26",
      "text": "If you refuse to sell food to hungry people, they will curse you. But if you sell it to them, they will praise you. But if you sell it to them, they will praise you."
    },
    {
      "verse": "27",
      "text": "If you try to do good things, people will respect you. But if you want evil things to happen, they will happen to you! But if you want evil things to happen, they will happen to you!"
    },
    {
      "verse": "28",
      "text": "If somebody trusts his riches to keep him safe, he will fall like a leaf that falls from a tree. But a righteous person will grow strong, like a fresh green leaf. he will fall like a leaf that falls from a tree. But a righteous person will grow strong, like a fresh green leaf."
    },
    {
      "verse": "29",
      "text": "Anyone who causes trouble for his family will not receive any good thing from them. A foolish person like that will become the servant of a wise person. A foolish person like that will become the servant of a wise person."
    },
    {
      "verse": "30",
      "text": "The good things that a righteous person does bring life. A person who saves people's lives shows that he is wise. A person who saves people's lives shows that he is wise."
    },
    {
      "verse": "31",
      "text": "Righteous people receive what they deserve, here on this earth. So you can be sure that cruel and wicked people will receive their punishment."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "Do you want to know the right way to live? Then you must accept it when people warn you that you have done something wrong. Only stupid people hate it when people warn them. Then you must accept it when people warn you that you have done something wrong. Only stupid people hate it when people warn them."
    },
    {
      "verse": "2",
      "text": "The Lord helps good people. But he punishes people who want to do evil things. But he punishes people who want to do evil things."
    },
    {
      "verse": "3",
      "text": "No one can use wicked things to make himself safe. But a righteous person has strong roots. But a righteous person has strong roots."
    },
    {
      "verse": "4",
      "text": "A good wife will bring honour to her husband, like a crown. But a wife who brings shame to her husband will take away his strength. But a wife who brings shame to her husband will take away his strength."
    },
    {
      "verse": "5",
      "text": "Righteous people want to do things that are right. But do not trust the advice of wicked people. But do not trust the advice of wicked people."
    },
    {
      "verse": "6",
      "text": "The words of wicked people are like a trap that will kill good people. But the words of honest people will save people's lives. But the words of honest people will save people's lives."
    },
    {
      "verse": "7",
      "text": "Wicked people soon come to an end and they disappear. But the families of righteous people will continue to be strong. But the families of righteous people will continue to be strong."
    },
    {
      "verse": "8",
      "text": "People will praise a wise person, as much as his wisdom deserves. But no one will respect a person who is stupid. But no one will respect a person who is stupid."
    },
    {
      "verse": "9",
      "text": "It is better to be a humble person who has a servantthan a proud person who has no food to eat. than a proud person who has no food to eat."
    },
    {
      "verse": "10",
      "text": "Righteous people take care of their animals. But wicked people are cruel even when they think they are kind. But wicked people are cruel even when they think they are kind."
    },
    {
      "verse": "11",
      "text": "A farmer who works hard will have plenty of food to eat. But anyone who works only on useless things is foolish. But anyone who works only on useless things is foolish."
    },
    {
      "verse": "12",
      "text": "Wicked people want to take the things that other bad people have. But righteous people remain strong, with deep roots. But righteous people remain strong, with deep roots."
    },
    {
      "verse": "13",
      "text": "The lies of evil people put them in trouble. But righteous people escape from trouble. But righteous people escape from trouble."
    },
    {
      "verse": "14",
      "text": "If you say good things, you will receive good things that make you happy. You will receive what you deserve from the things that you do. You will receive what you deserve from the things that you do."
    },
    {
      "verse": "15",
      "text": "Foolish people always do what seems right to them. But wise people listen to advice from others. But wise people listen to advice from others."
    },
    {
      "verse": "16",
      "text": "When a fool becomes angry, everybody knows it! But a careful person keeps quiet when someone insults him. But a careful person keeps quiet when someone insults him."
    },
    {
      "verse": "17",
      "text": "Honest people speak the truth in court. But a person who tells lies never says what is true. But a person who tells lies never says what is true."
    },
    {
      "verse": "18",
      "text": "If you speak in a careless way, you may hurt other people. But when wise people speak, it makes people feel well. But when wise people speak, it makes people feel well."
    },
    {
      "verse": "19",
      "text": "True words continue to be true for ever. But people quickly see that lies are lies. But people quickly see that lies are lies."
    },
    {
      "verse": "20",
      "text": "Someone who wants to cause trouble has a mind that is full of lies. But someone who wants to bring peace has a mind that is full of joy. But someone who wants to bring peace has a mind that is full of joy."
    },
    {
      "verse": "21",
      "text": "Trouble keeps away from righteous people. But wicked people have trouble all the time. But wicked people have trouble all the time."
    },
    {
      "verse": "22",
      "text": "The Lord hates people who tell lies. But he is pleased with people who do what they promise to do. But he is pleased with people who do what they promise to do."
    },
    {
      "verse": "23",
      "text": "Careful people keep quiet about how much they know. But foolish people show everyone how silly they are. But foolish people show everyone how silly they are."
    },
    {
      "verse": "24",
      "text": "If you work hard, you will become a leader. But if you are lazy, you will become a slave. But if you are lazy, you will become a slave."
    },
    {
      "verse": "25",
      "text": "If you worry all the time, it will make you sad. But kind words will make you happy. But kind words will make you happy."
    },
    {
      "verse": "26",
      "text": "A righteous person gives good advice to his friends. But wicked people are always taking the wrong path. But wicked people are always taking the wrong path."
    },
    {
      "verse": "27",
      "text": "A lazy person does not cook the animals that he has caught. But if you work hard, you will enjoy many valuable things. But if you work hard, you will enjoy many valuable things."
    },
    {
      "verse": "28",
      "text": "If you do what is right, you will find true life. Along that path, there is no death."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "A wise son listens to his father's teaching. But if you tell a proud person that he is wrong, he will not listen. But if you tell a proud person that he is wrong, he will not listen."
    },
    {
      "verse": "2",
      "text": "If you say kind words, you will eat good things. But wicked people only want to be cruel. But wicked people only want to be cruel."
    },
    {
      "verse": "3",
      "text": "Someone who thinks before he speaks will keep his life safe. But someone who talks too much will destroy himself. But someone who talks too much will destroy himself."
    },
    {
      "verse": "4",
      "text": "A lazy person always wants to have more, but he will not get it. If a person works hard, he will have more than he needs. If a person works hard, he will have more than he needs."
    },
    {
      "verse": "5",
      "text": "Honest people hate anything that is false. But wicked people do things that bring them shame. But wicked people do things that bring them shame."
    },
    {
      "verse": "6",
      "text": "When honest people do what is right, it keeps them safe. But when sinners do evil things, it destroys them. But when sinners do evil things, it destroys them."
    },
    {
      "verse": "7",
      "text": "Somebody who has nothing may still pretend to be rich. Somebody else may pretend to be poor, but he is very rich. Somebody else may pretend to be poor, but he is very rich."
    },
    {
      "verse": "8",
      "text": "A rich person may have to use his money to save his life. But poor people do not have that problem. But poor people do not have that problem."
    },
    {
      "verse": "9",
      "text": "Righteous people have joy that shines like a bright light. But wicked people have a light that will quickly go out. But wicked people have a light that will quickly go out."
    },
    {
      "verse": "10",
      "text": "A person who boasts only causes trouble. But if you accept good advice, it shows that you are wise. But if you accept good advice, it shows that you are wise."
    },
    {
      "verse": "11",
      "text": "If you try to get money quickly, you will not stay rich for long. But if you are patient, you will become rich little by little. But if you are patient, you will become rich little by little."
    },
    {
      "verse": "12",
      "text": "When you do not receive the things that you hope for, it makes you sad. But when you receive what you have always wanted, you are very happy. But when you receive what you have always wanted, you are very happy."
    },
    {
      "verse": "13",
      "text": "If you do not accept good teaching, you will destroy yourself. If you accept good advice, it will help you to do well. If you accept good advice, it will help you to do well."
    },
    {
      "verse": "14",
      "text": "The teaching of wise people is like a spring of water that gives life. It will keep you away from death's dangerous traps. It will keep you away from death's dangerous traps."
    },
    {
      "verse": "15",
      "text": "People respect a person who has wise thoughts. But the way that wicked people live destroys them. But the way that wicked people live destroys them."
    },
    {
      "verse": "16",
      "text": "Careful people need to understand what they are doing. But a fool quickly shows how foolish he is. But a fool quickly shows how foolish he is."
    },
    {
      "verse": "17",
      "text": "If you send a message with a wicked person, he will cause trouble. But if you send someone that you can trust, he will bring peace. But if you send someone that you can trust, he will bring peace."
    },
    {
      "verse": "18",
      "text": "Anyone who turns away from good teaching will become poor and ashamed. But if you accept advice when you do something wrong, people will respect you. But if you accept advice when you do something wrong, people will respect you."
    },
    {
      "verse": "19",
      "text": "It is very nice to receive the things that you want. But foolish people refuse to stop doing evil things. But foolish people refuse to stop doing evil things."
    },
    {
      "verse": "20",
      "text": "If you have wise people as your friends, you will become wise yourself. But if you have foolish friends, you will hurt yourself. But if you have foolish friends, you will hurt yourself."
    },
    {
      "verse": "21",
      "text": "Trouble chases sinners and it catches them. But righteous people will receive good things. But righteous people will receive good things."
    },
    {
      "verse": "22",
      "text": "When a good person dies, he leaves good things for his grandchildren. But a sinner's riches will belong to righteous people in the end. But a sinner's riches will belong to righteous people in the end."
    },
    {
      "verse": "23",
      "text": "Even a poor man's field may give him enough food. But he loses it because wicked people rob him. But he loses it because wicked people rob him."
    },
    {
      "verse": "24",
      "text": "If you do not punish your child, you show that you hate him. If you really love your child, you will punish him when he does something wrong. If you really love your child, you will punish him when he does something wrong."
    },
    {
      "verse": "25",
      "text": "Righteous people have plenty of food to eat. But wicked people have an empty stomach."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "Every wise woman makes her home strong. But a foolish woman destroys her home with her own hands. But a foolish woman destroys her home with her own hands."
    },
    {
      "verse": "2",
      "text": "An honest person respects and obeys the Lord. But anyone who deceives other people shows that he does not respect the Lord. But anyone who deceives other people shows that he does not respect the Lord."
    },
    {
      "verse": "3",
      "text": "When fools boast, they bring punishment on themselves. But the words of wise people keep them safe. But the words of wise people keep them safe."
    },
    {
      "verse": "4",
      "text": "When a farmer has no oxen to plough his fields, he does not have to feed them. But he needs strong oxen to grow plenty of crops. he does not have to feed them. But he needs strong oxen to grow plenty of crops."
    },
    {
      "verse": "5",
      "text": "A faithful person will not tell lies in court. But someone who says false things, always deceives. But someone who says false things, always deceives."
    },
    {
      "verse": "6",
      "text": "If you only pretend that you want wisdom, you will not find it. But if you are careful, you will easily understand what is right. But if you are careful, you will easily understand what is right."
    },
    {
      "verse": "7",
      "text": "Stay away from foolish people. They will stop you from learning anything that is wise. They will stop you from learning anything that is wise."
    },
    {
      "verse": "8",
      "text": "A careful person understands what is right and he does it. But a foolish person's silly thoughts deceive him. But a foolish person's silly thoughts deceive him."
    },
    {
      "verse": "9",
      "text": "Fools think that they do not need to do anything about their sins. But God is pleased with people who do what is right. But God is pleased with people who do what is right."
    },
    {
      "verse": "10",
      "text": "When you are upset, you yourself know how sad you are. No one else can know what you are feeling, sad or happy. No one else can know what you are feeling, sad or happy."
    },
    {
      "verse": "11",
      "text": "A wicked person's home will come to an end. But the home of a good person will continue to be strong. But the home of a good person will continue to be strong."
    },
    {
      "verse": "12",
      "text": "You may think that you are on a good, straight road. But in the end, that road may lead you to death. But in the end, that road may lead you to death."
    },
    {
      "verse": "13",
      "text": "Somebody may be upset, even when he is laughing. After his joy has gone, he will still be sad. After his joy has gone, he will still be sad."
    },
    {
      "verse": "14",
      "text": "If someone turns away from what is right, he will receive the punishment that he deserves. But good people will receive the good things that they deserve. he will receive the punishment that he deserves. But good people will receive the good things that they deserve."
    },
    {
      "verse": "15",
      "text": "A silly person will believe anything. But a careful person will think before he does anything. But a careful person will think before he does anything."
    },
    {
      "verse": "16",
      "text": "A wise person is careful to keep away from trouble. But a fool is careless and he thinks that he is always right. But a fool is careless and he thinks that he is always right."
    },
    {
      "verse": "17",
      "text": "A person who quickly becomes angry does silly things. And people hate anyone with cruel ideas. And people hate anyone with cruel ideas."
    },
    {
      "verse": "18",
      "text": "Silly people do foolish things, and they receive what they deserve. But wise people receive honour for their knowledge. But wise people receive honour for their knowledge."
    },
    {
      "verse": "19",
      "text": "Evil people will respect good people. Wicked people will ask righteous people to be kind to them. Wicked people will ask righteous people to be kind to them."
    },
    {
      "verse": "20",
      "text": "Even the neighbours of poor people do not like them. But rich people have many friends. But rich people have many friends."
    },
    {
      "verse": "21",
      "text": "It is a sin if you do not respect your neighbour. But if you are kind to helpless people, God will bless you. But if you are kind to helpless people, God will bless you."
    },
    {
      "verse": "22",
      "text": "People who want to do evil things have lost their way. But those who want to do good things show faithful love. But those who want to do good things show faithful love."
    },
    {
      "verse": "23",
      "text": "If you work hard, something good will come. But if you only talk about it, you will become poor. But if you only talk about it, you will become poor."
    },
    {
      "verse": "24",
      "text": "For wise people, their riches are like a crown of honour. But fools only work to get foolish things. But fools only work to get foolish things."
    },
    {
      "verse": "25",
      "text": "Someone who speaks the truth in court may save a life. But someone who always tells lies deceives everyone. But someone who always tells lies deceives everyone."
    },
    {
      "verse": "26",
      "text": "Someone who respects and obeys the Lord knows that he will be safe. His family also will be in a safe place. His family also will be in a safe place."
    },
    {
      "verse": "27",
      "text": "If you respect and obey the Lord, that is like a spring of water that gives you life. It will keep you safe from death's traps. that is like a spring of water that gives you life. It will keep you safe from death's traps."
    },
    {
      "verse": "28",
      "text": "A king who rules many people will receive great honour. But a ruler with only a few people will have nothing in the end. But a ruler with only a few people will have nothing in the end."
    },
    {
      "verse": "29",
      "text": "A patient man shows that he understands what is right. But someone who quickly becomes angry shows that he is foolish. But someone who quickly becomes angry shows that he is foolish."
    },
    {
      "verse": "30",
      "text": "If you have peace in your mind, your body will be healthy. But if you are jealous, it will eat away your body. But if you are jealous, it will eat away your body."
    },
    {
      "verse": "31",
      "text": "If you are cruel to poor people, you are insulting God who created them. But if you are kind to helpless people, it shows that you respect God. you are insulting God who created them. But if you are kind to helpless people, it shows that you respect God."
    },
    {
      "verse": "32",
      "text": "When wicked people are in trouble, they cannot stand. But righteous people still trust God, even when they are in danger of death. But righteous people still trust God, even when they are in danger of death."
    },
    {
      "verse": "33",
      "text": "People who understand what is right have true wisdom. Even fools may sometimes show wisdom. Even fools may sometimes show wisdom."
    },
    {
      "verse": "34",
      "text": "A nation will receive honour when its people do what is right. But sin will bring shame on its people. But sin will bring shame on its people."
    },
    {
      "verse": "35",
      "text": "A king will be pleased with a wise servant. But he will be angry with any servant who brings shame."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "If you answer people in a kind way, it stops them being angry. But if you say cruel things, it makes people angry. But if you say cruel things, it makes people angry."
    },
    {
      "verse": "2",
      "text": "When wise people speak, they show that knowledge is good. But when fools speak, they only say foolish things. But when fools speak, they only say foolish things."
    },
    {
      "verse": "3",
      "text": "The Lord sees what happens everywhere. He is watching what evil people do, and good people too. He is watching what evil people do, and good people too."
    },
    {
      "verse": "4",
      "text": "Kind words are like the fruit of a tree that gives life. But words that are not honest make people sad and weak. But words that are not honest make people sad and weak."
    },
    {
      "verse": "5",
      "text": "A fool hates his father's rules. But a wise child learns when his father warns him. But a wise child learns when his father warns him."
    },
    {
      "verse": "6",
      "text": "Righteous people have many valuable things in their homes. But the riches of wicked people bring trouble to them. But the riches of wicked people bring trouble to them."
    },
    {
      "verse": "7",
      "text": "When wise people speak, they give knowledge, but the minds of fools have nothing to give. but the minds of fools have nothing to give."
    },
    {
      "verse": "8",
      "text": "When wicked people offer sacrifices to the Lord, he hates it. But he is pleased when good people pray to him. But he is pleased when good people pray to him."
    },
    {
      "verse": "9",
      "text": "The Lord hates the way that wicked people live. But he loves people who want to do what is right. But he loves people who want to do what is right."
    },
    {
      "verse": "10",
      "text": "If you leave God's way, you will receive strong punishment. When people warn you, accept it or you will die. When people warn you, accept it or you will die."
    },
    {
      "verse": "11",
      "text": "The Lord sees clearly into the deep hole of death. So you can be sure that he knows people's secret thoughts. So you can be sure that he knows people's secret thoughts."
    },
    {
      "verse": "12",
      "text": "Proud people do not like it when someone warns them. They will not ask wise people to give them advice. They will not ask wise people to give them advice."
    },
    {
      "verse": "13",
      "text": "When someone is happy, their face smiles. But when someone is sad, their spirit hurts. But when someone is sad, their spirit hurts."
    },
    {
      "verse": "14",
      "text": "Wise people want to learn more. But fools only want to know useless things. But fools only want to know useless things."
    },
    {
      "verse": "15",
      "text": "Every day is difficult, if you have trouble in your mind. But if you are happy, every day is like a feast. But if you are happy, every day is like a feast."
    },
    {
      "verse": "16",
      "text": "You may be poor, but you respect and obey the Lord. That is better than if you are very rich, but you have a lot of trouble. That is better than if you are very rich, but you have a lot of trouble."
    },
    {
      "verse": "17",
      "text": "It is better to eat vegetables with people who love each otherthan to eat good meat with people who hate each other. than to eat good meat with people who hate each other."
    },
    {
      "verse": "18",
      "text": "Angry people bring quarrels, but patient people bring peace. but patient people bring peace."
    },
    {
      "verse": "19",
      "text": "A lazy person always has problems, as if he is walking through thorn bushes. But an honest person walks on a straight road through life. as if he is walking through thorn bushes. But an honest person walks on a straight road through life."
    },
    {
      "verse": "20",
      "text": "A wise child makes his father happy. But a foolish person does not respect his mother. But a foolish person does not respect his mother."
    },
    {
      "verse": "21",
      "text": "Stupid people are happy when they do foolish things. But wise people walk on a straight path. But wise people walk on a straight path."
    },
    {
      "verse": "22",
      "text": "Without good advice, your ideas will never happen. But you will do well if you have many advisors. But you will do well if you have many advisors."
    },
    {
      "verse": "23",
      "text": "It makes you happy when you give a good answer to a question. It is good when you find the right thing to say at the right time. It is good when you find the right thing to say at the right time."
    },
    {
      "verse": "24",
      "text": "A wise person walks on a path that leads him up to a long life. He keeps away from the path that would lead him down to death. He keeps away from the path that would lead him down to death."
    },
    {
      "verse": "25",
      "text": "The Lord destroys the homes of proud men. But he keeps the land of widows safe. But he keeps the land of widows safe."
    },
    {
      "verse": "26",
      "text": "The Lord hates the thoughts of wicked people. But kind words please him. But kind words please him."
    },
    {
      "verse": "27",
      "text": "Anyone who cheats people to become richwill cause trouble for his family. But anyone who refuses to accept bribeswill live safely. will cause trouble for his family. But anyone who refuses to accept bribes will live safely."
    },
    {
      "verse": "28",
      "text": "Righteous people think carefully before they answer someone. But when wicked people speak, the result is only trouble. But when wicked people speak, the result is only trouble."
    },
    {
      "verse": "29",
      "text": "The Lord does not answer the prayers of wicked people. But when righteous people pray, he listens. But when righteous people pray, he listens."
    },
    {
      "verse": "30",
      "text": "If someone smiles at you, it makes you happy. Good news makes you feel strong. Good news makes you feel strong."
    },
    {
      "verse": "31",
      "text": "If anyone accepts teaching that helps him to live in a good way, he becomes a friend of wise people. he becomes a friend of wise people."
    },
    {
      "verse": "32",
      "text": "If you refuse to accept it when people warn you, you are hurting yourself. But if you agree to listen, you will learn to do what is right. you are hurting yourself. But if you agree to listen, you will learn to do what is right."
    },
    {
      "verse": "33",
      "text": "If you respect and obey the Lord, that will teach you wisdom. If you want to receive honour, first learn to be humble."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "People make plans in their minds, but the Lord gives them the right words to say. but the Lord gives them the right words to say."
    },
    {
      "verse": "2",
      "text": "You may think that everything you do is right, but the Lord knows exactly why you are doing it. but the Lord knows exactly why you are doing it."
    },
    {
      "verse": "3",
      "text": "Put your plans in front of the Lord, so that what you want to do will go well. so that what you want to do will go well."
    },
    {
      "verse": "4",
      "text": "The Lord causes everything to have its proper result. Even wicked people will come to bad trouble in the end. Even wicked people will come to bad trouble in the end."
    },
    {
      "verse": "5",
      "text": "The Lord hates everyone who boasts. Be sure of this: They will receive the punishment that they deserve. Be sure of this: They will receive the punishment that they deserve."
    },
    {
      "verse": "6",
      "text": "If you love the Lord faithfully, he will forgive your sins. If you respect and obey him, you will not do evil things. he will forgive your sins. If you respect and obey him, you will not do evil things."
    },
    {
      "verse": "7",
      "text": "If you live in a way that pleases the Lord, even your enemies will become your friends. even your enemies will become your friends."
    },
    {
      "verse": "8",
      "text": "If you do what is right but you are not rich, that is better than to be rich because you cheat people. that is better than to be rich because you cheat people."
    },
    {
      "verse": "9",
      "text": "People make plans for what they will do, but it is the Lord who leads them in the right way. but it is the Lord who leads them in the right way."
    },
    {
      "verse": "10",
      "text": "A king speaks with God's authority. He must judge people in a fair way. He must judge people in a fair way."
    },
    {
      "verse": "11",
      "text": "The Lord wants people to use true weights and measures. He knows all the weights that a trader uses. He knows all the weights that a trader uses."
    },
    {
      "verse": "12",
      "text": "Kings hate all wicked acts, because justice makes their government strong. because justice makes their government strong."
    },
    {
      "verse": "13",
      "text": "Kings are happy to hear honest advice. They love people who speak true words. They love people who speak true words."
    },
    {
      "verse": "14",
      "text": "Someone may die if the king becomes angry with him. So a wise person will try to stop the king's anger. So a wise person will try to stop the king's anger."
    },
    {
      "verse": "15",
      "text": "If the king smiles at you, your life will go well. If he is pleased with you, that is like a cloud which gives rain in the spring. If he is pleased with you, that is like a cloud which gives rain in the spring."
    },
    {
      "verse": "16",
      "text": "It is better to have wisdom than gold or silver. You should want to understand what is right. You should want to understand what is right."
    },
    {
      "verse": "17",
      "text": "Honest people follow a straight road that keeps them away from evil things. If you want to keep your life safe, watch where you are going. If you want to keep your life safe, watch where you are going."
    },
    {
      "verse": "18",
      "text": "If you are proud, you will soon come to an end. Anyone who boasts will soon fall down. Anyone who boasts will soon fall down."
    },
    {
      "verse": "19",
      "text": "You may be humble and have poor people as your friends. But that is better than if you have proud friendswho give you things that they have robbed from others. But that is better than if you have proud friends who give you things that they have robbed from others."
    },
    {
      "verse": "20",
      "text": "If you listen carefully to good teaching, you will do well. If you trust in the Lord, you are in a happy place. If you trust in the Lord, you are in a happy place."
    },
    {
      "verse": "21",
      "text": "If you have wise thoughts, people will say that you know what is right. If you speak kind words, people will accept your teaching. people will say that you know what is right. If you speak kind words, people will accept your teaching."
    },
    {
      "verse": "22",
      "text": "Wisdom is like a spring of fresh water that gives life to those who have it. But the silly things that fools do brings them punishment. But the silly things that fools do brings them punishment."
    },
    {
      "verse": "23",
      "text": "Wise people think carefully and they speak wise words. Then other people will accept their teaching. Then other people will accept their teaching."
    },
    {
      "verse": "24",
      "text": "Kind words are as sweet as honey. They also bring health and strength. They also bring health and strength."
    },
    {
      "verse": "25",
      "text": "You may think that you are on a good, straight road. But in the end, that road may lead you to death. But in the end, that road may lead you to death."
    },
    {
      "verse": "26",
      "text": "When a worker feels hungry, it causes him to work more. So it helps him to get food to eat. So it helps him to get food to eat."
    },
    {
      "verse": "27",
      "text": "Wicked people look for ways to hurt other people. The cruel things that they say are like flames of fire. The cruel things that they say are like flames of fire."
    },
    {
      "verse": "28",
      "text": "People who tell lies cause arguments. If you tell people's secrets, you will lose all your friends. If you tell people's secrets, you will lose all your friends."
    },
    {
      "verse": "29",
      "text": "Violent people deceive their friends. They lead their friends to do wrong things. They lead their friends to do wrong things."
    },
    {
      "verse": "30",
      "text": "If someone sends secret messages with his eyes, he has a plan to hurt someone. If he squeezes his lips together, he is ready to do an evil thing. he has a plan to hurt someone. If he squeezes his lips together, he is ready to do an evil thing."
    },
    {
      "verse": "31",
      "text": "Grey hair is like a beautiful crown on your head! People who live in a righteous way may wear it. People who live in a righteous way may wear it."
    },
    {
      "verse": "32",
      "text": "A person who is patient is better than a brave soldier. If you can control your anger, you can win any battle. If you can control your anger, you can win any battle."
    },
    {
      "verse": "33",
      "text": "People throw dice to choose what is right. But it is the Lord who decides the answer."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "It is better to eat a piece of dry bread in a quiet place, than to eat a big feast in a house full of arguments. than to eat a big feast in a house full of arguments."
    },
    {
      "verse": "2",
      "text": "A slave who is wise will have authority over a son who does stupid things. When his master dies, that slave will receive some of his valuable things. When his master dies, that slave will receive some of his valuable things."
    },
    {
      "verse": "3",
      "text": "You need a hot fire to make silver and gold become pure. It is the Lord who does that for people, to show what they are really like. It is the Lord who does that for people, to show what they are really like."
    },
    {
      "verse": "4",
      "text": "People who do evil things listen to evil advice. People who tell lies listen to other people's lies. People who tell lies listen to other people's lies."
    },
    {
      "verse": "5",
      "text": "If you laugh at poor people, you are insulting God, who made them. If you are happy when trouble happens to other people, you will receive the punishment that you deserve. you are insulting God, who made them. If you are happy when trouble happens to other people, you will receive the punishment that you deserve."
    },
    {
      "verse": "6",
      "text": "Old people should be proud of their grandchildren. In the same way, children should be proud of their parents. In the same way, children should be proud of their parents."
    },
    {
      "verse": "7",
      "text": "It does not seem right when a fool says clever things. It is certainly not right when a ruler tells lies. It is certainly not right when a ruler tells lies."
    },
    {
      "verse": "8",
      "text": "Somebody who offers a bribe thinks that it will work like magic. It will help him to do whatever he wants to do. It will help him to do whatever he wants to do."
    },
    {
      "verse": "9",
      "text": "If you forgive people when they hurt you, they will still love you. But if you continue to talk about what they have done, they will no longer be your friends. they will still love you. But if you continue to talk about what they have done, they will no longer be your friends."
    },
    {
      "verse": "10",
      "text": "You can warn a wise person once and he will learn what is right. But a fool never learns, even if you hit him a hundred times. But a fool never learns, even if you hit him a hundred times."
    },
    {
      "verse": "11",
      "text": "An evil person never obeys authority, so a cruel messenger will come to punish him. so a cruel messenger will come to punish him."
    },
    {
      "verse": "12",
      "text": "Do not go near a fool who is doing stupid things. It would be safer to meet a mother bear who has lost her babies. It would be safer to meet a mother bear who has lost her babies."
    },
    {
      "verse": "13",
      "text": "If people are kind to you, do not do evil things in return. Anyone who does that will always have trouble in his home. Anyone who does that will always have trouble in his home."
    },
    {
      "verse": "14",
      "text": "It is difficult to stop a quarrel once it has started. It is like water that pours out of a broken pot. Stop it quickly! It is like water that pours out of a broken pot. Stop it quickly!"
    },
    {
      "verse": "15",
      "text": "If a judge says that a guilty person is not guilty, the Lord hates it. If a judge punishes someone who is not guilty, the Lord hates that too. the Lord hates it. If a judge punishes someone who is not guilty, the Lord hates that too."
    },
    {
      "verse": "16",
      "text": "Money does not help a foolish person, because he does not want to become wise. because he does not want to become wise."
    },
    {
      "verse": "17",
      "text": "A friend will always show that he loves you. Relatives are there to help you when you are in trouble. Relatives are there to help you when you are in trouble."
    },
    {
      "verse": "18",
      "text": "Only a stupid person promises to pay someone else's debts, even if he is a friend or a neighbour. even if he is a friend or a neighbour."
    },
    {
      "verse": "19",
      "text": "Someone who loves to argue loves sin. Someone who boasts causes trouble for himself. Someone who boasts causes trouble for himself."
    },
    {
      "verse": "20",
      "text": "Anyone who thinks about bad things will not do well in life. Anyone who deceives people with lies will have a lot of trouble. Anyone who deceives people with lies will have a lot of trouble."
    },
    {
      "verse": "21",
      "text": "To have a foolish son makes parents sad. The father of a fool is never happy. The father of a fool is never happy."
    },
    {
      "verse": "22",
      "text": "If you are happy in life, you will be healthy. But if you are sad and upset, your body will be weak. But if you are sad and upset, your body will be weak."
    },
    {
      "verse": "23",
      "text": "Wicked judges secretly accept bribes. Then they are not fair when they judge. Then they are not fair when they judge."
    },
    {
      "verse": "24",
      "text": "A person who knows what is right can easily find wisdom. But a foolish person looks everywhere and never finds it. But a foolish person looks everywhere and never finds it."
    },
    {
      "verse": "25",
      "text": "To have a foolish son makes his father sad. It makes his mother very upset. It makes his mother very upset."
    },
    {
      "verse": "26",
      "text": "It is not right to punish a person who has done nothing wrong. It is wrong to beat honest people with sticks. It is wrong to beat honest people with sticks."
    },
    {
      "verse": "27",
      "text": "A wise person does not talk too much. Anyone who keeps quiet shows that he understands things. Anyone who keeps quiet shows that he understands things."
    },
    {
      "verse": "28",
      "text": "Even a fool seems to be wise if he keeps quiet. If he keeps his mouth shut, people will think that he is clever."
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "People who do not have any friends think only about themselves. They refuse to listen to good advice. They refuse to listen to good advice."
    },
    {
      "verse": "2",
      "text": "A fool does not try to understand what is right. He only likes to tell people his own ideas. He only likes to tell people his own ideas."
    },
    {
      "verse": "3",
      "text": "When a wicked person arrives, shame comes with him. And shame causes people to speak against you. And shame causes people to speak against you."
    },
    {
      "verse": "4",
      "text": "The words that you speak are like the deep water of the sea. If they are wise words, they are like a cool stream. If they are wise words, they are like a cool stream."
    },
    {
      "verse": "5",
      "text": "Do not refuse to punish wicked people. That would not be good. Also, do not punish anyone who has not done anything wrong. Also, do not punish anyone who has not done anything wrong."
    },
    {
      "verse": "6",
      "text": "When a fool speaks, he starts an argument. He is asking for someone to beat him with a stick. He is asking for someone to beat him with a stick."
    },
    {
      "verse": "7",
      "text": "When a fool speaks, he is destroying himself. His own words are a trap that catches him. His own words are a trap that catches him."
    },
    {
      "verse": "8",
      "text": "We love to hear other people's secrets. They seem like good food that we can enjoy. They seem like good food that we can enjoy."
    },
    {
      "verse": "9",
      "text": "A lazy person is as bad as someone who destroys things."
    },
    {
      "verse": "10",
      "text": "The name of the Lord is like a strong tower. Righteous people can run there, and then they will be safe. Righteous people can run there, and then they will be safe."
    },
    {
      "verse": "11",
      "text": "Rich people think that their money makes them safe, like high, strong walls round a city. like high, strong walls round a city."
    },
    {
      "verse": "12",
      "text": "If you become proud, something will soon destroy you. But if you are humble, you will soon receive honour. But if you are humble, you will soon receive honour."
    },
    {
      "verse": "13",
      "text": "Listen carefully before you answer. If you answer too quickly, you will be ashamed like a fool. If you answer too quickly, you will be ashamed like a fool."
    },
    {
      "verse": "14",
      "text": "When someone is ill, his spirit will keep him strong. But if his spirit has lost hope, he cannot stay strong. But if his spirit has lost hope, he cannot stay strong."
    },
    {
      "verse": "15",
      "text": "Wise people are always learning something new."
    },
    {
      "verse": "16",
      "text": "A gift will give you a chance to meet new people. Important people may become your friends. Important people may become your friends."
    },
    {
      "verse": "17",
      "text": "You will always believe the first person to speak in court, until the other person starts to ask him questions. until the other person starts to ask him questions."
    },
    {
      "verse": "18",
      "text": "If two powerful people have an argument, you may have to throw dice to decide who is right. you may have to throw dice to decide who is right."
    },
    {
      "verse": "19",
      "text": "If you insult a relative, it will be difficult to become friends with him again. Arguments keep people apart, like the walls of a strong city. it will be difficult to become friends with him again. Arguments keep people apart, like the walls of a strong city."
    },
    {
      "verse": "20",
      "text": "If you speak words that help people, they are like good food. they are like good food."
    },
    {
      "verse": "21",
      "text": "Words have the power to bring life or death. So be careful if you talk a lot! So be careful if you talk a lot!"
    },
    {
      "verse": "22",
      "text": "If you find a wife, you find a good thing. The Lord has given you something to enjoy. The Lord has given you something to enjoy."
    },
    {
      "verse": "23",
      "text": "A poor person has to ask for help. But a rich person can insult people. But a rich person can insult people."
    },
    {
      "verse": "24",
      "text": "A man with many friends may lose them. But there is a friend who is more faithful than a brother."
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "It is better to be poor and honest, than to be a fool who speaks lies. than to be a fool who speaks lies."
    },
    {
      "verse": "2",
      "text": "If you want to do something but you do not know how to do it, that is dangerous! If you hurry to do it, you will get into trouble. that is dangerous! If you hurry to do it, you will get into trouble."
    },
    {
      "verse": "3",
      "text": "Some people do silly things and so they destroy themselves. Then they get angry with the Lord. Then they get angry with the Lord."
    },
    {
      "verse": "4",
      "text": "Rich people can easily find new friends. But poor people will easily lose their friends. But poor people will easily lose their friends."
    },
    {
      "verse": "5",
      "text": "If you tell lies in court, the judge will certainly punish you. You will not go free! You will not go free!"
    },
    {
      "verse": "6",
      "text": "Many people want an important person to like them. Everyone wants to be the friend of someone who gives lots of gifts. Everyone wants to be the friend of someone who gives lots of gifts."
    },
    {
      "verse": "7",
      "text": "If someone is poor, all his family hate him. His friends stay away from him. Even if he goes to ask them for help, he cannot find them anywhere. His friends stay away from him. Even if he goes to ask them for help, he cannot find them anywhere."
    },
    {
      "verse": "8",
      "text": "If you learn to be wise, it shows that you love yourself. If you understand what is right, you will do well. it shows that you love yourself. If you understand what is right, you will do well."
    },
    {
      "verse": "9",
      "text": "If you tell lies in court, the judge will certainly punish you. That will be the end of you! That will be the end of you!"
    },
    {
      "verse": "10",
      "text": "Fools should not live like rich people. Even worse, slaves should never have authority over rulers. Even worse, slaves should never have authority over rulers."
    },
    {
      "verse": "11",
      "text": "If someone is wise, he controls his anger. When anyone hurts him, he is careful to forget it. When anyone hurts him, he is careful to forget it."
    },
    {
      "verse": "12",
      "text": "When the king is angry, he makes people afraid, like a lion that roars. But when he is pleased with you, that is like dew on fresh grass. like a lion that roars. But when he is pleased with you, that is like dew on fresh grass."
    },
    {
      "verse": "13",
      "text": "A foolish child will destroy his father. A woman who quarrels with her husband is like rain that never stops. A woman who quarrels with her husband is like rain that never stops."
    },
    {
      "verse": "14",
      "text": "Your parents may give you riches and a house to live in. But only the Lord can give you a wise wife. But only the Lord can give you a wise wife."
    },
    {
      "verse": "15",
      "text": "A lazy person cannot wake up from sleep. If he does no work, he will always be hungry. If he does no work, he will always be hungry."
    },
    {
      "verse": "16",
      "text": "If you obey God's commands, you will keep your life safe. If you do not respect his teaching, you will die. If you do not respect his teaching, you will die."
    },
    {
      "verse": "17",
      "text": "If you are kind to poor people, you are lending money to the Lord. He will pay back the debt to you. He will pay back the debt to you."
    },
    {
      "verse": "18",
      "text": "When your children do wrong things, warn them while you still have the chance. If you do not punish them, you are helping them to go to an early death. warn them while you still have the chance. If you do not punish them, you are helping them to go to an early death."
    },
    {
      "verse": "19",
      "text": "Anyone who cannot control his anger is always getting into trouble. If you try to help him once, you will have to do it every time. If you try to help him once, you will have to do it every time."
    },
    {
      "verse": "20",
      "text": "Accept advice and good teaching. Then you will become wise one day. Then you will become wise one day."
    },
    {
      "verse": "21",
      "text": "You may have lots of ideas about what you want to do. But it is the Lord's plans that are important. But it is the Lord's plans that are important."
    },
    {
      "verse": "22",
      "text": "We all want other people to show faithful love. It is better to be poor than to deceive other people. It is better to be poor than to deceive other people."
    },
    {
      "verse": "23",
      "text": "If you respect and obey the Lord, you will enjoy life. You will have peace in your mindand no trouble will destroy you. you will enjoy life. You will have peace in your mind and no trouble will destroy you."
    },
    {
      "verse": "24",
      "text": "A lazy person pushes his hand into his bowl of food. But then he is too lazy to lift his hand up to his mouth. But then he is too lazy to lift his hand up to his mouth."
    },
    {
      "verse": "25",
      "text": "If you beat a proud fool, a silly person may learn to be careful. If you warn a wise person, he himself will learn a lesson. a silly person may learn to be careful. If you warn a wise person, he himself will learn a lesson."
    },
    {
      "verse": "26",
      "text": "Anyone who robs his father or chases away his motheris a bad son who brings shame to his family. is a bad son who brings shame to his family."
    },
    {
      "verse": "27",
      "text": "My child, never stop learning about what is right. If you stop learning, you will soon forget what you already know. If you stop learning, you will soon forget what you already know."
    },
    {
      "verse": "28",
      "text": "If someone tells lies in court, he is laughing at justice. Evil things are food that wicked people love to eat. Evil things are food that wicked people love to eat."
    },
    {
      "verse": "29",
      "text": "People who laugh at what is right will receive their punishment. Fools will be beaten, as they deserve."
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "If you drink too much wine or strong drink, you do stupid things and you fight. It is not wise to become drunk. you do stupid things and you fight. It is not wise to become drunk."
    },
    {
      "verse": "2",
      "text": "When the king is angry, he is as dangerous as a lion that roars. If you make him angry, you will lose your life. If you make him angry, you will lose your life."
    },
    {
      "verse": "3",
      "text": "If you keep away from arguments, you will receive honour. Only fools love to quarrel. Only fools love to quarrel."
    },
    {
      "verse": "4",
      "text": "A lazy farmer does not plough his fields in winter. As a result, he has nothing to eat when harvest time arrives. As a result, he has nothing to eat when harvest time arrives."
    },
    {
      "verse": "5",
      "text": "A person's thoughts are like deep waters. But a wise person can bring them into the open. But a wise person can bring them into the open."
    },
    {
      "verse": "6",
      "text": "Many people say that you can trust them. But it is difficult to find a truly faithful person. But it is difficult to find a truly faithful person."
    },
    {
      "verse": "7",
      "text": "Righteous people live in an honest way. Their children will also be happy. Their children will also be happy."
    },
    {
      "verse": "8",
      "text": "When a king sits on his throne as judge, he sees what is evil and he removes it. he sees what is evil and he removes it."
    },
    {
      "verse": "9",
      "text": "Nobody can say, ‘My thoughts are completely pure. There is no sin in me. ’ There is no sin in me. ’"
    },
    {
      "verse": "10",
      "text": "If people use false weights and measures, the Lord hates anything like that. the Lord hates anything like that."
    },
    {
      "verse": "11",
      "text": "Even children show what they are like by the things that they do. You can see if they are honest and good. You can see if they are honest and good."
    },
    {
      "verse": "12",
      "text": "The Lord has made us with ears to hear with and eyes to see with. They are both his gift to us. They are both his gift to us."
    },
    {
      "verse": "13",
      "text": "If you love to sleep too much, you will become poor. Keep awake so that you have food on the table! Keep awake so that you have food on the table!"
    },
    {
      "verse": "14",
      "text": "When somebody is buying something, he says, ‘It is worth nothing! ’But later he boasts about the cheap price! But later he boasts about the cheap price!"
    },
    {
      "verse": "15",
      "text": "Words that help you to learn things are very valuable. They are more valuable than gold or jewels. They are more valuable than gold or jewels."
    },
    {
      "verse": "16",
      "text": "If someone promises to pay the debts of a stranger, take his coat as a guarantee that he will pay. take his coat as a guarantee that he will pay."
    },
    {
      "verse": "17",
      "text": "If you cheat someone to get food to eat, it may seem good when you taste it. But soon it will be like sand in your mouth. it may seem good when you taste it. But soon it will be like sand in your mouth."
    },
    {
      "verse": "18",
      "text": "Things will go well if you receive good advice. If you want to fight a war, ask wise people to be your advisors. If you want to fight a war, ask wise people to be your advisors."
    },
    {
      "verse": "19",
      "text": "Keep away from people who talk too much. They will tell everybody about your secrets. They will tell everybody about your secrets."
    },
    {
      "verse": "20",
      "text": "If you insult your parents, your life will quickly finish, like a lamp that suddenly goes outand leaves you in complete darkness. like a lamp that suddenly goes out and leaves you in complete darkness."
    },
    {
      "verse": "21",
      "text": "If you receive riches too early in life, it will do you no good in the end. it will do you no good in the end."
    },
    {
      "verse": "22",
      "text": "Do not say, ‘I will pay you back for the evil thing you did to me. ’Trust the Lord to make it right for you. Trust the Lord to make it right for you."
    },
    {
      "verse": "23",
      "text": "The Lord hates traders who use false weights. He hates scales that do not weigh things properly. He hates scales that do not weigh things properly."
    },
    {
      "verse": "24",
      "text": "The Lord chooses the way that we take through life. We cannot understand what will happen to us. We cannot understand what will happen to us."
    },
    {
      "verse": "25",
      "text": "Do not be too quick to promise to give something to God. If you want to change your mind, you have made a trap for yourself. If you want to change your mind, you have made a trap for yourself."
    },
    {
      "verse": "26",
      "text": "A wise king can pick out wicked people, and he will punish them as they deserve. and he will punish them as they deserve."
    },
    {
      "verse": "27",
      "text": "The Lord makes our human spirit like his lamp inside us. It shows us what we are really like. It shows us what we are really like."
    },
    {
      "verse": "28",
      "text": "A king should rule with faithful love and truth. If he is honest and fair, he will continue to rule. If he is honest and fair, he will continue to rule."
    },
    {
      "verse": "29",
      "text": "Young men boast about their strength. Old men are proud of their beautiful grey hair. Old men are proud of their beautiful grey hair."
    },
    {
      "verse": "30",
      "text": "Painful punishment stops you from doing evil things. It makes you change to a better way of life."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "The Lord controls the things that a king decides to do. He can change the king's thoughts, like the direction of a stream. He can change the king's thoughts, like the direction of a stream."
    },
    {
      "verse": "2",
      "text": "People think that everything they do is right, but the Lord knows exactly why they are doing it. but the Lord knows exactly why they are doing it."
    },
    {
      "verse": "3",
      "text": "If you do what is right and fair, it pleases the Lord more than sacrifices. it pleases the Lord more than sacrifices."
    },
    {
      "verse": "4",
      "text": "Wicked people are proud and they boast. Sin is their guide through life. Sin is their guide through life."
    },
    {
      "verse": "5",
      "text": "A careful person makes good plansand he has everything that he needs. But anyone who works in a hurry will soon become poor. and he has everything that he needs. But anyone who works in a hurry will soon become poor."
    },
    {
      "verse": "6",
      "text": "If you deceive people to become rich, it will soon all disappear. It will lead you to an early death. it will soon all disappear. It will lead you to an early death."
    },
    {
      "verse": "7",
      "text": "When wicked people do violent things, it destroys them. They refuse to do what is right. They refuse to do what is right."
    },
    {
      "verse": "8",
      "text": "Guilty people are always going the wrong way. Good people keep on the right way. Good people keep on the right way."
    },
    {
      "verse": "9",
      "text": "It is better to live on the roof of your housethan to live with a wife who always argues. than to live with a wife who always argues."
    },
    {
      "verse": "10",
      "text": "Evil things are the food that wicked people eat to live. They are not kind to anyone, even their friends. They are not kind to anyone, even their friends."
    },
    {
      "verse": "11",
      "text": "When a proud person receives punishment, silly people become wise. When you teach a wise person, he learns more knowledge. silly people become wise. When you teach a wise person, he learns more knowledge."
    },
    {
      "verse": "12",
      "text": "The Righteous One knows what happens in the homes of wicked people. He punishes them as they deserve. He punishes them as they deserve."
    },
    {
      "verse": "13",
      "text": "If you refuse to listen when poor people ask for help, you too will receive no help when you need it. you too will receive no help when you need it."
    },
    {
      "verse": "14",
      "text": "If someone is angry with you, give him a gift secretly. A secret bribe will make him quiet, even if he is very angry. A secret bribe will make him quiet, even if he is very angry."
    },
    {
      "verse": "15",
      "text": "When there is justice, righteous people are happy, but wicked people are afraid. but wicked people are afraid."
    },
    {
      "verse": "16",
      "text": "If someone decides to turn away from wisdom, he will soon be in his grave. he will soon be in his grave."
    },
    {
      "verse": "17",
      "text": "Anyone who loves only pleasure will become poor. People who love wine and big feasts will never become rich. People who love wine and big feasts will never become rich."
    },
    {
      "verse": "18",
      "text": "When trouble comes, wicked people receive the pain instead of righteous people. wicked people receive the pain instead of righteous people."
    },
    {
      "verse": "19",
      "text": "It is better to live alone in a desertthan to live with a wife who quarrels and complains. than to live with a wife who quarrels and complains."
    },
    {
      "verse": "20",
      "text": "Wise people store valuable things and good food in their houses. But foolish people waste everything immediately. But foolish people waste everything immediately."
    },
    {
      "verse": "21",
      "text": "If you are kind and faithful, you will live a long life! Other people will respect you and they will be kind to you. Other people will respect you and they will be kind to you."
    },
    {
      "verse": "22",
      "text": "A wise person can win against a city that is full of strong men. He can destroy the strong place that they trust to keep them safe. He can destroy the strong place that they trust to keep them safe."
    },
    {
      "verse": "23",
      "text": "If you want to keep away from trouble, always be careful about what you say. always be careful about what you say."
    },
    {
      "verse": "24",
      "text": "If you are proud, people will call you ‘Boaster’, because you think that you are better than all other people. because you think that you are better than all other people."
    },
    {
      "verse": "25",
      "text": "Lazy people want many things but they refuse to work, so they are killing themselves. so they are killing themselves."
    },
    {
      "verse": "26",
      "text": "They think only about more things that they want for themselves. But righteous people are happy to give their things to other people. But righteous people are happy to give their things to other people."
    },
    {
      "verse": "27",
      "text": "The Lord hates itwhen wicked people offer sacrifices to him. He hates it even morewhen they do it with an evil purpose. when wicked people offer sacrifices to him. He hates it even more when they do it with an evil purpose."
    },
    {
      "verse": "28",
      "text": "Anyone who tells lies in court will come to nothing. But if someone listens to the truth, his report will remain for ever. But if someone listens to the truth, his report will remain for ever."
    },
    {
      "verse": "29",
      "text": "Wicked people do not show what they are really thinking. But righteous people think carefully about what they are doing. But righteous people think carefully about what they are doing."
    },
    {
      "verse": "30",
      "text": "There is no wisdom, no knowledge and no advicethat can win against the Lord. that can win against the Lord."
    },
    {
      "verse": "31",
      "text": "You can prepare your horses to fight in a battle, but only the Lord can help you to win."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "It is better to receive honour from people than to be very rich. If people respect you, that is better than silver or gold. If people respect you, that is better than silver or gold."
    },
    {
      "verse": "2",
      "text": "This is true about rich people and poor people: The Lord created them all. The Lord created them all."
    },
    {
      "verse": "3",
      "text": "A careful person can see danger and he will hide himself. But a silly person never stops, and he walks into trouble. But a silly person never stops, and he walks into trouble."
    },
    {
      "verse": "4",
      "text": "You should be humble. You should respect and obey the Lord. Then you will receive riches, honour and a long life. Then you will receive riches, honour and a long life."
    },
    {
      "verse": "5",
      "text": "Wicked people go through a lot of trouble, like thorn bushes and traps in their way. So be careful to keep far away from them. like thorn bushes and traps in their way. So be careful to keep far away from them."
    },
    {
      "verse": "6",
      "text": "If you teach children the right way to live, they will not forget it when they are older. they will not forget it when they are older."
    },
    {
      "verse": "7",
      "text": "Rich people have authority over poor people. People who borrow money have to serve those who lend it to them. People who borrow money have to serve those who lend it to them."
    },
    {
      "verse": "8",
      "text": "If you plant evil things, your harvest will be trouble. If you are angry and you hurt people, it will never help you. your harvest will be trouble. If you are angry and you hurt people, it will never help you."
    },
    {
      "verse": "9",
      "text": "If you are kind to poor people and you share your food with them, God will bless you. God will bless you."
    },
    {
      "verse": "10",
      "text": "If someone laughs at what is right, send him away. Then there will be no more arguments, quarrels and insults. Then there will be no more arguments, quarrels and insults."
    },
    {
      "verse": "11",
      "text": "If you live in a pure way, and you speak kind words, you will have the king as your friend. you will have the king as your friend."
    },
    {
      "verse": "12",
      "text": "The Lord watches over truth, to keep it safe. But when people tell lies, he makes them useless. But when people tell lies, he makes them useless."
    },
    {
      "verse": "13",
      "text": "A lazy person stays in his house. He says, ‘There is a lion outside in the street! If I go out, it will kill me! ’ He says, ‘There is a lion outside in the street! If I go out, it will kill me! ’"
    },
    {
      "verse": "14",
      "text": "The mouth of an adulteress is like a deep hole. If you make the Lord angry, you will fall into it! If you make the Lord angry, you will fall into it!"
    },
    {
      "verse": "15",
      "text": "Children love to do foolish things. To stop them, you must warn and punish them. To stop them, you must warn and punish them."
    },
    {
      "verse": "16",
      "text": "Someone may be cruel to poor people to make himself rich. Someone else may give gifts to rich people to make them his friends. But both those people will become poor in the end. Someone else may give gifts to rich people to make them his friends. But both those people will become poor in the end."
    },
    {
      "verse": "17",
      "text": "Listen carefully. I will teach you what wise people have said. Think about the things that I am teaching you."
    },
    {
      "verse": "18",
      "text": "If you remember these things, you will be happy. Tell them to other people."
    },
    {
      "verse": "19",
      "text": "I want you to trust in the Lord. So I will tell you these things today. They are for you."
    },
    {
      "verse": "20",
      "text": "wise thoughts for you. They will teach you what is right, so that you know how to live well."
    },
    {
      "verse": "21",
      "text": "You can trust these words because they are true. Then you can give a good answer to the people who sent you to me."
    },
    {
      "verse": "22",
      "text": "1. Do not cheat poor people just because they are poor. Do not attack helpless people in court."
    },
    {
      "verse": "23",
      "text": "The Lord will speak on their behalf. He will punish anyone who cheats them."
    },
    {
      "verse": "24",
      "text": "2. Do not become a friend of angry people. Keep away from them."
    },
    {
      "verse": "25",
      "text": "You might become angry, like them. Then you would spoil your whole life."
    },
    {
      "verse": "26",
      "text": "3. Do not promise to pay someone else's debt."
    },
    {
      "verse": "27",
      "text": "If you cannot pay, they will take away your bed, even while you are sleeping on it!"
    },
    {
      "verse": "28",
      "text": "4. Do not move any stone that shows the border of your land. Your ancestors put it there to stop arguments."
    },
    {
      "verse": "29",
      "text": "5. A worker with special skills may work for a king. He will no longer have to work for ordinary people."
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "6. When you sit down to eat a meal with a ruler, be careful how you eat."
    },
    {
      "verse": "2",
      "text": "Even if you enjoy your food, do not eat too much of it."
    },
    {
      "verse": "3",
      "text": "Do not want his special food for yourself. He may be trying to deceive you."
    },
    {
      "verse": "4",
      "text": "7. Do not work so hard to become rich that you make yourself ill. Be wise and rest when you need to."
    },
    {
      "verse": "5",
      "text": "Your money can disappear very quickly. It may seem to grow wings and then fly far away like an eagle."
    },
    {
      "verse": "6",
      "text": "8. Do not go and eat a meal with someone who hates to spend his money. His food may be good, but do not be greedy for it."
    },
    {
      "verse": "7",
      "text": "He says, ‘Eat and drink as much as you want, ’ but he does not really mean that. He is thinking about the cost of the food."
    },
    {
      "verse": "8",
      "text": "Even if you only eat a little of his food, it will make you sick. All your nice words to him will be useless."
    },
    {
      "verse": "9",
      "text": "9. Do not speak to foolish people. They will think that your wise words are silly."
    },
    {
      "verse": "10",
      "text": "10. Never move a stone that has always shown the border of someone's land. Do not take for yourself the fields of people who have no family to help them."
    },
    {
      "verse": "11",
      "text": "God himself will be the relative who helps them. He will speak against you in court."
    },
    {
      "verse": "12",
      "text": "11. Listen carefully to your teacher and study well. Then you will learn knowledge."
    },
    {
      "verse": "13",
      "text": "12. Remember to warn your children when they do something wrong. If you punish them with a stick, you will not kill them."
    },
    {
      "verse": "14",
      "text": "Punishment may save them from death."
    },
    {
      "verse": "15",
      "text": "13. My child, if you become wise, I will be happy."
    },
    {
      "verse": "16",
      "text": "When I hear you speak true words, it will make me very happy."
    },
    {
      "verse": "17",
      "text": "14. Do not be jealous of sinners. Always respect the Lord and obey him in everything that you do."
    },
    {
      "verse": "18",
      "text": "Then you will be happy in future days. What you hope for will surely happen."
    },
    {
      "verse": "19",
      "text": "15. Listen to me, my child. Learn to be wise and to live in a good way."
    },
    {
      "verse": "20",
      "text": "Do not be a friend of people who become drunk. Do not be a friend of greedy people who eat too much."
    },
    {
      "verse": "21",
      "text": "People who are like that soon become poor. They sleep too much, and their clothes have holes in them."
    },
    {
      "verse": "22",
      "text": "16. Listen to your father. You would not be alive without him. Continue to respect your mother when she becomes old."
    },
    {
      "verse": "23",
      "text": "Truth, wisdom, good teaching and knowledge are valuable things. Buy them for yourself. Do not sell them."
    },
    {
      "verse": "24",
      "text": "The father of a righteous person will be very happy. He will be proud of a wise child."
    },
    {
      "verse": "25",
      "text": "So make your father and your mother proud of you. Do things that will make your mother happy."
    },
    {
      "verse": "26",
      "text": "17. Listen to me carefully, my son. Watch how I live."
    },
    {
      "verse": "27",
      "text": "Prostitutes are a dangerous trap for men. Women who are not faithful to their husbands can cause men to fall into danger, like a deep well."
    },
    {
      "verse": "28",
      "text": "They are like robbers who wait to attack people. They take more and more men away from their wives."
    },
    {
      "verse": "31",
      "text": "So do not even look at that beautiful red wine! Do not think about the pleasure it would give to you."
    },
    {
      "verse": "32",
      "text": "In the end, it will bite you, like a snake with its poison."
    },
    {
      "verse": "33",
      "text": "Your eyes will see strange things. Your mind will be confused so that you say crazy things."
    },
    {
      "verse": "34",
      "text": "You will roll about, like a man who tries to sleep on a ship in a storm."
    },
    {
      "verse": "35",
      "text": "You will say, ‘Somebody must have hit me, but I do not remember what happened. I need to wake up soon and have another drink. ’"
    },
    {
      "verse": "29",
      "text": "18. People who drink too much wine have many problems."
    },
    {
      "verse": "30",
      "text": "Do you see someone who is in trouble? Someone who is very sad? Someone who argues or complains all the time? Do you see someone with wounds on his body for no reason, or someone with red eyes? Then you are looking at someone who likes to drink wine until late at night. He is someone who likes to try different drinks."
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "19. Do not be jealous of evil people. Do not try to be friends with them."
    },
    {
      "verse": "2",
      "text": "They only think about how to cause trouble. They only speak to be cruel."
    },
    {
      "verse": "3",
      "text": "20. It is wisdom that helps a man to build a house. The house will have a strong foundation if he understands what is right."
    },
    {
      "verse": "4",
      "text": "Knowledge will help him to fill its rooms with beautiful and valuable things."
    },
    {
      "verse": "5",
      "text": "21. A wise man is better than a brave soldier. If a man learns knowledge, he will become stronger."
    },
    {
      "verse": "6",
      "text": "If you receive good advice before you fight a battle, you will win against your enemy."
    },
    {
      "verse": "7",
      "text": "22. A fool cannot understand wisdom. He has nothing to say when leaders meet."
    },
    {
      "verse": "8",
      "text": "23. If anyone has ideas to do evil things, people will know that he always causes trouble."
    },
    {
      "verse": "9",
      "text": "If you decide to do something foolish, that is a sin. People hate anyone who laughs at others."
    },
    {
      "verse": "10",
      "text": "24. If you stop trying in times of trouble, you are really very weak."
    },
    {
      "verse": "11",
      "text": "25. You should rescue people who are in danger of death."
    },
    {
      "verse": "12",
      "text": "You may say, ‘We did not know what was happening. ’ But God knows your thoughts. He carefully watches your life and he knows what you are doing. He will pay back to you whatever you deserve."
    },
    {
      "verse": "13",
      "text": "26. My child, honey is good for you, so eat it. It is sweet on your tongue when you taste it."
    },
    {
      "verse": "14",
      "text": "In the same way, wisdom is also good for you. If you find wisdom, it will help you in life. The things that you hope for in the future will surely happen."
    },
    {
      "verse": "15",
      "text": "27. Do not be like wicked people who attack righteous people. Do not try to rob the homes of honest people."
    },
    {
      "verse": "16",
      "text": "If an honest person falls down seven times, he will still stand up again. But when trouble comes to a wicked person, that is the end of him."
    },
    {
      "verse": "17",
      "text": "28. Do not shout with joy when your enemy falls down. Do not be happy when his foot slips."
    },
    {
      "verse": "18",
      "text": "The Lord will know what you are thinking, and he will not be happy. He may decide not to punish your enemy."
    },
    {
      "verse": "19",
      "text": "29. Do not have trouble in your mind because of evil people. Do not be jealous of them."
    },
    {
      "verse": "20",
      "text": "A wicked person has nothing to hope for in the future. His life will end suddenly."
    },
    {
      "verse": "21",
      "text": "30. My child, respect and obey the Lord, and the king too. Do not be friends with people who turn against them."
    },
    {
      "verse": "22",
      "text": "Both the Lord and the king have the power to give strong punishment. In a moment they can destroy people who turn against them."
    },
    {
      "verse": "23",
      "text": "These are more things that wise people have said: When you judge people, be fair. It is not good to respect some people more than others."
    },
    {
      "verse": "24",
      "text": "A judge must not say to a guilty person, ‘You are not guilty. ’ If he does say that, everyone will curse him. People of all nations will say that he is bad."
    },
    {
      "verse": "25",
      "text": "When judges decide to punish a guilty person, they will be happy, because God will bless them."
    },
    {
      "verse": "26",
      "text": "Somebody who gives you an honest answer is your true friend."
    },
    {
      "verse": "27",
      "text": "Finish your work outside and prepare your fields. After that, you can build your house."
    },
    {
      "verse": "28",
      "text": "If you do not know what is true, do not speak against your neighbour in court. Do not deceive people with what you say."
    },
    {
      "verse": "29",
      "text": "Do not say, ‘I will do to him the same thing that he did to me. I will punish him because of what he did. ’"
    },
    {
      "verse": "30",
      "text": "I walked past the field of a lazy person. And I walked past the vineyard of a stupid person."
    },
    {
      "verse": "31",
      "text": "There were weeds and thorn bushes over all the ground. The wall of stones round the field had fallen down."
    },
    {
      "verse": "32",
      "text": "I looked at this and I thought about it carefully. I learned a lesson from the things that I had seen:"
    },
    {
      "verse": "33",
      "text": "You may say, ‘I will have a short sleep. I will rest quietly for a while. ’"
    },
    {
      "verse": "34",
      "text": "But while you sleep you will suddenly become poor. You will have nothing, as if someone has robbed you."
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "These are more of Solomon's proverbs. Hezekiah's men wrote them down when Hezekiah was king of Judah."
    },
    {
      "verse": "2",
      "text": "God hides things because he is great. But great kings can explain things."
    },
    {
      "verse": "3",
      "text": "You can never know all the thoughts of a king. They go high above the sky and deep below the earth."
    },
    {
      "verse": "4",
      "text": "If you remove dirt from silver, a worker can use it to make a beautiful thing."
    },
    {
      "verse": "5",
      "text": "In the same way, you should keep wicked people away from the king. Then he will rule in a right way."
    },
    {
      "verse": "6",
      "text": "When you stand in front of the king, do not be proud. Do not stand where the important people stand."
    },
    {
      "verse": "7",
      "text": "Then it will be good if the king says to you, ‘Come and sit up here, near me. ’ That would be better than if he sends you away while his officers watch."
    },
    {
      "verse": "8",
      "text": "If you see something bad happen, do not quickly go and tell a judge. Your neighbour may show that you are wrong. Then you will be ashamed. You will not know what to do."
    },
    {
      "verse": "9",
      "text": "If you argue with your neighbour, do not tell his secrets to other people."
    },
    {
      "verse": "10",
      "text": "If you do that, everyone will know about it. Then you will be ashamed for your whole life."
    },
    {
      "verse": "11",
      "text": "A wise word that you speak at the right time is a beautiful thing. It is like a gold apple on a silver plate."
    },
    {
      "verse": "12",
      "text": "When a wise person warns you, that is also a beautiful thing. It is like a gold ear-ring or a gold necklace."
    },
    {
      "verse": "13",
      "text": "When a faithful servant takes a message for his master, his master will have peace in his mind. It will keep him cool, like snow in the middle of summer."
    },
    {
      "verse": "14",
      "text": "Some people promise things, but they never do anything. Those people are like clouds and wind that do not bring any rain."
    },
    {
      "verse": "15",
      "text": "If you are patient, you may make a ruler change his mind. If you speak a quiet word, you can remove a difficult problem."
    },
    {
      "verse": "16",
      "text": "When you find honey, never eat more than you need. If you eat too much, you will become very sick."
    },
    {
      "verse": "17",
      "text": "Do not visit your neighbour's house too often. He may see you too much and he will start to hate you."
    },
    {
      "verse": "18",
      "text": "Some people may tell lies about their neighbour in court. Those people are like dangerous weapons, like sharp swords or arrows."
    },
    {
      "verse": "19",
      "text": "If you are in trouble and you trust someone who is not honest, it will not help you. He will be as useless as a bad tooth or a broken leg."
    },
    {
      "verse": "20",
      "text": "If you sing to a very sad man to make him happy, it only gives him more pain. It is like you are taking away his coat on a cold day, or you are putting vinegar on his wound."
    },
    {
      "verse": "21",
      "text": "If your enemy is hungry, give him something to eat. If he is thirsty, give him some water to drink."
    },
    {
      "verse": "22",
      "text": "If you help him, he will become ashamed, and the Lord will bless you with good things."
    },
    {
      "verse": "23",
      "text": "When the wind blows from the north, it brings rain. In the same way, when somebody tells other people's secrets, it brings anger."
    },
    {
      "verse": "24",
      "text": "It is better to live on the roof of your house than to live with a wife who always argues."
    },
    {
      "verse": "25",
      "text": "If you receive good news from a far away country, it is like cool water when you are tired and thirsty."
    },
    {
      "verse": "26",
      "text": "If you put dirt in a well, its good water becomes bad. It is the same with a righteous person who agrees to do wicked things."
    },
    {
      "verse": "27",
      "text": "It is bad for you to eat too much honey. If you always want people to praise you, it is also bad for you."
    },
    {
      "verse": "28",
      "text": "Somebody who cannot control his anger is in danger. He is like a city that no longer has a strong wall round it."
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "It is not right to give honour to a fool. It is as silly as snow that falls in summer, or rain that falls at the time of harvest. It is as silly as snow that falls in summer, or rain that falls at the time of harvest."
    },
    {
      "verse": "2",
      "text": "If someone curses you for no reason, it will not stay with you. Their words will be like birds that never stop to rest. Their words will be like birds that never stop to rest."
    },
    {
      "verse": "3",
      "text": "There are right ways to punish a horse or a donkey. The right way to punish a fool is to beat him with a stick. The right way to punish a fool is to beat him with a stick."
    },
    {
      "verse": "4",
      "text": "If someone asks you a silly question, do not give him a silly answer. Be careful that you do not become as silly as he is. Be careful that you do not become as silly as he is."
    },
    {
      "verse": "5",
      "text": "If someone asks you a silly question, give him a silly answer. Then he will know that he is not as wise as he thinks he is. Then he will know that he is not as wise as he thinks he is."
    },
    {
      "verse": "6",
      "text": "If you send a message with a fool, there will be trouble. It would be better to cut off your own feet! It would be better to cut off your own feet!"
    },
    {
      "verse": "7",
      "text": "A lame person cannot use his legs properly. A fool cannot use a proverb properly. A fool cannot use a proverb properly."
    },
    {
      "verse": "8",
      "text": "If you tie a stone into a sling, it will be a useless weapon. It is also useless to give honour to a fool. It is also useless to give honour to a fool."
    },
    {
      "verse": "9",
      "text": "A fool who speaks a proverb is like a drunk person with a thorn in his finger. He does not know what to do with it. He does not know what to do with it."
    },
    {
      "verse": "10",
      "text": "A soldier who shoots his arrows everywhere is useless. It is the same if you ask a stupid person to do work for you. It is the same if you ask a stupid person to do work for you."
    },
    {
      "verse": "11",
      "text": "A sick dog goes back to eat what it could not keep in its stomach. A fool goes back and makes the same mistakes again. A fool goes back and makes the same mistakes again."
    },
    {
      "verse": "12",
      "text": "Some men think that they are already wise. A fool is more likely to learn something than they are. A fool is more likely to learn something than they are."
    },
    {
      "verse": "13",
      "text": "A lazy person does not go out of his house. He says, ‘There is a lion outside in the street! ’ He says, ‘There is a lion outside in the street! ’"
    },
    {
      "verse": "14",
      "text": "A lazy person turns over in his bed, like a door that continues to open and close. like a door that continues to open and close."
    },
    {
      "verse": "15",
      "text": "A lazy person pushes his hand into his bowl of food. But then he is too tired to lift his hand up to his mouth. But then he is too tired to lift his hand up to his mouth."
    },
    {
      "verse": "16",
      "text": "A lazy person thinks that he is very wise. He thinks that he is wiser than seven people who can answer questions well. He thinks that he is wiser than seven people who can answer questions well."
    },
    {
      "verse": "17",
      "text": "When strangers are arguing, only a fool joins the argument. It would be better if he took hold of a wild dog's ears! It would be better if he took hold of a wild dog's ears!"
    },
    {
      "verse": "18",
      "text": "A crazy man may shoot sharp arrows to kill people."
    },
    {
      "verse": "19",
      "text": "If a person deceives his friend and then laughs about it, he is as bad as that crazy person. he is as bad as that crazy person."
    },
    {
      "verse": "20",
      "text": "Without wood, a fire stops burning. When people do not tell their friends' secrets, quarrels stop. When people do not tell their friends' secrets, quarrels stop."
    },
    {
      "verse": "21",
      "text": "But when a fire has wood, it continues to burn. When people love to quarrel, there will always be arguments. When people love to quarrel, there will always be arguments."
    },
    {
      "verse": "22",
      "text": "We love to hear other people's secrets. They seem like good food that we can really enjoy. They seem like good food that we can really enjoy."
    },
    {
      "verse": "23",
      "text": "When a hypocrite says nice words, that is like a cheap pot with silver paint. that is like a cheap pot with silver paint."
    },
    {
      "verse": "24",
      "text": "A hypocrite can say nice things to hide his thoughts, but he is still thinking about ways to hurt people. but he is still thinking about ways to hurt people."
    },
    {
      "verse": "25",
      "text": "Do not believe him when he speaks kind words. His mind is still full of evil things. His mind is still full of evil things."
    },
    {
      "verse": "26",
      "text": "He may not seem to hate people, but he is telling lies. In a public meeting, everyone will recognize his sins. In a public meeting, everyone will recognize his sins."
    },
    {
      "verse": "27",
      "text": "If a man digs a deep hole as a trap, he will fall into it himself. If a man pushes a stone to fall on someone, it will fall back on him. If a man pushes a stone to fall on someone, it will fall back on him."
    },
    {
      "verse": "28",
      "text": "If you tell lies, it shows that you hate other people. If you deceive people with sweet words, you will destroy them."
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "Do not boast about what you will do tomorrow. You do not know what might happen. You do not know what might happen."
    },
    {
      "verse": "2",
      "text": "Let other people praise you. Do not boast about yourself. Do not boast about yourself."
    },
    {
      "verse": "3",
      "text": "A stone is heavy to carry and sand also weighs a lot. But the silly acts of a fool give more pain than both of those. But the silly acts of a fool give more pain than both of those."
    },
    {
      "verse": "4",
      "text": "An angry person does cruel things that can destroy people. But a jealous person is much worse. But a jealous person is much worse."
    },
    {
      "verse": "5",
      "text": "When a friend is not afraid to warn you that you are wrong, it shows that he really loves you. it shows that he really loves you."
    },
    {
      "verse": "6",
      "text": "You can trust a friend when he says things that hurt you. But when an enemy kisses you, he is deceiving you. But when an enemy kisses you, he is deceiving you."
    },
    {
      "verse": "7",
      "text": "A person who has eaten enough food will refuse honey. But even bitter food seems sweet to a hungry person. But even bitter food seems sweet to a hungry person."
    },
    {
      "verse": "8",
      "text": "A person who travels away from his homeis like a bird that flies away from its nest. is like a bird that flies away from its nest."
    },
    {
      "verse": "9",
      "text": "Beautiful oil and perfume may give you joy. But good advice from a friend is even better. But good advice from a friend is even better."
    },
    {
      "verse": "10",
      "text": "Do not forget your friends or your father's friends. If you are in trouble, do not ask your relatives to help you. A friend who is a neighbour will be more help than a relative who lives far away. If you are in trouble, do not ask your relatives to help you. A friend who is a neighbour will be more help than a relative who lives far away."
    },
    {
      "verse": "11",
      "text": "My son, if you are wise, I will be happy. I will be able to answer anyone who insults me. I will be able to answer anyone who insults me."
    },
    {
      "verse": "12",
      "text": "A careful person can see danger and he will hide himself. But a silly person never stops, and he walks into trouble. But a silly person never stops, and he walks into trouble."
    },
    {
      "verse": "13",
      "text": "If someone promises to pay the debts of a stranger, take his coat as a guarantee that he will pay. take his coat as a guarantee that he will pay."
    },
    {
      "verse": "14",
      "text": "If you shout a blessing to your neighbour early in the morning, he will think it is no better than a curse. he will think it is no better than a curse."
    },
    {
      "verse": "15",
      "text": "A wife who is always arguing with youis as bad as rain that never stops falling. is as bad as rain that never stops falling."
    },
    {
      "verse": "16",
      "text": "Can you catch the wind? Can you hold oil in your hand? No! And you cannot keep that woman quiet. No! And you cannot keep that woman quiet."
    },
    {
      "verse": "17",
      "text": "People learn from each other, as one iron tool can make another one sharp. as one iron tool can make another one sharp."
    },
    {
      "verse": "18",
      "text": "If you take care of a fig tree, it will give you fruit to eat. If you take care of your master, he will give you honour. If you take care of your master, he will give you honour."
    },
    {
      "verse": "19",
      "text": "A man can see his face in a mirror. But his thoughts show what he is really like. But his thoughts show what he is really like."
    },
    {
      "verse": "20",
      "text": "The deep hole of death always wants more dead people to fill it. In the same way, a person wants to have everything that he sees. In the same way, a person wants to have everything that he sees."
    },
    {
      "verse": "21",
      "text": "You need a hot fire to see if silver and gold are pure. In the same way, when people praise you, they can see what you are really like. In the same way, when people praise you, they can see what you are really like."
    },
    {
      "verse": "22",
      "text": "Even if you beat a fool with a big stick, as hard as you beat grain, you will never remove all his silly ideas. you will never remove all his silly ideas."
    },
    {
      "verse": "23",
      "text": "Always take care of your sheep and your goats, as well as your cows."
    },
    {
      "verse": "24",
      "text": "Your riches will not be there for ever. One family does not rule a kingdom for ever."
    },
    {
      "verse": "25",
      "text": "One day you will cut the grass in your fields and then new grass will grow. You will store the grass that has grown on the hills."
    },
    {
      "verse": "26",
      "text": "Then you will use the wool from your sheep to make clothes. You make clothes from your sheep's wool. You will sell your goats, and you will buy a field."
    },
    {
      "verse": "27",
      "text": "You will have enough milk from your goats to feed yourself, your family and your female servants."
    }
  ],
  "28": [
    {
      "verse": "1",
      "text": "A wicked person runs away even when nobody is chasing him. But a righteous person is as brave as a lion. But a righteous person is as brave as a lion."
    },
    {
      "verse": "2",
      "text": "When the people in a country refuse to obey the law, they will have many rulers. But if a country has a wise ruler who understands what is right, it will continue to be strong. they will have many rulers. But if a country has a wise ruler who understands what is right, it will continue to be strong."
    },
    {
      "verse": "3",
      "text": "A poor person who is cruel to helpless peopleis like a storm that destroys crops. is like a storm that destroys crops."
    },
    {
      "verse": "4",
      "text": "People who do not obey the law praise wicked people. But people who obey the law speak against wicked people. But people who obey the law speak against wicked people."
    },
    {
      "verse": "5",
      "text": "Evil people do not understand justice. But people who serve the Lord understand all about it. But people who serve the Lord understand all about it."
    },
    {
      "verse": "6",
      "text": "It is better to be poor and live in an honest waythan to be a rich hypocrite. than to be a rich hypocrite."
    },
    {
      "verse": "7",
      "text": "If you obey the law, you are a wise child. But if you make friends with greedy people, you will make your parents ashamed. But if you make friends with greedy people, you will make your parents ashamed."
    },
    {
      "verse": "8",
      "text": "If you make people pay more when you lend money to them, you may become rich. But someone else will enjoy your riches. They will go to someone who is kind to poor people. you may become rich. But someone else will enjoy your riches. They will go to someone who is kind to poor people."
    },
    {
      "verse": "9",
      "text": "If you refuse to listen to God's law, God will refuse to listen to your prayers. God will refuse to listen to your prayers."
    },
    {
      "verse": "10",
      "text": "If you cause a good person to do evil things, your own evil trap will catch you. But people who do nothing wrong will receive good things. your own evil trap will catch you. But people who do nothing wrong will receive good things."
    },
    {
      "verse": "11",
      "text": "A rich person thinks that he knows everything. But a poor person who understands people knows what he is really like. But a poor person who understands people knows what he is really like."
    },
    {
      "verse": "12",
      "text": "When righteous people have power, everybody is happy. But when wicked people have power, good people run away to hide. everybody is happy. But when wicked people have power, good people run away to hide."
    },
    {
      "verse": "13",
      "text": "Anyone who hides his sins will never do well. But God will forgive somebody, if he agrees that he has done wrong things, and if he turns away from his sins. But God will forgive somebody, if he agrees that he has done wrong things, and if he turns away from his sins."
    },
    {
      "verse": "14",
      "text": "If you are afraid to do wrong things, God will bless you. But trouble will happen to anyone who refuses to obey. But trouble will happen to anyone who refuses to obey."
    },
    {
      "verse": "15",
      "text": "A wicked ruler brings danger to poor people. He is as dangerous as an angry lion or a hungry bear. He is as dangerous as an angry lion or a hungry bear."
    },
    {
      "verse": "16",
      "text": "If a ruler is cruel, it shows that he is not wise. But a ruler who refuses bribes will rule for a long time. But a ruler who refuses bribes will rule for a long time."
    },
    {
      "verse": "17",
      "text": "Someone who is guilty of murder will be running until he dies. Nobody should help him to escape. Nobody should help him to escape."
    },
    {
      "verse": "18",
      "text": "If you live in an honest way, you will be safe. But the hypocrite will suddenly fall into trouble. But the hypocrite will suddenly fall into trouble."
    },
    {
      "verse": "19",
      "text": "A farmer who works hard will have plenty of food to eat. But anyone who works only on useless things will always be poor. But anyone who works only on useless things will always be poor."
    },
    {
      "verse": "20",
      "text": "A faithful person will receive many blessings. But anyone who hurries to become rich will only receive punishment. But anyone who hurries to become rich will only receive punishment."
    },
    {
      "verse": "21",
      "text": "When you judge people, you must always be fair. That is the right thing to do. But even a small bribe can make some people do the wrong thing. But even a small bribe can make some people do the wrong thing."
    },
    {
      "verse": "22",
      "text": "Greedy people hurry to become rich. They do not know that they will soon be poor. They do not know that they will soon be poor."
    },
    {
      "verse": "23",
      "text": "If you warn someone that he has done a wrong thing, he will thank you in the end. He will like you more than if you only say sweet words to him. he will thank you in the end. He will like you more than if you only say sweet words to him."
    },
    {
      "verse": "24",
      "text": "If anyone cheats his parents, he may say that he has done nothing wrong. But a person like that is as bad as a robber. he may say that he has done nothing wrong. But a person like that is as bad as a robber."
    },
    {
      "verse": "25",
      "text": "Greedy people cause a lot of trouble. But someone who trusts the Lord will enjoy many good things. But someone who trusts the Lord will enjoy many good things."
    },
    {
      "verse": "26",
      "text": "If you trust your own thoughts, you are a fool. But if you live in a wise way, you will be safe from danger. But if you live in a wise way, you will be safe from danger."
    },
    {
      "verse": "27",
      "text": "If you give things to poor people, you will still have enough for yourself. But everyone will curse you if you refuse to help poor people. But everyone will curse you if you refuse to help poor people."
    },
    {
      "verse": "28",
      "text": "When wicked people become powerful, everyone runs away to hide. But when wicked people lose their power, righteous people do well again."
    }
  ],
  "29": [
    {
      "verse": "1",
      "text": "You may warn a proud person many times, but he will not listen to you. Trouble will suddenly happen to him and he will not escape. Trouble will suddenly happen to him and he will not escape."
    },
    {
      "verse": "2",
      "text": "When righteous people are doing well, everyone is happy. But when wicked people rule, everyone is sad. But when wicked people rule, everyone is sad."
    },
    {
      "verse": "3",
      "text": "A man who loves wisdom makes his father happy. But anyone who is a friend of prostitutes is wasting his father's money. But anyone who is a friend of prostitutes is wasting his father's money."
    },
    {
      "verse": "4",
      "text": "A king who rules with justice makes his country strong. But a king who takes lots of taxes destroys his country. But a king who takes lots of taxes destroys his country."
    },
    {
      "verse": "5",
      "text": "If you always praise your friends with sweet words, that will be a trap that you walk into yourself. that will be a trap that you walk into yourself."
    },
    {
      "verse": "6",
      "text": "The sin of an evil person becomes a trap that catches him. But a righteous person sings with joy. But a righteous person sings with joy."
    },
    {
      "verse": "7",
      "text": "Righteous people want poor people to receive justice. But wicked people do not understand things like that. But wicked people do not understand things like that."
    },
    {
      "verse": "8",
      "text": "People who insult their friends bring trouble to a city. But wise people stop arguments. But wise people stop arguments."
    },
    {
      "verse": "9",
      "text": "If a wise person accuses a foolish person in court, there will be no agreement. The fool will only laugh or he will become angry. there will be no agreement. The fool will only laugh or he will become angry."
    },
    {
      "verse": "10",
      "text": "Murderers hate honest people. They try to kill any good person. They try to kill any good person."
    },
    {
      "verse": "11",
      "text": "Foolish people cannot control their anger. But wise people are patient. But wise people are patient."
    },
    {
      "verse": "12",
      "text": "When a ruler listens to lies, all his officers will be wicked. all his officers will be wicked."
    },
    {
      "verse": "13",
      "text": "The Lord gives light to all people so that they can see. He does that for poor people and also those who are cruel to them. He does that for poor people and also those who are cruel to them."
    },
    {
      "verse": "14",
      "text": "If a king judges poor people in a true way, he will always have the power to rule. he will always have the power to rule."
    },
    {
      "verse": "15",
      "text": "If you want your children to be wise, warn them and punish them when they do wrong things. If you let them do anything that they want to do, they will make their mother ashamed. warn them and punish them when they do wrong things. If you let them do anything that they want to do, they will make their mother ashamed."
    },
    {
      "verse": "16",
      "text": "When wicked people receive more power, there is also more sin. But those wicked people will fall while righteous people watch. But those wicked people will fall while righteous people watch."
    },
    {
      "verse": "17",
      "text": "Warn your children when they do wrong things, so that you have peace in your mind. They will make you very happy. so that you have peace in your mind. They will make you very happy."
    },
    {
      "verse": "18",
      "text": "If people do not hear God's message, there is no law to control them. But if someone obeys God's law, he is in a happy place. there is no law to control them. But if someone obeys God's law, he is in a happy place."
    },
    {
      "verse": "19",
      "text": "You must use more than words to show a servant what is right. Even if he understands what you say, he will not obey you. Even if he understands what you say, he will not obey you."
    },
    {
      "verse": "20",
      "text": "Do you know anyone who speaks before he thinks? A foolish person is more likely to become wise than that person. A foolish person is more likely to become wise than that person."
    },
    {
      "verse": "21",
      "text": "You may give a servant everything that he wants from his birth. But if you do that, he will be useless in the end. But if you do that, he will be useless in the end."
    },
    {
      "verse": "22",
      "text": "An angry person causes arguments. When he is angry, he causes many sins to happen. When he is angry, he causes many sins to happen."
    },
    {
      "verse": "23",
      "text": "A person's pride will bring shame to him. But a humble person will receive honour. But a humble person will receive honour."
    },
    {
      "verse": "24",
      "text": "If you help a robber, you are bringing punishment on yourself. If you tell the truth in court, or if you keep quiet, you will receive your punishment. If you tell the truth in court, or if you keep quiet, you will receive your punishment."
    },
    {
      "verse": "25",
      "text": "If you are afraid of what people think about you, you will never feel safe. But if you trust in the Lord, he will keep you safe. you will never feel safe. But if you trust in the Lord, he will keep you safe."
    },
    {
      "verse": "26",
      "text": "Many people want the king to be their friend. But only the Lord can give you true justice. But only the Lord can give you true justice."
    },
    {
      "verse": "27",
      "text": "Righteous people hate wicked people. Wicked people also hate people who live in a good way."
    }
  ],
  "30": [
    {
      "verse": "1",
      "text": "These are the words of Jakeh's son, Agur. It is an important message. The man says this to Ithiel: God, I am weak and tired. I cannot continue to stand. God, I am weak and tired. I cannot continue to stand."
    },
    {
      "verse": "2",
      "text": "I feel more stupid than any other person. I do not understand things as other people do."
    },
    {
      "verse": "3",
      "text": "I have never learned wisdom. I do not know anything about God, the Holy One."
    },
    {
      "verse": "4",
      "text": "No one has gone up to heaven and then come back. No one has held the wind in his hands. No one has tied his coat around the seas. No one has fixed the borders of the earth. If anyone has done this, tell me his name. Tell me his son's name. Tell me, if you know."
    },
    {
      "verse": "5",
      "text": "Everything that God says is completely true. If you trust him, he will protect you like a soldier's shield."
    },
    {
      "verse": "6",
      "text": "Do not add anything to what God has said. If you do that, he will warn you. He will show that you are someone who tells lies."
    },
    {
      "verse": "7",
      "text": "God, I ask you to do two things for me. Please do them before I die:"
    },
    {
      "verse": "8",
      "text": "Do not let me ever deceive people with lies. Do not let me be too rich or too poor. Give me only as much food as I need each day. Do not let me be too rich or too poor. Give me only as much food as I need each day."
    },
    {
      "verse": "9",
      "text": "If I have more than enough, I might say that I do not know you. I might say, ‘Who is the Lord? ’But if I am poor, I might rob people. That would insult my God's good name. But if I am poor, I might rob people. That would insult my God's good name."
    },
    {
      "verse": "10",
      "text": "Do not say bad things about a servant to his master. If you do, the servant may curse you, and then you will be guilty."
    },
    {
      "verse": "11",
      "text": "There are some people who curse their fathers. They do not bless their mothers."
    },
    {
      "verse": "12",
      "text": "There are some people who think that they are perfect. But they are still dirty inside."
    },
    {
      "verse": "13",
      "text": "There are some people who are very proud. They look down on everyone else."
    },
    {
      "verse": "14",
      "text": "There are some people who are very cruel. Their teeth are like swords and sharp knives. They want to eat up all the poor and helpless people, so that they disappear from the earth."
    },
    {
      "verse": "15",
      "text": "A greedy leech has two daughters. They are always saying, ‘Give me more! ’There are three things that never have enough for themselves, even four things: There are three things that never have enough for themselves, even four things:"
    },
    {
      "verse": "16",
      "text": "The deep hole of death. A wife who has no children. Dry ground that needs rain. A fire that burns strongly."
    },
    {
      "verse": "17",
      "text": "Punishment will come to anyone who insults his father, or who refuses to listen to his mother. Wild birds will pick out his eyes and vultures will eat his body."
    },
    {
      "verse": "18",
      "text": "There are three things that are too difficult for me to understand, even four things:"
    },
    {
      "verse": "19",
      "text": "How an eagle flies high in the sky. How a snake moves across a rock. How a ship sails on the sea. How a man starts to love a young woman."
    },
    {
      "verse": "20",
      "text": "A woman who is not faithful to her husband does this: When she has sex with another man, she thinks it is like a meal that she has eaten. Then she washes herself and she says, ‘I have not done anything wrong. ’ That is something else that I cannot understand."
    },
    {
      "verse": "21",
      "text": "There are three things that make the earth shake, even four things:"
    },
    {
      "verse": "22",
      "text": "A slave who becomes a king. A fool who eats too much."
    },
    {
      "verse": "23",
      "text": "A woman that nobody loves who marries a husband. A female servant who takes the place of the woman that she has served."
    },
    {
      "verse": "24",
      "text": "There are four things that live on the earth which are very small, but they are also very wise:"
    },
    {
      "verse": "25",
      "text": "Ants are not very strong, but they prepare their food in the summer."
    },
    {
      "verse": "26",
      "text": "Rock badgers are weak animals, but they make their homes among the rocks."
    },
    {
      "verse": "27",
      "text": "Locusts have no king to lead them, but they all fly together as one."
    },
    {
      "verse": "28",
      "text": "Lizards are easy to catch with your hand, but you will see them in kings' palaces."
    },
    {
      "verse": "29",
      "text": "There are three things that seem great as they walk around, even four things:"
    },
    {
      "verse": "30",
      "text": "Lions are the strongest of all animals, and they are not afraid of anything."
    },
    {
      "verse": "31",
      "text": "Cockerels that shout proudly. Male goats. A king who has his army with him."
    },
    {
      "verse": "32",
      "text": "You may be foolish and too proud of yourself. You may have ideas to do evil things. If that is true, stop yourself! Do not say a word!"
    },
    {
      "verse": "33",
      "text": "If you beat milk for a long time, it will become butter. If you hit someone's nose, it will bleed. In the same way, if you make people angry, it will cause trouble."
    }
  ],
  "31": [
    {
      "verse": "1",
      "text": "These are the words that King Lemuel's mother said to him. It is an important message:"
    },
    {
      "verse": "2",
      "text": "Be careful, my dear son. God answered my prayers when I gave birth to you. Please listen carefully!"
    },
    {
      "verse": "3",
      "text": "Do not chase after women and lose your strength. Women like that have destroyed kings."
    },
    {
      "verse": "4",
      "text": "Listen, Lemuel. Kings should not drink lots of wine. They should not want strong drink."
    },
    {
      "verse": "5",
      "text": "When kings drink alcohol, they forget to obey the law. They take away justice for helpless people."
    },
    {
      "verse": "6",
      "text": "Give strong drink to people who are dying. Give wine to people who are very upset."
    },
    {
      "verse": "7",
      "text": "Then they can forget how poor they are, or how sad they are."
    },
    {
      "verse": "8",
      "text": "Speak on behalf of people who cannot speak for themselves. Help helpless people to receive justice."
    },
    {
      "verse": "9",
      "text": "Speak clearly to help them. Judge people in a way that is fair and right. Help poor and helpless people to receive justice."
    },
    {
      "verse": "10",
      "text": "How difficult it is to find a wife who is truly wise! She is worth much more than valuable jewels."
    },
    {
      "verse": "11",
      "text": "Her husband trusts her to help him. He will have everything that he needs."
    },
    {
      "verse": "12",
      "text": "She does good things for him every day of her life. She never tries to hurt him."
    },
    {
      "verse": "13",
      "text": "She is happy to work with her own hands to make clothes with wool and linen."
    },
    {
      "verse": "14",
      "text": "She brings special food from far away, like a ship that travels across the sea."
    },
    {
      "verse": "15",
      "text": "She gets up while it is still night and she prepares food for her family. She also gives some to her female servants."
    },
    {
      "verse": "16",
      "text": "She looks carefully at a field, and she decides to buy it. She uses her own money to plant a vineyard."
    },
    {
      "verse": "17",
      "text": "She is strong and she always works hard."
    },
    {
      "verse": "18",
      "text": "She knows how to make money as she buys and sells things. Even at night, she is still working."
    },
    {
      "verse": "19",
      "text": "She knows how to make cloth."
    },
    {
      "verse": "20",
      "text": "She gives money to poor and helpless people."
    },
    {
      "verse": "21",
      "text": "All her family have warm clothes to wear. She is not afraid when cold weather comes."
    },
    {
      "verse": "22",
      "text": "She makes beautiful cloths to cover the beds. Her own clothes are made with valuable linen and purple cloth."
    },
    {
      "verse": "23",
      "text": "People in the city respect her husband. He meets with the other leaders at the city's gate."
    },
    {
      "verse": "24",
      "text": "She uses linen to make clothes and she sells them. She makes belts to sell to the traders."
    },
    {
      "verse": "25",
      "text": "She shows her strength and people respect her. She is not afraid of what will happen in the future."
    },
    {
      "verse": "26",
      "text": "When she speaks, she says wise words. She is kind as she teaches people what is right."
    },
    {
      "verse": "27",
      "text": "She always works hard and she takes care of her family."
    },
    {
      "verse": "28",
      "text": "Her children all agree to thank her. Her husband also praises her."
    },
    {
      "verse": "29",
      "text": "He says, ‘Many women are wise and they work well, but you are better than all of them. ’"
    },
    {
      "verse": "30",
      "text": "A woman may seem to be beautiful, but that can deceive people. Her body will not be beautiful for ever. But a woman who respects the Lord with fear will receive honour. But a woman who respects the Lord with fear will receive honour."
    },
    {
      "verse": "31",
      "text": "Praise her for everything that she has done. Everyone in the city should know about her, and they should praise her as she deserves."
    }
  ]
};