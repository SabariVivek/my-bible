module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "In the first year that Cyrus, king of Persia, was ruling Babylon, the Lord put a thought in his mind. King Cyrus decided to send a message to everybody who lived in his kingdom. His message would cause what God had already spoken to his prophet Jeremiah to become true. The message was written down and people took it all over Cyrus's kingdom. It said:"
    },
    {
      "verse": "2",
      "text": "‘This is what Cyrus, the king of Persia says: The Lord, the God of heaven, has given me power over all the kingdoms of the earth. He has said that I must build a temple for him in Jerusalem, the city that is in Judah."
    },
    {
      "verse": "3",
      "text": "Any of God's people who live among you may now return to Jerusalem. I pray that their God will be with them. They must build a temple there for the Lord, Israel's God. He is the God whose home is in Jerusalem."
    },
    {
      "verse": "4",
      "text": "In places where there are some Israelites who want to return, their neighbours must help them with gifts. They should give them silver, gold and other things for their journey. They should also give them animals. They may also give them special gifts for God's temple that is in Jerusalem. ’"
    },
    {
      "verse": "5",
      "text": "Then the leaders of the families of Judah and Benjamin prepared to return to Jerusalem. The priests and the Levites also prepared to go. God had put a thought in the minds of all those people that they should go. So they prepared everything that they needed to go and build the Lord's temple in Jerusalem."
    },
    {
      "verse": "6",
      "text": "Their neighbours gave them silver things, gold things and other valuable gifts, as well as animals. They also gave them offerings for the temple."
    },
    {
      "verse": "7",
      "text": "Then King Cyrus brought the valuable things that King Nebuchadnezzar had taken from the Lord's temple in Jerusalem. Nebuchadnezzar had taken them from Jerusalem and brought them to Babylon. He had put them in the temple of his own gods."
    },
    {
      "verse": "8",
      "text": "Cyrus told his officer, Mithredath, to count all the valuable things. Mithredath was the officer who took care of all Persia's riches. As he counted the things, he gave them to Sheshbazzar, the leader of Judah's people."
    },
    {
      "verse": "9",
      "text": "They counted the things and they made this list:30 gold dishes. 1, 000 silver dishes. 29 special tools."
    },
    {
      "verse": "10",
      "text": "gold bowls. 410 silver bowls. 1, 000 other things."
    },
    {
      "verse": "11",
      "text": "There were 5, 400 things made from gold and silver. Sheshbazzar took them all with him when he left Babylon to return to Jerusalem with the other exiles."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "These are the people who returned to Jerusalem and the other towns in Judah. Nebuchadnezzar, king of Babylon, had brought them as prisoners to Babylon. Each person returned to his own town."
    },
    {
      "verse": "2",
      "text": "Their leaders were Zerubbabel, Jeshua, Nehemiah, Seraiah, Reelaiah, Mordecai, Bilshan, Mispar, Bigvai, Rehum and Baanah. This is the number of Israelite men from each clan:"
    },
    {
      "verse": "3",
      "text": "2, 172 descendants of Parosh."
    },
    {
      "verse": "4",
      "text": "descendants of Shephatiah."
    },
    {
      "verse": "5",
      "text": "descendants of Arah."
    },
    {
      "verse": "6",
      "text": "2, 812 descendants of Pahath-Moab (from the families of Jeshua and Joab)."
    },
    {
      "verse": "7",
      "text": "1, 254 descendants of Elam."
    },
    {
      "verse": "8",
      "text": "descendants of Zattu."
    },
    {
      "verse": "9",
      "text": "descendants of Zaccai."
    },
    {
      "verse": "10",
      "text": "descendants of Bani."
    },
    {
      "verse": "11",
      "text": "descendants of Bebai."
    },
    {
      "verse": "12",
      "text": "1, 222 descendants of Azgad."
    },
    {
      "verse": "13",
      "text": "descendants of Adonikam."
    },
    {
      "verse": "14",
      "text": "2, 056 descendants of Bigvai."
    },
    {
      "verse": "15",
      "text": "descendants of Adin."
    },
    {
      "verse": "16",
      "text": "descendants of Ater (from Hezekiah's family)."
    },
    {
      "verse": "17",
      "text": "descendants of Bezai."
    },
    {
      "verse": "18",
      "text": "descendants of Jorah."
    },
    {
      "verse": "19",
      "text": "descendants of Hashum."
    },
    {
      "verse": "20",
      "text": "descendants of Gibbar."
    },
    {
      "verse": "21",
      "text": "men from Bethlehem."
    },
    {
      "verse": "22",
      "text": "men from Netophah."
    },
    {
      "verse": "23",
      "text": "men from Anathoth."
    },
    {
      "verse": "24",
      "text": "men from Azmaveth."
    },
    {
      "verse": "25",
      "text": "men from Kiriath-Jearim, Kephirah and Beeroth."
    },
    {
      "verse": "26",
      "text": "men from Ramah and Geba."
    },
    {
      "verse": "27",
      "text": "men from Michmash."
    },
    {
      "verse": "28",
      "text": "men from Bethel and Ai."
    },
    {
      "verse": "29",
      "text": "men from Nebo."
    },
    {
      "verse": "30",
      "text": "men from Magbish."
    },
    {
      "verse": "31",
      "text": "1, 254 men from the other town called Elam."
    },
    {
      "verse": "32",
      "text": "men from Harim."
    },
    {
      "verse": "33",
      "text": "men from Lod, Hadid and Ono."
    },
    {
      "verse": "34",
      "text": "men from Jericho."
    },
    {
      "verse": "35",
      "text": "3, 630 men from Senaah."
    },
    {
      "verse": "36",
      "text": "These were the priests:973 descendants of Jedaiah (from Jeshua's family)."
    },
    {
      "verse": "37",
      "text": "1, 052 descendants of Immer."
    },
    {
      "verse": "38",
      "text": "1, 247 descendants of Pashhur."
    },
    {
      "verse": "39",
      "text": "1, 017 descendants of Harim."
    },
    {
      "verse": "40",
      "text": "These were the Levites:74 descendants of Jeshua and Kadmiel (from Hodaviah's family)."
    },
    {
      "verse": "41",
      "text": "The singers:128 descendants of Asaph."
    },
    {
      "verse": "42",
      "text": "The guards for the temple gates:139 descendants of Shallum, Ater, Talmon, Akkub, Hatita and Shobai."
    },
    {
      "verse": "43",
      "text": "The temple servants: the descendants of Ziha, Hasupha, Tabbaoth,"
    },
    {
      "verse": "44",
      "text": "Keros, Siaha, Padon,"
    },
    {
      "verse": "45",
      "text": "Lebanah, Hagabah, Akkub,"
    },
    {
      "verse": "46",
      "text": "Hagab, Shalmai, Hanan,"
    },
    {
      "verse": "47",
      "text": "Giddel, Gahar, Reaiah,"
    },
    {
      "verse": "48",
      "text": "Rezin, Nekoda, Gazzam,"
    },
    {
      "verse": "49",
      "text": "Uzza, Paseah, Besai,"
    },
    {
      "verse": "50",
      "text": "Asnah, Meunim, Nephussim,"
    },
    {
      "verse": "51",
      "text": "Bakbuk, Hakupha, Harhur,"
    },
    {
      "verse": "52",
      "text": "Bazluth, Mehida, Harsha,"
    },
    {
      "verse": "53",
      "text": "Barkos, Sisera, Temah,"
    },
    {
      "verse": "54",
      "text": "Neziah and Hatipha."
    },
    {
      "verse": "55",
      "text": "The descendants of King Solomon's servants: the descendants of Sotai, Hassophereth, Peruda,"
    },
    {
      "verse": "56",
      "text": "Jaala, Darkon, Giddel,"
    },
    {
      "verse": "57",
      "text": "Shephatiah, Hattil, Pokereth-Hazzebaim and Ami."
    },
    {
      "verse": "58",
      "text": "men who were temple servants and the descendants of Solomon's servants."
    },
    {
      "verse": "59",
      "text": "Some people came from the towns of Tel Melah, Tel Harsha, Kerub, Addon and Immer. But these people could not show that they belonged to Israelite families. They may not have been descendants of Israel."
    },
    {
      "verse": "60",
      "text": "descendants of Delaiah, Tobiah and Nekoda."
    },
    {
      "verse": "61",
      "text": "These priests also could not show what families they belonged to: The descendants of Hobaiah, Hakkoz and Barzillai. (This Barzillai had married one of the daughters of a man from Gilead called Barzillai. So he took Barzillai's name for himself. )"
    },
    {
      "verse": "62",
      "text": "These people tried to find their names in the lists of priests' families. But they could not find anything. So they could not serve as priests."
    },
    {
      "verse": "63",
      "text": "The officer in Judah said that they could not eat the priests' special food. They must wait until there was a leader of the priests who could use the Urim and Thummim to decide the right thing to do."
    },
    {
      "verse": "64",
      "text": "All together, 42, 360 people returned to Jerusalem."
    },
    {
      "verse": "65",
      "text": "There were also 7, 337 male and female servants, as well as 200 male and female singers."
    },
    {
      "verse": "66",
      "text": "horses, 245 mules,"
    },
    {
      "verse": "67",
      "text": "camels and 6, 720 donkeys."
    },
    {
      "verse": "68",
      "text": "They arrived at the Lord's temple in Jerusalem. Some of the leaders of their families gave gifts to build the temple again where it had been before."
    },
    {
      "verse": "69",
      "text": "They each gave as much money as they were able to give. Together they gave about 500 kilograms of gold and nearly 3, 000 kilograms of silver. They also gave 100 special sets of clothes for the priests."
    },
    {
      "verse": "70",
      "text": "The priests, the Levites, the singers, temple guards and other workers lived in their towns near Jerusalem. The other Israelites went to live in the towns where their ancestors had lived."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "When all the people were now living in their towns, they went to meet together in Jerusalem. It was the seventh month of the year."
    },
    {
      "verse": "2",
      "text": "Jozadak's son, Jeshua, and some of the other priests in his family began to build the altar of Israel's God. Shealtiel's son, Zerubbabel, and some of his family also began to build it. They wanted to make burnt offerings on it. God's servant, Moses, had written about this in the law."
    },
    {
      "verse": "3",
      "text": "The people who already lived near there made them afraid. But they built the altar on its foundation. Then they made burnt offerings to the Lord on the altar. They offered sacrifices on it every day, in the morning and in the evening."
    },
    {
      "verse": "4",
      "text": "Then they had the Feast of Huts, as the law said they should do. On each day of the feast they made the right number of burnt offerings."
    },
    {
      "verse": "5",
      "text": "After that, they made burnt offerings every day, and also at the time of each new moon. They made the right sacrifices for the special festivals, when people met together to worship the Lord. They also offered special gifts that people had chosen to give to the Lord."
    },
    {
      "verse": "6",
      "text": "They began to offer those burnt offerings on the first day of the seventh month. That was before they had started to build the temple."
    },
    {
      "verse": "7",
      "text": "The leaders gave money to men who could work with stone and wood. They sent food, drink and olive oil to the people in Tyre and Sidon. This was to pay for beams of wood from cedar trees. They would bring the wood from Lebanon on ships that came to Joppa. Cyrus, king of Persia, had commanded them to do this."
    },
    {
      "verse": "8",
      "text": "The Israelites began to build the Lord's temple two years after they arrived in Jerusalem. In the second month of the year, Shealtiel's son, Zerubbabel, and Jozadak's son, Jeshua, began the work. All the priests and the Levites who worked with them in Jerusalem joined them. All the people who had returned to Jerusalem from Babylon helped in the work. The leaders chose Levites who were 20 years old, or older, to have authority over the work."
    },
    {
      "verse": "9",
      "text": "These are their names: Jeshua, his sons and his brothers. Kadmiel and his sons. (They were descendants of Hodaviah. )Henadad's sons, with their sons and brothers, who were Levites."
    },
    {
      "verse": "10",
      "text": "The men who were building the Lord's temple finished the foundations. Then the priests put on their special clothes. They made a noise with their trumpets. The Levites (sons of Asaph) made a noise with their cymbals. They all stood to praise the Lord, in the way that Israel's King David had told them many years before. ‘He is good. His love for Israel will continue for ever. ’ Then all the people shouted loudly to praise the Lord. They praised him because they had finished work on the temple's foundation."
    },
    {
      "verse": "11",
      "text": "They sang together to praise the Lord. Group by group, they sang these words:‘He is good. His love for Israel will continue for ever. ’Then all the people shouted loudly to praise the Lord. They praised him because they had finished work on the temple's foundation."
    },
    {
      "verse": "12",
      "text": "But many of the older priests, Levites and leaders wept aloud. They were sad because they had seen the temple as it had been before. They remembered how beautiful it had been. At the same time, many other people shouted because they were happy."
    },
    {
      "verse": "13",
      "text": "The happy shouts and the noise of people who were weeping were both very loud. People far away could hear the noise. The different sounds mixed together, so nobody could say which was which."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "The Israelites who had returned to Jerusalem from exile were building the temple for the Lord, Israel's God. The enemies of the people of Judah and Benjamin heard that the Israelites had begun to build."
    },
    {
      "verse": "2",
      "text": "They went to speak to Zerubbabel and to the leaders of the Israelite families. They said, ‘Let us help you to build the temple. We also want to worship your God. We have lived in this country since Esarhaddon, king of Assyria, brought us here. All this time we have made sacrifices to your God. ’"
    },
    {
      "verse": "3",
      "text": "But Zerubbabel, Jeshua and the other leaders of Israel's people said, ‘No. You cannot help us to build the temple for our God. We must build it by ourselves for the Lord, Israel's God. That is what Cyrus, king of Persia, has commanded us to do. ’"
    },
    {
      "verse": "4",
      "text": "Then the people who lived near them tried to make Judah's people afraid. They tried to stop them building."
    },
    {
      "verse": "5",
      "text": "They paid bribes to government officers to work against the Israelite builders. Then they could not do the work. They continued to do this all the time that King Cyrus ruled Persia, until Darius became king."
    },
    {
      "verse": "6",
      "text": "When Xerxes became king of Persia, Judah's enemies wrote a letter to him. They said that the people who lived in Jerusalem and the rest of Judah were doing a bad thing."
    },
    {
      "verse": "7",
      "text": "Later, when Artaxerxes was king of Persia, Bishlam, Mithredath, Tabeel and their friends wrote a letter to him. They wrote it in the Aramaic language. People translated it for the king to understand."
    },
    {
      "verse": "8",
      "text": "Rehum, the city's ruler, and Shimshai, his officer, wrote this letter against Jerusalem to King Artaxerxes. This is what it said:"
    },
    {
      "verse": "9",
      "text": "Rehum, your ruler, and Shimshai, his officer, write this letter to you. The other officers who work with us also send this letter to you. They are the judges and other officers and leaders, together with the people who came here from Erech, Babylon and Susa (the Elamites)."
    },
    {
      "verse": "10",
      "text": "It also comes from people of other nations who came to live in Samaria's cities. The great King Ashurbanipal sent those people to live in Samaria and in the region that is on the west side of the River Euphrates."
    },
    {
      "verse": "11",
      "text": "This is the letter that they sent to Artaxerxes:‘To King Artaxerxes, from your servants in the land west of the Euphrates river. ‘To King Artaxerxes, from your servants in the land west of the Euphrates river."
    },
    {
      "verse": "12",
      "text": "We want to tell the king what the Jews here are doing. They came here to Jerusalem from Babylon. Jerusalem has always been a bad city whose people do not obey their rulers. Now they are building the city again. They are building the city's walls and the foundations for other buildings."
    },
    {
      "verse": "13",
      "text": "So you should know that there will be trouble. If they build this city again, with its walls, they will not pay any more taxes to you. You will not receive any more money from them as their king."
    },
    {
      "verse": "14",
      "text": "We serve you as our king. We do not want you to lose honour. So we have sent this letter to you."
    },
    {
      "verse": "15",
      "text": "You should look for the books where your ancestors recorded news about Jerusalem. Then you will read many bad things about this city. You will see that its people have always turned against their rulers. Since long ago, they have not obeyed the kings or the region's officers. It is because they are so wicked that Babylon's army destroyed the city."
    },
    {
      "verse": "16",
      "text": "So we are telling the king that you should not let these people build up this city again, with its walls. If they do that, you will no longer have any authority in this region that is west of the Euphrates river. ’"
    },
    {
      "verse": "17",
      "text": "The king of Persia sent this reply:‘To Rehum, my ruler, Shimshai, his officer, and all their friends in Samaria and in other parts of the region west of the Euphrates river. I thank you for your news. ‘To Rehum, my ruler, Shimshai, his officer, and all their friends in Samaria and in other parts of the region west of the Euphrates river. I thank you for your news."
    },
    {
      "verse": "18",
      "text": "People have translated the letter that you sent to me. They read it for me to listen to."
    },
    {
      "verse": "19",
      "text": "Then I commanded them to look in the old books. I have seen what the books say about Jerusalem. It is true that its people have always turned against the kings that ruled them. Since long ago, they have never obeyed their rulers."
    },
    {
      "verse": "20",
      "text": "In the past, powerful kings have ruled over Jerusalem and all the region west of the Euphrates river. They received many kinds of taxes from the people there."
    },
    {
      "verse": "21",
      "text": "Now you must command these people to stop their work. They must not build the city again until I decide to let them do it."
    },
    {
      "verse": "22",
      "text": "You must be very careful to make sure that they stop. We do not want the danger to our kingdom to become any greater. Our authority to rule them as kings must continue. ’"
    },
    {
      "verse": "23",
      "text": "Rehum, his officer, Shimshai, and their friends heard what the king's letter said. So they immediately took it to the Jews in Jerusalem. They used their power to command the Jews to stop their work."
    },
    {
      "verse": "24",
      "text": "So the people did no more work on God's temple in Jerusalem. The work stopped until the second year that King Darius ruled Persia."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Then the prophets Haggai and Iddo's grandson, Zechariah, spoke messages from God. They served Israel's God, and they spoke with his authority. They told God's message to the Jews who lived in Jerusalem and in other parts of Judea."
    },
    {
      "verse": "2",
      "text": "Then Shealtiel's son, Zerubbabel, and Jozadak's son, Jeshua, started again to build God's temple in Jerusalem. God's prophets were there to help them."
    },
    {
      "verse": "3",
      "text": "At that time, Tattenai was the ruler who had authority over the region on the west side of the Euphrates river. He went with Shethar-Bozenai and their friends to ask the Jews what they were doing. They asked them, ‘Who gave you the authority to build this temple and make it ready to use again? ’"
    },
    {
      "verse": "4",
      "text": "They also asked, ‘What are the names of the men who are building this place? ’"
    },
    {
      "verse": "5",
      "text": "But God was watching over the Jewish leaders. Nobody was able to stop them building at that time. The city's officers had to wait until they could send a letter to King Darius. They waited for him to reply."
    },
    {
      "verse": "6",
      "text": "Tattenai, the city's ruler, Shethar-Bozenai and their friends who had authority in the region west of the Euphrates river wrote to King Darius. King Darius, we hope that you are well."
    },
    {
      "verse": "7",
      "text": "This is what they said: King Darius, we hope that you are well."
    },
    {
      "verse": "8",
      "text": "We went to Judah to visit the temple of the great God. The king should know that the Jews are building it with big stones. They are putting wooden beams in its walls. They are working hard and very carefully. The building is growing fast."
    },
    {
      "verse": "9",
      "text": "We spoke to their leaders and we asked them, ‘Who gave you authority to build this temple and make it ready to use again? ’"
    },
    {
      "verse": "10",
      "text": "We also asked them to tell us their names. Then we could tell you who the leaders are."
    },
    {
      "verse": "11",
      "text": "This is the answer that they gave to us:‘We are servants of the God who rules heaven and earth. A great king of Israel built this temple and finished it many years ago. Now we are building it again."
    },
    {
      "verse": "12",
      "text": "Our ancestors made the God of heaven angry. So he let King Nebuchadnezzar of Babylon have power over them. He destroyed this temple. Then he took our people as prisoners to Babylon."
    },
    {
      "verse": "13",
      "text": "But later, King Cyrus of Babylon commanded that we must build God's temple again. He said this in the first year that he was king."
    },
    {
      "verse": "14",
      "text": "He gave back to us the gold and silver things that belong in our God's temple. King Nebuchadnezzar had taken those things away from the temple in Jerusalem. He took them to Babylon and he put them in his own temple. But King Cyrus gave our valuable things to Sheshbazzar. He had given authority to this man to rule over Judah."
    },
    {
      "verse": "15",
      "text": "He said to Sheshbazzar, “Take these things and put them safely in the temple in Jerusalem. Let the people build the house of God again, in the place where it used to be. ”"
    },
    {
      "verse": "16",
      "text": "So this man, Sheshbazzar, came here. He built the foundations of God's temple in Jerusalem. Since then we have continued to build it, but we have not finished it yet. ’"
    },
    {
      "verse": "17",
      "text": "If the king should choose, he may look in the books in Babylon's royal library. You should see whether King Cyrus did give a command about God's temple in Jerusalem. See if he said that the Jews should build it again. When you know what is true, you should decide what is right. Please tell us what we should do."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "King Darius told his officers to look in the books in the royal library. That was in Babylon, in the place where they stored important things. ‘This is an important note."
    },
    {
      "verse": "2",
      "text": "But it was in the region of Media that they found a scroll about the temple in Jerusalem. It was stored in a strong building in Ecbatana. This is what the scroll said:‘This is an important note."
    },
    {
      "verse": "3",
      "text": "King Cyrus gave a command about God's temple in Jerusalem, in the first year that he ruled in Babylon. He said:“The Jews must build their temple as a place where they can offer sacrifices to their God. They must build it on its foundations. They must make it 30 metres wide and 30 metres high."
    },
    {
      "verse": "4",
      "text": "They must build the walls with three rows of big stones, and then a row of wooden beams. They should take money from the king's palace to pay for the work."
    },
    {
      "verse": "5",
      "text": "We will give back to them the silver and gold things that belong in their God's temple. King Nebuchadnezzar took them from the temple in Jerusalem and he brought them here to Babylon. Now they must return to the place where they belong, in God's house in Jerusalem. ”"
    },
    {
      "verse": "6",
      "text": "So listen to me, Tattenai, my ruler of the region on the west side of the Euphrates river. You, Shethar-Bozenai and your other officers in that region must all stay away from the temple!"
    },
    {
      "verse": "7",
      "text": "You must not do anything to stop the work on God's temple. The Jewish ruler and their leaders must continue to build this house of God. They must build it in its proper place."
    },
    {
      "verse": "8",
      "text": "So I will now tell you what you must do for the Jewish leaders. You must help them to build this temple again. Use the king's money to pay for everything that they need to continue the work. Use the taxes that we receive from people in the region west of the Euphrates river. The work on the building must not stop."
    },
    {
      "verse": "9",
      "text": "Also give to the priests the things that they need each day for their sacrifices to the God of heaven. Give them young bulls, male sheep and lambs to use as burnt offerings. Give them grain, salt, wine and olive oil. Whenever the priests in Jerusalem ask for something, you must be sure to give it to them."
    },
    {
      "verse": "10",
      "text": "Then their offerings will make the God of heaven happy. They will pray for God to bless the king and his family."
    },
    {
      "verse": "11",
      "text": "Nobody may change what I have commanded in this letter. If anyone does not obey this command, men must remove a beam from the roof of his house. They must push the point of the beam through his body and lift him up on it. Then they must destroy his house so that it becomes a heap of stones. That is what he deserves."
    },
    {
      "verse": "12",
      "text": "No king or nation should try to change my command. They must never destroy God's temple in Jerusalem. That is the place that he has chosen for people to worship him. I pray that he will remove anyone who tries to attack that place. I, Darius, have made this command. Everyone must obey it completely. ’ I, Darius, have made this command. Everyone must obey it completely. ’"
    },
    {
      "verse": "13",
      "text": "Tattenai, ruler of the region west of the Euphrates river, Shethar-Bozenai and their friends carefully obeyed King Darius's command."
    },
    {
      "verse": "14",
      "text": "So the leaders of the Jews continued to build the temple. The work went very well. They listened to the messages from God that the prophet Haggai and Iddo's grandson, Zechariah, were teaching them. They finished building the temple. Israel's God had commanded them to do that. Cyrus, Darius and Artaxerxes, the kings of Persia, had also commanded them to do it."
    },
    {
      "verse": "15",
      "text": "They finished building the temple on the third day of Adar month. King Darius had then been king for six years."
    },
    {
      "verse": "16",
      "text": "Then the Israelite people offered the temple to God, so that he would bless it. The priests, the Levites and the other people who had returned from Babylon were all very happy."
    },
    {
      "verse": "17",
      "text": "bulls, 200 male sheep and 400 lambs. Then they sacrificed 12 male goats as a sin offering for all Israel. There was one goat for each of the 12 tribes of Israel."
    },
    {
      "verse": "18",
      "text": "They decided how each group of priests and Levites should work in God's temple in Jerusalem. Moses had written in his book how they should do this."
    },
    {
      "verse": "19",
      "text": "On the 14th day of the first month, the people ate the Passover feast."
    },
    {
      "verse": "20",
      "text": "The priests and Levites had all made themselves clean for their special work. The Levites killed the lambs for the Passover sacrifice. They did that on behalf of all the people, the priests and themselves."
    },
    {
      "verse": "21",
      "text": "So all the people who had returned from Babylon ate the feast. Other Israelites in Jerusalem had turned away from the bad things that other nations who lived there did. They had decided to worship the Lord, Israel's God. So they also ate the feast."
    },
    {
      "verse": "22",
      "text": "Then they ate the Feast of Flat Bread for seven days. The Lord had caused them to be very happy, because the king of Assyria had helped them. The Lord had made the king think in a different way about the Jews in Jerusalem. He had decided to help them to build the God of Israel's temple."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "After these things, Ezra came to Jerusalem from Babylon. This happened while Artaxerxes was king of Persia. This is the list of Ezra's ancestors: He was the son of Seraiah, the son of Azariah, the son of Hilkiah."
    },
    {
      "verse": "2",
      "text": "Hilkiah was the son of Shallum, the son of Zadok, the son of Ahitub."
    },
    {
      "verse": "3",
      "text": "Ahitub was the son of Amariah, the son of Azariah, the son of Meraioth."
    },
    {
      "verse": "4",
      "text": "Meraioth was the son of Zerahiah, the son of Uzzi, the son of Bukki."
    },
    {
      "verse": "5",
      "text": "Bukki was the son of Abishua, the son of Phinehas, the son of Eleazar. Eleazar was a son of Aaron, the leader of the priests."
    },
    {
      "verse": "6",
      "text": "This man Ezra arrived from Babylon. He was a teacher who knew the law of Moses very well. The Lord, Israel's God, had given that law to Moses. Ezra served the Lord as his God. The Lord was kind and he helped Ezra, so that the king of Persia gave him everything that he asked for."
    },
    {
      "verse": "7",
      "text": "In the seventh year that Artaxerxes was king, Ezra came together with other Israelites. They included priests, Levites, and singers, servants and guards for the temple."
    },
    {
      "verse": "8",
      "text": "Ezra arrived in Jerusalem in the fifth month of Artaxerxes' seventh year as king."
    },
    {
      "verse": "9",
      "text": "He left Babylon on the first day of the first month and he arrived in Jerusalem on the first day of the fifth month. God had helped him with his journey."
    },
    {
      "verse": "10",
      "text": "God was kind to Ezra because Ezra had decided to study the law of the Lord. Ezra always obeyed its rules. He also taught the law and its rules to the Israelite people."
    },
    {
      "verse": "11",
      "text": "This is a copy of the letter that King Artaxerxes had given to Ezra, the priest and teacher. Ezra had studied the Lord's commands and laws for Israel."
    },
    {
      "verse": "12",
      "text": "‘From Artaxerxes, king of all kings. To Ezra the priest, who has studied very well the law of the God of heaven. I hope that you are well. To Ezra the priest, who has studied very well the law of the God of heaven. I hope that you are well."
    },
    {
      "verse": "13",
      "text": "I have given this command: When you travel to Jerusalem, any other Israelites who live in my kingdom may go with you. Anyone who wants to go may go. That includes priests and Levites."
    },
    {
      "verse": "14",
      "text": "The king and his seven officers are sending you with their authority. You have the law of your God that he has given to you. Go and see if your people in Judah and Jerusalem are obeying his law."
    },
    {
      "verse": "15",
      "text": "Take with you the gold and silver that I and my officers have sent. They are a free gift for Israel's God, whose house is in Jerusalem."
    },
    {
      "verse": "16",
      "text": "Also take the gold and silver that other people in Babylonia give to you. And take the gifts that the people and the priests have given for their God's temple in Jerusalem."
    },
    {
      "verse": "17",
      "text": "You must use the money to buy bulls, male sheep and lambs. You must also buy grain and wine to offer to your God. Offer them as sacrifices on the altar of your God's temple in Jerusalem."
    },
    {
      "verse": "18",
      "text": "You and your friends may then use the rest of the silver and gold in the way that you choose. Decide what your God wants you to do."
    },
    {
      "verse": "19",
      "text": "Also take the valuable things that you use to worship your God in his temple. Take them safely to him in Jerusalem."
    },
    {
      "verse": "20",
      "text": "You may need other things to worship your God in his temple. You may take what you need from the royal store rooms."
    },
    {
      "verse": "21",
      "text": "I, King Artaxerxes, give this command to all my officers in the region on the west side of the Euphrates river: You must give Ezra anything that he asks for. He is a priest who studies the law of the God of heaven."
    },
    {
      "verse": "22",
      "text": "This is how much you may give to him:3, 400 kilograms of silver, 22, 000 litres of grain, 2, 200 litres of wine, 2, 200 litres of oil, and all the salt that he wants."
    },
    {
      "verse": "23",
      "text": "Be careful to give Ezra everything that the God of heaven wants for his temple. I do not want the God of heaven to be angry with the kingdom that I and my sons rule."
    },
    {
      "verse": "24",
      "text": "You must not take any kinds of taxes from the men who serve this God in his house. You have no authority to do this. Take no taxes from the priests, the Levites, or the singers, guards, and servants who work in the temple."
    },
    {
      "verse": "25",
      "text": "Ezra, your God has helped you to be wise. So you must choose judges and officers who know the laws of your God. Then they will decide things for all the people who live in the region on the west side of the Euphrates river. If the people do not know the laws of your God, you must teach them."
    },
    {
      "verse": "26",
      "text": "Everyone must obey the laws of your God and also the laws of the king. If they do not obey, they deserve the right punishment. They may have to die. They may have to leave the country. They may have to lose their valuable things. They may have to go to prison. ’"
    },
    {
      "verse": "27",
      "text": "I praise the Lord, the God that our ancestors worshipped. He has caused the king to give honour to him. He made the king decide to make the Lord's temple in Jerusalem very great."
    },
    {
      "verse": "28",
      "text": "The Lord has been kind to me, so that the king, his helpers and his powerful officers have helped me. Because the Lord my God has been with me, he has helped me to be strong. I have been able to bring many of the leaders of Israel to Jerusalem with me."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "We came from Babylon during the time that Artaxerxes was king. These are the leaders of clans who came with me, and the names of their families:"
    },
    {
      "verse": "2",
      "text": "Gershom, from Phinehas's clan. Daniel, from Ithamar's clan."
    },
    {
      "verse": "3",
      "text": "Shecaniah's son, Hattush, from David's clan. Zechariah and 150 other men, from Parosh's clan."
    },
    {
      "verse": "4",
      "text": "Zerahiah's son, Eliehoenai, and 200 other men, from Pahath-Moab's clan."
    },
    {
      "verse": "5",
      "text": "Jahaziel's son, Shecaniah, and 300 other men, from Zattu's clan."
    },
    {
      "verse": "6",
      "text": "Jonathan's son, Ebed, and 50 other men, from Adin's clan."
    },
    {
      "verse": "7",
      "text": "Athaliah's son, Jeshaiah, and 70 other men, from Elam's clan."
    },
    {
      "verse": "8",
      "text": "Michael's son, Zebadiah, and 80 other men, from Shephatiah's clan."
    },
    {
      "verse": "9",
      "text": "Jehiel's son, Obadiah, and 218 other men, from Joab's clan."
    },
    {
      "verse": "10",
      "text": "Josiphiah's son, Shelomith, and 160 other men, from Bani's clan."
    },
    {
      "verse": "11",
      "text": "Bebai's son, Zechariah, and 28 other men, from Bebai's clan."
    },
    {
      "verse": "12",
      "text": "Hakkatan's son, Johanan, and 110 other men, from Azgad's clan."
    },
    {
      "verse": "13",
      "text": "Eliphelet, Jeuel, Shemaiah, and 60 other men, from Adonikam's clan. They came later."
    },
    {
      "verse": "14",
      "text": "Uthai, Zaccur, and 70 other men, from Bigvai's clan."
    },
    {
      "verse": "15",
      "text": "I told all the people to come together at the river that runs towards Ahava. We stayed there for three days. I saw that there were Jewish people and priests, but I did not see any Levites."
    },
    {
      "verse": "16",
      "text": "So I asked them to send some of their leaders: Eliezer, Ariel, Shemaiah, Elnathan, Jarib, Elnathan, Nathan, Zechariah and Meshullam. I also asked for Joiarib and Elnathan, who were wise teachers."
    },
    {
      "verse": "17",
      "text": "I sent them all to Iddo, the leader in Casiphia. Iddo and his family were servants in the temple who were living in Casiphia. I told them what to say to Iddo. I wanted them to bring people who would serve God in his house."
    },
    {
      "verse": "18",
      "text": "God was kind to us and he helped us. So they brought Sherebiah to us. He was a worker who had special skills to make things. He was a descendant of Israel's son Levi. He belonged to the clan of Levi's son, Mahli. Sherebiah came with his sons and brothers. Together they were 18 men."
    },
    {
      "verse": "19",
      "text": "Hashabiah and Jeshaiah also came. They belonged to the clan of Levi's son, Merari. 20 men from their family came with them."
    },
    {
      "verse": "20",
      "text": "temple servants also came. King David had first chosen this group to help the Levites with their work. We made a list of all their names."
    },
    {
      "verse": "21",
      "text": "We were all waiting by the Ahava river. I told the people not to eat any food, so that we could pray to God for help. We asked him to keep us safe on the journey, with our children and all our things."
    },
    {
      "verse": "22",
      "text": "I was ashamed to ask the king to send his soldiers with us to keep us safe. He could have sent soldiers who rode on horses with us, or other soldiers. But we had said to the king, ‘Our God helps people who trust him and he keeps them safe. But he is very angry with people who turn away from him and he punishes them. ’"
    },
    {
      "verse": "23",
      "text": "So we ate no food and we prayed to our God about this. He answered our prayers."
    },
    {
      "verse": "24",
      "text": "of the most important priests to do an important job, as well as Sherebiah, Hashabiah and ten of their brothers."
    },
    {
      "verse": "25",
      "text": "I told them to take care of the valuable things that we had received for the temple of our God. These were silver and gold things and other special things that the king, his helpers and his officers had given to us. Israelite people who were living in Babylonia had also given us valuable things for the temple. I weighed all these things."
    },
    {
      "verse": "26",
      "text": "I weighed 20, 000 kilograms of silver and 3, 500 kilograms of things made from silver. I weighed 3, 500 kilograms of gold"
    },
    {
      "verse": "27",
      "text": "gold bowls that weighed 8. 5 kilograms. I also gave to them two beautiful bowls made from bronze. They shone brightly and they were as valuable as gold."
    },
    {
      "verse": "28",
      "text": "I said to the men, ‘Like these special things, you people are also special. You all belong to the Lord. People have chosen to give the silver and gold to the Lord, the God that your ancestors served."
    },
    {
      "verse": "29",
      "text": "So you must be careful to keep them safe until you reach Jerusalem. When you get there, you must weigh them again. Do that in front of the leaders of the priests, the Levites and the leaders of Israelite families. Then they should store them in the rooms of the temple. ’"
    },
    {
      "verse": "30",
      "text": "Then they gave the silver, the gold and the other valuable things to the priests and the Levites. They would take them to the temple of our God in Jerusalem."
    },
    {
      "verse": "31",
      "text": "We began our journey from the Ahava river on the 12th day of the first month. We left there to go to Jerusalem. Our God kept us safe on the journey. No enemies attacked us and nobody robbed us on the way."
    },
    {
      "verse": "32",
      "text": "So we arrived safely in Jerusalem. We rested there for three days."
    },
    {
      "verse": "33",
      "text": "On the fourth day, we went to the house of our God. Then we weighed the silver, the gold and the other valuable things there. We gave them to Meremoth, the son of Uriah the priest. Phinehas's son, Eleazar was with him. Jeshua's son, Jozabad, and Binnui's son, Noadiah, were also there. They were Levites."
    },
    {
      "verse": "34",
      "text": "They weighed and counted everything carefully. They wrote everything in a list as they weighed it."
    },
    {
      "verse": "35",
      "text": "All the people who had returned from Babylon made burnt offerings as sacrifices to Israel's God. They offered to the Lord 12 bulls on behalf of all Israel. They also offered 96 male sheep and 77 lambs. They killed 12 male goats as a sin offering. They gave all these to the Lord as burnt offerings."
    },
    {
      "verse": "36",
      "text": "They also gave the king's letter with its commands to his officers and rulers in the region west of the Euphrates river. The king's officers helped the Israelite people and the work of God's temple."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "When we had done all these things, the Jewish leaders came to speak to me. They said, ‘Some of the Israelites have done disgusting things, like the people of other nations do. Some priests and Levites have done the same bad things. They live in the same way as the other people who live in this land, the Canaanites, Hittites, Perizzites, Jebusites, Ammonites, Moabites, Egyptians and Amorites. They have not kept themselves separate."
    },
    {
      "verse": "2",
      "text": "They have married some of the foreign people's daughters. They have let their sons do the same thing. In this way, God's holy people have become mixed with the foreign people who live near to them. Our own leaders and officers have led the way in these bad things. ’"
    },
    {
      "verse": "3",
      "text": "When I heard this, I was very upset. I tore my shirt and my coat. I pulled out hair from my head and my beard. I was angry and ashamed. I sat down."
    },
    {
      "verse": "4",
      "text": "Then everyone who respected the words of Israel's God came around me. They were afraid of what God might do, because the Israelites who came from Babylon had not obeyed him. I continued to sit there, until the time of the evening sacrifice. I was still very upset."
    },
    {
      "verse": "5",
      "text": "When the time came for the evening sacrifice, I stood up. I still wore my shirt and coat that I had torn because I was so sad. Then I went down on my knees. I held out my hands and I prayed to the Lord, my God."
    },
    {
      "verse": "6",
      "text": "I said, ‘My God, I am too ashamed to look up at you. Our sins are very great. They are so many that they reach far above us. We are completely guilty."
    },
    {
      "verse": "7",
      "text": "Since our ancestors were alive, we have continued to do wrong things. Because of our sins, you have given our enemies power over us, our kings and our priests. Foreign kings and their armies have killed some of our people. They have made some of us prisoners. They have robbed us and they have caused us to be ashamed. And we are still ashamed today."
    },
    {
      "verse": "8",
      "text": "But now, for a short time, the Lord our God has been kind to us. He has let some of us remain alive. He has given us a safe place to live in this holy place. He has made our lives happier. He has given us rest from work as slaves."
    },
    {
      "verse": "9",
      "text": "We are still slaves, but our God has not left us alone to serve other people. Because he loves us, he has caused the kings of Persia to be kind to us. He has let us live so that we can build again the temple of our God. It had become a heap of stones, but now we have built it again. He has given us a safe place to live in Jerusalem and the other towns of Judah."
    },
    {
      "verse": "10",
      "text": "Our God, we can say nothing good about ourselves. We have turned away from your commands."
    },
    {
      "verse": "11",
      "text": "Your servants the prophets told us your laws. You said, “You will go and live in a land that is unclean. The people who live there have done wicked things. The whole land has been made unclean by all the evil things that they have done."
    },
    {
      "verse": "12",
      "text": "So you must not let your daughters marry their sons. And do not let your sons marry their daughters. Do not ever help them to live in peace and become strong. If you make yourselves separate from them, you will be strong yourselves. The land will give you good food to eat. After you die, the land will belong to your children, and to your descendants for ever. ”"
    },
    {
      "verse": "13",
      "text": "All these bad things have happened to us because we are guilty of many wicked things. But, our God, you still have not punished us as much as we deserve. You have let some of us remain alive."
    },
    {
      "verse": "14",
      "text": "But now we still refuse to obey your commands! Some of us have married foreign people who do disgusting things. If we continue to do that, you may destroy us all. None of us will remain alive!"
    },
    {
      "verse": "15",
      "text": "Lord God of Israel, you are righteous. Only a few of us escaped from exile and remain as your people today. Now we stand before you as guilty people. Because of our sins, we do not deserve to come near to you. ’"
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "Ezra continued to pray, in front of God's temple. He was asking God to forgive his people's sins. He was weeping, and he was bending down low to the ground. While he was doing that, a big crowd of Israelite people came around him. There were men, women and children. They were also weeping loudly."
    },
    {
      "verse": "2",
      "text": "Then Shecaniah spoke to Ezra. Shecaniah was Jehiel's son, a descendant of Elam. Shecaniah said, ‘We have not been faithful to our God. We have married foreign women from the nations who live near us. But Israel may still hope that God will forgive us."
    },
    {
      "verse": "3",
      "text": "We will make an agreement with our God. We will agree to send away these foreign women and their children. As our leader, you have told us we must do this. The people who respect our God's commands say the same thing. Now we want to do what God's law says is right."
    },
    {
      "verse": "4",
      "text": "Get up now! You must do something about this. We will help you, so you must be brave! ’"
    },
    {
      "verse": "5",
      "text": "So Ezra got up. He told the leaders of the priests, the Levites and all Israel's people to make a strong promise. They all promised God that they would do what they had said."
    },
    {
      "verse": "6",
      "text": "Then Ezra went away from the front of God's temple. He went to the room of Eliashib's son, Jehohanan. While Ezra stayed there, he did not eat any food or drink any water. He was still very sad because the people had not been faithful to God."
    },
    {
      "verse": "7",
      "text": "They wrote a message and they sent it to all the people in Jerusalem and the other towns in Judah. It said that all the Jews who had returned from exile in Babylon must come to Jerusalem."
    },
    {
      "verse": "8",
      "text": "If they did not arrive in three days, they would lose everything that belonged to them. They would no longer be part of the Israelite people. That is what the leaders and officers had decided should happen."
    },
    {
      "verse": "9",
      "text": "All the men from the tribes of Judah and Benjamin reached Jerusalem in three days. It was the 20th day of the ninth month. All the people sat in the yard in front of God's temple. Their bodies were shaking because they were afraid. It was also raining."
    },
    {
      "verse": "10",
      "text": "Then Ezra the priest stood up. He said to the people, ‘You have not been faithful to your God. You have married foreign wives. You have caused the whole nation of Israel to be guilty."
    },
    {
      "verse": "11",
      "text": "Now you must agree to obey the Lord, the God that your ancestors worshipped. Turn away from your sins and do the things that please him. Make yourselves separate from the foreign people who live near you. Send away your foreign wives. ’"
    },
    {
      "verse": "12",
      "text": "All the people spoke with a loud voice. They said, ‘You are right. We will do as you say."
    },
    {
      "verse": "13",
      "text": "But we are many people and we cannot continue to stand here in the heavy rain. We will need more than one or two days to do what we must do. There are many of us who have done this bad sin."
    },
    {
      "verse": "14",
      "text": "So please let our officers decide what to do on behalf of us all. People who have married foreign wives should come here on certain days. People from each town should come on the right day, together with the leaders and judges from that town. In this way, we can make things right. Then our God will not be angry with us any longer. ’"
    },
    {
      "verse": "15",
      "text": "Only four men did not agree with this. They were Asahel's son, Jonathan, Tikvah's son, Jahzeiah, as well as Meshullam and Shabbethai, the Levite."
    },
    {
      "verse": "16",
      "text": "So the Jews who had returned from Babylon did what they had agreed to do. Ezra the priest chose family leaders for each clan. He wrote down their names. The leaders met together to decide what to do. They started on the first day of the tenth month."
    },
    {
      "verse": "17",
      "text": "They finished on the first day of the first month of the new year."
    },
    {
      "verse": "18",
      "text": "These are the priests who had married foreign wives. From the clan of Jozadak's son, Jeshua, and his brothers: Maaseiah, Eliezer, Jarib, Gedaliah. From the clan of Jozadak's son, Jeshua, and his brothers:"
    },
    {
      "verse": "19",
      "text": "These men promised to send away their wives. Each of them gave a male sheep as a sacrifice because they were guilty."
    },
    {
      "verse": "20",
      "text": "From the clan of Immer: Hanani, Zebadiah."
    },
    {
      "verse": "21",
      "text": "From the clan of Harim: Maaseiah, Elijah, Shemaiah, Jehiel, Uzziah."
    },
    {
      "verse": "22",
      "text": "From the clan of Pashhur: Elioenai, Maaseiah, Ishmael, Nethanel, Jozabad, Elasah."
    },
    {
      "verse": "23",
      "text": "From the Levites: Jozabad, Shimei, Kelaiah (also called Kelita), Pethahiah, Judah, Eliezer."
    },
    {
      "verse": "24",
      "text": "From the singers: Eliashib. From the men who were guards at the temple gate: Shallum, Telem, Uri. From the men who were guards at the temple gate:"
    },
    {
      "verse": "25",
      "text": "These are the other Israelites who had married foreign wives. From the clan of Parosh: Ramiah, Izziah, Malkijah, Mijamin, Eleazar, Malkijah, Benaiah. From the clan of Parosh:"
    },
    {
      "verse": "26",
      "text": "From the clan of Elam: Mattaniah, Zechariah, Jehiel, Abdi, Jeremoth, Elijah."
    },
    {
      "verse": "27",
      "text": "From the clan of Zattu: Elioenai, Eliashib, Mattaniah, Jeremoth, Zabad, Aziza."
    },
    {
      "verse": "28",
      "text": "From the clan of Bebai: Jehohanan, Hananiah, Zabbai, Athlai."
    },
    {
      "verse": "29",
      "text": "From the clan of Bani: Meshullam, Malluch, Adaiah, Jashub, Sheal, Jeremoth."
    },
    {
      "verse": "30",
      "text": "From the clan of Pahath-Moab: Adna, Kelal, Benaiah, Maaseiah, Mattaniah, Bezalel, Binnui, Manasseh."
    },
    {
      "verse": "31",
      "text": "From the clan of Harim: Eliezer, Ishijah, Malkijah, Shemaiah, Shimeon,"
    },
    {
      "verse": "32",
      "text": "Benjamin, Malluch, Shemariah."
    },
    {
      "verse": "33",
      "text": "From the clan of Hashum: Mattenai, Mattattah, Zabad, Eliphelet, Jeremai, Manasseh, Shimei."
    },
    {
      "verse": "34",
      "text": "From the clan of Bani: Maadai, Amram, Uel,"
    },
    {
      "verse": "35",
      "text": "Benaiah, Bedeiah, Keluhi,"
    },
    {
      "verse": "36",
      "text": "Vaniah, Meremoth, Eliashib,"
    },
    {
      "verse": "37",
      "text": "Mattaniah, Mattenai, Jaasu."
    },
    {
      "verse": "38",
      "text": "From the clan of Binnui: Shimei,"
    },
    {
      "verse": "39",
      "text": "Shelemiah, Nathan, Adaiah,"
    },
    {
      "verse": "40",
      "text": "Macnadebai, Shashai, Sharai,"
    },
    {
      "verse": "41",
      "text": "Azarel, Shelemiah, Shemariah,"
    },
    {
      "verse": "42",
      "text": "Shallum, Amariah, Joseph."
    },
    {
      "verse": "43",
      "text": "From the clan of Nebo: Jeiel, Mattithiah, Zabad, Zebina, Jaddai, Joel, Benaiah."
    },
    {
      "verse": "44",
      "text": "All these men had married foreign women. They sent them away, together with their children."
    }
  ]
};