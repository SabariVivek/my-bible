module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "David's son Solomon made himself a strong ruler over his kingdom. The Lord his God was with Solomon, so that he became a great king."
    },
    {
      "verse": "2",
      "text": "Solomon called all the people of Israel to come together. They included the army officers who had authority over 1, 000 men, and those who had authority over 100 men. They also included the judges, the leaders in Israel and the leaders of families."
    },
    {
      "verse": "3",
      "text": "Then Solomon went with all those people to Gibeon town to worship God. The special tent that the Lord's servant Moses had made in the desert was there. It was the tent where God met with his people."
    },
    {
      "verse": "4",
      "text": "Before that, King David had brought God's Covenant Box from Kiriath-Jearim to Jerusalem. He had prepared a place for it in a tent there."
    },
    {
      "verse": "5",
      "text": "But the bronze altar that Bezalel had made was in Gibeon, in front of the Lord's tent. (Bezalel was the son of Uri, and the grandson of Hur. ) So Solomon and the people went to meet the Lord there in Gibeon."
    },
    {
      "verse": "6",
      "text": "Solomon went up to the bronze altar which was in front of the Lord's special tent. He offered 1, 000 burnt offerings on the altar to the Lord."
    },
    {
      "verse": "7",
      "text": "That night, God showed himself to Solomon. God said, ‘Ask me to give you whatever you want. ’"
    },
    {
      "verse": "8",
      "text": "Solomon answered God, ‘You always showed your faithful love to my father David. Now you have chosen me to be king after him."
    },
    {
      "verse": "9",
      "text": "Now, Lord God, please do as you promised to my father David. You have chosen me to rule as king over a great nation with as many people as the dust on the ground."
    },
    {
      "verse": "10",
      "text": "So please give me wisdom and knowledge, so that I can be a good leader of these people. I will only be able to rule this great nation of your people if you do that for me. ’"
    },
    {
      "verse": "11",
      "text": "God said to Solomon, ‘I am pleased that you have not asked to have riches or many valuable things. You have not asked me to give you great honour or for me to punish your enemies with death. You have not asked for a long life. Instead you asked me to give you wisdom and knowledge to rule over my people that I have chosen you to rule as king."
    },
    {
      "verse": "12",
      "text": "Because of that, I will give to you wisdom and knowledge, as you asked. But I will also give you riches, valuable things and honour. You will have more of those than any king who has lived before you and more than any king who will live after you. ’"
    },
    {
      "verse": "13",
      "text": "Solomon left the special tent in Gibeon where God met with his people. He returned to Jerusalem. There he ruled over Israel as king."
    },
    {
      "verse": "14",
      "text": "Solomon brought together many chariots and horses for his soldiers to ride. He had 1, 400 chariots and 12, 000 horses. He kept some of them in Jerusalem where he lived as king. He kept the others in cities that he had chosen for this."
    },
    {
      "verse": "15",
      "text": "While Solomon ruled as king, there was as much silver and gold in Jerusalem as stones! There was as much wood from cedar trees as there were fig trees that grew in the low hills in the west."
    },
    {
      "verse": "16",
      "text": "Solomon brought his horses from Egypt and from Kue. He sent traders to Kue to buy them for him."
    },
    {
      "verse": "17",
      "text": "pieces of silver for each chariot that they bought in Egypt. They paid 150 pieces of silver for each horse. They also sold chariots and horses to all the kings of the Hittites and to the kings of Syria."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Solomon decided to build a house to give honour to the Lord's name. He also decided to build a royal palace for himself."
    },
    {
      "verse": "2",
      "text": "He chose 70, 000 men to carry the heavy things for the buildings, and 80, 000 men to cut rocks in the hills. He also chose 3, 600 men to lead these workers."
    },
    {
      "verse": "3",
      "text": "Solomon wrote this letter to King Huram of Tyre:‘You helped my father King David when you sent him wood from cedar trees to build his palace. Please help me now."
    },
    {
      "verse": "4",
      "text": "I am ready to build a temple to give honour to the Lord my God. It will be a holy place that belongs to him. We Israelites will burn sweet incense for him there. We will put special bread there every day. We will burn sacrifices to the Lord our God every morning and every evening. We will also do that on Sabbath days, on New Moon festival days and on other special days that God has chosen. He has told us to do this for all time."
    },
    {
      "verse": "5",
      "text": "The house that I will build for our God will be a great temple, because he is greater than all gods."
    },
    {
      "verse": "6",
      "text": "I know that nobody can really build a house for our God. The whole sky, or even heaven itself, is not big enough to contain him. So I certainly cannot build a place for him to live in, but it will be a place where we can offer sacrifices to him."
    },
    {
      "verse": "7",
      "text": "Please send me a man who has special skills to work with gold, silver, bronze and iron, as well as with valuable red, purple and blue materials. He must also know how to cut pictures on metal. He will help my own workers here in Judah and in Jerusalem. They are workers with special skills that my father David chose to do this work."
    },
    {
      "verse": "8",
      "text": "Please send me wood from cedar trees, cypress trees and other strong trees from Lebanon. I know that your men have good skills to cut down trees in Lebanon. My own men will help your men with the work."
    },
    {
      "verse": "9",
      "text": "I will need you to send me a lot of wood because I am ready to build a large and beautiful temple."
    },
    {
      "verse": "10",
      "text": "I will pay your men who cut down the trees. To pay them, I will send 2, 000 tons of wheat, 2, 000 tons of barley, 450, 000 litres of wine and 450, 000 litres of olive oil. ’"
    },
    {
      "verse": "11",
      "text": "King Huram of Tyre replied to Solomon with this letter:‘Because the Lord loves his people, he has chosen you to be their king. ’ ‘Because the Lord loves his people, he has chosen you to be their king. ’"
    },
    {
      "verse": "12",
      "text": "Huram also said, ‘Praise the Lord, Israel's God! He made the whole universe. He has now given a wise son to King David, a son who is clever and who understands things well. He will build a temple for the Lord and a royal palace for himself."
    },
    {
      "verse": "13",
      "text": "I have decided to send Huram-Abi to you. He is a wise man who has special skills."
    },
    {
      "verse": "14",
      "text": "His mother belonged to the tribe of Dan. His father came from Tyre. He knows how to work with gold, silver, bronze, iron, stone and wood. He can also work with purple, blue and red materials, and with white linen. He can make all kinds of pictures on metal, if you show him what you want. He will help your own workers and the workers that your father King David chose."
    },
    {
      "verse": "15",
      "text": "Please sir, now send us the wheat, barley, olive oil and wine that you promised."
    },
    {
      "verse": "16",
      "text": "Then we will cut the wood that you need from the trees in Lebanon. We will tie the wood together to make boats. Then we will send them on the sea to Joppa. You can take the wood from there up to Jerusalem. ’"
    },
    {
      "verse": "17",
      "text": "Solomon counted all the foreign men who were living in Israel, as his father David had done. There were 153, 600 foreign men."
    },
    {
      "verse": "18",
      "text": "He chose 70, 000 of them to carry things for the buildings and 80, 000 of them to cut rocks in the hills. He also chose 3, 600 of them to lead the workers, to make sure that they finished the work properly."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "Then Solomon began to build the Lord's temple in Jerusalem. He built it on Mount Moriah, where the Lord had shown himself to his father David. David had prepared a place for the temple there, at the threshing floor of Araunah the Jebusite."
    },
    {
      "verse": "2",
      "text": "Solomon began to build the temple on the second day of the second month of the fourth year that he ruled Israel as king."
    },
    {
      "verse": "3",
      "text": "The foundation for God's temple was 27 metres long and 9 metres wide. (They measured it in cubits. )"
    },
    {
      "verse": "4",
      "text": "There was an entrance room at the front of the temple's big hall. It was as wide as the temple, 9 metres wide. It was 9 metres high. Solomon's workers covered the inside of the entrance room with pure gold."
    },
    {
      "verse": "5",
      "text": "They covered the walls inside the big hall with boards of cypress wood. Then they covered the boards with pure gold. They drew pictures of palm trees and chains on the walls."
    },
    {
      "verse": "6",
      "text": "They used valuable stones to make the temple beautiful. The gold that they used came from Parvaim."
    },
    {
      "verse": "7",
      "text": "They used gold to cover all parts of the temple: the beams for its roof, the entrances, the walls and the doors. They cut pictures of cherubs on the walls."
    },
    {
      "verse": "8",
      "text": "Solomon's workers built the Most Holy Place in the temple. It was 9 metres long and 9 metres wide. That was how wide the temple itself was. They used about 20, 000 kilograms of pure gold to cover its walls."
    },
    {
      "verse": "9",
      "text": "gold coins. They also covered the walls of the upstairs rooms with gold."
    },
    {
      "verse": "10",
      "text": "In the Most Holy Place, they made models of two cherubs. They covered them with gold."
    },
    {
      "verse": "14",
      "text": "Solomon's workers used blue, purple and red material and good linen to make a special curtain. It had pictures of cherubs on it."
    },
    {
      "verse": "15",
      "text": "Solomon's workers made two pillars to stand at the front of the temple. They were 16 metres high. There was a piece on the top of each pillar that was 2. 2 metres high."
    },
    {
      "verse": "16",
      "text": "They made images of chains around the top pieces of the pillars. They also made 100 images of pomegranates among the chains."
    },
    {
      "verse": "17",
      "text": "Then they put the two pillars at the entrance of the temple. One pillar stood on the south side of the entrance. The other pillar stood on the north side. Solomon called the pillar on the south side ‘Jakin’. He called the pillar on the north side ‘Boaz’."
    },
    {
      "verse": "11",
      "text": "The cherubs stood side by side in the Most Holy Place. Their faces looked towards the big hall. Each cherub had two wings."
    },
    {
      "verse": "12",
      "text": "Each wing was 2. 2 metres long. They held their wings out so that one wing of each cherub touched a wing of the other cherub."
    },
    {
      "verse": "13",
      "text": "The other wing of each cherub touched a wall of the Most Holy Place. The four wings of the two cherubs reached across 9 metres."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Solomon's workers made a bronze altar. It was 9 metres long, 9 metres wide and 4 metres high."
    },
    {
      "verse": "2",
      "text": "They used bronze to make a big bath which they called ‘the Sea’. It was in the shape of a circle 4½ metres across. It was 2½ metres deep. It was 14 metres around the outside."
    },
    {
      "verse": "3",
      "text": "All around its edge, below the top, there were two rows of images of things that looked like bulls. They were all part of the same piece of bronze as the big bath. There were 20 bulls for every metre around the edge."
    },
    {
      "verse": "4",
      "text": "They put the bronze ‘Sea’ on top of 12 bronze bulls. Three pointed north, three pointed west, three pointed south and three pointed east. Their backs were towards the middle of the ‘Sea’."
    },
    {
      "verse": "5",
      "text": "The bronze walls of the ‘Sea’ were 7½ centimetres thick. Its top edge was like a cup in the shape of a lily flower. The ‘Sea’ contained about 65, 000 litres of water."
    },
    {
      "verse": "6",
      "text": "They made ten bowls to wash in. They put five bowls on the south side and five bowls on the north side. The priests used them to wash all the things that they used for the burnt offerings. But the priests washed themselves in the water from the bronze ‘Sea’."
    },
    {
      "verse": "7",
      "text": "They used gold to make ten lampstands. They made them in the way that Solomon told them. They put the lampstands in the temple, five lampstands on the south side and five lampstands on the north side."
    },
    {
      "verse": "8",
      "text": "They also made ten tables. They put them in the temple, five tables on the south side and five tables on the north side. They also used gold to make 100 bowls."
    },
    {
      "verse": "9",
      "text": "They made a small yard for the priests and another big yard with doors. They covered the doors with bronze."
    },
    {
      "verse": "10",
      "text": "They put the bronze ‘Sea’ on the south side of the temple, at its south-east corner."
    },
    {
      "verse": "11",
      "text": "Huram-Abi also made more pots, small tools and bowls. So he finished all the work in God's temple that King Solomon had asked him to do. He made these things:"
    },
    {
      "verse": "12",
      "text": "two pillars; two pieces for the top of each pillar, with the shape of big bowls; rows of chains on the tops of the pillars;"
    },
    {
      "verse": "13",
      "text": "images of pomegranates for the two groups of chains (there were two rows of these images around the piece at the top of each pillar, which had the shape of a bowl);"
    },
    {
      "verse": "14",
      "text": "the carts with the buckets that were on them;"
    },
    {
      "verse": "15",
      "text": "the big bronze bath called ‘the Sea’ and the 12 bulls under it;"
    },
    {
      "verse": "16",
      "text": "the pots, small tools and forks for meat. King Solomon asked Huram-Abi to make all these things for the Lord's temple. He used bright bronze to make all these things."
    },
    {
      "verse": "17",
      "text": "The king told his workers to pour the hot bronze into shapes in the ground. They did that at a special place in the region of the Jordan Valley, between Succoth and Zarethan."
    },
    {
      "verse": "18",
      "text": "Solomon did not weigh any of these things, because there were so many of them. No one ever knew the weight of the bronze."
    },
    {
      "verse": "19",
      "text": "Solomon's workers also made all these things for God's temple: the gold altar; the tables which had the special bread on them;"
    },
    {
      "verse": "20",
      "text": "the pure gold lampstands with their lamps (the plans showed how the lamps had to burn at the entrance of the Most Holy Place);"
    },
    {
      "verse": "21",
      "text": "the gold images of flowers; the lamps; the small tools that held things for the altar;"
    },
    {
      "verse": "22",
      "text": "the small tools of pure gold that they used for the lamps; the bowls for water; the dishes for ashes; the baskets that carried hot coals; the gold pieces that held the doors of the Most Holy Place; the gold pieces that held the doors of the temple's big hall."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Solomon finished all the work for the Lord's temple. Then he brought into it all the holy things that belonged to his father, David. He stored all the valuable things in a safe place in God's temple. They included silver things and gold things."
    },
    {
      "verse": "2",
      "text": "Then Solomon told all the leaders of Israel to come to him in Jerusalem. They were all the leaders of the Israelite tribes and families. He wanted them to bring the Lord's Covenant Box from Mount Zion, the City of David, to put it in the temple."
    },
    {
      "verse": "3",
      "text": "So all the Israelite leaders came together to meet with King Solomon. This happened during the Festival of Huts in the seventh month of the year."
    },
    {
      "verse": "4",
      "text": "When all Israel's leaders had arrived, the Levites lifted up the Covenant Box."
    },
    {
      "verse": "5",
      "text": "The priests and the other Levites carried the Covenant Box, the Tent of Meeting and all the holy things that were in the tent."
    },
    {
      "verse": "6",
      "text": "King Solomon and all the Israelites who were with him walked in front of the Covenant Box. They offered many sheep and bulls as sacrifices. There were more animals than anyone could count."
    },
    {
      "verse": "7",
      "text": "Then the priests brought the Lord's Covenant Box to its proper place in the inside room of the temple. That was the Most Holy Place. They put it under the wings of the cherubs."
    },
    {
      "verse": "8",
      "text": "The wings of the cherubs touched each other above the place where the Covenant Box was. The cherubs covered the Covenant Box and the poles that the Levites used to carry it."
    },
    {
      "verse": "9",
      "text": "The poles in the Covenant Box were very long. The priests could see their ends from the Holy Place, if they stood in front of the Most Holy Place. But nobody could see the poles from outside the temple. And they are still there today."
    },
    {
      "verse": "10",
      "text": "There was nothing in the Covenant Box, except the two flat pieces of stone that Moses had put there at Sinai mountain. That was where the Lord made a covenant with the Israelites after they came out from Egypt."
    },
    {
      "verse": "11",
      "text": "Then the priests came out of the Holy Place. All the different groups of priests who were there had made themselves clean to serve God. ‘He is good! His faithful love continues for ever! ’"
    },
    {
      "verse": "12",
      "text": "The Levites who were musicians stood on the east side of the altar. They were Asaph, Heman, Jeduthun and their sons and their relatives. They wore clothes made of linen. They made music with cymbals, harps and lyres. There were also 120 priests who made music with trumpets."
    },
    {
      "verse": "13",
      "text": "All these musicians made nice music together. They joined together to praise the Lord and to thank him. The singers sang loudly to the music of the trumpets, the cymbals and the other musical instruments. They loudly sang these words to praise the Lord:‘He is good! His faithful love continues for ever! ’Then a cloud filled the Lord's temple."
    },
    {
      "verse": "14",
      "text": "The priests could not do their work to serve the Lord, because of the cloud. The bright glory of the Lord filled his temple."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "Then Solomon prayed, ‘Lord, you have said that you live in a dark cloud."
    },
    {
      "verse": "2",
      "text": "Now I have built a great temple for you. It is a place where you can live for ever. ’"
    },
    {
      "verse": "3",
      "text": "While all the Israelite people stood there, the king turned round towards them. He prayed that God would bless them."
    },
    {
      "verse": "4",
      "text": "He said, ‘Praise the Lord, Israel's God, as he deserves. He has used his power to do what he promised to do for my father David."
    },
    {
      "verse": "5",
      "text": "He told David, “I brought my people out of Egypt. From that time, I have not chosen a city in any of Israel's tribes to build a temple where my people would worship me. I have not chosen a man to be the leader of my people, the Israelites."
    },
    {
      "verse": "6",
      "text": "But now I have chosen Jerusalem to be the place where my people worship me. And I have chosen David to rule Israel, my people, as king. ”"
    },
    {
      "verse": "7",
      "text": "My father David wanted very much to build a temple to give honour to the Lord, Israel's God."
    },
    {
      "verse": "8",
      "text": "But the Lord said to my father David, “It was good that you wanted to build a temple to give me honour."
    },
    {
      "verse": "9",
      "text": "But you will not build the temple. Instead, one of your own sons will build it to give honour to me. ”"
    },
    {
      "verse": "10",
      "text": "Now the Lord has done what he promised to do. I now rule Israel as king on the throne of my father David, as the Lord promised. I have built this temple to give honour to the Lord, Israel's God."
    },
    {
      "verse": "11",
      "text": "I have put the Covenant Box there. It contains the covenant that the Lord made with the Israelites. ’"
    },
    {
      "verse": "12",
      "text": "Then Solomon stood in front of the Lord's altar. All the Israelite people who had come together there could see him. He lifted up his hands to pray."
    },
    {
      "verse": "13",
      "text": "He had made a bronze stage to stand on. It was 2. 3 metres long, 2. 3 metres wide and 1. 4 metres high. He put it in the middle of the yard and he stood on it. Then he went down on his knees where all the Israelites could see him. He lifted up his hands towards the sky."
    },
    {
      "verse": "14",
      "text": "He prayed, ‘Lord, Israel's God, there is no God like you, either in heaven or on the earth. You continue to do what you have promised to do for your people. You faithfully love those who want to serve you."
    },
    {
      "verse": "15",
      "text": "You have done what you promised to do for your servant, my father David. You have used your power to finish today everything that you said you would do."
    },
    {
      "verse": "16",
      "text": "Now Lord, Israel's God, there is another promise that you spoke to my father David. I pray that you will do that too. You said to David, “There will always be one of your descendants to rule Israel as my chosen king. But for this to happen, your sons must be careful to obey my law, as you have done. ”"
    },
    {
      "verse": "17",
      "text": "So now Lord, Israel's God, please cause what you promised to your servant David to happen."
    },
    {
      "verse": "18",
      "text": "But surely God, you do not live on the earth with people! The whole sky, or even heaven itself, is too small to contain you! So how can you live in this temple that I have built?"
    },
    {
      "verse": "19",
      "text": "But Lord, my God, please listen to my prayer, as I ask you for help. Please answer me, your servant, because I need your help."
    },
    {
      "verse": "20",
      "text": "Watch over this temple and take care of it day and night. This is the place about which you said, “People will give honour to my name there. ” Please answer my prayers when I turn towards this place to pray to you."
    },
    {
      "verse": "21",
      "text": "Hear the prayers of me, your servant, and the prayers of your people, the Israelites. Please answer us when we turn towards this place and we pray to you. Hear us from heaven, the place where you live. And when we pray, forgive us for our sins."
    },
    {
      "verse": "22",
      "text": "Somebody may do a bad thing against another person. Then he may come to this temple and stand in front of your altar. He may say to you that he is not guilty of any wrong thing."
    },
    {
      "verse": "23",
      "text": "Then listen from heaven to what these people are saying. Decide who is right. Punish the guilty person as he deserves. Show clearly that the other person is right, because he has not done any wrong thing."
    },
    {
      "verse": "24",
      "text": "Perhaps an enemy will win against your people, the Israelites, because we have not obeyed you. But then your people may turn back to you and worship you. They may come into this temple and pray that you will help them."
    },
    {
      "verse": "25",
      "text": "If they do that, please hear them from heaven! Please forgive the sins of your people, the Israelites. Please bring them back to the land that you gave to their ancestors."
    },
    {
      "verse": "26",
      "text": "Sometimes, there may be no rain from the sky because your people have not obeyed you. Then they may turn towards this place and pray to you. They may give honour to your name and turn away from their sins, because you have punished them."
    },
    {
      "verse": "27",
      "text": "If they do that, please hear them from heaven! Please forgive the sins of your servants, your people, the Israelites. Teach them to live in the right way. And please send rain onto this land that you gave to your people, to belong to them for ever."
    },
    {
      "verse": "28",
      "text": "Sometimes, there may be other troubles in our land. There may be a famine or a bad disease. Our crops may not grow and our animals may be ill. Locusts may destroy our crops. An enemy may attack some cities in our land. Or there may be other kinds of illness or trouble."
    },
    {
      "verse": "29",
      "text": "Then, some of your people may pray to you and ask you for help. If someone is very sad and in pain, he may turn towards this temple and lift up his hands in prayer."
    },
    {
      "verse": "30",
      "text": "If someone does that, please hear him from your home in heaven. Please forgive the sins of your people. Only you know what people are thinking. So please give to each person as they deserve."
    },
    {
      "verse": "31",
      "text": "Then your people will respect you and obey you all the time that they live in this land that you gave to our ancestors."
    },
    {
      "verse": "32",
      "text": "Foreigners, who do not belong to your people, the Israelites, will hear how great you are. They will hear about you and your power to do great things. Then they will come here from other countries far away. They will turn towards this temple and pray to you."
    },
    {
      "verse": "33",
      "text": "When that happens, please hear them from your home in heaven. Please answer all the prayers of these foreign people. Then people from all the nations in the world will realize how great you are. They also will respect you and obey you, as your own people do. They will understand that this temple that I have built belongs to you."
    },
    {
      "verse": "34",
      "text": "Sometimes, your people will go to fight against their enemies at the place where you have sent them. Then they may turn towards this city and pray to you. This is the city that you have chosen for me to build the temple to give you honour."
    },
    {
      "verse": "35",
      "text": "When they pray to you, please hear them from your home in heaven. Do what is right to help them win against their enemies."
    },
    {
      "verse": "36",
      "text": "There is nobody who never does a wrong thing. So when your people do not obey you, you will be angry with them. You will put them under the power of their enemies. Those enemies will take them away as their prisoners. Perhaps they will take them to a country that is far away. Perhaps it will be near."
    },
    {
      "verse": "37",
      "text": "Then your people may think about the bad things that they have done. While they are prisoners in their enemies' country, they may be sorry about their sins. They may pray to you and ask you to forgive them. They may say, “We have turned away from God and we have done wicked things. ”"
    },
    {
      "verse": "38",
      "text": "In the country where they are prisoners, they may turn back to you and worship you truly. They may turn towards this land that you gave to their ancestors. They may pray as they look towards this city that you have chosen. They may look towards the temple that I have built to give you honour."
    },
    {
      "verse": "39",
      "text": "If they do that, please hear them from your home in heaven. Please answer their prayers and do what is right to help them. Please forgive your people for all the sins that they have done against you."
    },
    {
      "verse": "40",
      "text": "Now, my God, please watch over us. Please listen to the prayers that we are praying in this place."
    },
    {
      "verse": "41",
      "text": "Lord God, come now and stay here, in your home. Come into the temple with the Covenant Box that shows your great power. Bless your priests as they serve you. Cause your faithful people be happy because you do good things for them."
    },
    {
      "verse": "42",
      "text": "Lord God do not turn away from your special chosen king. Remember the faithful love that you promised to your servant David. ’"
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "When King Solomon had finished his prayer, fire came down from heaven. It destroyed the burnt offerings and the other sacrifices. The Lord's bright glory filled the temple."
    },
    {
      "verse": "2",
      "text": "The priests could not go into the Lord's temple because the Lord's glory had completely filled it."
    },
    {
      "verse": "3",
      "text": "All the Israelites saw the fire come down. They also saw the Lord's glory above the temple. They went down on their knees on the flat stones of the yard, with their faces towards the ground. They worshipped the Lord and they thanked him. They said, ‘He is good. His faithful love continues for ever. ’"
    },
    {
      "verse": "4",
      "text": "Then the king and all the people offered sacrifices to the Lord."
    },
    {
      "verse": "5",
      "text": "King Solomon offered 22, 000 cows and 120, 000 sheep and goats as sacrifices. In this way the king and all the people offered the temple as a gift to God."
    },
    {
      "verse": "6",
      "text": "The priests and the Levites stood in their places. The Levites held the musical instruments that King David had made to thank the Lord. They sang these words to praise the Lord: ‘His faithful love continues for ever. ’ The priests stood on the other side and they made music with their trumpets. All the Israelites were standing up while this was happening."
    },
    {
      "verse": "7",
      "text": "On the same day, Solomon gave to the Lord the yard that was in front of the temple. He offered burnt offerings and grain offerings to the Lord. He also offered the fat from the friendship offerings there. The bronze altar that Solomon had made was too small to contain all these offerings, so he made these sacrifices in the middle of the yard instead."
    },
    {
      "verse": "8",
      "text": "At that time, Solomon and the big crowd of Israelites who were with him had a festival for seven days. There were people from everywhere in Israel, from Hamath in the north to the Stream of Egypt in the south."
    },
    {
      "verse": "9",
      "text": "On the day after the festival, they all met together. For seven days, they had given offerings to make the altar holy for God. For another seven days, they had enjoyed the festival."
    },
    {
      "verse": "10",
      "text": "Then Solomon sent the people away to their homes. That was on the 23rd day of the seventh month. The people were very happy and full of joy because the Lord had done many good things for King David, for King Solomon and for his people, the Israelites."
    },
    {
      "verse": "11",
      "text": "Solomon had finished building the Lord's temple and the king's palace. He had done everything that he wanted to do for the temple and his palace."
    },
    {
      "verse": "12",
      "text": "Then the Lord appeared to Solomon at night. He said to Solomon, ‘I have heard your prayer. I have chosen this place as my temple where people can offer sacrifices to me."
    },
    {
      "verse": "13",
      "text": "Sometimes I may stop the rain falling from the sky. I may send locusts to destroy your crops. Or I may send a bad disease to hurt my people."
    },
    {
      "verse": "14",
      "text": "If that happens, my people who belong to me should be humble and they should pray to me. They should turn away from their sins and try to please me. Then I will hear them from heaven. I will forgive their sins and I will make their land successful again."
    },
    {
      "verse": "15",
      "text": "Now I will watch over this place. I will answer the prayers that people offer to me here."
    },
    {
      "verse": "16",
      "text": "I have chosen this temple to be my special home. People will worship me there for ever. I will always be there to watch over it."
    },
    {
      "verse": "17",
      "text": "But you must all continue to serve me well, as your father David did. Do everything that I have commanded you to do. Obey my rules and my laws."
    },
    {
      "verse": "18",
      "text": "If you do that, I will always cause one of your descendants to rule as king. That is what I promised to your father David when I said, “There will always be someone from your family to rule over Israel. ”"
    },
    {
      "verse": "19",
      "text": "But if any of you turn away from me, I will punish your people. I will do that if you do not obey the laws and rules that I have given to you. I will do it if you choose to serve and to worship other gods."
    },
    {
      "verse": "20",
      "text": "I will remove the people from the land that I have given to them. I will turn away from this temple that I have made a special place for my people to worship me. People from all the other nations will insult them and they will laugh at them."
    },
    {
      "verse": "21",
      "text": "This beautiful temple will became a heap of stones. Everyone who sees it will be very surprised. They will laugh about it! They will ask, “Why has the Lord destroyed this land and this temple? ”"
    },
    {
      "verse": "22",
      "text": "People will answer, “He has done it because they have turned away from the Lord, the God of their ancestors. He brought their ancestors out of Egypt. But now they have chosen to worship other gods and to serve them. That is why the Lord has caused this trouble to happen to them. ” ’"
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Solomon was building the Lord's temple and the king's palace for 20 years."
    },
    {
      "verse": "2",
      "text": "After that, he built again the towns that King Hiram had given to him. He sent Israelites to live in them."
    },
    {
      "verse": "3",
      "text": "Then Solomon went to Hamath-Zobah and he took it for Israel."
    },
    {
      "verse": "4",
      "text": "He made the buildings in Tadmor strong again. That was a town in the wilderness. He did the same thing for the towns that he had built in Hamath region to store things."
    },
    {
      "verse": "5",
      "text": "He built again Higher Beth-Horon and Lower Beth-Horon. He made those cities strong. He built walls around them with strong gates."
    },
    {
      "verse": "6",
      "text": "He also made Baalath strong, and all his cities where he stored things, as well as all the cities where he kept his chariots and horses. He built everything that he wanted to build in Jerusalem, in Lebanon and everywhere in his kingdom."
    },
    {
      "verse": "7",
      "text": "Solomon only made people who were not Israelites do the hard work for him. They were Canaanite people who still lived in the land after the Israelites took it for themselves. They were Hittites, Amorites, Perizzites, Hivites and Jebusites."
    },
    {
      "verse": "8",
      "text": "The Israelites had not been able to destroy all of these people, so their descendants remained in the land. So Solomon made them do hard work as his slaves. They are still slaves of the Israelites today."
    },
    {
      "verse": "9",
      "text": "But Solomon did not cause any Israelites to do the hard work as slaves. Instead, they became his soldiers and army officers. Some of the soldiers drove chariots and some were leaders of the chariot drivers."
    },
    {
      "verse": "10",
      "text": "Israelite officers who had authority over the workers."
    },
    {
      "verse": "11",
      "text": "Solomon had built a palace for his wife, Pharaoh's daughter. When the palace was ready, he brought her up there from the City of David. He said, ‘My wife must not live in the palace of David, king of Israel. The Lord's Covenant Box has been there, so it is a holy place. ’"
    },
    {
      "verse": "12",
      "text": "Solomon offered burnt offerings to the Lord on the altar that he had built. The altar was outside the entrance of the temple."
    },
    {
      "verse": "13",
      "text": "He offered the sacrifices every day that Moses had told them to do. There were rules about sacrifices on Sabbath days, on festivals for each new moon and on the three special festivals each year. Those were the Festival of Flat Bread, the Festival of Weeks and the Festival of Huts."
    },
    {
      "verse": "14",
      "text": "Solomon gave jobs to each group of priests as his father David had commanded. He also gave the Levites their jobs to do each day. They led the music to worship God and they helped the priests with their work. He gave each group of guards a job to watch the gates of the temple. He told them all to do this in the way that God's servant David had commanded."
    },
    {
      "verse": "15",
      "text": "All the priests and the Levites were careful to do exactly what the king had commanded. That included the rooms where they stored valuable things."
    },
    {
      "verse": "16",
      "text": "Solomon's workers did all the jobs that he told them to do. They started on the day when they built the foundation of the Lord's temple. They continued to work until they had finished everything. In that way, work on the Lord's temple was complete."
    },
    {
      "verse": "17",
      "text": "Then Solomon went to Ezion-Geber and to Elath. They were towns on the coast of the sea, in the land of Edom."
    },
    {
      "verse": "18",
      "text": "King Hiram had sailors who knew how to sail ships on the sea. He sent some of these men to work with Solomon's sailors. They sailed to Ophir and they brought back about 15 tons of gold. They gave it to King Solomon."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "The Queen of Sheba heard news that Solomon was a great king. So she came to ask Solomon some difficult questions to see how wise he was. She arrived at Jerusalem with a big group of servants. She had many camels that carried spices. They also carried a lot of gold and valuable jewels. When she came to Solomon, she talked to him about everything that was in her mind."
    },
    {
      "verse": "2",
      "text": "Solomon answered all her questions. There was nothing that was too difficult for him to explain to her."
    },
    {
      "verse": "3",
      "text": "The Queen of Sheba saw that Solomon was very wise. She saw the palace that he had built."
    },
    {
      "verse": "4",
      "text": "She saw all the food that he ate in his palace. She saw all his servants and officers and their beautiful clothes. She saw the servants who prepared his food and wine. She saw the burnt offerings that he offered in the Lord's temple. All these things caused her to hold her breath in surprise."
    },
    {
      "verse": "5",
      "text": "She said to the king, ‘In my own country I heard news about your wisdom and about all the things that you had done. Everything that I heard was true!"
    },
    {
      "verse": "6",
      "text": "But I did not believe those things until I came here. Now I have seen everything with my own eyes, and it is true! Really, they told me less than half of what was true! You are even wiser than the report that people told me."
    },
    {
      "verse": "7",
      "text": "God has blessed your people and your officers! They are always with you, and they can listen to your wise words."
    },
    {
      "verse": "8",
      "text": "So we should praise the Lord your God! He is happy with you and he has chosen you to rule Israel on his behalf. Your God will continue to love Israel for ever, and he will always make them strong. So he has made you king to rule them in a fair and honest way. ’"
    },
    {
      "verse": "9",
      "text": "The Queen of Sheba gave to King Solomon more than four tons of gold, a lot of spices and many valuable jewels. Nobody has ever brought such a great number of spices as she gave to the king."
    },
    {
      "verse": "10",
      "text": "King Hiram's men had brought gold from Ophir. King Solomon's men had helped them to do this. They also brought very good wood, and valuable jewels."
    },
    {
      "verse": "11",
      "text": "The king used the wood to make steps for the Lord's temple and for the king's palace. He also used it to make harps and lyres for the musicians. Nobody had ever seen things like those in Judah."
    },
    {
      "verse": "12",
      "text": "King Solomon gave to the Queen of Sheba everything that she wanted. He gave more things to her than she had brought to him. Then she left with all her servants and she returned to her own country."
    },
    {
      "verse": "13",
      "text": "tons of gold each year."
    },
    {
      "verse": "14",
      "text": "He also received money from traders and from people who travelled to buy things. The kings of Arabia and the rulers of each region in Israel also brought gold and silver to Solomon."
    },
    {
      "verse": "15",
      "text": "King Solomon's workers used gold to make 200 large shields. They hit the gold with hammers to make it flat. They used about four kilograms of gold to cover each shield."
    },
    {
      "verse": "16",
      "text": "small shields in the same way. They used about 2 kilograms of gold to cover each shield. He put these shields in the Palace of the Forest of Lebanon."
    },
    {
      "verse": "17",
      "text": "The king used ivory to make a large throne. He covered it with pure gold."
    },
    {
      "verse": "18",
      "text": "There were six steps up to the throne. They fixed a gold box to the throne for the king to put his feet on. On both sides of the seat there were places to put his arms. An image of a lion stood on each side of the throne."
    },
    {
      "verse": "19",
      "text": "more images of lions on the six steps. There was one lion at each end of every step. There was no throne like it in any other kingdom."
    },
    {
      "verse": "20",
      "text": "They used gold to make all King Solomon's cups that he drank from. In the Palace of the Forest of Lebanon, all the dishes and other things were made with gold. They used pure gold. They did not make anything with silver. In Solomon's time, people did not think that silver was very valuable."
    },
    {
      "verse": "21",
      "text": "The king had many large ships that King Hiram's men could sail across the seas. Every three years they returned to Solomon with their loads. They brought to him gold, silver and ivory. They also brought apes and monkeys."
    },
    {
      "verse": "22",
      "text": "King Solomon was richer and wiser than any other king in the world."
    },
    {
      "verse": "23",
      "text": "The kings of every nation in the world wanted to talk to Solomon. They wanted to listen to the wisdom that God had given to him."
    },
    {
      "verse": "24",
      "text": "Every year, people who came to visit Solomon brought him gifts. They brought things that were made from silver and gold, as well as clothes, weapons, spices, horses and mules."
    },
    {
      "verse": "25",
      "text": "Solomon had places to keep 4, 000 horses that pulled his chariots. He also had 12, 000 horses. He kept them in the cities that he had chosen for this and also in Jerusalem where he lived."
    },
    {
      "verse": "26",
      "text": "He ruled over all the kings around Israel, from the Euphrates river as far as the Philistines' country and the border of Egypt."
    },
    {
      "verse": "27",
      "text": "While Solomon ruled as king, there was as much silver in Jerusalem as stones! There was as much wood from cedar trees as there were fig trees that grew in the low hills in the west."
    },
    {
      "verse": "28",
      "text": "People brought horses to Solomon from Egypt and from all the other countries."
    },
    {
      "verse": "29",
      "text": "People wrote down everything else that Solomon did while he ruled as king, from the beginning to the end. The prophet Nathan wrote them down in his book. The prophet Ahijah who came from Shiloh also wrote them down. The prophet Iddo also wrote about them in his book of the visions that he saw about Nebat's son Jeroboam."
    },
    {
      "verse": "30",
      "text": "years while he lived in Jerusalem."
    },
    {
      "verse": "31",
      "text": "Then he died. They buried him with his ancestors, in the city of his father David. His son Rehoboam became king after him."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "Rehoboam went to Shechem, because all the Israelites had gone there to make him king."
    },
    {
      "verse": "2",
      "text": "At this time, Nebat's son Jeroboam was in Egypt. He had been living there since he ran away from King Solomon. When he heard the news about Rehoboam, he returned from Egypt."
    },
    {
      "verse": "3",
      "text": "The Israelites sent a message to Jeroboam to meet with them. Then Jeroboam and all the Israelites went to speak to Rehoboam. They said to him,"
    },
    {
      "verse": "4",
      "text": "‘Your father caused us to work too hard. Please make the work easier for us. If you do that, we will serve you as our king. ’"
    },
    {
      "verse": "5",
      "text": "Rehoboam answered them, ‘Go away for three days. Then come back to me. ’ So the people went away."
    },
    {
      "verse": "6",
      "text": "Then King Rehoboam went to talk to the older advisors who had served his father Solomon. He asked them, ‘What answer should I give to these people? ’"
    },
    {
      "verse": "7",
      "text": "They replied, ‘If you agree to be kind to these people and help them, they will always serve you as their king. So do what they are asking you to do. ’"
    },
    {
      "verse": "8",
      "text": "But Rehoboam did not agree with their advice. Instead he talked to some younger men. They had been his friends since they were young and now they were his advisors."
    },
    {
      "verse": "9",
      "text": "He asked them, ‘What do you think that I should say to these people? They want me to make their work easier. ’"
    },
    {
      "verse": "10",
      "text": "Rehoboam's young advisors said, ‘The people said to you, “Your father made us work too hard. Please make our work easier. ” You should tell them, “Even my little finger is thicker than my father's whole body!"
    },
    {
      "verse": "11",
      "text": "My father made you work hard. I will make you work even harder! My father punished you with little whips. I will punish you with whips that bite your skin! ” ’"
    },
    {
      "verse": "12",
      "text": "Jeroboam and all the people returned to Rehoboam after three days. That was because the king had said, ‘Return to me in three days. ’"
    },
    {
      "verse": "13",
      "text": "King Rehoboam spoke cruel words to the people. He did not agree to say what the older men had told him to say."
    },
    {
      "verse": "14",
      "text": "Instead, he did what the young men had suggested. He said to the people, ‘My father gave you work that was too hard for you. I will make it even worse! My father punished you with little whips. I will punish you with whips that bite! ’"
    },
    {
      "verse": "15",
      "text": "So the king did not agree to do what the people wanted him to do. It was God who caused this to happen. He had already given his message about this to Nebat's son Jeroboam. The prophet Ahijah who came from Shiloh had spoken the Lord's message to Jeroboam."
    },
    {
      "verse": "16",
      "text": "All the Israelites realized that the king refused to listen to them. So they said to the king, ‘We can no longer serve the family of Jesse's son, David! Israelites, go back to your homes! You descendant of David, take care of your own family! ’So the Israelites went to their homes. ‘We can no longer serve the family of Jesse's son, David! Israelites, go back to your homes! You descendant of David, take care of your own family! ’"
    },
    {
      "verse": "17",
      "text": "But Rehoboam continued to rule over the Israelites who lived in the towns of Judah."
    },
    {
      "verse": "18",
      "text": "King Rehoboam sent a man called Adoniram to talk to the Israelite people. Adoniram had authority over the men who had to work for Rehoboam. But the Israelites threw stones at Adoniram and they killed him. So King Rehoboam quickly got into his chariot and he escaped to Jerusalem."
    },
    {
      "verse": "19",
      "text": "Since that time, the tribes in the north of Israel have not accepted the authority of King David's descendants."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "Rehoboam arrived back in Jerusalem. He brought together all the men from the tribes of Judah and Benjamin who knew how to fight. There were 180, 000 of them. Rehoboam wanted to attack the Israelite tribes so that he could rule them again as king. So they obeyed the Lord's message. They did not go to attack Jeroboam."
    },
    {
      "verse": "2",
      "text": "But the Lord told the prophet Shemaiah,"
    },
    {
      "verse": "3",
      "text": "‘Say this to Solomon's son Rehoboam, the king of Judah. Say it to all the Israelite people who belong to the tribes of Judah and Benjamin."
    },
    {
      "verse": "4",
      "text": "This is what the Lord says: “Do not go and attack your brothers. Do not fight against them. Instead, you must all go home. I, the Lord, have decided that this must happen. ” ’So they obeyed the Lord's message. They did not go to attack Jeroboam."
    },
    {
      "verse": "5",
      "text": "Rehoboam lived in Jerusalem. He built these strong cities in Judah to make it safe:"
    },
    {
      "verse": "6",
      "text": "Bethlehem, Etam, Tekoa,"
    },
    {
      "verse": "7",
      "text": "Beth-Zur, Soco, Adullam,"
    },
    {
      "verse": "8",
      "text": "Gath, Mareshah, Ziph,"
    },
    {
      "verse": "9",
      "text": "Adoraim, Lachish, Azekah,"
    },
    {
      "verse": "10",
      "text": "Zorah, Aijalon and Hebron. He made all those cities in Judah and Benjamin very strong."
    },
    {
      "verse": "11",
      "text": "He made their buildings stronger. He put important officers in them to rule over them. He stored food, olive oil and wine in them."
    },
    {
      "verse": "12",
      "text": "He supplied every city with shields and spears. He did all these things to make them very strong places. So Rehoboam kept his authority over Judah and Benjamin."
    },
    {
      "verse": "13",
      "text": "The priests and Levites who lived everywhere in Israel agreed to serve Rehoboam."
    },
    {
      "verse": "14",
      "text": "The Levites even left their lands and their houses to come to Judah and Jerusalem. They came because Jeroboam and his sons refused to let them serve the Lord as his priests."
    },
    {
      "verse": "15",
      "text": "Jeroboam chose his own priests to offer sacrifices at the altars that he had built on the hills. They worshipped the idols of goats and young bulls that Jeroboam had made."
    },
    {
      "verse": "16",
      "text": "But some people from every tribe in Israel still wanted to worship the Lord, Israel's God. So they came with the Levites to Jerusalem. They came to offer sacrifices to the Lord, the God of their ancestors."
    },
    {
      "verse": "17",
      "text": "These people helped to make the kingdom of Judah stronger. They were faithful to Solomon's son Rehoboam for three years. During that time, they lived in the way that David and Solomon had taught them to live."
    },
    {
      "verse": "18",
      "text": "Rehoboam married Mahalath. Her father was David's son Jerimoth. Her mother was Abihail, the daughter of Jesse's son Eliab."
    },
    {
      "verse": "19",
      "text": "She gave birth to three sons for Rehoboam. Their names were Jeush, Shemariah and Zaham."
    },
    {
      "verse": "20",
      "text": "Then Rehoboam married Absalom's daughter Maakah. She gave birth to Abijah, Attai, Ziza and Shelomith for him."
    },
    {
      "verse": "21",
      "text": "Rehoboam loved Absalom's daughter Maakah better than he loved any of his other wives. He had 18 wives and 60 slave wives. He was the father of 28 sons and 60 daughters."
    },
    {
      "verse": "22",
      "text": "Rehoboam chose Maakah's son Abijah to be the leader over his other sons. He wanted Abijah to become the next king."
    },
    {
      "verse": "23",
      "text": "He did a wise thing with his other sons. He sent many of them to the different regions of Judah and Benjamin, to live in all the strong cities. He supplied them with plenty of food. He also found many women to become their wives."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "Rehoboam became a strong king who ruled with authority. But after that, he stopped obeying the law of the Lord. All the Israelites did the same thing."
    },
    {
      "verse": "2",
      "text": "They did not serve the Lord in a faithful way. Because of that, King Shishak of Egypt attacked Jerusalem in the fifth year that Rehoboam was king Judah."
    },
    {
      "verse": "3",
      "text": "King Shishak's army had 1, 200 chariots and 60, 000 soldiers who rode on horses. Many other soldiers came with him from Egypt. They included men from Libya, Sukkoth and Ethiopia."
    },
    {
      "verse": "4",
      "text": "He took power over Judah's strong cities. Then his army marched to attack Jerusalem."
    },
    {
      "verse": "5",
      "text": "The prophet Shemaiah then came to speak to Rehoboam and the leaders of Judah. They had met together in Jerusalem because they were afraid of King Shishak. Shemaiah said to them, ‘The Lord says this: “You have turned away from me. So now I have turned away from you. I will let Shishak take power over you. ” ’"
    },
    {
      "verse": "6",
      "text": "The leaders of Israel and the king made themselves humble. They said, ‘The Lord is right to do that. ’"
    },
    {
      "verse": "7",
      "text": "The Lord saw that they had made themselves humble. So he said to Shemaiah, ‘Because they have made themselves humble, I will not destroy them. I will soon rescue them. I will not use Shishak to completely destroy Jerusalem's people. But because I am angry,"
    },
    {
      "verse": "8",
      "text": "they will become his servants. Then they will learn what it is like to serve a foreign king instead of me. ’"
    },
    {
      "verse": "9",
      "text": "King Shishak of Egypt then attacked Jerusalem. He took away the valuable things that were in the Lord's temple and in the king's palace. He took everything for himself. That included the gold shields that King Solomon had made."
    },
    {
      "verse": "10",
      "text": "So Rehoboam used bronze to make other shields instead. He gave them to the officers of his own soldiers. These soldiers stood as guards at the entrance of the king's palace."
    },
    {
      "verse": "11",
      "text": "Every time that the king went to the Lord's temple, the guards carried the shields. After that, they took them back to the guards' room where they stored them."
    },
    {
      "verse": "12",
      "text": "Rehoboam made himself humble. So the Lord did not destroy him. He stopped being angry with Rehoboam. He caused good things to happen in Judah."
    },
    {
      "verse": "13",
      "text": "Rehoboam made his authority as king in Jerusalem very strong. He was 41 years old when he became king. He ruled for 17 years in Jerusalem. That was the city that the Lord had chosen out of all the tribes of Israel. He chose it as the place where people would give honour to his name. Rehoboam's mother was an Ammonite woman. Her name was Naamah."
    },
    {
      "verse": "14",
      "text": "Rehoboam did wicked things because he did not want to serve the Lord faithfully."
    },
    {
      "verse": "15",
      "text": "All the things that happened while Rehoboam was king of Judah are written in some books. The prophet Shemaiah and the prophet Iddo wrote those things in their books. The books include lists of the ancestors of Rehoboam's family. Rehoboam and Jeroboam fought wars against each other all the time."
    },
    {
      "verse": "16",
      "text": "Rehoboam died and they buried him beside his ancestors in the City of David. His son Abijah became king after him."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "years."
    },
    {
      "verse": "2",
      "text": "Abijah ruled in Jerusalem as king for three years. His mother's name was Micaiah. She was the daughter of Uriel from Gibeah. Abijah and Jeroboam fought a war against each other."
    },
    {
      "verse": "3",
      "text": "Abijah attacked with an army of 400, 000 brave soldiers that he had chosen. Jeroboam prepared to fight against him with 800, 000 strong brave soldiers that he had chosen."
    },
    {
      "verse": "4",
      "text": "Abijah went to stand on Mount Zemaraim, in the hill country of Ephraim. He shouted, ‘Listen to me, Jeroboam and all you Israelites!"
    },
    {
      "verse": "5",
      "text": "The Lord, Israel's God, has chosen David and his descendants to be kings of Israel for all time. You know that God has promised that must happen."
    },
    {
      "verse": "6",
      "text": "Nebat's son Jeroboam was a servant of David's son, King Solomon. But he turned against his master."
    },
    {
      "verse": "7",
      "text": "He took some wicked useless men to join his group. They made themselves strong against Solomon's son, Rehoboam. Rehoboam was young and he had not been king for very long. So he was not strong enough to stop them."
    },
    {
      "verse": "8",
      "text": "Now you want to fight against the Lord's own kingdom that he has chosen David's descendants to rule over. You have a very large army. You bring with you the gold statues of young bulls that Jeroboam made for you as your gods."
    },
    {
      "verse": "9",
      "text": "But you chased away the Lord's own priests, the descendants of Aaron. You chased away the Levites. Instead you chose your own priests, as the people in other nations do. Anyone can become a priest to serve your false gods. He only has to come with a sacrifice of a young bull and seven male sheep!"
    },
    {
      "verse": "10",
      "text": "But we still serve the Lord as our God. We have not turned away from him. We have the descendants of Aaron to serve as our priests. The Levites help them in their work."
    },
    {
      "verse": "11",
      "text": "They offer burnt offerings and sweet incense to the Lord every morning and every evening. They put out the special bread on his table every day. They light the lamps on the gold lampstand every evening. So we are the people who are obeying the rules of the Lord our God. But you have turned away from him."
    },
    {
      "verse": "12",
      "text": "Listen to me! God himself is our leader. He is here to help us. His priests are ready to make a loud noise with their trumpets to start the battle against you. Israelite people, do not fight against the Lord, the God of your ancestors. You will not win the battle. ’"
    },
    {
      "verse": "13",
      "text": "But Jeroboam had sent some soldiers around behind Judah's army. Jeroboam was with the rest of his army, in front of Judah's army. The other soldiers were ready to attack from behind."
    },
    {
      "verse": "14",
      "text": "Judah's soldiers turned around. They saw that Jeroboam's soldiers were in front of them and behind them. So they called out to the Lord for help. The priests made a noise with their trumpets."
    },
    {
      "verse": "15",
      "text": "Judah's soldiers shouted very loudly. As King Abijah led Judah's soldiers into the battle, the Lord knocked down Jeroboam and all Israel's army."
    },
    {
      "verse": "16",
      "text": "Israel's soldiers ran away as Judah's army chased after them. God caused Judah's soldiers to win the fight."
    },
    {
      "verse": "17",
      "text": "Abijah and his army killed many of the Israel soldiers. 500, 000 of Israel's best soldiers died."
    },
    {
      "verse": "18",
      "text": "Judah's soldiers trusted the Lord, the God of their ancestors, to help them. That was why they won the battle that day against Israel's army."
    },
    {
      "verse": "19",
      "text": "King Abijah chased King Jeroboam. He took these Israelite towns for himself: Bethel, Jeshanah and Ephron, as well as the villages around them."
    },
    {
      "verse": "20",
      "text": "After that, while Abijah was Judah's king, Jeroboam never became strong again. Finally, the Lord punished Jeroboam so that he died."
    },
    {
      "verse": "21",
      "text": "But Abijah became more powerful. He married 14 wives. He became the father of 22 sons and 16 daughters."
    },
    {
      "verse": "22",
      "text": "All the other things that happened while Abijah ruled as king are written in the book of the prophet Iddo. It includes the things that Abijah did and the things that he said."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "Abijah died and they buried him beside his ancestors in the City of David. Abijah's son Asa became king after him. The country had peace for ten years while Asa was king."
    },
    {
      "verse": "2",
      "text": "Asa did things that pleased the Lord his God."
    },
    {
      "verse": "3",
      "text": "He removed the altars and other places where people worshipped foreign gods. He broke the stone pillars and he cut down the Asherah poles."
    },
    {
      "verse": "4",
      "text": "Asa commanded the people of Judah to worship the Lord, the God of their ancestors. He told them to obey God's law and his commands."
    },
    {
      "verse": "5",
      "text": "He removed the altars on the hills. He also removed the altars in all Judah's cities where people burned incense. There was peace in his kingdom while he ruled."
    },
    {
      "verse": "6",
      "text": "While there was peace in the land, Asa made the cities of Judah strong and safe. No enemies fought wars against Judah during that time. The Lord gave Asa rest from any trouble."
    },
    {
      "verse": "7",
      "text": "Asa said to Judah's people, ‘We should build these towns and make them stronger. We must put walls around them, with towers and strong gates. Judah still belongs to us because we have obeyed the Lord our God. He has made us safe from our enemies all around us. ’So the people made these towns strong. Everything went well for them. So the people made these towns strong. Everything went well for them."
    },
    {
      "verse": "8",
      "text": "Asa had an army of 300, 000 men from Judah. They carried big shields and spears. He also had 280, 000 men from Benjamin's tribe. Those men carried small shields and they could shoot arrows with their bows. They were all brave soldiers who could fight well."
    },
    {
      "verse": "9",
      "text": "A man from Ethiopia called Zerah marched out to attack Judah. He had a very big army of a million soldiers and 300 chariots. When he reached Mareshah,"
    },
    {
      "verse": "10",
      "text": "Asa went out to fight against him. The two armies prepared to fight a battle in Zephathah valley, near Mareshah."
    },
    {
      "verse": "11",
      "text": "Then Asa called out to the Lord his God to help him. He prayed, ‘There is nobody like you Lord. You have power to help a few weak people against many strong people. Help us, Lord our God, because we trust you. We want people to give honour to your name. That is why we have come to fight against this large army. Lord, you are our God. You cannot let these men win against you. ’"
    },
    {
      "verse": "12",
      "text": "So the Lord knocked down Zerah's soldiers as Asa and Judah's army attacked them. The Ethiopian soldiers ran away."
    },
    {
      "verse": "13",
      "text": "Asa and his soldiers chased after them until they reached Gerar. So many Ethiopian soldiers died there that their army could not fight any more. The Lord and his army completely destroyed them. Judah's soldiers carried away lots of their enemies' things for themselves."
    },
    {
      "verse": "14",
      "text": "The Lord caused the people in the towns near Gerar to become very afraid. So Judah's soldiers were able to attack those towns. There were many valuable things in all those towns and Judah's men took them away for themselves."
    },
    {
      "verse": "15",
      "text": "They also attacked the tents of the people who took care of animals. They took away many sheep and camels from there. Then they returned to Jerusalem."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "God's Spirit came to Oded's son Azariah."
    },
    {
      "verse": "2",
      "text": "Azariah went to meet King Asa. He said to him, ‘Listen to me Asa and all you people of the tribes of Judah and Benjamin. The Lord will be with you while you are faithful to him. If you ask him for help, he will answer you. But if you turn away from him, he will turn away from you."
    },
    {
      "verse": "3",
      "text": "For a long time, the Israelites did not serve the true God. They did not have any priests to teach them what was right. They did not know God's law."
    },
    {
      "verse": "4",
      "text": "But when they were in trouble, they turned to the Lord, Israel's God. They asked him to help them and he answered them."
    },
    {
      "verse": "5",
      "text": "At that time it was not safe to travel very far. There was too much trouble among the people of other countries."
    },
    {
      "verse": "6",
      "text": "One nation would attack and destroy another nation. The people of one city destroyed other cities. God caused all this trouble to happen to those people."
    },
    {
      "verse": "7",
      "text": "But you must be strong. Continue to be brave. God will make your work successful. ’"
    },
    {
      "verse": "8",
      "text": "Asa felt strong again when he heard God's message from Azariah, son of the prophet Oded. He removed the disgusting idols from the whole land of Judah and Benjamin. He also removed them from the towns that he had taken in the hill country of Ephraim. He repaired the Lord's altar that was in the yard at the front of the Lord's temple."
    },
    {
      "verse": "9",
      "text": "Then King Asa brought all the people together who belonged to the tribes of Judah and Benjamin. He also brought people from the tribes of Ephraim, Manasseh, and Simeon who had come to live in Judah. Many people from the other tribes of Israel had come to Judah to serve King Asa. They had seen that the Lord his God was with him to help him."
    },
    {
      "verse": "10",
      "text": "All these people met together in Jerusalem in the 15th year after Asa had become king. They met in the third month of the year. After that, the Lord made them safe from their enemies all around them."
    },
    {
      "verse": "11",
      "text": "At that time they offered many animals to the Lord as sacrifices. They were animals that they had taken from their enemies. There were 700 bulls and 7, 000 sheep."
    },
    {
      "verse": "12",
      "text": "They made a serious promise that they would faithfully serve the Lord, the God of their ancestors."
    },
    {
      "verse": "13",
      "text": "If anyone refused to worship the Lord, Israel's God, they would punish that person with death. They agreed to do that, whoever the person was, young or old, male or female."
    },
    {
      "verse": "14",
      "text": "As they made this promise to the Lord, they shouted loudly to show that they agreed. They also made a loud noise with trumpets and sheep's horns."
    },
    {
      "verse": "15",
      "text": "All Judah's people were happy to make this promise, because they truly wanted to serve the Lord. They wanted him to help them and he answered them. After that, the Lord made them safe from their enemies all around them."
    },
    {
      "verse": "16",
      "text": "King Asa also told his grandmother Maakah that she could no longer have authority as the Queen Mother. This was because she had made a disgusting Asherah pole to worship. Asa cut down the Asherah pole and he burned it in the Kidron Valley."
    },
    {
      "verse": "17",
      "text": "Asa did not remove the altars on all the hills in Israel, but he served the Lord faithfully for his whole life."
    },
    {
      "verse": "18",
      "text": "He brought into God's temple the things that he and his father had made as gifts for God. They used silver and gold to make some of these things."
    },
    {
      "verse": "19",
      "text": "years."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "years, King Baasha of Israel attacked Judah. He put a group of his soldiers in Ramah and he made it a strong town. As a result, nobody could travel into Judah or out of Judah, where King Asa ruled."
    },
    {
      "verse": "2",
      "text": "Then Asa took all the silver and gold that they had stored in the Lord's temple and in the king's palace. He sent it to Ben-Hadad, king of Syria, who lived in Damascus."
    },
    {
      "verse": "3",
      "text": "He also sent this message to Ben-Hadad: ‘We should make an agreement to be friends, as our fathers did. I am sending you this silver and gold. Please stop being friends with Baasha, king of Israel. If you no longer help him, he will have to take his soldiers out of my country. ’"
    },
    {
      "verse": "4",
      "text": "Ben-Hadad agreed to do what King Asa asked him to do. He sent his army with its leaders to attack towns in Israel. They won the battles at Ijon, Dan, Abel-Maim and all the cities of Naphtali's tribe where they stored things."
    },
    {
      "verse": "5",
      "text": "When King Baasha heard this news, he stopped the work in Ramah and he went away."
    },
    {
      "verse": "6",
      "text": "Then King Asa told all the men in Judah to do some hard work. They had to carry away from Ramah all the big stones and the wood that Baasha had been using there. Then King Asa used those things to make Geba and Mizpah strong towns again."
    },
    {
      "verse": "7",
      "text": "At that time, the prophet Hanani went to visit Asa, king of Judah. He said to him, ‘You asked the king of Syria to help you. You should have trusted the Lord your God to help you instead. Because of that, the army of Syria's king has escaped from your power."
    },
    {
      "verse": "8",
      "text": "The armies of Ethiopia and Libya were very large. They had lots of chariots and soldiers who rode on horses. But you trusted the Lord when they attacked you, and he put them under your power."
    },
    {
      "verse": "9",
      "text": "The Lord carefully watches over the whole earth. If people serve him faithfully, he makes them strong. But you have done a foolish thing. As a result, you will now always be fighting wars. ’"
    },
    {
      "verse": "10",
      "text": "Asa was angry with the prophet, so he put him in prison. At that time Asa also started to do cruel things to some people."
    },
    {
      "verse": "11",
      "text": "All the things that happened while Asa was king are written in a book. The book is called ‘The history of the kings of Judah and Israel’."
    },
    {
      "verse": "12",
      "text": "years, he had a disease in his feet. He became very ill, but he did not ask the Lord to help him. Instead, he asked doctors to make him better."
    },
    {
      "verse": "13",
      "text": "years."
    },
    {
      "verse": "14",
      "text": "His people buried him in the grave that he had prepared for himself in the City of David. They put him on a special bed that had spices and different kinds of perfume on it. They burned a large fire to give him honour."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "Asa's son Jehoshaphat became the next king of Judah. He made his kingdom strong to fight against Israel."
    },
    {
      "verse": "2",
      "text": "He put soldiers in all Judah's cities that had walls around them and in other places in Judah. He also put soldiers in the towns of Ephraim that his father Asa had taken power over."
    },
    {
      "verse": "3",
      "text": "Jehoshaphat obeyed the Lord as his ancestor David had done when he first ruled as king. So the Lord was with him to help him. Jehoshaphat did not worship the idols of Baal."
    },
    {
      "verse": "4",
      "text": "Instead, he served the God that his father had served. He obeyed the Lord's commands. He did not do the wrong things that Israel's people did."
    },
    {
      "verse": "5",
      "text": "The Lord gave Jehoshaphat power over the kingdom of Judah. All Judah's people brought gifts to him. So Jehoshaphat became rich and people respected him."
    },
    {
      "verse": "6",
      "text": "He served the Lord with all his strength. He removed from Judah the altars on the hills and the Asherah poles."
    },
    {
      "verse": "7",
      "text": "In the third year that Jehoshaphat ruled Judah as king, he sent his officers to teach people in all Judah's towns. The names of those officers were Ben-Hail, Obadiah, Zechariah, Nethanel and Micaiah."
    },
    {
      "verse": "8",
      "text": "He sent these Levites to go with them: Shemaiah, Nethaniah, Zebadiah, Asahel, Shemiramoth, Jehonathan, Adonijah, Tobijah, and Tob-Adonijah. He also sent the priests, Elishama and Jehoram."
    },
    {
      "verse": "9",
      "text": "These men travelled everywhere in Judah to teach people. They took with them the book which was a copy of the Lord's law. They used it to teach people in all Judah's towns."
    },
    {
      "verse": "10",
      "text": "The people in all the kingdoms around Judah were afraid of the Lord's power. So they did not want to fight a war against Jehoshaphat."
    },
    {
      "verse": "11",
      "text": "Some Philistines brought silver and other gifts to Jehoshaphat to make him happy. People from Arabia also brought gifts to him. They brought 7, 700 male sheep and 7, 700 male goats."
    },
    {
      "verse": "12",
      "text": "Jehoshaphat became more and more powerful. He built strong buildings and places to store things everywhere in Judah. From Judah's tribe, the officer who led the soldiers was Adnah. He had authority over 300, 000 soldiers, in groups of 1, 000."
    },
    {
      "verse": "13",
      "text": "He kept lots of things in Judah's towns. He had a big army of strong, brave soldiers in Jerusalem."
    },
    {
      "verse": "14",
      "text": "These are the groups of the soldiers in each clan: From Judah's tribe, the officer who led the soldiers was Adnah. He had authority over 300, 000 soldiers, in groups of 1, 000."
    },
    {
      "verse": "15",
      "text": "The next officer was Jehohanan. He had authority over 280, 000 soldiers."
    },
    {
      "verse": "16",
      "text": "After him, the next officer was Zikri's son, Amasiah. He himself chose to serve the Lord in this way. He had authority over 200, 000 soldiers."
    },
    {
      "verse": "17",
      "text": "From Benjamin's tribe, the officer who led the soldiers was Eliada, a brave soldier. He had authority over 200, 000 soldiers who had bows and arrows, as well as shields."
    },
    {
      "verse": "18",
      "text": "After him, the next officer was Jehozabad. He had authority over 180, 000 soldiers who had their weapons ready to fight."
    },
    {
      "verse": "19",
      "text": "All these men served as the king's soldiers in Jerusalem. He also had soldiers that he put in Judah's other strong cities."
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "Jehoshaphat became very rich. People respected him very much. His son married Ahab's daughter, so he and Ahab became friends."
    },
    {
      "verse": "2",
      "text": "After some years, he went to visit Ahab in Samaria. Ahab killed many sheep and cows to give honour to Jehoshaphat and the people who were with him. Ahab wanted to attack Ramoth Gilead, so he asked Jehoshaphat to help him."
    },
    {
      "verse": "3",
      "text": "King Ahab of Israel said to King Jehoshaphat of Judah, ‘Will you go with me to attack Ramoth Gilead? ’ Jehoshaphat replied, ‘Yes, we should work together! Use my soldiers as if they belonged to you. My army will join with your army in the war. ’"
    },
    {
      "verse": "4",
      "text": "Then Jehoshaphat said to the king of Israel, ‘Before we go to fight, we must ask the Lord what we should do. ’"
    },
    {
      "verse": "5",
      "text": "prophets. He asked them, ‘Should we attack Ramoth Gilead, or not? ’ They answered, ‘Yes, go and attack it, because the God will give it to you, our king. ’"
    },
    {
      "verse": "6",
      "text": "But Jehoshaphat then asked, ‘Is there any other prophet of the Lord that we could ask? ’"
    },
    {
      "verse": "7",
      "text": "The king of Israel said to Jehoshaphat, ‘There is still one man. We could ask him what the Lord wants us to do. But I do not like him, because he never says that anything good will happen to me. He always says that I will have trouble. He is Imlah's son, Micaiah. ’Jehoshaphat said, ‘The king should not talk like that. ’ Jehoshaphat said, ‘The king should not talk like that. ’"
    },
    {
      "verse": "8",
      "text": "So the king of Israel said to one of his officers, ‘Bring Imlah's son Micaiah here quickly. ’"
    },
    {
      "verse": "9",
      "text": "The king of Israel and Jehoshaphat, the king of Judah, were each sitting on their thrones. They were wearing their royal clothes. They sat near the threshing floor at Samaria's city gate. All the prophets stood in front of them and they were speaking messages from God."
    },
    {
      "verse": "10",
      "text": "Kenaanah's son Zedekiah had used iron to make sharp points like a bull's horns. He said, ‘This is what the Lord says: “With these sharp horns you will attack Syria's army. You will destroy them all. ” ’"
    },
    {
      "verse": "11",
      "text": "All the other prophets were speaking the same message. They said, ‘Attack Ramoth Gilead. You will win the fight. The Lord will give the city to you, our king. ’"
    },
    {
      "verse": "12",
      "text": "The man who had gone to fetch Micaiah said to him, ‘All the other prophets are saying the same thing. They say that the king will win the fight. So you must agree with what they are saying. Promise that something good will happen. ’"
    },
    {
      "verse": "13",
      "text": "But Micaiah said, ‘I can only speak what my God tells me to say. As surely as the Lord lives, that is what I must do. ’"
    },
    {
      "verse": "14",
      "text": "When Micaiah arrived, the king asked him, ‘Micaiah, should we attack Ramoth Gilead or not? ’Micaiah answered, ‘Yes, attack it. You will surely win the fight. You will take power over the city. ’ Micaiah answered, ‘Yes, attack it. You will surely win the fight. You will take power over the city. ’"
    },
    {
      "verse": "15",
      "text": "Then King Ahab said to Micaiah, ‘I have already told you many times to tell me only what is true! You must promise to do this in the name of the Lord! ’"
    },
    {
      "verse": "16",
      "text": "Then Micaiah said, ‘I saw the whole army of Israel and they were walking about on the hills without any leader. They were like sheep with no shepherd as their guide. The Lord told me, “These people have no master. They should go home quietly and they should not fight. ” ’"
    },
    {
      "verse": "17",
      "text": "The king of Israel said to King Jehoshaphat, ‘I told you what he would say! He never says that anything good will happen to me. He only says that I will have trouble. ’"
    },
    {
      "verse": "18",
      "text": "Then Micaiah said, ‘So now listen to the Lord's message! I saw the Lord as he was sitting on his throne. The great crowd of his angels in heaven were standing around him, on his right side and on his left side."
    },
    {
      "verse": "19",
      "text": "The Lord asked, “Who will go and deceive King Ahab of Israel so that he attacks Ramoth Gilead and he dies there? ” Many of the angels suggested different things."
    },
    {
      "verse": "20",
      "text": "Then a spirit came and stood in front of the Lord. The spirit said, “I will deceive Ahab. ”The Lord asked, “How will you do it? ”"
    },
    {
      "verse": "21",
      "text": "The spirit said, “I will give a message to all Ahab's prophets. I will cause them to speak lies. ” The Lord said, “Go and deceive King Ahab, as you have said. He will do what you say. ”"
    },
    {
      "verse": "22",
      "text": "So you see what has happened. The Lord has sent a spirit to these prophets who serve you. This spirit has caused them to speak lies. The Lord has decided that terrible trouble will come on you. ’"
    },
    {
      "verse": "23",
      "text": "Then Kenaanah's son Zedekiah went to Micaiah. He hit Micaiah on his face. He asked Micaiah, ‘Do you say that the Lord's spirit has gone away from me and has spoken to you instead? How did he do that? ’"
    },
    {
      "verse": "24",
      "text": "Micaiah answered him, ‘One day, you will know which of us has spoken the truth. That will be the day that you go to hide in a room at the back of a house. ’"
    },
    {
      "verse": "25",
      "text": "Then the king of Israel said to his men, ‘Take hold of Micaiah. Take him back to Amon, the city officer, and to Joash, the king's son."
    },
    {
      "verse": "26",
      "text": "Say to them, “The king commands you to put this man in prison. Feed him with only a little bread and water until I return safely from the battle. ” ’"
    },
    {
      "verse": "27",
      "text": "Micaiah said, ‘If you do return safely, it will show that I have not spoken the Lord's message. ’ Then he said to all the people who were there, ‘Remember what I have said to King Ahab! ’"
    },
    {
      "verse": "28",
      "text": "So King Ahab of Israel and King Jehoshaphat of Judah went to attack Ramoth Gilead."
    },
    {
      "verse": "29",
      "text": "King Ahab said to Jehoshaphat, ‘When we go into the battle, I will wear ordinary clothes. People will not recognize me as the king. But you should wear your royal clothes. ’ So the king of Israel went into the battle as if he was an ordinary soldier."
    },
    {
      "verse": "30",
      "text": "But the king of Syria had said to his chariot officers, ‘Only fight the king of Israel. Do not fight against anyone else, whoever they are. ’"
    },
    {
      "verse": "31",
      "text": "The chariot officers saw King Jehoshaphat in his royal clothes. So they thought, ‘That is the king of Israel! ’ They turned towards him to attack him. Jehoshaphat shouted out and the Lord helped him. God caused the officers to turn away from him."
    },
    {
      "verse": "32",
      "text": "The chariot officers realized that he was not the king of Israel. So they did not chase him any more."
    },
    {
      "verse": "33",
      "text": "Then a Syrian soldier shot an arrow into the air. He did not try to shoot at anyone, but the arrow hit the king of Israel. The arrow went through a space in the king's armour. The king commanded the man who drove his chariot, ‘Turn the chariot around. Take me away from the battle. An arrow has hit me. ’"
    },
    {
      "verse": "34",
      "text": "The soldiers fought the battle all day. While they were fighting, King Ahab sat in his chariot where he could see the Syrian soldiers. Then, at sunset, he died."
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "King Jehoshaphat of Judah returned safely to his home in Jerusalem."
    },
    {
      "verse": "2",
      "text": "The prophet Jehu, Hanani's son, went to meet him. He said to King Jehoshaphat, ‘You agreed to help a wicked man. You became the friend of someone who hates the Lord. You should not have done that. You have caused the Lord to be very angry with you."
    },
    {
      "verse": "3",
      "text": "But you have done some good things. You have removed the Asherah poles from Judah's land. You have chosen to serve God. ’"
    },
    {
      "verse": "4",
      "text": "King Jehoshaphat lived in Jerusalem. He also travelled around the country to meet people. He went everywhere, from Beersheba to the hill country of Ephraim. He warned the people to turn back to the Lord, the God of their ancestors."
    },
    {
      "verse": "5",
      "text": "He chose men to be judges. He put them everywhere in Judah, in each strong city."
    },
    {
      "verse": "6",
      "text": "He said to them, ‘Be careful how you do your job. Remember that you are not being a judge to please men. You are doing it to please the Lord. He will help you to decide what is right."
    },
    {
      "verse": "7",
      "text": "Respect the Lord's authority. Be careful to do your job well. The Lord our God is always fair. So be fair to everyone, whoever they are. Do not cheat people. Do not accept bribes. ’"
    },
    {
      "verse": "8",
      "text": "Jehoshaphat also chose some Levites, priests and clan leaders to serve the Lord as judges in Jerusalem. They used God's law to decide who was right when people who lived in Jerusalem had arguments."
    },
    {
      "verse": "9",
      "text": "He said to them, ‘Serve the Lord faithfully and respect his authority."
    },
    {
      "verse": "10",
      "text": "You must warn the people who come from their towns and they ask you to judge an argument for them. The argument may be about a murder, or about anyone who has not obeyed God's laws, rules and commands. Whatever it is, you must warn people not to do things that the Lord says are wrong. If you do not warn them, God will be angry with you and the people of Judah. But if you do warn them, you will not be guilty of a sin."
    },
    {
      "verse": "11",
      "text": "Amariah, the most important priest, will have authority over you. He will tell you what the Lord's law says is right. But if it is an argument about the king's laws, Ishmael's son Zebadiah, the officer who rules Judah, will decide what is right. The Levites will serve as your officers. Be brave and do your work well. The Lord will help you to do what is right! ’"
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "After that, armies from Moab and Ammon, as well as some Meunites, attacked Jehoshaphat."
    },
    {
      "verse": "2",
      "text": "Some men brought this news to Jehoshaphat: ‘A large army is coming from the other side of the Dead Sea to attack you. They came from Edom and they are already in Hazezon Tamar. ’ (That is another name for En Gedi. )"
    },
    {
      "verse": "3",
      "text": "Jehoshaphat was afraid. So he decided to ask the Lord what he should do. He commanded all the people in Judah that they must fast."
    },
    {
      "verse": "4",
      "text": "Judah's people came together to ask the Lord for his help. They came from every town in Judah to pray to the Lord."
    },
    {
      "verse": "5",
      "text": "Then Jehoshaphat stood up in front of the people of Jerusalem and the other places in Judah. He was standing in front of the new yard of the Lord's temple."
    },
    {
      "verse": "6",
      "text": "He prayed, ‘Lord, you are the God of our ancestors. You are the God who is in heaven and you rule over all kingdoms and nations. You are strong and powerful. Nobody can fight against you and win."
    },
    {
      "verse": "7",
      "text": "Our God, you chased out the people who were living in this land, so that your people, the Israelites, could move in. You have given this land to the descendants of your friend Abraham. It belongs to them for ever."
    },
    {
      "verse": "8",
      "text": "Your people made their homes here and they built a temple to give honour to your name. When they built it, they said,"
    },
    {
      "verse": "9",
      "text": "“In the future, we may have trouble. There might be war, disease, famine or some other punishment. If that happens, we will come to you and we will stand in front of this temple. You have chosen this place to be your home. We will call out to you to help us when we are in trouble. Then you will hear us and you will rescue us. ”"
    },
    {
      "verse": "10",
      "text": "But now soldiers from Ammon, Moab and Edom are coming to attack us. When the Israelites were escaping from Egypt, you would not allow them to attack those lands. So our people turned away and they did not destroy those people."
    },
    {
      "verse": "11",
      "text": "But now those people want to destroy us! They are coming to chase us out of the land that you gave to us as our home."
    },
    {
      "verse": "12",
      "text": "So, our God, please punish these people! We are not strong enough to fight against this large army that is attacking us. We do not know what to do. But we are asking you to help us. ’"
    },
    {
      "verse": "13",
      "text": "As King Jehoshaphat prayed, all the men of Judah were standing there at the temple. They had their babies, their wives and their children with them."
    },
    {
      "verse": "14",
      "text": "Then the Lord's Spirit came with power to Jahaziel as he stood among the people. Jahaziel was a Levite, a descendant of Asaph. He was the son of Zechariah, who was the son of Benaiah, who was the son of Jeiel, who was the son of Mattaniah."
    },
    {
      "verse": "15",
      "text": "Jahaziel said, ‘Listen to me all you people of Judah. That includes you people who live in Jerusalem, and King Jehoshaphat too. The Lord says to you, “Do not be afraid because this large army is coming to attack you. You must be brave! This is God's battle, not your battle."
    },
    {
      "verse": "16",
      "text": "Tomorrow, you must march out of here to attack them. They will be coming up the road through the hills at Ziz. You will meet them at the end of the narrow valley that is on the east side of the Jeruel desert."
    },
    {
      "verse": "17",
      "text": "You will not have to fight in this battle. Go to your places and stand still. Then you will see the Lord rescue you. People of Judah and Jerusalem, do not be afraid. Be brave! Tomorrow you must march out of here towards the enemy army. The Lord is with you! ” ’"
    },
    {
      "verse": "18",
      "text": "Then Jehoshaphat bent down with his face towards the ground. All the people of Judah and the people who lived in Jerusalem also bent down to worship the Lord."
    },
    {
      "verse": "19",
      "text": "Then some Levites stood up. They praised the Lord, Israel's God, with loud voices. They belonged to the clans of Kohath and Korah."
    },
    {
      "verse": "20",
      "text": "Early the next morning, Jehoshaphat prepared to leave with his army. They started to march to the Tekoa desert. When they were ready to leave, Jehoshaphat stood up and he said, ‘Listen to me, people of Judah and people who live in Jerusalem! Trust in the Lord your God. Then you will be safe. Believe the message that his prophets have spoken. Then you will win the battle. ’"
    },
    {
      "verse": "21",
      "text": "Jehoshaphat spoke with the people. He chose some musicians to march in front of his army. They sang songs to worship the Lord and to praise him for his holy power. As they marched, they sang, ‘We thank the Lord! His faithful love continues for ever! ’"
    },
    {
      "verse": "22",
      "text": "As the musicians began to sing, the Lord suddenly made the soldiers of Judah's enemies confused."
    },
    {
      "verse": "23",
      "text": "The soldiers from Ammon and Moab started to attack the soldiers from Edom. They destroyed Edom's army. When they had done that, they started to fight against each other. So they all destroyed one another."
    },
    {
      "verse": "24",
      "text": "Judah's soldiers came to a tower from where they could see the desert. They looked at the large army of their enemies. But they could not see any soldier who was still alive! They only saw dead bodies that were lying on the ground."
    },
    {
      "verse": "25",
      "text": "So Jehoshaphat and his men went to take things from the dead soldiers. They found a lot of weapons, clothes and other valuable things. They took as many things as they could carry. There were so many things that it took them three days to take them all away."
    },
    {
      "verse": "26",
      "text": "On the fourth day they all met together in Berakah valley. There they praised the Lord. That is why that place is still called Berakah valley."
    },
    {
      "verse": "27",
      "text": "Then all the men of Judah and Jerusalem returned to Jerusalem. Jehoshaphat marched in front of them. They were very happy because the Lord had helped them. He had caused them to win the fight against their enemies."
    },
    {
      "verse": "28",
      "text": "As they went into Jerusalem, they made music with harps, lyres and trumpets. They went to the Lord's temple."
    },
    {
      "verse": "29",
      "text": "People in all the kingdoms around Judah heard that the Lord had fought against Israel's enemies. So they became afraid of God's power."
    },
    {
      "verse": "30",
      "text": "There was a time of peace in Jehoshaphat's kingdom. God kept them safe from the nations all around."
    },
    {
      "verse": "31",
      "text": "So Jehoshaphat continued to rule Judah as king. He was 35 years old when he became king. He ruled in Jerusalem for 25 years. His mother's name was Azubah. She was the daughter of Shilhi."
    },
    {
      "verse": "32",
      "text": "Jehoshaphat lived in the good way that his father Asa had lived. He only did things that the Lord says are right."
    },
    {
      "verse": "33",
      "text": "But he did not remove all the altars that were on the hills. The people still did not want to be completely faithful to the God of their ancestors."
    },
    {
      "verse": "34",
      "text": "The other things that happened while Jehoshaphat was king are written in a book. Hanani's son Jehu recorded all of them in his book, which is part of ‘The history of Israel's kings’."
    },
    {
      "verse": "35",
      "text": "While Jehoshaphat was king, he became a friend of King Ahaziah of Israel, who did evil things. A storm destroyed the ships and they never went anywhere."
    },
    {
      "verse": "36",
      "text": "They agreed to build big ships that would bring things from countries that were far away. They built the ships in Ezion-Geber."
    },
    {
      "verse": "37",
      "text": "Dodavahu's son Eliezer from Mareshah warned Jehoshaphat with a message from the Lord. He said, ‘You should not have become a friend of Ahaziah. Because of that, the Lord will destroy the things that you have made. ’A storm destroyed the ships and they never went anywhere."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "Jehoshaphat died and they buried him beside his ancestors in the City of David. Jehoshaphat's son Jehoram became king after him."
    },
    {
      "verse": "2",
      "text": "Jehoram had brothers who were also sons of Jehoshaphat. They were Azariah, Jehiel, Zechariah, Azariahu, Michael and Shephatiah. All these men were sons of King Jehoshaphat of Judah."
    },
    {
      "verse": "3",
      "text": "Their father had given them many gifts of silver, gold and other valuable things. He gave them authority over the strong cities of Judah. But Jehoshaphat chose Jehoram be the next king because he was his oldest son."
    },
    {
      "verse": "4",
      "text": "Jehoram made himself a strong king to rule over his father's kingdom. Then he killed all his brothers, as well as some of the Israelite leaders."
    },
    {
      "verse": "5",
      "text": "years old when he became king. He ruled in Jerusalem for eight years."
    },
    {
      "verse": "6",
      "text": "He lived in the same bad way that the kings of Israel did. He did what the family of Ahab had done. He married a daughter of King Ahab and he became as wicked as King Ahab's family was. He did things that the Lord said were evil."
    },
    {
      "verse": "7",
      "text": "But the Lord did not want to destroy all David's descendants, because of his promise to David. He had promised that King David would always have descendants who would rule the nation."
    },
    {
      "verse": "8",
      "text": "While Jehoram was king, Edom's people turned against Judah. They would no longer accept the king of Judah's authority over them. They decided to have their own king."
    },
    {
      "verse": "9",
      "text": "So King Jehoram travelled to Zair with his army officers and all his chariots. The Edomite army came and they were all around him. But that night, Jehoram and his officers attacked the Edomites and they escaped."
    },
    {
      "verse": "10",
      "text": "Even today, Edom's people do not obey the rulers of Judah. The people of Libnah city also turned against Judah at the same time. That happened because Jehoram had turned away from the Lord, the God of his ancestors."
    },
    {
      "verse": "11",
      "text": "He also built altars on the hills of Judah. He caused the people of Judah and Jerusalem to turn away from the Lord and worship false gods."
    },
    {
      "verse": "12",
      "text": "The prophet Elijah wrote a letter to Jehoram. This is what it said:‘The Lord, the God of your ancestor David says, “You have not lived in a good way as your father Jehoshaphat did and as King Asa of Judah did."
    },
    {
      "verse": "13",
      "text": "Instead, you have lived in the way that the kings of Israel live. You have caused the people of Judah and Jerusalem to turn away from the Lord and worship false gods. That is the same as King Ahab's family has done in Israel. You have also killed your own brothers, your father's sons. They were better men than you are."
    },
    {
      "verse": "14",
      "text": "So now the Lord will send terrible trouble on your people, including your children, your wives and everything that belongs to you."
    },
    {
      "verse": "15",
      "text": "You will have a bad disease. You will have terrible pain in your stomach that becomes worse and worse. Finally, your inside parts will come out of your body. ” ’"
    },
    {
      "verse": "16",
      "text": "There were some Philistines and Arabs who lived near people from Ethiopia. The Lord caused them to be angry with Jehoram."
    },
    {
      "verse": "17",
      "text": "They attacked Judah and they took power over the land. They took away all the valuable things in the king's palace. They took his sons and his wives as their prisoners. The only son of Jehoram that remained was his youngest son, Ahaziah."
    },
    {
      "verse": "18",
      "text": "After all this happened, the Lord caused Jehoram to have a bad disease in his stomach. He could not become well again."
    },
    {
      "verse": "19",
      "text": "He was very ill for two years, and then his inside parts came out because of the illness. So he had a lot of pain until he died. His people did not make a big fire to give him honour, as they had done for his ancestors."
    },
    {
      "verse": "20",
      "text": "years old when he started to rule. He ruled in Jerusalem for eight years. When he died, nobody was sad. They buried him in the City of David, but not in the place where they had buried the other kings."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "The people who lived in Jerusalem chose Jehoram's youngest son, Ahaziah, to become king. The group of men who came into the city with the Arabs had killed all Jehoram's older sons. So Jehoram's son Ahaziah became the king of Judah."
    },
    {
      "verse": "2",
      "text": "years old when he became king. He ruled in Jerusalem for one year. His mother's name was Athaliah. She was a granddaughter of Omri, king of Israel."
    },
    {
      "verse": "3",
      "text": "Ahaziah lived in the same bad way that Ahab's family had done. His mother taught him to do wicked things."
    },
    {
      "verse": "4",
      "text": "He did things that the Lord said were evil, as Ahab's family had done. Ahab's family became advisors to Ahaziah after his father died, and they caused Ahaziah's death."
    },
    {
      "verse": "5",
      "text": "They told him to join with Ahab's son, King Joram of Israel, to fight against King Hazael of Syria. They fought a battle at Ramoth Gilead. The Syrian army won the fight and they hurt King Joram."
    },
    {
      "verse": "6",
      "text": "Joram returned to Jezreel, so that his wounds could get better after the battle. While he was there, King Ahaziah of Judah went to visit him, because of his wounds."
    },
    {
      "verse": "7",
      "text": "When Ahaziah visited Joram, God used it to cause Ahaziah's death. When Ahaziah arrived, he went with Joram to meet Nimshi's son Jehu. But the Lord had chosen Jehu to kill all Ahab's family. Now there was nobody in Ahaziah's family who had the authority to rule Judah as king."
    },
    {
      "verse": "8",
      "text": "While Jehu was destroying Ahab's family, he met some of the officers of Judah who had come with Ahaziah. Jehu killed them, as well as some of Ahaziah's relatives who had travelled with him."
    },
    {
      "verse": "9",
      "text": "Then he went to look for Ahaziah. Jehu's men caught him in the city of Samaria, where he was hiding. They took him to Jehu. Then they punished him with death. They buried him properly, because they said, ‘He was the grandson of King Jehoshaphat who served the Lord faithfully. ’Now there was nobody in Ahaziah's family who had the authority to rule Judah as king."
    },
    {
      "verse": "10",
      "text": "Ahaziah's mother Athaliah heard the news that her son was dead. So she started to kill everyone in Judah's royal family."
    },
    {
      "verse": "11",
      "text": "But King Jehoram's daughter Jehosheba rescued Ahaziah's son Joash. When Athaliah's servants had come to murder the royal sons, Jehosheba took Joash away and she hid him. She put him in a bedroom in the temple with his nurse. Jehosheba was Ahaziah's sister and she was the wife of Jehoiada, the priest. So she hid Joash from Athaliah to stop her from killing him."
    },
    {
      "verse": "12",
      "text": "Joash stayed safely in a room in God's temple while Queen Athaliah ruled Judah for six years."
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "In the seventh year that Queen Athaliah ruled Judah, the priest Jehoiada decided to be brave. He made an agreement with some officers in the army. Each of these men had authority over 100 soldiers. They were: Jeroham's son Azariah, Jehohanan's son Ishmael, Obed's son Azariah, Adaiah's son Maaseiah and Zikri's son Elishaphat."
    },
    {
      "verse": "2",
      "text": "They travelled around all the land of Judah. They brought together the Levites from the different cities and the leaders of Israel's clans. They all came to Jerusalem."
    },
    {
      "verse": "3",
      "text": "They met together in God's temple to make a promise to the new king. Jehoiada said to them, ‘Here is the king's son. He must become king, as the Lord promised that David's descendants would be."
    },
    {
      "verse": "4",
      "text": "This is what you must do: The priests and Levites who come to work on the Sabbath day must make three groups. One group must be guards who watch at the doors of the temple."
    },
    {
      "verse": "5",
      "text": "Another group will watch at the king's palace. The third group will stand at the Foundation Gate. All the other men will stand in the yards around the Lord's temple."
    },
    {
      "verse": "6",
      "text": "Only the priests and the Levites who have work there on that day may go into the Lord's temple. They may go in because they have made themselves clean to serve God. All the other people must do the jobs that the Lord has given to them."
    },
    {
      "verse": "7",
      "text": "The Levites must stand around the king. Each man must hold his weapon in his hand. If anyone tries to come into the temple, you must kill them. You must stay near to the king everywhere that he goes. ’"
    },
    {
      "verse": "8",
      "text": "The Levites and all the men of Judah did what Jehoiada the priest told them to do. Each officer brought his group of men. That included the men who worked on the Sabbath and those who did not. Jehoiada the priest did not allow any of the groups of men to go home."
    },
    {
      "verse": "9",
      "text": "Then Jehoiada gave some weapons that were in God's temple to the officers. He gave them the spears and the shields that had belonged to King David."
    },
    {
      "verse": "10",
      "text": "Then he put the men in their proper places around the king. They all held their weapons in their hands. They stood in a line from the south side of the temple to the north side. They were around the altar at the front of the temple."
    },
    {
      "verse": "11",
      "text": "Jehoiada and his sons brought the king's son out of the temple room. They put the crown onto Joash's head. They gave him a copy of the royal covenant. They poured olive oil on his head to show that he was now the king. They shouted, ‘May the king have a long life! ’"
    },
    {
      "verse": "12",
      "text": "Queen Athaliah heard the soldiers and the people as they shouted and praised the new king. So she went to the Lord's temple where all the people were. When Athaliah saw this, she was very upset. She tore her clothes. She shouted, ‘Treason! Treason! ’"
    },
    {
      "verse": "13",
      "text": "Then she saw the king! He was standing in the king's place beside the pillar at the entrance of the temple. The army officers and the men with trumpets were standing beside the king. All the people of Judah were shouting with joy. There were musicians making music with trumpets and other musical instruments. They helped the people to sing and to praise God. When Athaliah saw this, she was very upset. She tore her clothes. She shouted, ‘Treason! Treason! ’"
    },
    {
      "verse": "14",
      "text": "soldiers. He told them, ‘Bring her out of the temple to the line of guards outside. Use your swords to kill anyone who follows her. ’ That was because Jehoiada had said, ‘You must not kill her inside the Lord's temple. ’"
    },
    {
      "verse": "15",
      "text": "So they took hold of Athaliah. They took her through the gate for the king's horses into the yard of the palace. They killed her there."
    },
    {
      "verse": "16",
      "text": "Jehoiada prepared a covenant with the Lord. He, all the people and the king agreed to serve the Lord as his people."
    },
    {
      "verse": "17",
      "text": "All the people went to the temple of Baal. They destroyed it. They completely knocked down its altars and idols. They killed Baal's priest, Mattan, in front of Baal's altars."
    },
    {
      "verse": "18",
      "text": "Then Jehoiada gave jobs to the priests and the Levites to do in the Lord's temple. That was the work that King David had told them to do in the temple. They had to offer burnt offerings as sacrifices to the Lord, and they had to praise him with happy songs. They did the things that Moses had written in God's law and that David had taught."
    },
    {
      "verse": "19",
      "text": "Jehoiada put guards at the gates of the Lord's temple. They would stop anyone who was unclean from going in."
    },
    {
      "verse": "20",
      "text": "Jehoiada called together the officers of army groups, the important men, the government officers and all the other people. Jehoiada led them all to bring the king down from the Lord's temple into the palace. They went into the palace through the Higher Gate. They put Joash on the royal throne as king."
    },
    {
      "verse": "21",
      "text": "All the people were very happy. There was no longer any trouble in Jerusalem now that they had killed Athaliah as her punishment."
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "Joash was seven years old when he became the king of Judah. He ruled in Jerusalem for 40 years. His mother was Zibiah, who came from Beersheba."
    },
    {
      "verse": "2",
      "text": "Joash did things that pleased the Lord. He continued to do that all the time that Jehoiada the priest was alive."
    },
    {
      "verse": "3",
      "text": "Jehoiada chose two women for Joash to marry. She gave birth to sons and daughters for him."
    },
    {
      "verse": "4",
      "text": "After some time, Joash decided to repair the Lord's temple. But the Levites did not do it immediately."
    },
    {
      "verse": "5",
      "text": "He brought together the priests and the Levites. He told them, ‘Go around to all the towns in Judah. Bring here all the money that Israel's people offer each year for the temple. We will use it to repair the temple of your God. Go quickly and do it now! ’But the Levites did not do it immediately."
    },
    {
      "verse": "6",
      "text": "So the king told Jehoiada, the leader of the priests, to come to him. He said to him, ‘You have not told the Levites to bring the money that the people of Judah and Jerusalem have given. Why have you not done that? The Lord's servant Moses and all Israel's people made the rule that people should give the money each year. It would be a tax to help with the tent of God's covenant. ’"
    },
    {
      "verse": "7",
      "text": "The sons of wicked Queen Athaliah had broken the door of God's temple. They had gone in there and they had taken the holy things. They had used them to worship the idols of Baal. That is why Joash wanted to repair the Lord's temple."
    },
    {
      "verse": "8",
      "text": "The king told the Levites to make a big box. They put it outside the gate of the Lord's temple."
    },
    {
      "verse": "9",
      "text": "Then he sent a command to everyone in Jerusalem and in the rest of Judah. He told them to bring the money to pay their tax to the Lord. That was the tax that God's servant Moses had told the Israelites that they should pay when they were in the wilderness."
    },
    {
      "verse": "10",
      "text": "All the officers and all the people were happy to give this money. They brought it to Jerusalem and they threw it into the box, until the box was full."
    },
    {
      "verse": "11",
      "text": "Every time that the box became full of money, the Levites took it to the king's officers. Then the king's secretary and the officer who served the leader of the priests took the money out of the box. Then they put the box outside the temple gate again. They did that every day, so that they had a lot of money."
    },
    {
      "verse": "12",
      "text": "The king and Jehoiada gave the money to the men who would take care of the work on the Lord's temple. They paid men who could work with stone and wood to repair the temple. They also paid men who knew how to work with iron and bronze for this work."
    },
    {
      "verse": "13",
      "text": "These workers worked well so that they soon finished the work. They built the temple to be very strong, in the way that it should be."
    },
    {
      "verse": "14",
      "text": "When they had finished, there was some money that remained. So the workers took the money to the king and to Jehoiada. They decided to make tools to use in the temple. There were things that the priests used to serve the Lord in the temple, and to offer burnt offerings. They used gold and silver to make dishes and other things. While Jehoiada was still alive, the priests always made burnt offerings as sacrifices to the Lord in his temple."
    },
    {
      "verse": "15",
      "text": "years old."
    },
    {
      "verse": "16",
      "text": "They buried him beside the kings in the City of David. They gave him that honour, because he had done many good things in Israel for God and for the temple."
    },
    {
      "verse": "17",
      "text": "After Jehoiada died, the important officers of Judah came to the king. They bent down low in front of him to give him honour. The king listened to their advice."
    },
    {
      "verse": "18",
      "text": "They stopped worshipping the Lord, the God of their ancestors, in his temple. Instead, they worshipped Asherah poles and idols. So God became very angry with the people of Judah and Jerusalem, because they were guilty of these sins."
    },
    {
      "verse": "19",
      "text": "The Lord sent his prophets to tell the people to turn back to him. They warned the people, but the people would not listen to them."
    },
    {
      "verse": "20",
      "text": "Then God's Spirit came to Jehoiada's son Zechariah with power. Zechariah stood in front of the people and he said, ‘This is what God says: “You are not obeying the Lord's commands. So nothing will go well for you. You have turned away from the Lord, so now he has turned away from you! ” ’"
    },
    {
      "verse": "21",
      "text": "The people decided to punish Zechariah. The king gave a command to punish him with death. So they threw stones at him to kill him in the yard of the Lord's temple."
    },
    {
      "verse": "22",
      "text": "King Joash forgot that Zechariah's father Jehoiada had been a faithful servant. He killed Jehoiada's son. Zechariah said, as he was dying, ‘I pray that the Lord sees what you have done! May he punish you because of it! ’"
    },
    {
      "verse": "23",
      "text": "At the end of that year, Syria's army attacked Judah and Jerusalem, where Joash lived. They killed all the leaders of Judah's people. They took many valuable things to send to their king in Damascus."
    },
    {
      "verse": "24",
      "text": "Syria's army was very small but the Lord gave them power over Judah's large army. He did that because Judah's people had turned away from the Lord, the God of their ancestors. Syria's army punished Joash as he deserved."
    },
    {
      "verse": "27",
      "text": "The things that happened while Joash was king are written in a book. The book is called ‘The history of the kings’. It includes a list of Joash's sons, and the many messages that prophets spoke about him. It also includes a report of the work which he did on God's temple. Joash's son Amaziah became king after him."
    },
    {
      "verse": "25",
      "text": "Joash had received bad wounds in the battle. When Syria's army went away, Joash's officers decided to kill him. They were angry because he had killed Zechariah, the son of Jehoiada the priest. So they murdered him in his bed. The two officers who did this were Zabad and Jehozabad. Zabad's mother was Shimeath, who came from Ammon."
    },
    {
      "verse": "26",
      "text": "Jehozabad's mother was Shimrith, who came from Moab. Joash's people buried him in the City of David. But they did not bury him beside the graves of the other kings. Joash's people buried him in the City of David. But they did not bury him beside the graves of the other kings."
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "years old when he began to rule as king. He ruled in Jerusalem for 29 years. His mother's name was Jehoaddin. She was from Jerusalem."
    },
    {
      "verse": "2",
      "text": "He did things that the Lord said were good. But he was not completely faithful."
    },
    {
      "verse": "3",
      "text": "Amaziah made himself strong to rule his kingdom with authority. Then he killed the officers who had murdered his father, King Joash."
    },
    {
      "verse": "4",
      "text": "But he did not punish their sons with death. He obeyed the Lord's command that was written in the Book of the Law of Moses. The command says, ‘Do not punish fathers with death when their sons do bad things. Do not punish children with death when their fathers do bad things. Each person must die only because of his own sins. ’"
    },
    {
      "verse": "5",
      "text": "Then Amaziah brought all the people of Judah together. For each of their clans he chose officers to lead groups of 1, 000 men and groups of 100 men. He did that for the clans of Judah's tribe and the clans of Benjamin's tribe. He counted all the men who were 20 years old or older who could fight with spears and shields. There were 300, 000 of them."
    },
    {
      "verse": "6",
      "text": "He also paid 3, 500 kilograms of silver for 100, 000 soldiers from Israel to join his army."
    },
    {
      "verse": "7",
      "text": "But a prophet went to meet Amaziah and he said, ‘Please sir, do not take these soldiers from Israel to go and fight beside your own soldiers. The Lord has turned away from the tribe of Ephraim and all of Israel."
    },
    {
      "verse": "8",
      "text": "The Lord will allow your enemies to win against you, even if you fight very well. God has the power to help you, but he can also cause your enemies to win against you. ’"
    },
    {
      "verse": "9",
      "text": "Amaziah said to God's prophet, ‘But I have paid 3, 500 kilograms of silver for these soldiers from Israel. What should I do about that? ’ The prophet replied, ‘The Lord is able to give you much more than all that money! ’"
    },
    {
      "verse": "10",
      "text": "So Amaziah sent away the soldiers who had come from Ephraim. He told them to go back to their homes. So they became very angry with Judah's people. As they went home, they had angry thoughts."
    },
    {
      "verse": "11",
      "text": "But Amaziah was brave. He led his army to Salt Valley. There they killed 10, 000 soldiers from Edom."
    },
    {
      "verse": "12",
      "text": "They also caught 10, 000 soldiers as their prisoners. They took them to the top of a high rock. They threw their prisoners from the top. They all fell down onto the rocks below and they died."
    },
    {
      "verse": "13",
      "text": "But the soldiers from Israel that Amaziah had sent home attacked some towns in Judah. They were angry because Amaziah had not allowed them to join his army in the battle. They killed 3, 000 men in Judah's towns between Samaria and Beth Horon. They took away many valuable things from those towns."
    },
    {
      "verse": "14",
      "text": "After Amaziah's army had killed the soldiers from Edom, he returned to Judah. He brought back some idols of the gods that the people of Edom worshipped. He started to worship them as his own gods. He offered sacrifices to them."
    },
    {
      "verse": "15",
      "text": "So the Lord became angry with Amaziah. He sent a prophet to him with a message. The prophet said to Amaziah, ‘You should not worship these foreign gods! They could not even save their own people from your power! ’"
    },
    {
      "verse": "16",
      "text": "While the prophet was still speaking, the king said to him, ‘We did not choose you to be the king's advisor! If you do not stop speaking, my men will kill you. ’ So the prophet stopped. But then he said, ‘I know what God has decided to do. He will destroy you because you have done these bad things and you have not listened to my advice. ’"
    },
    {
      "verse": "17",
      "text": "Then King Amaziah of Judah met with his advisors. Then he sent a message to King Jehoash of Israel. He was the son of Jehoahaz and the grandson of Jehu. King Amaziah's message said, ‘Come here and meet me! ’"
    },
    {
      "verse": "18",
      "text": "But King Jehoash of Israel sent this message back to King Amaziah of Judah: ‘In Lebanon, a thorn bush sent this message to a cedar tree: “Please give your daughter to my son, to be his wife. ” Then a wild animal of Lebanon came and knocked down the thorn bush. It walked all over it!"
    },
    {
      "verse": "19",
      "text": "You are proud that you have won the fight against Edom. But do not boast about your power! You may be very happy, but stay at home! Do not try to fight against us. If you do that, you will cause trouble that destroys both you and your kingdom, Judah. ’"
    },
    {
      "verse": "20",
      "text": "But Amaziah did not accept Jehoash's message. God had decided to put him under the power of his enemies because he worshipped the gods of Edom."
    },
    {
      "verse": "21",
      "text": "So King Jehoash of Israel prepared to attack Amaziah's army. Jehoash and Amaziah met together in battle at Beth Shemesh, a town in Judah."
    },
    {
      "verse": "22",
      "text": "Israel's army won the battle against Judah's army. All the soldiers from Judah ran back home."
    },
    {
      "verse": "23",
      "text": "At Beth Shemesh, King Jehoash of Israel caught the king of Judah, Amaziah, the son of Joash and the grandson of Ahaziah. King Jehoash took him to Jerusalem. He destroyed the wall of Jerusalem, between the Ephraim Gate and the Corner Gate. That part of the wall was 180 metres long."
    },
    {
      "verse": "24",
      "text": "He took away all the gold and the silver from the temple, including the valuable things that Obed-Edom was taking care of. Jehoash also took the valuable things from the king's palace. He also took some of the people away with him as prisoners. Then he returned to Samaria."
    },
    {
      "verse": "25",
      "text": "Joash's son Amaziah, the king of Judah, lived for 15 years after Jehoahaz's son Jehoash, the king of Israel, died."
    },
    {
      "verse": "26",
      "text": "All the other things that happened while Amaziah was king are written in a book. The book is called ‘The history of the kings of Judah and Israel’."
    },
    {
      "verse": "27",
      "text": "After Amaziah had turned away from the Lord, some people in Jerusalem made a plan to kill him. So he ran away to Lachish. But the people in Jerusalem sent men to catch him in Lachish. They killed Amaziah there."
    },
    {
      "verse": "28",
      "text": "They carried his dead body back to Jerusalem on a horse. They buried him there beside his ancestors in the city of Judah."
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "All the people of Judah chose Uzziah to be their king instead of his father, King Amaziah. Uzziah was 16 years old."
    },
    {
      "verse": "2",
      "text": "He built Elath again after King Amaziah had died. He made it a part of Judah again."
    },
    {
      "verse": "3",
      "text": "years old when he became king. And he ruled in Jerusalem for 52 years. His mother's name was Jecoliah. She came from Jerusalem."
    },
    {
      "verse": "4",
      "text": "Uzziah did things that the Lord said were good, as his father Amaziah had done."
    },
    {
      "verse": "5",
      "text": "He served God faithfully all the time that Zechariah was alive. Zechariah taught him to respect and obey God. As long as Uzziah served the Lord faithfully, God gave him success."
    },
    {
      "verse": "6",
      "text": "Uzziah took his army to attack the Philistines. He destroyed the walls of their cities, Gath, Jabneh and Ashdod. Then he made the towns near Ashdod strong, as well as other towns where the Philistines lived."
    },
    {
      "verse": "7",
      "text": "God helped him to win battles against the Philistines, against the Arabs who lived in Gur-Baal, and against the Meunites."
    },
    {
      "verse": "8",
      "text": "The people from Ammon paid taxes to Uzziah. He became very powerful. So everyone as far as the border of Egypt knew that he was a great king."
    },
    {
      "verse": "9",
      "text": "Uzziah built strong towers on Jerusalem's walls to make the city safe. He built them at the Corner Gate, at the Valley Gate and at the place where the wall turned."
    },
    {
      "verse": "10",
      "text": "He also built towers in the desert. He dug holes in the ground to contain water. He needed water for his animals on the low hills and in the valleys, because he had many of them. He also enjoyed growing crops. He had men who worked in the fields and in the vineyards. These were on the hills and in places where crops would grow well."
    },
    {
      "verse": "11",
      "text": "Uzziah had an army of soldiers who were ready to fight battles. The king's secretary, Jeiel, and his officer, Maaseiah, put the soldiers into groups. They counted the soldiers in each group. Hananiah was the army captain who had authority over them."
    },
    {
      "verse": "12",
      "text": "There were 2, 600 family leaders who led the groups of soldiers."
    },
    {
      "verse": "13",
      "text": "Together they led 307, 500 soldiers who knew how to fight well. They were a powerful army that could keep the king safe against his enemies."
    },
    {
      "verse": "14",
      "text": "Uzziah gave shields, spears, helmets and armour to the whole army. He also gave them bows and arrows, and stones to put in their slings."
    },
    {
      "verse": "15",
      "text": "Men in Jerusalem who had special skills built machines that could shoot arrows and big stones. Uzziah put them on the towers and at the corners of the walls around Jerusalem. God helped him in many ways, so that he became very famous and powerful."
    },
    {
      "verse": "16",
      "text": "Uzziah was so powerful that he became proud. That caused him to lose his power. He began to turn away from the Lord his God. He went into the Lord's temple to burn incense on the special altar there."
    },
    {
      "verse": "17",
      "text": "other brave priests of the Lord went into the temple after him."
    },
    {
      "verse": "18",
      "text": "They warned King Uzziah. They said to him, ‘It is not right for you, Uzziah, to offer incense to the Lord. Only the priests, Aaron's descendants, may do that. They are the people that God has chosen to offer incense to him. So you must leave this Holy Place because you have done something that is wrong. As a result, the Lord God will not give you any honour. ’"
    },
    {
      "verse": "19",
      "text": "Then Uzziah became angry. In his hand, he was holding a pot with hot coals and incense in it. He was standing in the Lord's temple, near the special altar for incense. The priests were there with him. When he started to shout at the priests, a bad disease suddenly appeared on the skin of his face."
    },
    {
      "verse": "20",
      "text": "Azariah, the leader of the priests, and all the other priests turned towards Uzziah. They saw the terrible disease on the skin at the front of his head. So they quickly took him out of the temple. Uzziah himself was also in a hurry to leave, because the Lord had punished him with this disease."
    },
    {
      "verse": "21",
      "text": "King Uzziah had the terrible disease on his skin until the day that he died. He lived in his own house, away from other people. He could not go into the Lord's temple because of his disease. His son Jotham had authority in the palace and he ruled the people of Judah."
    },
    {
      "verse": "22",
      "text": "All the other things that happened while Uzziah was king are written in a book. The prophet Isaiah, Amoz's son, wrote down those things. His son Jotham became king after him."
    },
    {
      "verse": "23",
      "text": "Uzziah died and they buried him near his ancestors. Because he had the terrible disease on his skin, they did not bury him beside the other kings that had died. Instead they buried him in a field for graves that belonged to the kings of Judah. His son Jotham became king after him."
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "years old when he became king. He ruled Judah as king in Jerusalem for 16 years. His mother's name was Jerusha. She was Zadok's daughter."
    },
    {
      "verse": "2",
      "text": "Jotham did things that the Lord said were good, as his father Uzziah had done. But he did not try to go into the Lord's temple and offer incense, as his father had done. But the people continued to do bad things."
    },
    {
      "verse": "3",
      "text": "Jotham built the Higher Gate of the Lord's temple. He also did a lot of work to repair the city wall near Ophel hill."
    },
    {
      "verse": "4",
      "text": "He built towns in the hill country of Judah. He also built strong buildings and towers in the forests."
    },
    {
      "verse": "5",
      "text": "Jotham took his army to attack the king of Ammon. He won the battle against them. That year, the Ammonites gave to him 3, 400 kilograms of silver. They also gave him 2, 200 kilolitres of wheat and 2, 200 kilolitres of barley. The Ammonites paid Jotham the same amount for each of the next two years."
    },
    {
      "verse": "6",
      "text": "Jotham became a powerful king because he faithfully obeyed the Lord his God."
    },
    {
      "verse": "7",
      "text": "The other things that happened while Jotham was king are written in a book. The book is called ‘The history of the kings of Israel and Judah’. It tells about the wars that Jotham fought and the other things that he did. His son Ahaz became king after him."
    },
    {
      "verse": "8",
      "text": "years old when he became king. He ruled Judah as king in Jerusalem for 16 years."
    },
    {
      "verse": "9",
      "text": "Jotham died and his people buried him in the City of David. His son Ahaz became king after him."
    }
  ],
  "28": [
    {
      "verse": "1",
      "text": "years old when he became king. He ruled Judah as king in Jerusalem for 16 years. He did not do the things that the Lord said were good. So he was not like his ancestor, King David."
    },
    {
      "verse": "2",
      "text": "He lived in the same bad way that the kings of Israel did. He also used metal to make images of the god Baal."
    },
    {
      "verse": "3",
      "text": "He offered sacrifices in Ben-Hinnom Valley. He even caused his sons to walk through fire. In this way he copied the terrible sins of the other nations in Canaan. Those were the nations that the Lord had chased out so that the Israelites could live there."
    },
    {
      "verse": "4",
      "text": "Ahaz offered sacrifices and he burned incense on altars on the hills, as well as under all the big trees."
    },
    {
      "verse": "5",
      "text": "Because of this, the Lord his God put Ahaz under the power of the king of Syria. Syria's army won a battle against Ahaz's men. The king of Syria took many of Ahaz's people to Damascus as his prisoners. The Lord also allowed the king of Israel to attack Ahaz. Israel's soldiers completely won the battle against Ahaz."
    },
    {
      "verse": "6",
      "text": "In one day, King Pekah of Israel, Remaliah's son, killed 120, 000 of Judah's best soldiers. God punished the people of Judah because they had turned away from the Lord, the God of their ancestors."
    },
    {
      "verse": "7",
      "text": "Zikri, a brave soldier from Ephraim's tribe, killed Maaseiah, King Ahaz's son. He also killed Azrikam, the officer with authority over the king's palace, and Elkanah, the king's most important officer."
    },
    {
      "verse": "8",
      "text": "The Israelites took hold of 200, 000 wives, sons and daughters of Judah's soldiers. They took them as their prisoners, even though they were their relatives. They also carried away to Samaria a lot of valuable things."
    },
    {
      "verse": "9",
      "text": "Oded, a prophet of the Lord, lived there. He went to meet Israel's soldiers when they arrived back in Samaria. He said to them, ‘The Lord, the God of your ancestors, was angry with Judah's people. So he let you have power over them to punish them. But you have killed them in a very cruel way. God in heaven has seen what you have done."
    },
    {
      "verse": "10",
      "text": "Now you want to use the men and women from Judah and Jerusalem as your slaves. So you yourselves are guilty of sins against the Lord your God."
    },
    {
      "verse": "11",
      "text": "Now listen to me! The Lord is very angry with you. So you must send back the prisoners that you have brought here from Judah. Remember that they are your relatives. ’"
    },
    {
      "verse": "12",
      "text": "Then some family leaders of Ephraim warned the soldiers who were returning from the battle against Judah. The leaders' names were: Jehohanan's son Azariah, Meshillemoth's son Berekiah, Shallum's son Jehizkiah and Hadlai's son Amasa."
    },
    {
      "verse": "13",
      "text": "They said to the soldiers, ‘You must not bring your prisoners here! If you do, we will be guilty of even more sins against the Lord. The Lord is already angry with us people of Israel because we are guilty. Do not make it worse. ’"
    },
    {
      "verse": "14",
      "text": "So the soldiers let their prisoners go free. They gave the people and the things that they had brought from Judah to the leaders and the other people."
    },
    {
      "verse": "15",
      "text": "The leaders found clothes for each of the prisoners who had no clothes. They gave the prisoners clothes, shoes, food and drink, as well as oil to put on their skin. They took all these things from the things that the soldiers had brought from Judah. They put the prisoners who were too weak to walk on donkeys. Then they took them back to their relatives in Jericho, the city with many palm trees. After that, the Israelite leaders returned to Samaria."
    },
    {
      "verse": "16",
      "text": "At that time, King Ahaz asked the king of Assyria for help."
    },
    {
      "verse": "17",
      "text": "Soldiers from Edom had attacked Judah again. They had taken people away as their prisoners."
    },
    {
      "verse": "18",
      "text": "Philistine soldiers had also attacked towns in the low hills in the west of Judah and in the Negev in the south. They took these towns for themselves and they lived in them: Beth-Shemesh, Aijalon, Gederoth; Soco, Timnah and Gimzo with the villages around them."
    },
    {
      "verse": "19",
      "text": "The Lord caused a lot of trouble for Judah's people because of their king, Ahaz. He turned away from the Lord and he allowed his people to do wicked things."
    },
    {
      "verse": "20",
      "text": "King Tiglath-Pileser of Assyria came to Ahaz. But he did not help Ahaz. Instead, he caused trouble."
    },
    {
      "verse": "21",
      "text": "Ahaz took valuable things from the Lord's temple, from the king's palace and from his officers. He gave those things to the king of Assyria. But the king of Assyria still did not help him."
    },
    {
      "verse": "22",
      "text": "During this time of trouble, King Ahaz did even more bad things against the Lord."
    },
    {
      "verse": "23",
      "text": "He offered sacrifices to the gods of Damascus. He thought that those gods had helped the kings of Syria to win the wars against him. He thought, ‘If I offer sacrifices to them, perhaps they will help me too. ’ But that sin caused a lot of trouble for King Ahaz and for his nation."
    },
    {
      "verse": "24",
      "text": "Ahaz took away all the things that were in God's temple. He broke them into pieces. He shut the doors of the temple so that nobody could go in. He built altars for himself at the corner of every street in Jerusalem."
    },
    {
      "verse": "25",
      "text": "He built altars in every town in Judah to offer sacrifices to other gods. In that way he made the Lord, the God of his ancestors, very angry."
    },
    {
      "verse": "26",
      "text": "All the other things that happened while Ahaz was king are written in a book. The book is called ‘The history of the kings of Judah and Israel’. It tells about all the things that Ahaz did. His son Hezekiah became king after him."
    },
    {
      "verse": "27",
      "text": "Ahaz died and his people buried him in the City of David. But they did not bury him near the graves of Israel's kings. His son Hezekiah became king after him."
    }
  ],
  "29": [
    {
      "verse": "1",
      "text": "years old when he became king. He ruled Judah as king in Jerusalem for 29 years. His mother's name was Abijah. She was the daughter of Zechariah."
    },
    {
      "verse": "2",
      "text": "Hezekiah did things that the Lord said were good, as his ancestor King David had done."
    },
    {
      "verse": "3",
      "text": "In the first month of the year that Hezekiah became king, he opened the doors of the Lord's temple. He repaired the doors."
    },
    {
      "verse": "4",
      "text": "He brought together the priests and the Levites in the yard at the east side of the temple."
    },
    {
      "verse": "5",
      "text": "He said to them, ‘Listen to me, you Levites. Make yourselves clean to serve the Lord. Then you can make the temple a holy place again. It is the temple of the Lord, the God of your ancestors. Take out of that holy place anything that is unclean."
    },
    {
      "verse": "6",
      "text": "Our ancestors did not serve the Lord faithfully. They did things that the Lord our God saw were evil. They turned away from him. They stopped worshipping him in his temple, where he lives. They completely turned against him."
    },
    {
      "verse": "7",
      "text": "They shut the doors at the entrance of the temple. They stopped burning oil in the lamps. They did not offer to Israel's God any incense or burnt offerings in his holy place."
    },
    {
      "verse": "8",
      "text": "So the Lord became angry with Judah and Jerusalem. He made them disgusting places which other people insult. You can see this with your own eyes."
    },
    {
      "verse": "9",
      "text": "You know that cruel enemies killed our fathers. They took away our sons, our daughters and our wives as their prisoners. That was God's punishment."
    },
    {
      "verse": "10",
      "text": "Now I want to make a covenant with the Lord, Israel's God. Then he will stop being angry with us."
    },
    {
      "verse": "11",
      "text": "My sons, the Lord has chosen you to serve him in his temple and to offer sacrifices. So do your work well. ’"
    },
    {
      "verse": "12",
      "text": "Then these Levites started to work in the temple: From Kohath's clan: Amasai's son Mahath and Azariah's son Joel. From Merari's clan: Abdi's son Kish and Jehallelel's son Azariah. From Gershon's clan: Zimmah's son Joah and Joah's son Eden."
    },
    {
      "verse": "13",
      "text": "From Elizaphan's clan: Shimri and Jeiel. From Asaph's clan: Zechariah and Mattaniah."
    },
    {
      "verse": "14",
      "text": "From Heman's clan: Jehiel and Shimei. From Jeduthun's clan: Shemaiah and Uzziel."
    },
    {
      "verse": "15",
      "text": "Those men brought all the Levites together. They all made themselves clean to serve the Lord. Then they went into the temple to make it a holy place again, as the king had commanded them. They obeyed the Lord's command."
    },
    {
      "verse": "16",
      "text": "Then the priests went into the inside room of the Lord's temple to make it holy. They found some things in the temple that were unclean. They carried all those things out to the temple yard. Then the Levites took the unclean things out of the city to the Kidron Valley."
    },
    {
      "verse": "17",
      "text": "They began this work on the first day of the first month. On the 8th day of the month they reached the entrance room of the temple. They worked to make the temple a holy place for eight more days. On the 16th day of the first month they had finished the work."
    },
    {
      "verse": "18",
      "text": "Then they went to King Hezekiah and they said, ‘We have made the whole temple clean and holy. That includes the altar for burnt offerings and all its tools. It also includes the table for the special bread and all its tools."
    },
    {
      "verse": "19",
      "text": "When Ahaz was king, he removed many things from the temple when he turned away from the Lord. We have made all those things clean again. We have put them in front of the Lord's altar so that the priests can use them again. ’"
    },
    {
      "verse": "20",
      "text": "King Hezekiah got up early the next morning. He brought the city's officers together. They all went up to the Lord's temple."
    },
    {
      "verse": "21",
      "text": "They took with them seven bulls, seven male sheep, seven lambs and seven male goats. They offered these animals as a sin offering for the kingdom, for the holy place and for the people of Judah. The king told the priests, Aaron's descendants, to offer sacrifices on the Lord's altar."
    },
    {
      "verse": "22",
      "text": "So they killed the bulls. The priests took the blood and they splashed it on the altar. Then they killed the male sheep. The priests splashed their blood on the altar too. Then they killed the lambs. The priests also splashed their blood on the altar."
    },
    {
      "verse": "23",
      "text": "Finally, the priests brought the male goats in front of King Hezekiah and the people who were there. The king and the people put their hands on the goats."
    },
    {
      "verse": "24",
      "text": "Then the priests killed the goats as a sin offering. They offered their blood on the altar as a sacrifice. Then all the people of Israel would no longer be guilty for their sins. This was because the king had said that the burnt offerings and the sin offerings would be for all Israel."
    },
    {
      "verse": "25",
      "text": "The king told the Levites to stand in the Lord's temple with their cymbals, harps and lyres to make music. They stood at the places where King David, David's prophet Gad and the prophet Nathan had told the Levites to stand. This was the Lord's command that he had given to his prophets."
    },
    {
      "verse": "26",
      "text": "The Levites held the musical instruments that King David had provided. The priests held their trumpets."
    },
    {
      "verse": "27",
      "text": "Then Hezekiah told the priests to offer the burnt offering on the altar. When they began to offer the sacrifice, the singers started to sing to praise the Lord. The trumpets and the musical instruments of King David of Israel also started to make music."
    },
    {
      "verse": "28",
      "text": "All the people there were worshipping the Lord. At the same time the singers were singing and the priests were making music with their trumpets. They all continued to do that until the priests finished making the burnt offering."
    },
    {
      "verse": "29",
      "text": "When the priests finished offering the sacrifices, the king and everyone with him bent down low to worship God."
    },
    {
      "verse": "30",
      "text": "King Hezekiah and his officers told the Levites to sing songs to praise the Lord. They told them to sing the songs that King David and the prophet Asaph had written. So the Levites praised God in that way. They were very happy and they bent down low to worship God."
    },
    {
      "verse": "31",
      "text": "Then Hezekiah said, ‘Now you have made yourselves clean to serve the Lord. So come to the Lord's temple and bring sacrifices and offerings to thank the Lord. ’ So all the people brought their sacrifices and their offerings to thank the Lord. Everyone who wanted to offer burnt offerings brought animals for that too."
    },
    {
      "verse": "32",
      "text": "For their burnt offerings, the people brought 70 bulls, 100 male sheep and 200 lambs to offer to the Lord."
    },
    {
      "verse": "33",
      "text": "bulls and 3, 000 sheep to offer to the Lord."
    },
    {
      "verse": "34",
      "text": "But there were not enough priests to prepare all the animals for the sacrifices. So their relatives, the Levites, helped them until they had finished the work. By that time more priests had made themselves clean to serve the Lord. (The Levites had been more careful than the priests to make themselves clean for the Lord. )"
    },
    {
      "verse": "35",
      "text": "The people brought a lot of animals for burnt offerings. There was also the fat from the friendship offerings. And there were drink offerings too. The priests offered all those with the burnt offerings. That is how they started to worship the Lord again in his temple."
    },
    {
      "verse": "36",
      "text": "Hezekiah and all the people were happy because God had helped them. They had been able to do the work on the temple very quickly."
    }
  ],
  "30": [
    {
      "verse": "1",
      "text": "Hezekiah sent a message to all the people of Israel and Judah. He also wrote letters to the tribes of Ephraim and Manasseh. He told them to come to the Lord's temple in Jerusalem. They must come to worship the Lord, Israel's God, at the Passover festival."
    },
    {
      "verse": "2",
      "text": "The king, his officers and all the people who lived in Jerusalem decided to have the Passover festival in the second month."
    },
    {
      "verse": "3",
      "text": "Not enough priests had made themselves clean to serve the Lord. So they could not have the feast at the usual time. Also, all the people had not yet come to Jerusalem."
    },
    {
      "verse": "4",
      "text": "This idea seemed right to the king and to all the people."
    },
    {
      "verse": "5",
      "text": "So they sent a message with the king's command to all the people. They sent the message everywhere in Israel, from Beersheba to Dan. The message told the people to come to Jerusalem for the Passover festival to worship the Lord, Israel's God. Before that, they had not brought all the people together for the festival, as God's law taught them to do."
    },
    {
      "verse": "6",
      "text": "So men took the letters from the king and his officers to all the people in Israel and Judah. The king's command said this:‘A message to the people of Israel who have escaped from the power of the kings of Assyria. Turn back now to the Lord, the God of Abraham, Isaac and Israel. Then he will turn back to you."
    },
    {
      "verse": "7",
      "text": "Do not be like your parents and your relatives. They turned away from the Lord, the God of their ancestors. That made him so angry that he punished them, as you can see."
    },
    {
      "verse": "8",
      "text": "Do not refuse to obey him, as your parents did. Instead, agree to serve him. Come to his temple. He has made it a holy place for ever. Serve the Lord your God so that he will stop being so angry with you."
    },
    {
      "verse": "9",
      "text": "If you turn back to serve the Lord again, your enemies will be kind to your relatives and to your children. They will let them return here to their homes. The Lord your God is kind and he is ready to forgive you. So if you turn back to him, he will not send you away. ’"
    },
    {
      "verse": "10",
      "text": "The men took this message to every town among the tribes of Ephraim and Manasseh, and as far as the tribe of Zebulun. But in all those places, people insulted them and they laughed at them."
    },
    {
      "verse": "11",
      "text": "But some people from Asher, Manasseh and Zebulun were not too proud to accept the king's message. They agreed to come to Jerusalem."
    },
    {
      "verse": "12",
      "text": "As for the people of Judah, God caused them to accept the command that the king and his officers had given. They all agreed together to do what the Lord wanted them to do."
    },
    {
      "verse": "13",
      "text": "In the second month of the year, a very large crowd of people came together in Jerusalem. They came there for the Festival of Flat Bread."
    },
    {
      "verse": "14",
      "text": "They removed the altars for false gods that were in Jerusalem. They also removed all the altars where people burned incense. They threw them into the Kidron Valley."
    },
    {
      "verse": "15",
      "text": "On the 14th day of the second month, they killed the lamb for the Passover feast. The priests and the Levites who were not yet clean became ashamed. So they made themselves clean to serve the Lord. Then they could bring burnt offerings to the Lord's temple."
    },
    {
      "verse": "16",
      "text": "They stood in their proper places. God's servant Moses had written in God's law where they should stand. The Levites gave the blood from the sacrifices to the priests. The priests then splashed the blood on the altar."
    },
    {
      "verse": "17",
      "text": "Many of the people had not made themselves properly clean. So they could not kill their lambs for the Passover and offer them to the Lord. The Levites had to kill the lambs for those people instead."
    },
    {
      "verse": "18",
      "text": "Most of the people who came from the tribes of Ephraim, Manasseh, Issachar and Zebulun had not made themselves properly clean. They should not have eaten the Passover meal, because God's law said that was wrong. But they still ate the meal. So Hezekiah prayed for them. He said, ‘Lord you are good. Please forgive everyone"
    },
    {
      "verse": "19",
      "text": "who really wants to obey you, the God of their ancestors. If they have not made themselves properly clean to eat this meal, please forgive them. ’"
    },
    {
      "verse": "20",
      "text": "The Lord accepted Hezekiah's prayer. He did not punish those people."
    },
    {
      "verse": "21",
      "text": "The Israelites who were in Jerusalem enjoyed the Festival of Flat Bread for seven days. They were very happy. Every day, the Levites and the priests made loud music to praise the Lord."
    },
    {
      "verse": "22",
      "text": "All the Levites understood how they should serve the Lord. So King Hezekiah thanked them. The festival continued for seven days. They offered friendship offerings to the Lord. They thanked the Lord, the God of their ancestors."
    },
    {
      "verse": "23",
      "text": "Then all the people who were there agreed to continue the feast for another seven days. So they did that happily for seven more days."
    },
    {
      "verse": "24",
      "text": "King Hezekiah of Judah gave 1, 000 bulls and 7, 000 sheep to the people. The leaders also gave them 1, 000 bulls and 10, 000 sheep. Many more priests also made themselves clean to serve the Lord."
    },
    {
      "verse": "25",
      "text": "Everyone at the festival was very happy. They included all Judah's people, the priests, the Levites and the whole group of people who had come from Israel. There were also foreign people who were living in Israel and in Judah."
    },
    {
      "verse": "26",
      "text": "Everyone enjoyed the festival in Jerusalem. Nothing like this had happened in Jerusalem since the time when David's son Solomon was king of Israel."
    },
    {
      "verse": "27",
      "text": "The priests and the Levites stood up and they asked God to bless the people. Their prayers reached the Lord's home in heaven, and he did what they asked for."
    }
  ],
  "31": [
    {
      "verse": "1",
      "text": "The Passover festival finished. Then the Israelites who were there went to all the towns in Judah. They knocked down the stone pillars that people worshipped. They also cut down the Asherah poles. They destroyed all the altars and places for worship on the hills. They did that everywhere in Judah, Benjamin, Ephraim and Manasseh. After they finished, all the Israelites returned to their homes in their own towns."
    },
    {
      "verse": "2",
      "text": "Hezekiah put the priests and the Levites into several groups. Each group had special work to do. Their different jobs were to offer burnt offerings and friendship offerings, and to serve God in other ways. Some of them would thank the Lord and sing songs to praise him at the gates of his temple."
    },
    {
      "verse": "3",
      "text": "The king gave some of his own animals for burnt offerings. The priests offered these sacrifices in the way that the law of the Lord taught. They offered burnt offerings each morning and each evening. They also offered them on Sabbath days, on the days of New Moon festivals and on other special days."
    },
    {
      "verse": "4",
      "text": "King Hezekiah told the people who lived in Jerusalem to bring their offerings too. They must provide the proper gifts for the priests and the Levites. Then they would serve the Lord in the way that his law taught them to do."
    },
    {
      "verse": "5",
      "text": "As soon as the Israelite people received Hezekiah's message, they brought their gifts to the temple. They brought the first part of their grain, wine, olive oil, honey and all the crops that grew in their fields. They brought one tenth part of all the food that they grew, so there was a lot of it."
    },
    {
      "verse": "6",
      "text": "The Israelites and the people of Judah who lived in other towns also brought gifts. They brought one animal from every ten of all their cows, sheep and goats. They also brought one thing from every ten things that they had made holy for the Lord their God. They put these things together in many heaps."
    },
    {
      "verse": "7",
      "text": "They started to bring their things in the third month of the year and they finished in the seventh month."
    },
    {
      "verse": "8",
      "text": "Hezekiah and his officers went to the temple and they saw all the things. Then they praised the Lord and they asked him to bless his people, the Israelites."
    },
    {
      "verse": "9",
      "text": "Hezekiah asked the priests and the Levites about the heaps of gifts from the people."
    },
    {
      "verse": "10",
      "text": "The leader of the priests, Azariah from Zadok's clan, said, ‘The people have brought a lot of gifts to the Lord's temple. Since they started to do that, we have had enough food to eat. There has been a lot more food than we need. The Lord has blessed his people, so we still have all this extra food. ’"
    },
    {
      "verse": "11",
      "text": "Hezekiah told them that they must prepare some rooms in the temple to store the things. When they had done that,"
    },
    {
      "verse": "12",
      "text": "they put in there the gifts, the tithes and the holy things. A Levite called Konaniah had to take care of all these things. His brother Shimei helped him."
    },
    {
      "verse": "13",
      "text": "Konaniah and Shimei had authority over these people: Jehiel, Azaziah, Nahath, Asahel, Jerimoth, Jozabad, Eliel, Ismakiah, Mahath and Benaiah. King Hezekiah chose all these men to do this work. Azariah was the priest who had authority over the temple."
    },
    {
      "verse": "14",
      "text": "Imnah's son Kore, a Levite, was the guard who watched the East Gate of the temple. He received the gifts that people offered to the Lord. He had authority to share among the priests and the Levites the gifts that people brought and the holy things."
    },
    {
      "verse": "15",
      "text": "Eden, Miniamin, Jeshua, Shemaiah, Amariah and Shecaniah helped him. They lived in the towns where the priests lived. They faithfully shared the people's gifts among the other Levites and priests, group by group. They included everyone, young and old."
    },
    {
      "verse": "16",
      "text": "They gave gifts to all those who were in the lists of men who could serve God in the temple. They had to be three years old or older. Those men would go into the temple on the right days for their group. They would do the work that their group had to do on those days."
    },
    {
      "verse": "17",
      "text": "The lists of the priests showed the clans that they belonged to. The list of the Levites showed which group they belonged to. Those who were 20 years old or older had to do the work that was given to their group."
    },
    {
      "verse": "18",
      "text": "The young children, wives, sons and daughters of all the men in the lists also received gifts. That was because the men faithfully kept themselves clean to serve God in their work."
    },
    {
      "verse": "19",
      "text": "Some of the priests and Levites lived on the land around the cities that belonged to them. So the king's officers chose honest men to take the gifts to them. They gave them their proper share of the gifts. The priests had to be Aaron's descendants, and the Levites' names had to be on the list of Levite families."
    },
    {
      "verse": "20",
      "text": "Those are the things that King Hezekiah did everywhere in Judah. He did what was good and right to please the Lord his God."
    },
    {
      "verse": "21",
      "text": "He served God faithfully with all his strength. He helped the work in the temple and he obeyed God's law and his commands. So he was successful in the things that he did."
    }
  ],
  "32": [
    {
      "verse": "1",
      "text": "After King Hezekiah had done all these good things, King Sennacherib of Assyria attacked Judah. He put his soldiers in camps around all the strong cities in Judah. He wanted to take the cities for himself."
    },
    {
      "verse": "2",
      "text": "Hezekiah saw that Sennacherib had come to attack Judah. He realized that Sennacherib had decided to attack Jerusalem."
    },
    {
      "verse": "3",
      "text": "So Hezekiah talked with his advisors and his army officers about what they should do. They decided to stop all the water that came from springs around the city. They all agreed that this was a good idea."
    },
    {
      "verse": "4",
      "text": "A big group of people came to help. They stopped the water that came from the springs and from the stream that went through that region. They said, ‘When the kings of Assyria arrive here, we do not want them to find plenty of water. ’"
    },
    {
      "verse": "5",
      "text": "King Hezekiah's men worked hard to repair the city's walls where they had broken. Hezekiah built towers on the walls. He also built another wall outside the first wall. He made the Millo around the City of David stronger, too. He also made many weapons and shields."
    },
    {
      "verse": "6",
      "text": "Hezekiah chose some men as captains to lead the men of his army. He told them to meet together in the open place near the city's gate. He said to them, After King Hezekiah of Judah said that to his men, they felt brave and strong."
    },
    {
      "verse": "7",
      "text": "‘Be strong and brave. Do not be afraid of the king of Assyria and his large army. Do not worry! We have much greater power than he has."
    },
    {
      "verse": "8",
      "text": "He has only the strength of human soldiers to help him. But we have the Lord our God to help us and to fight our battles! ’After King Hezekiah of Judah said that to his men, they felt brave and strong."
    },
    {
      "verse": "9",
      "text": "King Sennacherib of Assyria and his army were ready to attack Lachish. While he was there, he sent some men to Jerusalem with a message. The message was for King Hezekiah and all Judah's people who were in Jerusalem with him. The message said this:"
    },
    {
      "verse": "10",
      "text": "‘King Sennacherib of Assyria says this to you: My soldiers have made their camp around Jerusalem. So why do you remain in the city? Why are you so sure that someone will rescue you?"
    },
    {
      "verse": "11",
      "text": "Hezekiah tells you, “The Lord our God will save us from the power of Assyria's king. ” But he is deceiving you. You will die because you will have no food or water."
    },
    {
      "verse": "12",
      "text": "Remember that it was Hezekiah who removed the altars and the special places where you worship the Lord your God. He told the people of Judah and Jerusalem, “You must worship God only at the altar here in Jerusalem. That is the only place that you may offer sacrifices. ”"
    },
    {
      "verse": "13",
      "text": "You surely know what my ancestors and I have done to all the other nations. The gods of the nations around you could not save their people from my power."
    },
    {
      "verse": "14",
      "text": "Look at all the nations that my ancestors completely destroyed. None of their gods could rescue any of them. So do not think that your God can save you from my power."
    },
    {
      "verse": "15",
      "text": "Do not let Hezekiah deceive you with his lies. Do not believe him. No god of any nation or kingdom has been able to save his people from me or from my ancestors. So your God certainly cannot save you from my power! ’"
    },
    {
      "verse": "16",
      "text": "King Sennacherib's men continued to insult the Lord God and his servant Hezekiah."
    },
    {
      "verse": "17",
      "text": "Sennacherib also wrote letters to insult the Lord, Israel's God, and to laugh at him. He wrote, ‘The gods of the other nations around you could not save their people from my power. So Hezekiah's God cannot rescue his people from me either. ’"
    },
    {
      "verse": "18",
      "text": "Then Sennacherib's men shouted loudly to the people who were standing on Jerusalem's walls. They spoke in the language of Judah's people. They wanted to make the people very afraid so that they could take the city for themselves."
    },
    {
      "verse": "19",
      "text": "They insulted the God of Jerusalem's people, as they insulted the gods of other nations. They spoke about him as if he was only a god that people had made for themselves."
    },
    {
      "verse": "20",
      "text": "King Hezekiah and Amoz's son, Isaiah the prophet, prayed to God in heaven. They asked him to help."
    },
    {
      "verse": "21",
      "text": "The Lord God sent an angel to destroy Assyria's army. The angel killed all the soldiers and the army officers in their camp. So the king of Assyria had to return home to his own country. He was very ashamed. He went into the temple of his god. There some of his own sons used their swords to kill him."
    },
    {
      "verse": "22",
      "text": "That is how the Lord saved Hezekiah and Jerusalem's people from King Sennacherib of Assyria. The Lord also saved them from all their other enemies. So all Judah had a time of peace."
    },
    {
      "verse": "23",
      "text": "Many people brought gifts to Jerusalem to offer to the Lord. They also brought valuable gifts for King Hezekiah. From that time, all the other nations respected Hezekiah as a great king."
    },
    {
      "verse": "24",
      "text": "Soon after that, Hezekiah became very ill. He nearly died. He prayed to the Lord and the Lord answered him. The Lord did a miracle to show that Hezekiah would get better."
    },
    {
      "verse": "25",
      "text": "But Hezekiah did not thank the Lord for the kind thing that he had done for him. The king was too proud to do that. So the Lord became angry with him, and with the people of Judah and Jerusalem."
    },
    {
      "verse": "26",
      "text": "But then Hezekiah and the people who lived in Jerusalem made themselves humble. They stopped being proud, so the Lord did not punish them. He was not angry with them while Hezekiah continued to be king."
    },
    {
      "verse": "27",
      "text": "Hezekiah was very rich. People gave him great honour. He built rooms to store all his valuable things. They included silver, gold, jewels, spices and shields."
    },
    {
      "verse": "28",
      "text": "He built rooms to store grain, wine and olive oil. He also made buildings to keep all his cows, sheep and goats."
    },
    {
      "verse": "29",
      "text": "He built special cities for himself. He put lots of sheep and cows in them, because God had given him very many things."
    },
    {
      "verse": "30",
      "text": "Hezekiah had stopped the water coming out from the higher spring at Gihon. Instead, he caused the water to go down to the west side of the City of David. Hezekiah was successful in all the things that he did."
    },
    {
      "verse": "31",
      "text": "After that, the rulers of Babylon sent some officers to visit Hezekiah. They wanted to ask him about the miracle that had happened in Judah. God let Hezekiah decide what to tell them. He wanted to test Hezekiah, to see if he would be faithful."
    },
    {
      "verse": "32",
      "text": "The other things that happened while Hezekiah was king are written in a book. They include his faithful love for the Lord. The prophet Isaiah, Amoz's son, wrote down these things in the book of his visions. It is part of ‘The history of the kings of Judah and Israel’."
    },
    {
      "verse": "33",
      "text": "Hezekiah died and his people buried him beside the graves of King David's descendants, near the top of the hill. At his death, all the people of Judah and those who lived in Jerusalem gave him great honour. Hezekiah's son Manasseh became king after him."
    }
  ],
  "33": [
    {
      "verse": "1",
      "text": "years old when he became king. He ruled as king in Jerusalem for 55 years."
    },
    {
      "verse": "2",
      "text": "Manasseh did things that the Lord said were evil. He did the same terrible sins that the other nations in Canaan had done. Those were the nations that the Lord had chased out so that the Israelites could live there."
    },
    {
      "verse": "3",
      "text": "Manasseh built again the altars on the hills that his father Hezekiah had knocked down. He built altars for people to worship idols of Baal. He also made Asherah poles. He bent down low to worship all the stars in the sky."
    },
    {
      "verse": "4",
      "text": "He built altars in the Lord's temple. The Lord had said about his temple, ‘That is my home in Jerusalem where people will worship me for ever. ’"
    },
    {
      "verse": "5",
      "text": "Manasseh built altars to give honour to the stars in both yards of the Lord's temple."
    },
    {
      "verse": "6",
      "text": "He burnt his own sons with fire as a sacrifice in Ben Hinnom valley. He used magic and false gods to find out what would happen in the future. He took advice from magicians and people who talked to the spirits of dead people. He did many things that the Lord said were very evil. This made the Lord very angry."
    },
    {
      "verse": "7",
      "text": "Manasseh made an image of a false god. He put this idol in God's temple. God had said this about his temple to King David and to his son King Solomon: ‘My people will worship me in my temple here in Jerusalem. That is the place that I have chosen to be my home for ever. I have chosen it from among all the tribes of Israel."
    },
    {
      "verse": "8",
      "text": "I will never cause the Israelite people to leave this land that I gave to their ancestors. But they must be careful to obey all my commands, my laws and the rules that I gave to my servant Moses for them. ’"
    },
    {
      "verse": "9",
      "text": "But Manasseh caused Judah's people and the people of Jerusalem to turn away from God. So they did more evil things than the people who lived in Canaan before them. The Lord had destroyed those nations so that the Israelites could live there."
    },
    {
      "verse": "10",
      "text": "The Lord warned Manasseh and his people. But they would not listen to him."
    },
    {
      "verse": "11",
      "text": "So the Lord brought the officers of the king of Assyria's army to attack them. They took hold of Manasseh. They put metal hooks in his nose and they tied bronze chains around him. Then they took him away to Babylon."
    },
    {
      "verse": "12",
      "text": "This gave Manasseh a lot of pain. He asked the Lord his God to be kind to him. He made himself humble and he prayed for help to the Lord, the God of his ancestors."
    },
    {
      "verse": "13",
      "text": "When Manasseh prayed to the Lord, the Lord answered him. He was kind to Manasseh, as Manasseh had asked him to be. So the Lord brought Manasseh back to Jerusalem again, to rule there as king. Then Manasseh knew that the Lord is the true God."
    },
    {
      "verse": "14",
      "text": "After that, Manasseh repaired the outside wall of the City of David. He built it higher, from the west side of Gihon stream, as far as the Fish Gate. Then he continued around Ophel hill. He built the wall up higher than it had been. He also put army officers with their soldiers in all the strong cities of Judah."
    },
    {
      "verse": "15",
      "text": "Manasseh removed from the Lord's temple the foreign gods and the idol that he had put there. He also removed the altars that he had built on the hill of the temple and in other places in Jerusalem. He threw them away, outside the city."
    },
    {
      "verse": "16",
      "text": "Then he repaired the Lord's altar in the temple. He brought friendship offerings and thank offerings as sacrifices on the altar. He told Judah's people to worship the Lord, Israel's God."
    },
    {
      "verse": "17",
      "text": "The people still offered sacrifices at the other altars in the country. But they only offered those sacrifices to the Lord their God."
    },
    {
      "verse": "18",
      "text": "The other things that happened while Manasseh was king are written in a book. The book is called ‘The history of Israel's kings’. It includes Manasseh's prayer to God. It also includes the messages that the Lord, Israel's God, told his prophets to speak to Manasseh."
    },
    {
      "verse": "19",
      "text": "The book of the prophets' messages also includes Manasseh's prayer and how God answered him. It tells about all Manasseh's sins and how he turned away from God. It includes a list of all the places where he built altars and where he put Asherah poles and idols. He did those things before he made himself humble and he turned back to God."
    },
    {
      "verse": "20",
      "text": "Manasseh died and his people buried him in his palace. His son Amon became king after him."
    },
    {
      "verse": "21",
      "text": "years old when he became king. He ruled as king in Jerusalem for two years."
    },
    {
      "verse": "22",
      "text": "Amon did things that the Lord said were evil, as his father Manasseh had done. He offered sacrifices to all the idols that his father Manasseh had made. He worshipped those idols."
    },
    {
      "verse": "23",
      "text": "But he did not make himself humble and turn back to the Lord, as his father Manasseh had done. Instead, Amon became guilty of even more sins."
    },
    {
      "verse": "24",
      "text": "Amon's own officers decided to kill him. They killed him in his palace."
    },
    {
      "verse": "25",
      "text": "Then the people of Judah punished all Amon's murderers with death. They chose his son Josiah to be king after him."
    }
  ],
  "34": [
    {
      "verse": "1",
      "text": "Josiah was eight years old when he became king. He ruled as king in Jerusalem for 31 years."
    },
    {
      "verse": "2",
      "text": "Josiah did things that the Lord said were right. He lived in the good ways of his ancestor, King David. He did not turn away from the Lord's teaching in any way."
    },
    {
      "verse": "3",
      "text": "When Josiah had been king for eight years, he was still a young man. At that time he began to worship God, as his ancestor David had done. When he had been king for 12 years, he started to remove the places in Jerusalem and in all Judah where people worshipped false gods. He removed the altars on the hills, the Asherah poles, the idols and the images of false gods."
    },
    {
      "verse": "4",
      "text": "He told his men to knock down the altars where people worshipped the idols of Baal. He broke into pieces the altars for incense that were near the other altars. He destroyed the Asherah poles, the idols and the images. He broke them all into very small pieces. He threw the bits over the graves of the people who had offered sacrifices to those false gods."
    },
    {
      "verse": "5",
      "text": "Josiah took the bones of the priests who had made sacrifices to the false gods. He burned the priests' bones on their own altars. That is how Josiah made Judah and Jerusalem clean again."
    },
    {
      "verse": "6",
      "text": "He went to the towns that belonged to the tribes of Manasseh, Ephraim and Simeon. He even went as far as Naphtali. He did the same thing in all those towns, as well as in the villages around them where nobody lived."
    },
    {
      "verse": "7",
      "text": "He knocked down the altars and the Asherah poles. He completely destroyed the idols and the altars for incense everywhere in the kingdom of Israel. Then he returned to Jerusalem."
    },
    {
      "verse": "8",
      "text": "years, he continued to make Judah and the temple clean places again. He sent three men to repair the temple of the Lord his God. They were Azaliah's son Shaphan, the city's officer Maaseiah, and Joah, son of Joahaz, the city's secretary."
    },
    {
      "verse": "9",
      "text": "They went to meet Hilkiah, the leader of the priests. They gave him the money that people had brought as gifts to God's temple. The people had given their money to the Levites who stood as guards at the doors of the temple. The people who brought these gifts had come from the tribes of Manasseh, Ephraim and the other people who still lived in Israel. All the people from the tribes of Judah and Benjamin, and those who lived in Jerusalem had also brought their gifts."
    },
    {
      "verse": "10",
      "text": "Then they gave this money to the men who had authority over the work on the Lord's temple. Those leaders then paid the workers who did the repairs to make the temple strong again."
    },
    {
      "verse": "11",
      "text": "They gave money to the carpenters and the builders to buy stones that were ready to use and wood. The kings of Judah had not taken care of the buildings. So the workers now needed stones and wood to repair the walls and the roofs."
    },
    {
      "verse": "12",
      "text": "The workers were honest men who worked well. Four Levites had authority over the workers. They were Jahath and Obadiah from Merari's clan, and Zechariah and Meshullam from Kohath's clan. Other Levites who were musicians"
    },
    {
      "verse": "13",
      "text": "had authority over the men who carried the wood and the stones. They told the workers what to do as they did their different jobs. Some Levites worked as secretaries, officers or guards."
    },
    {
      "verse": "14",
      "text": "The Levites were bringing the money out of the Lord's temple that people had brought there. While they were doing that, Hilkiah the priest found the book of God's laws. Those were the laws that the Lord had given to Moses for his people."
    },
    {
      "verse": "15",
      "text": "Hilkiah told Shaphan, the king's secretary, ‘I have found the book of the Law in the Lord's temple. ’ He gave the book to Shaphan."
    },
    {
      "verse": "16",
      "text": "Then Shaphan took the book to the king and he said, ‘Your servants are doing everything that you told them to do."
    },
    {
      "verse": "17",
      "text": "They have paid out the money that was in the Lord's temple. They have given it to the leaders who have authority over the men who are doing the work. ’"
    },
    {
      "verse": "18",
      "text": "Then Shaphan, the king's secretary, told the king, ‘Hilkiah the priest has given a book to me. ’ Then Shaphan read it aloud to the king."
    },
    {
      "verse": "19",
      "text": "When the king heard the words in the book of God's laws, he was so upset that he tore his clothes."
    },
    {
      "verse": "20",
      "text": "King Josiah gave a command to Hilkiah, Shaphan's son Ahikam, Micah's son Abdon, Shaphan the secretary and Asaiah the king's servant."
    },
    {
      "verse": "21",
      "text": "He told them, ‘Go to the temple. Ask the Lord about the message in this book that Hilkiah has found. I need to know what I should do, as well as the people who still live in Judah and in Israel. The Lord has become very angry with us because our ancestors have not obeyed his message. They have not done the things that this book tells us that we should do. ’"
    },
    {
      "verse": "22",
      "text": "So Hilkiah and the other men that the king had sent went to speak to Huldah. Huldah was a prophetess who lived in the north part of Jerusalem. She was the wife of Shallum, the son of Tokhath. Tokhath was the son of Hasrah, who took care of the king's clothes. The king's men told Huldah why they had come to meet her."
    },
    {
      "verse": "23",
      "text": "She said to them, ‘The Lord, Israel's God, says, “Tell this to the man who sent you here to me: The men took Huldah's answer back to the king."
    },
    {
      "verse": "24",
      "text": "This is what the Lord says: I will bring great trouble to this place and the people who live here. The message of the book that they read to the king of Judah tells about what will happen."
    },
    {
      "verse": "25",
      "text": "I will send this trouble because they have turned away from me. They have offered sacrifices to other gods. I am very angry with them because of all the idols that they have made for themselves. My anger is like a fire that is burning and nobody can stop it! ”"
    },
    {
      "verse": "26",
      "text": "The king of Judah sent you here to ask for the Lord's answer. Say to the king, “The Lord, Israel's God, says this about the message that you have heard:"
    },
    {
      "verse": "27",
      "text": "When you heard the message that I had spoken, you were very upset. You made yourself humble to respect me. You tore your clothes and you wept. You did that when you heard how I would punish this place and the people who live here. Because you became so upset, I have heard your prayer."
    },
    {
      "verse": "28",
      "text": "So I will let you die in peace and people will bury you beside your ancestors. You yourself will never see the great trouble that I will bring to this place and the people who live here. ” That is what the Lord says. ’The men took Huldah's answer back to the king."
    },
    {
      "verse": "29",
      "text": "Then King Josiah told all the leaders of Judah and Jerusalem to come and meet with him."
    },
    {
      "verse": "30",
      "text": "He went up to the Lord's temple. All the people who lived in Jerusalem and in the rest of Judah went with him. They included the priests, the Levites, young people and old people. Everyone went to the temple. They all listened while the king read to them all the words in the book of God's covenant. That was the book that Hilkiah had found in the Lord's temple."
    },
    {
      "verse": "31",
      "text": "Then the king stood in his place beside the pillar in the temple. He promised the Lord that he would obey the covenant. He agreed to serve the Lord faithfully and to obey his commands, laws and rules. Josiah agreed to obey what was written in the book of God's covenant."
    },
    {
      "verse": "32",
      "text": "The king told all the people who were in Jerusalem and the people of Benjamin's tribe to stand. He told them to promise to obey God's laws. So the people who lived in Jerusalem agreed to obey the covenant of God, the God of their ancestors."
    },
    {
      "verse": "33",
      "text": "Josiah removed all the disgusting idols from all the land of the Israelites. He told all the people of Israel to worship the Lord their God. All the time that Josiah ruled as king, the people continued to worship the Lord, the God of their ancestors."
    }
  ],
  "35": [
    {
      "verse": "1",
      "text": "King Josiah told the people to have the Passover festival in Jerusalem, to give honour to the Lord. They killed the lambs for the Passover meal on the 14th day of the first month of the year."
    },
    {
      "verse": "2",
      "text": "Josiah told the priests the jobs that they should do. He told them to be strong as they served the Lord in his temple."
    },
    {
      "verse": "3",
      "text": "The work of the Levites was to teach all the Israelites about God's laws. The Lord had chosen them to do that special work. Josiah said to them, ‘Put the holy Covenant Box in the temple that David's son, King Solomon, built. Do not carry it on your shoulders. Now you must serve the Lord your God and his people, the Israelites."
    },
    {
      "verse": "4",
      "text": "Each group of families must be ready to do their work. King David of Israel and his son Solomon decided what work each group must do."
    },
    {
      "verse": "5",
      "text": "Each group of Levites must stand in the holy place of the temple. Each group will be ready to help the people of different clans."
    },
    {
      "verse": "6",
      "text": "Kill the lambs for the Passover meal. Make yourselves clean to serve the Lord. Prepare the sacrifices for each Israelite family. Then they can eat the Passover meal, as the Lord told Moses they must do. ’"
    },
    {
      "verse": "7",
      "text": "Josiah took 30, 000 lambs and goats, and 3, 000 bulls from his own animals. He gave them to the people who were there, to kill for their Passover sacrifices."
    },
    {
      "verse": "8",
      "text": "His officers were also happy to give their animals to the people, as well as to the priests and the Levites. Hilkiah, Zechariah, and Jehiel were officers who took care of the temple. They gave 2, 600 lambs and 300 bulls to the priests for Passover sacrifices."
    },
    {
      "verse": "9",
      "text": "These Levite officers gave 5, 000 lambs and 500 bulls to the Levites for Passover sacrifices: Konaniah and his brothers, Shemaiah and Nethanel; Hashabiah, Jeiel and Jozabad."
    },
    {
      "verse": "10",
      "text": "Everything was ready for the Passover to begin. The priests and the Levites stood in their places, group by group, as the king had commanded."
    },
    {
      "verse": "11",
      "text": "Some Levites killed the lambs for the Passover meal. They gave the blood to the priests, and the priests splashed the blood on the altar. At the same time, some Levites were removing the skins from the animals."
    },
    {
      "verse": "12",
      "text": "They took the animals for the burnt offerings to give to the people. They shared them among each group of families. Then each family could offer a bull to the Lord as a sacrifice, in the way that the book of Moses taught."
    },
    {
      "verse": "13",
      "text": "The Levites cooked the lambs for the Passover meal over a fire, as the rules taught. They boiled the meat of the holy offerings in pots and pans. Then they quickly carried the meat to all the people."
    },
    {
      "verse": "14",
      "text": "After that, the Levites prepared the Passover meal for themselves and for the priests. The priests had been busy all day, until the evening. They were offering the burnt offerings and the pieces of fat to the Lord. So the Levites prepared the meal for themselves and for the priests, Aaron's descendants."
    },
    {
      "verse": "15",
      "text": "Asaph's descendants, the musicians, stood in their places. Those were the places that David, Asaph, Heman and the king's prophet, Jeduthun, had chosen. The guards continued to watch the different gates all through the day. So the other Levites prepared the meal for them too."
    },
    {
      "verse": "16",
      "text": "So they did everything properly to serve the Lord that day. Everyone did what King Josiah had told them to do. They had the Passover meal and they offered the burnt offerings on the Lord's altar."
    },
    {
      "verse": "17",
      "text": "Some Israelite people were also there in Jerusalem for the Passover festival at that time. They also stayed seven more days for the festival of Flat Bread."
    },
    {
      "verse": "18",
      "text": "There had not been a Passover festival like that in Israel since the time of the prophet Samuel. No king of Israel had enjoyed a Passover festival as good as the one that King Josiah had. The priests, the Levites and all the people enjoyed the festival. They were the people of Judah, the people of Israel who had come to Jerusalem, as well as the people who lived in Jerusalem."
    },
    {
      "verse": "19",
      "text": "This Passover festival happened in the 18th year that Josiah ruled Judah as king."
    },
    {
      "verse": "20",
      "text": "After Josiah had done all those things for the temple, King Necho of Egypt marched out with his army. He came to fight a battle at Carchemish, a city beside the Euphrates river. King Josiah went with his army to fight against King Necho."
    },
    {
      "verse": "21",
      "text": "But Necho sent men with a message to Josiah. King Necho said, ‘King of Judah, you should not come to fight against me. We should be friends. I came to fight against this kingdom which is my enemy. God has told me that I must hurry. So do not try to stop me, because God is with me. If you try to fight against God, he will destroy you. ’"
    },
    {
      "verse": "22",
      "text": "But Josiah would not agree to go away. He changed his clothes so that nobody would recognize him in the battle. God had told King Necho what to say to Josiah. But Josiah would not listen to his words. Instead, he went to fight against Necho in Megiddo valley."
    },
    {
      "verse": "23",
      "text": "Necho's soldiers hit King Josiah with their arrows. The king said to his servants, ‘Take me away from the battle! The arrows have hurt me very much. ’"
    },
    {
      "verse": "24",
      "text": "So they took him out of the chariot that he was riding in. They put him in his other chariot. Then they took him to Jerusalem and he died there. His people buried him beside his ancestors. All the people of Judah and Jerusalem wept because Josiah had died."
    },
    {
      "verse": "25",
      "text": "Jeremiah wrote sad songs about Josiah's death. The male and female singers still sing these songs to remember Josiah, even today. The songs have become something that the people of Israel always like to sing. They are written in a book called ‘The book of sad songs’."
    },
    {
      "verse": "26",
      "text": "All the other things that Josiah did while he was king are written in a book. The book is called ‘The history of the kings of Israel and Judah’."
    },
    {
      "verse": "27",
      "text": "It tells how Josiah faithfully obeyed what is written in the Law of the Lord. It includes all the good things that he did, from the beginning to the end of his time as king."
    }
  ],
  "36": [
    {
      "verse": "1",
      "text": "The people of Judah chose Josiah's son, Jehoahaz, to become king in Jerusalem after his father."
    },
    {
      "verse": "2",
      "text": "years old when he became king. He ruled as king in Jerusalem for three months."
    },
    {
      "verse": "3",
      "text": "The king of Egypt stopped Jehoahaz from ruling in Jerusalem. He made Judah pay tax to him. It was 3, 400 kilograms of silver and 34 kilograms of gold."
    },
    {
      "verse": "4",
      "text": "The king of Egypt chose Eliakim, Jehoahaz's brother, to rule as king over Judah and Jerusalem. He changed Eliakim's name to Jehoiakim. But Necho took Jehoiakim's brother Jehoahaz away to Egypt."
    },
    {
      "verse": "5",
      "text": "years old when he became king. He ruled for 11 years as king in Jerusalem. He did things that the Lord his God said were evil."
    },
    {
      "verse": "6",
      "text": "While he was king, King Nebuchadnezzar of Babylon attacked Judah. He took hold of King Jehoiakim. He tied bronze chains around him and he took him away to Babylon."
    },
    {
      "verse": "7",
      "text": "King Nebuchadnezzar took some valuable things from the Lord's temple. He took them to Babylon and he put them in his palace there."
    },
    {
      "verse": "8",
      "text": "The other things that happened while Jehoiakim was king are written in a book. The book is called ‘The history of the kings of Israel and Judah’. It tells about the disgusting sins that he was guilty of. Jehoiakim's son Jehoiachin became king after him. Jehoiakim's son Jehoiachin became king after him."
    },
    {
      "verse": "9",
      "text": "years old when he became king. He ruled as king in Jerusalem for three months and ten days. He did things that the Lord said were evil."
    },
    {
      "verse": "10",
      "text": "In the spring, King Nebuchadnezzar sent his soldiers to bring Jehoiachin to Babylon. They also took to Babylon some valuable things from the Lord's temple. Nebuchadnezzar chose Jehoiachin's relative, Zedekiah, to be king of Judah and Jerusalem."
    },
    {
      "verse": "11",
      "text": "years old when he became king. He ruled in Jerusalem for 11 years."
    },
    {
      "verse": "12",
      "text": "He did things that the Lord said were evil. The prophet Jeremiah spoke the Lord's message to Zedekiah. But Zedekiah was too proud to listen to him."
    },
    {
      "verse": "13",
      "text": "King Nebuchadnezzar had made Zedekiah promise in God's name that he would be faithful to Nebuchadnezzar. But Zedekiah turned against Nebuchadnezzar. He was very proud and he refused to change. He refused to turn back to the Lord, Israel's God."
    },
    {
      "verse": "14",
      "text": "All the leaders of the priests and the people also turned away from the Lord more and more. They did the same disgusting sins that the people in other nations did. They made the Lord's temple an unclean place. That was the place that the Lord himself had chosen as his special home in Jerusalem."
    },
    {
      "verse": "15",
      "text": "The Lord sent his servants many times to warn his people. He wanted to be kind to them. He wanted to keep his temple safe."
    },
    {
      "verse": "16",
      "text": "But they laughed at the men that God sent to them. They did not think that his messages were important. They insulted his prophets. Finally, the Lord became very angry with his people. Nothing could stop him from punishing them."
    },
    {
      "verse": "17",
      "text": "Then the Lord sent the king of Babylon to attack them. His soldiers killed Jerusalem's young men in the temple, where they thought that they would be safe. They were not kind to anybody, the young men or women, or even the very old people. God put all the people of Jerusalem under the king of Babylon's power."
    },
    {
      "verse": "18",
      "text": "The king took away to Babylon all the things that were in God's temple. He took everything, big things and small things. He took all the valuable things that were in the Lord's temple. He also took the valuable things of the king and his officers. He took them all away to Babylon."
    },
    {
      "verse": "19",
      "text": "Nebuchadnezzar's men destroyed the Lord's temple with fire. They knocked down the walls around Jerusalem. They burned all the important buildings. They destroyed all the valuable things in the city."
    },
    {
      "verse": "20",
      "text": "Nebuchadnezzar took away to Babylon all the people in Jerusalem who were still alive. They worked as slaves for him and for his sons until the kingdom of Persia became powerful."
    },
    {
      "verse": "21",
      "text": "In this way, the Lord's message that his prophet Jeremiah had spoken became true. The land of Judah was empty for 70 years. It was finally able to rest, like the rest on a Sabbath day."
    },
    {
      "verse": "22",
      "text": "In the first year that Cyrus, king of Persia, was ruling Babylon, the Lord put a thought in his mind. King Cyrus decided to send a message to everybody who lived in his kingdom. His message would cause what God had already spoken to his prophet Jeremiah to become true. The message was written down and people took it all over Cyrus's kingdom. It said:"
    },
    {
      "verse": "23",
      "text": "‘This is what Cyrus, the king of Persia, says: The Lord, the God of heaven, has given me power over all the kingdoms of the earth. He has said that I must build a temple for him in Jerusalem, the city that is in Judah. Any of God's people who live among you may now return to Jerusalem. I pray that the Lord their God will be with them. ’"
    }
  ]
};