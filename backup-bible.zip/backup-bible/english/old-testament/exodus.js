module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "Here are the names of the Israelites who went to Egypt with Jacob. Each one went there with his family."
    },
    {
      "verse": "2",
      "text": "Jacob's sons were Reuben, Simeon, Levi and Judah,"
    },
    {
      "verse": "3",
      "text": "Issachar, Zebulun and Benjamin,"
    },
    {
      "verse": "4",
      "text": "Dan, Naphtali, Gad and Asher."
    },
    {
      "verse": "5",
      "text": "descendants. His other son, Joseph, was already in Egypt."
    },
    {
      "verse": "6",
      "text": "After some time, Joseph died. Joseph's brothers and all his generation also died."
    },
    {
      "verse": "7",
      "text": "But the Israelites had many children, so they grew into a very large family. They became very powerful. They were everywhere in the whole country."
    },
    {
      "verse": "8",
      "text": "Later, a new king began to rule in Egypt. He did not know anything about Joseph."
    },
    {
      "verse": "9",
      "text": "He said to his people, ‘Look! The Israelites have become too many for us. They are more powerful than we are."
    },
    {
      "verse": "10",
      "text": "We must find a clever way to stop them. If we do nothing, their families will become even bigger. Then, if there is a war, they will join our enemies and they will fight against us. That will give the Israelites a chance to leave our country. ’"
    },
    {
      "verse": "11",
      "text": "So the Egyptians made the Israelites work as their slaves. The Egyptian masters made the Israelites do very hard work. They had to build cities for the king, Pharaoh, where he could store food for his people. The names of the cities were Pithom and Rameses."
    },
    {
      "verse": "12",
      "text": "The Egyptians made the Israelites work more and more. But the Israelites still became more in number. They had many children and they lived in every part of the country. Because of this, the Egyptians began to be afraid of them."
    },
    {
      "verse": "13",
      "text": "So the Egyptians made the Israelites work without any rest."
    },
    {
      "verse": "14",
      "text": "The Israelites became very upset because of all the difficult work. They had to build houses with bricks and mortar. They also did many different kinds of work in the fields. The Egyptians made the Israelites do all this difficult work."
    },
    {
      "verse": "15",
      "text": "There were two Israelite women who helped the other women when they were giving birth. These two women were called Shiphrah and Puah. The king of Egypt said to them,"
    },
    {
      "verse": "16",
      "text": "‘When you help the Israelite women at the birth of their children, this is what you must do. If she gives birth to a son, kill him. But if the child is a daughter, you may let her live. ’"
    },
    {
      "verse": "17",
      "text": "But the two women respected God. So they did not do what the king of Egypt had told them. They obeyed God and they let the boys live."
    },
    {
      "verse": "18",
      "text": "Then the king of Egypt called the two women to come to him. He asked them, ‘Why have you done this? Why have you let the boys live? ’"
    },
    {
      "verse": "19",
      "text": "The two women said to Pharaoh, ‘Israelite women are not like Egyptian women. Israelite women are very strong. They give birth to their babies very quickly, before we arrive at the house. ’"
    },
    {
      "verse": "20",
      "text": "Because the two women respected God, he was kind to them. The Israelite people continued to grow in number. They became very strong."
    },
    {
      "verse": "21",
      "text": "Because the two women obeyed God, he gave them families of their own."
    },
    {
      "verse": "22",
      "text": "Then Pharaoh spoke to all the Egyptian people. He said, ‘When an Israelite boy is born, you must throw him in the river Nile. But you can let the baby girls live. ’"
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "At this time, there was an Israelite man who belonged to the family of Levi. He married a woman who was also a descendant of Levi."
    },
    {
      "verse": "2",
      "text": "The woman became pregnant and she gave birth to a son. She saw that he was a beautiful boy. So she hid him for three months."
    },
    {
      "verse": "3",
      "text": "Then she could not continue to hide him. So she took a basket that was made from river grass. She painted the basket with tar, to keep the water out of it. Then she put her baby in the basket. She put the basket among the reeds at the edge of the river."
    },
    {
      "verse": "4",
      "text": "The baby's sister stood not very far away. She wanted to see what would happen to the baby."
    },
    {
      "verse": "5",
      "text": "Soon, Pharaoh's daughter came to wash herself in the river. Her servant girls were walking near the edge of the river. Pharaoh's daughter saw the basket among the river grasses. So she sent one of her servant girls to fetch it for her."
    },
    {
      "verse": "6",
      "text": "When she opened the basket, she saw the baby boy. He was crying. She was sorry for him and she said, ‘This is one of the Israelite children. ’"
    },
    {
      "verse": "7",
      "text": "Then the baby's sister said to Pharaoh's daughter, ‘Do you want me to fetch one of the Israelite mothers? She can take care of this baby and she can feed him for you. ’"
    },
    {
      "verse": "8",
      "text": "Pharaoh's daughter said, ‘Yes, please do that. ’So the girl went and she fetched the baby's own mother."
    },
    {
      "verse": "9",
      "text": "Pharaoh's daughter said to the baby's mother, ‘Please take this baby to your house. You can take care of him for me. I will pay you to do this. ’ So the woman took the baby home and she took care of him."
    },
    {
      "verse": "10",
      "text": "When the baby was older, his mother took him to Pharaoh's daughter. He now became her son. She gave him the name ‘Moses’. She said, ‘I will call him Moses because I pulled him out of the water. ’"
    },
    {
      "verse": "11",
      "text": "Many years later, Moses grew to become a man. At that time, he went out to visit his own people, the Israelites. He saw that they had to do very hard work without any rest. He saw an Egyptian man. He was attacking an Israelite man. The Egyptian was hitting someone from Moses' own country!"
    },
    {
      "verse": "12",
      "text": "Moses looked in every direction. He saw that nobody was near. So Moses killed the Egyptian. He buried his body in the sand to hide it."
    },
    {
      "verse": "13",
      "text": "The next day, Moses went out again to visit his people. He saw that two Israelite men were fighting each other. Moses said to the guilty man, ‘Why are you attacking your friend, who is an Israelite like you? ’"
    },
    {
      "verse": "14",
      "text": "The man answered, ‘You do not have authority over us! You cannot judge us! Do you want to kill me, as you killed that Egyptian man? ’ Then Moses was afraid. He said to himself, ‘People must know what I have done! ’"
    },
    {
      "verse": "15",
      "text": "Pharaoh heard about what had happened. He wanted to kill Moses. So Moses ran away from Pharaoh. He went from Egypt to the country called Midian and he lived there. One day, Moses sat down by a well which was near where he lived. One day, Moses sat down by a well which was near where he lived."
    },
    {
      "verse": "16",
      "text": "There was a priest in Midian who had seven daughters. Those seven young women came to get water out of the well. They used the water to fill the places where the animals drink. Then their father's sheep and goats could drink there."
    },
    {
      "verse": "17",
      "text": "But some shepherds then arrived at the well. They made the girls go away. So Moses stood up and he went to help the young women. He gave water to their animals."
    },
    {
      "verse": "18",
      "text": "Then the girls went back home to Reuel, their father. He asked them, ‘Why have you come home so soon today? ’"
    },
    {
      "verse": "19",
      "text": "They answered, ‘An Egyptian man saved us from the shepherds. He even took water from the well and he gave it to our animals. ’"
    },
    {
      "verse": "20",
      "text": "Reuel said to his daughters, ‘So where is the man? You should not have left him there. Ask him to come here so that he can eat a meal with us. ’"
    },
    {
      "verse": "21",
      "text": "Moses agreed to stay with Reuel. Reuel gave his daughter Zipporah to Moses as his wife."
    },
    {
      "verse": "22",
      "text": "Later, Zipporah gave birth to a son for Moses. Moses gave the boy the name ‘Gershom’. He called him that because he said, ‘I am living as a stranger in a foreign country. ’"
    },
    {
      "verse": "23",
      "text": "After a long time had passed, the king of Egypt died. The Israelites were still slaves of the Egyptians. That made them very sad and they complained loudly. God heard them when they cried for help."
    },
    {
      "verse": "24",
      "text": "He thought about his promise to take care of Abraham, Isaac and Jacob and their descendants."
    },
    {
      "verse": "25",
      "text": "God saw what was happening to the Israelites. He knew that he must help them."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "Moses worked as a shepherd and he took care of Jethro's sheep. Jethro was his wife's father and he was the priest of Midian. Moses led the sheep to the far side of the desert. He came to Sinai, the mountain of God."
    },
    {
      "verse": "2",
      "text": "The angel of the Lord appeared to Moses there. The angel looked like a fire that was burning in the middle of a bush. Moses looked at the bush. He saw that it was on fire, but the fire still did not destroy it."
    },
    {
      "verse": "3",
      "text": "Moses said to himself, ‘I will go nearer and see this strange thing. I want to see why the bush is not completely burned. ’"
    },
    {
      "verse": "4",
      "text": "The Lord saw that Moses came near to look at the bush. God spoke to Moses from inside the bush. He said, ‘Moses! Moses! ’ Moses answered, ‘Here I am. ’"
    },
    {
      "verse": "5",
      "text": "God said to Moses, ‘Do not come nearer! Remove your shoes from your feet. The ground that you are standing on is holy. ’"
    },
    {
      "verse": "6",
      "text": "Then God said, ‘I am the God that your father worshipped. I am also the God of your ancestors, Abraham, Isaac and Jacob. ’ Then Moses covered his face. He was afraid to look at God."
    },
    {
      "verse": "7",
      "text": "The Lord said, ‘I have certainly seen the troubles of my people in Egypt. I have heard them when they cry for help because of their cruel masters. I know that they are very sad."
    },
    {
      "verse": "8",
      "text": "So now I have come down to save them from the power of the Egyptians. I will bring them out from Egypt to go to another land. That will be a good land and a big land. The land will give them plenty of good food and drink, enough for everyone. These are the nations who live there now: the Canaanites, the Hittites, the Amorites, the Perizzites, the Hivites and the Jebusites."
    },
    {
      "verse": "9",
      "text": "Yes, I have heard that my Israelite people are crying for help. I have seen that the Egyptians do bad things to hurt them."
    },
    {
      "verse": "10",
      "text": "So now you must go! I will send you to speak to Pharaoh. You will lead my people, the Israelites, out of Egypt. ’"
    },
    {
      "verse": "11",
      "text": "But Moses said to God, ‘I am not an important person. I cannot go to Pharaoh. I cannot lead the Israelites out of Egypt! ’"
    },
    {
      "verse": "12",
      "text": "God said to Moses, ‘Be sure of this: I will be with you. After you have led the people out of Egypt you will all worship me here, on this mountain. That will show you that I myself have sent you to do this. ’"
    },
    {
      "verse": "13",
      "text": "Then Moses said to God, ‘If I go to the Israelites, they may not believe me. I will say, “The God that your ancestors worshipped has sent me to you. ” But then they will ask me, “What is his name? ” Then what will I say to them? ’"
    },
    {
      "verse": "14",
      "text": "God said to Moses, ‘I am who I am! Say this to the Israelite people: “I AM has sent me to you. ” ’"
    },
    {
      "verse": "15",
      "text": "God also said to Moses, ‘Say this to the Israelite people: “It is the Lord God who has sent me to you. He is the God that your ancestors worshipped. He is the God of Abraham, Isaac and Jacob. ” That is my name for all time. All generations of my people must call me by that name."
    },
    {
      "verse": "16",
      "text": "Go and call the leaders of Israel to meet together. Say to them, “The Lord God has appeared to me. He is the God that your ancestors worshipped. He is the God of Abraham, Isaac and Jacob. He said to me, ‘I have been carefully watching my people in Egypt. I have seen the bad things that the Egyptians have done to you."
    },
    {
      "verse": "17",
      "text": "I promise that I will bring you out of your troubles in Egypt. I will lead you into the land of the Canaanites, the Hittites, the Amorites, the Perizzites, the Hivites and the Jebusites. It is a land that will give you plenty of good food and drink, enough for everyone. ’ ”"
    },
    {
      "verse": "18",
      "text": "When you say that, the leaders of the Israelites will listen to you. Then you must go with them to the king of Egypt. Say to him, “The Lord God has met with us. He is the God that we, the Israelite people, worship. So let us go on a journey into the wilderness. That will be a journey of three days. We must offer sacrifices to the Lord our God there. ”"
    },
    {
      "verse": "19",
      "text": "But I know that the king of Egypt will not let you go. Only some great power will make him agree."
    },
    {
      "verse": "20",
      "text": "So I will show him my power! I will do powerful miracles to punish the Egyptians. When they see that, Pharaoh will let you go free."
    },
    {
      "verse": "21",
      "text": "More than that, I will cause the Egyptians to think well of you, my own people. So when you leave Egypt, they will give you many gifts."
    },
    {
      "verse": "22",
      "text": "All the Israelite women will ask their Egyptian friends to give them things. They will ask the women who live near them and those who live with them in their houses. They will ask for silver things, gold things and beautiful clothes. Then you will take those things and you will dress your sons and your daughters with them. In that way, you will take many valuable things away from the Egyptians. ’"
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Then Moses replied, ‘Perhaps the leaders of Israel will not believe me. Perhaps they will not listen to my message. Perhaps they will say, “The Lord did not really appear to you. ” ’"
    },
    {
      "verse": "2",
      "text": "Then the Lord said to Moses, ‘What is that thing in your hand? ’ Moses answered, ‘It is a stick. ’"
    },
    {
      "verse": "3",
      "text": "The Lord said, ‘Throw it down on the ground. ’ So Moses threw it on the ground. Then the stick became a snake! Moses ran away from the snake."
    },
    {
      "verse": "4",
      "text": "Then the Lord said to Moses, ‘Take hold of the snake's tail with your hand. ’ So Moses caught the snake with his hand. Then it became a stick in his hand again."
    },
    {
      "verse": "5",
      "text": "God said, ‘Do this in front of them. Then they will believe you. They will believe that I, the Lord God, have appeared to you. I am the God that their ancestors worshipped. I am the God of Abraham, the God of Isaac and the God of Jacob. ’"
    },
    {
      "verse": "6",
      "text": "Then the Lord said to Moses, ‘Put your hand inside your robe. ’ So Moses did this. When he took his hand out again, the skin had become white, like snow. It was the bad disease called leprosy."
    },
    {
      "verse": "7",
      "text": "Then God said, ‘Put your hand back inside your robe again. ’ So Moses did that. And when he took his hand out, it was well again, like the rest of his skin!"
    },
    {
      "verse": "8",
      "text": "God said, ‘The leaders may not believe you. They may not think that the miracle with the stick shows anything. But they may believe you when you do the second miracle."
    },
    {
      "verse": "9",
      "text": "But they may still not listen to your message. If they will not even believe those two miracles, do this: Take some water from the River Nile and pour it on the dry ground. The water that you take from the river will become blood on the ground. ’"
    },
    {
      "verse": "10",
      "text": "Then Moses said to the Lord, ‘My Lord, I cannot speak well. I speak slowly and I speak with difficulty. I never could speak well. And even now, when you have spoken to me, I still cannot speak well. ’"
    },
    {
      "verse": "11",
      "text": "Then the Lord said to Moses, ‘Who has made human mouths? Who makes a person that cannot speak? Who makes a person that cannot hear? Who makes a person who can see, or who cannot see? It is I, the Lord God!"
    },
    {
      "verse": "12",
      "text": "Now go! I will help you to speak well. I will teach you what you must say. ’"
    },
    {
      "verse": "13",
      "text": "But Moses said, ‘My Lord, please send some other person. Do not send me! ’"
    },
    {
      "verse": "14",
      "text": "Then the Lord became angry with Moses. He said, ‘Aaron, the Levite, is your brother. I know that he can speak very well. Look! He is coming to meet you now. When he sees you, he will be very happy."
    },
    {
      "verse": "15",
      "text": "So this is what you must do. You must speak to him. You must tell him what to say. I will help both of you to speak. And I will teach both of you what you must do."
    },
    {
      "verse": "16",
      "text": "Aaron will speak to the people on your behalf. He will be like your mouth, to speak your message. And you will be like God to him. You will tell him what to say."
    },
    {
      "verse": "17",
      "text": "Take this stick with you and hold it in your hand. You will use it to do the miracles to show that I have sent you. ’"
    },
    {
      "verse": "18",
      "text": "Then Moses went back to Jethro, his wife's father. Moses said to him, ‘Please let me return to my family in Egypt. I must see if they are still alive. ’ So Jethro said to Moses, ‘Go in peace. ’"
    },
    {
      "verse": "19",
      "text": "The Lord had said to Moses while he was still in Midian, ‘Go back to Egypt. All the men who tried to kill you are now dead. ’"
    },
    {
      "verse": "20",
      "text": "So Moses put his wife and his sons on a donkey and they started on the journey back to Egypt. And Moses carried the stick of God in his hand."
    },
    {
      "verse": "21",
      "text": "Then the Lord said to Moses, ‘When you return to Egypt you must do the signs. Do all the signs that I gave you the power to do. Do them in front of Pharaoh. But I will make Pharaoh angry and cruel. Because of this, he will not let the people go."
    },
    {
      "verse": "22",
      "text": "Then you must speak to Pharaoh. You must say, “The Lord says, Israel is my first son."
    },
    {
      "verse": "23",
      "text": "I have already said to you, Let my son go so that he can worship me. But if you refuse to let him go, I will kill your first son. ” ’"
    },
    {
      "verse": "24",
      "text": "On the way to Egypt, there was a place where people could rest on their journey. The Lord met Moses there and he wanted to kill Moses."
    },
    {
      "verse": "25",
      "text": "But Zipporah took a sharp stone and she cut off her son's foreskin with the stone. She touched Moses' feet with the foreskin. She said, ‘You are a husband of blood to me. ’"
    },
    {
      "verse": "26",
      "text": "So God did not do anything bad to Moses. Then Zipporah said to Moses, ‘You are a husband of blood, because of this circumcision. ’"
    },
    {
      "verse": "27",
      "text": "The Lord said to Aaron, ‘Go into the desert to meet Moses. ’ So Aaron went. He met Moses at the mountain of God and he kissed him."
    },
    {
      "verse": "28",
      "text": "Then Moses told Aaron all that the Lord had told him to say. He also told Aaron about all the special signs. God had commanded Moses to show these signs to the Israelites and to Pharaoh."
    },
    {
      "verse": "29",
      "text": "Then Moses and Aaron went to Egypt. They brought together all the leaders of the Israelites."
    },
    {
      "verse": "30",
      "text": "Aaron told them all the things that the Lord had said to Moses. Then Moses did the signs in front of the people."
    },
    {
      "verse": "31",
      "text": "And the people believed Aaron and Moses. They had heard that the Lord had come to his people. God had seen their hard life and he was sorry for them. They put their heads down and they worshipped God."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "After this, Moses and Aaron went to visit Pharaoh. They said to him, ‘Listen to what the Lord says. He is the God of Israel. He says, “Let my people go. Let them prepare a feast in the desert to worship me. ” ’"
    },
    {
      "verse": "2",
      "text": "But Pharaoh said, ‘The Lord is not my god. I do not need to obey him. I do not have to let the Israelites go. I do not know the Lord. I will not let the Israelites go. ’"
    },
    {
      "verse": "3",
      "text": "Moses and Aaron said, ‘The God of the Israelites has met us. Please let us go. We must go on a journey of three days into the desert. There we must give gifts to the Lord our God. If we do not do this, God may punish us. We may become very ill, or people may attack us in war. ’"
    },
    {
      "verse": "4",
      "text": "But the king of Egypt said, ‘Moses and Aaron, you must not take the people away from their work! Go back to your jobs! ’"
    },
    {
      "verse": "5",
      "text": "Pharaoh said, ‘Look, there are now many of your people who live in my country. But you are taking them away from their work. ’"
    },
    {
      "verse": "6",
      "text": "On that day, Pharaoh gave a command to the masters of the slaves, and to the leaders of the work."
    },
    {
      "verse": "7",
      "text": "This was the command: ‘Do not give the people any more straw to make bricks. Now they must go and find their own straw."
    },
    {
      "verse": "8",
      "text": "But they must still make the same number of bricks as they did before. Do not let them make fewer bricks. These people are lazy. That is why they are complaining. They say, “We want to go and offer sacrifices to our God. ”"
    },
    {
      "verse": "9",
      "text": "Make the work more difficult for them to do. They will have to do very hard work. They will be too busy to listen to the lies of their leaders. ’"
    },
    {
      "verse": "10",
      "text": "So the slaves' masters and the leaders of the work went to the Israelite people. They said to them, ‘Pharaoh says, “Now I will not give you straw."
    },
    {
      "verse": "11",
      "text": "You must try to find straw for yourselves. But you will still have to make the same number of bricks. ” ’"
    },
    {
      "verse": "12",
      "text": "So the people went everywhere in the land of Egypt, to get straw from the fields."
    },
    {
      "verse": "13",
      "text": "The slaves' masters made the Israelites work quickly. They said, ‘Finish all your work for each day, as much as when we gave straw to you. ’"
    },
    {
      "verse": "14",
      "text": "Pharaoh's slave masters hit the Israelite leaders who had authority over the people. They said to them, ‘Why have you not made the complete number of bricks today, as you did before? ’"
    },
    {
      "verse": "15",
      "text": "Then the Israelite leaders of the work went to Pharaoh. They asked him, ‘Please sir, why do you do these things to us, your servants?"
    },
    {
      "verse": "16",
      "text": "Our masters no longer give us any straw. But they say “Make bricks! ” Then they hit us. But it is your people who are doing wrong things, not us. ’"
    },
    {
      "verse": "17",
      "text": "But Pharaoh said, ‘You Israelites are just lazy people! That is why you say, “Let us go to offer sacrifices to the Lord. ”"
    },
    {
      "verse": "18",
      "text": "Now go back and do your work. Nobody will give you any straw. But you must make the complete number of bricks. ’"
    },
    {
      "verse": "19",
      "text": "The Israelite work leaders heard Pharaoh say, ‘You must still make the same number of bricks as you made before. ’ Then they knew that they were in trouble."
    },
    {
      "verse": "20",
      "text": "When they left Pharaoh, they met Moses and Aaron. Moses and Aaron were waiting for them to return from Pharaoh."
    },
    {
      "verse": "21",
      "text": "The work leaders said to Moses and Aaron, ‘We hope that the Lord will punish you! You have made us like a bad smell to Pharaoh and to his officers. You have given them a reason to kill us. ’"
    },
    {
      "verse": "22",
      "text": "Then Moses returned to the Lord. He said, ‘My Lord, why have you brought trouble to these people? Why did you send me to lead them?"
    },
    {
      "verse": "23",
      "text": "I went to speak to Pharaoh with your authority. But since I spoke to Pharaoh, he has caused these people to have trouble. And you have done nothing to save your people. ’"
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "Then the Lord said to Moses, ‘Now you will see what I will do to Pharaoh. I will use my great power to make him let my people go. With my strong power I will cause him to make them leave his land. ’"
    },
    {
      "verse": "2",
      "text": "And God said to Moses, ‘I am the Lord."
    },
    {
      "verse": "3",
      "text": "I appeared to Abraham, to Isaac and to Jacob. I showed them that I am God Almighty. But I did not let them know me by my special name, the Lord."
    },
    {
      "verse": "4",
      "text": "I also made my covenant with them. I promised to give them the land of Canaan, where they were living as foreign people."
    },
    {
      "verse": "5",
      "text": "I have heard the Israelites when they cry in pain. I know that the Egyptians have caused the Israelites to be their slaves. Now I have thought about my covenant."
    },
    {
      "verse": "6",
      "text": "So you must say this to the Israelites: “I am the Lord. I will remove you from the power of the Egyptians. You will not have to do hard work to serve them as their slaves any more. I will use my strength to save you and I will punish the Egyptians."
    },
    {
      "verse": "7",
      "text": "I will cause you to be my own people, and I will be your God. Then you will know that I am the Lord. I am your God who saved you from the power of the Egyptians."
    },
    {
      "verse": "8",
      "text": "I will take you to live in another land. That is the land that I promised to give to Abraham, to Isaac and to Jacob. Yes, I will give it to you and it will belong to you. I am the Lord. ” ’"
    },
    {
      "verse": "9",
      "text": "Moses told the Lord's message to the Israelites. But they refused to listen to him. They were very weak and tired, because their Egyptian masters were so cruel to them."
    },
    {
      "verse": "10",
      "text": "Then the Lord said to Moses,"
    },
    {
      "verse": "11",
      "text": "‘Go and speak to Pharaoh, king of Egypt. Tell him that he must let the Israelites go out of his country. ’"
    },
    {
      "verse": "12",
      "text": "But Moses said to the Lord, ‘Look! Even the Israelites have not listened to me. So Pharaoh certainly will not listen to me. You know that I do not speak well. ’"
    },
    {
      "verse": "13",
      "text": "Then the Lord spoke to Moses and Aaron about the Israelites, and about Pharaoh, the king of Egypt. He commanded Moses and Aaron to lead the Israelites out of Egypt."
    },
    {
      "verse": "14",
      "text": "These were the leaders of their family clans: Israel's firstborn son was Reuben. Reuben's sons were: Hanoch, Pallu, Hezron and Carmi. These were Reuben's family clans. Israel's firstborn son was Reuben. Reuben's sons were: Hanoch, Pallu, Hezron and Carmi. These were Reuben's family clans."
    },
    {
      "verse": "15",
      "text": "The sons of Simeon: Jemuel, Jamin, Ohad, Jakin, Zohar and Shaul. Shaul was the son of a Canaanite woman. These were Simeon's family clans."
    },
    {
      "verse": "16",
      "text": "These are the names of the sons of Levi, from the oldest to the youngest: Gershon, Kohath and Merari. Levi himself lived for 137 years."
    },
    {
      "verse": "17",
      "text": "The sons of Gershon and their clans: Libni and Shimei."
    },
    {
      "verse": "18",
      "text": "The sons of Kohath: Amram, Izhar, Hebron and Uzziel. Kohath lived for 133 years."
    },
    {
      "verse": "19",
      "text": "The sons of Merari: Mahli and Mushi. These were the family clans of Levi, from the oldest to the youngest. These were the family clans of Levi, from the oldest to the youngest."
    },
    {
      "verse": "20",
      "text": "Amram married Jochebed, his father's sister. Aaron and Moses were their sons. Amram lived for 137 years."
    },
    {
      "verse": "21",
      "text": "The sons of Izhar: Korah, Nepheg and Zikri."
    },
    {
      "verse": "22",
      "text": "The sons of Uzziel: Mishael, Elzaphan and Sithri."
    },
    {
      "verse": "23",
      "text": "Aaron married Elisheba. She was the daughter of Amminadab and the sister of Nahshon. Elisheba's children were: Nadab and Abihu, Eleazar and Ithamar."
    },
    {
      "verse": "24",
      "text": "The sons of Korah: Assir, Elkanah and Abiasaph. These were Korah's family clans."
    },
    {
      "verse": "25",
      "text": "Aaron's son, Eleazar, married one of Putiel's daughters. Phinehas was their son. These were the leaders of the Levite family clans. These were the leaders of the Levite family clans."
    },
    {
      "verse": "26",
      "text": "This shows us the ancestors of Aaron and Moses. They were the men to whom the Lord spoke. He said to them, ‘Lead the Israelites out of Egypt. Lead them out in their families and clans, like an army. ’"
    },
    {
      "verse": "27",
      "text": "Moses and Aaron were the men who spoke to Pharaoh, king of Egypt. They told him that the Israelites would leave Egypt. They were the same Moses and Aaron as we read about in the list of Israelite families."
    },
    {
      "verse": "28",
      "text": "When the Lord spoke to Moses in the country of Egypt,"
    },
    {
      "verse": "29",
      "text": "he said, ‘I am the Lord. Tell Pharaoh, king of Egypt, everything that I say to you. ’"
    },
    {
      "verse": "30",
      "text": "But Moses said, ‘You know that I do not speak well. Pharaoh will not listen to me. ’"
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "Then the Lord said to Moses, ‘Look, I have made you like God to Pharaoh. Your brother Aaron will speak on your behalf, like your prophet."
    },
    {
      "verse": "2",
      "text": "You must say everything that I command you to say. Your brother Aaron must tell Pharaoh to let the Israelites go out of his country."
    },
    {
      "verse": "3",
      "text": "But I will make Pharaoh's mind become hard. I will do many miracles in Egypt that show my power."
    },
    {
      "verse": "4",
      "text": "But Pharaoh will still refuse to listen to you. Then I will show my authority and I will punish the Egyptians. I will bring my people, the Israelites, out of Egypt like an army."
    },
    {
      "verse": "5",
      "text": "Then the Egyptians will know that I am the Lord. I will show my great strength in Egypt and I will lead the Israelites out from there. ’"
    },
    {
      "verse": "6",
      "text": "Moses and Aaron obeyed all the commands of the Lord."
    },
    {
      "verse": "7",
      "text": "years old and Aaron was 83 years old when they spoke to Pharaoh."
    },
    {
      "verse": "8",
      "text": "The Lord said to Moses and Aaron,"
    },
    {
      "verse": "9",
      "text": "‘Pharaoh will say to you, “Show me a miracle. ” Then say to Aaron, “Take your stick and throw it down in front of Pharaoh. ” When Aaron does that, his stick will become a snake. ’"
    },
    {
      "verse": "10",
      "text": "So Moses and Aaron went to see Pharaoh. They did everything that the Lord had commanded them. Aaron threw down his stick in front of Pharaoh and his officers. And the stick became a snake!"
    },
    {
      "verse": "11",
      "text": "Then Pharaoh called for his wise men and his magicians to come to him. The Egyptian magicians did the same thing as Aaron. They used their secret magic to do it."
    },
    {
      "verse": "12",
      "text": "Each of them threw down his stick and it became a snake. But Aaron's stick ate all their sticks!"
    },
    {
      "verse": "13",
      "text": "But Pharaoh's mind was hard and he refused to listen to Moses and Aaron. That was what the Lord had said would happen, and it did!"
    },
    {
      "verse": "14",
      "text": "Then the Lord said to Moses, ‘Pharaoh's mind is still hard. He refuses to let the people go."
    },
    {
      "verse": "15",
      "text": "Go to Pharaoh in the morning when he goes to the river. Wait for him by the edge of the river. Then take in your hand the stick that became a snake."
    },
    {
      "verse": "16",
      "text": "Then say to Pharaoh, “The Lord, the God of the Israelites, has sent me to you to say, ‘Let my people go, so that they may worship me in the desert. ’ But until now, you have not listened to my message."
    },
    {
      "verse": "17",
      "text": "So this is what the Lord says: In this way, you will know that I am the Lord. Look! I will hit the water in the Nile river with the stick that is in my hand. Then the water will become blood."
    },
    {
      "verse": "18",
      "text": "The fish in the river will die, and the river will have a very bad smell. Then the Egyptians will not be able to drink the water from the Nile river. ” ’"
    },
    {
      "verse": "19",
      "text": "Then the Lord said to Moses, ‘Say to Aaron, “Take your stick. Lift up your hand over the waters of Egypt. Lift your stick up over their rivers and their streams. Lift it up over their lakes and pools of water. Do that so that all the water becomes blood. ” There will be blood in every part of Egypt. There will even be blood in their buckets and bowls. ’"
    },
    {
      "verse": "20",
      "text": "Moses and Aaron obeyed the command of the Lord. Aaron lifted up the stick in front of Pharaoh and his servants. He hit the water in the Nile river with the stick. Then all the water in the river became blood."
    },
    {
      "verse": "21",
      "text": "The fish in the river died. The river had such a bad smell that the Egyptians could not drink its water. There was blood in every part of Egypt."
    },
    {
      "verse": "22",
      "text": "But the Egyptian magicians used their magic and they did the same thing. So Pharaoh's mind continued to be hard. He still refused to listen to Moses and Aaron. The Lord had said that this would happen, and it did!"
    },
    {
      "verse": "23",
      "text": "Pharaoh turned away and he went into his house. He did not worry about what had happened."
    },
    {
      "verse": "24",
      "text": "The Egyptians dug holes on the shore of the Nile river to find water to drink. They could not drink the water from the river itself."
    },
    {
      "verse": "25",
      "text": "After the Lord had made the water in the river become blood, another seven days passed."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "The Lord said to Moses, ‘Go to Pharaoh and say to him, “This is the message from the Lord: Let my people go so that they may worship me."
    },
    {
      "verse": "2",
      "text": "If you refuse to let them go, I will send thousands of frogs to bring trouble to your whole country."
    },
    {
      "verse": "3",
      "text": "The Nile river will be full of frogs. The frogs will go into your house. They will jump into your bed. They will go into the houses of your servants. They will go into the houses of your people. They will jump into your ovens and into your dishes."
    },
    {
      "verse": "4",
      "text": "The frogs will jump all over you. They will jump on your people and on all your servants. ” ’"
    },
    {
      "verse": "5",
      "text": "Then the Lord said to Moses, ‘Say to Aaron, “Take your stick in your hand. Then raise your hand over the rivers, the streams and the pools. You will cause frogs to come up over the whole of Egypt. ” ’"
    },
    {
      "verse": "6",
      "text": "So Aaron lifted up his hand over the water of Egypt. Then the frogs came up and they covered the whole of Egypt."
    },
    {
      "verse": "7",
      "text": "But the magicians used their magic to do the same thing. They also made frogs come up on the land of Egypt."
    },
    {
      "verse": "8",
      "text": "Then Pharaoh called Moses and Aaron to come to him. He said, ‘Pray to the Lord. Ask him to remove the frogs from me and from my people. Then I will let your people go. They can offer sacrifices to the Lord. ’"
    },
    {
      "verse": "9",
      "text": "Moses said to Pharaoh, ‘I will let you choose the time when I should pray to God. Then I will ask God to do this for you, for your servants and for your people. I will ask God to remove the frogs from you and from all your houses. The frogs will remain only in the Nile river. ’"
    },
    {
      "verse": "10",
      "text": "Pharaoh said, ‘Do it tomorrow. ’ Moses answered, ‘I will do what you have asked. Then you will know that there is nobody like the Lord our God."
    },
    {
      "verse": "11",
      "text": "The frogs will go away from you and your houses. They will go away from your servants and your people. They will remain only in the river. ’"
    },
    {
      "verse": "12",
      "text": "So Moses and Aaron left Pharaoh. Then Moses prayed to the Lord about the frogs that he had brought to punish Pharaoh."
    },
    {
      "verse": "13",
      "text": "And the Lord did what Moses asked. The frogs in the houses, in the yards and in the fields all died."
    },
    {
      "verse": "14",
      "text": "The people swept the frogs together to make big heaps. There was a very bad smell over the whole country."
    },
    {
      "verse": "15",
      "text": "But when Pharaoh saw that the trouble had gone, his mind became hard again. He refused to listen to Moses and Aaron. The Lord had said that this would happen, and it did!"
    },
    {
      "verse": "16",
      "text": "Then the Lord said to Moses, ‘Say to Aaron, “Lift up your stick and hit the dirt on the ground. It will become gnats in the whole land of Egypt. ” ’"
    },
    {
      "verse": "17",
      "text": "Moses and Aaron obeyed God. Aaron lifted up his hand and he hit the dirt with his stick. The dirt became gnats that flew onto all the people and onto all the animals. The dirt on the ground became gnats all over Egypt."
    },
    {
      "verse": "18",
      "text": "Then the Egyptian magicians tried to use their magic to make gnats appear. But they could not do it. The gnats were on all the people and on all the animals."
    },
    {
      "verse": "19",
      "text": "Then the magicians said to Pharaoh, ‘This is the work of God. ’ But there was no change in Pharaoh's thoughts. He would not listen to them. The Lord had said that this would happen, and it did!"
    },
    {
      "verse": "20",
      "text": "Then the Lord said to Moses, ‘Get up early in the morning. Meet Pharaoh when he goes out to the river. Then say to him, “The Lord says: You must let my people go. Let them go to worship me."
    },
    {
      "verse": "21",
      "text": "If you do not let my people go, I will send thousands of flies on you. I will send them on your servants and on your people. I will send them into your houses. The houses of the Egyptians will be full of flies. The flies will cover all the ground where people live."
    },
    {
      "verse": "22",
      "text": "But it will be different in the region of Goshen, where my people live. I will not send flies there. Then you will know that I, the Lord, am doing my work here in this land."
    },
    {
      "verse": "23",
      "text": "I will make a difference between my people and your people. This miracle will happen tomorrow. ” ’"
    },
    {
      "verse": "24",
      "text": "That is what the Lord did. Great numbers of flies came into Pharaoh's house and into his servants' houses. The flies went all over Egypt and they destroyed the whole land."
    },
    {
      "verse": "25",
      "text": "Then Pharaoh called Moses and Aaron to come to him. He said to them, ‘Go! You can offer sacrifices to your God here, in Egypt. ’"
    },
    {
      "verse": "26",
      "text": "But Moses said, ‘It would not be right to do that. The Egyptians do not like our sacrifices of animals. If we offer these sacrifices to the Lord our God, the Egyptians will be angry with us. They will throw stones at us to kill us."
    },
    {
      "verse": "27",
      "text": "So we must go on a journey for three days into the desert. We will offer sacrifices to the Lord our God there, as he has told us to do. ’"
    },
    {
      "verse": "28",
      "text": "So Pharaoh said, ‘I will let you go. You may go into the desert and offer sacrifices to the Lord your God there. But do not go very far away. And pray for me too. ’"
    },
    {
      "verse": "29",
      "text": "Then Moses said, ‘I will leave you now, and I will pray to the Lord. Tomorrow, all the flies will go away from you, your officers and your people. But be careful! Do not deceive us, as you did before. You must really let the people go away to offer sacrifices to the Lord. ’"
    },
    {
      "verse": "30",
      "text": "So Moses left Pharaoh and he prayed to the Lord."
    },
    {
      "verse": "31",
      "text": "The Lord did what Moses asked him. All the flies left Pharaoh, his officers and his people. Not one fly remained!"
    },
    {
      "verse": "32",
      "text": "But again, Pharaoh's mind became hard. He refused to let the people go."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "Then the Lord said to Moses, ‘Go to Pharaoh and say to him, “The Lord, the God of the Israelites says this: Let my people go so that they may worship me."
    },
    {
      "verse": "2",
      "text": "If you refuse to let them go, you will have more trouble. If you still keep them in Egypt,"
    },
    {
      "verse": "3",
      "text": "the Lord will punish you. He will send a very bad illness on all your animals. Your animals in the fields, your horses, donkeys, camels, cows, sheep and goats will all become very ill."
    },
    {
      "verse": "4",
      "text": "But the Lord will make a difference between the animals of the Israelites and the animals of the Egyptians. None of the animals of the Israelites will die. ” ’"
    },
    {
      "verse": "5",
      "text": "The Lord decided when this would happen. He said, ‘Tomorrow I will make this happen in the land of Egypt. ’"
    },
    {
      "verse": "6",
      "text": "So on the next day, the Lord did it! All the animals of the Egyptians died. But not one of the animals of the Israelites died."
    },
    {
      "verse": "7",
      "text": "Pharaoh sent his men to see what had happened. They saw that not one of the animals of the Israelites was dead! But Pharaoh's mind was still hard. He did not let the people go."
    },
    {
      "verse": "8",
      "text": "Then the Lord said to Moses and Aaron, ‘Take in your hands some ashes from an oven. Throw them up in the air as Pharaoh watches."
    },
    {
      "verse": "9",
      "text": "They will become very small dust over the whole country of Egypt. The dust will cause boils to appear on the skin of people and animals. It will happen all over Egypt. ’"
    },
    {
      "verse": "10",
      "text": "So they took ashes from an oven and they stood in front of Pharaoh. Moses threw the ashes up in the air. Then bad boils appeared on both people and animals."
    },
    {
      "verse": "11",
      "text": "All the Egyptians had boils, even the magicians. Because of the boils, the magicians could not stand in front of Moses."
    },
    {
      "verse": "12",
      "text": "But Pharaoh refused to listen to Moses and Aaron. The Lord caused Pharaoh's mind to be hard. The Lord had told Moses that this would happen, and it did!"
    },
    {
      "verse": "13",
      "text": "Then the Lord said to Moses, ‘Get up early in the morning and go to Pharaoh. Say to him, “This is what the Lord, the God of the Israelites says: Let my people go to worship me."
    },
    {
      "verse": "14",
      "text": "This time, I will send all my troubles to punish you. I will send them against you, your officers and your people. I want you to know that there is nobody as great as me in the whole earth. That is why I am doing this."
    },
    {
      "verse": "15",
      "text": "Already I could have used my power to destroy you and your people. With one very bad trouble, I could have removed you from the earth."
    },
    {
      "verse": "16",
      "text": "But I have let you live, to show you my power. Then people all over the world will know how great I am."
    },
    {
      "verse": "17",
      "text": "You are still too proud to let my people go."
    },
    {
      "verse": "18",
      "text": "Look! Tomorrow at this time, I will send a very great storm of hail. Nobody has ever seen hail fall like this in Egypt before now. From Egypt's first day as a country until today, nobody has seen a storm like this."
    },
    {
      "verse": "19",
      "text": "Now send your servants out to tell this message to your people. You must bring into your houses all your animals from the fields to be safe. The hail will fall on every person and on every animal that is still outside. They will all die. ” ’"
    },
    {
      "verse": "20",
      "text": "Some of Pharaoh's officers were afraid of what the Lord said he would do. So they quickly brought their servants and animals inside their houses."
    },
    {
      "verse": "21",
      "text": "But others did not believe the Lord's message. They left their servants and animals outside in the fields."
    },
    {
      "verse": "22",
      "text": "Then the Lord said to Moses, ‘Lift up your hand towards the sky. Then hail will fall over all the country of Egypt. It will fall on people and on animals. It will fall on all the plants that grow in the fields of Egypt. ’"
    },
    {
      "verse": "23",
      "text": "When Moses lifted up his stick towards the sky, the Lord sent a great storm. He sent thunder, hail and lightning."
    },
    {
      "verse": "24",
      "text": "The hail fell and there was lightning like fire. It was the worst storm anywhere in Egypt since Egypt had become a nation."
    },
    {
      "verse": "25",
      "text": "Everywhere in Egypt, the hail knocked down everything that was in the fields. It knocked down both people and animals. It knocked down all the plants in the fields and it broke all the trees."
    },
    {
      "verse": "26",
      "text": "But no hail fell in the region of Goshen, where the Israelites lived."
    },
    {
      "verse": "27",
      "text": "Then Pharaoh called Moses and Aaron to come to him. He said to them, ‘This time, I have done a bad thing. The Lord is right. I and my people are guilty."
    },
    {
      "verse": "28",
      "text": "The storms with the thunder and the hail are too much for us! Pray to the Lord to take them away. Then I will let you go! You do not need to stay any longer in Egypt. ’"
    },
    {
      "verse": "29",
      "text": "Then Moses said to Pharaoh, ‘As soon as I leave the city, I will lift my hands to the Lord and I will pray to him. The storm will stop and there will be no more hail. Then you will know that the whole world belongs to the Lord."
    },
    {
      "verse": "30",
      "text": "But I know you and your officers. You still do not respect the Lord God. ’"
    },
    {
      "verse": "31",
      "text": "At that time, the barley was ripe in the fields and the flax was nearly ripe. So the storm of hail destroyed the flax and the barley."
    },
    {
      "verse": "32",
      "text": "But the hail did not destroy the wheat and other grains. Those crops become ripe later in the year."
    },
    {
      "verse": "33",
      "text": "Then Moses left Pharaoh and he went out of the city. He lifted up his hands to the Lord and he prayed. Then the storms and the hail stopped. The heavy rain stopped falling on the earth."
    },
    {
      "verse": "34",
      "text": "Pharaoh saw that the rain and the hail and the storms had stopped. So he did a bad thing again. His mind and his officers' minds became hard."
    },
    {
      "verse": "35",
      "text": "Pharaoh still refused to obey God. He did not let the Israelites go. The Lord had told Moses that this would happen, and it did!"
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "Then the Lord said to Moses, ‘Go to see Pharaoh. I have caused his mind to become hard. I have also caused his officers' minds to become hard. I have done this so that I can do miracles to show him my power."
    },
    {
      "verse": "2",
      "text": "In the future, you can tell your children and your children's children how I punished the Egyptians. You can tell them about the miracles that I did among the Egyptians. In this way, you will know that I am the Lord. ’"
    },
    {
      "verse": "3",
      "text": "So Moses and Aaron went to Pharaoh. They said to him, ‘The Lord, the God of the Israelites says this: “You are still too proud to obey me. Let my people go so that they may worship me."
    },
    {
      "verse": "4",
      "text": "If you refuse to let them go, I will bring locusts into your country tomorrow."
    },
    {
      "verse": "5",
      "text": "They will cover the whole country. Nobody will be able to see the ground. They will eat everything that the hail did not destroy. They will eat any crops that you still have. That will include every tree that is growing in your fields."
    },
    {
      "verse": "6",
      "text": "They will fill your houses, and your officers' houses. They will fill all the houses in Egypt! It will be worse than anything that your fathers or your grandfathers have ever seen. Nothing like this has ever happened in Egypt before now. ” ’ Then Moses turned away and left Pharaoh."
    },
    {
      "verse": "7",
      "text": "Pharaoh's officers said to him, ‘Will you let this man bring trouble to us for ever? Allow the people to go. Then they can worship the Lord their God. Surely you understand by now that this man has destroyed Egypt! ’"
    },
    {
      "verse": "8",
      "text": "So Pharaoh's officers took Moses and Aaron back to him. Pharaoh said to them, ‘Go and worship the Lord your God. But tell me, who will go? ’"
    },
    {
      "verse": "9",
      "text": "Moses said, ‘We will all go, both young people and old people. We will take our sons and daughters. We will also take our animals, because we must have a feast to worship the Lord. ’"
    },
    {
      "verse": "10",
      "text": "Pharaoh said to them, ‘No! If I let you go with your families like that, you will need the Lord to take care of you! I can see that you want to make trouble."
    },
    {
      "verse": "11",
      "text": "No! If you really want to go and worship the Lord, only the men can go. ’ Pharaoh was angry and he told Moses and Aaron to go away."
    },
    {
      "verse": "12",
      "text": "Then the Lord said to Moses, ‘Lift up your hand over the country of Egypt. Then locusts will fly all over the land. They will eat every plant that grows in the ground. They will eat everything that the hail has not destroyed. ’"
    },
    {
      "verse": "13",
      "text": "So Moses lifted up his stick over the country of Egypt. Then the Lord caused an east wind to blow across the land, for the whole day and the whole night. In the morning, the east wind had brought the locusts."
    },
    {
      "verse": "14",
      "text": "The locusts flew into every part of the country of Egypt. Thousands of locusts sat on everything. There had never been so many locusts in Egypt before. And it will never happen again."
    },
    {
      "verse": "15",
      "text": "The locusts covered all the ground, until the ground became black with locusts. They ate all the plants that grew in the ground, and all the fruit of the trees. They ate everything that the hail had not destroyed. Not one green thing remained on any tree or plant, in all the country of Egypt."
    },
    {
      "verse": "16",
      "text": "Then Pharaoh quickly called Moses and Aaron to come to him. He said, ‘I have done bad things against the Lord your God and against you."
    },
    {
      "verse": "17",
      "text": "Please forgive my sins just one more time. Ask the Lord your God to remove this punishment of death from me. ’"
    },
    {
      "verse": "18",
      "text": "Moses left Pharaoh and he prayed to the Lord."
    },
    {
      "verse": "19",
      "text": "Then the Lord changed the wind to a very strong west wind. This wind lifted the locusts up and it blew them away into the Red Sea. Not one locust remained in all the country of Egypt."
    },
    {
      "verse": "20",
      "text": "But the Lord caused Pharaoh's mind to become hard again. Pharaoh would not let the Israelites go."
    },
    {
      "verse": "21",
      "text": "Then the Lord said to Moses, ‘Lift up your hand towards the sky. Then it will become dark over the whole country of Egypt. It will be so dark that people will be able to feel it. ’"
    },
    {
      "verse": "22",
      "text": "So Moses lifted up his hand towards the sky and it became completely dark. It was dark through the whole country of Egypt for three days."
    },
    {
      "verse": "23",
      "text": "People could not see each other. Nobody could move anywhere for three days. But the Israelites had light in the places where they lived."
    },
    {
      "verse": "24",
      "text": "Then Pharaoh called Moses to come to him. He said, ‘Go and worship the Lord. Even your families may go with you. Only your animals must remain in Egypt. ’"
    },
    {
      "verse": "25",
      "text": "But Moses said, ‘Then you will have to give us animals for our sacrifices and burnt offerings. We need our animals to offer to the Lord our God."
    },
    {
      "verse": "26",
      "text": "So we must take our animals with us. Not one animal can remain behind. We must take them to worship the Lord our God. Until we arrive in the desert, we will not know which animals to use as sacrifices. ’"
    },
    {
      "verse": "27",
      "text": "But the Lord caused Pharaoh's mind to be hard. Pharaoh would not agree to let the Israelites go."
    },
    {
      "verse": "28",
      "text": "Pharaoh said to Moses, ‘Go away from me! Be careful not to come back! I never want to see you again! On the day that you see my face, you will die! ’"
    },
    {
      "verse": "29",
      "text": "Moses replied, ‘You are right! You will never see me again. ’"
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "The Lord said to Moses, ‘I will cause Pharaoh and Egypt to have one more trouble. Then Pharaoh will let you go out of Egypt. He will cause you to leave very quickly and go away from him."
    },
    {
      "verse": "2",
      "text": "So tell the Israelite people now what they must do. Every man and every woman must ask the Egyptians that live near them for gold things and silver things. ’"
    },
    {
      "verse": "3",
      "text": "The Lord caused the Egyptians to be kind to the Israelite people. As for Moses himself, Pharaoh's officers and the Egyptian people respected him as an important man."
    },
    {
      "verse": "4",
      "text": "So Moses went to the king and he said, ‘The Lord God says this: “At about midnight, I will travel through the whole country of Egypt."
    },
    {
      "verse": "5",
      "text": "I will cause all the firstborn sons in Egypt to die. The firstborn son of Pharaoh, king of Egypt, will die. The firstborn son of the female slave who makes flour, will die. Even the firstborn of the farm animals will die."
    },
    {
      "verse": "6",
      "text": "Everyone will be crying loudly in the whole country of Egypt. Nothing like that has ever happened before now, and it will never happen again."
    },
    {
      "verse": "7",
      "text": "But no trouble will happen to the Israelite people. Not even a dog will frighten them or their animals. Then you will know that I, the Lord, make a difference between Egypt and Israel. ” ’"
    },
    {
      "verse": "8",
      "text": "Moses continued to say to the king, ‘All your officers will come to me. They will fall down in front of me and they will say, “Now go! Leave here with all your people. ” After that, I will leave. ’After he said that, Moses left Pharaoh. Moses was very angry. After he said that, Moses left Pharaoh. Moses was very angry."
    },
    {
      "verse": "9",
      "text": "The Lord had already said to Moses, ‘Pharaoh will refuse to listen to you. But that will give me the chance to do even greater miracles in Egypt. ’"
    },
    {
      "verse": "10",
      "text": "Moses and Aaron did all these miracles in front of Pharaoh. But the Lord caused Pharaoh's mind to be hard. So Pharaoh would not let the Israelites leave his country."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "The Lord spoke to Moses and Aaron in the country of Egypt."
    },
    {
      "verse": "2",
      "text": "He said, ‘This month will be the first month of each year for you."
    },
    {
      "verse": "3",
      "text": "Tell all the Israelite people to do this on the tenth day of this month: Each man must choose a lamb to kill as a sacrifice for his family. That will be one lamb for each home."
    },
    {
      "verse": "4",
      "text": "But the family may be too small to eat a whole lamb. Then they must share a lamb with another family that lives near. You must decide how much each person can eat and then count the number of people."
    },
    {
      "verse": "5",
      "text": "The lamb that you choose must have nothing wrong with it. It must be a male lamb that is one year old. It can be either a young sheep or a young goat."
    },
    {
      "verse": "6",
      "text": "Keep the lamb safe until the 14th day of this month. Then every Israelite family must kill their lamb in the evening."
    },
    {
      "verse": "7",
      "text": "They must take some of its blood. They must put the blood on the wood that is round the door of their house. They must put it on each side of the door and above the door. They must do this in every house where they will eat a lamb."
    },
    {
      "verse": "8",
      "text": "That night, they must cook the meat over the fire. They must eat it immediately, with bitter herbs and with bread that has no yeast in it."
    },
    {
      "verse": "9",
      "text": "You must cook the meat before you eat it. Cook it over the fire. Do not cook it in water. Cook the whole lamb, with its head, its legs and the inside parts of its body."
    },
    {
      "verse": "10",
      "text": "You must eat all the meat before morning arrives. If some of it still remains in the morning, then you must burn it."
    },
    {
      "verse": "11",
      "text": "This is how you must eat the lamb: Dress yourselves so that you are ready to travel. Put your shoes on your feet. Take your stick in your hand. Then eat the food quickly. This is the Passover meal which shows that you obey me, the Lord."
    },
    {
      "verse": "12",
      "text": "On the night that you eat the Passover meal, I will travel through the country of Egypt. I will kill every firstborn son and every firstborn male animal. I will punish all the gods of Egypt. I am the Lord."
    },
    {
      "verse": "13",
      "text": "When you put the blood round the doors of your houses, that will be a sign to show that you live there. When I see the blood on your house, I will pass over you. No trouble will hurt you, when I attack the people of Egypt."
    },
    {
      "verse": "14",
      "text": "In future years, you must remember this day as a special day every year. It will be a festival when you worship me, the Lord. You and your descendants must do this every year, for all time."
    },
    {
      "verse": "15",
      "text": "For seven days, you must eat flat bread that has no yeast in it. On the first day of the Passover festival, you must take all the yeast out of your houses. During those seven days, if anyone eats bread with yeast in it, he will no longer belong to my people, the Israelites."
    },
    {
      "verse": "16",
      "text": "On the first day of the festival, you must bring together all the people to a special meeting. And you must do the same thing on the seventh day. On these special days, you must not do your usual work. You may prepare the food that you need to eat on those days. That is the only work that you may do."
    },
    {
      "verse": "17",
      "text": "This will be the Feast of Flat Bread, when you eat bread with no yeast in it. You will remember that I brought you all out of the country of Egypt on this day. You marched out like an army, family by family! That is why you must enjoy this day as a special day, for all time. This is a rule that you must always obey."
    },
    {
      "verse": "18",
      "text": "In the first month of each year, you must eat bread without yeast in it. Do this from the evening of the 14th day until the evening of the 21st day."
    },
    {
      "verse": "19",
      "text": "For those seven days, you must not have any yeast in your houses. Whoever eats anything with yeast in it will no longer belong to my people, the Israelites. Everyone must obey these rules, those who live among you as strangers, as well as those who have been born in your land."
    },
    {
      "verse": "20",
      "text": "Eat nothing that has yeast in it. Whatever country you live in, you must eat bread without yeast in it. ’"
    },
    {
      "verse": "21",
      "text": "Then Moses called the leaders of the Israelites to come to him. He said to them, ‘Go immediately and choose a lamb for each of your families. Then kill the animals for the Passover feast."
    },
    {
      "verse": "22",
      "text": "Put the blood into a dish. Then take a branch of hyssop. Make it wet with the blood that is in the dish. Then put some of the blood on the wood that is round your door. Nobody must go out of the door of his house until the morning."
    },
    {
      "verse": "23",
      "text": "The Lord will pass through the country and he will kill the Egyptians. But when the Lord sees the blood on the wood round the door, he will pass over that house. He will not let the death angel come into your houses. The Lord will not let him kill you."
    },
    {
      "verse": "24",
      "text": "You must obey these rules always, both you and your descendants, for all time."
    },
    {
      "verse": "25",
      "text": "You will go into the land that the Lord promised to give you. Then you must continue to obey these rules."
    },
    {
      "verse": "26",
      "text": "Your children may say to you, “What does this feast mean? ”"
    },
    {
      "verse": "27",
      "text": "Then you must say to them, “It is the Lord's Passover sacrifice. The Lord passed over the houses of the Israelites when they were in Egypt. He killed the Egyptians but he saved our families. ” ’ Then the people bent their heads down to the ground and they worshipped God."
    },
    {
      "verse": "28",
      "text": "The Israelites did everything that the Lord had commanded Moses and Aaron."
    },
    {
      "verse": "29",
      "text": "At midnight, the Lord killed all the firstborn sons in the land of Egypt. The firstborn son of Pharaoh, the king, died. But also, the firstborn son of any man who was in prison died. Every firstborn son in Egypt died. All the firstborn animals also died."
    },
    {
      "verse": "30",
      "text": "Pharaoh and all his officers woke up in the middle of the night. All the Egyptians also woke up in the middle of the night. Everyone was crying loudly everywhere in Egypt. In every home, somebody had died that night."
    },
    {
      "verse": "31",
      "text": "During the night, Pharaoh called Moses and Aaron to come to him. He said, ‘Get out of here! Take all the Israelites with you and go away from my people! Go and worship the Lord, as you asked me before."
    },
    {
      "verse": "32",
      "text": "Take all your animals with you, as you have said. Just go away! But also pray that God will bless me. ’"
    },
    {
      "verse": "33",
      "text": "The Egyptians were telling the Israelites to leave quickly. They wanted them to go out of the country immediately. The Egyptians said, ‘If we do not send them away immediately, we will all die! ’"
    },
    {
      "verse": "34",
      "text": "So the Israelites took their bread before they had cooked it. They had not even put the yeast into it. They put the bread in dishes and they put clothes round the dishes. Then they carried the dishes on their shoulders."
    },
    {
      "verse": "35",
      "text": "The Israelites obeyed Moses. They asked the Egyptians for silver and gold. They also asked them for clothes."
    },
    {
      "verse": "36",
      "text": "The Lord had caused the Egyptians to be kind to the Israelites. Because of this, the Egyptians gave the Israelites everything that they asked for. In that way, the Israelites took away all the valuable things that belonged to the Egyptians."
    },
    {
      "verse": "37",
      "text": "The Israelites travelled from Rameses to Succoth. There were about 600, 000 men who walked. There were also many women and children."
    },
    {
      "verse": "38",
      "text": "Many other people also travelled with them. They had a very large number of sheep, goats and cows."
    },
    {
      "verse": "39",
      "text": "The Israelites cooked the bread that they had brought with them from Egypt. It had no yeast in it, because they had to leave Egypt quickly. The Egyptians did not let them wait. So the Israelites did not have time to prepare any food for themselves."
    },
    {
      "verse": "40",
      "text": "years."
    },
    {
      "verse": "41",
      "text": "years that all the Lord's people left Egypt. They left in family groups, like an army."
    },
    {
      "verse": "42",
      "text": "The Lord carefully watched his people all that night, when he brought them out of Egypt. Because of that, all Israelites must watch carefully during this special night. They and their descendants must do this every year, to thank the Lord."
    },
    {
      "verse": "43",
      "text": "Then the Lord said to Moses and Aaron, ‘These are the rules for the Passover festival: No foreign person may eat the Passover meal."
    },
    {
      "verse": "44",
      "text": "If you buy a foreign slave, you must first circumcise him. Then he may eat the food."
    },
    {
      "verse": "45",
      "text": "But if you pay him money for his work, he must not eat the food. A visitor also must not eat the food."
    },
    {
      "verse": "46",
      "text": "You must eat the meal in one house. You must not take any of the meat outside the house. You must not break any of the bones in the meat."
    },
    {
      "verse": "47",
      "text": "All the Israelites must enjoy the feast together."
    },
    {
      "verse": "48",
      "text": "There may be a foreign person who lives among you. He may want to join you to eat the Lord's Passover meal. But he must first be circumcised as well as all the men in his house. Then he can join with you and eat the Passover meal. He will be like a man who has been born in Israel. But no male person without circumcision can join the Passover feast."
    },
    {
      "verse": "49",
      "text": "Both the people who were born as Israelites and the foreign people who live among you must obey this rule. ’"
    },
    {
      "verse": "50",
      "text": "All the Israelites did everything that the Lord had commanded Moses and Aaron."
    },
    {
      "verse": "51",
      "text": "On that same day, the Lord brought the Israelites out of Egypt, in family groups, like an army."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "The Lord spoke to Moses."
    },
    {
      "verse": "2",
      "text": "He said, ‘Keep every firstborn male separate and special for me. Every male who is the first to be born of his mother is mine. He is mine, whether he is man or animal. ’"
    },
    {
      "verse": "3",
      "text": "Moses said to the people, ‘Remember this day, the day when you came out of Egypt. You left the place where you were slaves. The Lord brought you out with his powerful authority. Remember! Do not eat anything that has yeast in it on this day."
    },
    {
      "verse": "4",
      "text": "Today you are leaving Egypt. It is the first month of the year, called Abib."
    },
    {
      "verse": "5",
      "text": "The Lord will bring you to the land of the Canaanites, the Hittites, the Amorites, the Hivites and the Jebusites. God promised your ancestors that he would give that land to you. The land will give you plenty of good food and drink, enough for everyone. When the Lord brings you into that place, you must eat the Passover meal to worship God in this month every year."
    },
    {
      "verse": "6",
      "text": "For seven days you must eat bread without yeast in it. Then on the seventh day you must have a festival for the Lord."
    },
    {
      "verse": "7",
      "text": "Eat bread without yeast during those seven days. There must not be any yeast left among you, in the whole of your land."
    },
    {
      "verse": "8",
      "text": "On that day, you must tell your children the reason for this festival. Tell them, “We do this because of what the Lord did for us. He brought us out of Egypt. ”"
    },
    {
      "verse": "9",
      "text": "This special time will be like a mark on your hand. It will be like something that you fix between your eyes. It will be a sign that causes you to remember what happened on this day. Then you will not forget to speak about the Law of the Lord. Remember this: The Lord brought you out of Egypt with his great power."
    },
    {
      "verse": "10",
      "text": "Every year, at the right time you must do what I have said."
    },
    {
      "verse": "11",
      "text": "The Lord will bring you into the land of the Canaanites. It is the land that he promised to give to you and to your ancestors. When he gives it to you, you must do this:"
    },
    {
      "verse": "12",
      "text": "You must give to the Lord all the firstborn males. That includes your own firstborn sons, and the male animals that are born first. They belong to the Lord."
    },
    {
      "verse": "13",
      "text": "When a donkey gives birth to her first male, you must give a lamb to God, instead of the donkey. If you do not do that, you must kill the donkey. You must break its neck. For any of your own firstborn sons, you must give an animal instead of your son."
    },
    {
      "verse": "14",
      "text": "One day, your son may ask you, “What does this mean? ” Then you must say to him, “The Lord brought us out of Egypt with his powerful authority. He took us away from the place where we were slaves."
    },
    {
      "verse": "15",
      "text": "Pharaoh refused to let us go. But the Lord killed all the firstborn sons in the country of Egypt. He killed all the firstborn males, both people and animals. That is why I offer all the firstborn male animals as a sacrifice to the Lord. But for each of my firstborn sons, I give an animal to God instead. ”"
    },
    {
      "verse": "16",
      "text": "It will be like a mark on your hand or something that you fix between your eyes. It will be a sign that causes you to remember what happened. You will remember that the Lord used his great power to bring us out of Egypt. ’"
    },
    {
      "verse": "17",
      "text": "When Pharaoh let the people go away, God did not lead them through the country of the Philistines. This was a short way for them to go, but God did not lead them that way. God said, ‘If the people have to fight a war, they may change their minds. Then they may return to Egypt. ’"
    },
    {
      "verse": "18",
      "text": "So God led the people round by the desert road. They went towards the Red Sea. When the Israelites came out of the country of Egypt, they were ready to fight."
    },
    {
      "verse": "19",
      "text": "Moses took Joseph's bones with him. Joseph had made the Israelites promise to do this. He had said, ‘One day, God will come and he will save you. Then you must carry my bones with you when you leave this place. ’"
    },
    {
      "verse": "20",
      "text": "The Israelites travelled from Succoth and they arrived at Etham. They put up their tents there, on the edge of the desert."
    },
    {
      "verse": "21",
      "text": "As they travelled, the Lord was leading them. During the day, he was there as a pillar of cloud that went in front of them. During the night, he went as a pillar of fire. This gave them light, so they could travel during the day or the night."
    },
    {
      "verse": "22",
      "text": "The cloud did not leave the people during the day. Nor did the fire leave them during the night. It was always in front of them."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "Then the Lord said to Moses, The Israelites did what God said."
    },
    {
      "verse": "2",
      "text": "‘Tell the Israelites that they must turn round. They must go and stay near Pi-Hahiroth, between Migdol and the sea. You must put up your tents beside the sea, across from Baal Zephon."
    },
    {
      "verse": "3",
      "text": "Then Pharaoh will think, “The Israelites are confused. They do not know where they are going. The desert has stopped them. ”"
    },
    {
      "verse": "4",
      "text": "Then I will cause Pharaoh's mind to become hard again. He will go to catch the Israelites. I will show how great I am when I win against Pharaoh and his whole army. Because of this, the Egyptians will know that I am the Lord. ’The Israelites did what God said."
    },
    {
      "verse": "5",
      "text": "Someone told the king of Egypt that the Israelites had run away. Then Pharaoh and his officers changed their minds about the Israelites. They said, ‘We have done a foolish thing. We have let the Israelites go. We have lost our slaves! ’"
    },
    {
      "verse": "6",
      "text": "So Pharaoh prepared his chariot and he took his army with him."
    },
    {
      "verse": "7",
      "text": "of his best chariots with him. , as well as all the other chariots of Egypt. All the chariots had officers to drive them."
    },
    {
      "verse": "8",
      "text": "The Lord caused the mind of Pharaoh, king of Egypt, to be hard. So Pharaoh followed after the Israelites, when they left Egypt without any fear."
    },
    {
      "verse": "9",
      "text": "The Egyptian soldiers followed after the Israelites to catch them. They went with all Pharaoh's horses, chariots and officers. The Egyptian army reached the place where the Israelites had put up their tents. That was beside the sea, near Pi-Hahiroth, across from Baal Zephon."
    },
    {
      "verse": "10",
      "text": "When Pharaoh came nearer, the Israelites looked up. They saw that the Egyptian army had followed them. The Israelites became very afraid. They called loudly to the Lord to help them."
    },
    {
      "verse": "11",
      "text": "They said to Moses, ‘Why have you brought us here, to die in the desert? Surely there were enough places in Egypt to bury dead people! You should never have brought us out of Egypt!"
    },
    {
      "verse": "12",
      "text": "We said to you in Egypt, “Leave us alone. Let us work for the Egyptians. ” It would have been better for us to be their slaves than to die here in the desert! ’"
    },
    {
      "verse": "13",
      "text": "Then Moses said to the people, ‘Do not be afraid! Be brave! You will see how the Lord will save you today. Look at the Egyptians over there. You will never see them again!"
    },
    {
      "verse": "14",
      "text": "The Lord will fight for you. You will only have to watch. ’"
    },
    {
      "verse": "15",
      "text": "Then the Lord said to Moses, ‘Do not continue to call to me for help! Tell the Israelites to move on."
    },
    {
      "verse": "16",
      "text": "You yourself must do this: Lift up your stick and hold your hand out over the sea. The water will become two separate parts. Then the Israelites can cross through the middle of the sea on dry ground."
    },
    {
      "verse": "17",
      "text": "This is what I, the Lord, will do: I will cause the minds of the Egyptians to become hard. They will follow the Israelites into the sea to catch them. I will show how great I am when I win against Pharaoh and all his army, his chariots, his horses and their riders."
    },
    {
      "verse": "18",
      "text": "When I do that, the Egyptians will know that I really am the Lord. They will know that I am great. ’"
    },
    {
      "verse": "19",
      "text": "The angel of God had been leading the army of the Israelites. Now he moved and he went behind them. The pillar of cloud moved and it stood behind the army."
    },
    {
      "verse": "20",
      "text": "It stood between the Egyptian army and the Israelite army. During the whole night, the Egyptians were in the dark, because of the cloud. But the cloud gave light to the Israelites. So the two armies did not come near to each other during the whole night."
    },
    {
      "verse": "21",
      "text": "Then Moses lifted up his hand over the sea. During that whole night, the Lord made a strong wind blow from the east. This caused the sea to become two separate parts. The ground between the water became dry land."
    },
    {
      "verse": "22",
      "text": "So the Israelites walked on the dry ground through the middle of the sea. The water was like a wall on their right side and on their left side."
    },
    {
      "verse": "23",
      "text": "The Egyptians followed the Israelites into the middle of the sea to catch them. All Pharaoh's horses, his chariots and their riders did this."
    },
    {
      "verse": "24",
      "text": "Just before dawn, the Lord looked down from the pillar of cloud with fire in it. He saw the Egyptian army and he made them become confused."
    },
    {
      "verse": "25",
      "text": "He stopped the wheels of their chariots, so that the Egyptians could not drive them properly. So the Egyptians said, ‘Let us run away from the Israelite army! It is the Lord who fights for them against Egypt. ’"
    },
    {
      "verse": "26",
      "text": "Then the Lord said to Moses, ‘Lift up your hand over the sea. Then the water will return back. The sea will cover the Egyptians, their chariots, their horses and their riders. ’"
    },
    {
      "verse": "27",
      "text": "So Moses lifted up his hand over the sea. At dawn, the sea returned to its proper place. The Egyptians tried to run away from the water, but the Lord made them drown in the middle of the sea."
    },
    {
      "verse": "28",
      "text": "The water returned to its proper place. It covered all of Pharaoh's army that had followed the Israelites into the sea. It covered all the chariots, the horses and their riders. Not one of Pharaoh's soldiers was still alive!"
    },
    {
      "verse": "29",
      "text": "But the Israelites walked on dry ground through the middle of the sea. The water was like a wall on their right side and on their left side."
    },
    {
      "verse": "30",
      "text": "On that day, the Lord saved the Israelites from the Egyptian army. The Israelites saw the dead bodies of the Egyptians, which lay on the shore."
    },
    {
      "verse": "31",
      "text": "The Israelites saw the great power that the Lord had used against the Egyptians. As a result, they respected the Lord and his power. They trusted the Lord to help them, and they also trusted Moses, his servant."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "Then Moses and the Israelites sang this song to praise the Lord:‘I will sing to the Lord, because he has shown his great power. He threw horses and their riders into the sea. ‘I will sing to the Lord, because he has shown his great power. He threw horses and their riders into the sea."
    },
    {
      "verse": "2",
      "text": "The Lord makes me strong. He is the reason for my song. He is the one who has saved me. He is my God and I will praise him. He is my father's God and I will praise his name. He is the one who has saved me. He is my God and I will praise him. He is my father's God and I will praise his name."
    },
    {
      "verse": "3",
      "text": "The Lord is like a brave soldier. The Lord is his name. The Lord is his name."
    },
    {
      "verse": "4",
      "text": "He threw Pharaoh's chariots and his army into the sea. Pharaoh's best officers drowned in the Red Sea. Pharaoh's best officers drowned in the Red Sea."
    },
    {
      "verse": "5",
      "text": "The deep waters have covered them. They fell to the floor of the sea, like a stone. They fell to the floor of the sea, like a stone."
    },
    {
      "verse": "6",
      "text": "Your right hand, Lord, was great and powerful. Your right hand, Lord, destroyed the enemy. Your right hand, Lord, destroyed the enemy."
    },
    {
      "verse": "7",
      "text": "With your powerful authority, you killed your enemies. You were very angry with them. You killed them, like a fire burns dry grass. You were very angry with them. You killed them, like a fire burns dry grass."
    },
    {
      "verse": "8",
      "text": "You blew on the water and it became like a wall. The deep waters stood up in a big heap. The deep waters stood up in a big heap."
    },
    {
      "verse": "9",
      "text": "The enemy said, “We will go after them. We will catch them. We will destroy them with our swords. We will do whatever we want to them. We will take all their valuable things for ourselves. ” We will destroy them with our swords. We will do whatever we want to them. We will take all their valuable things for ourselves. ”"
    },
    {
      "verse": "10",
      "text": "But Lord, you blew on the watersso that the sea covered your enemies. They went down like heavy metal in the great waters. so that the sea covered your enemies. They went down like heavy metal in the great waters."
    },
    {
      "verse": "11",
      "text": "Lord, there is nobody like you among all the gods! There is nobody like you anywhere! You are great and holy. Everyone should respect you and praise you. You do great miracles. There is nobody like you! There is nobody like you anywhere! You are great and holy. Everyone should respect you and praise you. You do great miracles. There is nobody like you!"
    },
    {
      "verse": "12",
      "text": "You lifted up your right hand. A big hole opened in the ground and our enemies fell into it. A big hole opened in the ground and our enemies fell into it."
    },
    {
      "verse": "13",
      "text": "You have promised to love your people. So you have saved them and you lead them. With your strength, you show them the way to your holy home. So you have saved them and you lead them. With your strength, you show them the way to your holy home."
    },
    {
      "verse": "14",
      "text": "The people of other nations will hear what you have done. They will be very afraid. The people who live in Philistia will shake with fear. They will be very afraid. The people who live in Philistia will shake with fear."
    },
    {
      "verse": "15",
      "text": "The rulers of Edom will be afraid. The leaders of Moab will shake with fear. The people who live in Canaan will become weak. The leaders of Moab will shake with fear. The people who live in Canaan will become weak."
    },
    {
      "verse": "16",
      "text": "They will all be afraid. Because of your great power they will want to run away. But they cannot move! They will remain still, like stones, until your people go on past them. They will stand and watch as the people you have saved, Lord, pass by. Because of your great power they will want to run away. But they cannot move! They will remain still, like stones, until your people go on past them. They will stand and watch as the people you have saved, Lord, pass by."
    },
    {
      "verse": "17",
      "text": "You will bring your people in safely. You will bring them to live on your own mountain. Lord, that is the place that you have prepared for your home. It is the holy place that you have built, Lord. You will bring them to live on your own mountain. Lord, that is the place that you have prepared for your home. It is the holy place that you have built, Lord."
    },
    {
      "verse": "18",
      "text": "The Lord will rule as king for ever!"
    },
    {
      "verse": "19",
      "text": "Pharaoh's horses, his chariots and his soldiers went into the sea. Then the Lord made the waters of the sea come back over them. But the Israelites walked through the middle of the sea on dry ground. ’ Then the Lord made the waters of the sea come back over them. But the Israelites walked through the middle of the sea on dry ground. ’"
    },
    {
      "verse": "20",
      "text": "Then Miriam, Aaron's sister, who was a prophet, took a tambourine in her hand. All the other women followed her, with tambourines in their hands. They danced while Miriam sang to them."
    },
    {
      "verse": "21",
      "text": "This is the song that she sang:‘Sing to the Lord, because he has shown his great power. He threw horses and their riders into the sea. ’ ‘Sing to the Lord, because he has shown his great power. He threw horses and their riders into the sea. ’"
    },
    {
      "verse": "22",
      "text": "Then Moses led the Israelites away from the Red Sea. They travelled into the desert called Shur. They walked into the desert for three days and they could not find any water to drink."
    },
    {
      "verse": "23",
      "text": "Then they arrived at Marah. But they could not drink the water there because it was too bitter. That is why they called that place ‘Marah’."
    },
    {
      "verse": "24",
      "text": "Then the people complained. They spoke against Moses. They said, ‘There is nothing for us to drink! ’"
    },
    {
      "verse": "25",
      "text": "Then Moses called to the Lord for help. The Lord showed Moses a special tree. Moses threw a branch into the water. Then the water became good for them to drink. There at Marah, the Lord made a law for the Israelites to obey. He tested them there, to see if they would trust him."
    },
    {
      "verse": "26",
      "text": "He said, ‘Be careful to listen to what the Lord your God says to you. Let him see that you are doing things that are right. Obey his commands and his rules. Then I will not give to you the diseases that I gave to the Egyptians. I am the Lord. I am the one who gives you health. ’"
    },
    {
      "verse": "27",
      "text": "Then the Israelites arrived at Elim. There they found 12 wells of water and 70 palm trees. The Israelites put up their tents there, where there was water."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "Then all the Israelites left Elim and they went into the desert called Sin. This is between Elim and Sinai. They arrived in the desert on the 15th day of the second month after they had left Egypt."
    },
    {
      "verse": "2",
      "text": "When they were in the desert, all the Israelites complained against Moses and Aaron."
    },
    {
      "verse": "3",
      "text": "The Israelites said to them, ‘It would have been better if the Lord had killed us in Egypt! There, we sat round pots with plenty of meat. We ate all the food that we wanted. But now you have brought us into this desert. We are so hungry that we will soon die! ’"
    },
    {
      "verse": "4",
      "text": "Then the Lord said to Moses, ‘I will cause bread to fall down from the sky for you like rain. Each day, the people must go out and pick up enough bread for that day. In this way I will test them. I will discover whether they will obey my rules."
    },
    {
      "verse": "5",
      "text": "On the sixth day, they must pick up and prepare twice as much bread. ’"
    },
    {
      "verse": "6",
      "text": "So Moses and Aaron said to all the Israelites, ‘In the evening, you will know who brought you out of Egypt. It was the Lord!"
    },
    {
      "verse": "7",
      "text": "Then, in the morning, you will see how great the Lord is. The Lord has heard the bad things that you have said against him. We, Moses and Aaron, are the Lord's servants. So you are complaining against him, not against us! ’"
    },
    {
      "verse": "8",
      "text": "Moses said to them, ‘The Lord will give you meat to eat in the evening. And in the morning, he will give you all the bread that you want. He will do this because he has heard you when you complained against him. We are only his servants. You have said bad things against the Lord, not against us. ’"
    },
    {
      "verse": "9",
      "text": "Then Moses said to Aaron, ‘Say to all the Israelites, “The Lord has heard the bad things that you have said against him. Now come together, and stand in front of him. ” ’"
    },
    {
      "verse": "10",
      "text": "While Aaron spoke, the Israelites looked towards the desert. They saw the bright glory of the Lord which appeared in the cloud."
    },
    {
      "verse": "11",
      "text": "Then the Lord said to Moses,"
    },
    {
      "verse": "12",
      "text": "‘I have heard the bad things that the Israelites have said against me. Tell them this: “In the evening, you will eat meat. And in the morning you will eat all the bread that you want. Then you will know that I am the Lord your God. ” ’"
    },
    {
      "verse": "13",
      "text": "That evening, quails appeared. They covered all the ground round the tents. In the morning, there was dew on the ground round the tents."
    },
    {
      "verse": "14",
      "text": "When the dew had gone, thin white pieces remained on the dry ground, there in the desert. It seemed like frost on the ground."
    },
    {
      "verse": "15",
      "text": "When the Israelites saw these pieces, they said, ‘What is it? ’ They did not understand what it was. But Moses said to them, ‘This is the bread that the Lord has given to you. It is for you to eat."
    },
    {
      "verse": "16",
      "text": "This is what the Lord has commanded: “Each family must pick up as much as they need to eat. Pick up two litres for each person who lives in your tent. ” ’"
    },
    {
      "verse": "17",
      "text": "So the Israelites did this. Some of them picked up a lot of the food. Some of them picked up only a little food."
    },
    {
      "verse": "18",
      "text": "But when they measured the right amount, everyone had enough to eat. The person who had picked up a lot did not have too much. And the person who had picked up only a little food still had enough to eat. Each person had picked up what he needed."
    },
    {
      "verse": "19",
      "text": "Then Moses said to them, ‘Do not keep any of it until the morning. ’"
    },
    {
      "verse": "20",
      "text": "But some of the people did not listen to Moses. They kept part of the food until the morning. But worms appeared in it, and it began to have a bad smell. Then Moses was angry with those people."
    },
    {
      "verse": "21",
      "text": "Each morning, everyone picked up as much food as they needed. But when the sun became hot, the food would melt away."
    },
    {
      "verse": "22",
      "text": "On the sixth day, the Israelites picked up twice as much food. They picked up four litres for each person. Then the leaders of the people told Moses what they had done."
    },
    {
      "verse": "23",
      "text": "Moses said to them, ‘This is what the Lord has said: “Tomorrow is a special day of rest. It is a Sabbath day, to worship the Lord. Today, you must bake any food that you want to bake. Boil the meat that you want to boil. Keep until the morning whatever food you do not eat today. ” ’"
    },
    {
      "verse": "24",
      "text": "So they kept some food until the morning, as Moses had said. This time, the food did not have a bad smell and there were no worms in it."
    },
    {
      "verse": "25",
      "text": "Moses said, ‘Eat the food today, because this day is a Sabbath day, to worship the Lord. You will not find any food on the ground today."
    },
    {
      "verse": "26",
      "text": "On six days of each week, you must pick food up from the ground. But on the seventh day of the week, there will not be any food on the ground. That is because the seventh day is the Sabbath day of rest. ’"
    },
    {
      "verse": "27",
      "text": "But on the seventh day, some of the people went out to pick up food. But they did not find any."
    },
    {
      "verse": "28",
      "text": "Then the Lord said to Moses, ‘The people continue to refuse to obey my commands. They refuse to do what I tell them!"
    },
    {
      "verse": "29",
      "text": "Remember this: The Lord has given the Sabbath day to you. That is why, on the sixth day, he gives you enough food for two days. Then everyone must stay at home on the seventh day. Nobody must leave his home that day. ’"
    },
    {
      "verse": "30",
      "text": "So the people rested on the seventh day."
    },
    {
      "verse": "31",
      "text": "The Israelites called the special food ‘manna’. It was white, like seeds called coriander. When they tasted the manna, it was like thin pieces of bread with honey in it."
    },
    {
      "verse": "32",
      "text": "Moses said, ‘This is what the Lord has commanded: “Keep one bowl (an omer) of manna for people to look at in future times. They will see the bread that I fed to you in the desert, after I had brought you out of Egypt. ” ’"
    },
    {
      "verse": "33",
      "text": "So Moses said to Aaron, ‘Put an omer of manna into a jar. Then put the jar in the place where we worship the Lord. We must keep it safe, so that our descendants can see it in the future. ’"
    },
    {
      "verse": "34",
      "text": "Aaron did what the Lord had told Moses. He put the jar in the Covenant Box, to keep it safe."
    },
    {
      "verse": "35",
      "text": "years, until they had finished their journey in the desert. After those 40 years, they arrived at the edge of Canaan."
    },
    {
      "verse": "36",
      "text": "(The people used omers to measure the food. Ten omers is equal to one ephah. )"
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "Then all the Israelites continued to travel on from the desert called Sin. They moved from one place to another, as the Lord told them. When they arrived at Rephidim, they put up their tents there. But there was no water for the people to drink."
    },
    {
      "verse": "2",
      "text": "Because of this, the people quarrelled with Moses. They said, ‘Give us water to drink! ’ Moses said to them, ‘You should not quarrel with me! You should not try to test the Lord! ’"
    },
    {
      "verse": "3",
      "text": "But the people needed water to drink. They complained against Moses. They said, ‘You should not have brought us out of Egypt! You will kill us and our children and our animals. We will all die, because we have no water to drink. ’"
    },
    {
      "verse": "4",
      "text": "Then Moses called to the Lord for help. He said, ‘What can I do with these people? They will soon be throwing stones at me to kill me. ’"
    },
    {
      "verse": "5",
      "text": "The Lord said to Moses, ‘Take some of the leaders of the Israelites with you and go in front of the people. Take your stick in your hand. Take the stick that you used to hit the Nile river. Now go!"
    },
    {
      "verse": "6",
      "text": "I will stand there, in front of you, by the rock at Sinai. Hit the rock with your stick, and water will come out of it. Then the people can drink. ’ So Moses did this, while the leaders of the Israelites watched him."
    },
    {
      "verse": "7",
      "text": "Moses called that place Massah and Meribah, because the Israelites quarrelled there. They tried to test the Lord to see what he would do. They said, ‘Let us see if the Lord is really with us. Will he help us, or not? ’"
    },
    {
      "verse": "8",
      "text": "At Rephidim, the Amalekites came and they fought against the Israelites."
    },
    {
      "verse": "9",
      "text": "Moses said to Joshua, ‘Choose some of our men. Then go out with them and fight against the Amalekites. Tomorrow I will stand on the top of the hill, and I will hold God's stick in my hand. ’"
    },
    {
      "verse": "10",
      "text": "So Joshua fought against the Amalekites. He did what Moses had told him to do. Moses, Aaron and Hur went up to the top of the hill."
    },
    {
      "verse": "11",
      "text": "When Moses lifted up his hands, the Israelites were winning in the fight. But when Moses brought his hands down, the Amalekites were winning."
    },
    {
      "verse": "12",
      "text": "Moses' hands became very tired. So Aaron and Hur put a big stone under Moses for him to sit on. Then Aaron and Hur held up Moses' hands. Aaron stood on one side of Moses, and Hur stood on the other side. They held his hands up, until sunset."
    },
    {
      "verse": "13",
      "text": "As a result, Joshua and his men destroyed the Amalekite army in the fight."
    },
    {
      "verse": "14",
      "text": "Then the Lord said to Moses, ‘Write down what happened here in a book. Then people will remember it. Read it aloud for Joshua to hear. Say that I will completely destroy all the Amalekites. Nobody in the whole world will remember them any more. ’"
    },
    {
      "verse": "15",
      "text": "Then Moses used big stones to build an altar. He called it ‘The Lord is my flag in war’."
    },
    {
      "verse": "16",
      "text": "Moses said, ‘Take hold of the Lord's flag! The Lord will always continue to fight against the Amalekites. ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "The father of Moses' wife was called Jethro. He was the priest for the Midian people. He heard about all the things that God had done for Moses and for the Israelites. He also heard how the Lord had brought Israel out of Egypt."
    },
    {
      "verse": "2",
      "text": "Moses had sent his wife, Zipporah, back to her home. He also sent his two sons with her. Jethro took care of them."
    },
    {
      "verse": "3",
      "text": "Moses' older son was called Gershom. Moses said about him, ‘I have become a stranger in a foreign country. ’"
    },
    {
      "verse": "4",
      "text": "The other son was called Eliezer. Moses said about him, ‘My ancestors' God gave me help. He saved me from Pharaoh, when Pharaoh wanted to kill me. ’"
    },
    {
      "verse": "5",
      "text": "Jethro came to visit Moses in the wilderness. He brought with him Moses' wife and two sons. The Israelites had put up their tents near the mountain of God."
    },
    {
      "verse": "6",
      "text": "Jethro had already sent a message to Moses. He said, ‘I am coming with your wife and her two sons to see you. ’"
    },
    {
      "verse": "7",
      "text": "So Moses went out to meet his wife's father. He bent down and he kissed Jethro. They said ‘hello’ and they spoke together. Then they went into Moses' tent."
    },
    {
      "verse": "8",
      "text": "Moses told Jethro about all the things that the Lord had done to help the Israelites. He told him what the Lord had done against Pharaoh and against the Egyptians. He told Jethro about the troubles that had happened to the Israelites during their journey. And Moses told him how the Lord had saved his people."
    },
    {
      "verse": "9",
      "text": "When Jethro heard what Moses said, he was very happy. He realized that the Lord had saved the Israelites from the power of the Egyptians."
    },
    {
      "verse": "10",
      "text": "Jethro said, ‘Praise the Lord! He has saved you from the power of the Egyptians and their king, Pharaoh. Yes! He has saved the Israelites from the powerful Egyptians."
    },
    {
      "verse": "11",
      "text": "Now I know that the Lord is greater than all other gods. He destroyed the proud Egyptians when they were cruel to his people. ’"
    },
    {
      "verse": "12",
      "text": "Then Jethro brought an animal to burn as a sacrifice to God. He also brought other sacrifices. Aaron came, with all the leaders of the Israelites. They ate a special meal together with Jethro, to worship God."
    },
    {
      "verse": "13",
      "text": "The next day, Moses sat down to judge people who had quarrels against each other. From morning until evening, people were coming to him with their quarrels."
    },
    {
      "verse": "14",
      "text": "Jethro saw all these things that Moses did to help the people. So he said, ‘You are trying to do too much! Why do you sit there alone to judge all these people during the whole day? ’"
    },
    {
      "verse": "15",
      "text": "Moses answered Jethro, ‘The people come to me to discover what God says."
    },
    {
      "verse": "16",
      "text": "When they quarrel, they come to me to decide who is right. I tell them what God's laws and commands teach. ’"
    },
    {
      "verse": "17",
      "text": "Jethro replied, ‘The thing that you are doing is not good."
    },
    {
      "verse": "18",
      "text": "You will become too tired. The people who come to you will also become tired. You cannot do all this work alone."
    },
    {
      "verse": "19",
      "text": "Now listen to me! I will tell you what I think will help you. God will take care of you. When people have quarrels, you must continue to speak to God on their behalf."
    },
    {
      "verse": "20",
      "text": "You are the person who must teach them God's laws and commands. You must show them how they should live and what they must do."
    },
    {
      "verse": "21",
      "text": "But you must also choose some other clever men to help you. They must be honest men who respect God. They must not want to take money from people. Choose these men to be officers with authority over groups of the people. They will be leaders of 1, 000 people, or 100 people, or 50 people, or 10 people."
    },
    {
      "verse": "22",
      "text": "They will be able to work as judges for the people, every day. They can decide the small quarrels. But if there is a difficult problem, they must bring it to you. That will make your work easier, because they will help you with the work."
    },
    {
      "verse": "23",
      "text": "If you agree with my idea, and if God commands you to do it, it will help you. The work will not be too hard for you. And all these people will go home happily. ’"
    },
    {
      "verse": "24",
      "text": "Moses listened to Jethro and he did everything that Jethro had said."
    },
    {
      "verse": "25",
      "text": "Moses chose wise men from all the Israelites. He made them officers to lead 1, 000 people, or 100 people, or 50 people, or 10 people."
    },
    {
      "verse": "26",
      "text": "They worked as judges for the people at all times. If there was a difficult problem, they took it to Moses for him to decide. But they themselves decided the small problems."
    },
    {
      "verse": "27",
      "text": "Then Moses said ‘goodbye’ to his wife's father, Jethro. Jethro returned to his own country."
    }
  ],
  "19": [
    {
      "verse": "3",
      "text": "Moses went up the mountain to speak with God. The Lord spoke to him from the mountain. He said, ‘This is what you must say to the Israelites, Jacob's descendants:"
    },
    {
      "verse": "4",
      "text": "“You yourselves have seen what I did against the Egyptians. You know how I took care of you. I carried you carefully, like an eagle carries her babies on her wings. I brought you here to come to me."
    },
    {
      "verse": "5",
      "text": "Now you must be careful to obey me and my covenant with you. Then you will belong to me as my special people. The whole earth belongs to me, and I have chosen you from among all the nations."
    },
    {
      "verse": "6",
      "text": "You will be my priests who serve in my kingdom. You will be a nation that is special to me. ” These are the words that you must speak to the Israelites. ’"
    },
    {
      "verse": "7",
      "text": "So Moses came back down from the mountain. He brought together all the leaders of the Israelites. He told them all the words that the Lord had commanded him."
    },
    {
      "verse": "8",
      "text": "The people all replied together. They said, ‘We will do everything that the Lord has said. ’ Then Moses repeated their answer to the Lord."
    },
    {
      "verse": "9",
      "text": "The Lord said to Moses, ‘I will come to you in a thick cloud. Then the people will hear me when I speak to you. Then they will always believe what you say. ’ Moses told the Lord the words that the people had said."
    },
    {
      "verse": "10",
      "text": "Then the Lord said to Moses, ‘Go to the people. Make them ready to meet with me. Today and tomorrow they must wash their clothes."
    },
    {
      "verse": "11",
      "text": "They must be ready on the third day. On that day, I will come down on Sinai mountain, so that all the people see me."
    },
    {
      "verse": "12",
      "text": "Make a line round the edge of the mountain so that the people do not cross it. Say to them, “Be careful! Do not go up the mountain or even touch the edge of it. If any people or animals touch the mountain, they must die."
    },
    {
      "verse": "13",
      "text": "Nobody must go near them. You must throw stones at them to kill them. Or you must shoot arrows at them. You must not let them live, whether they are people or animals. ” The people must wait until they hear the sound of a trumpet. When they hear a long noise, then they may go up on the mountain. ’"
    },
    {
      "verse": "14",
      "text": "Then Moses came down from the mountain to speak to the people. He told them to make themselves ready for God. So the people washed their clothes."
    },
    {
      "verse": "15",
      "text": "Then Moses said to them, ‘Prepare yourselves for the third day. While you wait, do not have sex with your wives, or anyone. ’"
    },
    {
      "verse": "16",
      "text": "On the morning of the third day, there was thunder and lightning. A thick cloud was there over the mountain. The people heard the noise of a loud trumpet. They were so afraid that their bodies were shaking."
    },
    {
      "verse": "17",
      "text": "Then Moses led the people away from their tents to meet with God. They went and they stood at the edge of the mountain."
    },
    {
      "verse": "18",
      "text": "Smoke covered Sinai mountain because the Lord had come down on the mountain, like a fire. The smoke rose up from the mountain, like smoke from a great fire. The whole mountain shook very much."
    },
    {
      "verse": "19",
      "text": "The noise of the trumpet became louder and louder. Moses spoke to God and God answered him with a loud voice."
    },
    {
      "verse": "20",
      "text": "The Lord came down onto the top of Sinai mountain. Then the Lord told Moses that he must come up to the top of the mountain. So Moses went up the mountain."
    },
    {
      "verse": "21",
      "text": "The Lord said to Moses, ‘Go down to the people. Warn them that they must stay away from the mountain. They must not cross the line to try to see me, the Lord. If they do that, many of them will die."
    },
    {
      "verse": "22",
      "text": "Even the priests must make themselves clean before they come near to me. If they do not obey this command, I will punish them. I am the Lord. ’"
    },
    {
      "verse": "23",
      "text": "Moses said to the Lord, ‘The people cannot come up Sinai mountain. You warned us that we must make a line round the edge of the mountain. You said that we must make the mountain a special place. ’"
    },
    {
      "verse": "24",
      "text": "The Lord replied, ‘Now go back down. Then bring Aaron up with you. But the priests and the people must stay where they are. They must not try to come up here where I am. If they come across the line, I will punish them. ’"
    },
    {
      "verse": "25",
      "text": "So Moses went down to the people. He told them what the Lord had said."
    },
    {
      "verse": "1",
      "text": "After the Israelites left Rephidim, they went into the Sinai desert. The Israelites put up their tents in the desert, at the side of Sinai mountain."
    },
    {
      "verse": "2",
      "text": "That happened on the first day of the third month since they came out of Egypt."
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "Then God spoke all these words:"
    },
    {
      "verse": "2",
      "text": "‘I am the Lord your God. I brought you out of Egypt, the country where you were slaves."
    },
    {
      "verse": "3",
      "text": "You must not have any other gods except me."
    },
    {
      "verse": "4",
      "text": "You must not make any idol for yourself. Do not make a false god in the shape of anything that is in the sky above. Do not make one in the shape of anything on the earth or in the sea."
    },
    {
      "verse": "5",
      "text": "You must not bend down your head to any idol or worship it. I am the Lord your God and I want you to belong to me alone. I will punish children because of the bad things that their fathers have done. I will also punish their children and their grandchildren too. That is how I will punish everyone who turns against me."
    },
    {
      "verse": "6",
      "text": "But I will truly love all those who love me. They are the people who obey my laws. I will continue to love them and their families for ever."
    },
    {
      "verse": "7",
      "text": "You must not speak the name of the Lord your God in a wrong way. The Lord will punish anyone who speaks his name in a wrong way."
    },
    {
      "verse": "8",
      "text": "Remember the Sabbath day. Keep it as a special day for me."
    },
    {
      "verse": "9",
      "text": "You have six days every week to do all your work."
    },
    {
      "verse": "10",
      "text": "But the seventh day is a Sabbath day. It is special for the Lord your God. You must not do any work on that day. Your son and your daughter must not work on that day. Your servants, male or female, must not work on that day. The foreign person who lives among you and even your animals must not work on that day."
    },
    {
      "verse": "11",
      "text": "In six days, the Lord made the heavens, the earth and the sea. He made everything that is in them. But on the seventh day, the Lord rested. So he blessed the Sabbath day and he made it special."
    },
    {
      "verse": "12",
      "text": "Always respect your father and your mother. Then you will live for many years in the land that the Lord your God will give to you."
    },
    {
      "verse": "13",
      "text": "You must not murder anyone."
    },
    {
      "verse": "14",
      "text": "You must not have sex with another person's husband or wife."
    },
    {
      "verse": "15",
      "text": "You must not take another person's things for yourself."
    },
    {
      "verse": "16",
      "text": "You must not say false things against your neighbour."
    },
    {
      "verse": "17",
      "text": "You must not want to take your neighbour's house for yourself. You must not want to take his wife, or his servants, male or female. You must not want to take his ox, or his donkey, or anything else that belongs to your neighbour. ’"
    },
    {
      "verse": "18",
      "text": "The people heard the loud thunder and they saw the bright lightning. They heard the noise of the trumpet. They saw the smoke on the mountain. They were so afraid that their bodies were shaking. They would not come near."
    },
    {
      "verse": "19",
      "text": "They said to Moses, ‘Speak to us yourself. We will listen to you. But do not let God speak to us. If he does, we will die. ’"
    },
    {
      "verse": "20",
      "text": "Moses said to the people, ‘Do not be afraid. God has come to test you. He wants you to respect him and to obey him. Then you will not do things that are wrong. ’"
    },
    {
      "verse": "21",
      "text": "So the people stayed away from the mountain. But Moses walked towards the thick, dark cloud, where God was."
    },
    {
      "verse": "22",
      "text": "Then the Lord said to Moses, ‘Tell this to the Israelites: “You yourselves have heard me speak to you from heaven."
    },
    {
      "verse": "23",
      "text": "Do not make any idols to take my place. Do not use silver or gold to make an idol that you will worship."
    },
    {
      "verse": "24",
      "text": "Instead, use earth to make an altar for me. You must offer sacrifices to me on the altar. You may take your sheep, your goats or your cows to make burnt offerings or friendship offerings or other sacrifices to me. Make an altar like this in any place that I choose for you to worship me. In those places, I will come to you and I will bless you."
    },
    {
      "verse": "25",
      "text": "You may also use stones from the ground to make an altar for me. But do not use any tools to cut the stones. If you use a tool on the stones, the altar will not be right for you to worship me there."
    },
    {
      "verse": "26",
      "text": "Do not make an altar which has stairs going up to it. If you do that, someone may see under your clothes when you climb up the stairs. Then you would be ashamed. ”"
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "These are the laws that you must put in front of the Israelites:"
    },
    {
      "verse": "2",
      "text": "If you buy an Israelite slave, he must work for you for six years. But in the seventh year he will become a free man. He can leave you. He does not have to pay you any money."
    },
    {
      "verse": "3",
      "text": "If he came to you alone, he is free to leave alone. If he came with a wife, she can also leave with him."
    },
    {
      "verse": "4",
      "text": "But if the master has given a wife to the slave, she belongs to her master. If she has children, they also belong to her master. The slave must then leave by himself, without his wife and children."
    },
    {
      "verse": "5",
      "text": "But perhaps the slave may say, “I love my master, my wife and my children. I will not go away as a free man! ”"
    },
    {
      "verse": "6",
      "text": "Then his master must take the slave to stand in front of the judges. He must lead the slave to stand beside the door, or the wood that holds the door. Then the master must push the sharp point of a tool through the slave's ear. After that, he will serve his master for all his life."
    },
    {
      "verse": "7",
      "text": "Perhaps a man may sell his daughter to someone as a slave. She is not free to leave her master after six years, as the male slaves are."
    },
    {
      "verse": "8",
      "text": "Her master has chosen her for himself. If she does not make her master happy, he must let her family buy her back from him. He cannot sell her to a foreign person. He has not done what he promised to her."
    },
    {
      "verse": "9",
      "text": "If the master had chosen the girl to marry his son, he must take care of her like his own daughter."
    },
    {
      "verse": "10",
      "text": "If the master marries another woman as well, he must still take care of the first woman. He must continue to give her food and clothes. He must not refuse to sleep with her."
    },
    {
      "verse": "11",
      "text": "If he does not do these three things, she may leave him. She does not have to pay him any money."
    },
    {
      "verse": "12",
      "text": "Perhaps a person may hit another person so that he dies. You must punish the murderer with death."
    },
    {
      "verse": "13",
      "text": "But perhaps he had not decided to kill the other person. Perhaps God let it happen. Then the man should run away to a safe place that I will choose for you."
    },
    {
      "verse": "14",
      "text": "But if he already decided to kill the other person, he is a murderer. You must punish him with death. Even if he runs to my altar as a safe place, take him away from there and kill him."
    },
    {
      "verse": "15",
      "text": "If someone attacks his father or his mother, you must punish him with death."
    },
    {
      "verse": "16",
      "text": "If someone catches another person to sell him, you must punish him with death. Kill him even if you find him when he has not yet sold the man that he caught."
    },
    {
      "verse": "17",
      "text": "If someone curses his father or his mother, you must punish him with death."
    },
    {
      "verse": "18",
      "text": "Perhaps two men argue and they fight one another. One man might hit the other man with a stone or with his fist. The man that he hit might not die but he might have to stay in bed for some time."
    },
    {
      "verse": "19",
      "text": "After that, he may get up. He may be able to walk about outside, if he uses a stick. Then the man who hit him is not guilty. But he must pay the man that he has hurt. He must pay him for the time that he has not been able to work. He must also make sure that the man becomes completely well again."
    },
    {
      "verse": "20",
      "text": "Perhaps a master may hit his male slave or his female slave with a stick. If the slave dies because of this, you must punish the master."
    },
    {
      "verse": "21",
      "text": "But if the slave is still alive after one or two days, do not punish his master. The master has already lost the slave's work for that time."
    },
    {
      "verse": "22",
      "text": "When two men fight together, perhaps one of them may hit a pregnant woman. As a result of the fight, she may give birth to her child before the right time. If the man has not hurt the woman very much, he must pay money to her husband. He must pay the amount of money that the husband demands. A judge must agree that the money for his punishment is fair."
    },
    {
      "verse": "23",
      "text": "But if the man has hurt the woman a lot, you must punish him as he deserves. Take a life for a life,"
    },
    {
      "verse": "24",
      "text": "an eye for an eye, a tooth for a tooth, a hand for a hand, a foot for a foot."
    },
    {
      "verse": "25",
      "text": "You must give him a burn for a burn, a wound for a wound, a bruise for a bruise."
    },
    {
      "verse": "26",
      "text": "If a master hits the eye of his male slave or his female slave, he might destroy it. Then he must let the slave go away as a free person to pay for the loss of their eye."
    },
    {
      "verse": "27",
      "text": "If he knocks out the tooth of his slave, he must also let the slave go away to pay for the loss of the tooth."
    },
    {
      "verse": "28",
      "text": "Perhaps a bull may attack someone so that the person dies. Then you must throw stones at the bull to kill it. You must not eat the meat from that bull. But do not punish the owner of the bull."
    },
    {
      "verse": "29",
      "text": "But perhaps that bull has attacked people before. Perhaps someone warned the owner about this, but the man did not keep the bull in a safe place. If that happens, and the bull kills someone, you must kill the bull. You must also punish the bull's owner with death."
    },
    {
      "verse": "30",
      "text": "But if the dead person's family demands money, the man can give them money instead of his life. He must pay them what they ask for."
    },
    {
      "verse": "31",
      "text": "This law is the same if the bull attacks someone's son or their daughter."
    },
    {
      "verse": "32",
      "text": "If it attacks a male slave or a female slave, the man must pay 30 silver coins to the slave's master. You must also throw stones at the bull to kill it."
    },
    {
      "verse": "33",
      "text": "If a man digs a hole in the ground, he must cover it. If he leaves a hole open, a cow or a donkey might fall into it."
    },
    {
      "verse": "34",
      "text": "Then the man who dug the hole must pay for the loss of the animal. He must pay money to the animal's owner, but he may keep the dead animal for himself."
    },
    {
      "verse": "35",
      "text": "If one man's bull attacks another man's bull, it may die. Then they must sell the bull that is still alive. Each man can take half of the money and half of the dead bull as well."
    },
    {
      "verse": "36",
      "text": "But perhaps that bull has attacked other animals before. If its owner knows that and he did not do anything, he must pay for the dead bull. He should have kept his bull in a safe place. So he must pay the owner of the dead bull, but he can keep the dead animal for himself."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "Perhaps someone may take another person's cow or sheep for himself. He may kill it or he may sell it. As punishment, he must pay the owner five cows for each cow that he has taken. He must pay four sheep for each sheep that he has taken."
    },
    {
      "verse": "2",
      "text": "Perhaps someone may catch a robber as he goes into another person's house. The owner of the house might knock down the robber so that he dies. If this happens at night, the owner of the house is not guilty of murder. Anyone who takes something that belongs to someone else must pay back the owner. If he cannot pay for everything that he has taken, he must become a slave. The owner will receive the money that someone has paid for the slave."
    },
    {
      "verse": "3",
      "text": "But if the owner of the house kills the robber after sunrise, he is guilty of murder. Anyone who takes something that belongs to someone else must pay back the owner. If he cannot pay for everything that he has taken, he must become a slave. The owner will receive the money that someone has paid for the slave."
    },
    {
      "verse": "4",
      "text": "You may find an animal that someone has taken for himself. If the animal is still alive, the person who took it must pay back to the owner twice its value. He must do this, whether it was a cow, a donkey, or a sheep."
    },
    {
      "verse": "5",
      "text": "A man's animals might go into someone else's field or vineyard to eat what is growing there. Then the owner of those animals must pay back the value of what they have eaten. He must give his best grain and his best grapes to pay back the other man."
    },
    {
      "verse": "6",
      "text": "Someone might light a fire in his field to burn thorn bushes. But the fire might grow and it might burn the crops in another farmer's field. It may destroy the crops that are growing there or the grain that is ready for harvest. It might even destroy the whole field. Then the person who lit the fire must pay the farmer for the crops that the fire has destroyed."
    },
    {
      "verse": "7",
      "text": "Perhaps you may give some of your money or your valuable things to your neighbour. You may ask your neighbour to keep them safe for you. But a robber might take those things from your neighbour's house. If you catch the robber, he must pay back twice the value of the things that he took."
    },
    {
      "verse": "8",
      "text": "But if you do not find the robber, you must take your neighbour to stand in front of the judges. They must decide if your neighbour has taken your things for himself."
    },
    {
      "verse": "9",
      "text": "Perhaps two people both say that something belongs to them. They may argue about a cow, a donkey, a sheep, some clothes or anything else that they have lost. Then both of them must go to stand in front of the judges. The judges will decide which of them is guilty. The guilty person must pay back twice the value of the thing to the other person."
    },
    {
      "verse": "10",
      "text": "Perhaps you may ask your neighbour to keep one of your animals safe for you. It may be a donkey, a cow, a sheep or any other animal that belongs to you. Then the animal may die, or something may hurt it. Or perhaps a robber takes it for himself. If nobody has seen what really happened, you must do this:"
    },
    {
      "verse": "11",
      "text": "Your neighbour must make a serious promise to the Lord. He must promise that he did not take your animal for himself, or hurt it. Then you must accept what he has said. Do not ask your neighbour to pay you any money."
    },
    {
      "verse": "12",
      "text": "But if a robber did take the animal from your neighbour, then your neighbour must pay you for it."
    },
    {
      "verse": "13",
      "text": "But perhaps a wild animal attacked it. Then your neighbour must show the pieces of your animal that are left. Then he will not have to pay you for the loss of your animal."
    },
    {
      "verse": "14",
      "text": "Your neighbour might lend one of his animals to you to do some work. Something bad might happen to the animal while its owner is not with it. It might die, or something might hurt it. Then you must pay your neighbour for the loss of the animal."
    },
    {
      "verse": "15",
      "text": "But if the owner is with his animal when something bad happens to it, you do not have to pay anything. And if you already paid your neighbour some money to use his animal, that will be enough to pay him for the loss."
    },
    {
      "verse": "16",
      "text": "Perhaps a man may meet a young girl who has not had sex with any man before. He might deceive her to have sex with her. If she has not yet promised to marry another man, he must marry her. He must give the right gifts to her parents."
    },
    {
      "verse": "17",
      "text": "Her father might refuse to give her to the man to be his wife. But the man must still give the right gifts for a girl who is not married."
    },
    {
      "verse": "18",
      "text": "You must punish with death any woman who is a magician."
    },
    {
      "verse": "19",
      "text": "You must punish with death anyone who has sex with an animal."
    },
    {
      "verse": "20",
      "text": "You must completely destroy anyone who offers a sacrifice to a false god. You must only offer sacrifices to the Lord."
    },
    {
      "verse": "21",
      "text": "Never be cruel to a foreign person or give them trouble. Remember that you yourselves lived in Egypt as foreigners."
    },
    {
      "verse": "22",
      "text": "Never give trouble to any widow or to any children who have no family."
    },
    {
      "verse": "23",
      "text": "If you are cruel to them, I will hear them when they call out to me for help."
    },
    {
      "verse": "24",
      "text": "I will be very angry with you. I will kill you in war. Your wives will become widows. Your children will no longer have any family."
    },
    {
      "verse": "25",
      "text": "You may lend money to any of my people who need help. But do not ask them to pay back more money than you have lent to them. That is what traders in money do."
    },
    {
      "verse": "26",
      "text": "You may take someone's coat as a guarantee that he will pay you back. But you must always return his coat to him before sunset."
    },
    {
      "verse": "27",
      "text": "He needs his coat to keep him warm at night. It is the only warm thing that he has to sleep in. If you keep his coat, I will hear him when he calls out to me for help. And I will help him, because I am very kind to people."
    },
    {
      "verse": "28",
      "text": "Never insult God. Never curse anyone who is a leader of your people."
    },
    {
      "verse": "29",
      "text": "Do not refuse to offer your grain, your wine or your olive oil to me. You must give your firstborn sons to me. You must give your firstborn sons to me."
    },
    {
      "verse": "30",
      "text": "Do the same thing with your cows and your sheep. Let them stay with their mothers for seven days. But on the eighth day, you must give them to me."
    },
    {
      "verse": "31",
      "text": "You must live as my special people. So do not eat any meat from your animals that wild animals have killed. Instead, you must give it as food to the dogs."
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "Do not make false reports. Do not tell lies in court to help wicked people."
    },
    {
      "verse": "2",
      "text": "Do not join a group of bad people to do evil things. When you speak in court, tell the truth so that the judges will decide what is right. Do not tell lies to agree with what everyone else says."
    },
    {
      "verse": "3",
      "text": "Do not speak on behalf of a poor man only because you like him."
    },
    {
      "verse": "4",
      "text": "Perhaps you may find your enemy's cow or his donkey when he has lost it. If so, you must give it back to him."
    },
    {
      "verse": "5",
      "text": "Perhaps you may see your enemy's donkey when it is carrying a heavy load. If the donkey has fallen down, do not refuse to give help. Do not leave the donkey there."
    },
    {
      "verse": "6",
      "text": "Always do what is right for your poor people when they stand in front of a judge."
    },
    {
      "verse": "7",
      "text": "Do not help anyone to use lies to accuse another person. Never punish anyone with death if they are not guilty. I will never say that a wicked person is not guilty."
    },
    {
      "verse": "8",
      "text": "Do not accept a bribe. A bribe will hide the truth even from honest people. It can make good people tell lies."
    },
    {
      "verse": "9",
      "text": "Do not be cruel to a foreign person who lives among you. You yourselves know what that feels like. Remember that you lived in Egypt as foreigners."
    },
    {
      "verse": "10",
      "text": "You must plant seed in your fields for six years. Then you can bring your crops home at harvest time."
    },
    {
      "verse": "11",
      "text": "But in the seventh year, you must let your fields lie empty. Do not dig them and do not plant anything in them. Then poor people among you can eat the food that they find in your fields. After that, the wild animals can eat any food that still remains. Do the same thing with your vineyards and your fields of olive trees."
    },
    {
      "verse": "12",
      "text": "Do your work for six days each week, but do not work on the seventh day. Then your oxen and your donkeys will have time to rest. Any slave who was born in your home and any foreigner who works for you may also have time to rest. That will help them to be strong."
    },
    {
      "verse": "13",
      "text": "Be careful to obey everything that I have told you. Do not pray to other gods for help. Do not even speak about them."
    },
    {
      "verse": "14",
      "text": "Three times each year, you must eat a feast to give me honour."
    },
    {
      "verse": "15",
      "text": "Eat the Feast of Flat Bread every year. For seven days, you must eat bread that you have made without any yeast. I have commanded you to do this. Do it at the right time during the month Abib. It was in that month that you came out of Egypt. Nobody must come to me without an offering."
    },
    {
      "verse": "16",
      "text": "Eat the Feast of Harvest every year. Offer to me the first crops that you bring from your fields. At the end of each year, eat Feast of Final Harvest. Do that when you have finished bringing in all of your crops from the fields. At the end of each year, eat Feast of Final Harvest. Do that when you have finished bringing in all of your crops from the fields."
    },
    {
      "verse": "17",
      "text": "Three times each year, all your men must come to worship the Almighty Lord."
    },
    {
      "verse": "18",
      "text": "When you kill an animal to offer it to me as a sacrifice, do not offer it with bread that has yeast in it. Be sure to burn all the fat of the animal on the same day. Do not keep any of it until the next morning."
    },
    {
      "verse": "19",
      "text": "When you cut the first crops from your fields, bring the best food to the house of the Lord your God. Do not cook a young goat in its mother's milk. Do not cook a young goat in its mother's milk."
    },
    {
      "verse": "20",
      "text": "Look! I will send an angel to lead you on your journey. He will keep you safe. He will take you to the place that I have prepared for you."
    },
    {
      "verse": "21",
      "text": "Be careful to obey him. Listen to what he says to you. Do not turn against him. If you do that, he will not forgive you. I have given him my authority."
    },
    {
      "verse": "22",
      "text": "So be careful to obey him. Do everything that I tell you. Then I will be the enemy of your enemies. I will fight against anyone who fights against you."
    },
    {
      "verse": "23",
      "text": "My angel will go in front of you. He will bring you into the land of the Amorites, the Hittites, the Perizzites, the Canaanites, the Hivites and the Jebusites. I will destroy them completely."
    },
    {
      "verse": "24",
      "text": "Do not worship their gods. Do not serve them. Do not copy the evil things that these people do. Destroy their idols and break their special stones into pieces."
    },
    {
      "verse": "25",
      "text": "You must serve only me, the Lord your God. Then I will bless your food and your water. I will remove illness from among you."
    },
    {
      "verse": "26",
      "text": "Your women will safely give birth to babies. They will all be able to have children. Everyone will live a long life."
    },
    {
      "verse": "27",
      "text": "I will cause all the nations that you meet to be afraid. All the people who attack you will become confused. I will cause all your enemies to turn round and run away from you."
    },
    {
      "verse": "28",
      "text": "I will send great fear on the people as you move into the land. That will chase out the Hivites, the Canaanites and the Hittites."
    },
    {
      "verse": "29",
      "text": "But I will not chase out those people in one year. If I did that, the country would become empty of people. Then there would be many wild animals that would cause trouble to you."
    },
    {
      "verse": "30",
      "text": "I will remove the people slowly, one group at a time. As you become strong, you will take the land as your own home."
    },
    {
      "verse": "31",
      "text": "I will decide where the borders of your land will be. You will have the land from the Red Sea to the Mediterranean Sea, and from the desert to the Euphrates River. I will put the people who live there under your power. As you move into the land, you will chase those people out."
    },
    {
      "verse": "32",
      "text": "Do not make any agreement with them or with their gods."
    },
    {
      "verse": "33",
      "text": "Do not let them live in your land. They would cause you to do bad things against me. If you serve their gods, you will become like their prisoners. ’"
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "Then God said to Moses, ‘Come up to me, the Lord. Come with Aaron, Nadab, Abihu and 70 of the leaders of Israel. Worship me, but do not come near."
    },
    {
      "verse": "2",
      "text": "Only Moses can come near to me, but not the others. The people must not come up the mountain with him. ’"
    },
    {
      "verse": "3",
      "text": "Moses went and he told the people all the Lord's commands and his teaching. The people answered together, ‘We will do everything that the Lord has told us. ’"
    },
    {
      "verse": "4",
      "text": "Then Moses wrote down everything that the Lord had said. Early the next morning, Moses built an altar at the bottom of the mountain. Then he put up 12 stone pillars. Each pillar stood there for one of Israel's 12 tribes."
    },
    {
      "verse": "5",
      "text": "Moses sent young Israelite men to burn animals there, as offerings to the Lord. They also killed young bulls as friendship offerings to the Lord."
    },
    {
      "verse": "6",
      "text": "Moses took half of the blood of these animals and he put it into some bowls. He splashed the other half of the blood over the altar."
    },
    {
      "verse": "7",
      "text": "Then he took the Book of God's Covenant and he read it to the people. They replied, ‘We will do everything that the Lord has told us. We will obey his commands. ’"
    },
    {
      "verse": "8",
      "text": "Then Moses used the blood in the bowls to splash on the people. He said, ‘This blood shows that you accept the covenant that the Lord has made with you. You agree to obey the rules of his covenant. ’"
    },
    {
      "verse": "9",
      "text": "Then Moses and Aaron, Nadab, Abihu and the 70 Israelite leaders went up the mountain."
    },
    {
      "verse": "10",
      "text": "They saw the God of Israel there. Under his feet was something like a jewel called sapphire. It was as bright as a clear blue sky."
    },
    {
      "verse": "11",
      "text": "God did not hurt those Israelite leaders. They saw God. They ate a meal and they drank together."
    },
    {
      "verse": "12",
      "text": "The Lord said to Moses, ‘Come up to me on the mountain. Stay here. I will give you the flat stones with my Law on them. I have written on them my Law and my commands, so that you can teach them to the people. ’"
    },
    {
      "verse": "13",
      "text": "So Moses went up the mountain of God. His servant Joshua went with him."
    },
    {
      "verse": "14",
      "text": "Moses said to the leaders, ‘Wait here for us. We will come back to you. Aaron and Hur are here with you. If you have any arguments, they can decide who is right. ’"
    },
    {
      "verse": "15",
      "text": "When Moses went up the mountain, the cloud covered it."
    },
    {
      "verse": "16",
      "text": "The Lord's bright glory appeared on Sinai mountain. The cloud covered the mountain for six days. On the seventh day, the Lord called out to Moses from inside the cloud."
    },
    {
      "verse": "17",
      "text": "The people could see the Lord's bright glory. To them, it looked like a fire that was burning the top of the mountain."
    },
    {
      "verse": "18",
      "text": "Moses went up the mountain and he went into the cloud. He stayed on the mountain for 40 days and 40 nights."
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "The Lord said to Moses:"
    },
    {
      "verse": "2",
      "text": "‘Tell the Israelites to bring me an offering. Every person who wants to give can make a gift to me. You must receive their gifts."
    },
    {
      "verse": "3",
      "text": "These are the gifts that you must receive from the people as an offering: gold, silver and bronze;"
    },
    {
      "verse": "4",
      "text": "blue, purple and red material; good linen and goat's hair;"
    },
    {
      "verse": "5",
      "text": "red leather from sheep's skins and other good leather; wood from acacia trees;"
    },
    {
      "verse": "6",
      "text": "olive oil for the lamps; spices for the special oil and for incense with a nice smell;"
    },
    {
      "verse": "7",
      "text": "onyx and other jewels to fix on the priest's ephod and his breastpiece."
    },
    {
      "verse": "8",
      "text": "You must tell the Israelites to make a special place to be my home. Then I will live among them."
    },
    {
      "verse": "9",
      "text": "I will show you how to make this tabernacle and everything that you will put inside it. But you must make everything in the way that I tell you."
    },
    {
      "verse": "10",
      "text": "The Israelites must use acacia wood to make a big box. It must be 1 metre long, 75 centimetres wide and 75 centimetres high."
    },
    {
      "verse": "11",
      "text": "Cover the wood with gold, both inside and outside. Build up the edges of the box with gold."
    },
    {
      "verse": "12",
      "text": "Make four gold rings and fix them to the four feet of the box. Fix two rings on one side and two rings on the other side."
    },
    {
      "verse": "13",
      "text": "Then use acacia wood to make two poles. Cover them with gold too."
    },
    {
      "verse": "14",
      "text": "Push the poles through the rings on the sides of the box. You will use the poles to carry the box."
    },
    {
      "verse": "15",
      "text": "The poles must remain along the side of the box, in the rings. Never remove them."
    },
    {
      "verse": "16",
      "text": "Then put into the box the two flat stones with the words of the covenant on them. I will give those to you."
    },
    {
      "verse": "17",
      "text": "Use pure gold to make a lid for the box. Make the lid 1 metre long and 75 centimetres wide."
    },
    {
      "verse": "18",
      "text": "Use gold to make images of two cherubs. Use a hammer to make them the right shape. They will stand at the two ends of the lid."
    },
    {
      "verse": "19",
      "text": "One cherub will stand at one end of the lid, and one cherub will stand at the other end. The two cherubs and the lid must be one piece of gold."
    },
    {
      "verse": "20",
      "text": "The cherubs must look towards each other and watch over the lid. Their wings must touch each other over the top of the lid."
    },
    {
      "verse": "21",
      "text": "Then put the lid on the top of the box. Put the flat stones with the words of the covenant into the box. I will give those to you."
    },
    {
      "verse": "22",
      "text": "I will meet with you there, between the two cherubs that are above the lid. They watch over the Covenant Box. In that place I will give you all my commands for the Israelites."
    },
    {
      "verse": "23",
      "text": "Use acacia wood to make a table. It must be one 1 metre long, 50 centimetres wide and 75 centimetres high."
    },
    {
      "verse": "24",
      "text": "Cover the wood with gold. Build up the edges of the table with gold."
    },
    {
      "verse": "25",
      "text": "Also, fix an extra piece of wood around its edge. It must be 7 centimetres wide. Build up the edges of this piece with gold."
    },
    {
      "verse": "26",
      "text": "Make four gold rings for the table. Fix them to the four corners, one beside each leg of the table."
    },
    {
      "verse": "27",
      "text": "The rings must be near to the extra piece of wood. They will hold the poles that you will use to carry the table."
    },
    {
      "verse": "28",
      "text": "Use acacia wood to make the poles. Cover them with gold. Use the poles to carry the table."
    },
    {
      "verse": "29",
      "text": "Use pure gold to make plates, big spoons, jars and bowls. You will use these things to pour out drink offerings."
    },
    {
      "verse": "30",
      "text": "Put the Lord's special bread on this table. The bread must always be there for me."
    },
    {
      "verse": "31",
      "text": "Use one piece of pure gold to make a lampstand. Use a hammer to make it the right shape. Use the gold to make its base, its middle pole and the cups to hold the oil. The cups will be like open flowers and closed flowers."
    },
    {
      "verse": "32",
      "text": "Make six branches on the lampstand, three branches on each side of the middle pole."
    },
    {
      "verse": "33",
      "text": "Put three cups in the shape of almond flowers and their leaves on each branch. Each of the six branches of the lampstand will have three cups like that."
    },
    {
      "verse": "34",
      "text": "On the lampstand itself, put four cups in the shape of almond flowers and their leaves."
    },
    {
      "verse": "35",
      "text": "Put one closed flower under the first pair of branches. Put a second closed flower under the second pair of branches. Put the third closed flower under the third pair of branches. So there will be three closed flowers for the six branches on the lampstand."
    },
    {
      "verse": "36",
      "text": "You must make the flowers and the branches from the same piece of pure gold as the lampstand. Use a hammer to make the gold into the right shape."
    },
    {
      "verse": "37",
      "text": "Then make seven lamps and fix them to the lampstand. Fix them so that they light the space in front of the lampstand."
    },
    {
      "verse": "38",
      "text": "Also use pure gold to make small tools and dishes to take care of the lamps."
    },
    {
      "verse": "39",
      "text": "kilograms of pure gold to make the lampstand and all the tools to take care of it."
    },
    {
      "verse": "40",
      "text": "Be careful to make all these things like the plan that I have shown you on the mountain."
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "Make the tabernacle with ten curtains of very good linen. Also use blue, purple and red material. Tell a worker to use special skills to make pictures of cherubs on the curtains."
    },
    {
      "verse": "2",
      "text": "All the curtains must be the same size: 12 metres long and 2 metres wide."
    },
    {
      "verse": "3",
      "text": "Join five of the curtains together. Do the same thing with the other five curtains."
    },
    {
      "verse": "4",
      "text": "Fix rings of blue material along the edge of the last curtain in each set of five curtains."
    },
    {
      "verse": "5",
      "text": "rings on the edge of the first set. Put 50 rings on the edge of the other set. Do this so that the rings on one curtain are opposite to the rings on the other curtain."
    },
    {
      "verse": "6",
      "text": "small gold hooks to join the curtains together. In this way, a single piece of curtain will make the whole tabernacle."
    },
    {
      "verse": "7",
      "text": "Use goats' hair to make 11 curtains. They will cover the tabernacle, like a tent."
    },
    {
      "verse": "8",
      "text": "All the curtains must be the same size: 13. 5 metres long and 2 metres wide."
    },
    {
      "verse": "9",
      "text": "Join five of the curtains together to make one set. Fix the other six curtains together to make a second set. Turn the sixth curtain of this set over itself to cover the entrance of the tent."
    },
    {
      "verse": "10",
      "text": "rings along the edge of the end curtain in each set."
    },
    {
      "verse": "11",
      "text": "bronze hooks. Use them to join the two sets of curtains together so that it makes a single tent."
    },
    {
      "verse": "12",
      "text": "The curtains for the tent will be longer than the curtains for the tabernacle. The extra half of the curtain for the tent will hang at the back of the tabernacle."
    },
    {
      "verse": "13",
      "text": "The curtains of the tent will be half a metre longer on both sides. The extra material will hang over each side of the tabernacle to cover it completely."
    },
    {
      "verse": "14",
      "text": "Use red leather from sheep's skins to cover the tent. Then use another kind of good leather to cover the red leather."
    },
    {
      "verse": "15",
      "text": "Use acacia wood to make boards to hold up the tabernacle."
    },
    {
      "verse": "16",
      "text": "metres high and 65 centimetres wide."
    },
    {
      "verse": "17",
      "text": "Make two wooden pegs on each board, beside each other. Make all the boards of the tabernacle like this."
    },
    {
      "verse": "18",
      "text": "boards for the south side of the tabernacle."
    },
    {
      "verse": "19",
      "text": "heavy bases to hold up the boards. Two bases will hold up each board. The pegs on the boards will fit into holes in the bases."
    },
    {
      "verse": "20",
      "text": "boards for the north side of the tabernacle."
    },
    {
      "verse": "21",
      "text": "silver bases, two bases under each board."
    },
    {
      "verse": "22",
      "text": "Make six boards for the west side, at the back of the tabernacle."
    },
    {
      "verse": "23",
      "text": "Then make two boards for the corners at the back of the tabernacle."
    },
    {
      "verse": "24",
      "text": "You must fix the two boards together, from the bottom to the top. Use a ring to fix them together at the top. Make both the corners in the same way."
    },
    {
      "verse": "25",
      "text": "silver bases, two bases under each board."
    },
    {
      "verse": "26",
      "text": "You must also use acacia wood to make bars to fix across the boards. Make five bars for the south side of the tabernacle,"
    },
    {
      "verse": "27",
      "text": "five bars for the north side, and five bars for the west side at the back of the tabernacle."
    },
    {
      "verse": "28",
      "text": "The bar that goes across the centre of the boards must reach from one end of the tabernacle to the other end."
    },
    {
      "verse": "29",
      "text": "Use gold to cover the boards and to make rings for the boards. These rings will hold the bars in place across the boards. Also cover the wooden bars with gold."
    },
    {
      "verse": "30",
      "text": "Make the tabernacle the same as the plan that I showed to you on the mountain."
    },
    {
      "verse": "31",
      "text": "Use blue, purple and red material and good linen to make a special curtain. A worker must use special skills to make pictures of cherubs on it."
    },
    {
      "verse": "32",
      "text": "Use gold rings to hang the curtain from four poles of acacia wood. Cover these poles with gold. Then fix them on four silver bases."
    },
    {
      "verse": "33",
      "text": "Hang the top of the curtain from the rings. Put the Covenant Box behind the curtain, in the Most Holy Place. The curtain will hang between the Most Holy Place and the Holy Place so that they are separate."
    },
    {
      "verse": "34",
      "text": "Put the special lid on the Covenant Box, in the Most Holy Place."
    },
    {
      "verse": "35",
      "text": "Put the special table in the Holy Place, outside the curtain. It will be on the north side of the tabernacle. Put the lampstand opposite the table, on the south side."
    },
    {
      "verse": "36",
      "text": "Make a curtain for the entrance of the tent. Use blue, purple and red material and good linen to make it. A worker must use special skills to make it so that it looks beautiful."
    },
    {
      "verse": "37",
      "text": "Use acacia wood to make five poles. Cover them with gold. Fix gold rings to the poles. Use bronze to make five bases to hold up the poles. Then hang the curtain from the rings on the poles."
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "Use acacia wood to make an altar. It must be square, 2. 2 metres long and 2. 2 metres wide. It must be 1. 3 metres high."
    },
    {
      "verse": "2",
      "text": "Make four horns, one at each corner of the altar. The horns and the altar itself must be one piece of work. Then cover the whole altar with bronze."
    },
    {
      "verse": "3",
      "text": "Make all the tools for the altar with bronze. Make pots to remove the ashes, spades and bowls. Make forks for the meat. Make dishes to carry the fire."
    },
    {
      "verse": "4",
      "text": "Use bronze to make a square net and rings at each corner."
    },
    {
      "verse": "5",
      "text": "Fix this net inside the altar, in the middle, between the top of the altar and the ground."
    },
    {
      "verse": "6",
      "text": "Use acacia wood to make poles for the altar. Cover them with bronze."
    },
    {
      "verse": "7",
      "text": "You must put the poles through the rings when you carry the altar. There will be a pole on each of two sides of the altar."
    },
    {
      "verse": "8",
      "text": "Use boards to make the altar, so that it is empty inside. You must make it in the way that the Lord showed you on the mountain."
    },
    {
      "verse": "9",
      "text": "Make a yard around the tent of the tabernacle. The south side must be 45 metres long. It will have curtains that are made of good linen."
    },
    {
      "verse": "10",
      "text": "poles and 20 bronze bases to hold the poles. Use silver to make hooks and sticks to hold the curtains."
    },
    {
      "verse": "11",
      "text": "metres long. It will also have 20 poles with their bronze bases, as well as their silver hooks and sticks."
    },
    {
      "verse": "12",
      "text": "metres long. Make curtains for it, with ten poles and their bronze bases."
    },
    {
      "verse": "13",
      "text": "The entrance to the yard is at its east end. That end must also be 23 metres long."
    },
    {
      "verse": "16",
      "text": "metres wide for the entrance to the yard. Make it out of blue, purple and red material, as well as good linen. Choose a worker who can use special skills to make the curtain look beautiful. Make four poles and their bases to hold the curtain at the entrance."
    },
    {
      "verse": "17",
      "text": "All the poles around the yard must have bronze bases. They will also have silver hooks and sticks to hold the curtains."
    },
    {
      "verse": "18",
      "text": "metres long and 23 metres wide. Use good linen to make the curtains. They must be 2¼ metres high on the bronze bases."
    },
    {
      "verse": "19",
      "text": "Use bronze to make all the tools that you will use in the tabernacle. Also use bronze to make the pegs that fix the tent of the tabernacle to the ground. And make bronze pegs to fix the curtain around the yard to the ground."
    },
    {
      "verse": "20",
      "text": "Command the Israelites to bring you pure oil from fresh olives. You will use this oil to make the lamps give light all the time."
    },
    {
      "verse": "21",
      "text": "Aaron and his sons must make sure that the lamps always give light from evening until morning. The lampstand will be in the Tent of Meeting, outside the curtain that hangs in front of the Covenant Box. The lamps must always give light there, where the Lord is. This will always be a rule for the Israelites, now and in the future."
    },
    {
      "verse": "14",
      "text": "metres of curtain on each side of the entrance."
    },
    {
      "verse": "15",
      "text": "There will be three poles with their bases to hold the curtains on each side."
    }
  ],
  "28": [
    {
      "verse": "1",
      "text": "Bring your brother Aaron and his sons from among the other Israelites. They will serve me as my priests. That will be Aaron and his sons, Nadab, Abihu, Eleazar and Ithamar."
    },
    {
      "verse": "2",
      "text": "Make special clothes for Aaron. They will be beautiful clothes to show that he deserves honour."
    },
    {
      "verse": "3",
      "text": "I have given special skills to some workers so that they know how to make beautiful things. Tell them to make clothes for Aaron. They will show that I have chosen him to serve me as my priest."
    },
    {
      "verse": "4",
      "text": "These are the clothes that they must make: a breastpiece, an ephod, a robe, a long shirt, a linen hat, and a long belt of cloth. They must make these special clothes for your brother Aaron and for his sons. Then Aaron and his sons will serve me as my priests."
    },
    {
      "verse": "5",
      "text": "The workers who have special skills must use beautiful material that is gold, blue, purple and red, as well as good linen."
    },
    {
      "verse": "6",
      "text": "Use gold, blue, purple and red material, as well as good linen, to make the ephod. A worker should use special skills to make it so that it looks beautiful."
    },
    {
      "verse": "7",
      "text": "Fix pieces of cloth on its two edges. These will go over the priest's shoulders to join the front and the back parts of the ephod."
    },
    {
      "verse": "8",
      "text": "Make a beautiful belt to tie around the ephod. The belt and the ephod must be one piece of work. Use the same materials to make both of them: gold, blue, purple and red material, and good linen."
    },
    {
      "verse": "9",
      "text": "Take two onyx stones and write on them with a sharp tool. Write the names of the sons of Israel."
    },
    {
      "verse": "10",
      "text": "Begin with the name of the oldest son and finish with the name of the youngest son. Write six names on one stone and six names on the other stone."
    },
    {
      "verse": "11",
      "text": "A worker who has skill to cut letters into metal must do this work. Then fix the stones into beautiful gold around their edges."
    },
    {
      "verse": "12",
      "text": "sons of Israel. Aaron will carry the names on his shoulders as he serves the Lord. Then the Lord will remember to bless his people."
    },
    {
      "verse": "13",
      "text": "Use gold to make beautiful pieces to hold the stones."
    },
    {
      "verse": "14",
      "text": "And use pure gold to make two thin chains, like strings. Fix these chains to the gold pieces that hold the onyx stones."
    },
    {
      "verse": "15",
      "text": "A worker must use special skills to make a breastpiece so that it looks beautiful. The breastpiece will help the priest to know what God is saying. Make it like the ephod. Use gold, blue, purple and red material, and good linen to make it."
    },
    {
      "verse": "16",
      "text": "Bend a piece of cloth over to make a square pocket, 22 centimetres long and 22 centimetres wide."
    },
    {
      "verse": "17",
      "text": "Then fix four rows of jewels on it. These are the names of the jewels: a ruby, a topaz and a beryl in the first row;"
    },
    {
      "verse": "18",
      "text": "a turquoise, a sapphire and an emerald in the second row;"
    },
    {
      "verse": "19",
      "text": "a jacinth, an agate and an amethyst in the third row;"
    },
    {
      "verse": "20",
      "text": "a chrysolite, an onyx and a jasper in the fourth row. Fix each jewel into beautiful gold around its edges."
    },
    {
      "verse": "21",
      "text": "jewels, one jewel for each of Israel's sons. You must carefully write one tribe's name on each jewel with a sharp tool."
    },
    {
      "verse": "22",
      "text": "Use pure gold to make two thin chains like strings. These will fix the breastpiece to the ephod."
    },
    {
      "verse": "23",
      "text": "Make two gold rings and fix them to the two top corners of the breastpiece."
    },
    {
      "verse": "24",
      "text": "Fix the two gold chains to the two rings on the corners of the breastpiece."
    },
    {
      "verse": "25",
      "text": "Fix the other ends of the two chains to the shoulder pieces of the ephod, in the front. Join them to the gold pieces that hold the onyx stones."
    },
    {
      "verse": "26",
      "text": "Make two gold rings and fix them to the two bottom corners of the breastpiece. Put them on its inside edge, so that they are next to the ephod."
    },
    {
      "verse": "27",
      "text": "Make two more gold rings. Fix them to the bottom edge of the shoulder pieces, on the front of the ephod. Put them just above the ephod's belt."
    },
    {
      "verse": "28",
      "text": "Use a string of blue material to tie the rings on the breastpiece to the rings on the ephod. Fix them together above the ephod's belt. Then the breastpiece and the belt will not become separate."
    },
    {
      "verse": "29",
      "text": "When Aaron goes into the Holy Place, he will wear the breastpiece. So he will carry the names of Israel's sons over his heart. And the Lord will always remember to bless the Israelites."
    },
    {
      "verse": "30",
      "text": "Put the Urim and Thummim in the pocket of the breastpiece. They will also be over Aaron's heart when he goes in there to serve the Lord. The Urim and Thummim will always be there to show Aaron what the Lord is saying about the Israelites. He will carry this help over his heart all the time."
    },
    {
      "verse": "31",
      "text": "Use only blue cloth to make the robe for the ephod."
    },
    {
      "verse": "32",
      "text": "Make a hole in the top of the robe, in the middle. Make an edge around this hole, for the priest's head to go through. Make the edge so that it will not tear."
    },
    {
      "verse": "33",
      "text": "Use blue, purple and red material to make pictures of pomegranates. Also make gold bells. The pomegranates and the bells will go all around the bottom edge of the robe."
    },
    {
      "verse": "34",
      "text": "There will be a bell then a pomegranate, another bell then a pomegranate, all around the edge of the robe."
    },
    {
      "verse": "35",
      "text": "Aaron must wear the robe when he is serving the Lord. The bells will make a noise when he goes into the Holy Place to serve the Lord. They will also make a sound when he comes out. Then he will not die."
    },
    {
      "verse": "36",
      "text": "Use pure gold to make a thin plate and write on it carefully with a sharp tool. Write this sign on it: “Holy to the Lord”."
    },
    {
      "verse": "37",
      "text": "Fix a blue string to the plate and tie it to the front of the linen hat."
    },
    {
      "verse": "38",
      "text": "Aaron will always wear this sign on the front of his head. When the Israelites bring gifts to God, they may be guilty of sins. When Aaron has this sign on his head, he himself will be guilty instead of them. Then the Lord will accept the gifts that his people offer to him."
    },
    {
      "verse": "39",
      "text": "Use good linen to make the long shirt and the hat for the priest. A worker with special skills must make the long belt, so that it looks beautiful."
    },
    {
      "verse": "40",
      "text": "Make shirts, belts and hats for Aaron's sons. These clothes must be beautiful to give them honour."
    },
    {
      "verse": "41",
      "text": "Dress your brother Aaron and his sons with these clothes. Then pour oil on their heads to show that they have my authority. Make them separate from the other Israelites as my holy servants. They will serve me as my priests."
    },
    {
      "verse": "42",
      "text": "Use good linen to make trousers that will cover the lower parts of their bodies."
    },
    {
      "verse": "43",
      "text": "Aaron and his sons must wear them when they go into the Tent of Meeting. They must also wear them when they go near to the altar to serve me in the Holy Place. Then they will not be guilty. I will not punish them with death. This will always be a rule for Aaron and his descendants."
    }
  ],
  "29": [
    {
      "verse": "1",
      "text": "When you make the priests God's special servants, do it in this way: Take a young bull and two male sheep. They must not have anything wrong with them."
    },
    {
      "verse": "2",
      "text": "Use good flour from wheat to make three kinds of bread, with no yeast in it. Mix olive oil with some of the flour before you cook it. Cook some of the flour without any oil in it. And cook some flour to make biscuits that you then put oil on."
    },
    {
      "verse": "3",
      "text": "Put the bread and the biscuits into a basket. Bring them to the Tent of Meeting with the bull and the two sheep."
    },
    {
      "verse": "4",
      "text": "Then bring Aaron and his sons to the entrance of the Tent of Meeting. Use water to wash them there and make them clean."
    },
    {
      "verse": "5",
      "text": "Then take the special clothes. Dress Aaron in the shirt, the robe, the ephod and the breastpiece. Tie the ephod on him with its special belt."
    },
    {
      "verse": "6",
      "text": "Put the linen hat on Aaron's head. Fix the special gold sign to the hat."
    },
    {
      "verse": "7",
      "text": "Take the special olive oil. Pour it on his head to show that God has chosen him to be his servant."
    },
    {
      "verse": "8",
      "text": "Bring Aaron's sons and dress them in their special shirts."
    },
    {
      "verse": "9",
      "text": "Put the cloth hats on their heads. Tie the long cloth belts around Aaron and on his sons. These men and their descendants will always be priests. That is a law that continues for ever. That is how you must make Aaron and his sons God's special servants."
    },
    {
      "verse": "10",
      "text": "Bring the bull to the front of the Tent of Meeting. Aaron and his sons must put their hands on the bull's head."
    },
    {
      "verse": "11",
      "text": "Then kill the animal as an offering to the Lord, at the entrance of the Tent of Meeting."
    },
    {
      "verse": "12",
      "text": "Take some of the bull's blood. Use your finger to put some of it on the horns of the altar. Pour the blood that remains on the ground around the altar."
    },
    {
      "verse": "13",
      "text": "Take all the fat that is round the inside parts of the animal. Take the best part of the liver. Take both the kidneys with the fat that is round them. Burn all these things on the altar."
    },
    {
      "verse": "14",
      "text": "But burn the rest of the bull's body outside the camp, with its skin and the food in its stomach. It is an offering to make the priests clean from their sins."
    },
    {
      "verse": "15",
      "text": "Take one of the male sheep. Aaron and his sons must put their hands on its head."
    },
    {
      "verse": "16",
      "text": "Kill the sheep and take its blood to the altar. Throw some of the blood onto every side of the altar."
    },
    {
      "verse": "17",
      "text": "Cut the sheep into pieces. Wash its inside parts and its legs. Then put them together with its head and the other pieces."
    },
    {
      "verse": "18",
      "text": "Completely burn the whole sheep on the altar. It is a burnt offering to the Lord. Its smell pleases him."
    },
    {
      "verse": "19",
      "text": "Take the second male sheep. Aaron and his sons must put their hands on its head."
    },
    {
      "verse": "20",
      "text": "Kill the sheep. Put some of its blood on Aaron's right ear, the thumb of his right hand and on the big toe of his right foot. Do the same thing to each of his sons. Then throw some of the sheep's blood onto every side of the altar."
    },
    {
      "verse": "21",
      "text": "Mix together some of the blood on the altar and some of the special oil. Splash this onto Aaron and onto his clothes. Splash it also onto his sons and onto their clothes. Then Aaron and his sons and their clothes will be holy."
    },
    {
      "verse": "22",
      "text": "Take all the fat from this male sheep. Take its fat tail, the fat around its inside parts and the best part of the liver. Take the two kidneys with the fat that is round them. Also take the top part of its right leg. (This is the sheep that makes Aaron and his sons special servants of God. )"
    },
    {
      "verse": "23",
      "text": "Take one piece of each kind of flat bread out of the basket: bread that has no oil in it, bread with oil in it and a biscuit. These are an offering to the Lord."
    },
    {
      "verse": "24",
      "text": "Put all these things in the hands of Aaron and his sons. Then lift these things up to the Lord as an offering to him."
    },
    {
      "verse": "25",
      "text": "Then take them from Aaron and his sons and burn them on the altar. It is a burnt offering to the Lord. Its smell pleases him."
    },
    {
      "verse": "26",
      "text": "Take the meat from the ribs of the sheep that makes Aaron God's special servant. Lift it up to the Lord as an offering to him. Then you may eat this meat from the sheep."
    },
    {
      "verse": "27",
      "text": "You must keep separate this meat from the sheep's ribs, as well as the top part of its right leg. Those are the pieces that you lifted up to the Lord as an offering to him. Those pieces belong to Aaron and his sons."
    },
    {
      "verse": "28",
      "text": "In the future, when the Israelites bring a peace offering to the Lord, these pieces will belong to Aaron and his descendants. This will always be the regular gift from the Israelites to the priests. That is the law that will continue for ever. It is the gift that the Israelites must bring to the Lord."
    },
    {
      "verse": "29",
      "text": "Aaron's special clothes will belong to his descendants after he dies. When they too become God's special servants as his priests, they will wear them."
    },
    {
      "verse": "30",
      "text": "After Aaron's death, his son who becomes priest will first take seven days to serve the Lord in the tabernacle. The new priest must wear the special clothes in the Holy Place for those seven days."
    },
    {
      "verse": "31",
      "text": "Take the male sheep that makes Aaron God's special servant. Cook its meat in a holy place in the yard of the tabernacle."
    },
    {
      "verse": "32",
      "text": "Aaron and his sons must eat this meat and the bread that was in the basket. They must do this at the entrance of the Tent of Meeting."
    },
    {
      "verse": "33",
      "text": "That meat was part of the sacrifice which made them clean from their sins. It made them God's special servants as his priests. No other person may eat those things, because they are holy."
    },
    {
      "verse": "34",
      "text": "But if any of the meat from the offerings remains until the morning, you must burn it. Also burn any bread that remains. You must not eat it, because it is holy."
    },
    {
      "verse": "35",
      "text": "Do everything that I have commanded you, to make Aaron and his sons my special servants. Take seven days to do this."
    },
    {
      "verse": "36",
      "text": "Kill a bull each day, as a sacrifice that makes people clean from their sins. Also make the altar clean and pure. Pour oil over it to make it holy for me."
    },
    {
      "verse": "37",
      "text": "Do this to the altar for seven days to make it pure. Then it will be completely holy. Anything that touches the altar will become holy too."
    },
    {
      "verse": "38",
      "text": "You must offer a regular gift on the altar each day. This offering must be two lambs that are one year old."
    },
    {
      "verse": "39",
      "text": "Offer one lamb in the morning and the other lamb in the evening."
    },
    {
      "verse": "40",
      "text": "With the first lamb, offer two litres of good flour. Mix the flour with one litre of olive oil. Also offer one litre of wine as a drink offering."
    },
    {
      "verse": "41",
      "text": "Kill the other lamb in the evening. Offer it with the same gifts of food and drink as in the morning. It is a burnt offering to the Lord. Its smell pleases him."
    },
    {
      "verse": "42",
      "text": "You and your descendants must continue to make this burnt offering as a regular offering to me, the Lord. Offer it to me at the entrance of the Tent of Meeting. I will meet with you there and I will speak to you."
    },
    {
      "verse": "43",
      "text": "I will meet with the Israelites there. My bright glory will make it a holy place."
    },
    {
      "verse": "44",
      "text": "In that way I will make the Tent of Meeting and its altar a special, holy place. Aaron and his sons will become my special servants. They will serve me as my priests."
    },
    {
      "verse": "45",
      "text": "I will live among the Israelites and I will be their God."
    },
    {
      "verse": "46",
      "text": "They will know that I am the Lord their God. I brought them out of Egypt so that I could live among them. I am the Lord their God."
    }
  ],
  "30": [
    {
      "verse": "1",
      "text": "Use acacia wood to make an altar so that you can burn incense on it."
    },
    {
      "verse": "2",
      "text": "The altar must be square. Make it 45 centimetres long, 45 centimetres wide and 90 centimetres high. The altar's horns must be part of it, made from one piece of wood."
    },
    {
      "verse": "3",
      "text": "Cover all the altar with gold: its top, its sides and the horns. Build up an edge of gold around the four sides."
    },
    {
      "verse": "4",
      "text": "Make two gold rings for the altar. Fix them below the gold edge on two opposite sides. They will hold the poles for you to carry the altar."
    },
    {
      "verse": "5",
      "text": "Use acacia wood to make the poles. Cover them with gold."
    },
    {
      "verse": "6",
      "text": "Put the altar for incense in the Holy Place in the tabernacle. Put it in front of the curtain that hides the Covenant Box. It will be near the special lid that covers the Covenant Box. That is the place where I will meet with you."
    },
    {
      "verse": "7",
      "text": "Every morning, Aaron must burn sweet incense on this altar. He must do this when he goes in to take care of the lamps."
    },
    {
      "verse": "8",
      "text": "He must burn incense again when he lights the lamps in the evening. Incense must burn there as an offering to the Lord every day from now on."
    },
    {
      "verse": "9",
      "text": "Only offer proper incense on this altar. Do not offer any burnt offerings or grain offerings on it. And do not pour any drink offerings on it."
    },
    {
      "verse": "10",
      "text": "Once every year, Aaron must make the altar clean and pure. He must put some of the blood from the sin offering on the horns of the altar. A priest must do this every year from now on. The altar is holy because it belongs to me, the Lord. ’"
    },
    {
      "verse": "11",
      "text": "Then the Lord said to Moses,"
    },
    {
      "verse": "12",
      "text": "‘When you count the number of the Israelites, each person must pay the Lord a price for his life. Everyone must do this at the time when you count them. Then no bad illness will happen to them as you count them."
    },
    {
      "verse": "13",
      "text": "Each person that you count must give six grams of silver. That is the proper weight that they use in the tabernacle. The silver is an offering to the Lord."
    },
    {
      "verse": "14",
      "text": "years old or more. Each person must offer his gift to the Lord."
    },
    {
      "verse": "15",
      "text": "Rich people must not give more than six grams of silver. Poor people must not give less than that. That is the offering that you must each give to the Lord. It is the price that everyone must pay for his life."
    },
    {
      "verse": "16",
      "text": "Receive these silver coins from the Israelites. Use the money to take care of the Tent of Meeting. Then the Lord will always remember that you belong to him. You have paid money for your lives. ’"
    },
    {
      "verse": "17",
      "text": "Then the Lord said to Moses,"
    },
    {
      "verse": "18",
      "text": "‘Use bronze to make a large bowl for water. Also use bronze to make a base for it to stand on. Put it between the Tent of Meeting and the altar. Fill it with water."
    },
    {
      "verse": "19",
      "text": "Aaron and his sons must use the water from the bowl to wash their hands and their feet."
    },
    {
      "verse": "20",
      "text": "Every time they go into the Tent of Meeting, they must wash in the same way. Then they will not die. They must also wash before they go to the altar to make a burnt offering to the Lord."
    },
    {
      "verse": "21",
      "text": "If they wash their hands and their feet, they will not die as they serve me. This will always be a rule for Aaron and for his descendants, the priests. ’"
    },
    {
      "verse": "22",
      "text": "Then the Lord said to Moses,"
    },
    {
      "verse": "23",
      "text": "‘Mix together these special spices:6 kilograms of pure myrrh, 3 kilograms of sweet cinnamon, 3 kilograms of sweet grasses,"
    },
    {
      "verse": "24",
      "text": "kilograms of cassia, and 4 litres of olive oil."
    },
    {
      "verse": "25",
      "text": "Mix these spices to make a special oil. A worker should use special skills to make it, so that it has a sweet smell, like perfume. It will be a very special oil to put on things that belong to me."
    },
    {
      "verse": "26",
      "text": "Then pour some of this special oil on these things: the Tent of Meeting, the Covenant Box,"
    },
    {
      "verse": "27",
      "text": "the special table and all its tools, the lampstand and its tools, the altar for incense,"
    },
    {
      "verse": "28",
      "text": "the altar for burnt offerings and all its tools, and the large bowl of water with its base."
    },
    {
      "verse": "29",
      "text": "You must make all these things special for me. They will be very holy things. Anything that touches them will also become holy."
    },
    {
      "verse": "30",
      "text": "Pour some of the special oil on Aaron's head and on the heads of his sons. Make them special for me. Then they can serve me as my priests."
    },
    {
      "verse": "31",
      "text": "Say to the Israelites, “This will always be my special oil for all time."
    },
    {
      "verse": "32",
      "text": "Do not put it on the bodies of anyone, except priests. Do not use spices like this to make oil for yourselves. It is holy and you must always think about it as holy."
    },
    {
      "verse": "33",
      "text": "Nobody must make a perfume that has a sweet smell like this oil. Nobody must put this oil on any person who is not a priest. Anyone who does not obey this rule will no longer belong to my people. ” ’"
    },
    {
      "verse": "34",
      "text": "Then the Lord said to Moses, ‘Use the same amount of each of these sweet spices to make some incense: gum resin, onycha, galbanum and frankincense."
    },
    {
      "verse": "35",
      "text": "Give them to a worker who can use special skills to make the incense. It must have a sweet smell, like a perfume. Add some salt to it so that it is a pure and holy incense."
    },
    {
      "verse": "36",
      "text": "Beat some of the incense to make powder. Put this in front of the Covenant Box, in the Tent of Meeting. That is where I will meet with you. This incense will be a very holy thing for you."
    },
    {
      "verse": "37",
      "text": "Do not make any incense like this for yourselves. You must always think about it as very holy. It belongs to the Lord."
    },
    {
      "verse": "38",
      "text": "If anyone makes any incense like it for his own perfume, he will no longer belong to my people. ’"
    }
  ],
  "31": [
    {
      "verse": "1",
      "text": "Then the Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Look! I have chosen Bezalel, the son of Uri and the grandson of Hur. He belongs to the tribe of Judah."
    },
    {
      "verse": "3",
      "text": "I have filled him with my Spirit so that he has special skills. He knows how to make many kinds of things."
    },
    {
      "verse": "4",
      "text": "He can draw pictures of beautiful things that he wants to make. Then he uses gold, silver or bronze to make them."
    },
    {
      "verse": "5",
      "text": "He knows how to cut valuable stones and make them look beautiful. He knows how to cut wood into different shapes. He is very clever at all kinds of work."
    },
    {
      "verse": "6",
      "text": "I have also chosen Oholiab to help Bezalel. Oholiab is the son of Ahisamach. He belongs to the tribe of Dan. I have also helped all the workers who have special skills. They will be able to make everything that I have commanded you to make."
    },
    {
      "verse": "7",
      "text": "They will make these things: the Tent of Meeting, the Covenant Box with its special lid, the other things that will be in the tabernacle."
    },
    {
      "verse": "8",
      "text": "Those things include: the special table with all its tools, the pure gold lampstand with all its tools, the altar for incense, The workers must make all these things in the way that I have commanded you. ’"
    },
    {
      "verse": "9",
      "text": "the altar for burnt offerings with all its tools, the large bowl for water and its base,"
    },
    {
      "verse": "10",
      "text": "the beautiful clothes for Aaron the priest, the clothes for his sons as they serve as priests,"
    },
    {
      "verse": "11",
      "text": "the special oil to show that things belong to me, and the sweet incense for the Holy Place. The workers must make all these things in the way that I have commanded you. ’"
    },
    {
      "verse": "12",
      "text": "Then the Lord said to Moses,"
    },
    {
      "verse": "13",
      "text": "‘Say to the Israelites, “You must keep my Sabbath days as special days. This will help you and your descendants to remember that you belong to me. You will remember that I, the Lord, have chosen you to be my people."
    },
    {
      "verse": "14",
      "text": "The Sabbath day must be special for you, because it is a holy day. If anyone does not make the Sabbath a special day, you must punish him with death. If anyone does any work on a Sabbath day, he can no longer belong to my people."
    },
    {
      "verse": "15",
      "text": "You may work for six days each week, but the seventh day is a day of rest. It is a holy day that is special to me, the Lord. If anyone does any work on a Sabbath day, you must punish him with death."
    },
    {
      "verse": "16",
      "text": "The Israelites must always keep the Sabbath as a special day. They must obey the rules for the Sabbath day. Those rules are part of my covenant with my people that continues for ever."
    },
    {
      "verse": "17",
      "text": "It will always be a sign that I have chosen the Israelites to be my people. You will remember that the Lord made the heavens and the earth in six days. Then, on the seventh day, he stopped working and he rested. ” ’"
    },
    {
      "verse": "18",
      "text": "The Lord finished speaking to Moses on Sinai mountain. Then he gave Moses the two flat stones with the special commands that God himself had written on them."
    }
  ],
  "32": [
    {
      "verse": "1",
      "text": "The people realized that Moses had been on the mountain for a long time. So they went in a group to Aaron. They said to him, ‘Do something! Make some gods for us who will lead us. This man, Moses, brought us here out of Egypt. But now we do not know what has happened to him. ’"
    },
    {
      "verse": "2",
      "text": "So Aaron said to them, ‘Take the gold rings from the ears of your wives, your sons and your daughters. Then bring the rings to me. ’"
    },
    {
      "verse": "3",
      "text": "So all the Israelites removed the rings from their ears. They brought them to Aaron."
    },
    {
      "verse": "4",
      "text": "Aaron took the gold rings from the people. He melted the gold and he used a tool to make an image of a calf. Then the people said, ‘Look, people of Israel! This is our god who brought us up out of Egypt! ’"
    },
    {
      "verse": "5",
      "text": "When Aaron saw this, he built an altar in front of the gold calf. He told everyone, ‘Tomorrow, there will be a feast to worship the Lord. ’"
    },
    {
      "verse": "6",
      "text": "So the next day, the Israelites got up early. They killed animals as burnt offerings on the altar. They also brought peace offerings. After that, they sat down to eat a meal and they drank wine. Then they had a wild party."
    },
    {
      "verse": "7",
      "text": "The Lord said to Moses, ‘Hurry back down the mountain! The people that you brought out of Egypt have done a wicked thing."
    },
    {
      "verse": "8",
      "text": "They have already turned away from my commands. They have made for themselves an image of a calf. They have bent down low to worship it. They have made sacrifices to give it honour. They are saying, “This is the god of the Israelites, the god who brought us out of Egypt! ” ’"
    },
    {
      "verse": "9",
      "text": "Then the Lord said to Moses, ‘I have seen these people. They are proud and they do not obey me."
    },
    {
      "verse": "10",
      "text": "I am very angry with them and I will destroy them. Do not try to stop me. I will make your descendants into a great nation, instead of them. ’"
    },
    {
      "verse": "11",
      "text": "But Moses asked the Lord his God to be kind. He said, ‘Lord, please do not be so angry with your own people! You used your great power and authority to bring them safely out of Egypt."
    },
    {
      "verse": "12",
      "text": "If you destroy them, the Egyptians will say, “God led the Israelites out of our land so that he could completely destroy them. He wanted to kill them in the mountains. ” So please stop being angry. Change your mind. Please do not bring this great trouble on your own people."
    },
    {
      "verse": "13",
      "text": "Remember your servants, Abraham, Isaac and Jacob, who are our ancestors. Remember the serious promise that you made to them. You said, “I will give you many descendants. They will be as many as the stars in the sky. I have also promised to give this whole land to them. It will belong to them as their home for ever. ” ’"
    },
    {
      "verse": "14",
      "text": "Then the Lord changed his mind. He did not bring the great trouble on his people as he had said he would."
    },
    {
      "verse": "15",
      "text": "Moses left the Lord and he went down the mountain. He carried in his hands the two flat stones with God's special commands on them. God had written his commands on both sides of the stones."
    },
    {
      "verse": "16",
      "text": "This was God's own work. He himself had written the words on the stones."
    },
    {
      "verse": "17",
      "text": "Joshua heard the noise of the Israelites as they were shouting down below. He said to Moses, ‘I can hear the sound of war in the camp! ’"
    },
    {
      "verse": "18",
      "text": "But Moses said, ‘It is not the noise that soldiers make when they have won a battle. It is not the sound of soldiers who are crying because their enemy has won against them. I can hear the sound of people who are singing. ’"
    },
    {
      "verse": "19",
      "text": "Then Moses arrived at the camp. He saw the gold calf. He saw that the people were dancing. He became very angry. He threw the two flat stones that he was carrying onto the ground. He broke them into pieces there at the bottom of the mountain."
    },
    {
      "verse": "20",
      "text": "Then he took the image of the calf that they had made. He burned it in the fire. He beat it into powder. He mixed the powder with the people's water. Then he commanded the Israelites to drink it."
    },
    {
      "verse": "21",
      "text": "Moses said to Aaron, ‘Why did you agree to do this? What did the people do to you? You have made them guilty of a great sin. ’"
    },
    {
      "verse": "22",
      "text": "Aaron answered, ‘My lord, please do not be so angry with me. You know how quickly these people decide to do wicked things."
    },
    {
      "verse": "23",
      "text": "They said to me, “Make us some gods that will lead us. This man Moses brought us here out of Egypt. But now we do not know what has happened to him. ”"
    },
    {
      "verse": "24",
      "text": "So I said to them, “Everyone who has any gold rings must remove them. ” So they gave the gold to me. I threw it into the fire. Then this image of a calf came out of the fire! ’"
    },
    {
      "verse": "25",
      "text": "Moses saw that the people were running about everywhere. Aaron had not been able to control them. If their enemies could see them, they would see how foolish they were."
    },
    {
      "verse": "26",
      "text": "So Moses stood at the edge of the camp. He said, ‘Everyone who decides to serve the Lord must come here to me. ’ Then all the Levites went to stand near Moses."
    },
    {
      "verse": "27",
      "text": "Then Moses said to the Levites, ‘The Lord, Israel's God, says this: Each one of you must take his sword in his hand. You must go everywhere in the camp, from this side to the other side. You must kill everyone, even your brothers, your friends and your neighbours. ’"
    },
    {
      "verse": "28",
      "text": "The Levites obeyed Moses' command. About 3, 000 Israelites died on that day."
    },
    {
      "verse": "29",
      "text": "Then Moses said to the Levites, ‘You have shown today that you want to serve the Lord. You have become his special servants because you have obeyed him. You have agreed to kill even your own sons and brothers. God has blessed you because of this. ’"
    },
    {
      "verse": "30",
      "text": "On the next day, Moses said to the people, ‘You have done a great sin. But now I will go back up the mountain. I will speak to the Lord. Perhaps I can do something so that the Lord will forgive your sin. ’"
    },
    {
      "verse": "31",
      "text": "So Moses returned to the Lord. He said to the Lord, ‘Please listen to me. These people have done a very great sin. They have made a gold idol to worship as their god."
    },
    {
      "verse": "32",
      "text": "But now I ask you to forgive them for their sin. But if you will not do that, then please remove my name from your book. ’"
    },
    {
      "verse": "33",
      "text": "The Lord answered Moses, ‘I will only remove the names of the people who have turned against me."
    },
    {
      "verse": "34",
      "text": "Now go! Lead the Israelites to the place that I have told you about. My angel will go in front of you. But on the day for punishment, I will certainly punish them for their sin. ’"
    },
    {
      "verse": "35",
      "text": "The Lord did send a bad disease to punish the people. He punished them because they had caused Aaron to make an image of a calf."
    }
  ],
  "33": [
    {
      "verse": "1",
      "text": "Then the Lord said to Moses, ‘You must now leave here with the people that you brought out of Egypt. You must take them to the land that I promised to Abraham, Isaac and Jacob. I made a serious promise to them that I would give the land to their descendants."
    },
    {
      "verse": "2",
      "text": "I will send an angel to lead you. I will chase the Canaanites, the Amorites, the Hittites, the Perizzites, the Hivites and the Jebusites out of the land."
    },
    {
      "verse": "3",
      "text": "You will go to that land where there is plenty of food and drink, enough for everyone. But I will not travel with you. You are proud people who refuse to obey me. If I go with you, I might destroy you as you travel. ’"
    },
    {
      "verse": "4",
      "text": "The Israelites heard God's strong words. His message made them very upset. They stopped wearing their jewels, to show that they were sad."
    },
    {
      "verse": "5",
      "text": "The Lord had said to Moses, ‘Tell the Israelites, “You are proud people who refuse to obey me. If I go with you, even for a moment, I might destroy you. Now remove your jewels. Then I will decide what I should do with you. ” ’"
    },
    {
      "verse": "6",
      "text": "So the Israelites no longer wore their jewels after they left Sinai mountain."
    },
    {
      "verse": "7",
      "text": "As they travelled, Moses put up a special tent outside the camp. It was not near the other tents. He called it the Tent of Meeting. Anyone could go there to ask the Lord about something. They would go to the Tent of Meeting that was outside the camp."
    },
    {
      "verse": "8",
      "text": "When Moses went out to the special tent, all the people would stand at the doors of their tents. They would watch Moses until he went into the special tent."
    },
    {
      "verse": "9",
      "text": "When Moses went into the tent, the pillar of cloud would come down. The cloud would stay at the door of the tent while the Lord spoke to Moses."
    },
    {
      "verse": "10",
      "text": "Every time that the people saw the pillar of cloud at the door of the special tent, they all stood up. Then each person would stand at the door of his tent. They would bend low to worship the Lord."
    },
    {
      "verse": "11",
      "text": "The Lord would speak to Moses face to face, as a man speaks to his friend. Then Moses would return to the camp. But Nun's son Joshua always stayed in the special tent. Joshua was a young man who helped Moses."
    },
    {
      "verse": "12",
      "text": "Moses said to the Lord, ‘You have said to me, “Lead these people to their new land. ” But you have not told me who my helper will be on the journey. You have told me, “I know you by your name. I am very pleased with you. ”"
    },
    {
      "verse": "13",
      "text": "If you are really pleased with me, tell me your thoughts. I want to understand you properly. Then I can continue to please you. Remember that this nation, the Israelites, are your own people. ’"
    },
    {
      "verse": "14",
      "text": "The Lord replied, ‘I myself will go with you. I will give you rest. ’"
    },
    {
      "verse": "15",
      "text": "Then Moses said, ‘If you do not agree to go with us, do not let us go anywhere."
    },
    {
      "verse": "16",
      "text": "If you do not go with us, nobody will know that you are pleased with me. Nobody will know that you are pleased with us as your special people. I, and all your people, will be the same as all the other people in the world. ’"
    },
    {
      "verse": "17",
      "text": "The Lord said to Moses, ‘I will certainly do what you have asked for. This is because I am pleased with you. I know you by your name. ’"
    },
    {
      "verse": "18",
      "text": "Then Moses said, ‘Please, show me your glory! ’"
    },
    {
      "verse": "19",
      "text": "The Lord said, ‘I will let you see how great and good I am. I will tell you my name, that I am the Lord. If I choose to be kind to someone, I will be kind to them. If I choose to forgive someone, I will forgive them."
    },
    {
      "verse": "20",
      "text": "But you will never see my face. Nobody can see my face and still be alive. ’"
    },
    {
      "verse": "21",
      "text": "Then the Lord said, ‘Look! There is a place near to me. You can stand there on a rock."
    },
    {
      "verse": "22",
      "text": "When my glory passes in front of you, I will put you in a hole in the rock. I will cover your eyes with my hand as I pass by there."
    },
    {
      "verse": "23",
      "text": "Then I will remove my hand so that you will see my back. But nobody must ever see my face. ’"
    }
  ],
  "34": [
    {
      "verse": "1",
      "text": "The Lord said to Moses, ‘Cut two flat stones like the first stones. Then I will write on them all the words that I wrote on the first stones. Those were the stones that you broke into pieces."
    },
    {
      "verse": "2",
      "text": "Make yourself ready in the morning and come up Sinai mountain. Stand there, ready to meet me on the top of the mountain."
    },
    {
      "verse": "3",
      "text": "Nobody must come with you. Nobody must go anywhere on the mountain. Even your sheep and your cows must not eat grass near the bottom of the mountain. ’"
    },
    {
      "verse": "4",
      "text": "So Moses cut two flat stones like the first stones. Early in the morning, he went up Sinai mountain, as the Lord had commanded him. He carried the two flat stones in his hands."
    },
    {
      "verse": "5",
      "text": "Then the Lord came down in the cloud. He came and he stood with Moses. The Lord spoke aloud his own name, the Lord."
    },
    {
      "verse": "6",
      "text": "The Lord passed in front of Moses. He said in a loud voice, ‘I am the Lord! The Lord! I am kind to people and I forgive them. I do not quickly become angry. My faithful love for my people continues for ever, and I am always faithful."
    },
    {
      "verse": "7",
      "text": "I faithfully love thousands of people. I forgive their sins when they turn against me. But if people are guilty, I surely punish them. I punish their children, their grandchildren and their grandchildren's children. ’"
    },
    {
      "verse": "8",
      "text": "Then Moses quickly bent down low to worship the Lord."
    },
    {
      "verse": "9",
      "text": "He said, ‘Lord, my God, if you are pleased with me, please travel with us! It is true that these people are proud and they often do not obey you. But please forgive all our sins. Please accept us as your own people. ’"
    },
    {
      "verse": "10",
      "text": "Then the Lord said, ‘I will make a covenant with the Israelites. I will do great miracles for them to see. Nobody in any nation anywhere in the world has ever done such great things. All the people who live near you will see the great things that I, the Lord, will do. The powerful things that I do among you will make them very afraid."
    },
    {
      "verse": "11",
      "text": "Obey the commands that I am giving you today. Then I will chase out the Amorites, the Canaanites, the Hittites, the Perizzites, the Hivites and the Jebusites, as you move into the land."
    },
    {
      "verse": "12",
      "text": "Do not make any agreements with those people in the land where you are going. If you become their friends, they would teach you to do wrong things."
    },
    {
      "verse": "13",
      "text": "Instead, you must knock down their altars. Destroy the special stones that are their idols. Cut down their Asherah poles."
    },
    {
      "verse": "14",
      "text": "Do not worship any other god instead of me. I am the Lord and I want you to belong to me alone."
    },
    {
      "verse": "15",
      "text": "Be careful not to make an agreement with the people who live in that land. They have turned away to worship their own gods. They offer sacrifices to their gods. When they do that, they may ask you to join with them. Then you will eat the food that they have offered to their gods."
    },
    {
      "verse": "16",
      "text": "Perhaps you may choose some of their daughters for your sons to marry. Their daughters will continue to worship their gods. Then they will teach your sons to turn away from me and worship their gods."
    },
    {
      "verse": "17",
      "text": "Do not melt metal to make images of false gods."
    },
    {
      "verse": "18",
      "text": "Eat the Feast of Flat Bread every year. Eat bread that has no yeast in it for seven days, as I commanded you. Do this on the right day in the month of Abib. That is the month that you came out from Egypt."
    },
    {
      "verse": "19",
      "text": "Every firstborn child that a woman gives birth to belongs to me. That is also true for every firstborn male that your animals give birth to. That includes your cows and your sheep. Nobody may come to worship me without an offering to give me."
    },
    {
      "verse": "20",
      "text": "For a firstborn donkey, you may pay for it with a lamb instead. If you do not pay for it, you must break the donkey's neck. You must pay me back for every firstborn son that you have. Nobody may come to worship me without an offering to give me."
    },
    {
      "verse": "21",
      "text": "You may work for six days each week, but on the seventh day you must rest. That is true even when it is the time to plough your fields. It is also true at harvest time. You must rest on the seventh day each week."
    },
    {
      "verse": "22",
      "text": "Eat the Feast of Weeks every year when you cut the first wheat in your fields. Eat the Feast of Harvest at the end of each year."
    },
    {
      "verse": "23",
      "text": "Three times in every year, all your men must come to worship the Lord God, the God of Israel."
    },
    {
      "verse": "24",
      "text": "I will chase the nations out of the land as you move in. I will give you more and more land to live in. Three times each year you must come to worship the Lord your God. When you do that, nobody will try to take your land for themselves."
    },
    {
      "verse": "25",
      "text": "When you offer the blood of an animal to me as your sacrifice, do not also offer any bread with yeast in it. When you kill a lamb for the Passover sacrifice, do not keep any of the meat until the next morning."
    },
    {
      "verse": "26",
      "text": "When you cut the first crops from your fields, bring the best food to the house of the Lord your God. Do not cook a young goat in its mother's milk. ’ Do not cook a young goat in its mother's milk. ’"
    },
    {
      "verse": "27",
      "text": "Then the Lord said to Moses, ‘Write down these words. They are the rules of the covenant that I have made with you and with the Israelites. ’"
    },
    {
      "verse": "28",
      "text": "days and 40 nights. He did not eat anything or drink anything during that time. He wrote the words of God's covenant on the flat stones. Those were God's ten special commands."
    },
    {
      "verse": "29",
      "text": "Moses came down from Sinai mountain. He carried the two stones of the covenant in his hands. As he came down the mountain, he did not know that his face was shining. His face was shining because he had spoken with the Lord."
    },
    {
      "verse": "30",
      "text": "When Aaron and all the Israelites saw Moses, they could see that his face was shining. They were afraid to come near him."
    },
    {
      "verse": "31",
      "text": "But Moses called out to them. So Aaron and the leaders of the people came back to him. Then Moses talked to them."
    },
    {
      "verse": "32",
      "text": "After this, all the Israelites came near to Moses. He told them all the commands that the Lord had given to him on Sinai mountain."
    },
    {
      "verse": "33",
      "text": "When Moses had finished speaking to the people, he covered his face with a thin cloth."
    },
    {
      "verse": "34",
      "text": "But when he went into the special tent to speak with the Lord, he would remove the cloth. When he came out again, he would tell God's commands to the Israelites."
    },
    {
      "verse": "35",
      "text": "They could see that his face was shining. So Moses would put the thin cloth over his face again. The cloth would stay on his face until he went into the special tent again to speak with the Lord."
    }
  ],
  "35": [
    {
      "verse": "1",
      "text": "Moses brought all the Israelites together. Then he said to them, ‘These are the Lord's commands to you."
    },
    {
      "verse": "2",
      "text": "You may work for six days each week, but the seventh day will be a holy day for you. It will be a day of complete rest to give honour to the Lord. If anyone works on that day, you must punish him with death."
    },
    {
      "verse": "3",
      "text": "Do not light a fire in any of your homes on a Sabbath day. ’"
    },
    {
      "verse": "4",
      "text": "Moses said to all the Israelites, ‘This is what the Lord has commanded:"
    },
    {
      "verse": "5",
      "text": "Take an offering to give to the Lord from the things that you have. Everyone who wants to give something may choose to give these things: gold, silver, bronze;"
    },
    {
      "verse": "6",
      "text": "blue, purple and red material; good linen, goats' hair;"
    },
    {
      "verse": "7",
      "text": "red leather from sheep's skins and other kinds of good leather; acacia wood;"
    },
    {
      "verse": "8",
      "text": "olive oil for the lamps; spices to make the special oil and the sweet incense;"
    },
    {
      "verse": "9",
      "text": "onyx stones and other jewels to fix on the ephod and on the breastpiece."
    },
    {
      "verse": "10",
      "text": "Every clever person who has special skills must come to help. They must make all these things that the Lord has commanded:"
    },
    {
      "verse": "11",
      "text": "the tabernacle, with the tent and the other material that covers it; the rings, boards, sticks, poles and bases that are part of the tabernacle;"
    },
    {
      "verse": "12",
      "text": "the Covenant Box, with its poles, its special lid and the curtain that hides it;"
    },
    {
      "verse": "13",
      "text": "the special table with its poles and all its dishes; the special bread that you will put on the table for the Lord;"
    },
    {
      "verse": "14",
      "text": "the lampstand that will give light and its tools; the lamps and the oil for the lamps;"
    },
    {
      "verse": "15",
      "text": "the altar for incense and its poles; the special oil and the sweet incense; the curtain for the entrance of the tabernacle;"
    },
    {
      "verse": "16",
      "text": "the altar for burnt offerings and its bronze net; the poles for this altar and all its tools; the large bowl for water and its base;"
    },
    {
      "verse": "17",
      "text": "the curtains for the yard, its poles and their bases; the curtain for the entrance of the yard;"
    },
    {
      "verse": "18",
      "text": "pegs to fix the tent to the ground; pegs and ropes to hold the curtain around the yard;"
    },
    {
      "verse": "19",
      "text": "the special clothes for Aaron and his sons to wear when they serve the Lord as priests in the Holy Place. ’"
    },
    {
      "verse": "20",
      "text": "After Moses had said this, all the Israelites went away."
    },
    {
      "verse": "21",
      "text": "Everyone who decided to offer a gift to the Lord brought the things that they wanted to give. They brought the things to make the Tent of Meeting and the things to use in it. They also brought materials to make the priests' special clothes."
    },
    {
      "verse": "22",
      "text": "Both men and women brought beautiful things because they wanted to do that. They brought gold things and jewels that they had worn. They included rings, necklaces and other beautiful things. When they brought their gifts, they lifted them up as an offering of gold to the Lord."
    },
    {
      "verse": "23",
      "text": "Everyone who had blue, purple or red material, or good linen, brought it. They also brought goats' hair, red leather from sheep's skins and other kinds of good leather."
    },
    {
      "verse": "24",
      "text": "Those who brought gifts of silver or bronze offered them to the Lord. Everyone who had acacia wood brought it to help with the Lord's work."
    },
    {
      "verse": "25",
      "text": "All the women who knew how to make things used their hands to make material. They brought what they had made: blue, purple and red material and good linen."
    },
    {
      "verse": "26",
      "text": "Other clever women used goats' hair to make cloth. They did that because they wanted to help."
    },
    {
      "verse": "27",
      "text": "The leaders of the Israelites brought onyx stones and other jewels to fix on the ephod and on the breastpiece."
    },
    {
      "verse": "28",
      "text": "They also brought spices and olive oil. These things were to burn in the lamps, and to make the special oil and the sweet incense."
    },
    {
      "verse": "29",
      "text": "Many Israelites chose to offer gifts to the Lord. Men and women all brought the gifts that they had decided to bring. Moses had told them about the work that the Lord had commanded them to do. So they brought these things to help with the work."
    },
    {
      "verse": "30",
      "text": "Then Moses said to the Israelites, ‘Listen! The Lord has chosen Bezalel, the son of Uri and the grandson of Hur. He belongs to the tribe of Judah."
    },
    {
      "verse": "31",
      "text": "The Lord has filled him with his Spirit so that he has special skills. He knows how to make many kinds of things."
    },
    {
      "verse": "32",
      "text": "He can draw pictures of beautiful things that he wants to make. He can use gold, silver and bronze to make them."
    },
    {
      "verse": "33",
      "text": "He knows how to cut valuable stones and make them look beautiful. He knows how to cut wood into different shapes. He is very clever at all kinds of beautiful work."
    },
    {
      "verse": "34",
      "text": "The Lord has chosen Oholiab to help Bezalel. Oholiab is the son of Ahisamach. He belongs to the tribe of Dan. Bezalel and Oholiab can teach other people how to make things."
    },
    {
      "verse": "35",
      "text": "They have special skills to make all kinds of things. They can draw pictures of the things that they want to make. They can cut pictures in metal. They can use blue, purple and red material and good linen to make beautiful things with pictures on them. They are very clever at their work, so that the things that they make look beautiful. ’"
    }
  ],
  "36": [
    {
      "verse": "1",
      "text": "Then Moses said, ‘Bezalel and Oholiab will do the work that the Lord has commanded us to do. Everyone that the Lord has helped to have special skills will work with them. They will help to build the tabernacle and all the other special things that the Lord has commanded. ’"
    },
    {
      "verse": "2",
      "text": "Then Moses called Bezalel, Oholiab and all the other people who had special skills to come together. The Lord had given them these skills and they wanted to start the work."
    },
    {
      "verse": "3",
      "text": "They received from Moses all the gifts that the Israelites had chosen to bring. They had brought gifts that would help to build the tabernacle and the other special things. The Israelites continued to bring more gifts to Moses every morning."
    },
    {
      "verse": "4",
      "text": "Then all the workers who had special skills stopped doing their work. They left their work on the tabernacle and they went to speak to Moses."
    },
    {
      "verse": "5",
      "text": "They said to Moses, ‘The people are bringing many more gifts than we need to finish the tabernacle, as the Lord commanded us to do. ’"
    },
    {
      "verse": "6",
      "text": "So Moses sent a message to everyone in the whole camp. He said, ‘No man or woman must offer any more gifts for the work of the tabernacle. ’ When the people heard Moses' message, they did not bring any more gifts."
    },
    {
      "verse": "7",
      "text": "The workers already had more things than they needed to finish all the work."
    },
    {
      "verse": "8",
      "text": "All the workers who had special skills made the tabernacle with ten curtains. They used very good linen, as well as blue, purple and red material. They made beautiful pictures of cherubs on the curtains."
    },
    {
      "verse": "9",
      "text": "All the curtains were the same size: 12 metres long and 2 metres wide."
    },
    {
      "verse": "10",
      "text": "The workers joined five of the curtains together. They did the same thing with the other five curtains."
    },
    {
      "verse": "11",
      "text": "They made rings of blue material along the edge of the last curtain in each set of five curtains."
    },
    {
      "verse": "12",
      "text": "rings along the edge of the first set. They put another 50 rings along the edge of the second set. The rings on one curtain were opposite to the rings on the other curtain."
    },
    {
      "verse": "13",
      "text": "small gold hooks to join the curtains together. So a single piece of curtain made the whole tabernacle."
    },
    {
      "verse": "14",
      "text": "The workers used goats' hair to make 11 more curtains to cover the tabernacle, like a tent."
    },
    {
      "verse": "15",
      "text": "The curtains were all the same size: 13. 5 metres long and 2 metres wide."
    },
    {
      "verse": "16",
      "text": "They joined five of the curtains together to make one set. They joined the other six curtains to make another set."
    },
    {
      "verse": "17",
      "text": "rings along the edge of the end curtain in each set."
    },
    {
      "verse": "18",
      "text": "bronze hooks to join the two sets of curtains together. It made a single tent."
    },
    {
      "verse": "19",
      "text": "They used red leather from sheep's skins to cover the tent. They used another kind of good leather to cover the red leather."
    },
    {
      "verse": "20",
      "text": "They used acacia wood to make the boards that would hold up the tabernacle."
    },
    {
      "verse": "21",
      "text": "metres high and 65 centimetres wide."
    },
    {
      "verse": "22",
      "text": "Each board had two wooden pegs, beside each other. They made all the boards for the tabernacle like this."
    },
    {
      "verse": "23",
      "text": "boards for the south side of the tabernacle."
    },
    {
      "verse": "24",
      "text": "heavy bases to hold up the boards. Two bases would hold up each board. The pegs on the boards fitted into holes in the bases."
    },
    {
      "verse": "25",
      "text": "boards for the north side of the tabernacle."
    },
    {
      "verse": "26",
      "text": "silver bases, two bases under each board."
    },
    {
      "verse": "27",
      "text": "They made six boards for the west side, at the back of the tabernacle."
    },
    {
      "verse": "28",
      "text": "They made two boards for the corners at the back of the tabernacle."
    },
    {
      "verse": "29",
      "text": "They fixed the two boards together, from the bottom to the top. They used a ring to fix them together at the top. They made both corners in the same way."
    },
    {
      "verse": "30",
      "text": "silver bases, two bases under each board."
    },
    {
      "verse": "31",
      "text": "They used acacia wood to make bars to fix across the boards. They made five bars for the south side of the tabernacle,"
    },
    {
      "verse": "32",
      "text": "five bars for the north side, and five bars for the west side at the back of the tabernacle."
    },
    {
      "verse": "33",
      "text": "The bar that would go across the centre of the boards would reach from one end of the tabernacle to the other end."
    },
    {
      "verse": "34",
      "text": "They used gold to cover the boards and to make rings for the boards. The rings would hold the bars in place across the boards. They also covered the wooden bars with gold."
    },
    {
      "verse": "35",
      "text": "The workers used blue, purple and red material, and good linen to make a special curtain. A worker used special skills to make pictures of cherubs on it."
    },
    {
      "verse": "36",
      "text": "They used gold rings to hang the curtain from four poles of acacia wood. They covered the poles with gold. They made four silver bases to hold the poles."
    },
    {
      "verse": "37",
      "text": "They made a curtain for the entrance of the tent. They used blue, purple and red material and good linen to make it. A worker used special skills to make it, so that it looked beautiful."
    },
    {
      "verse": "38",
      "text": "They made five poles to hold up this curtain. They fixed gold hooks to the poles. They covered the tops of the poles with gold. But they used bronze to make five bases to hold up the poles."
    }
  ],
  "37": [
    {
      "verse": "1",
      "text": "Bezalel used acacia wood to make the Covenant Box. It was 1 metre long, 75 centimetres wide and 75 centimetres high."
    },
    {
      "verse": "2",
      "text": "He covered it with gold, inside and outside. He built up the edges of the box with gold."
    },
    {
      "verse": "3",
      "text": "He made four gold rings for it and he fixed them to its four feet. He fixed two rings on one side and two rings on the other side."
    },
    {
      "verse": "4",
      "text": "He used acacia wood to make two poles. He also covered them with gold."
    },
    {
      "verse": "5",
      "text": "He pushed the poles through the rings on the sides of the Covenant Box, to carry it."
    },
    {
      "verse": "6",
      "text": "He used pure gold to make the special lid for the Covenant Box. It was 1 metre long and 75 centimetres wide."
    },
    {
      "verse": "7",
      "text": "He used gold to make images of two cherubs. He used a hammer to make them the right shape. He made them to stand at the two ends of the lid."
    },
    {
      "verse": "8",
      "text": "One cherub stood at one end of the lid and one cherub stood at the other end. He made the two cherubs and the lid from one piece of gold."
    },
    {
      "verse": "9",
      "text": "The cherubs looked at each other and they watched over the lid. Their wings touched each other over the top of the lid."
    },
    {
      "verse": "10",
      "text": "Bezalel used acacia wood to make the special table. It was 1 metre long, 50 centimetres wide and 75 centimetres high."
    },
    {
      "verse": "11",
      "text": "He covered the wood with gold. He built up the edges of the table with gold."
    },
    {
      "verse": "12",
      "text": "He fixed an extra piece of wood around its edge. It was 7 centimetres wide. He built up the edges of this piece with gold."
    },
    {
      "verse": "13",
      "text": "He made four gold rings for the table. He fixed them to the four corners, one beside each leg of the table."
    },
    {
      "verse": "14",
      "text": "The rings were near to the extra piece of wood. They would hold the poles to carry the table."
    },
    {
      "verse": "15",
      "text": "He used acacia wood to make the poles and he covered them with gold. They would use the poles to carry the table."
    },
    {
      "verse": "16",
      "text": "He used pure gold to make the things that would be on the table. He made plates, big spoons, jars and bowls. They would use those things to pour out drink offerings."
    },
    {
      "verse": "17",
      "text": "Bezalel used one piece of pure gold to make the lampstand. He used a hammer to make it the right shape. He used the gold to make its base, its middle pole and the cups to hold the oil. The cups were like open flowers and closed flowers."
    },
    {
      "verse": "18",
      "text": "There were six branches on the lampstand, three branches on each side of the middle pole."
    },
    {
      "verse": "19",
      "text": "Three cups in the shape of almond flowers and their leaves were on each branch. Each of the six branches of the lampstand had three cups like that."
    },
    {
      "verse": "20",
      "text": "On the lampstand itself there were four cups in the shape of almond flowers and their leaves."
    },
    {
      "verse": "21",
      "text": "There was one closed flower under the first pair of branches. There was a second closed flower under the second pair of branches. There was a third closed flower under the third pair of branches. So there were three closed flowers for the six branches."
    },
    {
      "verse": "22",
      "text": "He made the flowers and the branches from the same piece of pure gold as the lampstand. He used a hammer to make the gold into the right shape."
    },
    {
      "verse": "23",
      "text": "He used pure gold to make seven lamps for the lampstand, as well as the small tools and dishes to take care of the lamps."
    },
    {
      "verse": "24",
      "text": "kilograms of pure gold to make the lampstand and all its tools."
    },
    {
      "verse": "25",
      "text": "Bezalel used acacia wood to make the altar for incense. It was square, 45 centimetres long, 45 centimetres wide and 90 centimetres high. The altar's horns were part of it, made from one piece of wood."
    },
    {
      "verse": "26",
      "text": "He covered all the altar with gold: its top, its sides and the horns. He built up an edge of gold around the four sides."
    },
    {
      "verse": "27",
      "text": "He made two gold rings for the altar. He fixed them below the gold edge, on two opposite sides. They would hold the poles to carry the altar."
    },
    {
      "verse": "28",
      "text": "He used acacia wood to make the poles and he covered them with gold."
    },
    {
      "verse": "29",
      "text": "He also made the special oil that would make things holy. He also made the incense with a sweet smell, like perfume."
    }
  ],
  "38": [
    {
      "verse": "1",
      "text": "Bezalel used acacia wood to build the altar for burnt offerings. It was square, 2. 2 metres long and 2. 2 metres wide. It was 1. 3 metres high."
    },
    {
      "verse": "2",
      "text": "He made four horns, one at each corner of the altar. The horns and the altar itself were one piece of work. He covered the whole altar with bronze."
    },
    {
      "verse": "3",
      "text": "He made all the tools for the altar with bronze. He made pots to remove the ashes, and also spades and bowls. He made forks for the meat and dishes to carry the fire."
    },
    {
      "verse": "4",
      "text": "He used bronze to make a square net for the altar. He fixed it inside the altar, in the middle between the top and the ground."
    },
    {
      "verse": "5",
      "text": "He used bronze to make four rings. He fixed them to the four corners of the net. The poles would go through these rings."
    },
    {
      "verse": "6",
      "text": "He used acacia wood to make the poles. He covered them with bronze."
    },
    {
      "verse": "7",
      "text": "He put the poles through the rings on each side of the altar, to carry it. He used boards to make the altar so that it was empty inside."
    },
    {
      "verse": "8",
      "text": "He used bronze to make a large bowl for water, and a base for it to stand on. He used the bronze from small mirrors to make these things. The mirrors had belonged to women who worked at the entrance of the Tent of Meeting."
    },
    {
      "verse": "9",
      "text": "Bezalel made the yard around the tent. The south side of the yard was 45 metres long. It had curtains that were made from good linen."
    },
    {
      "verse": "10",
      "text": "poles and 20 bronze bases to hold the poles. He used silver to make hooks and sticks to hold the curtains."
    },
    {
      "verse": "11",
      "text": "metres long. It also had 20 poles and their bronze bases, as well as their silver hooks and sticks."
    },
    {
      "verse": "12",
      "text": "metres long. It had curtains with ten poles and their ten bronze bases. The poles had silver hooks and sticks."
    },
    {
      "verse": "13",
      "text": "The entrance of the yard was at its east end. That end was also 23 metres long."
    },
    {
      "verse": "16",
      "text": "The workers used good linen to make all the curtains around the yard."
    },
    {
      "verse": "17",
      "text": "All the poles had bronze bases to hold them. But the workers used silver to make the hooks that were on the poles, and the sticks. They covered the tops of the poles with silver too. All the poles around the yard had silver sticks to join them together."
    },
    {
      "verse": "18",
      "text": "They used blue, purple and red material, as well as good linen, to make the curtain for the entrance of the yard. A worker used special skills so that it looked beautiful. It was 9 metres wide and 2. 2 metres high. All the curtains around the yard were 2. 2 metres high."
    },
    {
      "verse": "19",
      "text": "Four poles in bronze bases held the curtain at the entrance. The poles had silver hooks and silver sticks. Silver also covered the tops of the poles."
    },
    {
      "verse": "20",
      "text": "The workers used bronze to make the pegs that fixed the tabernacle to the ground. They also made bronze pegs to fix all the curtains around the yard to the ground."
    },
    {
      "verse": "21",
      "text": "This is a list of the materials that the workers used to make the tabernacle with the Covenant Box inside it. Moses commanded the Levites to write this list. Ithamar, the son of Aaron the priest, was the leader of this work."
    },
    {
      "verse": "22",
      "text": "Bezalel, the son of Uri and grandson of Hur, made all the things that the Lord had commanded Moses. Bezalel belonged to the tribe of Judah."
    },
    {
      "verse": "23",
      "text": "Ahisamach's son Oholiab helped him. He belonged to the tribe of Dan. He had a special skill to draw things that he wanted to make. He could make beautiful pictures on cloth, with blue, purple and red materials, as well as good linen."
    },
    {
      "verse": "24",
      "text": "The workers used 1, 000 kilograms of gold to do all the work to make the tabernacle. That was its proper weight. The Israelites had lifted up this gold as an offering to the Lord."
    },
    {
      "verse": "25",
      "text": "The people had also brought 3, 430 kilograms of silver as an offering for the work."
    },
    {
      "verse": "26",
      "text": "years old when Moses counted them had given the right amount, about ten grams. There were 603, 550 men that Moses had counted."
    },
    {
      "verse": "27",
      "text": "kilograms of silver to make each base to hold the poles. There were 100 bases to hold the tabernacle and the special curtain inside it. So they used 3, 400 kilograms of silver to make the bases."
    },
    {
      "verse": "28",
      "text": "kilograms that still remained. With this, they made the hooks and the sticks for the poles, and they covered the tops of the poles."
    },
    {
      "verse": "29",
      "text": "The people had also lifted up 2, 425 kilograms of bronze as an offering to the Lord."
    },
    {
      "verse": "30",
      "text": "The workers used this bronze to make the bases for the entrance to the tabernacle. They also used it to make the bronze altar, with its net and all its tools."
    },
    {
      "verse": "31",
      "text": "They used this bronze to make the bases for the curtains around the yard and for the entrance to the yard. They used it to make the pegs to fix the tabernacle and the curtain around the yard to the ground."
    },
    {
      "verse": "14",
      "text": "metres of curtain on each side of the entrance."
    },
    {
      "verse": "15",
      "text": "Three poles with their bases held the curtains on each side."
    }
  ],
  "39": [
    {
      "verse": "1",
      "text": "The workers used blue, purple and red material to make beautiful clothes for the priests. They would wear them when they served God in the Holy Place. They made these special clothes for Aaron, as the Lord had commanded Moses."
    },
    {
      "verse": "2",
      "text": "The workers used gold, and blue, purple and red material, as well as good linen, to make the ephod."
    },
    {
      "verse": "3",
      "text": "They used a hammer to hit the gold to make thin pieces. Then they cut these pieces into narrow strings. A worker with special skills used the gold strings to make the blue, purple and red material, and the good linen, look very beautiful."
    },
    {
      "verse": "4",
      "text": "The workers fixed pieces of cloth on the two edges of the ephod. These pieces went over the priest's shoulders to join the front and the back parts of the ephod."
    },
    {
      "verse": "5",
      "text": "They made the beautiful belt to tie around the ephod. The belt and the ephod were one piece of work. They used the same materials to make both of them: gold, blue, purple and red material and good linen. They made them in the way that the Lord had commanded Moses."
    },
    {
      "verse": "6",
      "text": "The workers fixed the onyx stones into beautiful gold around their edges. A worker used a sharp tool to write on them the names of the sons of Israel."
    },
    {
      "verse": "7",
      "text": "They fixed the two onyx stones on the shoulder pieces of the ephod. They showed the names of the 12 sons of Israel, so that the Lord would remember to bless his people. The Lord had commanded Moses to do this."
    },
    {
      "verse": "8",
      "text": "A worker used special skills to make the breastpiece, so that it looked beautiful. He made it like the ephod. He used gold, blue, purple and red material as well as good linen to make it."
    },
    {
      "verse": "9",
      "text": "They bent a piece of cloth over to make a square pocket, 22 centimetres long and 22 centimetres wide."
    },
    {
      "verse": "10",
      "text": "Then they fixed four rows of jewels on it. These are the names of the jewels: A ruby, a topaz and a beryl in the first row."
    },
    {
      "verse": "11",
      "text": "A turquoise, a sapphire and an emerald in the second row."
    },
    {
      "verse": "12",
      "text": "A jacinth, an agate and an amethyst in the third row."
    },
    {
      "verse": "13",
      "text": "A chrysolite, an onyx and a jasper in the fourth row. They fixed each jewel into beautiful gold around its edges."
    },
    {
      "verse": "14",
      "text": "jewels, one jewel for each of Israel's sons. They used a sharp tool to write one tribe's name on each jewel."
    },
    {
      "verse": "15",
      "text": "They used pure gold to make two thin chains like strings, to fix the breastpiece to the ephod"
    },
    {
      "verse": "16",
      "text": "Then they made two gold rings with beautiful gold around the edges. They fixed the rings to the two top corners of the breastpiece."
    },
    {
      "verse": "17",
      "text": "They fixed the two gold chains to the rings on the corners of the breastpiece."
    },
    {
      "verse": "18",
      "text": "They fixed the other ends of the two chains to the shoulder pieces of the ephod, in the front. They joined them to the gold pieces that held the onyx stones."
    },
    {
      "verse": "19",
      "text": "They made two gold rings and they fixed them to the bottom corners of the breastpiece. They were on its inside edge, next to the ephod."
    },
    {
      "verse": "20",
      "text": "Then they made two more gold rings. They fixed them to the bottom edge of the shoulder pieces, on the front of the ephod. They put the rings just above the ephod's belt."
    },
    {
      "verse": "21",
      "text": "They used a string of blue material to tie the rings of the breastpiece to the rings of the ephod. They fixed them together above the ephod's belt, so that the breastpiece would not become separate. The workers made all these things as the Lord had commanded Moses."
    },
    {
      "verse": "22",
      "text": "The workers used only blue cloth to make the robe for the ephod."
    },
    {
      "verse": "23",
      "text": "They made a hole in the top of the robe, in the middle. They made an edge around the hole so that it would not tear. The priest's head would go through this hole."
    },
    {
      "verse": "24",
      "text": "They used blue, purple and red materials and good linen to make pictures of pomegranates. These were around the bottom edge of the robe."
    },
    {
      "verse": "25",
      "text": "They used pure gold to make little bells. They fixed the bells between the pomegranates on the bottom edge of the robe."
    },
    {
      "verse": "26",
      "text": "So there was a bell, then a pomegranate, another bell then a pomegranate, all around the edge of the robe. The priest would wear this robe when he served the Lord, as the Lord had commanded Moses."
    },
    {
      "verse": "27",
      "text": "The workers made long shirts for Aaron and his sons, the priests. They used good linen to make cloth for the shirts."
    },
    {
      "verse": "28",
      "text": "They also used good linen to make Aaron's special hat, as well as hats for the other priests. They used special soft linen to make the trousers that they wore next to their skin."
    },
    {
      "verse": "29",
      "text": "A worker used special skills to make the long belt, so that it looked beautiful. He used blue, purple and red materials to make it, as the Lord had commanded Moses."
    },
    {
      "verse": "30",
      "text": "The workers used pure gold to make a thin plate as a holy sign. They wrote these words on it carefully with a sharp tool: ‘Holy to the Lord’."
    },
    {
      "verse": "31",
      "text": "They fixed a blue string to the plate, to tie it to the front of the special hat. The Lord had commanded Moses to do this."
    },
    {
      "verse": "32",
      "text": "So the workers finished making everything for the tabernacle, the Tent of Meeting. The Israelites made everything exactly as the Lord had commanded Moses."
    },
    {
      "verse": "33",
      "text": "Then they brought the tabernacle to Moses. They brought the tent and all the things that would be in it. They brought the hooks, boards, sticks, poles and bases."
    },
    {
      "verse": "34",
      "text": "They brought the red leather from sheep's skins, and the other kinds of good leather that covered the tent. They also brought the curtain that hid the Most Holy Place."
    },
    {
      "verse": "35",
      "text": "They brought the Covenant Box with its poles and its special lid."
    },
    {
      "verse": "36",
      "text": "They brought the special table with all its dishes, and the special bread to put on the table for the Lord."
    },
    {
      "verse": "37",
      "text": "They brought the gold lampstand with its lamps, and the oil and the tools to make the lamps give light."
    },
    {
      "verse": "38",
      "text": "They brought the gold altar, the special oil, the sweet incense and the curtain for the entrance of the tabernacle."
    },
    {
      "verse": "39",
      "text": "They brought the bronze altar and its bronze net, with its poles and all its tools. They brought the large bowl for water and its base."
    },
    {
      "verse": "40",
      "text": "They brought the curtains for the yard and the curtain for the entrance to the yard, with their poles and their bases. They brought all the ropes and the pegs to fix those things to the ground. They brought everything that the priests needed to serve the Lord in the tabernacle, the Tent of Meeting."
    },
    {
      "verse": "41",
      "text": "They also brought the special clothes for Aaron and his sons to wear when they served the Lord as priests in the Holy Place."
    },
    {
      "verse": "42",
      "text": "The Israelites did all the work in the way that the Lord had commanded Moses. When Moses saw this, he blessed the people."
    },
    {
      "verse": "43",
      "text": "Moses carefully checked all the work. He saw that the workers had done it exactly as the Lord had commanded them. When Moses saw this, he blessed the people."
    }
  ],
  "40": [
    {
      "verse": "1",
      "text": "Then the Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘On the first day of the first month, put up the tabernacle, the Tent of Meeting."
    },
    {
      "verse": "3",
      "text": "Put the Covenant Box in the tabernacle and hide it behind the special curtain."
    },
    {
      "verse": "4",
      "text": "Bring in the special table and put the dishes on it. Then bring in the lampstand. Fix its lamps on it."
    },
    {
      "verse": "5",
      "text": "Put the gold altar for incense in front of the Covenant Box. Hang the curtain that will be at the entrance to the tabernacle."
    },
    {
      "verse": "6",
      "text": "Put the altar for burnt offerings in front of the entrance to the Tent of Meeting."
    },
    {
      "verse": "7",
      "text": "Put the large bowl for water between the Tent of Meeting and the altar. Put water in the bowl."
    },
    {
      "verse": "8",
      "text": "Hang the curtains around the yard of the tabernacle, as well as the curtain at the entrance to the yard."
    },
    {
      "verse": "9",
      "text": "Take the special oil that makes things holy. Pour some oil on the tabernacle and on everything that is in it. Offer the tabernacle and all its things to God, and then it will be holy."
    },
    {
      "verse": "10",
      "text": "Then pour some oil on the altar for burnt offerings and all its tools. Offer it all to God, and then it will be completely holy."
    },
    {
      "verse": "11",
      "text": "Pour some oil on the large bowl for water and on its base to offer them to God."
    },
    {
      "verse": "12",
      "text": "Bring Aaron and his sons to the entrance of the Tent of Meeting. Wash them with water."
    },
    {
      "verse": "13",
      "text": "Then dress Aaron in the special clothes for the priest. Pour some of the special oil on his head. Offer him to me to serve me as my priest."
    },
    {
      "verse": "14",
      "text": "Also bring his sons and dress them in the special long shirts."
    },
    {
      "verse": "15",
      "text": "Pour some oil on their heads, as you did to their father. Then they too may serve me as my priests. In this way, they and their descendants will always continue to serve me as priests. ’"
    },
    {
      "verse": "16",
      "text": "Moses did all these things, as the Lord had commanded him."
    },
    {
      "verse": "17",
      "text": "So they put up the tabernacle on the first day of the first month. It was in the second year after they had left Egypt."
    },
    {
      "verse": "18",
      "text": "When Moses put up the tabernacle, he first put the metal bases in their right places. Then he put up the boards, the bars to hold them, and the poles."
    },
    {
      "verse": "19",
      "text": "Then he covered the tabernacle with the tent and he put the leather covers over the tent. He did this in the way that the Lord had commanded him."
    },
    {
      "verse": "20",
      "text": "Moses took the two flat stones with God's special commands on them. He put them inside the Covenant Box. He put the poles through the rings on the box. He put the special lid on top of the box."
    },
    {
      "verse": "21",
      "text": "Then he brought the Covenant Box into the tabernacle. He hung the special curtain to hide it, so that nobody could see it. He did this in the way that the Lord had commanded him."
    },
    {
      "verse": "22",
      "text": "Moses put the special table inside the Tent of Meeting. He put it outside the curtain, on the north side of the Holy Place."
    },
    {
      "verse": "23",
      "text": "He put the special bread on the table as an offering to the Lord, as the Lord had commanded him."
    },
    {
      "verse": "24",
      "text": "He also put the lampstand in the Tent of Meeting. He put it on the south side of the Holy Place, opposite the table."
    },
    {
      "verse": "25",
      "text": "Then he put the lamps in their places in front of the Lord, as the Lord had commanded him."
    },
    {
      "verse": "26",
      "text": "Moses put the gold altar in the Tent of Meeting, outside the curtain that hid the Covenant Box."
    },
    {
      "verse": "27",
      "text": "He burned sweet incense on it, as the Lord had commanded him."
    },
    {
      "verse": "28",
      "text": "Then he hung the curtain at the entrance of the tent."
    },
    {
      "verse": "29",
      "text": "He put the altar for burnt offerings outside the entrance of the Tent of Meeting. He offered a burnt offering and a grain offering on it, as the Lord had commanded him."
    },
    {
      "verse": "30",
      "text": "Moses put the large bowl for water between the Tent of Meeting and the altar. He put water in it for the priests to wash themselves."
    },
    {
      "verse": "31",
      "text": "Moses and Aaron and Aaron's sons used the water to wash their hands and their feet."
    },
    {
      "verse": "32",
      "text": "They washed themselves every time that they went into the Tent of Meeting. They also washed themselves before they went to offer sacrifices at the altar. They did what the Lord had commanded Moses to do."
    },
    {
      "verse": "33",
      "text": "Moses also made the yard around the tabernacle and round the altar. He hung the curtain at the entrance of the yard. In that way, Moses finished the work. In that way, Moses finished the work."
    },
    {
      "verse": "34",
      "text": "Then the cloud covered the Tent of Meeting. The glory of the Lord filled the tabernacle."
    },
    {
      "verse": "35",
      "text": "Moses could not go into the Tent of Meeting because of the cloud and the bright glory of the Lord."
    },
    {
      "verse": "36",
      "text": "The Israelites followed the cloud during all their journeys. Every time that the cloud rose up from the tabernacle, they would continue on their journey."
    },
    {
      "verse": "37",
      "text": "But if the cloud remained on the tabernacle, the Israelites did not travel. They stayed where they were until the day when the cloud rose up."
    },
    {
      "verse": "38",
      "text": "So the cloud stayed over the tabernacle during the day, to show that the Lord was with them. During the night, there was fire in the cloud. All the Israelites could see the cloud during all their journeys."
    }
  ]
};