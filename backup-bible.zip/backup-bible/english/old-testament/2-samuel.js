module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "After David had won the fight against the Amalekites, he returned to Ziklag. He stayed in Ziklag for two days. Saul had already died."
    },
    {
      "verse": "2",
      "text": "The next day, a man arrived from the camp of Saul's army. He had dirt on his head and he had torn his clothes. When the man met David, he threw himself down on the ground to give honour to David."
    },
    {
      "verse": "3",
      "text": "David asked him, ‘Where have you come from? ’The man replied, ‘I have run from the Israelite army's camp. ’ The man replied, ‘I have run from the Israelite army's camp. ’"
    },
    {
      "verse": "4",
      "text": "David said, ‘Tell me what happened in the battle. ’The man replied, ‘The Israelites ran away and the enemy killed many of them. Even Saul and his son Jonathan are dead. ’ The man replied, ‘The Israelites ran away and the enemy killed many of them. Even Saul and his son Jonathan are dead. ’"
    },
    {
      "verse": "5",
      "text": "When the young man told this to David, David asked him, ‘How do you know that Saul and his son Jonathan are dead? ’"
    },
    {
      "verse": "6",
      "text": "The young man said, ‘I was on Gilboa mountain. I saw Saul there. He had to use his spear like a stick to help him to stand. The enemy army with its horses and chariots were getting very near to him."
    },
    {
      "verse": "7",
      "text": "Saul turned round and he saw me. He shouted to me and I said, “Here I am, sir. ”"
    },
    {
      "verse": "8",
      "text": "He asked me, “Who are you? ”I said to him, “I am an Amalekite. ” I said to him, “I am an Amalekite. ”"
    },
    {
      "verse": "9",
      "text": "He said to me, “Stand over me and kill me. I have a lot of pain and I am almost dead. ”"
    },
    {
      "verse": "10",
      "text": "I knew that he would soon fall down. He was too weak to live. So I stood over him and I killed him. Then I took the crown from his head and the ring that was on his arm. I have brought them here to you, my lord. ’"
    },
    {
      "verse": "11",
      "text": "Then David tore his clothes because he was very upset. The men who were with him did the same thing."
    },
    {
      "verse": "12",
      "text": "They cried and they wept until the evening. They did not eat any food. They were very upset about Saul and Jonathan, and all the Lord's people. They were sad because so many Israelites had died in the battle."
    },
    {
      "verse": "13",
      "text": "David asked the young man who had brought the report to him, ‘Where are you from? ’The man replied, ‘I am an Amalekite, the son of a foreign man who lives in Israel. ’ The man replied, ‘I am an Amalekite, the son of a foreign man who lives in Israel. ’"
    },
    {
      "verse": "14",
      "text": "David said to him, ‘The Lord had chosen Saul to be Israel's king. You should have been very afraid to kill him! ’"
    },
    {
      "verse": "15",
      "text": "Then David said to one of his own young men, ‘Go and knock him down! ’ So the man knocked him down so that he died."
    },
    {
      "verse": "16",
      "text": "David had said to the Amalekite, ‘You deserve to die because of what you have said. Your own words show that you did a bad thing. You yourself said, “I have killed the Lord's chosen king. ” ’"
    },
    {
      "verse": "17",
      "text": "David sang this song to remember the death of Saul and his son Jonathan."
    },
    {
      "verse": "18",
      "text": "He said that the people in Judah should learn this song. Its name is ‘The Bow’. It is written down in the Book of Jashar."
    },
    {
      "verse": "19",
      "text": "‘The greatest men of Israel now lie on the mountains. They are dead! Those brave men have fallen to the ground! Those brave men have fallen to the ground!"
    },
    {
      "verse": "20",
      "text": "Do not tell the people in Gath about it. Do not tell the news in the streets of Ashkelon. If you do, the daughters of the Philistines will sing with joy. Yes, those foreign people who do not worship God will be happy. Do not tell the news in the streets of Ashkelon. If you do, the daughters of the Philistines will sing with joy. Yes, those foreign people who do not worship God will be happy."
    },
    {
      "verse": "21",
      "text": "You mountains of Gilboa, I hope that no rain or dew will come on you now. I pray that no crops will grow in your fields to make grain offerings. In those fields, the shields of brave soldiers became useless. No longer will anyone clean Saul's shield with oil. I pray that no crops will grow in your fields to make grain offerings. In those fields, the shields of brave soldiers became useless. No longer will anyone clean Saul's shield with oil."
    },
    {
      "verse": "22",
      "text": "When Jonathan shot arrows from his bow, his enemies fell to the ground, dead. He would never turn away from them. Saul's sword also cut down his enemies. He always finished the job. his enemies fell to the ground, dead. He would never turn away from them. Saul's sword also cut down his enemies. He always finished the job."
    },
    {
      "verse": "23",
      "text": "People loved Saul and Jonathan as great people while they lived. They were still together when they died. They moved faster than eaglesThey were stronger than lions. They were still together when they died. They moved faster than eagles They were stronger than lions."
    },
    {
      "verse": "24",
      "text": "You women of Israel, weep for Saul. He gave you beautiful clothes to wear. He gave you gold and jewels to fix on your clothes. He gave you beautiful clothes to wear. He gave you gold and jewels to fix on your clothes."
    },
    {
      "verse": "25",
      "text": "Brave soldiers have died as they fought a great battle! Jonathan's dead body lies on Gilboa's hills. Jonathan's dead body lies on Gilboa's hills."
    },
    {
      "verse": "26",
      "text": "My brother, Jonathan! I am very sad about your death. You were my good friend. Your love for me was very special. It was better than the love of women. You were my good friend. Your love for me was very special. It was better than the love of women."
    },
    {
      "verse": "27",
      "text": "The brave men have fallen in the battle! Their weapons are now useless. ’"
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "After some time, David asked the Lord, ‘Should I go up to one of Judah's towns? ’The Lord said to him, ‘Go up. ’David asked, ‘Where should I go? ’The Lord replied, ‘Go to Hebron. ’ The Lord said to him, ‘Go up. ’ David asked, ‘Where should I go? ’ The Lord replied, ‘Go to Hebron. ’"
    },
    {
      "verse": "2",
      "text": "So David went up to Hebron. He took his two wives with him. They were Ahinoam of Jezreel and Abigail, Nabal's widow, from Carmel."
    },
    {
      "verse": "3",
      "text": "David also took the men who had been with him. Each man took his family. They lived in Hebron and in the towns near there."
    },
    {
      "verse": "4",
      "text": "Then the men of Judah's tribe came to Hebron. They anointed David as king over Judah's people. David heard that the people from Jabesh Gilead had buried Saul's body."
    },
    {
      "verse": "5",
      "text": "So David sent men to them with a message. He said, ‘You were kind to Saul, your master, when you buried his body. So I pray that the Lord will bless you."
    },
    {
      "verse": "6",
      "text": "I pray that the Lord will keep you safe with his faithful love. I too will do good things for you, because of what you have done."
    },
    {
      "verse": "7",
      "text": "Saul, your master, is dead, so you must continue to be strong and brave. The people of Judah have now chosen me to rule them as king. ’"
    },
    {
      "verse": "8",
      "text": "Ner's son Abner was the leader of Saul's army. He took Saul's son Ish-Bosheth to Mahanaim."
    },
    {
      "verse": "9",
      "text": "Abner gave Ish-Bosheth authority to rule as king over Gilead, Asher and Jezreel, as well as the tribes of Ephraim and Benjamin. So Ish-Bosheth became king of all Israel."
    },
    {
      "verse": "10",
      "text": "Saul's son, Ish-Bosheth, was 40 years old when he became king over Israel. He ruled Israel for two years. But Judah's people were faithful to David as their king."
    },
    {
      "verse": "11",
      "text": "David remained in Hebron as king of Judah for seven and a half years."
    },
    {
      "verse": "12",
      "text": "Then Ner's son, Abner, left Mahanaim and he went to Gibeon. He took with him the men who served Saul's son, Ish-Bosheth."
    },
    {
      "verse": "13",
      "text": "Zeruiah's son, Joab, took David's men to meet Abner's men at the pool of Gibeon. One group sat on one side of the pool while the other group sat on the other side."
    },
    {
      "verse": "14",
      "text": "Then Abner said to Joab, ‘Some young men from each of our groups should fight against each other. Then we can watch them. ’ Joab agreed."
    },
    {
      "verse": "15",
      "text": "men to fight on behalf of Benjamin and Ish-Bosheth. They also chose 12 of David's men to fight against them."
    },
    {
      "verse": "16",
      "text": "As they fought, each man took hold of his enemy's head. And each man pushed his sword into his enemy's side. So they all fell down together and they were dead. So people called that place ‘The Field of Swords’. It is in Gibeon."
    },
    {
      "verse": "17",
      "text": "That day, the two groups fought a great battle against each other. David's men won the fight against Abner and the men of Israel."
    },
    {
      "verse": "18",
      "text": "Zeruiah's three sons were there. They were Joab, Abishai and Asahel. Asahel could run as fast as a wild deer. ‘Yes, it is, ’ he answered."
    },
    {
      "verse": "19",
      "text": "He chased after Abner. He ran straight after him. He did not turn to the right or to the left."
    },
    {
      "verse": "20",
      "text": "Abner looked behind him and he asked, ‘Is that you, Asahel? ’‘Yes, it is, ’ he answered."
    },
    {
      "verse": "21",
      "text": "Then Abner said to him, ‘Turn away from me to the right or to the left. Then you can chase one of the young soldiers and you can take his weapons. ’ But Asahel would not stop chasing after Abner."
    },
    {
      "verse": "22",
      "text": "Abner said again to Asahel, ‘Stop chasing after me. I do not want to knock you down to the ground. If I kill you, I will never be able to show myself to your brother Joab again! ’"
    },
    {
      "verse": "23",
      "text": "But Asahel refused to stop chasing Abner. So Abner pushed the stick of his spear behind him into Asahel's stomach. It went through his body and came out of his back. Asahel fell to the ground immediately and he died there. When anyone came to that place, they stopped to look at Asahel's body."
    },
    {
      "verse": "24",
      "text": "But Joab and Abishai continued to chase after Abner. When the sun was going down, they reached Ammah hill, near Giah. That was on the road to the wilderness of Gibeon."
    },
    {
      "verse": "25",
      "text": "Then the men of Benjamin's tribe joined with Abner. They were all ready to fight as one group. They stood together at the top of a hill."
    },
    {
      "verse": "26",
      "text": "Abner shouted to Joab, ‘We should stop fighting. We do not want to continue killing one another for ever. In the end, we would all be very sad. Please tell your men to stop chasing after their brothers. ’"
    },
    {
      "verse": "27",
      "text": "Joab replied, ‘As surely as God lives, I agree! If you had not spoken, our men would have chased you all through the night. They would not have stopped until the morning. ’"
    },
    {
      "verse": "28",
      "text": "So Joab made a loud noise with the trumpet. Then all his men stopped where they were. They did not continue to chase after the men of Israel. They stopped fighting."
    },
    {
      "verse": "29",
      "text": "Abner and his men marched all that night through the Jordan Valley. They crossed over the Jordan River. They continued to march all the next morning until they arrived back at Mahanaim."
    },
    {
      "verse": "30",
      "text": "Joab left the battle and he returned with David's men. They counted all the soldiers. Asahel had died, as well as 19 other men."
    },
    {
      "verse": "31",
      "text": "But David's soldiers had killed 360 men of Benjamin's tribe who were fighting in Abner's army."
    },
    {
      "verse": "32",
      "text": "They took Asahel's body from the place where he died. They buried him in his father's grave at Bethlehem. Then Joab and his men marched all night. They arrived home at Hebron at dawn."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "David's men continued to fight against the men who were faithful to Saul's family. The war continued for a long time. David's army became stronger and stronger, but Saul's army became weaker and weaker."
    },
    {
      "verse": "2",
      "text": "While David lived in Hebron he had several sons: The firstborn was Amnon. Ahinoam from Jezreel gave birth to him. These sons of David were all born in Hebron."
    },
    {
      "verse": "3",
      "text": "The second son was Kileab. Nabal's widow, Abigail, from Carmel gave birth to him. The third son was Absalom. His mother was Maakah, the daughter of Talmai, king of Geshur."
    },
    {
      "verse": "4",
      "text": "The fourth son was Adonijah. His mother was Haggith. The fifth son was Shephatiah. Abital was his mother."
    },
    {
      "verse": "5",
      "text": "The sixth son was Ithream. David's wife, Eglah, gave birth to him. These sons of David were all born in Hebron."
    },
    {
      "verse": "6",
      "text": "The war continued between David's men and the men who fought on behalf of Saul's family. Abner was becoming a more powerful leader among Saul's group."
    },
    {
      "verse": "7",
      "text": "Saul had had slave wife called Rizpah. She was Aiah's daughter. One day, Ish-Bosheth asked Abner, ‘Why did you sleep with my father's woman? ’"
    },
    {
      "verse": "8",
      "text": "Abner was very angry because of what Ish-Bosheth had said to him. Abner said, ‘Do you think that I am a useless dog that belongs to Judah? I have always been faithful to your father Saul and to his family and his friends. I have not deceived you to put you under David's power. But now you say that I am guilty of a sin with this woman."
    },
    {
      "verse": "9",
      "text": "So I promise you this! Now I will help David to get what the Lord has promised to him. I ask God to punish me if I do not help David!"
    },
    {
      "verse": "10",
      "text": "The Lord promised that David's family would rule as kings instead of Saul's family. He promised that David would be king over all the people of Israel and Judah, from Dan to Beersheba. ’"
    },
    {
      "verse": "11",
      "text": "Ish-Bosheth was so afraid of Abner that he could not say anything."
    },
    {
      "verse": "12",
      "text": "Then Abner sent men to David with this message: ‘Who should rule this country? If you make an agreement with me, I will help you. I will cause all Israel's people to be faithful to you. ’"
    },
    {
      "verse": "13",
      "text": "David said, ‘That is good! I will make an agreement with you. But you must do this for me: You must bring Saul's daughter, Michal, with you when you come to visit me. If you do not do that, I will not agree to see you. ’"
    },
    {
      "verse": "14",
      "text": "Then David sent men to Saul's son, Ish-Bosheth, with this message: ‘Give back to me my wife, Michal. I paid 100 Philistine foreskins to have her as my wife. ’"
    },
    {
      "verse": "15",
      "text": "So Ish-Bosheth sent his men to take Michal from her husband, Paltiel, son of Laish."
    },
    {
      "verse": "16",
      "text": "But her husband came with her. He wept while he followed her all the way to Bahurim. Then Abner said to him, ‘Return to your home! ’ So he returned home."
    },
    {
      "verse": "17",
      "text": "Then Abner talked to the leaders of Israel. He said, ‘For a long time you have wanted David to be your king."
    },
    {
      "verse": "18",
      "text": "So now is your chance to do something! Remember that the Lord promised, “I will use David's strength to save my people, Israel, from the Philistines and from all their enemies. ” ’"
    },
    {
      "verse": "19",
      "text": "Abner also went himself to speak to the men of Benjamin's tribe. After that, he went to Hebron. He went to tell David what all Israel's people had agreed to do. All the people of Benjamin's tribe had also agreed the same thing."
    },
    {
      "verse": "20",
      "text": "of his men to visit David. David prepared a feast for Abner and the men who were with him."
    },
    {
      "verse": "21",
      "text": "Then Abner said to David, ‘Please let me go now to bring all the people of Israel together for my lord the king. Then they will make an agreement with you. Then you will rule over the whole land, as you really want to do. ’ So David sent Abner away, with a promise that he would be safe."
    },
    {
      "verse": "22",
      "text": "David's men and Joab had attacked some of the enemy's towns. Now they were returning home. They brought with them a lot of things that they had taken from the enemy. By this time Abner had left Hebron because David had sent him away safely."
    },
    {
      "verse": "23",
      "text": "When Joab and all his soldiers arrived in Hebron, people told him, ‘Ner's son Abner came to visit the king. The king sent him back home safely. ’"
    },
    {
      "verse": "24",
      "text": "Joab went to the king. He said, ‘Why did you do this? Abner came to visit you. You allowed him to go back home safely. Now he has gone."
    },
    {
      "verse": "25",
      "text": "You should know what Abner is like. He came here to deceive you. He wanted to find out everything that you do and everywhere that you go. ’"
    },
    {
      "verse": "26",
      "text": "Then Joab left David. He sent men to run after Abner with a message. They found him at the well at Sirah and they brought him back to Hebron. But David did not know that."
    },
    {
      "verse": "27",
      "text": "When Abner returned to Hebron, Joab met him at the city's gate. Then Joab took him into a corner, as if he wanted to speak with Abner alone. But he pushed his knife into Abner's stomach. Joab killed Abner because Abner had killed Asahel, Joab's brother."
    },
    {
      "verse": "28",
      "text": "Later, David heard about what Joab had done. He said, ‘The Lord knows this: I and the people of my kingdom are not guilty of Abner's murder."
    },
    {
      "verse": "29",
      "text": "I pray that Joab and all his father's family will pay for this murder! May God punish his descendants for ever! May somebody always have sores or leprosy. May there be men who are not brave enough to fight, men who die in battle, or people who have no food to eat! ’"
    },
    {
      "verse": "30",
      "text": "That is how Joab and his brother Abishai killed Abner. They killed him because he had killed their brother Asahel in the battle at Gibeon."
    },
    {
      "verse": "31",
      "text": "David said to Joab and to all the people who were with him, ‘Tear your clothes! Wear sackcloth to show that you are sad! Weep because of Abner's death. ’ King David himself walked behind the men who carried Abner's dead body."
    },
    {
      "verse": "32",
      "text": "They buried Abner in a grave in Hebron. The king wept loudly beside Abner's grave. All the people wept too."
    },
    {
      "verse": "33",
      "text": "The king sang this song about Abner's death:‘Abner, you should not have died like a fool. ‘Abner, you should not have died like a fool."
    },
    {
      "verse": "34",
      "text": "Nobody had tied your hands. Nobody had put chains on your feet. It was murder by wicked people that killed you. ’Then all the people started to weep again for Abner. Nobody had put chains on your feet. It was murder by wicked people that killed you. ’ Then all the people started to weep again for Abner."
    },
    {
      "verse": "35",
      "text": "The people came and they spoke to David. They said that he should eat some food before the end of the day. But David said, ‘I will not eat any food at all before sunset. May God punish me if I eat anything! ’"
    },
    {
      "verse": "36",
      "text": "All the people heard David say this. It made them happy. They were pleased with everything that the king did."
    },
    {
      "verse": "37",
      "text": "That day, everyone in Israel realized that David had not wanted the death of Ner's son, Abner."
    },
    {
      "verse": "38",
      "text": "The king said to his servants, ‘You must understand that a great leader has died today in Israel."
    },
    {
      "verse": "39",
      "text": "I am God's chosen king, but even I am weak today. I cannot control these sons of Zeruiah! They have done a wicked thing. I pray that the Lord will punish them as they deserve. ’"
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Saul's son Ish-Bosheth heard the news that Abner had died in Hebron. Then he felt very frightened. All the people in Israel became afraid."
    },
    {
      "verse": "2",
      "text": "Ish-Bosheth had two officers called Baanah and Recab. They were leaders of small groups of soldiers. Their father was Rimmon from Beeroth. He belonged to Benjamin's tribe. At that time, Beeroth was part of Benjamin's land."
    },
    {
      "verse": "3",
      "text": "The people from Beeroth had run away to Gittaim. So Beeroth's people still live there as strangers."
    },
    {
      "verse": "4",
      "text": "Saul's son Jonathan had a son called Mephibosheth. Since he was five years old he had not been able to walk. At that time someone had come from Jezreel to say that Saul and Jonathan had died. So Mephibosheth's nurse picked him up to escape with him. But as she ran in a hurry, he fell to the ground. It hurt his feet very badly."
    },
    {
      "verse": "5",
      "text": "Rimmon's sons, Recab and Baanah, left their home and they went to Ish-Bosheth's house. They arrived in the middle of the day when it was very hot. Ish-Bosheth was resting on his bed."
    },
    {
      "verse": "6",
      "text": "They went into the house as if they wanted to get some wheat. But they pushed knives into Ish-Bosheth's stomach. Then Recab and his brother Baanah escaped."
    },
    {
      "verse": "7",
      "text": "When they had gone into the house, Ish-Bosheth had been lying on his bed in his bedroom. After they had killed him, they cut off his head. They took it with them and they travelled all night through the Jordan Valley."
    },
    {
      "verse": "8",
      "text": "They brought Ish-Bosheth's head to David in Hebron. They said to the king, ‘Here is the head of Ish-Bosheth, Saul's son! Saul was your enemy who wanted to kill you. So today the Lord has punished him and his descendants. They have paid for the bad things that they did to you, our lord, the king. ’"
    },
    {
      "verse": "9",
      "text": "David answered Recab and his brother Baanah, the sons of Rimmon from Beeroth. He said to them, ‘The Lord has rescued me from all my troubles. So I tell you this, as surely as the Lord lives:"
    },
    {
      "verse": "10",
      "text": "When someone told me in Ziklag, “Saul is dead”, he thought that he was bringing good news to me. But I took hold of him and I told my men to kill him. That was how I paid him for his good news!"
    },
    {
      "verse": "11",
      "text": "Now you wicked men have done a worse thing. You killed a good man in his own house while he was asleep! So I must surely punish you for his death. You must disappear from the earth! ’"
    },
    {
      "verse": "12",
      "text": "So David commanded his young men to kill Recab and Baanah. After they had killed them, they cut off their hands and their feet. They hung the dead bodies by the pool in Hebron. But they took Ish-Bosheth's head and they buried it in Abner's grave in Hebron."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "All Israel's tribes came to David at Hebron. They said, ‘We all belong to the same family as you do."
    },
    {
      "verse": "2",
      "text": "In the past, when Saul ruled over us as king, you were the leader of Israel's army in the wars. The Lord said to you, “You will take care of my people as a shepherd takes care of his sheep. You will rule over Israel. ” ’"
    },
    {
      "verse": "3",
      "text": "So King David made an agreement with the leaders of Israel when they came to him at Hebron. They made promises in the Lord's name. Then they anointed David to be king over Israel."
    },
    {
      "verse": "4",
      "text": "years old when he became king. He ruled Israel as king for 40 years."
    },
    {
      "verse": "5",
      "text": "He ruled over Judah in Hebron for seven years and six months. And in Jerusalem he ruled over all Israel and Judah for 33 years."
    },
    {
      "verse": "6",
      "text": "King David and his soldiers marched to Jerusalem. They went to attack the Jebusites who lived there. The Jebusites said to David, ‘You will never get into our city. Even blind men and those who are lame could keep you out. ’They thought, ‘David will never get in here. ’ They thought, ‘David will never get in here. ’"
    },
    {
      "verse": "7",
      "text": "But David did get in and he took Zion, the city's strong place. It is now called ‘The City of David’."
    },
    {
      "verse": "8",
      "text": "On that day, David said to his men, ‘We must attack my enemies, the Jebusites. To do that, we must go into the city through the water tunnel. Then we will see if their blind and lame people can stop us! I hate them all. ’That is why people still say, ‘Anybody who is blind or lame must not go into the palace. ’ That is why people still say, ‘Anybody who is blind or lame must not go into the palace. ’"
    },
    {
      "verse": "9",
      "text": "Then David went to live in the strong place of the city. He called it ‘The City of David’. He built more houses all around it, from the edge of the hill into the city."
    },
    {
      "verse": "10",
      "text": "David became more and more powerful because the Lord God Almighty was with him."
    },
    {
      "verse": "11",
      "text": "Then Hiram, king of Tyre, sent some of his men to David. They brought wood from Lebanon's cedar trees. Men who could work with wood and stone also came. They built a palace for David."
    },
    {
      "verse": "12",
      "text": "David knew that the Lord had made him strong as king over Israel. He knew that God had given honour to his kingdom, to help his people, the Israelites."
    },
    {
      "verse": "13",
      "text": "After David moved to Jerusalem from Hebron, he married more wives. He also took more slave wives to live with him. They gave birth to more sons and daughters for David."
    },
    {
      "verse": "14",
      "text": "These are the names of David's children who were born in Jerusalem: Shammua, Shobab, Nathan, Solomon,"
    },
    {
      "verse": "15",
      "text": "Ibhar, Elishua, Nepheg, Japhia,"
    },
    {
      "verse": "16",
      "text": "Elishama, Eliada and Eliphelet."
    },
    {
      "verse": "17",
      "text": "The Philistines heard the news that David had now become king over Israel. So their whole army went to look for him to catch him. When David heard about this, he went out of the city to a strong, safe place."
    },
    {
      "verse": "18",
      "text": "The Philistine soldiers arrived at Rephaim valley. They covered all the ground there. The Lord answered him, ‘Yes, go and attack the Philistines. I will certainly help you to win against them. ’"
    },
    {
      "verse": "19",
      "text": "So David asked the Lord, ‘Should I go and attack the Philistines? Will you put them under my power? ’The Lord answered him, ‘Yes, go and attack the Philistines. I will certainly help you to win against them. ’"
    },
    {
      "verse": "20",
      "text": "So David went to Baal Perazim. He won the fight against the Philistines in that place. He said, ‘The Lord has swept away my enemy like a flood of water. ’ So they called that place ‘Baal Perazim’."
    },
    {
      "verse": "21",
      "text": "When the Philistines ran away from there, they did not take their idols with them. So David and his men took them away."
    },
    {
      "verse": "22",
      "text": "Once again, the Philistine soldiers came and they covered the ground in Rephaim valley."
    },
    {
      "verse": "23",
      "text": "So David again asked the Lord what he should do. This time the Lord said, ‘Do not march straight towards them. Instead, go round behind them. Then attack them from the other side, where the poplar trees are."
    },
    {
      "verse": "24",
      "text": "When you hear a noise in the tops of the trees like marching men, go quickly to attack them. Then you will know that the Lord has gone in front of you. He will knock down the Philistine army for you. ’"
    },
    {
      "verse": "25",
      "text": "So David did as the Lord had commanded him to do. His men chased the Philistines all the way from Gibeon to Gezer."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "David chose 30, 000 of the best soldiers in Israel."
    },
    {
      "verse": "2",
      "text": "He took them with him to Baalah, a town in Judah. He wanted to bring God's Covenant Box from there to Jerusalem. The Israelites called it by the name of the Lord Almighty. He sits as King between the two cherubs that are on the top of the Covenant Box."
    },
    {
      "verse": "3",
      "text": "They put the Covenant Box on a new cart. They took it out of Abinadab's house which was on the hill. Abinadab's sons, Uzzah and Ahio, were leading the new cart"
    },
    {
      "verse": "4",
      "text": "which had the Covenant Box on it. Ahio walked in front of the Covenant Box."
    },
    {
      "verse": "5",
      "text": "David and all Israel's people were singing and dancing with all their strength to praise the Lord. They made music with harps, lyres, tambourines, shakers and cymbals."
    },
    {
      "verse": "6",
      "text": "They reached the place of Nacon's threshing floor. There the oxen that were pulling the cart almost fell. So Uzzah reached out to hold God's Covenant Box to stop it falling."
    },
    {
      "verse": "7",
      "text": "The Lord was very angry with Uzzah because he did not respect God's rules. He immediately knocked Uzzah down to the ground. Uzzah died there, beside the Covenant Box."
    },
    {
      "verse": "8",
      "text": "David was angry because the Lord had punished Uzzah. So he called that place ‘Perez Uzzah’. That is still its name today."
    },
    {
      "verse": "9",
      "text": "So David now became afraid of the Lord. He said, ‘The Lord's Covenant Box is too holy to come with me! ’"
    },
    {
      "verse": "10",
      "text": "He no longer wanted to take the Lord's Covenant Box to the City of David to be with him there. Instead, he took it to the house of Obed-Edom, who came from Gath."
    },
    {
      "verse": "11",
      "text": "The Lord's Covenant Box stayed in Obed-Edom's house for three months. During that time, the Lord blessed Obed-Edom and all the people in his house."
    },
    {
      "verse": "12",
      "text": "People told King David, ‘The Lord has blessed Obed-Edom's family and everything that belongs to him, because of the Covenant Box. ’So David went back to Obed-Edom's house. He was now happy to bring the Covenant Box from there to the City of David."
    },
    {
      "verse": "13",
      "text": "The men who were carrying it walked six steps and they stopped. Then David offered a bull and a fat calf as sacrifices to God."
    },
    {
      "verse": "14",
      "text": "David was wearing a linen ephod. He danced with all his strength to worship the Lord."
    },
    {
      "verse": "15",
      "text": "He and all the Israelites brought the Lord's Covenant Box to Jerusalem. They shouted and they made a loud noise with trumpets."
    },
    {
      "verse": "16",
      "text": "While they were bringing the Lord's Covenant Box into the City of David, Saul's daughter Michal looked out through a window. She saw what King David was doing. He was jumping and dancing to worship the Lord. Michal felt ashamed of him."
    },
    {
      "verse": "17",
      "text": "David had put up a special tent for the Covenant Box, so they took it there. They put it in its place inside the tent. Then David offered burnt offerings and friendship offerings to the Lord."
    },
    {
      "verse": "18",
      "text": "After David had offered those sacrifices, he prayed that the Lord Almighty would bless the people."
    },
    {
      "verse": "19",
      "text": "Then he gave a gift to every man and woman in the crowd of Israelite people. Each person received a loaf of bread, some dates and some raisins. Then all the people went to their homes."
    },
    {
      "verse": "20",
      "text": "David returned to his home to bless his own family. As he arrived, Saul's daughter Michal came out to meet him. She said, ‘The king of Israel has brought honour to himself today, has he? No, he has brought shame on himself! Even your officers' slave girls have seen how stupid you are. You have made your body bare like a useless fool! ’"
    },
    {
      "verse": "21",
      "text": "David said to Michal, ‘I was worshipping the Lord with joy! It was the Lord who chose me to be the ruler of his people, Israel. He chose me instead of your father or any of his family."
    },
    {
      "verse": "22",
      "text": "I am ready to bring even more shame on myself. Even I will be ashamed of myself! But the slave girls that you spoke about will still give me honour! ’"
    },
    {
      "verse": "23",
      "text": "Saul's daughter Michal gave birth to no children all her life."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "The king was living in his palace. The Lord kept him safe from all his enemies everywhere."
    },
    {
      "verse": "2",
      "text": "One day, the king said to Nathan the prophet, ‘I am living in a beautiful palace that is made of cedar wood. But God's Covenant Box still has a tent for its home! ’"
    },
    {
      "verse": "3",
      "text": "Nathan replied to the king, ‘Do what you think is right. The Lord will help you. ’"
    },
    {
      "verse": "4",
      "text": "But that night the Lord said to Nathan,"
    },
    {
      "verse": "5",
      "text": "‘Go and tell my servant David, “The Lord says this: Do not think that you are the right man to build a house for me to live in."
    },
    {
      "verse": "6",
      "text": "From the time that I brought Israel's people out of Egypt until now, I have never lived in a house. While my people moved from place to place, I travelled with them. I lived in a tent as my home."
    },
    {
      "verse": "7",
      "text": "I have moved about to many different places with the Israelite people. I chose leaders to take care of Israel's tribes, like shepherds for them. But in all that time, I never said to any of the leaders, ‘You should have built a beautiful house of cedar wood for me. ’"
    },
    {
      "verse": "8",
      "text": "So tell my servant David that the Lord Almighty says this: I took you from the fields where you were taking care of sheep. I took you from there to become the ruler of my people Israel."
    },
    {
      "verse": "9",
      "text": "I have been with you everywhere that you have gone. I destroyed all your enemies that were attacking you. Now I will make you famous. Your name will be as great as the names of the earth's greatest men."
    },
    {
      "verse": "10",
      "text": "I have chosen a place where my people Israel will live. I have put them in that place, where they can be safe. They will not be afraid of trouble from any enemy. Wicked people will not hurt them any more. That happened in the past,"
    },
    {
      "verse": "11",
      "text": "from the time that I chose leaders to rule my people Israel. But now I will keep you safe from all your enemies. I, the Lord, say to you, David: I will give you descendants who will rule as kings after you. That will be the royal house that I build for you!"
    },
    {
      "verse": "12",
      "text": "When you die, people will bury you in the grave of your ancestors. Then I will choose your descendant, one of your own sons, to become king. I will make his kingdom strong."
    },
    {
      "verse": "13",
      "text": "He is the man who will build a house for me. People will give honour to my name there. I will cause his descendants to rule as kings for ever."
    },
    {
      "verse": "14",
      "text": "I will be his father and he will be my son. When he does something wrong, I will punish him, so that he learns to do what is right. I will punish him in the way that human fathers punish their sons."
    },
    {
      "verse": "15",
      "text": "I removed my faithful love from Saul, and I removed him as king before you. But I will always continue to faithfully love your son."
    },
    {
      "verse": "16",
      "text": "The kingdom that your descendants rule will continue for ever. Someone from your family will always be king. ” ’"
    },
    {
      "verse": "17",
      "text": "Nathan told David the whole message that God had shown to him."
    },
    {
      "verse": "18",
      "text": "Then King David went into the Lord's tent. He sat down and he prayed to the Lord. He said, ‘Almighty Lord, I am not a special person and my family is not special. You have helped me very much and I do not deserve it."
    },
    {
      "verse": "19",
      "text": "You have also made a promise about the descendants in my family, Almighty Lord. You have promised to help them in the future, as well as me. I am only a man but you have shown this to me, Almighty Lord."
    },
    {
      "verse": "20",
      "text": "I am your servant, Almighty Lord, and you know me completely. There is nothing more that I can say."
    },
    {
      "verse": "21",
      "text": "Because of your covenant you have chosen to do all these great things. You have told me, your servant, what you promise to do."
    },
    {
      "verse": "22",
      "text": "Almighty Lord, you are very great. There is nobody like you. You alone are God. What we have heard about you is true!"
    },
    {
      "verse": "23",
      "text": "There is no other nation on earth like your people, Israel. We are the only nation that you have rescued so that we would belong to you. You did that to show that your name is great. You did great miracles to rescue your people from Egypt where they were slaves. Then you chased out other nations and their gods from the land that you were giving to your people."
    },
    {
      "verse": "24",
      "text": "You chose Israel to be your own people for all time. You, Lord, became our God."
    },
    {
      "verse": "25",
      "text": "Lord God, please do the things that you have promised to do for me, your servant, and for my family. Continue to do for ever what you have promised to do."
    },
    {
      "verse": "26",
      "text": "Then people will always give honour to your great name. They will say, “The Lord Almighty is the God who rules over Israel! ” And David's descendants will continue to serve you as kings."
    },
    {
      "verse": "27",
      "text": "Lord Almighty, Israel's God, you have made this promise to me, your servant. You have said to me, “You will always have descendants who will rule. That is the house that I will build for you. ” That is why I am not afraid to pray to you like this."
    },
    {
      "verse": "28",
      "text": "Almighty Lord, you are the true God. We trust your promises. You have promised these good things to me, your servant."
    },
    {
      "verse": "29",
      "text": "I pray that you will be pleased to bless my family and my descendants. Then we will serve you faithfully for ever. Almighty Lord, you have promised to do this. So I know that you will continue to bless my descendants for ever. ’"
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Some time later, David attacked the Philistines, and he won the fight against them. He now had power over them and over their towns."
    },
    {
      "verse": "2",
      "text": "David also won a battle against the Moabites. He made the Moabite prisoners lie down on the ground. Then he used a piece of rope to measure them into groups. When he had measured two groups, he would tell his men to kill all those prisoners. When he measured the next group, he would let those prisoners stay alive. So the Moabites were now under David's authority and they began to pay taxes to him."
    },
    {
      "verse": "3",
      "text": "David also won a battle against Rehob's son, Hadadezer, king of Zobah. This happened when Hadadezer took his army to the Euphrates river to show that he had authority there."
    },
    {
      "verse": "4",
      "text": "David took from Hadadezer 1, 700 men who drove chariots. He also caught 20, 000 of Hadadezer's other soldiers. David kept 100 of the horses that pulled chariots. But he cut the legs of the other horses so that they could not run."
    },
    {
      "verse": "5",
      "text": "The Syrians from Damascus sent an army to help King Hadadezer of Zobah. But David killed 22, 000 soldiers of the Syrian army."
    },
    {
      "verse": "6",
      "text": "David put groups of his soldiers in Damascus to be guards over the Syrian people. So the Syrians were now under David's authority and they paid taxes to him. The Lord helped David to win all the battles that he fought."
    },
    {
      "verse": "7",
      "text": "David took the gold shields that Hadadezer's officers had carried. He brought the shields to Jerusalem."
    },
    {
      "verse": "8",
      "text": "David also took a lot of bronze things from Tebah and Berothai, towns that had belonged to Hadadezer."
    },
    {
      "verse": "9",
      "text": "Toi, the king of Hamath, heard news that David had won the battle against the whole army of Hadadezer."
    },
    {
      "verse": "10",
      "text": "There had been a war between King Hadadezer and King Toi. So now Toi sent his son, Joram to say ‘hello’ to David. He wanted to thank David because he had won the battle against King Hadadezer. Joram brought gifts to David that were made of gold, silver and bronze."
    },
    {
      "verse": "11",
      "text": "David took these gifts and he offered them to the Lord. He also offered to the Lord all the silver and gold things that he had taken from other nations. Those were all the nations that David had won against in battle."
    },
    {
      "verse": "12",
      "text": "They included Edom, Moab, the Ammonites, the Philistines and the Amalekites. He also offered to the Lord things that he had taken from Rehob's son, King Hadadezer of Zobah."
    },
    {
      "verse": "13",
      "text": "After that, David's army won a battle in the Valley of Salt against 18, 000 Edomites. David became very famous because of that."
    },
    {
      "verse": "14",
      "text": "He put groups of his soldiers in every part of Edom's land, so that David had authority over all the Edomites. The Lord helped David to win all the battles that he fought."
    },
    {
      "verse": "15",
      "text": "David ruled over all Israel. He did everything that was right and fair for all his people."
    },
    {
      "verse": "16",
      "text": "Zeruiah's son, Joab, was the leader of Israel's army. Ahilud's son, Jehoshaphat, wrote down the important things that happened."
    },
    {
      "verse": "17",
      "text": "Ahitub's son Zadok and Abiathar's son Ahimelech were priests. Seraiah was David's secretary."
    },
    {
      "verse": "18",
      "text": "Jehoiada's son Benaiah was the leader of David's personal guards. David's sons served as priests."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "David asked, ‘Is there anyone from Saul's family who is still alive? I want to be kind to them because Jonathan was my friend. ’"
    },
    {
      "verse": "2",
      "text": "Saul's family had a servant called Ziba. So they asked him to come to see David. The king said to him, ‘Are you Ziba? ’Ziba replied, ‘Yes, I am your servant. ’ Ziba replied, ‘Yes, I am your servant. ’"
    },
    {
      "verse": "3",
      "text": "The king asked him, ‘Is there anyone from Saul's family who is still alive? I want to be kind to them because of God's faithful love for his people. ’Ziba replied, ‘One of Jonathan's sons still lives. But both his feet are weak so that he cannot walk properly. ’ Ziba replied, ‘One of Jonathan's sons still lives. But both his feet are weak so that he cannot walk properly. ’"
    },
    {
      "verse": "4",
      "text": "The king asked Ziba, ‘Where is he? ’Ziba answered, ‘He lives in the house of Ammiel's son, Makir, in Lo-Debar. ’ Ziba answered, ‘He lives in the house of Ammiel's son, Makir, in Lo-Debar. ’"
    },
    {
      "verse": "5",
      "text": "So David sent his men to bring him from the house of Ammiel's son, Makir, in Lo-Debar."
    },
    {
      "verse": "6",
      "text": "Then Jonathan's son Mephibosheth, grandson of Saul, came to David. He bent his body down to the ground to respect David. David said, ‘Mephibosheth! ’Mephibosheth replied, ‘Yes, I am your servant. ’ David said, ‘Mephibosheth! ’ Mephibosheth replied, ‘Yes, I am your servant. ’"
    },
    {
      "verse": "7",
      "text": "David said to him, ‘Do not be afraid. I will be kind to you because your father Jonathan was my friend. I will give back to you all the land which belonged to your grandfather, Saul. You will always be able to eat here with me. ’"
    },
    {
      "verse": "8",
      "text": "Mephibosheth bent his body low. He said, ‘I am your servant, no better than a dead dog. I do not deserve that you should be so kind to me. ’"
    },
    {
      "verse": "9",
      "text": "Then David sent his men to fetch Saul's servant, Ziba. David said to him, ‘I have given everything that belonged to Saul or his family to your master's grandson, Mephibosheth."
    },
    {
      "verse": "10",
      "text": "You, your sons and your servants must work on the land for him. You must grow crops that will be food for your master's grandson to eat. But Mephibosheth will always be able to eat with me. ’ Ziba himself had 15 sons and 20 servants."
    },
    {
      "verse": "11",
      "text": "Ziba said to the king, ‘I am your servant. I will do everything that my lord the king has told me to do. ’ So after that, Mephibosheth ate meals at the king's table. He was like one of the king's own sons."
    },
    {
      "verse": "12",
      "text": "Mephibosheth had a young son called Mica. Ziba and all his family and servants became servants to Mephibosheth."
    },
    {
      "verse": "13",
      "text": "That is how Mephibosheth came to live in Jerusalem. He could always eat his meals at the king's table. He had two weak feet, so he could not walk properly."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "Some time later, the king of the Ammonites died. His son Hanun became the new king. So David sent some of his officers to give a message to Hanun. David wanted to tell Hanun that he was sorry that Nahash had died. David's officers took his message to the land of the Ammonites."
    },
    {
      "verse": "2",
      "text": "David thought, ‘I will be kind to Hanun, because his father Nahash was kind to me. ’So David sent some of his officers to give a message to Hanun. David wanted to tell Hanun that he was sorry that Nahash had died. David's officers took his message to the land of the Ammonites."
    },
    {
      "verse": "3",
      "text": "The leaders of the Ammonites said to Hanun, the king, ‘David has sent his officers to you with a kind message about your father's death. But do not think that he really wants to give honour to your father. No, he has sent his officers to look at our city. They want to see how David's army can attack the city and take it for themselves. ’"
    },
    {
      "verse": "4",
      "text": "So Hanun took hold of David's officers. He cut off half the hair from their beards. He also cut off the lower half of their clothes up to their hips. Then he sent them away."
    },
    {
      "verse": "5",
      "text": "Some people told David what had happened. His officers were very ashamed, so David sent a message to them. King David said, ‘Stay in Jericho city until your beards have grown again. Then you can return here. ’"
    },
    {
      "verse": "6",
      "text": "The Ammonites realized that they had made David very angry. So they paid 20, 000 Syrian soldiers from Beth Rehob and Zobah to come and fight for them. They also brought 1, 000 soldiers from the king of Maakah and 12, 000 soldiers from Tob."
    },
    {
      "verse": "7",
      "text": "David heard news about this. So he sent Joab with all the soldiers in his army to fight against them."
    },
    {
      "verse": "8",
      "text": "The Ammonite soldiers marched out from their city. They stood in front of the city's gates and they were ready to fight. The Syrian soldiers from Zobah and Rehob and the soldiers from Tob and Maakah stayed in the fields near the city."
    },
    {
      "verse": "9",
      "text": "Joab saw that there were two groups of the enemy's soldiers. They were ready to attack his army from different sides. So he chose some of Israel's best soldiers. Joab himself led them to attack the Syrian soldiers in the fields."
    },
    {
      "verse": "10",
      "text": "He told his brother Abishai to lead the rest of Israel's army to fight against the Ammonites."
    },
    {
      "verse": "11",
      "text": "Joab said to Abishai, ‘If the Syrian soldiers are too strong for me, you must come to rescue me. But if the Ammonites are too strong for you, I will come to rescue you."
    },
    {
      "verse": "12",
      "text": "Be strong! We must be brave as we fight on behalf of our people and the cities of our God. The Lord will do what he decides is good. ’"
    },
    {
      "verse": "13",
      "text": "Then Joab and his group of soldiers went to fight against the Syrians. As they marched towards the Syrian soldiers, they ran away."
    },
    {
      "verse": "14",
      "text": "The Ammonites saw that the Syrians were running away from Joab. So they also ran away from his brother Abishai's men. They ran back into their city. So Joab stopped fighting the Ammonites. He returned to Jerusalem with his army."
    },
    {
      "verse": "15",
      "text": "The Syrian soldiers realized that Israel had won the battle against them. So they brought all their soldiers together."
    },
    {
      "verse": "16",
      "text": "King Hadadezer sent a message to fetch more Syrian soldiers from the other side of the Euphrates river. Shobach, the captain of his army, brought them all to Helam."
    },
    {
      "verse": "17",
      "text": "David heard about what was happening. So he took all Israel's soldiers across the Jordan River to Helam. The Syrian soldiers stood in their places ready to fight. When the battle started,"
    },
    {
      "verse": "18",
      "text": "the Syrians ran away from the Israelites. David and his army killed 700 Syrians who drove chariots. They killed 40, 000 other Syrian soldiers. David also knocked down Shobach, the captain of the Syrian army. Shobach died there."
    },
    {
      "verse": "19",
      "text": "All the other kings who were under Hadadezer's authority saw that Israel had won the battle. So they made an agreement with Israel that they would not fight against them any more. They agreed to serve the Israelites. After that, the Syrians were afraid to help the Ammonites any more."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "In the spring, David sent out his army to attack the Ammonites. That was the time of year when kings go out to fight battles. Joab led the whole Israelite army, together with his officers. They attacked the Ammonites, and they won the fight against them. Israel's army made their camp all around Rabbah city. But David had stayed in Jerusalem."
    },
    {
      "verse": "2",
      "text": "One evening, David got up from his bed. He walked around on the roof of his palace. From the roof he saw a woman who was washing herself. She was very beautiful."
    },
    {
      "verse": "3",
      "text": "David sent a servant to ask who she was. The servant told him, ‘She is Eliam's daughter, Bathsheba. She is the wife of Uriah the Hittite. ’"
    },
    {
      "verse": "4",
      "text": "Then David sent some servants to bring Bathsheba to him. She came to him and he slept with her. (She had just made herself clean from her monthly blood loss. ) Then she returned to her home."
    },
    {
      "verse": "5",
      "text": "Later, Bathsheba realized that she was pregnant. She sent a message to tell David about it."
    },
    {
      "verse": "6",
      "text": "So David sent a message to Joab. He said, ‘Send Uriah the Hittite to me. ’ So Joab sent Uriah to David."
    },
    {
      "verse": "7",
      "text": "When Uriah arrived, David asked him about Joab and the Israelite army. He asked Uriah about the war."
    },
    {
      "verse": "8",
      "text": "Then David said to Uriah, ‘Now go to your house and rest for a time. ’ So Uriah left the palace. Then King David sent a gift to him at home."
    },
    {
      "verse": "9",
      "text": "But Uriah slept at the door of the palace, together with his master's servants. He did not go to his house."
    },
    {
      "verse": "10",
      "text": "David's servants told him, ‘Uriah did not go to his house last night. ’ So David said to Uriah, ‘You have just arrived after a long journey. Why did you not go to your house? ’"
    },
    {
      "verse": "11",
      "text": "Uriah said to David, ‘The armies of Israel and Judah are all living in tents, as well as the Covenant Box. My master Joab and the soldiers of your army are sleeping in the fields. So I cannot go to my house and eat a meal there. It would not be right for me to go home and sleep with my wife. As surely as you live, I promise that I would never do that! ’"
    },
    {
      "verse": "12",
      "text": "David said to Uriah, ‘Stay here one more day. Tomorrow I will send you back to the war. ’ So Uriah stayed in Jerusalem that day and the next day."
    },
    {
      "verse": "13",
      "text": "David asked him to come and eat a meal with him. David caused Uriah to drink a lot of wine so that he became drunk. But in the evening Uriah still did not go to his own house. He slept on his mat, where his master's servants all slept."
    },
    {
      "verse": "14",
      "text": "In the morning, David wrote a letter to Joab. Uriah took the letter to Joab."
    },
    {
      "verse": "15",
      "text": "In the letter, David told Joab, ‘Put Uriah at the front of all our soldiers, where the battle is most dangerous. Then tell the other soldiers to move back away from him. Then he will be alone and the enemy's soldiers will kill him. ’"
    },
    {
      "verse": "16",
      "text": "Joab's soldiers were all around Rabbah city and they were watching it carefully. Joab sent Uriah to fight near to the city, where the enemy's best soldiers were."
    },
    {
      "verse": "17",
      "text": "When some of the Ammonite soldiers came out of the city to fight Joab's army, they killed some of David's men. Uriah the Hittite was one of the men who died there."
    },
    {
      "verse": "18",
      "text": "Joab wrote a report to tell David about the battle."
    },
    {
      "verse": "19",
      "text": "He told the man who was taking the message, ‘When you finish giving my report to the king,"
    },
    {
      "verse": "20",
      "text": "the king may be angry. He may ask you, “Why did you go and fight so near to the city? Surely you knew that they would shoot arrows from the walls."
    },
    {
      "verse": "21",
      "text": "Remember how a woman killed Jerub-Besheth's son, Abimelech. She threw a heavy stone down on him from the city wall in Thebez. You should not have gone so near to Rabbah's city wall. ” If King David does say that, tell him, “Your servant, Uriah the Hittite is dead too. ” ’"
    },
    {
      "verse": "22",
      "text": "The man that Joab sent to David with his message arrived. He told David all the news that Joab had sent with him."
    },
    {
      "verse": "23",
      "text": "The man said to David, ‘The enemy's men were stronger than us and they attacked us in the fields. But we chased them back as far as the gate of their city."
    },
    {
      "verse": "24",
      "text": "Then enemy soldiers shot arrows from the city wall and some of your men died. Your servant, Uriah the Hittite, is also dead. ’"
    },
    {
      "verse": "25",
      "text": "David said to the man that Joab had sent, ‘Tell Joab, “Do not be too upset. The enemy will always kill some of our men, and it could be anyone. Continue to attack the city even more strongly and then you will take it for us. ” If you say that to Joab, he will not be so sad. ’"
    },
    {
      "verse": "26",
      "text": "Uriah's wife heard the news that her husband was dead. She was very sad and she wept because of his death."
    },
    {
      "verse": "27",
      "text": "The time for Uriah's wife to weep for her husband came to an end. Then David sent some of his men to bring her to his palace. She became David's wife. Later, she gave birth to a son. But the Lord was not pleased with David because of the bad things that David had done."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "The Lord sent Nathan to go and speak to David. Nathan told this story to David, ‘There were two men who lived in the same town. One man was rich and the other man was poor."
    },
    {
      "verse": "2",
      "text": "The rich man had very many sheep, goats and cows."
    },
    {
      "verse": "3",
      "text": "But the poor man had only one little female lamb. He had bought it and he had taken care of it. It had grown up with his own children. It ate his bits of food and it drank water from his cup. It even slept while he held it. It was like a daughter for him."
    },
    {
      "verse": "4",
      "text": "One day, the rich man had a visitor to his home. The rich man needed to make a meal for his visitor. But he did not want to kill one of his own animals. Instead, he took the poor man's lamb away from him. He cooked the lamb to feed his visitor. ’"
    },
    {
      "verse": "5",
      "text": "When David heard what the rich man had done, he became very angry. He said to Nathan, ‘As surely as the Lord lives, that man deserves to die."
    },
    {
      "verse": "6",
      "text": "He did that cruel thing and he was not sorry for the poor man. So he must pay the poor man enough money to buy four lambs. ’"
    },
    {
      "verse": "7",
      "text": "Then Nathan said to David, ‘You are that man! This is what the Lord, Israel's God, says: “I chose you as king to rule over Israel. I saved you from Saul's power."
    },
    {
      "verse": "8",
      "text": "I gave your master's palace to you, and his wives as well. I gave the kingdoms of Israel and Judah to you. And if that was not enough for you, I would have given you even more than that."
    },
    {
      "verse": "9",
      "text": "But now you have not respected the Lord's command. You have done an evil thing. You caused Uriah the Hittite to die in a battle. You used the Ammonite soldiers to kill Uriah."
    },
    {
      "verse": "10",
      "text": "So now your family will always have people who die in battle. When you took the wife of Uriah the Hittite to be your own wife, you showed that you did not respect me. ”"
    },
    {
      "verse": "11",
      "text": "This is what the Lord says, “I will cause someone from your own family to bring trouble to you. You yourself will see it happen! I will take your wives from you and I will give them to someone else. He will have sex with them in the daytime, for everyone to see."
    },
    {
      "verse": "12",
      "text": "What you did, you did secretly. But I will cause this to happen in the light of day, so that all Israel can see it. ” ’"
    },
    {
      "verse": "13",
      "text": "Then David said to Nathan, ‘I have sinned against the Lord. ’Nathan replied, ‘The Lord has forgiven your sin. He will not punish you with death."
    },
    {
      "verse": "14",
      "text": "But you did not respect the Lord when you did this bad thing. Because of that, your baby son will certainly die. ’"
    },
    {
      "verse": "15",
      "text": "Then Nathan went home. After that, the Lord caused the child of Uriah's wife to become very ill."
    },
    {
      "verse": "16",
      "text": "David asked the Lord to make his child well again. He lay on the floor of his house all night and he ate no food."
    },
    {
      "verse": "17",
      "text": "His palace officers stood around him. They tried to help him to get up from the ground. But he refused and he would not eat anything with them."
    },
    {
      "verse": "18",
      "text": "On the seventh day, the child died. David's officers were afraid to tell him. They thought, ‘Even when the child was alive, David refused to listen to us. So what will happen if we tell him that the child is dead? He might try to hurt himself. ’"
    },
    {
      "verse": "19",
      "text": "But David saw that his officers were speaking secretly to each other. So he realized that the child had died. He asked them, ‘Is the child dead? ’They replied, ‘Yes, he is dead. ’ They replied, ‘Yes, he is dead. ’"
    },
    {
      "verse": "20",
      "text": "Then David got up from the ground and he washed himself. He put special oil on his body and he dressed himself in clean clothes. Then he went into the Lord's house to worship him. After that, he went back to his palace. He asked his servants to bring some food and he ate it."
    },
    {
      "verse": "21",
      "text": "His officers said to him, ‘We do not understand what you are doing. While the child was still alive, you refused to eat food and you wept. But now that the child is dead you are no longer weeping. You are moving around and you are eating. Why? ’"
    },
    {
      "verse": "22",
      "text": "David replied, ‘While the child was still alive, I wept and I did not eat anything. I thought that perhaps the Lord would be kind to me. I thought that he might let the child live."
    },
    {
      "verse": "23",
      "text": "But now the child is dead. Even if I fast and I pray, I cannot bring him back to me. One day, I will go to the place where he is. But he will never come back here to me. ’"
    },
    {
      "verse": "24",
      "text": "Then David went to comfort his wife, Bathsheba. He had sex with her as his wife. Later, she gave birth to a son. David gave him the name ‘Solomon’. The Lord loved the child,"
    },
    {
      "verse": "25",
      "text": "so he sent a message to David with Nathan, the prophet. He told David to call his son Jedidiah, because the Lord loved him."
    },
    {
      "verse": "26",
      "text": "At this time, Joab was attacking Rabbah, the Ammonite city. He had taken from the enemy the king's strong place in the city."
    },
    {
      "verse": "27",
      "text": "Joab sent men to take this message to David: ‘I have attacked Rabbah. Now I have taken the place that holds the city's water."
    },
    {
      "verse": "28",
      "text": "So you should bring the other soldiers of our army to make their camp here. Then you can attack the city and you can take it for us. If you do not do that, I will take the city myself. Then the city will have my name instead of yours. ’"
    },
    {
      "verse": "29",
      "text": "So David brought all the soldiers of the army together. He led them to Rabbah. They attacked the city and they won against it. Then David and all his army returned to Jerusalem."
    },
    {
      "verse": "30",
      "text": "He took the crown off the Ammonite king's head. The crown was made of gold. It weighed 34 kilograms. There was a valuable jewel fixed on it. David's men then put the crown on David's head. David also took a lot of valuable things from the city."
    },
    {
      "verse": "31",
      "text": "He brought the people out from the city to do hard work for him. He made them cut wood with saws, and use iron tools and axes. He also made them work at the brick ovens. He did the same thing to the people of all the other Ammonite cities. Then David and all his army returned to Jerusalem."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "David's son Absalom had a beautiful sister. Her name was Tamar. After some time, David's son Amnon began to love Tamar very much."
    },
    {
      "verse": "2",
      "text": "Amnon was very upset because he loved his sister Tamar so much. He became ill because of this. Tamar had never had sex with any man, so Amnon knew that it would be difficult to get near her."
    },
    {
      "verse": "3",
      "text": "Amnon had a friend called Jonadab. He was the son of David's brother, Shimeah. Jonadab was a clever man. Amnon said to him, ‘I love Tamar, my brother Absalom's sister. ’"
    },
    {
      "verse": "4",
      "text": "He said to Amnon, ‘You are the king's son! So why do you seem so sad every morning? Tell me about your trouble. ’Amnon said to him, ‘I love Tamar, my brother Absalom's sister. ’"
    },
    {
      "verse": "5",
      "text": "Jonadab told him, ‘Go and lie down on your bed. Pretend that you are ill. Your father will come to see you. Then you can say to him, “Please send my sister Tamar in here to give me something to eat. I will watch her as she prepares the food. Then she can use her own hand to feed me. ” ’"
    },
    {
      "verse": "6",
      "text": "So Amnon lay down on his bed. He pretended that he was ill. When the king came in to see him, Amnon said to him, ‘Please let my sister Tamar come in here. I want her to cook some little cakes while I watch her. Then she can feed me herself. ’"
    },
    {
      "verse": "7",
      "text": "David sent a message to Tamar in the palace. He told her, ‘Go to your brother Amnon's house. Prepare some food for him to eat there. ’"
    },
    {
      "verse": "8",
      "text": "So Tamar went to Amnon's house. He was lying down on his bed. She took some flour and water and she mixed them together. She made the cakes while he watched her. Then she baked them."
    },
    {
      "verse": "9",
      "text": "Then she put the cakes on a plate and she put them in front of him. But he refused to eat them. Instead, Amnon said, ‘Everyone must go out and leave me alone here. ’ So everyone left him alone with Tamar."
    },
    {
      "verse": "10",
      "text": "Then Amnon said to Tamar, ‘Bring the food here into my bedroom. Then you can use your own hand to feed me. ’So Tamar took the cakes that she had made. She brought them to Amnon in his bedroom."
    },
    {
      "verse": "11",
      "text": "But when she offered the cakes to him, he took hold of her. He said to her, ‘Come here, my sister! Come into bed with me. ’"
    },
    {
      "verse": "12",
      "text": "Tamar answered him, ‘Do not do this, my brother! Do not make me ashamed. Nobody in Israel would do such a wicked thing. Do not be so foolish!"
    },
    {
      "verse": "13",
      "text": "Think about me. I would have to hide because of my shame. And people would say that you are the worst fool in Israel. No, you should speak to the king. I am sure that he will let you marry me. ’"
    },
    {
      "verse": "14",
      "text": "But Amnon refused to listen to her. He was stronger than she was. So he took hold of her and he had sex with her."
    },
    {
      "verse": "15",
      "text": "After that, Amnon hated Tamar very much. He now hated her more strongly than he had loved her. He said to her, ‘Go away from here! ’"
    },
    {
      "verse": "16",
      "text": "But Tamar replied, ‘No, I will not go! If you send me away, that would be even worse. It would be more evil that what you have already done to me. ’But Amnon refused to listen to her."
    },
    {
      "verse": "17",
      "text": "He called out to his own special servant. He told him, ‘Throw this woman out of my house! Then lock the door after she has gone. ’"
    },
    {
      "verse": "18",
      "text": "So the servant took her out and then he locked the door. Tamar was wearing a beautiful long dress. All the king's daughters who were not yet married wore beautiful dresses like that."
    },
    {
      "verse": "19",
      "text": "Now Tamar put ashes on her head. She tore the beautiful dress that she was wearing. She covered her head with her hands. She wept loudly as she went home."
    },
    {
      "verse": "20",
      "text": "When her brother Absalom saw her, he said, ‘Has your brother Amnon done this to you? Now be quiet. Remember that he is your brother. So do not be too upset. ’After that, Tamar lived in her brother Absalom's house. She was sad and lonely. After that, Tamar lived in her brother Absalom's house. She was sad and lonely."
    },
    {
      "verse": "21",
      "text": "When King David heard about what had happened, he was very angry."
    },
    {
      "verse": "22",
      "text": "But Absalom would not say anything to Amnon, good or bad. He hated Amnon because he had brought shame on his sister, Tamar."
    },
    {
      "verse": "23",
      "text": "Two years later, Absalom's men were cutting the wool from his sheep. They were in Baal Hazor, near to Ephraim's land. Absalom asked all the king's sons to meet him there."
    },
    {
      "verse": "24",
      "text": "Then he went to the king and he said, ‘My men have started to cut the wool from my sheep. Please will your and your officers come and join us at this happy time? ’"
    },
    {
      "verse": "25",
      "text": "King David replied to Absalom, ‘No, my son, we should not all go. It would cause you too much trouble. ’Absalom asked him again, but the king still refused to go. Instead, he asked God to bless Absalom. Absalom asked him again, but the king still refused to go. Instead, he asked God to bless Absalom."
    },
    {
      "verse": "26",
      "text": "So Absalom said, ‘If you will not come with me, please let my brother Amnon come. ’The king said, ‘Why do you want him to go with you? ’"
    },
    {
      "verse": "27",
      "text": "But Absalom asked the king more strongly. So the king agreed to send Amnon and all his other sons."
    },
    {
      "verse": "28",
      "text": "Absalom then told his servants, ‘When Amnon has drunk a lot of wine I will tell you, “Knock him down! ” Then you must kill him immediately. Do not be afraid. I am the one who is commanding you to do this. So be strong and brave. ’"
    },
    {
      "verse": "29",
      "text": "So Absalom's men killed Amnon, as Absalom had told them to do. Then all the king's other sons got on their mules. They quickly rode away."
    },
    {
      "verse": "30",
      "text": "While they were still on the way home, David heard news about what had happened. Someone told him, ‘Absalom has attacked all the king's sons. Not one son is still alive. ’"
    },
    {
      "verse": "31",
      "text": "The king was very upset. He stood up and he tore his clothes. Then he lay down on the ground. All his servants were standing around him. They had torn their clothes, too."
    },
    {
      "verse": "32",
      "text": "But Jonadab, the son of David's brother Shimeah, said, ‘My lord, do not think that they have killed all your sons. Only Amnon is dead. Absalom has decided to do this since Amnon brought shame on his sister Tamar."
    },
    {
      "verse": "33",
      "text": "My lord the king, you should not believe the report that all your sons are dead. Only Amnon is dead. ’"
    },
    {
      "verse": "34",
      "text": "While this was happening, Absalom had run away. There was an officer standing on the wall of Jerusalem to watch. When he looked, he saw a big group of people who were coming from the west. They were coming down the hill on the road from Horonaim. He went to the king and he told him the news. There was an officer standing on the wall of Jerusalem to watch. When he looked, he saw a big group of people who were coming from the west. They were coming down the hill on the road from Horonaim. He went to the king and he told him the news."
    },
    {
      "verse": "35",
      "text": "Jonadab said to the king, ‘See, the king's sons are coming now, as I said they would. ’"
    },
    {
      "verse": "36",
      "text": "As he said that, the king's sons arrived. They were weeping loudly. The king and all his servants were also weeping. King David continued to weep for his son Amnon every day."
    },
    {
      "verse": "37",
      "text": "Absalom ran away to Ammihud's son, Talmai, the king of Geshur."
    },
    {
      "verse": "38",
      "text": "He stayed in Geshur for three years."
    },
    {
      "verse": "39",
      "text": "By this time, King David had stopped being so upset about Amnon's death. He wanted very much to see Absalom again."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "Zeruiah's son, Joab, knew how much the king wanted to see Absalom."
    },
    {
      "verse": "2",
      "text": "So he sent a message to Tekoa to bring a wise woman from there. He said to her, ‘Pretend that you are upset because of someone's death. Dress in funeral clothes. Do not use any perfume on your body. You must seem like a woman who has been sad for a long time."
    },
    {
      "verse": "3",
      "text": "Then go to the king to speak to him. ’ Then Joab told her the words that she should speak to the king."
    },
    {
      "verse": "4",
      "text": "So the woman from Tekoa went to the king. She bent her body down low with her face towards the ground. She gave honour to the king. Then she said, ‘Please help me, sir! ’"
    },
    {
      "verse": "5",
      "text": "The king asked her, ‘What is your trouble? ’She said, ‘My husband is dead, sir, and I am a widow."
    },
    {
      "verse": "6",
      "text": "I had two sons. One day, they were fighting in the fields. There was nobody near to stop them. One son knocked down the other son and killed him."
    },
    {
      "verse": "7",
      "text": "Now all my relatives have turned against me. They want to take my son from me, because he killed his brother. They say that he must die. That is the punishment that he deserves. But if they do that, I will have no son. My husband will have no descendants, so the name of our family will not continue. ’"
    },
    {
      "verse": "8",
      "text": "The king said to the woman, ‘Go to your home. I will make sure that your son is safe. ’"
    },
    {
      "verse": "9",
      "text": "Then the woman said to the king, ‘My lord the king, I pray that nobody will think that you have done anything wrong. They should call me guilty, but not you or your family. ’"
    },
    {
      "verse": "10",
      "text": "The king replied, ‘If anyone says anything against you, bring him to me. After that, he will not cause you any more trouble. ’"
    },
    {
      "verse": "11",
      "text": "Then the woman said, ‘Sir, please stop my relative from punishing my son with death. I do not want this son to die as well as my other son. Please promise me in the name of the Lord your God that it will not happen. ’The king replied, ‘As surely as the Lord lives, I promise that nobody will touch even one hair of your son's head. ’ The king replied, ‘As surely as the Lord lives, I promise that nobody will touch even one hair of your son's head. ’"
    },
    {
      "verse": "12",
      "text": "Then the woman said, ‘Please sir, there is one other thing that I want to tell you. ’King David said, ‘Tell me. ’ King David said, ‘Tell me. ’"
    },
    {
      "verse": "13",
      "text": "The woman said, ‘I think that you have done a wrong thing like this against God's own people. You have not let your own son return to his home. He still lives in a foreign city. Because of what you have said to me, you show that you yourself are guilty."
    },
    {
      "verse": "14",
      "text": "We must all die one day. When that happens, we are like water that is poured on the ground. We cannot pick it up again. But God does not remove our lives from us. Instead, he finds a way to bring us back to him when we have gone far away."
    },
    {
      "verse": "15",
      "text": "My lord the king, I have told you this because the people have made me afraid. I thought to myself, “I will speak to the king. I do not deserve it, but perhaps he will do what I ask him to do."
    },
    {
      "verse": "16",
      "text": "Perhaps he will listen to me. Perhaps he will save me from the man who wants to destroy both me and my son. That man wants to take away from us the land that God gave to us. ”"
    },
    {
      "verse": "17",
      "text": "Now I can say, “I know that the promise of my lord the king will keep me safe. The king can judge things like an angel of God. He knows what is right and what is wrong. ” I pray that the Lord your God will be with you! ’"
    },
    {
      "verse": "18",
      "text": "Then the king said to the woman, ‘Now I want to ask you a question. You must not hide the truth from me. ’She replied, ‘Ask me anything, sir. ’ She replied, ‘Ask me anything, sir. ’"
    },
    {
      "verse": "19",
      "text": "The king asked her, ‘Is it Joab who has told you to do this? ’The woman answered, ‘My lord the king, as surely as you live, I cannot hide the truth from you. Yes, it was your servant Joab who told me what to do. He gave me the words to say."
    },
    {
      "verse": "20",
      "text": "He did it because he wanted things to be different. But you, my lord, are as wise as one of God's angels. You know everything that happens in our land. ’"
    },
    {
      "verse": "21",
      "text": "Then the king spoke to Joab. He said, ‘I have decided to do what you want. Go and bring back the young man Absalom. ’"
    },
    {
      "verse": "22",
      "text": "Joab bent his body down low with his face towards the ground. He thanked the king. He said, ‘Now I know that you are pleased with me. You have agreed to do what I have asked you to do. ’"
    },
    {
      "verse": "23",
      "text": "Then Joab went to Geshur. He brought Absalom back to Jerusalem. So Absalom did not go to see the king. Instead, he went to live in his own house."
    },
    {
      "verse": "24",
      "text": "But the king said, ‘Absalom must go to live in his own house. I do not want him to come to see me. ’So Absalom did not go to see the king. Instead, he went to live in his own house."
    },
    {
      "verse": "25",
      "text": "Everyone in Israel praised Absalom. They all thought that he was the most handsome man in the whole country. His body was perfect, from head to toe."
    },
    {
      "verse": "26",
      "text": "Once every year he cut his hair because it became too heavy. Each time, the hair that he cut off weighed about 2 kilograms."
    },
    {
      "verse": "27",
      "text": "Absalom had three sons and one daughter. Her name was Tamar. She was a very beautiful woman."
    },
    {
      "verse": "28",
      "text": "Absalom lived in Jerusalem for two years, but he never saw the king."
    },
    {
      "verse": "29",
      "text": "Then Absalom sent a message to Joab. He asked Joab to come to him. He wanted Joab to go to the king on his behalf. But Joab refused to come to Absalom. So then Absalom sent another message, but Joab still refused to come."
    },
    {
      "verse": "30",
      "text": "Then Absalom said to his servants, ‘Joab has a field that is next to mine. Some barley is growing in it. Go and light a fire there, so that it all burns. ’ So Absalom's servants went to Joab's field and they did that."
    },
    {
      "verse": "31",
      "text": "Then Joab did go to Absalom's house. He asked Absalom, ‘Why did your servants take fire and burn my field? ’"
    },
    {
      "verse": "32",
      "text": "Absalom replied, ‘You did not come when I sent messages to you. I wanted you to take a message to the king on my behalf. I wanted to ask the king, “Why have you brought me from Geshur to Jerusalem? It would have been better for me to stay there! ” Now I want to go to see the king myself. If he thinks that I am guilty, then he can punish me with death. ’"
    },
    {
      "verse": "33",
      "text": "So Joab went to the king. He told the king what Absalom had said. King David then sent his men to bring Absalom to him. When Absalom arrived, he bent his body down low in front of the king, with his face towards the ground. The king was happy and he kissed Absalom."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "Some time later, Absalom bought a chariot and some horses. He had 50 men who ran in front of the chariot to give him honour."
    },
    {
      "verse": "2",
      "text": "Every day, he got up early in the morning. Then he went to stand at the side of the road near the city's gate. He called out to anyone who was bringing a problem for the king to judge. He would ask them, ‘Which town have you come from? ’ Then the man would tell Absalom which tribe of Israel he belonged to."
    },
    {
      "verse": "3",
      "text": "Then Absalom would say, ‘I am sure that you are right. You deserve to receive justice. But the king has not given any of his officers authority to listen to you. ’"
    },
    {
      "verse": "4",
      "text": "Absalom would also say, ‘I think that I should have authority to be a judge in Israel. Then when people have a problem to take to court, they could come to me. I would make sure that they receive justice. ’"
    },
    {
      "verse": "5",
      "text": "When anyone bent his body down low to give honour to Absalom, Absalom would reach out and pull the man towards him. He would kiss the man."
    },
    {
      "verse": "6",
      "text": "Absalom did this to all the Israelites who came to Jerusalem to ask the king for justice. In that way, Absalom turned the people of Israel so that they became faithful to him."
    },
    {
      "verse": "7",
      "text": "After four years, Absalom said to the king, ‘Please let me go to Hebron. I need to make a sacrifice to the Lord, as I promised to do."
    },
    {
      "verse": "8",
      "text": "When I was living at Geshur with the Arameans, I made this promise: “If the Lord brings me back to live in Jerusalem, I will go to Hebron and I will worship him there. ” ’"
    },
    {
      "verse": "9",
      "text": "The king said, ‘Yes, you may go. ’ So Absalom left Jerusalem and he went to Hebron."
    },
    {
      "verse": "10",
      "text": "Then Absalom sent his men to go secretly to all the tribes of Israel. They took this message to the people: ‘When you hear the noise of trumpets, then you must shout, “Absalom has become king in Hebron. ” ’"
    },
    {
      "verse": "11",
      "text": "men had gone with Absalom from Jerusalem. He had asked them to go with him as his friends. They trusted him and they did not know about his ideas."
    },
    {
      "verse": "12",
      "text": "Absalom offered his sacrifices as he had promised to do. But at the same time he sent men to fetch Ahithophel from Giloh, where he lived. Ahithophel was King David's advisor. More and more people agreed to join Absalom and turn against David. So Absalom was becoming more powerful."
    },
    {
      "verse": "13",
      "text": "Somebody brought this message to David: ‘The Israelites are now faithful to Absalom instead of you. ’"
    },
    {
      "verse": "14",
      "text": "So David said to the officers who were with him in Jerusalem, ‘We must go! We must run away! If we do not do that, no one will escape from Absalom. Hurry, or he will quickly catch us here. Then he will destroy us and our whole city! ’"
    },
    {
      "verse": "15",
      "text": "The king's officers answered, ‘Our lord the king, we will do anything that you decide is right. ’"
    },
    {
      "verse": "16",
      "text": "So the king left home. He took all his servants and family with him. But he left ten of his slave wives to take care of the palace."
    },
    {
      "verse": "17",
      "text": "As King David and all his people were leaving, they stopped at the last house on the edge of Jerusalem."
    },
    {
      "verse": "18",
      "text": "All his officers and his personal guards, the Kerethites and Pelethites, went on past him. There were also 600 men who had come with him from Gath. All these people were leaving Jerusalem with the king."
    },
    {
      "verse": "19",
      "text": "Then the king asked Ittai, who came from Gath, ‘Why are you coming with us? Go back into the city and join with Absalom, the new king. You have come from another country and you live here as a foreigner."
    },
    {
      "verse": "20",
      "text": "It seems like only a few days since you arrived here. There is no reason for you to travel with us. I do not even know where we are going! So you should go back. Take your men with you. I pray that the Lord will keep you safe with his faithful love. ’"
    },
    {
      "verse": "21",
      "text": "But Ittai replied to the king, ‘As surely as the Lord lives and as surely as you live, I promise that I will go with you, sir. Wherever you go, I will be there with you. My lord the king, I will stay with you, even if it brings death. ’"
    },
    {
      "verse": "22",
      "text": "So David said to Ittai, ‘Go on ahead of me. ’ So Ittai, with all his men and their families, went on ahead of David."
    },
    {
      "verse": "23",
      "text": "As David and his men left the city, all the people who saw them wept loudly. The king went across the Kidron Valley and his men followed him. They travelled along the road towards the desert."
    },
    {
      "verse": "24",
      "text": "Zadok and Abiathar, the priests, were with them. The Levites were also there, and they were carrying God's Covenant Box. They put it down on the ground while all the people left the city. After all the people had passed, they picked it up again."
    },
    {
      "verse": "25",
      "text": "Then the king said to Zadok, ‘Take the Covenant Box back into the city. If the Lord is pleased with me, he will bring me back here again. The Lord will let me see the Covenant Box again, as well as his home."
    },
    {
      "verse": "26",
      "text": "But if he is not pleased with me, then he must do to me whatever he decides is right. ’"
    },
    {
      "verse": "27",
      "text": "Then the king said to Zadok the priest, ‘You do not know what will happen. So go safely back into the city, both you and Abiathar. Take your son Ahimaaz and Abiathar's son Jonathan with you."
    },
    {
      "verse": "28",
      "text": "I will wait at the place in the desert where we go across the river. I will wait there until I receive a message from you. ’"
    },
    {
      "verse": "29",
      "text": "So Zadok and Abiathar took the Covenant Box back into Jerusalem. They stayed there."
    },
    {
      "verse": "30",
      "text": "But David continued to go up the Mount of Olives. He was weeping as he went. He had covered his head and he was not wearing any shoes on his feet. All the people with him also covered their heads and they wept as they went up the hill."
    },
    {
      "verse": "31",
      "text": "Someone told David that his advisor, Ahithophel, had now joined with Absalom and his men. So David prayed, ‘Lord, please cause Ahithophel to give them foolish advice. ’"
    },
    {
      "verse": "32",
      "text": "David arrived at the top of the hill. It was a place where people worshipped God. Hushai, who was an Arkite, met him there. He had torn his clothes and he had dirt on his head."
    },
    {
      "verse": "33",
      "text": "David said, ‘If you come with me, you will be no help to me."
    },
    {
      "verse": "34",
      "text": "Instead, go back into the city. You should say to Absalom, “I accept you as king and I will be your servant. I was once your father's servant, but now I will be your servant. ” Then you will be able to speak against Ahithophel's advice."
    },
    {
      "verse": "35",
      "text": "The priests, Zadok and Abiathar, will be there with you. Tell them any news that you hear in the king's palace."
    },
    {
      "verse": "36",
      "text": "Their two sons, Ahimaaz and Jonathan, are with them. Send them to me to tell me any news that you hear. ’"
    },
    {
      "verse": "37",
      "text": "So David's friend Hushai arrived at Jerusalem at the same time that Absalom was coming into the city."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "When David had passed beyond the top of the Mount of Olives, he met Mephibosheth's servant Ziba. Ziba was waiting there for him with two donkeys. The donkeys were ready for people to ride them. They also carried 200 loaves of bread, 100 blocks of raisins, 100 blocks of figs and a leather bag of wine."
    },
    {
      "verse": "2",
      "text": "The king asked Ziba, ‘Why have you brought all these things? ’Ziba answered, ‘The donkeys are for the king's family to ride. The bread and the fruit are for the young men to eat. The wine will help people who become weak when you travel through the desert. ’ Ziba answered, ‘The donkeys are for the king's family to ride. The bread and the fruit are for the young men to eat. The wine will help people who become weak when you travel through the desert. ’"
    },
    {
      "verse": "3",
      "text": "The king asked, ‘Where is your master's grandson? ’Ziba answered, ‘He is staying in Jerusalem. He thinks that the Israelites will now give back to him his grandfather Saul's kingdom. ’ Ziba answered, ‘He is staying in Jerusalem. He thinks that the Israelites will now give back to him his grandfather Saul's kingdom. ’"
    },
    {
      "verse": "4",
      "text": "Then the king said to Ziba, ‘Everything that Mephibosheth had will now belong to you. ’Ziba said, ‘Thank you, sir. I hope that you will always be pleased with me. ’ Ziba said, ‘Thank you, sir. I hope that you will always be pleased with me. ’"
    },
    {
      "verse": "5",
      "text": "King David and his people arrived near Bahurim town. Gera's son Shimei came out to meet David. He was a relative of Saul. Shimei cursed David in a loud voice as he came towards him."
    },
    {
      "verse": "6",
      "text": "He threw stones at David and at the king's officers. There was a big group of people and brave soldiers all around David."
    },
    {
      "verse": "7",
      "text": "Shimei said, ‘Go away! Get out of here! You are a murderer, a wicked man!"
    },
    {
      "verse": "8",
      "text": "The Lord has punished you because of all the people that you killed from Saul's family. You made yourself king, instead of Saul. But now the Lord has given the kingdom to your son, Absalom. All this trouble has come to you because you are a murderer! ’"
    },
    {
      "verse": "9",
      "text": "Then Zeruiah's son, Abishai, said to the king, ‘This man is only a useless dog! He must not curse you, my lord the king. I should go and cut off his head! ’"
    },
    {
      "verse": "10",
      "text": "The king said, ‘No! You sons of Zeruiah should not tell me what to do! Perhaps he is cursing me because the Lord has said to him, “Curse David. ” Then we cannot say that he is wrong to curse me. ’"
    },
    {
      "verse": "11",
      "text": "Then David said to Abishai and to all his officers, ‘My own son is trying to kill me. Now this man from Benjamin's tribe wants to do the same thing. The Lord has told him to do this, so do not stop him cursing me."
    },
    {
      "verse": "12",
      "text": "Perhaps the Lord will understand my trouble. He may see how Shimei is cursing me and he may bless me instead. ’"
    },
    {
      "verse": "13",
      "text": "David and his men continued to walk along the road. Shimei walked along the side of the hill, near the road. As he went, he cursed David and he threw stones and dirt at David and his people."
    },
    {
      "verse": "14",
      "text": "When King David and all the people who were with him reached the Jordan River, they were tired and weak. So they rested there."
    },
    {
      "verse": "15",
      "text": "So Absalom and all the Israelites who were with him arrived in Jerusalem. Ahithophel came with him."
    },
    {
      "verse": "16",
      "text": "David's friend, Hushai the Arkite, had also come there. He went to Absalom and he said to him, ‘May the king live for ever! May the king live for ever! ’"
    },
    {
      "verse": "17",
      "text": "Absalom asked Hushai, ‘Why have you not been faithful to your friend David? Why did you not go with him? ’"
    },
    {
      "verse": "18",
      "text": "Hushai replied, ‘No, I will serve you. You are the king that the Lord has chosen. And all these people and the men of Israel have chosen you too. So I will stay with you."
    },
    {
      "verse": "19",
      "text": "I served your father when he was king. So now it is surely right for me to serve you, his son. ’"
    },
    {
      "verse": "20",
      "text": "Then Absalom said to Ahithophel, ‘What do you think that we should do now? What is your advice? ’"
    },
    {
      "verse": "21",
      "text": "Ahithophel answered, ‘Sleep with your father's slave wives that are here. He left them to take care of his palace. Then all the people in Israel will know that you have insulted your father. They will know that he must now hate you. That will help your own men to be strong. ’"
    },
    {
      "verse": "22",
      "text": "So they put up a tent for Absalom on the roof of the palace. There he had sex with his father's slave wives, and all the Israelites could see him."
    },
    {
      "verse": "23",
      "text": "In those days, people thought that Ahithophel's words were as good as a message from God. So Absalom trusted Ahithophel as his advisor, as David had done too."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "Ahithophel said to Absalom, ‘Please let me choose 12, 000 men so that I can go and attack David tonight."
    },
    {
      "verse": "2",
      "text": "Now he will be very tired and weak. So when we attack him, he will be frightened. All his soldiers will run away. But I will kill only the king."
    },
    {
      "verse": "3",
      "text": "Then I will bring all his army back to you. If we kill this one man that you want to destroy, then all the people will return safely. ’"
    },
    {
      "verse": "4",
      "text": "This seemed a good idea to Absalom and to all the leaders of Israel."
    },
    {
      "verse": "5",
      "text": "But Absalom said, ‘Send Hushai the Arkite to me. We should hear what advice he gives us. ’"
    },
    {
      "verse": "6",
      "text": "When Hushai arrived, Absalom said to him, ‘This is Ahithophel's advice. What do you think we should do? If you think differently, what advice do you give us? ’"
    },
    {
      "verse": "7",
      "text": "Hushai replied to Absalom, ‘This time Ahithophel's idea is not good."
    },
    {
      "verse": "8",
      "text": "You know your father and his men. They are all strong fighters. They are as dangerous as a mother bear when you take away her babies. Remember that your father has fought many battles. He will not stay all night among his soldiers."
    },
    {
      "verse": "9",
      "text": "By this time he is hiding in a cave or in some other safe place. He might attack your soldiers first and kill some of them. When somebody hears the news, he will say, “They have destroyed Absalom's army! ”"
    },
    {
      "verse": "10",
      "text": "Then your bravest soldiers will be very frightened, even if they are as brave as lions. Everyone in Israel knows that your father is a fighter. And they know that the men with him are brave."
    },
    {
      "verse": "11",
      "text": "This is my advice to you. Bring together all the soldiers in Israel. Tell them to come from everywhere in the land, from Dan to Beersheba. There will be as many of them as the sand on the shore of the sea. Then you yourself should lead the whole army into the battle."
    },
    {
      "verse": "12",
      "text": "In this way we can attack David in any place that we find him. We will suddenly be all around him, like dew that covers the ground. He and his men will all die. Not even one of them will still be alive."
    },
    {
      "verse": "13",
      "text": "If he escapes into a city, we can completely destroy the city. Our soldiers will use ropes to pull it all down into the valley! ’"
    },
    {
      "verse": "14",
      "text": "Absalom and all Israel's leaders said, ‘Hushai's idea is better than Ahithophel's idea. ’ This happened because the Lord did not let the people accept Ahithophel's advice. His idea was a good one, but the Lord had decided to cause trouble for Absalom."
    },
    {
      "verse": "15",
      "text": "Then Hushai went to the priests Zadok and Abiathar. He said to them, ‘This was Ahithophel's advice to Absalom and Israel's leaders. But this was my advice."
    },
    {
      "verse": "16",
      "text": "So now quickly send a report to David. Warn him that he must not stay tonight at the place in the desert where the road crosses the river. Instead, he must cross the Jordan River immediately, together with all the people who are with him. If not, Absalom and his army may catch them all and destroy them. ’"
    },
    {
      "verse": "17",
      "text": "Jonathan and Ahimaaz were staying at En Rogel. They did not go into the city because they did not want anyone to see them there. So a female servant would take messages to them. Then they would take the messages to King David."
    },
    {
      "verse": "18",
      "text": "But this time a young man did see them. He told Absalom where they were. So they quickly left En Rogel and they went to a man's house in Bahurim. He had a well in his yard and they climbed down into it."
    },
    {
      "verse": "19",
      "text": "His wife took a lid and she put it over the top of the well. Then she put some grain on it. Nobody knew that the men were hiding there."
    },
    {
      "verse": "20",
      "text": "Absalom's men came to the house. They asked the woman, ‘Where are Ahimaaz and Jonathan? ’The woman answered, ‘They went across the stream. ’ Absalom's men looked everywhere for them, but they did not find them. So they returned to Jerusalem. The woman answered, ‘They went across the stream. ’ Absalom's men looked everywhere for them, but they did not find them. So they returned to Jerusalem."
    },
    {
      "verse": "21",
      "text": "After the men had gone, Ahimaaz and Jonathan climbed out of the well. Then they took the message to David. They said to him, ‘You must go across the river immediately. Ahithophel has told Absalom how he can catch you here. ’"
    },
    {
      "verse": "22",
      "text": "So David and all the people who were with him went across the Jordan River. When dawn came, they had all gone across to the other side."
    },
    {
      "verse": "23",
      "text": "Ahithophel realized that Absalom had not agreed to his advice. So he got on his donkey and he went home to his own town. He told his family what he needed to tell them. Then he hanged himself. He died and his family buried him in his father's grave."
    },
    {
      "verse": "24",
      "text": "David arrived at Mahanaim with his men. Absalom and Israel's army went across the Jordan River."
    },
    {
      "verse": "25",
      "text": "Joab had been the leader of Israel's army. But now Absalom had chosen Amasa as leader instead of Joab. Amasa's father, Jether, was a descendant of Ishmael. He had married Abigail. She was Nahash's daughter and a sister of Zeruiah, Joab's mother."
    },
    {
      "verse": "26",
      "text": "Absalom and Israel's army made their camp in Gilead region."
    },
    {
      "verse": "27",
      "text": "When David arrived in Mahanaim, three men came to help him. One man was Nahash's son Shobi. He was from the Ammonites' town, Rabbah. The other men were Ammiel's son Makir, from Lo-Debar, and Barzillai from Rogelim in Gilead."
    },
    {
      "verse": "28",
      "text": "They brought beds and pots and cups for David's people. They also brought food for David and his people to eat. There was wheat, barley, flour and cooked grain. They also brought beans, lentils,"
    },
    {
      "verse": "29",
      "text": "honey, cream, sheep and cheese made from cows' milk. They said, ‘The people have travelled through the desert. So they must be tired, thirsty and hungry. ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "David brought together all the men who were with him. He chose some officers to lead groups of 1, 000 soldiers, and some to lead groups of 100 soldiers."
    },
    {
      "verse": "2",
      "text": "David sent his army out in three groups. Joab led one group. Joab's brother Abishai, Zeruiah's son, led another group. Ittai from Gath led the third group. The king said to them all, ‘I myself will go with you into battle. ’"
    },
    {
      "verse": "3",
      "text": "But the men replied, ‘No, you must not go with us. If we have to run away quickly, it will not matter to Absalom's men. Even if they kill half of our soldiers, it will not seem important to them. What they really want is to kill you. You are worth 10, 000 of us. You must stay here in the city. Then you can send help to us if we need it. ’"
    },
    {
      "verse": "4",
      "text": "The king said to them, ‘I will do whatever you think is good. ’ So he stood beside the gate of the city while his army marched out. They marched out in their groups of hundreds and of thousands."
    },
    {
      "verse": "5",
      "text": "The king commanded Joab, Abishai and Ittai, ‘Because the young man Absalom is my son, do not hurt him. ’ All the soldiers heard David give this command to the three officers."
    },
    {
      "verse": "6",
      "text": "David's army marched out to fight Israel's army. They fought the battle in the forest of Ephraim."
    },
    {
      "verse": "7",
      "text": "David's soldiers won the fight against Israel's soldiers. Many soldiers died in the battle that day. There were 20, 000 dead men."
    },
    {
      "verse": "8",
      "text": "They fought the battle everywhere in the forest and around it. The forest itself caused the death of more men than the battle did."
    },
    {
      "verse": "9",
      "text": "During the battle, Absalom was riding on his mule and he met some of David's soldiers. His mule carried him under a big oak tree. The tree's branches caught Absalom's hair so that he hung there above the ground. His mule ran off and left him there."
    },
    {
      "verse": "10",
      "text": "One of David's men saw what had happened. He told Joab, ‘I have seen Absalom. He is hanging from an oak tree. ’"
    },
    {
      "verse": "11",
      "text": "Joab said to the man who told him the news, ‘You saw him there, did you? So why did you not kill him? I would have given you ten silver coins and a brave soldier's belt. ’"
    },
    {
      "verse": "12",
      "text": "But the man replied, ‘I would never hurt the king's son, even for a gift of 1, 000 silver coins. We all heard the king give this command to you, Abishai and Ittai. He said, “Keep the young man Absalom safe, because he is my son. ”"
    },
    {
      "verse": "13",
      "text": "If I had killed Absalom, my own life would be in danger. The king knows everything that happens! You would not have tried to save me from the king's punishment. ’"
    },
    {
      "verse": "14",
      "text": "Joab said, ‘I cannot stay here while you talk like this. ’ So he took three spears and he went to the tree where Absalom was hanging. While Absalom was still alive, Joab pushed the spears into Absalom's heart."
    },
    {
      "verse": "15",
      "text": "Then ten of Joab's own guards came around Absalom. They knocked him down and they killed him."
    },
    {
      "verse": "16",
      "text": "Then Joab made a sound with his trumpet to stop the battle. So his soldiers stopped chasing after Israel's soldiers. All the Israelite soldiers ran back to their homes."
    },
    {
      "verse": "17",
      "text": "They took Absalom's dead body and they threw it into a deep hole in the forest. They made a big heap of stones over the body. All the Israelite soldiers ran back to their homes."
    },
    {
      "verse": "18",
      "text": "While Absalom was alive, he had built a tall pillar in the King's Valley. He built it so that people would remember him. He thought, ‘I have no son, so my family's name will not continue. ’ He put his own name on the pillar, so people still call it Absalom's Pillar."
    },
    {
      "verse": "19",
      "text": "Zadok's son Ahimaaz said to Joab, ‘Let me run to give the king the good news. I will tell him that the Lord has saved him from the power of his enemies. ’"
    },
    {
      "verse": "20",
      "text": "Joab said, ‘No, it will not be good news for the king. His son is dead. You must not take this news today. Another day there will be good news for you to take to him, but not today. ’"
    },
    {
      "verse": "21",
      "text": "Then Joab spoke to a servant who came from Ethiopia, ‘Go now to the king. Tell him what you have seen. ’ The man bent down in front of Joab and then he ran off with the message."
    },
    {
      "verse": "22",
      "text": "Zadok's son Ahimaaz spoke to Joab again. He said, ‘I am not afraid of what may happen to me. Please let me run after the Ethiopian man. ’But Joab replied, ‘Why do you want to go as well? The king will not give you any gift for this news. ’ But Joab replied, ‘Why do you want to go as well? The king will not give you any gift for this news. ’"
    },
    {
      "verse": "23",
      "text": "Ahimaaz said, ‘But I do want to go, whatever happens. ’So Joab said, ‘Run after him, then! ’So Ahimaaz ran fast along a road in the Jordan Valley. He arrived near Mahanaim before the Ethiopian man. So Joab said, ‘Run after him, then! ’ So Ahimaaz ran fast along a road in the Jordan Valley. He arrived near Mahanaim before the Ethiopian man."
    },
    {
      "verse": "24",
      "text": "David was sitting between the two gates of Mahanaim city. A man went up to the top of the wall, on the roof above the gate. He was watching the road. As he looked, he saw a man who was running towards the city. He was running alone. The king said, ‘If the man is alone, he is bringing good news. ’ The man who was running towards the city came much nearer."
    },
    {
      "verse": "25",
      "text": "So the man on the wall shouted a message to the king, to say what he had seen. The king said, ‘If the man is alone, he is bringing good news. ’ The man who was running towards the city came much nearer."
    },
    {
      "verse": "26",
      "text": "Then the man on the wall saw another man who was running towards the city. He called down to the guard at the city's gate, ‘Look! There is another man who is running alone! ’The king said, ‘He will bring good news, too. ’ The king said, ‘He will bring good news, too. ’"
    },
    {
      "verse": "27",
      "text": "The man on the wall said, ‘The first man is running like Zadok's son, Ahimaaz. ’The king said, ‘He is a good man. I am sure that he brings good news. ’ The king said, ‘He is a good man. I am sure that he brings good news. ’"
    },
    {
      "verse": "28",
      "text": "Then Ahimaaz shouted to the king, ‘All is well! ’ He bent down low in front of the king, with his face towards the ground. He said, ‘Praise the Lord your God! He has put your enemies under your power. They turned against you, my lord the king, but they have lost the fight. ’"
    },
    {
      "verse": "29",
      "text": "The king asked, ‘Is the young man Absalom safe? ’Ahimaaz answered, ‘When Joab sent me, your servant, I saw that many people had come together. There was a lot of noise, but I do not know what was happening. ’ Ahimaaz answered, ‘When Joab sent me, your servant, I saw that many people had come together. There was a lot of noise, but I do not know what was happening. ’"
    },
    {
      "verse": "30",
      "text": "The king said, ‘Stand over there and wait. ’ So Ahimaaz moved away and he waited."
    },
    {
      "verse": "31",
      "text": "Then the Ethiopian man arrived. He said, ‘My lord the king, listen to this good news! Today the Lord has helped you to win the fight. He has kept you safe from all the people who turned against you. ’"
    },
    {
      "verse": "32",
      "text": "The king asked the Ethiopian man, ‘Is the young man Absalom safe? ’The man replied, ‘My lord the king, I hope that your enemies and all those who want to hurt you would be as dead as he is! ’ The man replied, ‘My lord the king, I hope that your enemies and all those who want to hurt you would be as dead as he is! ’"
    },
    {
      "verse": "33",
      "text": "The king became very upset. He went upstairs to the room above the gate. He wept loudly. As he went, he cried, ‘My son Absalom! My son, my son Absalom! It would be better if I had died instead of you! Absalom, my son, my son! ’"
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "Someone told Joab that the king was very sad and he was weeping because Absalom was dead."
    },
    {
      "verse": "2",
      "text": "All the people heard the news that the king was very sad about his son's death. King David's army had won the battle, so everyone should have been very happy. But instead, they were all sad."
    },
    {
      "verse": "3",
      "text": "The soldiers came very quietly back into Mahanaim city. It seemed like they were ashamed because they had run away from the battle."
    },
    {
      "verse": "4",
      "text": "The king covered his face and he cried, ‘Absalom, Absalom! My son, my son! ’"
    },
    {
      "verse": "5",
      "text": "Then Joab went to see the king in his room. He said to the king, ‘Today you have made your men feel ashamed. But the army has saved your life today. We have saved the lives of your sons, your daughters, your wives, and your slave wives."
    },
    {
      "verse": "6",
      "text": "You seem to love the people who hate you. And you seem to hate the people who love you! You have shown today that your officers and soldiers are not important to you. It seems that you would be happy if Absalom were still alive, and all the rest of us were dead."
    },
    {
      "verse": "7",
      "text": "Now go out and speak to your soldiers. Thank them that they have fought well. If you do not do that, none of your men will remain here tonight. I tell you in the Lord's name, that will certainly happen. That would bring worse trouble to you than anything that has happened in your whole life. ’"
    },
    {
      "verse": "8",
      "text": "So the king went out from his room. He went to sit by the city's gate. People heard the news, ‘The king is sitting by the gate. ’ So they all came there to listen to him. At this time, the Israelite soldiers had run back to their own homes."
    },
    {
      "verse": "9",
      "text": "People in all the Israelite tribes were quarrelling with each other. They were saying, ‘King David saved us from the power of the Philistines and all our other enemies. But now Absalom has chased him out of our land."
    },
    {
      "verse": "10",
      "text": "We chose Absalom to be our king, but now he has died in the battle. We should surely go and bring David back to be our king again. ’"
    },
    {
      "verse": "11",
      "text": "Then King David sent a message to Zadok and Abiathar, the priests. He told them, ‘Go to the leaders of Judah and say to them, “Surely, you should not be the last tribe to bring the king back to his palace? He knows what the people in all Israel are saying about him."
    },
    {
      "verse": "12",
      "text": "You are my brothers! I belong to your family. So you should not be the last people to bring me back as your king. ”"
    },
    {
      "verse": "13",
      "text": "Also, say to Amasa, “We belong to the same family. I promise you that I will now make you the leader of my army, instead of Joab. I ask God to punish me if I do not do that for you. ” ’"
    },
    {
      "verse": "14",
      "text": "Because of this message, all the people of Judah's tribe agreed to serve David as their king. They sent this message to the king: ‘Return to us, together with all your officers. ’ When David arrived at the Jordan River, the people of Judah had come to Gilgal to meet him there. They wanted to help him to cross the river."
    },
    {
      "verse": "15",
      "text": "So the king left Mahanaim to return to Jerusalem. When David arrived at the Jordan River, the people of Judah had come to Gilgal to meet him there. They wanted to help him to cross the river."
    },
    {
      "verse": "16",
      "text": "Gera's son, Shimei, came there quickly with the people of Judah to meet King David. He was from Bahurim and he belonged to Benjamin's tribe."
    },
    {
      "verse": "17",
      "text": "He brought 1, 000 men from his own tribe with him. Ziba, the servant of Saul's family, also came with his 15 sons and 20 servants. They all hurried to the Jordan River to meet the king."
    },
    {
      "verse": "18",
      "text": "They crossed the river where the water was not deep. They were ready to help the king and his people come across. They were ready to do whatever the king wanted. When Shimei had gone across the Jordan River, he bent down low to the ground in front of the king."
    },
    {
      "verse": "19",
      "text": "He said to the king, ‘Please forgive me for my sin. Do not punish me. I insulted you, my lord, on the day when you left Jerusalem. Please forget about what I did."
    },
    {
      "verse": "20",
      "text": "I am your servant. I know that I did a bad thing. So I have come to meet you today. From all the descendants of Joseph, I am the first person to come to meet you here, my lord the king. ’"
    },
    {
      "verse": "21",
      "text": "Then Abishai, Zeruiah's son, said, ‘We should kill Shimei. He cursed you, the Lord's chosen king, so he deserves to die. ’"
    },
    {
      "verse": "22",
      "text": "David replied, ‘No! You sons of Zeruiah should not tell me what to do! Have you become my enemy? You should realize that today I have become king over all Israel. So we should not punish anyone with death. ’"
    },
    {
      "verse": "23",
      "text": "The king made a strong promise to Shimei. He said to Shimei, ‘You will not die because of this. ’"
    },
    {
      "verse": "24",
      "text": "Mephibosheth, Saul's grandson, also came from Jerusalem to meet the king. Since David had left Jerusalem, Mephibosheth had not washed his feet, cut his beard or washed his clothes."
    },
    {
      "verse": "25",
      "text": "When he arrived from Jerusalem to meet the king, David asked him, ‘Why did you not go with me, Mephibosheth? ’"
    },
    {
      "verse": "26",
      "text": "He said, ‘My lord the king, as you know, I cannot walk properly. So I said to my servant, “Prepare a donkey for me to ride, so that I can leave Jerusalem with the king. ” But Ziba, my servant, deceived me."
    },
    {
      "verse": "27",
      "text": "And he has told you lies about me. But you are like an angel of God. I know that you will do what you think is right."
    },
    {
      "verse": "28",
      "text": "I know that you, my lord the king, would have been right to kill all my grandfather's family. We all deserved that punishment. But instead, you asked me to eat meals at your table. So it would not be right for me to ask you to do anything more for me. ’"
    },
    {
      "verse": "29",
      "text": "The king said, ���You have said enough about this. I have decided that you and Ziba will share the fields that belonged to your grandfather, Saul. ’"
    },
    {
      "verse": "30",
      "text": "Mephibosheth said to the king, ‘That is not important to me. Ziba can take them all. You have returned home safely. That is what makes me happy. ’"
    },
    {
      "verse": "31",
      "text": "Barzillai, the man from Gilead, came from Rogelim to meet the king at the Jordan River. He wanted to help the king to come across the river and to continue his journey."
    },
    {
      "verse": "32",
      "text": "But Barzillai was a very old man, 80 years old. He had taken care of David when David was living in Mahanaim. He had helped David with many gifts, because he was a very rich man."
    },
    {
      "verse": "33",
      "text": "King David said to him, ‘Come with me to live in Jerusalem. I will take care of you while you are with me there. ’"
    },
    {
      "verse": "34",
      "text": "Barzillai answered the king, ‘I will not live many more years. Why should I go to live in Jerusalem with the king?"
    },
    {
      "verse": "35",
      "text": "years old. I can no longer tell what is nice or what is bad. I cannot taste what I eat and drink. I cannot still hear people's voices when they sing. I would only cause trouble to you, my lord the king."
    },
    {
      "verse": "36",
      "text": "I will come across the river and I will travel a short way with you. But I cannot accept your kind gift."
    },
    {
      "verse": "37",
      "text": "Let me return to my own town, sir. Then I will die there. They can bury me near the grave of my father and my mother. Look! Here is my son, Kimham. Let him go with you, my lord the king. Please do for him whatever you think is right. ’"
    },
    {
      "verse": "38",
      "text": "The king said, ‘Kimham can go with me. I will do for him whatever you think is good. I will also help you in any way that you choose. ’"
    },
    {
      "verse": "39",
      "text": "So all the people went across the Jordan River with the king. The king kissed Barzillai and he asked God to bless him. Then Barzillai returned to his home."
    },
    {
      "verse": "40",
      "text": "The king went across the river to Gilgal. Kimham went with him. All Judah's army and half of Israel's soldiers helped the king to cross the river."
    },
    {
      "verse": "41",
      "text": "Then all the men of Israel's tribes came to the king. They complained, ‘Why did our brothers, the men of Judah's tribe, take you for themselves? Why were they the only people who could help the king to cross the Jordan River? They helped you and your family and your soldiers to cross, and we had no part in it. ’"
    },
    {
      "verse": "42",
      "text": "The men of Judah's tribe replied, ‘We did it because the king belongs to our own family. Do not be angry about it. The king did not pay for the food that we ate. We have not taken any of his things for ourselves. ’"
    },
    {
      "verse": "43",
      "text": "The men of Israel's tribes replied, ‘In Israel we are ten tribes, and Judah is only one tribe. So he is our king ten times more than he is your king! So why have you tried to insult us? We were the first people to say that we should bring the king back to Jerusalem. ’But the words that the men of Judah spoke were much stronger than the words of the men of Israel."
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "There was a wicked man there in Gilgal. His name was Sheba. He was Bicri's son, who belonged to Benjamin's tribe. He made a loud noise with a trumpet and then he shouted, ‘Israelite people, we have nothing to do with Jesse's son, David! We do not belong to his kingdom! So we should all return to our homes. ’"
    },
    {
      "verse": "2",
      "text": "So the Israelites left David in Gilgal, and they went with Bicri's son, Sheba. But the men of Judah's tribe stayed with David. They helped him on his journey all the way from the Jordan River to Jerusalem."
    },
    {
      "verse": "3",
      "text": "David returned to his palace in Jerusalem. Then he took the ten slave wives that he had left there to take care of his palace. Now he made them live in their own house, with guards to keep them safe. He gave them everything that they needed, but he did not sleep with them. They lived there on their own. They lived like widows until they died."
    },
    {
      "verse": "4",
      "text": "The king said to Amasa, ‘Bring all the men of Judah's tribe here to me. Three days from now, I will meet with them. You must also be here yourself. ’"
    },
    {
      "verse": "5",
      "text": "Amasa went to fetch Judah's men, but he did not return in three days."
    },
    {
      "verse": "6",
      "text": "Then David said to Abishai, ‘Bicri's son, Sheba, will cause us more trouble than Absalom did. Take my soldiers and chase after him. If you do not catch him, his people will hide in towns with strong walls. Then he will escape from us. ’"
    },
    {
      "verse": "7",
      "text": "So Abishai took Joab's soldiers, as well as the king's personal guards, the Pelethites and the Kerethites. He and all the king's soldiers marched out from Jerusalem to find Sheba."
    },
    {
      "verse": "8",
      "text": "When they arrived at the big rock in Gibeon, Amasa came to meet them. Joab was wearing his soldier's clothes. He had a long knife that was tied to his belt. As Joab went towards Amasa, the knife fell to the ground."
    },
    {
      "verse": "9",
      "text": "Joab said to Amasa, ‘How are you, my brother? ’ He took hold of Amasa's beard with his right hand. He pretended that he wanted to kiss him. Then Joab and his brother Abishai continued to chase after Sheba."
    },
    {
      "verse": "10",
      "text": "But Amasa did not see the knife in Joab's other hand. Joab pushed the knife into Amasa's stomach. His inside parts poured out onto the ground. He died immediately. Joab did not have to hit him again. Then Joab and his brother Abishai continued to chase after Sheba."
    },
    {
      "verse": "11",
      "text": "One of Joab's soldiers stood beside Amasa's dead body. He shouted, ‘If you are fighting for Joab and for King David, you must follow Joab! ’"
    },
    {
      "verse": "12",
      "text": "Amasa's dead body was lying in the road. His blood was all around it. All the soldiers who came there stopped when they saw the body. So the man pulled Amasa's dead body off the road into a field. He covered it with a cloth."
    },
    {
      "verse": "13",
      "text": "After he had removed Amasa's dead body from the road, the soldiers all followed Joab. They continued to chase after Bicri's son, Sheba."
    },
    {
      "verse": "14",
      "text": "Sheba travelled through the land of all Israel's tribes. He arrived at Abel Beth Maakah. All the people of Bicri's clan also came to the city. They joined Sheba there."
    },
    {
      "verse": "15",
      "text": "Then Joab's soldiers arrived and they started to attack Abel Beth Maakah. They made their camp all around the city. They built heaps of earth against the city's walls. They started to dig holes through the walls to cause them to fall down."
    },
    {
      "verse": "16",
      "text": "Then a wise woman stood on the wall and she shouted to them, ‘Listen! Listen to me! Tell Joab to come near so that I can speak to him! ’"
    },
    {
      "verse": "17",
      "text": "So Joab went towards her. The woman asked him, ‘Are you Joab? ’He answered, ‘Yes, I am. ’She said to him, ‘Please listen to what I have to say. ’‘I am listening, so tell me, ’ he replied. He answered, ‘Yes, I am. ’ She said to him, ‘Please listen to what I have to say. ’ ‘I am listening, so tell me, ’ he replied."
    },
    {
      "verse": "18",
      "text": "Then she said, ‘A long time ago, people said, “If you want an answer to your problem, go to Abel city. ” So that is what people did when they had problems."
    },
    {
      "verse": "19",
      "text": "The people of this city like to live in peace. We are faithful to our nation, Israel. Have you decided to destroy such an important city in Israel? Why do you want to destroy a city that belongs to the Lord? ’"
    },
    {
      "verse": "20",
      "text": "Joab answered her, ‘That is stupid! I would never do that! I am not trying to destroy anything. The woman said to Joab, ‘Wait there! I will throw his head to you from the wall. ’"
    },
    {
      "verse": "21",
      "text": "That is not what we want. But there is a man in your city whose name is Sheba. He is Bicri's son and he comes from the hill country of Ephraim. He has turned against King David. If you will give me this one man, I will go away from your city. I will not destroy it. ’The woman said to Joab, ‘Wait there! I will throw his head to you from the wall. ’"
    },
    {
      "verse": "22",
      "text": "Then the woman spoke to all the people in the city. She told them her wise advice. So they cut off Sheba's head and they threw it off the wall to Joab. Then Joab made a loud noise with his trumpet. So his soldiers went away from the city. Each of them went to his own home. Joab returned to King David in Jerusalem. Then Joab made a loud noise with his trumpet. So his soldiers went away from the city. Each of them went to his own home. Joab returned to King David in Jerusalem."
    },
    {
      "verse": "23",
      "text": "Joab was the officer who led all Israel's army. Jehoiada's son Benaiah was the leader of the king's personal guards. Jehoiada's son Benaiah was the leader of the king's personal guards."
    },
    {
      "verse": "24",
      "text": "Adoniram ruled over the men who had to work for the king. Ahilud's son Jehoshaphat wrote a report of everything that the king did. Ahilud's son Jehoshaphat wrote a report of everything that the king did."
    },
    {
      "verse": "25",
      "text": "Sheva was the royal secretary. Zadok and Abiathar were the priests. Zadok and Abiathar were the priests."
    },
    {
      "verse": "26",
      "text": "Ira from Jair was David's special priest."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "While David was king, there was a famine in Israel for three years. So David asked the Lord what had caused this trouble. The Lord said, ‘Saul's family is guilty of murder, because Saul killed many of the Gibeonites. ’"
    },
    {
      "verse": "2",
      "text": "The Gibeonites were not descendants of Israel. They were the only Amorite people who still lived. The Israelites had promised not to kill them. But Saul thought that he should kill them. He thought that this would help Israel and Judah to rule their land. Now King David told the Gibeonites to come to speak with him."
    },
    {
      "verse": "3",
      "text": "He asked them, ‘What can I do to help you? How can I make things right between us? I want you to bring the Lord's blessing to his people again. ’"
    },
    {
      "verse": "4",
      "text": "The Gibeonites answered David, ‘We do not want Saul's family to give us money or gold. And it would not be right for us to kill anyone in Israel. ’So David asked them, ‘What do you want me to do for you? ’ So David asked them, ‘What do you want me to do for you? ’"
    },
    {
      "verse": "5",
      "text": "They answered the king, ‘You know that Saul tried to destroy us. That man wanted to kill all of our family who were living in Israel. The king said, ‘I will give them to you. ’"
    },
    {
      "verse": "6",
      "text": "So we want you to give us seven of his male descendants. Then we will kill them. We will hang their bodies at the place where people worship the Lord in Gibeah. That was Saul's town, the man that the Lord had chosen to be king. ’The king said, ‘I will give them to you. ’"
    },
    {
      "verse": "7",
      "text": "The king did not give Jonathan's son Mephibosheth to them. He was kind to Mephibosheth because of David's promise to Jonathan, Saul's son. David had made that promise in the Lord's name."
    },
    {
      "verse": "8",
      "text": "Instead, the king took Saul's two sons, Armoni and Mephibosheth. Aiah's daughter Rizpah was their mother. He also took the five sons of Saul's daughter Merab. Adriel, the son of Barzillai from Meholath, was their father."
    },
    {
      "verse": "9",
      "text": "He gave them to the Gibeonites. The Gibeonites hanged them on a hill where people worshipped the Lord. All seven of them died together. That happened at the time when the barley harvest was beginning."
    },
    {
      "verse": "10",
      "text": "Aiah's daughter, Rizpah, put sackcloth on a rock and she sat on it. She stayed there to watch her sons' bodies, from the harvest time until the heavy rain came. During that time, she stopped the birds from eating the bodies in the daytime. At night, she kept the wild animals away."
    },
    {
      "verse": "11",
      "text": "They told David what Saul's slave wife, Rizpah, had done."
    },
    {
      "verse": "12",
      "text": "Then David went to fetch the bones of Saul and Saul's son Jonathan from the people at Jabesh Gilead. Their men had secretly taken their bodies from the open place in Beth Shan. The Philistines had killed Saul on Gilboa mountain and they had hung their bodies there."
    },
    {
      "verse": "13",
      "text": "Now David brought the bones of Saul and Jonathan back from Jabesh Gilead. He also picked up the bones of the seven men that the Gibeonites had killed."
    },
    {
      "verse": "14",
      "text": "People buried the bones of Saul and Jonathan in the grave of Saul's father, Kish. The grave was in Zela, in land that belonged to Benjamin's tribe. The king had told them everything that they should do. After they had done all these things, God answered their prayers for their country."
    },
    {
      "verse": "15",
      "text": "Now the Philistines had started to attack the Israelites again. David went with his soldiers to fight against the Philistines. He became very tired."
    },
    {
      "verse": "16",
      "text": "A descendant of Rapha who was called Ishbi-Benob said that he would kill David. He had a bronze spear that weighed 3½ kilograms and he had a new sword."
    },
    {
      "verse": "17",
      "text": "But Zeruiah's son Abishai saved David. Abishai knocked down the Philistine and he killed him. So David's men said very strongly, ‘Our king, you must never again come out with us to fight a battle. You are like Israel's light. We do not want your life to finish. ’"
    },
    {
      "verse": "18",
      "text": "Some time after that, the Israelites fought a battle against the Philistines at Gob. In that battle, Sibbecai from Hushah killed Saph, a descendant of Rapha."
    },
    {
      "verse": "19",
      "text": "In another battle against the Philistines at Gob, Elhanan, the son of Jaare-Oregim from Bethlehem, killed Goliath from Gath. Goliath's spear was very thick and heavy, like a big tree."
    },
    {
      "verse": "20",
      "text": "There was another battle at Gath. Another descendant of Rapha fought against the Israelites there. He was a very large man. He had six fingers on each hand and six toes on each foot."
    },
    {
      "verse": "21",
      "text": "He shouted to insult the Israelite soldiers. So Jonathan, the son of David's brother Shimeah, killed him."
    },
    {
      "verse": "22",
      "text": "Those four Philistines were descendants of Rapha and they lived in Gath. David and his soldiers killed all of them."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "David wrote this song when the Lord saved him from the power of his enemies when Saul was king."
    },
    {
      "verse": "2",
      "text": "This is what he sang:‘The Lord keeps me safe. He is my great rock and my strong place. ‘The Lord keeps me safe. He is my great rock and my strong place."
    },
    {
      "verse": "3",
      "text": "My God is my high rock. I run to him to hide and be safe. He keeps me safe like a soldier's shield. He is the strong place where I can hide safely. God, you have saved me from men who want to attack me. I run to him to hide and be safe. He keeps me safe like a soldier's shield. He is the strong place where I can hide safely. God, you have saved me from men who want to attack me."
    },
    {
      "verse": "4",
      "text": "I praise the Lord because he deserves it! When I called to him for help, he saved me from my enemies. When I called to him for help, he saved me from my enemies."
    },
    {
      "verse": "5",
      "text": "Death was near enough to catch me! Danger was like a river that wanted to drown me. Danger was like a river that wanted to drown me."
    },
    {
      "verse": "6",
      "text": "Death was tying me up with ropes, to pull me into the deep hole of the grave. to pull me into the deep hole of the grave."
    },
    {
      "verse": "7",
      "text": "In my trouble I prayed to the Lord. I called to my God to help me. He heard my voice from his home in heaven. My prayer reached his ears. I called to my God to help me. He heard my voice from his home in heaven. My prayer reached his ears."
    },
    {
      "verse": "8",
      "text": "Then the earth moved and it shook. Even the sky shook, because God was angry. Even the sky shook, because God was angry."
    },
    {
      "verse": "9",
      "text": "He breathed out smoke from his nose. Fire and hot coals came out from his mouth, to destroy his enemies. Fire and hot coals came out from his mouth, to destroy his enemies."
    },
    {
      "verse": "10",
      "text": "God caused the sky to bend as he came down. Dark clouds were under his feet. Dark clouds were under his feet."
    },
    {
      "verse": "11",
      "text": "He sat on a cherub and he flew. He flew like the wind. He flew like the wind."
    },
    {
      "verse": "12",
      "text": "God put darkness all round him. He hid himself under dark clouds that held rain. He hid himself under dark clouds that held rain."
    },
    {
      "verse": "13",
      "text": "Bright light went in front of him. There was lightning like hot coals! There was lightning like hot coals!"
    },
    {
      "verse": "14",
      "text": "The Lord sent thunder from the sky. People everywhere heard the voice of the Most High God. People everywhere heard the voice of the Most High God."
    },
    {
      "verse": "15",
      "text": "The Lord shot arrows of lightning. He caused his enemies to run away. He caused his enemies to run away."
    },
    {
      "verse": "16",
      "text": "When the Lord shouted against his enemies, even the bottom of the deep sea appeared. People could see the deepest places of the earth, when he breathed out in anger. even the bottom of the deep sea appeared. People could see the deepest places of the earth, when he breathed out in anger."
    },
    {
      "verse": "17",
      "text": "The Lord reached down to me from above. He took hold of me and he pulled me up out of the deep water. He took hold of me and he pulled me up out of the deep water."
    },
    {
      "verse": "18",
      "text": "Yes, he saved me from my powerful enemies. The people who hated me were too strong for me, but the Lord saved me from their power. The people who hated me were too strong for me, but the Lord saved me from their power."
    },
    {
      "verse": "19",
      "text": "They attacked me when I was in trouble, but the Lord helped me. but the Lord helped me."
    },
    {
      "verse": "20",
      "text": "He led me out to an open place where I would be safe. He saved me because I made him happy. He saved me because I made him happy."
    },
    {
      "verse": "21",
      "text": "The Lord was kind to mebecause I do things that please him. He blesses mebecause I am not guilty of bad things. because I do things that please him. He blesses me because I am not guilty of bad things."
    },
    {
      "verse": "22",
      "text": "I have obeyed the Lord's commands. I have not turned against my God. I have not turned against my God."
    },
    {
      "verse": "23",
      "text": "I understand all his rules, and I do not refuse to obey them. and I do not refuse to obey them."
    },
    {
      "verse": "24",
      "text": "He knows that I have done nothing that is wrong. I kept away from any sin. I kept away from any sin."
    },
    {
      "verse": "25",
      "text": "The Lord was kind to me, because I did good things. He sees that I am not guilty. because I did good things. He sees that I am not guilty."
    },
    {
      "verse": "26",
      "text": "Lord, if people are faithful to you, then you are faithful to them. If people do nothing that is bad, they can trust you to do nothing bad to them. then you are faithful to them. If people do nothing that is bad, they can trust you to do nothing bad to them."
    },
    {
      "verse": "27",
      "text": "If people keep themselves pure, they can trust you to do only good things. But if people are wicked, you turn against them. they can trust you to do only good things. But if people are wicked, you turn against them."
    },
    {
      "verse": "28",
      "text": "You save people who are humble. But if people are proud, you cause them to fall. But if people are proud, you cause them to fall."
    },
    {
      "verse": "29",
      "text": "Lord, you make my lamp burn brightly. You are my light in the dark. You are my light in the dark."
    },
    {
      "verse": "30",
      "text": "You make me strong, so that I can chase a whole army! With the help of my God, I can climb over any high wall. so that I can chase a whole army! With the help of my God, I can climb over any high wall."
    },
    {
      "verse": "31",
      "text": "God's way is perfect. The Lord's promises are always true. He keeps safe everyone who goes to him for help, like a shield that keeps a soldier safe. The Lord's promises are always true. He keeps safe everyone who goes to him for help, like a shield that keeps a soldier safe."
    },
    {
      "verse": "32",
      "text": "We know that the Lord is God, and no one else. Only our God can keep us safe, like a strong rock! and no one else. Only our God can keep us safe, like a strong rock!"
    },
    {
      "verse": "33",
      "text": "It is God who makes me strong. He shows me the safe way through my life. He shows me the safe way through my life."
    },
    {
      "verse": "34",
      "text": "He makes my feet stand strongly on the ground. Like a deer, I can stand on high hills and not fall. Like a deer, I can stand on high hills and not fall."
    },
    {
      "verse": "35",
      "text": "He teaches me how to fight in war. He makes my arms strongto shoot arrows from a metal bow. He makes my arms strong to shoot arrows from a metal bow."
    },
    {
      "verse": "36",
      "text": "You keep me safe in the battle, like a shield. Your kind help has made me great. like a shield. Your kind help has made me great."
    },
    {
      "verse": "37",
      "text": "You have helped me to move safely, so that my feet do not slip. so that my feet do not slip."
    },
    {
      "verse": "38",
      "text": "I ran after my enemies and I destroyed them. I did not turn back until I had killed them. I did not turn back until I had killed them."
    },
    {
      "verse": "39",
      "text": "I destroyed them completely. I knocked them down to the ground. They could not get up again. They fell under my feet. I knocked them down to the ground. They could not get up again. They fell under my feet."
    },
    {
      "verse": "40",
      "text": "You have made me strong to fight battlesso that I win against my enemies. so that I win against my enemies."
    },
    {
      "verse": "41",
      "text": "You caused my enemies to turn their backs, and they ran away from me. I destroyed those who hate me. and they ran away from me. I destroyed those who hate me."
    },
    {
      "verse": "42",
      "text": "They called out for help, but nobody was there to save them. They called to the Lord, but he did not answer them. but nobody was there to save them. They called to the Lord, but he did not answer them."
    },
    {
      "verse": "43",
      "text": "I beat them until they became like dust. I walked over them, like dirt that lies on the streets. I walked over them, like dirt that lies on the streets."
    },
    {
      "verse": "44",
      "text": "You have saved me when my people were attacking me. You have made me a ruler of other nations. People that I did not know beforenow serve me as their ruler. You have made me a ruler of other nations. People that I did not know before now serve me as their ruler."
    },
    {
      "verse": "45",
      "text": "Foreign people cannot stand against me, because they are afraid. When they hear about me, they choose to obey me. because they are afraid. When they hear about me, they choose to obey me."
    },
    {
      "verse": "46",
      "text": "They are not brave enough to fight me. They shake with fearas they leave their strong cities. They shake with fear as they leave their strong cities."
    },
    {
      "verse": "47",
      "text": "The Lord is alive! He is my strong Rock! Everyone should praise him! He rules as king! He is the strong God who saves me. Everyone should praise him! He rules as king! He is the strong God who saves me."
    },
    {
      "verse": "48",
      "text": "He is the true God who punishes my enemies. He makes the nations obey me. He makes the nations obey me."
    },
    {
      "verse": "49",
      "text": "He is the one who saves me from my enemies. Yes, God, you give me powerto win against those who attack me. You keep me safe from angry and cruel men. Yes, God, you give me power to win against those who attack me. You keep me safe from angry and cruel men."
    },
    {
      "verse": "50",
      "text": "Lord, I will thank you, so that all the nations know about you. I will sing to praise your name. so that all the nations know about you. I will sing to praise your name."
    },
    {
      "verse": "51",
      "text": "Yes, the Lord gives power to me, David, his king. He gives me great strength to win against my enemies. I am the special king that he has chosen. He will continue to be kind to meand to my descendants for ever. ’"
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "These are David's last words. The God that Jacob worshipped made Jesse's son David great. God chose him to rule Israel as king. He also wrote beautiful songs for the Israelites. This is David's message:"
    },
    {
      "verse": "2",
      "text": "‘The Spirit of the Lord gives me his message. I speak what he tells me to say. I speak what he tells me to say."
    },
    {
      "verse": "3",
      "text": "Israel's God has spoken. The one who keeps Israel safe said to me, “A king should rule over people in a way that is right and fair. He should show that he respects and obeys God. The one who keeps Israel safe said to me, “A king should rule over people in a way that is right and fair. He should show that he respects and obeys God."
    },
    {
      "verse": "4",
      "text": "A king who rules like that is like the light of the sun at dawn. He is like the sky when it has no clouds in it in the morning. He is like bright sun after rain, that helps the grass to grow strongly. ” He is like the sky when it has no clouds in it in the morning. He is like bright sun after rain, that helps the grass to grow strongly. ”"
    },
    {
      "verse": "5",
      "text": "That is how God will bless my descendants. He has made a promise to me that will continue for ever. It is a strong promise that will never change. I know that he will always help me. He will do for me everything that I hope for. He has made a promise to me that will continue for ever. It is a strong promise that will never change. I know that he will always help me. He will do for me everything that I hope for."
    },
    {
      "verse": "6",
      "text": "But God will remove all wicked people. He will throw them away like weeds. They are like thorn bushesthat you cannot pull out with your hands. He will throw them away like weeds. They are like thorn bushes that you cannot pull out with your hands."
    },
    {
      "verse": "7",
      "text": "You need an iron tool or a spear to remove them. Then you burn them completely in a fire. ’ Then you burn them completely in a fire. ’"
    },
    {
      "verse": "8",
      "text": "These are the names of David's bravest soldiers: Josheb-Basshebeth was the leader of the ‘Three Brave Soldiers’. He belonged to Tahkemon's clan. He used his spear to fight against 800 men in one battle and he killed them all. Josheb-Basshebeth was the leader of the ‘Three Brave Soldiers’. He belonged to Tahkemon's clan. He used his spear to fight against 800 men in one battle and he killed them all."
    },
    {
      "verse": "9",
      "text": "Another of the ‘Three Brave Soldiers’ was Dodai's son, Eleazar. He belonged to Ahoh's clan. He was with David at Pas-Dammim when they insulted the Philistine soldiers before a battle. The Israelite soldiers ran away from the fight,"
    },
    {
      "verse": "10",
      "text": "but Eleazar stood there. He knocked down the Philistine soldiers until his hand became tired. It became fixed to his sword. On that day, the Lord caused him to win a great battle. When the other Israelite soldiers returned to help him, they took things from the dead Philistines. That was the only thing left for them to do."
    },
    {
      "verse": "11",
      "text": "The third of the ‘Three Brave Soldiers’ was Shammah, the son of Agee, who belonged to Harar's clan. The Philistine soldiers had come together in a field of beans. The Israelite soldiers ran away from them."
    },
    {
      "verse": "12",
      "text": "But Shammah stood in the middle of the field to stop the Philistines taking it for themselves. He killed the Philistines. The Lord caused him to win a great battle."
    },
    {
      "verse": "13",
      "text": "At the time of the harvest, three of David's 30 bravest soldiers went to be with David near Adullam. He was hiding there in a cave. A group of Philistine soldiers had made their camp in Rephaim valley. Those were some of the great things that the three brave soldiers did."
    },
    {
      "verse": "14",
      "text": "David was in his strong safe place. A group of Philistine soldiers had made their home in Bethlehem."
    },
    {
      "verse": "15",
      "text": "David was very thirsty. He said, ‘I want someone to bring water from the well near Bethlehem's gate for me to drink. ’"
    },
    {
      "verse": "16",
      "text": "So the three brave soldiers fought through the Philistine camp and they reached Bethlehem's gate. They took some water from the well there and they carried it back to David. But he refused to drink it. He poured it on the ground as an offering to the Lord."
    },
    {
      "verse": "17",
      "text": "He said, ‘Lord, it is not right for me to drink this water. It would seem like the blood of the men who fetched it for me. The Philistines might have killed them on the way. ’ So David refused to drink it. Those were some of the great things that the three brave soldiers did."
    },
    {
      "verse": "18",
      "text": "Abishai was the leader of David's 30 great soldiers. He was the brother of Zeruiah's son Joab. One time, he used his spear to fight 300 men and he killed them all. So he became as famous as the ‘Three Brave Soldiers’."
    },
    {
      "verse": "19",
      "text": "He was not one of the ‘Three Brave Soldiers’ but he received more honour than the other 30 great soldiers. So he became their leader."
    },
    {
      "verse": "20",
      "text": "Jehoiada's son, Benaiah, was also one of David's brave soldiers. He came from Kabzeel and he did many great things. He killed two of Moab's best soldiers. He also went down into a deep hole to kill a lion when snow was on the ground."
    },
    {
      "verse": "21",
      "text": "Benaiah also killed a great Egyptian man who held a spear. Benaiah attacked him with a heavy stick. He took the spear from the Egyptian's hand and he used it to kill him."
    },
    {
      "verse": "22",
      "text": "Those were some things that Jehoiada's son Benaiah did. He became as famous as the ‘Three Brave Soldiers’."
    },
    {
      "verse": "23",
      "text": "great soldiers, but he did not belong to the ‘Three Brave Soldiers’. David made him the leader of his own special soldiers who were his guards."
    },
    {
      "verse": "24",
      "text": "These men were among David's 30 great soldiers: Joab's brother Asahel, Elhanan, Dodo's son, from Bethlehem, great soldiers if you count them all."
    },
    {
      "verse": "25",
      "text": "Shammah and Elika, from Harod's clan,"
    },
    {
      "verse": "26",
      "text": "Helez, from Pelet, Ira, Ikkesh's son, from Tekoa,"
    },
    {
      "verse": "27",
      "text": "Abiezer, from Anathoth, Mebunnai, from Hushah's clan,"
    },
    {
      "verse": "28",
      "text": "Zalmon, from Ahoh's clan, Maharai, from Netophah,"
    },
    {
      "verse": "29",
      "text": "Heleb, Baanah's son, from Netophah, Ittai, Ribai's son, from Gibeah in the land that belonged to Benjamin's tribe,"
    },
    {
      "verse": "30",
      "text": "Benaiah, from Pirathon, Hiddai, from the valleys near Gaash,"
    },
    {
      "verse": "31",
      "text": "Abi-Albon from Arabah's clan, Azmaveth, from Bahurim,"
    },
    {
      "verse": "32",
      "text": "Eliahba, from Shaalbon, Jashen's sons, Jonathan,"
    },
    {
      "verse": "33",
      "text": "Shammah's son, from Harar, Ahiam, Sharar's son, from Harar,"
    },
    {
      "verse": "34",
      "text": "Eliphelet, Ahasbai's son, from Maakah, Eliam, Ahithophel's son, from Gilo,"
    },
    {
      "verse": "35",
      "text": "Hezro, from Carmel, Paarai, from Arba,"
    },
    {
      "verse": "36",
      "text": "Igal, Nathan's son, from Zobah, Bani, who belonged to Gad's tribe,"
    },
    {
      "verse": "37",
      "text": "Zelek, from Ammon, Naharai, from Beeroth (he carried Joab's weapons),"
    },
    {
      "verse": "38",
      "text": "Ira and Gareb, from Jattir,"
    },
    {
      "verse": "39",
      "text": "and Uriah the Hittite. There were 37 great soldiers if you count them all."
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "The Lord again became angry with the Israelites. So he caused David to bring trouble to them. He said to David, ‘Send men to count the people in Israel and Judah. ’"
    },
    {
      "verse": "2",
      "text": "So the king said to Joab, the leader of his army, ‘Go from Dan to Beersheba, through all the tribes of Israel. Count all the men who can fight. I want to know how many men there are. ’"
    },
    {
      "verse": "3",
      "text": "But Joab said to the king, ‘I pray that the Lord your God will make your army bigger and bigger. May it grow 100 times while you are alive to see it! But, my lord the king, why do you want to do this? ’"
    },
    {
      "verse": "4",
      "text": "But Joab and his officers had to obey the king's command. So Joab and the officers of the army went out to count the number of people in Israel."
    },
    {
      "verse": "5",
      "text": "They crossed the Jordan River. They made their first camp in a valley, on the south side of Aroer. Then they went through Gad's land and they reached Jazer."
    },
    {
      "verse": "6",
      "text": "They went from there to Gilead. Then they went to Kadesh in the land of the Hittites. Then they went to Dan and they continued west to Sidon."
    },
    {
      "verse": "7",
      "text": "Then they went south to Tyre, a strong city with walls around it. They went to all the towns of the Hivites and the Canaanites. Then they arrived at Beersheba in the south part of Judah."
    },
    {
      "verse": "8",
      "text": "In that way, they travelled through the whole country. After nine months and 20 days they returned to Jerusalem."
    },
    {
      "verse": "9",
      "text": "Joab reported to the king about the number of soldiers who could fight. There were 800, 000 men in Israel who could use a sword to fight. There were also 500, 000 soldiers in Judah."
    },
    {
      "verse": "10",
      "text": "David had counted the men who were able to fight in his army. But now he was sorry that he had done it. He said to the Lord, ‘What I have done was a bad sin. Please forgive me, Lord. I have done a foolish thing. ’"
    },
    {
      "verse": "11",
      "text": "While David slept that night, the Lord gave a message to Gad, David's prophet."
    },
    {
      "verse": "12",
      "text": "The Lord told him, ‘Go and give my message to David: “There are three ways that I could punish you. You must choose one of them, and that is what I will do to punish you. ” ’"
    },
    {
      "verse": "13",
      "text": "So when David woke up, Gad went to him and he said, ‘You may choose to have three years when there will be a famine in the whole country. Or you may choose to have three months when your enemies are chasing after you. Or you may choose to have three days of very bad disease in the whole country. Now think carefully and decide. I will take your answer to God, who sent me with this message. ’"
    },
    {
      "verse": "14",
      "text": "David said to Gad, ‘I am very upset. I do not want men to punish me. The Lord is kind and he forgives people. So it would be better for him to punish me. ’"
    },
    {
      "verse": "15",
      "text": "So, from that morning, the Lord caused a bad disease to kill people in Israel. It continued for three days, as the Lord had said. 70, 000 Israelite men died in that time, in the whole country, from Dan to Beersheba."
    },
    {
      "verse": "16",
      "text": "The Lord's angel was ready to destroy Jerusalem. But the Lord decided to stop the trouble that he was causing for the people. He said to the angel who was killing the people, ‘That is enough. Stop what you are doing! ’ When the Lord said that, his angel was standing near the threshing floor of Araunah the Jebusite."
    },
    {
      "verse": "17",
      "text": "David saw the angel who was killing the people. So he said to the Lord, ‘I am the person who has done an evil thing. These people have followed me like sheep that follow a shepherd. They have not done anything wrong. You should only punish me and my family. ’"
    },
    {
      "verse": "18",
      "text": "That day, Gad went to David. He said to David, ‘Go up to the threshing floor of Araunah the Jebusite. Build an altar there to worship the Lord. ’"
    },
    {
      "verse": "19",
      "text": "So David obeyed the Lord's message that Gad had spoken to him."
    },
    {
      "verse": "20",
      "text": "When Araunah looked, he saw the king and his officers. They were coming towards him. So he went out and he bent down low in front of the king, with his face towards the ground."
    },
    {
      "verse": "21",
      "text": "Araunah said, ‘My lord the king, why have you come here to me, your servant? ’David replied, ‘I have come to buy your threshing floor from you. I want to build an altar here to worship the Lord. Then he will stop this bad disease from killing the people. ’ David replied, ‘I have come to buy your threshing floor from you. I want to build an altar here to worship the Lord. Then he will stop this bad disease from killing the people. ’"
    },
    {
      "verse": "22",
      "text": "Araunah said to David, ‘My lord the king, take anything that you would like to offer to the Lord. You can take these oxen to offer as sacrifices. You can use the wood from these tools and yokes to make a fire. Araunah also said to the king, ‘I pray that the Lord your God will accept your offerings. ’"
    },
    {
      "verse": "23",
      "text": "I will give all these things to you sir, my lord the king. ’Araunah also said to the king, ‘I pray that the Lord your God will accept your offerings. ’"
    },
    {
      "verse": "24",
      "text": "But the king said to Araunah, ‘No, I must pay you for it. I will not burn as an offering to the Lord my God any sacrifice that costs me nothing. ’So David bought Araunah's threshing floor and his oxen for 50 silver coins."
    },
    {
      "verse": "25",
      "text": "Then he built an altar there to worship the Lord. He made burnt offerings and friendship offerings on the altar. Then the Lord answered David's prayer. The disease stopped killing people in Israel."
    }
  ]
};