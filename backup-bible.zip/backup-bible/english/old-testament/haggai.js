module.exports = {
  "1": [
    {
      "verse": "3",
      "text": "The Lord told his prophet Haggai to say this to the people:"
    },
    {
      "verse": "4",
      "text": "‘You people are living in beautiful houses. But my temple is still just a heap of stones! It is time for you to do something about it!"
    },
    {
      "verse": "5",
      "text": "I, the Almighty Lord, tell you this: Think carefully about what is happening to you."
    },
    {
      "verse": "6",
      "text": "You plant seeds but not many plants grow to give you food. You never have enough to eat. You drink, but you are still thirsty. You have clothes to wear, but they do not keep you warm. When you receive money for your work, you soon need to spend it. Then you have no money left."
    },
    {
      "verse": "7",
      "text": "The Almighty Lord also says this: Think about how you live your lives."
    },
    {
      "verse": "8",
      "text": "Now go up to the hills to get wood to build my temple again. If you do that, I will be happy. You will worship me there as you should do."
    },
    {
      "verse": "9",
      "text": "You thought that you would get a lot of food from the crops that grow in your fields. But only a few plants grew. When you brought your food home, it quickly disappeared. I blew it away! Why do you think all this happened? It happened because my temple is still a heap of stones. At the same time, you all work hard to build your own houses. I, the Almighty Lord, am telling you this!"
    },
    {
      "verse": "10",
      "text": "That is why there has been no rain on your fields. That is why your plants do not grow well."
    },
    {
      "verse": "11",
      "text": "I have stopped the rain, so that your fields and the hills have become dry. Your crops will not grow. There will be no grapes to make wine. You will not have olives to make oil. Nothing will grow in the ground. Your animals will not become fat. People and animals will all hurt. For all your work, you will get nothing. ’"
    },
    {
      "verse": "12",
      "text": "Zerubbabel and Joshua, the leader of the priests, as well as all the people obeyed the Lord, their God. They were the people that the Lord had brought back to Jerusalem from Babylon. When they heard the message that Haggai spoke to them, they agreed that it was a message from the Lord. As a result, they respected the Lord and they decided to obey him."
    },
    {
      "verse": "13",
      "text": "Haggai, the Lord's prophet, then spoke this message from the Lord: ‘The Lord says, “I am with you. ” ’"
    },
    {
      "verse": "14",
      "text": "In that way, the Lord gave strength to Zerubbabel, Joshua and all the people who had returned to live in Jerusalem. They decided to work hard to build the temple of their God, the Almighty Lord."
    },
    {
      "verse": "15",
      "text": "They started to work on the 24th day of that same month, in the second year after Darius had become king."
    },
    {
      "verse": "1",
      "text": "The Lord spoke his message to Haggai, his prophet. At that time, Darius was king of Persia. He had been king for 1 year and five months. On the first day of the next month, the Lord told Haggai to speak to Zerubbabel, Judah's ruler, and to Joshua, the leader of God's priests."
    },
    {
      "verse": "2",
      "text": "Zerubbabel was the son of Shealtiel. Joshua was the son of Jehozadak. This was the Almighty Lord's message: ‘Judah's people say that this is not the right time to build a temple for me. ’."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "On the 21st day of the seventh month, the Lord spoke again to Haggai, his prophet."
    },
    {
      "verse": "2",
      "text": "The Lord told Haggai that he must speak to Zerubbabel and to Joshua. Shealtiel's son, Zerubbabel, was the ruler of Judah. Jehozadak's son, Joshua was the leader of the priests. The Lord also told Haggai to speak his message to all the people who had returned to live in Jerusalem. The Lord told Haggai to say this to them all:"
    },
    {
      "verse": "3",
      "text": "The Lord says, ‘Some of you will remember how beautiful my temple was in past times. Look at it now! It seems nothing like it was before."
    },
    {
      "verse": "4",
      "text": "But now, Zerubbabel, be strong and brave! Joshua too, and all you people who belong here in Judah, be strong and brave! Now begin to work, because I am with you to help you. That is what I, the Almighty Lord, say to you."
    },
    {
      "verse": "5",
      "text": "Do not be afraid. Remember that I made a promise to your ancestors when I brought them out of Egypt. I promised them that I would be with them. My Spirit is now with you too."
    },
    {
      "verse": "6",
      "text": "I, the Almighty Lord also tell you this: Soon, I will cause the sky and the whole earth to shake. I will also cause the sea and the land to shake."
    },
    {
      "verse": "7",
      "text": "I will cause people in all the nations of the world to shake with fear. They will come here to offer their valuable gifts. At that time, I will cause my temple to be full of glory. I, the Almighty Lord, tell you this."
    },
    {
      "verse": "8",
      "text": "Yes, all the silver and gold in the world belongs to me. And I promise you this:"
    },
    {
      "verse": "9",
      "text": "This new temple will be even more beautiful than the old temple in past times. Here in this place I will bless my people. ’ That is what the Almighty Lord says."
    },
    {
      "verse": "10",
      "text": "The Lord spoke again to Haggai, his prophet, on the 24th day of the ninth month, in the second year since Darius had become king. This was the Lord's message:"
    },
    {
      "verse": "11",
      "text": "The Almighty Lord says, ‘Ask the priests a question about my Law."
    },
    {
      "verse": "12",
      "text": "A person might be carrying some special, holy meat in his clothes. His clothes might then touch some food. It might be bread, or soup, or wine, or oil. If the clothes that hold the holy meat touch any other food, does that other food also become holy? ’ The priests replied, ‘No. ’"
    },
    {
      "verse": "13",
      "text": "Haggai asked the priests another question: ‘If anyone touches a dead body, you know that you become unclean. If an unclean person touches any of these foods, would they also become unclean? ’ The priests replied, ‘Yes, those things would be unclean. ’"
    },
    {
      "verse": "14",
      "text": "So Haggai told them, ‘This is what the Lord says: This nation and its people are just like that. They are unclean. So everything that they do is also unclean. All the gifts that they offer to me are unclean. I could not accept them."
    },
    {
      "verse": "15",
      "text": "Think carefully what life was like before you started again to build the Lord's temple. Do not forget that."
    },
    {
      "verse": "16",
      "text": "In those days, you hoped to get 20 bags of grain from your fields. But you only got ten bags. You hoped to get 50 jars of wine from your grapes. But you only got 20 jars."
    },
    {
      "verse": "17",
      "text": "I sent bad weather and other problems to destroy all your crops. All your hard work came to nothing. But you still did not return to worship me, your Lord."
    },
    {
      "verse": "18",
      "text": "Remember today, the 24th day of the ninth month. You have started again to build my temple. Now you have built its foundation, think about what will happen from today."
    },
    {
      "verse": "19",
      "text": "You have already eaten the crops that you stored. The grapes, figs, pomegranates and olives are not yet ready for you to pick. But after today, I will bless you. You will have many good things. ’"
    },
    {
      "verse": "20",
      "text": "On the same day, the Lord spoke to Haggai again. He said:"
    },
    {
      "verse": "21",
      "text": "‘Speak to Zerubbabel, the ruler of Judah. Tell him that I will cause the sky and the whole earth to shake."
    },
    {
      "verse": "22",
      "text": "Tell him that I will destroy the power of foreign kings. I will destroy their armies. Their horses and chariots will fall down. Their soldiers will fight against each other. They will kill each other with their swords."
    },
    {
      "verse": "23",
      "text": "But I, the Almighty Lord say this to you, Zerubbabel, son of Shealtiel. You are my servant and I have chosen you. On that special day, I will give to you the authority to rule on my behalf. That is the message of the Almighty Lord. ’"
    }
  ]
};