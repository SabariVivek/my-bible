module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This is Solomon's most beautiful song. The young woman: The young woman:"
    },
    {
      "verse": "2",
      "text": "Please kiss me with your lips! Your love makes me happier than wine does. Your love makes me happier than wine does."
    },
    {
      "verse": "3",
      "text": "You have put perfume on your body. It has a lovely smell. The sound of your name causes pleasure everywhere, like sweet perfume. All the young women love you! It has a lovely smell. The sound of your name causes pleasure everywhere, like sweet perfume. All the young women love you!"
    },
    {
      "verse": "4",
      "text": "Take me away with you. Come quickly. I want the king to take me into his rooms. The woman's friends: We are very happy! You make us happy. We praise your love, because it is better than wine. The young woman: I agree! The young women are right to praise you like that. I want the king to take me into his rooms. The woman's friends: We are very happy! You make us happy. We praise your love, because it is better than wine. The young woman: I agree! The young women are right to praise you like that."
    },
    {
      "verse": "5",
      "text": "Young women of Jerusalem, my skin is dark but I am beautiful. My skin is dark, like the tents of Kedar. It is beautiful, like the curtains of King Solomon's tent. My skin is dark, like the tents of Kedar. It is beautiful, like the curtains of King Solomon's tent."
    },
    {
      "verse": "6",
      "text": "The sun has caused my skin to become dark. Please do not look at me as if I am strange. My brothers were angry with me. They caused me to work outside in the sun. I took care of the vineyards, and I could not take care of my own vineyard, my body. Please do not look at me as if I am strange. My brothers were angry with me. They caused me to work outside in the sun. I took care of the vineyards, and I could not take care of my own vineyard, my body."
    },
    {
      "verse": "7",
      "text": "I love you, my dear one. Tell me where you take your sheep to eat grass. Where will you take them to rest at midday? I do not want to look for you everywhereamong the sheep of your friends. They might not understand what I am doing. The young man: Tell me where you take your sheep to eat grass. Where will you take them to rest at midday? I do not want to look for you everywhere among the sheep of your friends. They might not understand what I am doing. The young man:"
    },
    {
      "verse": "8",
      "text": "You are the most beautiful woman of all. If you do not know where to find me, follow the marks from the feet of my sheep. Take your young goats to eat grassamong the tents of the shepherds. If you do not know where to find me, follow the marks from the feet of my sheep. Take your young goats to eat grass among the tents of the shepherds."
    },
    {
      "verse": "9",
      "text": "My dear friend, you are very beautiful. You seem to me like a beautiful horse that pulls one of Pharaoh's chariots. You seem to me like a beautiful horse that pulls one of Pharaoh's chariots."
    },
    {
      "verse": "10",
      "text": "Your face is beautiful with jewels. A necklace makes your neck beautiful too. A necklace makes your neck beautiful too."
    },
    {
      "verse": "11",
      "text": "We will use gold to make ear rings for you, and we will add pieces of silver. The young woman: and we will add pieces of silver. The young woman:"
    },
    {
      "verse": "12",
      "text": "While the king was eating a meal, the sweet smell of my perfume was in the air. the sweet smell of my perfume was in the air."
    },
    {
      "verse": "13",
      "text": "My lover is like a bag of myrrhthat lies between my breasts. that lies between my breasts."
    },
    {
      "verse": "14",
      "text": "He is like a group of henna flowersthat grow in the vineyards at En Gedi. The young man: that grow in the vineyards at En Gedi. The young man:"
    },
    {
      "verse": "15",
      "text": "My dear friend, I see that you are very beautiful! Yes, you are beautifuland your eyes are like doves. The young woman: Yes, you are beautiful and your eyes are like doves. The young woman:"
    },
    {
      "verse": "16",
      "text": "My lover, I see that you are very handsome! Yes, you are lovely! This field of fresh, green grass is our comfortable bed. Yes, you are lovely! This field of fresh, green grass is our comfortable bed."
    },
    {
      "verse": "17",
      "text": "The cedar trees above us are the beams of our bedroom. The pine trees cover us like a roof."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "I am a wild flower of Sharon. I am a lily from the valleys. The young man: I am a lily from the valleys. The young man:"
    },
    {
      "verse": "2",
      "text": "Among the other young women, my dear friend is like a lilythat grows among thorn bushes. The young woman: my dear friend is like a lily that grows among thorn bushes. The young woman:"
    },
    {
      "verse": "3",
      "text": "Among the other young men, my lover is like an apple treethat grows among the trees of the forest. I love to sit in his shade. His fruit is sweet when I taste it. my lover is like an apple tree that grows among the trees of the forest. I love to sit in his shade. His fruit is sweet when I taste it."
    },
    {
      "verse": "4",
      "text": "He has taken me to the room for feasts. Everyone can see that he loves me. Everyone can see that he loves me."
    },
    {
      "verse": "5",
      "text": "I am weak with love. So give me raisins to make me strong. Give me apples to me to keep me awake. So give me raisins to make me strong. Give me apples to me to keep me awake."
    },
    {
      "verse": "6",
      "text": "His left hand is under my head. His right hand brings me near to him. His right hand brings me near to him."
    },
    {
      "verse": "7",
      "text": "Promise this to me, young women of Jerusalem: Do not cause our love to wake up. Do not cause it to become too stronguntil the time is right. The gazelles and the wild deer will know about your promise. Do not cause our love to wake up. Do not cause it to become too strong until the time is right. The gazelles and the wild deer will know about your promise."
    },
    {
      "verse": "8",
      "text": "Listen! I hear the voice of my lover! Look! He is coming! He moves quickly across the mountains. He runs across the hills. Look! He is coming! He moves quickly across the mountains. He runs across the hills."
    },
    {
      "verse": "9",
      "text": "My lover is like a gazelle or a young male deer. Look! There he is! He is standing behind our wall. He is looking through the window. He wants to see into the room. Look! There he is! He is standing behind our wall. He is looking through the window. He wants to see into the room."
    },
    {
      "verse": "10",
      "text": "My lover said this to me:‘My beautiful friend, I love you. Get up now and come with me. ‘My beautiful friend, I love you. Get up now and come with me."
    },
    {
      "verse": "11",
      "text": "Look! The winter time has finished. The heavy rains have stopped. The heavy rains have stopped."
    },
    {
      "verse": "12",
      "text": "Flowers are appearing everywhere. It is now the season to sing happy songs. We can hear the voices of doves around us. It is now the season to sing happy songs. We can hear the voices of doves around us."
    },
    {
      "verse": "13",
      "text": "New fruit is growing on the fig trees. There are flowers on the vines, and their sweet smell is in the air. I love you, my beautiful friend. Please get up now and come with me! ’The young man: There are flowers on the vines, and their sweet smell is in the air. I love you, my beautiful friend. Please get up now and come with me! ’ The young man:"
    },
    {
      "verse": "14",
      "text": "My dear friend, you are like a dove that is hiding among the rocks. You hide from me in the mountains. Show your face to mebecause it is lovely. Let me hear your voicebecause it has a sweet sound. You hide from me in the mountains. Show your face to me because it is lovely. Let me hear your voice because it has a sweet sound."
    },
    {
      "verse": "15",
      "text": "Catch the foxes for us! Our vines now have flowersand they will soon give us fruit. So catch the little foxes before they destroy our vineyards. The young woman: Our vines now have flowers and they will soon give us fruit. So catch the little foxes before they destroy our vineyards. The young woman:"
    },
    {
      "verse": "16",
      "text": "My lover belongs to me, and I belong to him. He moves among the lilies with his sheep. and I belong to him. He moves among the lilies with his sheep."
    },
    {
      "verse": "17",
      "text": "Turn back to me, my lover. Stay until dawn comes and the shadows have gone, Be like a gazelle or a young male deerthat plays among the mountains' rocks."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "All night I lay on my bed. I wanted my lover to come to me. I looked for him but he did not appear. I wanted my lover to come to me. I looked for him but he did not appear."
    },
    {
      "verse": "2",
      "text": "I thought, ‘I will get up now and I will go into the city. I will look everywhere for my lover. I will look in all the streets. I will look in all the market places. ’So I looked for him, but I did not find him. I will look everywhere for my lover. I will look in all the streets. I will look in all the market places. ’ So I looked for him, but I did not find him."
    },
    {
      "verse": "3",
      "text": "The city guards found meas they walked in the streets of the city. I asked them, ‘Have you seen the man that I love? ’ as they walked in the streets of the city. I asked them, ‘Have you seen the man that I love? ’"
    },
    {
      "verse": "4",
      "text": "Just then, as I left them, I found my lover! I hugged him and I would not let him go. I took him to my mother's house. I took him into my mother's bedroom. That is where my life started, inside my mother's body. I hugged him and I would not let him go. I took him to my mother's house. I took him into my mother's bedroom. That is where my life started, inside my mother's body."
    },
    {
      "verse": "5",
      "text": "Promise this to me, young women of Jerusalem: Do not cause our love to wake up. Do not cause it to become too stronguntil the time is right. The gazelles and the wild deer will know about your promise. Do not cause our love to wake up. Do not cause it to become too strong until the time is right. The gazelles and the wild deer will know about your promise."
    },
    {
      "verse": "6",
      "text": "Who is this who is coming from the desert? It seems that smoke is rising into the air! There is a lovely smell of myrrh and incense. It is the smell of all the spices that a trader sells. It seems that smoke is rising into the air! There is a lovely smell of myrrh and incense. It is the smell of all the spices that a trader sells."
    },
    {
      "verse": "7",
      "text": "Look! They are carrying King Solomon on a throne! 60 soldiers are travelling with it. They are Israel's bravest soldiers. soldiers are travelling with it. They are Israel's bravest soldiers."
    },
    {
      "verse": "8",
      "text": "All of them have swords. They all know how to fight well. Their swords are ready for them to use. They are ready for any danger that comes in the night. They all know how to fight well. Their swords are ready for them to use. They are ready for any danger that comes in the night."
    },
    {
      "verse": "9",
      "text": "King Solomon made the throne for himself. He used wood from Lebanon to make it. He used wood from Lebanon to make it."
    },
    {
      "verse": "10",
      "text": "He used silver to make the posts for it. He used gold to make its back. Its seat has valuable purple cloth to cover it. The young women of Jerusalem made it beautiful inside, to show their love. He used gold to make its back. Its seat has valuable purple cloth to cover it. The young women of Jerusalem made it beautiful inside, to show their love."
    },
    {
      "verse": "11",
      "text": "Young women of Zion, come out to see King Solomon! He is wearing his crown. His mother put the crown on him on his wedding day. It was the happiest day of his life!"
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "My dear friend, how beautiful you are! Yes, you are very beautiful! Your eyes behind your veil are like doves. Your hair is like a group of goatsthat are coming down from Mount Gilead. Yes, you are very beautiful! Your eyes behind your veil are like doves. Your hair is like a group of goats that are coming down from Mount Gilead."
    },
    {
      "verse": "2",
      "text": "Your teeth are very white like a group of sheep. They are like sheep after someone has cut off their dirty wooland they are coming from the pool of water. Each tooth is one of a pair. Not one of them is alone. They are like sheep after someone has cut off their dirty wool and they are coming from the pool of water. Each tooth is one of a pair. Not one of them is alone."
    },
    {
      "verse": "3",
      "text": "Your lips are like bright red strings. Your mouth is lovely. The sides of your face are beautiful, like the halves of a pomegranate. I see them through your veil. Your mouth is lovely. The sides of your face are beautiful, like the halves of a pomegranate. I see them through your veil."
    },
    {
      "verse": "4",
      "text": "Your neck is like the great tower of King David. It is round and strong. Your necklace is like the shields of 1, 000 brave soldiersthat hang from the stones of the tower. It is round and strong. Your necklace is like the shields of 1, 000 brave soldiers that hang from the stones of the tower."
    },
    {
      "verse": "5",
      "text": "Your breasts are perfect, like two young gazelles that are twins. They feed themselves among the lilies. like two young gazelles that are twins. They feed themselves among the lilies."
    },
    {
      "verse": "6",
      "text": "I will go to the mountain of myrrhand the hill of frankincense. I will stay among them until the dawn comesand the shadows go away. and the hill of frankincense. I will stay among them until the dawn comes and the shadows go away."
    },
    {
      "verse": "7",
      "text": "You are completely beautiful, my dear friend. Your body is perfect in every way. Your body is perfect in every way."
    },
    {
      "verse": "8",
      "text": "Come with me from Lebanon, my bride. Yes, come with me from Lebanon. Come down from the top of Amana, from the top of Senir. Come down from the highest part of Hermon. Come away from those mountains where lions live, and where there are leopards. Yes, come with me from Lebanon. Come down from the top of Amana, from the top of Senir. Come down from the highest part of Hermon. Come away from those mountains where lions live, and where there are leopards."
    },
    {
      "verse": "9",
      "text": "I love you so much that I never want to leave you, my sister and my bride. When you looked at me only onceand I saw one jewel in your necklace, I knew that I could never leave you. my sister and my bride. When you looked at me only once and I saw one jewel in your necklace, I knew that I could never leave you."
    },
    {
      "verse": "10",
      "text": "Your love for me is wonderful, my sister and my bride. I enjoy your love even more than I enjoy wine. Your perfume has a smellthat is more lovely than any spice! my sister and my bride. I enjoy your love even more than I enjoy wine. Your perfume has a smell that is more lovely than any spice!"
    },
    {
      "verse": "11",
      "text": "Your lips taste very sweet to me, my bride. They taste like honey that falls from the honeycomb. Milk and honey are under your tongue. The smell of your clothesis like the cedar trees of Lebanon. They taste like honey that falls from the honeycomb. Milk and honey are under your tongue. The smell of your clothes is like the cedar trees of Lebanon."
    },
    {
      "verse": "12",
      "text": "My sister and my bride, you are like a garden for methat is locked to other men. You are like a spring or a fountainthat other people may not drink water from. that is locked to other men. You are like a spring or a fountain that other people may not drink water from."
    },
    {
      "verse": "13",
      "text": "Your body is like a special garden. It is full of pomegranate trees with their sweet fruit. There are wonderful fruits to enjoy. There are also henna and nard. It is full of pomegranate trees with their sweet fruit. There are wonderful fruits to enjoy. There are also henna and nard."
    },
    {
      "verse": "14",
      "text": "There are nard, saffron, calamus, cinnamonand many different spices. There are myrrh, aloesand all the best spices. and many different spices. There are myrrh, aloes and all the best spices."
    },
    {
      "verse": "15",
      "text": "You are like a spring of water in a garden. You are like a well that has fresh water. The water runs down from Lebanon's mountains. The young woman: You are like a well that has fresh water. The water runs down from Lebanon's mountains. The young woman:"
    },
    {
      "verse": "16",
      "text": "Wake up, north wind! Come now, south wind! Blow on my garden! Make the sweet smell of its spices move in the air. May my lover come into his garden now! Let him taste its wonderful fruits!"
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "I have come into my garden, my sister, my bride. I have taken my myrrh with my spice. I have eaten my honeycomb and my honey. I have drunk my wine and my milk. The writer: Eat, friends, and drink, you who love each other! Drink until you can drink no more! The young woman: I have taken my myrrh with my spice. I have eaten my honeycomb and my honey. I have drunk my wine and my milk. The writer: Eat, friends, and drink, you who love each other! Drink until you can drink no more! The young woman:"
    },
    {
      "verse": "2",
      "text": "I slept but my mind was awake. Listen! My lover is knocking on my door! He said, ‘Open the door for me, my dear friend. You are my sister, the perfect one that I love. To me you are like a beautiful dove. Dew from the night air covers my head. My hair is very wet. ’ Listen! My lover is knocking on my door! He said, ‘Open the door for me, my dear friend. You are my sister, the perfect one that I love. To me you are like a beautiful dove. Dew from the night air covers my head. My hair is very wet. ’"
    },
    {
      "verse": "3",
      "text": "I said, ‘I have taken off my day clothes. I do not want to dress myself again. I have washed my feet. I do not want them to get dirty again. ’ I do not want to dress myself again. I have washed my feet. I do not want them to get dirty again. ’"
    },
    {
      "verse": "4",
      "text": "My lover pushed his hand through the hole in the door. My heart began to beat faster because he was near. My heart began to beat faster because he was near."
    },
    {
      "verse": "5",
      "text": "I got up to open the door for my lover. My hands were wet with myrrh. Myrrh dropped from my fingersonto the handle of the door. My hands were wet with myrrh. Myrrh dropped from my fingers onto the handle of the door."
    },
    {
      "verse": "6",
      "text": "I opened the door for my lover. But he had already turned away. He had gone! I was very upset that he had gone away. I looked for him but I did not find him. I called to him but he did not answer me. But he had already turned away. He had gone! I was very upset that he had gone away. I looked for him but I did not find him. I called to him but he did not answer me."
    },
    {
      "verse": "7",
      "text": "The city guards found meas they walked in the streets of the city. They beat me and they hurt my body. Those guards on the city walls took away my robe. as they walked in the streets of the city. They beat me and they hurt my body. Those guards on the city walls took away my robe."
    },
    {
      "verse": "8",
      "text": "Young women of Jerusalem, please find my lover! Promise me to tell him this, if you find him. Tell him that my love for him has made me weak! The young women of Jerusalem: please find my lover! Promise me to tell him this, if you find him. Tell him that my love for him has made me weak! The young women of Jerusalem:"
    },
    {
      "verse": "9",
      "text": "Tell us this, most beautiful of all women. Why do you think that your lover is better than other men? Why must we promise to do this for you? The young woman: Why do you think that your lover is better than other men? Why must we promise to do this for you? The young woman:"
    },
    {
      "verse": "10",
      "text": "My lover is very handsome and healthy. He is the greatest man among 10, 000 men. He is the greatest man among 10, 000 men."
    },
    {
      "verse": "11",
      "text": "His head is like very pure gold. The hairs on his head are like waves. They are black like a raven. The hairs on his head are like waves. They are black like a raven."
    },
    {
      "verse": "12",
      "text": "His eyes are like doves beside streams of water. They are like doves that someone has washed in milk. They shine like jewels. They are like doves that someone has washed in milk. They shine like jewels."
    },
    {
      "verse": "13",
      "text": "The sides of his face are like a garden with spice trees. Their smell is like perfume. His lips are like lilieswith myrrh that falls from them. Their smell is like perfume. His lips are like lilies with myrrh that falls from them."
    },
    {
      "verse": "14",
      "text": "His arms are like bars of goldwith jewels in them. His body shines like bright ivory, with sapphire jewels to make it more beautiful. with jewels in them. His body shines like bright ivory, with sapphire jewels to make it more beautiful."
    },
    {
      "verse": "15",
      "text": "His legs are like pillars of beautiful stone. They stand on feet that are like pure gold. He stands tall like the mountains of Lebanon. He is as handsome as its best cedar trees. They stand on feet that are like pure gold. He stands tall like the mountains of Lebanon. He is as handsome as its best cedar trees."
    },
    {
      "verse": "16",
      "text": "The taste of his mouth is very sweet. Everything about him causes me to love him. I say to you, young women of Jerusalem, this is my lover! This is my true friend."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "Tell us this, most beautiful of all women. Where has your lover gone? Which way did he go? Tell us, so that we can look for him with you. The young woman: Where has your lover gone? Which way did he go? Tell us, so that we can look for him with you. The young woman:"
    },
    {
      "verse": "2",
      "text": "My lover has gone down to his garden. He has gone to his garden of spice trees. He has gone there to walk in the gardensand to pick lilies. He has gone to his garden of spice trees. He has gone there to walk in the gardens and to pick lilies."
    },
    {
      "verse": "3",
      "text": "My lover belongs to me, and I belong to him. He moves among the lilies with his sheep. The young man: and I belong to him. He moves among the lilies with his sheep. The young man:"
    },
    {
      "verse": "4",
      "text": "My dear friend, you are as beautiful as Tirzah. You are as lovely as Jerusalem. You are as wonderful as an army that is waving its flags. You are as lovely as Jerusalem. You are as wonderful as an army that is waving its flags."
    },
    {
      "verse": "5",
      "text": "Turn your eyes away from me. They give me pleasure that is too strong for me! Your hair is like a group of goatsthat are coming down from Mount Gilead. They give me pleasure that is too strong for me! Your hair is like a group of goats that are coming down from Mount Gilead."
    },
    {
      "verse": "6",
      "text": "Your teeth are very whitelike a group of clean sheep that is coming from the pool of water. Each tooth is one of a pair. Not one of them is alone. like a group of clean sheep that is coming from the pool of water. Each tooth is one of a pair. Not one of them is alone."
    },
    {
      "verse": "7",
      "text": "The sides of your face are beautiful, like the halves of a pomegranate. I see them through your veil. like the halves of a pomegranate. I see them through your veil."
    },
    {
      "verse": "8",
      "text": "queens. He may have 80 slave wives. He may have many other young women too. There may be too many for him to count! slave wives. He may have many other young women too. There may be too many for him to count!"
    },
    {
      "verse": "9",
      "text": "But there is only one woman that I want. Nobody is like her in any way. She is my perfect one, as lovely as a dove. She is the special daughter of her mother. Her mother loves her best among all her children. The young women saw her and they praised her. The queens and the slave wives also praised her. Nobody is like her in any way. She is my perfect one, as lovely as a dove. She is the special daughter of her mother. Her mother loves her best among all her children. The young women saw her and they praised her. The queens and the slave wives also praised her."
    },
    {
      "verse": "10",
      "text": "They said, ‘She is like the light that appears at dawn. She is as beautiful as the moon. She is as bright as the sun. She is as wonderful as the stars that shine brightly in their places. ’ She is as beautiful as the moon. She is as bright as the sun. She is as wonderful as the stars that shine brightly in their places. ’"
    },
    {
      "verse": "11",
      "text": "I went down to the garden of walnut trees. I wanted to see the new plants that were growing in the valley; to see if the vines had new leaves now; to see if the pomegranate trees had flowers. I wanted to see the new plants that were growing in the valley; to see if the vines had new leaves now; to see if the pomegranate trees had flowers."
    },
    {
      "verse": "12",
      "text": "I became so happythat I did not understand what was happening. I knew that I wanted to be with her. I felt that I was riding with the king's men in their chariots. The young women of Jerusalem: that I did not understand what was happening. I knew that I wanted to be with her. I felt that I was riding with the king's men in their chariots. The young women of Jerusalem:"
    },
    {
      "verse": "13",
      "text": "Come back, come back, young woman from Shulam! Yes, come back, so that we can look at you again. The young man: Why do you want to look at the young woman from Shulam? Do not look at her as if she is dancing the dance of Mahanaim."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "How beautiful are your feet in sandals, my princess! Your round hips are as beautiful as jewelsthat a clever worker has made. my princess! Your round hips are as beautiful as jewels that a clever worker has made."
    },
    {
      "verse": "2",
      "text": "Your navel is like a round bowlthat is always full of good wine. Your stomach is like a round heap of wheatwith lilies around the edge. that is always full of good wine. Your stomach is like a round heap of wheat with lilies around the edge."
    },
    {
      "verse": "3",
      "text": "Your breasts are like two young gazellesthat are twins. that are twins."
    },
    {
      "verse": "4",
      "text": "Your neck is like an ivory tower. Your eyes shine like the pools in Heshbonthat are near the Bath Rabbim gate. Your nose is like the tower of Lebanonthat looks towards Damascus. Your eyes shine like the pools in Heshbon that are near the Bath Rabbim gate. Your nose is like the tower of Lebanon that looks towards Damascus."
    },
    {
      "verse": "5",
      "text": "Your head stands tall on you, like Mount Carmel. Your long hair hangs down like a royal cloth. It is so beautiful that it can make the king its prisoner! Your long hair hangs down like a royal cloth. It is so beautiful that it can make the king its prisoner!"
    },
    {
      "verse": "6",
      "text": "You are very beautiful, my dear friend, and I love you. You give a lot of pleasure to me. and I love you. You give a lot of pleasure to me."
    },
    {
      "verse": "7",
      "text": "You stand like a tall palm tree. Your breasts are like bunches of fruit that hang from the tree. Your breasts are like bunches of fruit that hang from the tree."
    },
    {
      "verse": "8",
      "text": "I said, ‘I will climb the palm tree. I will take hold of its fruit. ’For me, your breasts are like bunches of grapes. Your breath is like the sweet smell of apples. I will take hold of its fruit. ’ For me, your breasts are like bunches of grapes. Your breath is like the sweet smell of apples."
    },
    {
      "verse": "9",
      "text": "For me, your mouth has the taste of the best wine. The young woman: May the wine pour out for my lover. May it pour over his lips and his teeth. The young woman: May the wine pour out for my lover. May it pour over his lips and his teeth."
    },
    {
      "verse": "10",
      "text": "I belong to my lover, and he wants to be with me! and he wants to be with me!"
    },
    {
      "verse": "11",
      "text": "Come with me now, my lover! Let us go and walk through the fields. We can stay in the villages for the night. Let us go and walk through the fields. We can stay in the villages for the night."
    },
    {
      "verse": "12",
      "text": "We can get up early in the morningand go to the vineyards. We can see if the vines have started to make new leaves. We can see if their flowers have opened. We can see if the pomegranate trees have flowers. When we are thereI will give my love to you. and go to the vineyards. We can see if the vines have started to make new leaves. We can see if their flowers have opened. We can see if the pomegranate trees have flowers. When we are there I will give my love to you."
    },
    {
      "verse": "13",
      "text": "The mandrake plants send out their sweet smell. At our door, there are many good things to eat. I have stored many good things that are both old and new. I have kept them all for you, my lover."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "I would like it if you were my brotherwho drank milk from my mother's breasts! If you were my brother, if I found you outside, I could kiss you. Nobody would think that I was doing something wrong. who drank milk from my mother's breasts! If you were my brother, if I found you outside, I could kiss you. Nobody would think that I was doing something wrong."
    },
    {
      "verse": "2",
      "text": "I would lead you to my mother's house. She is the one who has taught me. I would give you wine with spices to drink, the juice from my pomegranates. She is the one who has taught me. I would give you wine with spices to drink, the juice from my pomegranates."
    },
    {
      "verse": "3",
      "text": "His left hand is under my head. His right hand brings me near to him. His right hand brings me near to him."
    },
    {
      "verse": "4",
      "text": "Promise this to me, young women of Jerusalem: Do not cause our love to wake up. Do not cause it to become too stronguntil the time is right. The young women of Jerusalem: Do not cause our love to wake up. Do not cause it to become too strong until the time is right. The young women of Jerusalem:"
    },
    {
      "verse": "5",
      "text": "Who is this who is coming from the desert? Her head is on her lover's shoulder. The young woman: Under the apple tree, I caused your love to wake. That is the place where your mother became pregnant. In that place too, your mother gave birth to you in pain. Her head is on her lover's shoulder. The young woman: Under the apple tree, I caused your love to wake. That is the place where your mother became pregnant. In that place too, your mother gave birth to you in pain."
    },
    {
      "verse": "6",
      "text": "Keep me near to you, like a seal over your heart. Keep me like a seal on your arm. Keep me there always, because love is as powerful as death. It keeps hold of people as strongly as the grave does. Love burns like a hot fire. It burns with bright flames. Keep me like a seal on your arm. Keep me there always, because love is as powerful as death. It keeps hold of people as strongly as the grave does. Love burns like a hot fire. It burns with bright flames."
    },
    {
      "verse": "7",
      "text": "Even a flood of water cannot stop the flames. Rivers of water cannot carry it away. A man might try to give all his richesto buy a woman's love. But she would refuse to accept what he offers to her. The young woman's brothers: Rivers of water cannot carry it away. A man might try to give all his riches to buy a woman's love. But she would refuse to accept what he offers to her. The young woman's brothers:"
    },
    {
      "verse": "8",
      "text": "We have a younger sister. Her breasts have not yet grown. What will we do to help herwhen it is the time for her to marry? Her breasts have not yet grown. What will we do to help her when it is the time for her to marry?"
    },
    {
      "verse": "9",
      "text": "If she is a wall, we will use silver to build towers on her. But if she is a door, we will use boards of cedar wood to keep the door shut. The young woman: we will use silver to build towers on her. But if she is a door, we will use boards of cedar wood to keep the door shut. The young woman:"
    },
    {
      "verse": "10",
      "text": "I am a wall. My breasts are like strong towers. So my lover is happy when he looks at me. My breasts are like strong towers. So my lover is happy when he looks at me."
    },
    {
      "verse": "11",
      "text": "King Solomon had a vineyard in Baal Hamon. He allowed other people to take care of it. They each paid him 1, 000 silver coins for its fruit. He allowed other people to take care of it. They each paid him 1, 000 silver coins for its fruit."
    },
    {
      "verse": "12",
      "text": "But my own vineyard belongs to me alone. I take care of it myself. You may keep the 1, 000 silver coins, Solomon. And I will give 200 silver coins to those who take care of the fruit. The young man: I take care of it myself. You may keep the 1, 000 silver coins, Solomon. silver coins to those who take care of the fruit. The young man:"
    },
    {
      "verse": "13",
      "text": "You have been staying in the gardenwith your friends who are listening to you. Let me too hear your voice! The young woman: with your friends who are listening to you. Let me too hear your voice! The young woman:"
    },
    {
      "verse": "14",
      "text": "Come quickly to me now, my lover! Run like a gazelle or a young deer. Come to the mountains that have sweet spices!"
    }
  ]
};