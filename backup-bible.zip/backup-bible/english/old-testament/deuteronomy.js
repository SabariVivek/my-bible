module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "These are the words that Moses spoke to all the Israelites. They were together in the desert on the east side of the Jordan River. This is in the Jordan Valley near Suph. It is between the towns called Paran, Tophel, Laban, Hazeroth and Dizahab."
    },
    {
      "verse": "2",
      "text": "(It is a journey of 11 days from Sinai to Kadesh-Barnea, along the road past Mount Seir. )"
    },
    {
      "verse": "3",
      "text": "Moses spoke to the Israelites on the first day of the 11th month, in the 40th year of their journey. He told the Israelites the message that the Lord had commanded him to speak."
    },
    {
      "verse": "4",
      "text": "This happened after Moses and the Israelites had won against Sihon, king of the Amorites. Sihon ruled in Heshbon. They had also won against Og, the king of Bashan, who ruled in Ashtaroth. The Israelites fought against him at Edrei."
    },
    {
      "verse": "5",
      "text": "Moses began to speak the Lord's message on the east side of the Jordan River, in Moab's country. This is what he said:"
    },
    {
      "verse": "6",
      "text": "The Lord our God said to us at Sinai, ‘You have stayed for a long time near this mountain."
    },
    {
      "verse": "7",
      "text": "Now you must continue your journey. Go to the hill country of the Amorites and to all the regions near there. Go to the Jordan Valley and the mountains and the low hills in the west. Go to the Negev in the south, and to the Mediterranean coast. Go to the land of Canaan and to Lebanon, even as far as the great Euphrates river."
    },
    {
      "verse": "8",
      "text": "Look! I have given you all this land. Go there and take it for yourselves. I, the Lord, promised to give this land to your ancestors, Abraham, Isaac and Jacob, and to their descendants. ’"
    },
    {
      "verse": "9",
      "text": "At that time I, Moses, said this to you: ‘I cannot lead you and help you by myself. It is too difficult for me to do alone."
    },
    {
      "verse": "10",
      "text": "The Lord your God has caused you to become very many people. You are as many as the stars in the sky!"
    },
    {
      "verse": "11",
      "text": "I pray that the Lord, your ancestors' God, will cause you to become a thousand times as many people. That is how he has promised to bless you."
    },
    {
      "verse": "12",
      "text": "But I cannot help you with your troubles and arguments all by myself."
    },
    {
      "verse": "13",
      "text": "You must choose some wise men who understand what is right. Choose people that you know, from each of your tribes. Then I will give them authority as your leaders. ’"
    },
    {
      "verse": "14",
      "text": "You answered me, ‘That is a good idea! ’"
    },
    {
      "verse": "15",
      "text": "So I chose men that you knew were wise to be the leaders in your tribes. I gave them authority to rule over you. Some were leaders of groups of 1, 000 men. Some led groups of 100 men, or 50 men, or ten men. I also chose other officers for each tribe."
    },
    {
      "verse": "16",
      "text": "At that time, I said to your leaders, ‘Listen to the arguments between the Israelites that you lead. Decide what is right. Do that when the argument is between two Israelites. Do the same thing when the argument is between an Israelite and a foreign person who lives among you."
    },
    {
      "verse": "17",
      "text": "When you judge them, do not make any difference between important people and poor people. Listen to all of them in a careful way. Do not be afraid of anyone. God is the one who decides what is right. If it is too difficult for you to decide who is right, bring it to me. I will listen and then I will decide what is right. ’"
    },
    {
      "verse": "18",
      "text": "So, at that time, I told you about everything that you should do."
    },
    {
      "verse": "19",
      "text": "Then we left Sinai, as the Lord our God had commanded us to do. We travelled through the desert towards the hill country of the Amorites. You saw that the desert was very big and it made you very afraid. Finally, we arrived at Kadesh-Barnea."
    },
    {
      "verse": "20",
      "text": "Then I said to you, ‘You have reached the hill country of the Amorites. The Lord our God is giving this land to us."
    },
    {
      "verse": "21",
      "text": "Look at the land! It is now in front of you! The Lord your God has given it to you. Go in and take it for yourselves. The Lord, your ancestors' God, has told you to do this. So do not be afraid. Be brave! ’"
    },
    {
      "verse": "22",
      "text": "Then all of you came to me and you said, ‘Let us send some men into the land first, before we all go in. They can explore the land. Then they can bring a report to us. They can tell us the best way for us to go in there. They can tell us about the towns that we will come to. ’"
    },
    {
      "verse": "23",
      "text": "I thought that this was a good idea. I chose 12 men, one from each of your tribes."
    },
    {
      "verse": "24",
      "text": "They left and went up into the hill country. They came to Eshcol valley and they explored it."
    },
    {
      "verse": "25",
      "text": "They picked some of the fruit that they found there and they brought it back to us. They told us, ‘The land that the Lord our God is giving to us is a very good land. ’"
    },
    {
      "verse": "26",
      "text": "But you refused to go into the land. You turned against the Lord your God."
    },
    {
      "verse": "27",
      "text": "You complained to each other in your tents. You said, ‘The Lord hates us. That is why he brought us out of Egypt. He wanted to give us to the Amorites, so that they would kill us."
    },
    {
      "verse": "28",
      "text": "We do not know what will happen to us now. Our brothers who explored the land have made us afraid. They say, “Those people in Canaan are taller and stronger than we are. Their cities are big and strong. They have walls around them that reach up to the sky. We even saw some men there who are descendants of Anak. ” ’"
    },
    {
      "verse": "29",
      "text": "Then I said to you, ‘Do not be so frightened of those people."
    },
    {
      "verse": "30",
      "text": "The Lord your God will go in front of you. He will fight to help you, as he fought for you in Egypt. You saw him do it."
    },
    {
      "verse": "31",
      "text": "He was also with you in the desert. He helped you when you were weak, as a father carries his son. You saw how he helped you all the way on your journey. He brought you safely here to this place. ’"
    },
    {
      "verse": "32",
      "text": "But you did not trust the Lord your God to help you."
    },
    {
      "verse": "33",
      "text": "He was the one who went in front of you on your journey. He was there in a fire during the night and in a cloud during the day. He found good places for you to put up your tents. He showed you the way that you should go."
    },
    {
      "verse": "34",
      "text": "When the Lord heard that you were complaining, he was angry. He made this serious promise:"
    },
    {
      "verse": "35",
      "text": "‘You people who are now alive are wicked. None of you will see the good land that I promised to give to your ancestors."
    },
    {
      "verse": "36",
      "text": "Only Jephunneh's son Caleb will see it. He has obeyed me faithfully. So I will give to him and to his descendants the land that he walked on. ’"
    },
    {
      "verse": "37",
      "text": "As for me, the Lord became angry with me also, because of you. He said to me, ‘You also will not go into the land."
    },
    {
      "verse": "38",
      "text": "But your servant Joshua, the son of Nun, will go in there. You must tell him to be brave. He will lead the Israelites into the land. It will become their land."
    },
    {
      "verse": "39",
      "text": "You thought that enemies would catch your small children. But they are the people who will go into the land. Your children who are still too young to know the difference between good and bad will also go in there. I will give the land to them and it will become their land."
    },
    {
      "verse": "40",
      "text": "But now you must all turn back towards the desert. Travel along the road to the Red Sea. ’"
    },
    {
      "verse": "41",
      "text": "Then you answered me. You said, ‘Yes, we have done wrong things against the Lord. We will now go and fight those people. We will do what the Lord our God has told us to do. ’ So then each one of you picked up his weapons. You thought that it would be easy to go up into the hill country."
    },
    {
      "verse": "42",
      "text": "But the Lord told me, ‘Do not let them go up there to fight. I will not be with you to help you. Your enemies will win against you. ’"
    },
    {
      "verse": "43",
      "text": "So I told you what the Lord had said, but you would not agree. Instead, you turned against the Lord. You were so proud that you marched up into the hill country."
    },
    {
      "verse": "44",
      "text": "The Amorite people who lived in those hills came out to attack you. You ran away from them, as if they were a crowd of bees. They attacked you as you ran down into the country of Edom, all the way to Hormah."
    },
    {
      "verse": "45",
      "text": "Then you came back to Kadesh-Barnea. You wept to show the Lord that you were very sorry. But he would not listen to your prayers."
    },
    {
      "verse": "46",
      "text": "So you stayed in Kadesh for a long time, until it was time to leave."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Then we turned back to travel towards the desert. We went along the road to the Red Sea, as the Lord had told me. For many days, we walked around the region of Mount Seir."
    },
    {
      "verse": "2",
      "text": "Then the Lord said to me,"
    },
    {
      "verse": "3",
      "text": "‘You have walked round this mountain for a long time. Now turn to the north."
    },
    {
      "verse": "4",
      "text": "Give this message to the Israelites: “You will soon go through the country that belongs to Esau's descendants. They have the same ancestors that you have. They live in Seir. They will be afraid of you, so be very careful."
    },
    {
      "verse": "5",
      "text": "Do not attack them at all. I will not give any of their land to you, not even enough ground to put your foot on. I have given the hills around Mount Seir to Esau, for his descendants to live there."
    },
    {
      "verse": "6",
      "text": "When you eat their food and you drink their water, you must pay them for it."
    },
    {
      "verse": "7",
      "text": "I, the Lord your God, have blessed you in everything that you have done. I have taken care of you as you travelled through this great desert. I have been with you for 40 years. You have received everything that you needed. ” ’"
    },
    {
      "verse": "8",
      "text": "So we went on. We passed the descendants of Esau, who live in Seir. They have the same ancestors that we have. We left the road through the Jordan Valley that goes from Elath and Ezion-Geber. Instead, we travelled on the road through the Moab desert."
    },
    {
      "verse": "9",
      "text": "Then the Lord said to me, ‘Do not make the people of Moab angry. Do not start a fight against them. I will not give any part of their land to you. I have given Ar to Lot's descendants to be their city. ’"
    },
    {
      "verse": "10",
      "text": "(Some people called the Emites once lived there. There were many of them and they were as strong and tall as the Anakites."
    },
    {
      "verse": "11",
      "text": "Some people called the Emites and the Anakites, ‘Rephaites’. But the people from Moab called them ‘Emites’."
    },
    {
      "verse": "12",
      "text": "Before this time, the Horites lived in Seir, but the descendants of Esau chased them away. They destroyed the Horites and they lived in their country. The Israelites did the same thing to the people who had lived in the land that the Lord gave to them. )"
    },
    {
      "verse": "13",
      "text": "Then the Lord said, ‘Get up now and cross the Zered valley. ’ So we went across the stream."
    },
    {
      "verse": "14",
      "text": "years had passed since we left Kadesh-Barnea. By the time we crossed the Zered valley, all the men who had been old enough to fight had now died. The Lord had said that this would happen."
    },
    {
      "verse": "15",
      "text": "The Lord himself removed them so that they all died, one by one."
    },
    {
      "verse": "16",
      "text": "Finally, the last one of these men died and no longer lived among the people."
    },
    {
      "verse": "17",
      "text": "Then the Lord said to me,"
    },
    {
      "verse": "18",
      "text": "‘Today you will cross the border of Moab at Ar."
    },
    {
      "verse": "19",
      "text": "You will go into the land of the Ammonites. Do not make them angry so that they fight against you. I will not give any of their land to you. I have already given it to Lot's descendants so that they can live there. ’"
    },
    {
      "verse": "20",
      "text": "(People also call this region the land of the Rephaites, who had once lived there. The Ammonites called them Zamzummites."
    },
    {
      "verse": "21",
      "text": "There were many Zamzummites and they were as tall and strong as the Anakites. The Lord destroyed the Rephaites when the Ammonites moved in. Then the Ammonites lived there instead of the Rephaites."
    },
    {
      "verse": "22",
      "text": "The Lord had done the same thing for Esau's descendants who lived in Seir. The Lord destroyed the Horites when Esau's descendants moved in and chased them out. Esau's descendants still live in their country today."
    },
    {
      "verse": "23",
      "text": "The same thing happened to the Avvites. They had lived in villages as far west as Gaza. But Philistines came from Crete island and they killed the Avvites. The Philistines lived there instead. )"
    },
    {
      "verse": "24",
      "text": "Then God said, ‘Now go across Arnon valley. Look, I have given you the land of King Sihon, the Amorite. He is the king of Heshbon. You must go and fight against him. Attack him and take his land for yourselves."
    },
    {
      "verse": "25",
      "text": "Today I will begin to make all the people in the world afraid of you. They will hear reports about you. That will cause them to be very frightened. They will shake with fear! ’"
    },
    {
      "verse": "26",
      "text": "When we were in Kedemoth desert, I sent a message to Sihon, king of Heshbon. We wanted to agree that we would not fight against each other."
    },
    {
      "verse": "27",
      "text": "I said to him, ‘Please let us go through your country. We will only travel along the road. We will not turn away from the road, to the right side or to the left side."
    },
    {
      "verse": "28",
      "text": "Please sell us food to eat and water to drink. We will pay you with silver coins. We only want to walk through your country."
    },
    {
      "verse": "29",
      "text": "The descendants of Esau who live in Seir let us do this. So did the descendants of Moab who live in Ar. We will go through your country and then we will cross the Jordan River. We will go into the land that the Lord our God is giving to us. ’"
    },
    {
      "verse": "30",
      "text": "But Sihon, the king of Heshbon, refused to let us travel through his country. He was too proud to agree with us. The Lord our God had caused him to be like that. He wanted to put King Sihon under your power and give his land to you. You still live in his land today."
    },
    {
      "verse": "31",
      "text": "The Lord said to me, ‘Look! I have begun to give King Sihon and his country to you. Now you must begin to fight against him and take his land for yourselves. ’"
    },
    {
      "verse": "32",
      "text": "Then Sihon and all his army came out to fight a battle against us at Jahaz."
    },
    {
      "verse": "33",
      "text": "The Lord our God put him under our power. We won the battle against him. We killed King Sihon and his sons and all his soldiers."
    },
    {
      "verse": "34",
      "text": "At that time we took all his towns and we gave everything as a gift to the Lord. We killed the men, women and children. We left no one alive."
    },
    {
      "verse": "35",
      "text": "But we kept the farm animals and other valuable things in the cities for ourselves."
    },
    {
      "verse": "36",
      "text": "The Lord our God gave us all their towns. That included Aroer, on the edge of the Arnon valley, the city in the valley and other towns all the way to Gilead. No town was too strong for us to take."
    },
    {
      "verse": "37",
      "text": "But we did not go into the Ammonites' country. We did not go into the Jabbok valley. We did not go near the towns in the hill country. The Lord our God had commanded us not to attack those places."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "Then we turned and we went along the road towards Bashan. Og, king of Bashan, marched out with his whole army to attack us at Edrei."
    },
    {
      "verse": "2",
      "text": "But the Lord said to me, ‘Do not be afraid of him. I have given him to you with his whole army and his land. You must do the same thing to Og as you did to Sihon, king of the Amorites, who ruled in Heshbon. ’"
    },
    {
      "verse": "3",
      "text": "So the Lord our God put Og, king of Bashan, under our power, as well as his whole army. We killed them all so that we left no one alive."
    },
    {
      "verse": "4",
      "text": "Then we took all of his cities. We took power over all the cities in the region of Argob where King Og of Bashan ruled. There were 60 cities."
    },
    {
      "verse": "5",
      "text": "All the cities had high walls around them, with gates that the people locked. There were also very many villages which did not have walls around them."
    },
    {
      "verse": "6",
      "text": "We destroyed them completely as a gift to the Lord. We had done the same thing to the cities of Sihon, king of Heshbon. We destroyed every city and we killed all the men, women and children."
    },
    {
      "verse": "7",
      "text": "But we kept all the animals and the valuable things from the cities for ourselves."
    },
    {
      "verse": "8",
      "text": "So, at that time, we took power over all the land that the two Amorite kings, Og and Bashan, had ruled. Their land was east of the Jordan River, from the Arnon valley to Mount Hermon."
    },
    {
      "verse": "9",
      "text": "(The people from Sidon call Mount Hermon ‘Sirion’. The Amorites call it ‘Senir’. )"
    },
    {
      "verse": "10",
      "text": "We took all their cities in the high, flat land and cities in the whole of Gilead and in Bashan. We went as far as Salecah and Edrei, cities that belonged to the kingdom of Og in Bashan."
    },
    {
      "verse": "11",
      "text": "Og, king of Bashan, was the only descendant of the Rephaites who had still been alive. He had an iron bed that is still in the Ammonites' town, Rabbah. It was 4 metres long and 2 metres wide."
    },
    {
      "verse": "12",
      "text": "When we had taken power over all that land, I gave some of it to the tribes of Reuben and Gad. I gave them the land north of Aroer near the Arnon valley. I also gave them half of the hill country of Gilead and the cities there."
    },
    {
      "verse": "13",
      "text": "I gave the other part of Gilead to one half of the tribe of Manasseh. I also gave Og's kingdom, Bashan, to them. People called all the region of Argob in Bashan the land of the Rephaites."
    },
    {
      "verse": "14",
      "text": "Jair belonged to the tribe of Manasseh. He took power over all the region of Argob. He went as far as the borders of Geshur and Maakah. Then he gave his own name to that land. To this day, Bashan has the name ‘Jair's towns’."
    },
    {
      "verse": "15",
      "text": "I gave Gilead to Makir, who also belonged to the tribe of Manasseh."
    },
    {
      "verse": "16",
      "text": "As for the tribes of Reuben and Gad, I gave them land from Gilead to the Arnon valley. The middle of the valley was the border of their land. Their land went as far as the Jabbok valley, which is the border of the Ammonites' land."
    },
    {
      "verse": "17",
      "text": "The valley of the Jordan River was also a border of their land. It went from Lake Galilee as far as the Salt Sea, with Mount Pisgah to the east."
    },
    {
      "verse": "18",
      "text": "At that time I commanded you, ‘The Lord your God has given this land to you, for you to live in it. But all your soldiers must take their weapons and they must cross the Jordan River. You must go in front of the other Israelite tribes across the river."
    },
    {
      "verse": "19",
      "text": "But your wives, your children and your animals may stay here in the towns that I have given to you. I know that you have many animals."
    },
    {
      "verse": "20",
      "text": "Your men must fight to help the other Israelites until the Lord gives them a safe place to live. He has already given you a safe place to live. Now you must help the other Israelites to take the land which the Lord your God is giving to them. That land is on the other side of the Jordan River. When they take the land for themselves, you may return here to the land that I have given to you. ’"
    },
    {
      "verse": "21",
      "text": "At that time, I commanded Joshua, ‘You have seen everything that the Lord your God has done to those two kings, Sihon and Og. He will do the same thing to the kingdoms where you are going."
    },
    {
      "verse": "22",
      "text": "So do not be afraid of them. The Lord your God himself will fight to help you. ’"
    },
    {
      "verse": "23",
      "text": "At that time, I asked the Lord many times,"
    },
    {
      "verse": "24",
      "text": "‘Almighty Lord, I am your servant. You are showing me how great and how strong you are. There is no other god in heaven or on earth that can do the great things that you do."
    },
    {
      "verse": "25",
      "text": "Please let me go across the Jordan River! I want to see the good land over there. I want to see the beautiful hills and the mountains in Lebanon. ’"
    },
    {
      "verse": "26",
      "text": "But the Lord was angry with me, because of you. He would not answer my prayer. He said, ‘You have said enough! Do not speak to me about that any more."
    },
    {
      "verse": "27",
      "text": "Go up to the top of Mount Pisgah. Stand there and look all around, to the west, north, south and east. Look carefully at the land, because you will not go across the Jordan River."
    },
    {
      "verse": "28",
      "text": "Now you must tell Joshua what to do. Tell him to be brave and strong. He will lead my people across the river into the land that you see. He will help them to take the land for themselves. ’"
    },
    {
      "verse": "29",
      "text": "After that, we stayed in the valley near Beth-Peor."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Israel's people, listen to the rules and laws that I will now teach you. If you obey them, you will live. You will go into the land that the Lord, the God of your ancestors, is giving to you. The land will belong to you, for you to live in."
    },
    {
      "verse": "2",
      "text": "Do not add anything to these rules. Do not remove anything from them. You must obey the commands of the Lord your God that I am giving to you."
    },
    {
      "verse": "3",
      "text": "You saw for yourselves what the Lord your God did at Baal-Peor. He killed every person among you who worshipped Baal there."
    },
    {
      "verse": "4",
      "text": "But each of you who continued to trust the Lord your God is still alive today."
    },
    {
      "verse": "5",
      "text": "Look! I have taught you rules and laws, as the Lord my God told me to do. Now you must obey them when you go into the land where you will live."
    },
    {
      "verse": "6",
      "text": "Obey them carefully. That will show people of other nations that you are wise. They will hear about all your laws. Then they will say, ‘The people of this great nation are very wise and clever! ’"
    },
    {
      "verse": "7",
      "text": "No other nation has a god who is near to them like the Lord our God. Even great nations have no god like that. But when we pray to the Lord our God, he listens!"
    },
    {
      "verse": "8",
      "text": "And no other great nation has rules and laws that are as fair as ours. That is God's Law that I am giving to you today."
    },
    {
      "verse": "9",
      "text": "But be very careful! Never forget the things that you yourselves have seen. Remember these things for as long as you live. Tell your children and your grandchildren about all the things that God has done."
    },
    {
      "verse": "10",
      "text": "Remember when you stood in front of the Lord your God at Sinai. He said to me, ‘Bring all the people here to me so that I can tell them my commands. Then they will learn to respect me and obey me. They will do this for as long as they live and they will teach my commands to their children. ’"
    },
    {
      "verse": "11",
      "text": "At that time, you came and you stood at the edge of the mountain. You saw that the fire on the mountain reached up to the sky. But the sky was full of black clouds and it was dark."
    },
    {
      "verse": "12",
      "text": "Then the Lord spoke to you from the middle of the fire. You heard him as he spoke, but you did not see him. You only heard a voice."
    },
    {
      "verse": "13",
      "text": "He told you about his covenant and the ten commands that he wrote on two flat pieces of stone. He commanded you to obey them."
    },
    {
      "verse": "14",
      "text": "At that time, the Lord commanded me to teach you his rules and his laws. You must obey them in the land that you will now go in to live there."
    },
    {
      "verse": "15",
      "text": "Remember when the Lord spoke to you at Mount Horeb from the middle of the fire. You did not see him in any shape. So be very careful about everything that you do."
    },
    {
      "verse": "16",
      "text": "Do not make any image to be your god. That would be a sin. Do not make an image in any shape as your idol. Do not copy the shape of a man or a woman,"
    },
    {
      "verse": "17",
      "text": "or the shape of any animal or bird."
    },
    {
      "verse": "18",
      "text": "Do not copy the shape of anything that moves along the ground, or any fish that swims in the deep water."
    },
    {
      "verse": "19",
      "text": "When you look up at the sky, you see the sun, the moon and the stars. They all shine up in the sky. But do not bend down low to them or worship them. They are there because the Lord your God has made them. He has given them to people everywhere in the world."
    },
    {
      "verse": "20",
      "text": "But you belong to the Lord. He brought you out of Egypt, which was like a hot oven where you had much pain. He rescued you, to be his own special people, as you are today."
    },
    {
      "verse": "21",
      "text": "The Lord your God became angry with me, because of you. He told me very strongly that I would not go across the Jordan River. He said that I would not go into the good land that he is now giving to you."
    },
    {
      "verse": "22",
      "text": "So I will die here. I will not cross the Jordan River. But you will soon cross over. That good land will belong to you as your home."
    },
    {
      "verse": "23",
      "text": "Be careful! Do not forget the covenant that the Lord your God has made with you. Do not make for yourselves any kind of image as your idol. That is the command that he has given to you."
    },
    {
      "verse": "24",
      "text": "That is because the Lord your God wants you to belong to him alone. He is like a fire that destroys all bad things."
    },
    {
      "verse": "25",
      "text": "One day, you will have lived in the land for a long time. You will have children and grandchildren. Remember that you still must not make any kind of image as your idol. That would be a sin. Do not do any evil things that will cause the Lord your God to become angry."
    },
    {
      "verse": "26",
      "text": "I am warning you today, as everyone on earth and everyone in heaven hears what I say. If you do not obey this command, you will soon die. You will not live long in the land that is your home on the other side of the Jordan River. You will die very soon."
    },
    {
      "verse": "27",
      "text": "The Lord will send you out of that land to live among other nations. Only a few of you will continue to be alive."
    },
    {
      "verse": "28",
      "text": "Among those nations, you will worship gods that men have made from wood and stone. Those gods cannot see or hear or eat or smell anything."
    },
    {
      "verse": "29",
      "text": "But even in those places, if you look for the Lord your God, you will find him. If you want to serve him with everything that you think and with everything that you do, you will find him."
    },
    {
      "verse": "30",
      "text": "When trouble happens to you in the future, you will turn back to him. When all these bad things happen to you, you will obey God again."
    },
    {
      "verse": "31",
      "text": "That is because the Lord your God is very kind. So he will not leave you alone. He will never destroy you. He will never forget the covenant that he made with your ancestors. That was a serious promise that he made to them."
    },
    {
      "verse": "32",
      "text": "Find out what happened many years ago. Think about everything that has happened since God created people to live on the earth. Go to anyone in the world and ask them. You will realize that nothing as great as this has ever happened before. People have never heard of anything like this."
    },
    {
      "verse": "33",
      "text": "Only you, the nation of Israel, have heard the voice of God that spoke to you from the middle of the fire. Only you have heard God speak and you still live!"
    },
    {
      "verse": "34",
      "text": "No other god has tried to rescue a nation from the power of another nation. The Lord your God did this for you when you were in Egypt. You saw how he used his great authority and strength to punish the Egyptians. He did powerful miracles. He brought war and disease that made them very afraid."
    },
    {
      "verse": "35",
      "text": "The Lord has shown you all these things. So you know that he is the only true God. There is no other God."
    },
    {
      "verse": "36",
      "text": "God spoke to you from heaven so that he could teach you. Here on earth he let you see his great fire. He spoke from that fire and you heard him."
    },
    {
      "verse": "37",
      "text": "He chose you as his special people because he loved your ancestors. You are their descendants so he rescued you out of Egypt. He himself showed you his great power."
    },
    {
      "verse": "38",
      "text": "Now he is chasing out other nations so that you can take their land to live in. They are greater and stronger nations than you are, but he has given their land to you."
    },
    {
      "verse": "39",
      "text": "Remember today that the Lord is God. He rules in heaven above and on the earth below. Think about that! There is no other God."
    },
    {
      "verse": "40",
      "text": "Obey his commands and his rules that I am giving you today. If you do that, everything will be well for you and for your descendants. You will continue to live for a long time in the land that the Lord your God is giving to you. It will belong to you for ever."
    },
    {
      "verse": "41",
      "text": "Then Moses chose three special cities on the east side of the Jordan River."
    },
    {
      "verse": "42",
      "text": "If someone killed another person when he did not mean to do it, he could hide there safely. If he had not hated the other person as his enemy, he could run to one of these cities. Then he would be safe."
    },
    {
      "verse": "43",
      "text": "Moses chose these cities: For Reuben's tribe, he chose Bezer, in the high land of the desert. For Gad's tribe, he chose Ramoth, in Gilead. For Manasseh's tribe, he chose Golan, in Bashan."
    },
    {
      "verse": "44",
      "text": "This is God's Law that Moses explained to the Israelites."
    },
    {
      "verse": "45",
      "text": "These are the rules, the teaching and the commands that Moses taught the Israelites after they had left Egypt."
    },
    {
      "verse": "46",
      "text": "At that time they were in the valley near to Beth-Peor, on the east side of the Jordan River. That was in the land of Sihon, king of the Amorites, who ruled in Heshbon. Moses and the Israelites had attacked him after they came out of Egypt."
    },
    {
      "verse": "47",
      "text": "They took power over his land, as well as the land of Og, king of Bashan. These two Amorite kings ruled on the east side of the Jordan River."
    },
    {
      "verse": "48",
      "text": "Their land went from Aroer, on the edge of the Arnon valley, as far as Mount Sirion (that is Mount Hermon)."
    },
    {
      "verse": "49",
      "text": "This land included all the Jordan Valley on the east side of the river, as far south as the Salt Sea, near Mount Pisgah."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Moses called all the Israelites to come together. He said to them: Listen, Israelites, to the rules and commands that I am teaching to you today. Learn them. Be careful to obey them."
    },
    {
      "verse": "2",
      "text": "The Lord our God made a covenant with us at Sinai. God said this:"
    },
    {
      "verse": "3",
      "text": "He did not make this agreement with our ancestors. He made it with all of us who are alive here today."
    },
    {
      "verse": "4",
      "text": "The Lord spoke clearly to you from the middle of the fire on the mountain."
    },
    {
      "verse": "5",
      "text": "(At that time, I stood between the Lord and you. I repeated the Lord's message to you. You were afraid of the fire, so you did not go up the mountain. )God said this:"
    },
    {
      "verse": "6",
      "text": "‘I am the Lord your God. I brought you out of Egypt, the country where you were slaves."
    },
    {
      "verse": "7",
      "text": "You must not have any other gods except me."
    },
    {
      "verse": "8",
      "text": "You must not make any idol for yourself. Do not make a false god in the shape of anything that is in the sky above. Do not make one in the shape of anything on the earth or in the sea."
    },
    {
      "verse": "9",
      "text": "You must not bend down your head to any idol or worship it. I am the Lord your God and I want you to belong to me alone. I will punish children because of the bad things that their fathers have done. I will also punish their grandchildren and their children too. That is how I will punish everyone who hates me."
    },
    {
      "verse": "10",
      "text": "But I will truly love all those who love me. They are the people who obey my laws. I will continue to love them and their families for ever."
    },
    {
      "verse": "11",
      "text": "You must not speak the name of the Lord your God in a wrong way. The Lord will punish anyone who speaks his name in a wrong way."
    },
    {
      "verse": "12",
      "text": "Always make the Sabbath day a special day for God, as the Lord your God has commanded you."
    },
    {
      "verse": "13",
      "text": "You have six days every week to do all your work."
    },
    {
      "verse": "14",
      "text": "But the seventh day is a Sabbath day. It is special for the Lord your God. You must not do any work on that day. Your son and your daughter must not work on that day. Your servants, male or female, must not work on that day. Your ox or your donkey or any of your animals must not work on that day, nor any foreign person who lives among you. Then your servants can rest in the same way as you rest."
    },
    {
      "verse": "15",
      "text": "You must remember that you were slaves in Egypt. But I, the Lord your God, brought you out by my powerful authority. So the Lord your God has told you to make the Sabbath day a special day."
    },
    {
      "verse": "16",
      "text": "Always respect your father and your mother, as the Lord your God has commanded you. Then you will live for many years in the land that the Lord your God will give to you. And you will be happy."
    },
    {
      "verse": "17",
      "text": "You must not murder anyone."
    },
    {
      "verse": "18",
      "text": "You must not have sex with another person's wife or husband."
    },
    {
      "verse": "19",
      "text": "You must not take another person's things for yourself."
    },
    {
      "verse": "20",
      "text": "You must not say false things against your neighbour."
    },
    {
      "verse": "21",
      "text": "You must not want to take your neighbour's wife for yourself. You must not want his house or his land, or his servants, male or female. You must not want his ox or his donkey or anything else that belongs to your neighbour. ’"
    },
    {
      "verse": "22",
      "text": "These are the commands that the Lord spoke to you. You were all there together at the mountain. He spoke with a loud voice from the middle of a great fire. There was a cloud and it was very dark. He gave only those commands. Then he wrote them on two flat stones and he gave them to me."
    },
    {
      "verse": "23",
      "text": "The mountain was burning with fire and you heard God's voice speak from the darkness. Then the leaders and older men of your tribes came to speak to me."
    },
    {
      "verse": "24",
      "text": "They said, ‘The Lord our God has shown us how great and how powerful he is. We have heard his voice from the middle of the fire. We have learned this: People can continue to live, even after God has spoken to them."
    },
    {
      "verse": "25",
      "text": "But now we think that this great fire will kill us. We do not want to die! If we continue to hear the voice of the Lord our God, we will surely die."
    },
    {
      "verse": "26",
      "text": "The God who lives for ever has spoken to us from the middle of the fire. Has anyone ever heard him speak like that and then continued to live?"
    },
    {
      "verse": "27",
      "text": "We ask you to go near to the Lord our God. Listen to everything that he says. Then you should tell us what he says to you. We will listen carefully and we will obey him. ’"
    },
    {
      "verse": "28",
      "text": "The Lord heard what you said to me. He said to me, ‘I have heard what these people have said to you. What they said is right."
    },
    {
      "verse": "29",
      "text": "I really want them to respect me with fear. I want them to obey my commands in the future! If they do that, everything will be well for them and for their descendants for ever."
    },
    {
      "verse": "30",
      "text": "Now tell them to return to their tents."
    },
    {
      "verse": "31",
      "text": "But you should stay here with me. I will tell you all the commands, rules and laws that you must teach to the people. Then they can obey them in the land that I will give them to live in. ’"
    },
    {
      "verse": "32",
      "text": "So you must be careful to do everything that the Lord your God has commanded you to do. You must not refuse to obey any of his laws."
    },
    {
      "verse": "33",
      "text": "Live in the way that he has commanded you. If you do that, you will be happy in the land where you are going. You will live for a long time in the land that will be your home."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "These are the commands, rules and laws that the Lord your God gave to me. He told me to teach them to you. You must obey them when you go across the Jordan River to live in that land."
    },
    {
      "verse": "2",
      "text": "You must respect the Lord your God with fear. You must obey his rules and his commands that I am teaching you. You, your children and your grandchildren must obey them all through your lives. If you do that, you will enjoy a long life."
    },
    {
      "verse": "3",
      "text": "Listen, Israelites! Be careful to obey God's rules. If you do that, everything will be well for you. You will have many children. You will live in a land where there is plenty of food and drink, enough for everyone. The Lord, the God of your ancestors, promised that this will happen."
    },
    {
      "verse": "4",
      "text": "Listen, Israelites! The Lord alone is our God. There is no other true God."
    },
    {
      "verse": "5",
      "text": "Love the Lord your God with all your mind and with all your strength. Love him with all that you are."
    },
    {
      "verse": "6",
      "text": "Always think about these commands that I am giving you today."
    },
    {
      "verse": "7",
      "text": "Teach them to your children at all times. Talk about them when you sit together at home. Talk about them as you walk along the road, when you lie down and when you get up."
    },
    {
      "verse": "8",
      "text": "Tie them as signs on your arms and on your heads, so that you remember them."
    },
    {
      "verse": "9",
      "text": "Write them on the wood beside the doors of your houses and on your gates."
    },
    {
      "verse": "10",
      "text": "The Lord your God will soon bring you into a land that has large, beautiful cities that you did not build. That is the land that he promised to give to your ancestors, Abraham, Isaac and Jacob."
    },
    {
      "verse": "11",
      "text": "It has houses that are full of good things that you did not put into them. There are wells of water that you did not dig. There are fields with grapes and olive trees that you did not plant. You will be able to eat as much as you want."
    },
    {
      "verse": "12",
      "text": "But be careful that you do not forget the Lord. He rescued you from Egypt, where you were slaves."
    },
    {
      "verse": "13",
      "text": "You must respect and obey the Lord your God. Serve only him. If you make a serious promise, only use his name to make it strong."
    },
    {
      "verse": "14",
      "text": "Do not try to serve other gods. They are the gods that the people who live around you worship."
    },
    {
      "verse": "15",
      "text": "The Lord your God lives among you. He wants you to belong to him alone. If you worship other gods, he will be very angry with you. He will completely destroy you from the whole earth."
    },
    {
      "verse": "16",
      "text": "Do not test the Lord your God, to see what he will do. That is what you did at Massah."
    },
    {
      "verse": "17",
      "text": "Be careful to obey his commands. Remember the laws and the rules that he has told you to obey."
    },
    {
      "verse": "18",
      "text": "Do things that the Lord says are right and good. If you do that, you will be happy in everything that you do. You will go into the good land that he promised to your ancestors, and that will be your home."
    },
    {
      "verse": "19",
      "text": "You will be able to chase out all your enemies, as the Lord has promised."
    },
    {
      "verse": "20",
      "text": "One day, your children may say to you, ‘Please tell us about the rules and laws that the Lord our God commanded us to obey. ’"
    },
    {
      "verse": "21",
      "text": "Then you must tell them, ‘We were slaves of Pharaoh in Egypt. But the Lord used his great power to rescue us."
    },
    {
      "verse": "22",
      "text": "We saw him do great and powerful miracles that brought trouble to the Egyptians, and to Pharaoh himself and his family."
    },
    {
      "verse": "23",
      "text": "The Lord rescued us from Egypt so that he could give us another land to live in. That is the land that he promised to our ancestors."
    },
    {
      "verse": "24",
      "text": "The Lord commanded us to obey all these rules and to respect him with fear. If we do that, we will always live happily and the Lord will keep us safe, as he has done until now."
    },
    {
      "verse": "25",
      "text": "We must be careful to obey all the commands of the Lord our God. If we do what he has told us, he will be pleased with us as people who do what is right. ’"
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "The Lord your God will now bring you into the land that will be your home. As you go in, he will chase out seven nations that now live there. Those nations are larger and more powerful than you are. They are the Hittites, the Girgashites, the Amorites, the Canaanites, the Perizzites, the Hivites and the Jebusites."
    },
    {
      "verse": "2",
      "text": "The Lord your God will put those people under your power so that you win against them. When that happens, you must destroy them completely as a gift to God. Do not make any agreement with them to keep them safe. Do not be kind to them."
    },
    {
      "verse": "3",
      "text": "You must not marry any of these people. Do not let your daughters marry their sons. Do not take their daughters to marry your sons."
    },
    {
      "verse": "4",
      "text": "If that happens, your children may turn away from the Lord. They will start to worship other gods. Then the Lord will be very angry with you. He will immediately destroy you."
    },
    {
      "verse": "5",
      "text": "This is what you must do to the people of those nations: Break their altars and their stone pillars into pieces. Cut down their Asherah poles. Burn their idols with fire."
    },
    {
      "verse": "6",
      "text": "Remember that you are a special people who belong to the Lord your God. He has chosen you for himself out of all the other people who live on the earth. He loves you as his special people."
    },
    {
      "verse": "7",
      "text": "Why did the Lord choose you as the people who would give him pleasure? It was not because you were the largest nation on the earth. No, you were the smallest of all nations!"
    },
    {
      "verse": "8",
      "text": "Instead, it was because of the Lord's love for you. Also, he had made a serious promise to your ancestors and he was faithful to that promise. So he used his great power to bring you out of Egypt, where you were slaves. He rescued you from the power of Pharaoh, Egypt's king."
    },
    {
      "verse": "9",
      "text": "Remember that the Lord your God is the only true God. So love him and obey his commands. Then you can trust him to be faithful to his covenant. He made that covenant with you, his people, and with your descendants for ever."
    },
    {
      "verse": "10",
      "text": "But if his people turn against him, he will punish them as they deserve. He will quickly destroy them."
    },
    {
      "verse": "11",
      "text": "So be careful to obey all the commands, rules and laws that I am teaching you today."
    },
    {
      "verse": "12",
      "text": "Listen to these rules and be careful to obey them. If you do that, the Lord your God will be faithful to the covenant that he has made with you. He promised your ancestors that he would do this."
    },
    {
      "verse": "13",
      "text": "He will love you and he will bless you. He will give you many children so that you become a large nation. He will cause your fields to give you plenty of food: grain, wine and olive oil. He will cause your cows, sheep and goats to have many babies. That is how he will bless you in the land that he promised your ancestors to give you."
    },
    {
      "verse": "14",
      "text": "God will bless you more than any other people on the earth. All your people and all your animals will have children of their own."
    },
    {
      "verse": "15",
      "text": "The Lord will keep you safe from all kinds of disease. He will not give you any of the terrible diseases that you saw in Egypt. Instead, he will cause those diseases to hurt the people who hate you."
    },
    {
      "verse": "16",
      "text": "You must remove the people of every nation that the Lord your God will put under your power. Do not be kind to them. Do not worship their gods. If you do that, they will make you turn away from God."
    },
    {
      "verse": "17",
      "text": "Perhaps you will say to each other, ‘The people of these nations are stronger than we are. We cannot chase them away. ’"
    },
    {
      "verse": "18",
      "text": "But do not be afraid of them. Remember what the Lord your God did to Pharaoh and all the Egyptian people."
    },
    {
      "verse": "19",
      "text": "You saw how he punished them. You saw how he used his strength and power to do great miracles. The Lord your God did all those things to rescue you from Egypt. He will use the same power against all the people that make you afraid."
    },
    {
      "verse": "20",
      "text": "Also, the Lord your God will send great fear among these people. Even those people who hide from you will soon die."
    },
    {
      "verse": "21",
      "text": "When you fight against them, do not let them frighten you. The Lord your God is there to help you. He is a great and powerful God."
    },
    {
      "verse": "22",
      "text": "He will chase out the people of those nations, one at a time. He will not let you destroy them all immediately. If you did that, wild animals would become so many that they would be a danger to you."
    },
    {
      "verse": "23",
      "text": "But the Lord your God will put your enemies under your power. He will cause them to become completely confused, so that you can destroy them."
    },
    {
      "verse": "24",
      "text": "He will put their kings under your power. No one will remember their names any more. No one will be able to stop you. You will destroy them all."
    },
    {
      "verse": "25",
      "text": "You must burn the images of their gods with fire. Do not try to keep the silver or gold from those idols. The Lord your God hates those things. If you take it for yourselves, it will catch you like a trap."
    },
    {
      "verse": "26",
      "text": "Do not bring anything that God hates into your house. If you do that, God will be ready to destroy you as well as the thing itself. God has said that he hates things like that, so you must hate them too."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Be careful to obey all the commands that I am giving to you today. If you do that, you will continue to live, and you will have many children. You will go into the land that the Lord your God promised to your ancestors. It will become your home."
    },
    {
      "verse": "2",
      "text": "Remember how the Lord your God led you all the way across the desert. He took care of you for 40 years. He caused many troubles to come and to test you. He did that to see if you would trust him. He wanted to know whether you would continue to obey his commands."
    },
    {
      "verse": "3",
      "text": "He caused you to become hungry and then he fed you with manna. Neither you nor your ancestors had ever seen this food before. In this way, he taught you that food alone cannot cause people to live. They need to hear every word that the Lord speaks. That is what gives them true life."
    },
    {
      "verse": "4",
      "text": "years in the desert, your clothes did not spoil. Your feet did not become big with pain."
    },
    {
      "verse": "5",
      "text": "You should realize that the Lord your God wants you to learn what is right. When he punishes you, he is warning you. That is what a parent does to teach his child."
    },
    {
      "verse": "6",
      "text": "So obey the Lord's commands. Live in a way that pleases him. Respect him with fear."
    },
    {
      "verse": "7",
      "text": "Remember that the Lord your God is bringing you into a good land. It is a land that has many streams, pools and springs of water. There is water that runs in the valleys and in the hills."
    },
    {
      "verse": "10",
      "text": "You can eat all the food that you want. Then remember to thank the Lord your God for the good land that he has given to you."
    },
    {
      "verse": "11",
      "text": "Be careful that you do not forget the Lord your God. Always remember to obey his commands, rules and laws that I am telling you today."
    },
    {
      "verse": "12",
      "text": "When you are living in the land, you will have plenty of food to eat. You will build beautiful houses to live in."
    },
    {
      "verse": "13",
      "text": "You will have many cows, sheep and goats. You will have plenty of gold and silver. You will have many more things than you have now."
    },
    {
      "verse": "14",
      "text": "Then be careful! Do not become proud. Never forget the Lord your God who brought you out of Egypt. He rescued you from the place where you were slaves."
    },
    {
      "verse": "15",
      "text": "He led you through the large and terrible desert where there were dangerous snakes and scorpions. It was very hot and dry. There was no water there for you to drink. But the Lord made water pour out of a hard rock for you."
    },
    {
      "verse": "16",
      "text": "In the desert, he gave you manna to eat. That was food that your ancestors had never seen. He tested you, to see if you would trust him. He did that to help you enjoy good things in the end."
    },
    {
      "verse": "17",
      "text": "You must never say to yourself, ‘I have got all these valuable things because I am strong and clever! ’"
    },
    {
      "verse": "18",
      "text": "Instead, you must always remember the Lord your God. He is the one who gives you the strength to get good things. He does that to show that his covenant still has authority today. That is the covenant that he promised to your ancestors."
    },
    {
      "verse": "19",
      "text": "But if you forget the Lord your God, he will destroy you. If you turn to other gods and you worship them, I warn you now: God will certainly destroy you!"
    },
    {
      "verse": "20",
      "text": "The Lord will do the same thing to you as he does to your enemies. Like those nations, he will completely destroy you if you do not obey him."
    },
    {
      "verse": "8",
      "text": "It is a land where you will have plenty of food to eat. There is wheat, barley, grapes, figs, pomegranates, olives and honey. You will have everything that you need."
    },
    {
      "verse": "9",
      "text": "The rocks have iron in them. You can dig copper out of the hills."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "Moses said: Listen, Israelites! You will soon go across the Jordan River. You will chase away the people who live there in large cities with very high walls around them. Those nations of people are greater and stronger than you are."
    },
    {
      "verse": "2",
      "text": "You know about the Anakites who live there. They are strong and tall. You have heard people say, ‘No one can fight against the Anakites and win. ’"
    },
    {
      "verse": "3",
      "text": "But you must understand this: The Lord your God is leading you across the river. He is like a fire that destroys everything! He will win against your enemies. He will give you power over them. Then you will chase them away and remove them quickly. The Lord has promised you that this will happen."
    },
    {
      "verse": "4",
      "text": "The Lord your God will chase them away. After he has done that, be careful! Do not say to yourselves, ‘The Lord has brought us into this land because we do right things. ’No! It is because these nations are doing wicked things. That is why the Lord is chasing them out of the land so that you can live there."
    },
    {
      "verse": "5",
      "text": "It is not because you are doing right things. It is not because you are good, honest people. That is not the reason that you will take their land for yourselves. Instead, it is because these nations are wicked people. That is why the Lord your God will chase them away as you move in there. He will do what he promised to your ancestors, Abraham, Isaac and Jacob."
    },
    {
      "verse": "6",
      "text": "You must understand this. The Lord your God is not giving you this good land to live in because you are doing right things. No! You are proud people who do not want to obey me."
    },
    {
      "verse": "7",
      "text": "Remember how you made the Lord your God angry when you were in the desert. Never forget that! Since you left Egypt, you have always turned against the Lord your God. You have continued to make him angry all the time until you arrived here."
    },
    {
      "verse": "8",
      "text": "When you were at Sinai you made him angry enough to destroy you."
    },
    {
      "verse": "9",
      "text": "I climbed the mountain to meet with the Lord. I received the two flat stones with the covenant that he had made with you. I stayed there for 40 days and nights. During that time, I did not eat or drink anything."
    },
    {
      "verse": "10",
      "text": "Then the Lord gave the two flat stones to me. He had written all his commands on the stones with his own finger. The Lord spoke those commands to you from middle of the fire. That was on the day when you all came together at the mountain."
    },
    {
      "verse": "11",
      "text": "days and nights, the Lord gave me the two flat stones. They had his covenant on them."
    },
    {
      "verse": "12",
      "text": "Then the Lord said to me, ‘Now go down the mountain! The people that you led out of Egypt have done something very bad. They have already refused to obey my commands. They have used gold to make an idol for themselves. ’"
    },
    {
      "verse": "13",
      "text": "The Lord also said to me, ‘I know what these people are like! They are proud people who do not want to obey me."
    },
    {
      "verse": "14",
      "text": "Keep away from me! I will now destroy them! Then no one on the earth will remember them at all. Instead, Moses, I will make your descendants into a nation that is stronger and larger than they are. ’"
    },
    {
      "verse": "15",
      "text": "So I turned and I went down the mountain. It was still burning with fire. I held the two stones with the covenant on them in my hands."
    },
    {
      "verse": "16",
      "text": "When I looked, I saw that you had made an image of a calf as your idol. You really had done a very bad thing. You had quickly stopped doing the things that the Lord your God had commanded you to do."
    },
    {
      "verse": "17",
      "text": "When I saw that, I threw the two flat stones down onto the ground. I broke them into pieces while you watched."
    },
    {
      "verse": "18",
      "text": "Then I again fell down with my face on the ground, to pray to the Lord. I did that for 40 days and nights. I did not eat or drink anything. You had done an evil thing which caused the Lord to be very angry."
    },
    {
      "verse": "19",
      "text": "I prayed, because the Lord had said that he would destroy you. He was so angry with you that I was very afraid. But the Lord listened to me this time too."
    },
    {
      "verse": "20",
      "text": "The Lord was also angry with my brother Aaron. He wanted to kill Aaron. But at that time, I prayed for Aaron too."
    },
    {
      "verse": "21",
      "text": "When you made that idol, it was a sin that you did. So I took that gold calf and I burned it in the fire. Then I beat it into powder, like dust. I threw the powder into a stream that ran down from the mountain."
    },
    {
      "verse": "22",
      "text": "After that, you also caused the Lord to be angry with you at Taberah, at Massah and at Kibroth-Hattaavah."
    },
    {
      "verse": "23",
      "text": "When the Lord sent you out from Kadesh-Barnea, he said, ‘Go into the land that I have given to you and live there. ’ But you turned against the Lord your God. You refused to trust him or obey him."
    },
    {
      "verse": "24",
      "text": "You have refused to obey the Lord ever since I have known you."
    },
    {
      "verse": "25",
      "text": "days and nights. I prayed to the Lord because he had said that he would destroy you."
    },
    {
      "verse": "26",
      "text": "I prayed this prayer: ‘Almighty Lord, do not destroy your people! They belong to you as your special people. You used your great power and strength to rescue them from Egypt."
    },
    {
      "verse": "27",
      "text": "Remember your servants, Abraham, Isaac and Jacob. Do not think about these proud people who are so wicked. Please forgive their sins."
    },
    {
      "verse": "28",
      "text": "If you destroy your people, the Egyptians will say, “The Lord could not take them into the land that he promised to give to them. Instead, he took them into the desert so that he could kill them there. He did this because he hated them! ”"
    },
    {
      "verse": "29",
      "text": "Please remember that they belong to you as your own special people. You used your strength and your power to rescue them. ’"
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "At that time, the Lord said to me, ‘Cut out two new flat stones that are like the first stones. Then bring them up to me, on the mountain. You must also use some wood to make a big box."
    },
    {
      "verse": "2",
      "text": "I will write on the new stones the same words that I wrote on the first stones. You broke those stones. But you must put the new stones into the wooden box. ’"
    },
    {
      "verse": "3",
      "text": "So I used acacia wood to make a box. I also cut two new flat stones that were like the first stones. Then I carried the two new stones up the mountain in my hands."
    },
    {
      "verse": "4",
      "text": "The Lord wrote on the stones the same words that he had written before. Those were the ten special commands that he had told you before. He spoke those commands from the middle of the fire on the mountain, when you came together there. Then the Lord gave the stones to me."
    },
    {
      "verse": "5",
      "text": "I came down from the mountain. I put the stones into the box that I had made, as the Lord had told me to do. The stones are still there now."
    },
    {
      "verse": "6",
      "text": "(At that time, the Israelites travelled to Moserah from the wells that belonged to Jaakan's descendants. Aaron died there and they buried him. His son Eleazar became priest instead."
    },
    {
      "verse": "7",
      "text": "Then they travelled to Gudgodah. From there they travelled to Jotbathah, a place where there are many streams of water."
    },
    {
      "verse": "8",
      "text": "At that time, the Lord chose the tribe of Levi to carry the Lord's Covenant Box. He chose them to be his special servants. They had to pray for the Lord to bless his people. They still do these things today."
    },
    {
      "verse": "9",
      "text": "That is why the Levites did not receive any land for themselves, as the other tribes did. The Lord himself would give them everything that they needed, as he had promised. )"
    },
    {
      "verse": "10",
      "text": "days and nights, as I did the first time. The Lord listened to my prayer. He decided that he would not destroy you."
    },
    {
      "verse": "11",
      "text": "Then the Lord said to me, ‘Go now! Lead the people on their journey. Then they can go into the land and take it for themselves. It is the land that I promised to their ancestors that I would give to them. ’"
    },
    {
      "verse": "12",
      "text": "So, people of Israel, this is what the Lord your God wants you to do: You should respect him with fear. You should live in a way that pleases him. Love him and serve him in everything that you think and in everything that you do."
    },
    {
      "verse": "13",
      "text": "Obey the Lord's commands and rules that I am giving to you today. If you do these things, you will have a happy life."
    },
    {
      "verse": "14",
      "text": "The whole sky and the highest heavens belong to the Lord your God. The earth and everything that is in it also belong to him."
    },
    {
      "verse": "15",
      "text": "But the Lord chose to love your ancestors with a faithful love. You are their descendants. He has chosen you from among all the people of the world. You can see that this is true today!"
    },
    {
      "verse": "16",
      "text": "So remember that you belong to the Lord. Live to please him! Do not refuse to obey him."
    },
    {
      "verse": "17",
      "text": "For the Lord your God rules all other gods. He is the Lord over all other lords. He is great and powerful. We should respect him and obey him. He is fair to everyone. He will not accept any bribes!"
    },
    {
      "verse": "18",
      "text": "He brings justice to widows and to children who have no family. He loves the foreign people who live among you. He gives them food to eat and clothes to wear."
    },
    {
      "verse": "19",
      "text": "You too must love the foreign people who live among you. Remember that you also lived as foreigners in Egypt at one time."
    },
    {
      "verse": "20",
      "text": "Respect and obey the Lord your God. Serve him faithfully. If you make a promise, only use his name to do that."
    },
    {
      "verse": "21",
      "text": "He is the one that you should praise. He is the God that you worship. He has done great and powerful things to help you, and you saw him do them."
    },
    {
      "verse": "22",
      "text": "When your ancestors went to Egypt, they were only 70 people. Now the Lord your God has caused you to become very many people. You are as many as the stars in the sky!"
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "Love the Lord your God. Do what he tells you to do. Always obey his rules, his laws and his commands."
    },
    {
      "verse": "2",
      "text": "Remember that today I am speaking to you who have seen his powerful acts! Your children did not see the great things that the Lord your God did to teach you. You saw for yourselves how great, strong and powerful he is."
    },
    {
      "verse": "3",
      "text": "But your children did not see the great miracles that he did in Egypt. He punished Pharaoh, king of Egypt, and all his people."
    },
    {
      "verse": "4",
      "text": "You saw how God destroyed Egypt's army, with all their horses and chariots. They were chasing after you to catch you. But God caused the water of the Red Sea to cover them, so that they drowned."
    },
    {
      "verse": "5",
      "text": "Your children did not see all the things that the Lord did in the desert as he brought you here."
    },
    {
      "verse": "6",
      "text": "They did not see how he punished Dathan and Abiram, Eliab's sons, from Reuben's tribe. God caused the earth to open up in the middle of the Israelites' camp. These men fell down into the hole and they disappeared. Their families, their tents and everything that they had all disappeared in the hole."
    },
    {
      "verse": "7",
      "text": "Remember that I am speaking to you, the people who have seen the Lord's powerful acts."
    },
    {
      "verse": "8",
      "text": "So you must obey all the commands that I am giving to you today. If you do that, you will be able to go across the Jordan River into Canaan. You will be strong enough to take the land for yourselves and live there."
    },
    {
      "verse": "9",
      "text": "Then you will enjoy a long life in that land. It is the land that the Lord promised to give to your ancestors and to their descendants. It is a land where there is plenty of food and drink, enough for everyone."
    },
    {
      "verse": "10",
      "text": "The land that you are going into is not like the land of Egypt, where you lived before. There, when you planted seeds, you had to take water to them. It was like a garden where you grow vegetables."
    },
    {
      "verse": "11",
      "text": "But now you are going across the Jordan River into a different kind of land. It has hills and valleys. Rain falls from the sky and makes the ground wet."
    },
    {
      "verse": "12",
      "text": "The Lord your God takes care of the land there. He watches over it every day, through the whole year."
    },
    {
      "verse": "13",
      "text": "So listen carefully to the commands that I am giving to you today. Love the Lord your God and serve him in everything that you think and in everything that you do."
    },
    {
      "verse": "14",
      "text": "If you do that, he makes this promise to you: ‘I will send rain on your land at the right time each year. There will be rain in autumn and rain in spring. Then your crops will give you food. You will also have grapes to make wine and olives to make oil."
    },
    {
      "verse": "15",
      "text": "I will make grass grow in your fields for your animals to eat. You will have as much food as you want to eat. ’"
    },
    {
      "verse": "16",
      "text": "But be careful! Do not turn away from the Lord so that you worship other gods. Do not let those things deceive you."
    },
    {
      "verse": "17",
      "text": "If you do that, the Lord will be very angry with you. He will not send rain down from the sky. The land will no longer give you food to eat. Then you will soon die. You will no longer be able to live in the good land that the Lord is giving to you."
    },
    {
      "verse": "18",
      "text": "Continue to think carefully about these commands in everything that you do. Tie them as signs onto your hands so that you remember them. Also tie them around your heads."
    },
    {
      "verse": "19",
      "text": "Teach them to your children. Talk about them when you sit together at home. Talk about them as you walk along the road, when you lie down and when you get up."
    },
    {
      "verse": "20",
      "text": "Write them on the wood beside the doors of your houses and on your gates."
    },
    {
      "verse": "21",
      "text": "Do these things so that you and your descendants will live long lives in the land. It is the land that the Lord promised to give to your ancestors. You will continue to live there while there is still a sky above the earth."
    },
    {
      "verse": "22",
      "text": "Be careful to obey these commands that I am giving to you. Love the Lord your God. Live in a way that pleases him. Be faithful to him."
    },
    {
      "verse": "23",
      "text": "If you do that, the Lord will chase out all those nations as you move into the land. They are greater and stronger than you are, but you will take the land from them."
    },
    {
      "verse": "24",
      "text": "Every piece of ground that you walk on will belong to you. The borders of your land will go from the desert in the south as far as Lebanon in the north. They will go from the Euphrates river in the east to the Mediterranean Sea in the west."
    },
    {
      "verse": "25",
      "text": "Nobody will be able to stop you. The Lord your God will cause everyone in the other nations to be afraid of you. They will shake with fear. He has promised to do that, everywhere that you go in the land."
    },
    {
      "verse": "26",
      "text": "Today I am telling you to choose. Do you want God to bless you? Or do you want God to curse you?"
    },
    {
      "verse": "27",
      "text": "The Lord your God will bless you if you obey his commands that I am giving to you today."
    },
    {
      "verse": "28",
      "text": "But he will curse you if you refuse to obey his commands. If you turn away from him and you serve other gods that are new to you, he will curse you!"
    },
    {
      "verse": "29",
      "text": "When the Lord brings you into the land where you will live, do this: Speak aloud God's blessings from Mount Gerizim. Speak his curses from Mount Ebal."
    },
    {
      "verse": "30",
      "text": "You know where these mountains are. They are west of the Jordan River, in the land of the Canaanites who live in the Jordan Valley. They are near Gilgal town, where the oak trees of Moreh are."
    },
    {
      "verse": "31",
      "text": "Soon you will go across the Jordan River. You will take for yourselves the land that the Lord your God is giving to you. It will belong to you as your home."
    },
    {
      "verse": "32",
      "text": "When you are there, be careful to obey his laws and his teaching that I am giving to you today."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "These are the laws and the rules that you must obey. Be careful to obey them when you live in the land that the Lord your God has given to you. He is the God that your ancestors worshipped. Obey these laws all the time that you live in that land."
    },
    {
      "verse": "2",
      "text": "You will chase out the nations who live there. Then you must destroy completely all the places where those people worship their gods. Those places are on the tops of mountains and hills, and under big green trees."
    },
    {
      "verse": "3",
      "text": "You must break into pieces their altars and stone pillars. Burn their Asherah poles. Knock down the images of their gods. Destroy those places so that nobody remembers the false gods."
    },
    {
      "verse": "4",
      "text": "Do not worship the Lord your God in the same way that those people worship their gods."
    },
    {
      "verse": "5",
      "text": "The Lord will choose one place from the land where all your tribes live. That is the place where people must go to worship him. That is his special home."
    },
    {
      "verse": "6",
      "text": "That is where you must take your burnt offerings and other sacrifices to offer to the Lord. Take your tithes and offerings to him there. Take the gifts that you have promised to give, and the gifts that you choose to give. Take the firstborn animals from your cows, sheep and goats."
    },
    {
      "verse": "7",
      "text": "You and your families will go there to meet with the Lord your God. You will be happy as you eat together there. You will enjoy the results of all your work, because the Lord has blessed you."
    },
    {
      "verse": "8",
      "text": "At this time, all of you now do what you think is right. But when you are in the land, you must worship God in a different way."
    },
    {
      "verse": "9",
      "text": "You have not yet reached the place where you can rest. That is in the land that the Lord your God is giving to you as your home."
    },
    {
      "verse": "10",
      "text": "But when you go across the Jordan River, that land will become your home. The Lord will protect you from all the enemies who are around you. You will live safely."
    },
    {
      "verse": "11",
      "text": "At that time, the Lord your God will choose one special place for his people to worship him. You must take there everything that I have told you. Take your burnt offerings and other sacrifices to offer to the Lord. Take your tithes and special offerings. Take the special gifts that you have promised to give to him. Take everything to the place that God will choose."
    },
    {
      "verse": "12",
      "text": "Go there to enjoy time with the Lord your God. Take with you your children and your servants. Also take with you the Levites who live in your towns. Remember that they have not received any land for themselves, as you have."
    },
    {
      "verse": "13",
      "text": "So be careful! Do not offer your burnt offerings in any place that you choose for yourself."
    },
    {
      "verse": "14",
      "text": "Only make offerings to the Lord in the place that he chooses. That will be in the land that belongs to one of your tribes. It is the place where you must do all the things that I am commanding you to do."
    },
    {
      "verse": "15",
      "text": "But you may kill your animals and eat the meat in any of the towns where you live. When the Lord your God blesses you and he gives you animals, you may eat them as often as you want. It is the same as if you are eating meat from deer. Anyone may eat it. That includes people who are clean and people who are unclean."
    },
    {
      "verse": "16",
      "text": "But you must not eat the blood of any animal. You must pour it on the ground like water."
    },
    {
      "verse": "17",
      "text": "Do not eat any of your offerings to the Lord in the places where you live. Do not eat the tithes that you have taken from your grain, your new wine or your olive oil. Do not eat at home the firstborn animals from your cows, sheep or goats. Do not eat the gifts that you have promised, the gifts that you choose to give or any other special gifts."
    },
    {
      "verse": "18",
      "text": "You may only eat these offerings in the place that the Lord will choose as his special home. That is true for you, your children, your servants and the Levites who live in your towns. At that place, you should meet with the Lord your God and you should enjoy the results of all your work."
    },
    {
      "verse": "19",
      "text": "As long as you live in the land, be careful to take care of the Levites."
    },
    {
      "verse": "20",
      "text": "The Lord your God has promised to give you more and more land. When he does that, perhaps you will say, ‘I would like to eat some meat. ’ Then you may eat as much meat as you like."
    },
    {
      "verse": "21",
      "text": "The place that God chooses as his special home may be far away from you. If it is, you may kill any of the animals that the Lord has given to you. You may eat the meat at your own town, in the way that I have told you."
    },
    {
      "verse": "22",
      "text": "You should eat them in the same way that you eat deer. People who are unclean may eat them, as well as people who are clean."
    },
    {
      "verse": "23",
      "text": "But never eat the blood. The blood of an animal gives it life. You must not eat the life together with the meat!"
    },
    {
      "verse": "24",
      "text": "You must not eat the blood. You must pour it on the ground like water."
    },
    {
      "verse": "25",
      "text": "Do not eat it! Then you will be doing what the Lord says is right. You will enjoy a happy life and so will your children."
    },
    {
      "verse": "26",
      "text": "It is only the holy things that you must take to the place that the Lord will choose for himself. Those are the gifts and sacrifices that you are offering to him."
    },
    {
      "verse": "27",
      "text": "Offer the meat and the blood of your burnt offerings on the altar of the Lord your God. For the other sacrifices, you must pour out the blood beside the altar. But you may eat the meat."
    },
    {
      "verse": "28",
      "text": "Be careful to obey all these commands that I am giving to you. Then you will be doing things that the Lord your God says are good and right. You and your children will enjoy a happy life."
    },
    {
      "verse": "29",
      "text": "When you go into the land where the other nations live, the Lord your God will remove them. You will take their land and you will live on it."
    },
    {
      "verse": "30",
      "text": "But after the Lord has destroyed them, be careful! Do not do the same wrong things as they do. Do not try to worship their gods. Do not say, ‘How do the people of these nations worship their gods? I would like to do the same thing! ’"
    },
    {
      "verse": "31",
      "text": "No! You must not worship the Lord your God in the same way that those people worship their gods. When they worship, they do wicked things that the Lord hates. They even burn their children with fire, to make sacrifices to their gods."
    },
    {
      "verse": "32",
      "text": "Be careful to do everything that I am telling you. Do not add anything to these commands. Do not remove anything from them."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "One day, you may have a prophet among you who tells you what will happen in the future. He may have dreams about what will happen. He may promise to do miracles to show that he is right."
    },
    {
      "verse": "2",
      "text": "He may say that you should start to worship other gods that you did not know about before. The miracles may happen, as he promised,"
    },
    {
      "verse": "3",
      "text": "but do not listen to that prophet's message. The Lord your God is using this person to test your thoughts. He wants to know if you really love him in everything that you think and everything that you do."
    },
    {
      "verse": "4",
      "text": "You must serve only the Lord your God and respect him with fear. You must obey his commands and serve him faithfully."
    },
    {
      "verse": "5",
      "text": "You must punish that false prophet with death. He has told you to turn against the Lord your God. The Lord rescued you from Egypt, where you were slaves. But the false prophet has tried to turn you away from the way of life that the Lord your God has commanded. So you must remove all evil things like that from among you."
    },
    {
      "verse": "6",
      "text": "Even someone in your own family may try to turn you away from the Lord. It may be your own brother, your son or your daughter. It may be your wife whom you love. It may be a friend that you like very much. They may say to you secretly, ‘We should worship other gods. ’ Those are gods that you and your ancestors never knew about before."
    },
    {
      "verse": "7",
      "text": "They are gods that people who live around you may worship. They may be gods of people who live near to you. They may be gods of people who live anywhere on the earth."
    },
    {
      "verse": "8",
      "text": "But never agree with anyone who says that you should worship those gods. Do not even listen to him! Do not feel sorry for him. Do not try to protect him from punishment."
    },
    {
      "verse": "9",
      "text": "Instead, you must certainly kill him! You must be the first person to throw stones to kill him. Then everyone else must do the same thing."
    },
    {
      "verse": "10",
      "text": "You must throw stones at him until he dies. He tried to turn you away from the Lord your God. It was the Lord who rescued you from Egypt, where you were slaves."
    },
    {
      "verse": "11",
      "text": "When you punish the false prophet with death, all Israel's people will hear about it. They will be afraid. No one will do evil things like that again."
    },
    {
      "verse": "12",
      "text": "The Lord your God will give you towns to live in. When you are there, you may hear news of people who are causing trouble."
    },
    {
      "verse": "13",
      "text": "They may be turning the other people in their town away from the Lord. They may be saying, ‘We should worship other gods! ’ Those are gods that you never knew about before."
    },
    {
      "verse": "14",
      "text": "Then you must check carefully that the news is true. You must discover whether people really have done this wicked thing in one of your towns."
    },
    {
      "verse": "15",
      "text": "If the news is true, you must attack that town. You must completely destroy it. Kill all the people and the animals."
    },
    {
      "verse": "16",
      "text": "You must put all the valuable things in a heap in the town's public place. Then burn down the whole town as an offering to the Lord your God. Leave the town as a heap of stones. Nobody must ever build it again."
    },
    {
      "verse": "17",
      "text": "You must not keep any of the valuable things for yourselves. They have been given to the Lord. If you destroy the whole town, the Lord will stop being angry. He will be kind to you and he will forgive you. He will cause you to grow into a big nation, as he promised your ancestors."
    },
    {
      "verse": "18",
      "text": "The Lord your God will bless you if you listen to what he says. You must obey all his commands that I am giving you today. You must do the things that he says are right."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "You are people who belong to the Lord your God. When someone dies, you are sad. But do not cut your bodies. Do not cut off all the hair from the front of your head."
    },
    {
      "verse": "2",
      "text": "You are the Lord's own special people. He has chosen you to belong to him. You are much more valuable to him than any other people in the whole earth."
    },
    {
      "verse": "3",
      "text": "Do not eat anything that God says is unclean."
    },
    {
      "verse": "4",
      "text": "You may eat the meat of these animals: cows, sheep, goats,"
    },
    {
      "verse": "5",
      "text": "deer, wild goats, mountain goats, antelopes and wild sheep."
    },
    {
      "verse": "6",
      "text": "You may eat any animal with feet that have two separate parts. They must also bring their food back into their mouths and eat it again."
    },
    {
      "verse": "7",
      "text": "But you must not eat these animals: camels, wild rabbits and rock badgers. They eat their food a second time, but they do not have feet with two separate parts. For this reason they are unclean food for you."
    },
    {
      "verse": "8",
      "text": "You may not eat pigs, either. They have feet in two parts but they do not eat their food a second time. You must not eat any meat from these animals. You must not even touch their dead bodies."
    },
    {
      "verse": "9",
      "text": "You may eat any fish that has fins and scales."
    },
    {
      "verse": "10",
      "text": "But other things that live in the water do not have fins or scales. Those are not clean food for you. Do not eat them."
    },
    {
      "verse": "11",
      "text": "You may eat any clean bird."
    },
    {
      "verse": "12",
      "text": "But these birds you must not eat: eagles, vultures, kites, owls, hawks, falcons, buzzards, ostriches, seagulls, storks, herons, pelicans, cormorants, hoopoes and bats."
    },
    {
      "verse": "13",
      "text": "owls, hawks, falcons,"
    },
    {
      "verse": "14",
      "text": "buzzards, ostriches, seagulls,"
    },
    {
      "verse": "15",
      "text": "storks, herons, pelicans,"
    },
    {
      "verse": "16",
      "text": "cormorants, hoopoes"
    },
    {
      "verse": "17",
      "text": "and bats."
    },
    {
      "verse": "18",
      "text": "(verse included in the list above as part of the prohibited birds)"
    },
    {
      "verse": "19",
      "text": "Some insects have wings but they walk on the ground. Insects like that are unclean food for you. You must not eat them."
    },
    {
      "verse": "20",
      "text": "But you may eat any clean insect that has wings."
    },
    {
      "verse": "21",
      "text": "You must not eat anything that you find dead already. You may give it to a foreign person who lives in any of your towns. He may eat it. You may give it to him or sell it to him. But you yourselves are special people who belong to the Lord your God. You must not cook a young goat in the milk from its mother. You must not cook a young goat in the milk from its mother."
    },
    {
      "verse": "22",
      "text": "You must keep safe a tenth part of all the crops that grow in your fields. You must be careful to do this every year."
    },
    {
      "verse": "23",
      "text": "Then take your tithe to the place that the Lord your God will choose as his special home. It will be a tenth part of your grain, your new wine, your olive oil and the firstborn animals from your cows, sheep and goats. Eat them there, at the Lord's special home. Then you will learn to respect the Lord your God always."
    },
    {
      "verse": "24",
      "text": "But the Lord's special place may be a long way from your home. If he has blessed you with a lot of things, they may be too heavy for you to carry all that way."
    },
    {
      "verse": "25",
      "text": "If that is true, you may sell your tithe. Then you may take the money carefully to the place that the Lord your God will choose."
    },
    {
      "verse": "26",
      "text": "When you arrive there, you can use the money to buy any food that you choose: cows, sheep, wine, beer or anything else. Then you and your family should eat it there. You should enjoy your time together at the Lord's special home."
    },
    {
      "verse": "27",
      "text": "Do not forget to help the Levites who live in your towns. Remember that they have not received any land as you have."
    },
    {
      "verse": "28",
      "text": "Every third year, take the tithe of the food that you have grown in your fields that year. Store it in your town or your village."
    },
    {
      "verse": "29",
      "text": "Keep this food for the Levites, who have no land of their own. It is also for the foreign people, the widows, and the children who have no family. These people in your town can eat as much as they want. If you do that, the Lord your God will bless you in all your work."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "At the end of every seven years you must remove the debts of people that you have lent money to."
    },
    {
      "verse": "2",
      "text": "This is how you must do it: Every person who has lent money to someone must remove that debt. He must not demand to get his money back from any other Israelite. It is the Lord's time to remove debts."
    },
    {
      "verse": "3",
      "text": "You can demand to get your money back from a foreign person. But if you have lent money to another Israelite, you must forgive the debt."
    },
    {
      "verse": "4",
      "text": "The Lord will bless you in the land that he is giving you to live in. So there should be no poor people among you."
    },
    {
      "verse": "5",
      "text": "But you must always obey him completely. So be careful to obey all the commands that I am giving to you today."
    },
    {
      "verse": "6",
      "text": "For the Lord your God will bless you, as he has promised to do. You will lend money to the people of many other nations, but you will not borrow money from them. You will rule over many other nations, but they will not rule over you."
    },
    {
      "verse": "7",
      "text": "The Lord your God will bless you in the land that he is giving to you. But perhaps there will be a poor person among the Israelites in one of your towns. Then do not refuse to help him. Do not think only about yourself."
    },
    {
      "verse": "8",
      "text": "Instead, be generous. Lend him the money that he needs."
    },
    {
      "verse": "9",
      "text": "Be careful not to think this wicked thought: ‘The seventh year will happen soon. That is the year when I must forgive people's debts. So I will not lend money to people at this time. ’ Do not be cruel like that to another Israelite who is poor. Do not refuse to lend him anything. He might complain about you to the Lord. Then the Lord would say that you are guilty of a sin."
    },
    {
      "verse": "10",
      "text": "Instead, you should certainly lend money to him. Do not feel upset about it. If you are generous, the Lord your God will bless you in everything that you do."
    },
    {
      "verse": "11",
      "text": "There will always be some poor people among you in the land where you are going. So I command you to be generous to other Israelites who are poor. Help them with the things that they need."
    },
    {
      "verse": "12",
      "text": "You may buy another Israelite to be your servant, a man or a woman. Let that servant work for you for six years. Then in the seventh year, you must let him go free."
    },
    {
      "verse": "13",
      "text": "When you let him go, you must not send him away with nothing to take with him."
    },
    {
      "verse": "14",
      "text": "Give him gifts of sheep, grain and wine. Be generous! Give him many good things, as the Lord has blessed you with good things."
    },
    {
      "verse": "15",
      "text": "Remember that you were once slaves in Egypt. But the Lord your God rescued you from there. This is why I am giving you this command today."
    },
    {
      "verse": "16",
      "text": "But perhaps your servant will say to you, ‘I do not want to leave you! ’ He may say that because he loves you and your family. He enjoys his life with you."
    },
    {
      "verse": "17",
      "text": "If he says that, you must take a tool with a sharp point. Push it through his ear, into your door. After that, he will be your servant for his whole life. Do the same thing for any female servant who wants to stay with you."
    },
    {
      "verse": "18",
      "text": "Do not think that it will be difficult for you if he goes free. Remember that he has served you well for six years. He has been worth twice as much as a servant that you pay to do your work. The Lord your God will bless you in everything that you do."
    },
    {
      "verse": "19",
      "text": "You must keep separate every firstborn male animal that is born from your cows, sheep or goats. They belong to the Lord your God. Do not make these firstborn animals do any work for you. Do not cut off the wool from your firstborn sheep."
    },
    {
      "verse": "20",
      "text": "Each year, you and your family must take these animals to the place that the Lord your God will choose. Eat them there, at the Lord's special home."
    },
    {
      "verse": "21",
      "text": "But if a firstborn animal is not perfect, you must not offer it as a sacrifice to the Lord your God. It must not be blind or have weak legs. It must not have anything wrong with it."
    },
    {
      "verse": "22",
      "text": "You may eat animals like that at home. It is the same as if you are eating meat from deer. Anyone may eat it. That includes people who are clean and people who are unclean."
    },
    {
      "verse": "23",
      "text": "But you must not eat the animal's blood. You must pour it on the ground like water."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "The month Abib is a special month for you. In this month, you must eat a meal to remember the Passover. Remember what the Lord your God did for you. In that month, he brought you out of Egypt during the night."
    },
    {
      "verse": "2",
      "text": "You must go to the special place that the Lord will choose for his people to worship him. There you must kill one of your animals as a sacrifice to remember the Passover. You may kill one of your cows or sheep."
    },
    {
      "verse": "3",
      "text": "At this feast, eat bread that you make without any yeast. For seven days, you must eat bread that you make without yeast. You ate that kind of bread when you had much trouble in Egypt. You had to leave Egypt in a hurry that night. You must eat that bread each year. Then you will always remember the day when you left Egypt."
    },
    {
      "verse": "4",
      "text": "During those seven days, no one may keep any yeast in their house. There must not be any yeast in the whole land. On the first day, you will kill your animal to eat in the evening. You must eat all the meat that same night, so that there is no meat left in the morning."
    },
    {
      "verse": "5",
      "text": "You must not kill the animal for the Passover sacrifice in any of the towns that the Lord your God gives to you."
    },
    {
      "verse": "6",
      "text": "You must go to the place that he will choose as his special home. You must kill the animal there, at sunset. That was the time of day when you came out of Egypt."
    },
    {
      "verse": "7",
      "text": "Cook the meat and eat it in the place that the Lord your God will choose. The next morning, you may return to your tents."
    },
    {
      "verse": "8",
      "text": "For the next six days, you must eat bread that you make without yeast. On the seventh day, you must all come together to worship the Lord your God. You must not do any work on that day."
    },
    {
      "verse": "9",
      "text": "Count seven weeks from the first day that you bring in crops of grain from your fields."
    },
    {
      "verse": "10",
      "text": "Then eat the Feast of Weeks to worship the Lord your God. Bring the gifts that you want to offer to him. Bring gifts that show how much he has blessed you."
    },
    {
      "verse": "11",
      "text": "You and your family will be happy to worship the Lord your God, at the special place that he chooses. Enjoy time together with your children, your servants and the Levites who live in your town. Also join with the foreign people who live among you, with widows, and children who have no family. Worship God happily together."
    },
    {
      "verse": "12",
      "text": "Remember that you were once slaves in Egypt. So be careful to obey these commands."
    },
    {
      "verse": "13",
      "text": "When you have prepared the grain and the grapes from your fields, eat the Feast of Huts for seven days."
    },
    {
      "verse": "14",
      "text": "Enjoy your feast with your children, your servants and the Levites. Join with the foreign people who live among you, and also with the widows and the children who have no family."
    },
    {
      "verse": "15",
      "text": "Eat this feast to worship the Lord your God at the special place that he chooses. Do it for seven days. He will bless you in everything that you do, so that you grow plenty of food. So you should all enjoy this feast!"
    },
    {
      "verse": "16",
      "text": "Three times in every year, all your men must go to the place that the Lord your God will choose. They must go there for the Passover festival, the festival of Weeks and the festival of Huts. Each man must bring with him gifts to offer to the Lord."
    },
    {
      "verse": "17",
      "text": "Give to the Lord as much as you are able to. Your gifts may be large or small, as much as the Lord has blessed you."
    },
    {
      "verse": "18",
      "text": "Each tribe must choose judges and officers in every town that the Lord gives you. They must judge the people in a way that is fair."
    },
    {
      "verse": "19",
      "text": "Judges must do what is right for every person, rich or poor. They must not accept any bribes. A bribe may hide the truth even from a wise man. It can make honest people tell lies."
    },
    {
      "verse": "20",
      "text": "Make sure that there is justice for everyone in the land that the Lord your God is giving to you. Then the land will belong to you and you will enjoy life in it."
    },
    {
      "verse": "21",
      "text": "When you build an altar to offer sacrifices to the Lord your God, do not put any Asherah pole there."
    },
    {
      "verse": "22",
      "text": "Do not put up any stone pillar as an idol. The Lord your God hates everything like that."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "When you offer an animal as a sacrifice to the Lord your God, it must be perfect. Do not bring any sheep or bull that has something wrong with it. The Lord hates any gift like that."
    },
    {
      "verse": "2",
      "text": "The Lord your God will give you towns to live in. You may hear that a man or a woman who lives in one of your towns has done a bad thing. He has done a sin that is against the covenant of the Lord your God."
    },
    {
      "verse": "3",
      "text": "He may have started to worship false gods that I have commanded you not to worship. Perhaps he worships the sun, the moon or the stars."
    },
    {
      "verse": "4",
      "text": "If you hear news like that, you must check the report carefully. If it is true that a wicked thing like that has happened in Israel,"
    },
    {
      "verse": "5",
      "text": "you must punish that person. Take the man or woman who has done that wicked thing to the gate of the town. Then you must throw stones at that person to kill them."
    },
    {
      "verse": "6",
      "text": "But two or three people must agree about what the person has done. You must never kill anyone because of the words of only one person."
    },
    {
      "verse": "7",
      "text": "The people who saw the wicked act must throw the first stones to kill the person. Then everyone else must also throw stones. In that way, you must remove evil acts from among you."
    },
    {
      "verse": "8",
      "text": "It may be difficult for the judges in your towns to decide what is true. This may happen when one person has attacked or killed another person. It may happen when people cannot agree about some land. It may be anything that people in your towns are arguing about. If you do not know who is right, you must take those people to the place that the Lord your God will choose."
    },
    {
      "verse": "9",
      "text": "You must go to the Levite priests and to the judge who has authority at that time. Ask them to decide what is right and true."
    },
    {
      "verse": "10",
      "text": "When they decide, you must do what they tell you to do."
    },
    {
      "verse": "11",
      "text": "Accept their teaching. Agree with what they have decided is right. Obey their words completely. Do not try to do anything that is different."
    },
    {
      "verse": "12",
      "text": "Someone might be too proud to obey the priest who has authority as the Lord's servant. He may not agree with what the judge says is right. You must punish any proud person like that with death. In that way you will remove evil things from Israel."
    },
    {
      "verse": "13",
      "text": "Then all the people will hear what has happened. They will be afraid. They will no longer be too proud to obey the judge."
    },
    {
      "verse": "14",
      "text": "You are going into the land that the Lord your God is giving to you. You will take it for yourselves to be your home. Then you may say, ‘The other nations around us have kings. We must also have a king to rule us. ’"
    },
    {
      "verse": "15",
      "text": "If that happens, you must only accept a king that the Lord your God chooses. Choose a king from among your own people. Do not choose anyone who is not an Israelite."
    },
    {
      "verse": "16",
      "text": "A king must not get a lot of horses for himself. He must not send his people back to Egypt to buy more horses. The Lord has said to you, ‘Never return to Egypt for any reason! ’"
    },
    {
      "verse": "17",
      "text": "A king must not marry many wives. They may turn his thoughts away from the Lord. He must not store a lot of silver and gold for himself."
    },
    {
      "verse": "18",
      "text": "When anyone starts to rule as king, he must copy this Law of God on a scroll. The scroll will be a copy of the one that belongs to the Levite priests."
    },
    {
      "verse": "19",
      "text": "He must keep this scroll with him all the time. He must continue to read it every day of his life. If he does that, he will learn to respect the Lord his God. He will learn to obey all the rules and commands of this Law."
    },
    {
      "verse": "20",
      "text": "If he does that, he will not become proud. He will not think that he is better than other Israelites. He will continue to obey the Lord's commands. Then he and his descendants will rule Israel as kings for many years."
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "The priests and the whole tribe of Levi will have no land for themselves, as the other Israelite tribes do. Instead, they may eat the meat from the sacrifices that belong to the Lord."
    },
    {
      "verse": "2",
      "text": "They will receive no land among the other Israelites. The Lord himself is the one who gives them everything that they need. He has promised to do that for them."
    },
    {
      "verse": "3",
      "text": "When you bring a bull or a sheep as a sacrifice to the Lord, give the priests their part. You must give them the animal's shoulder, the meat from its face, and its stomach."
    },
    {
      "verse": "4",
      "text": "You must also give them the first part of your grain, your wine and your olive oil. Give them the first wool that you cut from your sheep."
    },
    {
      "verse": "5",
      "text": "Do this because the Lord your God has chosen the Levites to serve him from among all your tribes. He wants them and their descendants to be ready to serve him at all times, for ever."
    },
    {
      "verse": "6",
      "text": "Any Levite may choose to go to the place that the Lord will choose. He can leave the town where he lives, wherever it is in Israel."
    },
    {
      "verse": "7",
      "text": "He may go to serve the Lord his God. He may join the other Levites who are ready to serve the Lord at his special place."
    },
    {
      "verse": "8",
      "text": "A Levite may have sold some of his family's valuable things. He may keep that money and he may receive the same amount of food as the other Levites."
    },
    {
      "verse": "9",
      "text": "When you go into the land that the Lord your God is giving you, be careful! Do not learn to do the evil things that the nations who live there are doing."
    },
    {
      "verse": "10",
      "text": "Nobody among you must ever burn your child in a fire, as an offering. Nobody must use magic or other things to learn about future times. There must not be any magicians or diviners."
    },
    {
      "verse": "11",
      "text": "Never use magic to curse anyone. Never try to speak to the spirits of dead people or other spirits."
    },
    {
      "verse": "12",
      "text": "The Lord hates anyone who does these things. It is because of those evil things that the Lord will chase the other nations out of the land as you move in."
    },
    {
      "verse": "13",
      "text": "You must live in a completely right way that pleases the Lord your God."
    },
    {
      "verse": "14",
      "text": "The people of the nations that you will chase away get help from magicians and diviners. But the Lord your God has commanded you not to do those things."
    },
    {
      "verse": "15",
      "text": "One day, the Lord your God will send to you a prophet like me. He will come from among your own people. You must listen to him."
    },
    {
      "verse": "16",
      "text": "Remember what happened when you all met together at Sinai mountain. You said to the Lord your God, ‘Please do not let us hear your voice again. Do not let us see this great fire again. If we do, we will die! ’"
    },
    {
      "verse": "17",
      "text": "Then the Lord said to me, ‘The people have said the right thing."
    },
    {
      "verse": "18",
      "text": "I will send them a prophet who will be like you. He will be an Israelite. I will tell him what to say. Then he will tell the people everything that I command him to say."
    },
    {
      "verse": "19",
      "text": "He will speak on my behalf, so I myself will punish anyone who does not listen to his message."
    },
    {
      "verse": "20",
      "text": "A false prophet may say that he speaks with my authority when that is not true. Or he may say that he has a message from another god. You must punish a false prophet with death. ’"
    },
    {
      "verse": "21",
      "text": "You may say to yourselves, ‘How can we know when a message has not come from the Lord? ’"
    },
    {
      "verse": "22",
      "text": "A prophet may say that he speaks with my authority, and he may say what will happen. But if it does not happen, you will know that his message has not come from me. He has not spoken my message. That prophet has spoken his own ideas. So do not be afraid of him!"
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "The Lord your God will destroy the nations who now live in the land that he is giving to you. You will chase them out and you will live in their cities and in their houses."
    },
    {
      "verse": "4",
      "text": "This is the rule when anyone has killed another person: If it was a mistake, he can run to a safe city. He can do that if he has killed someone that he did not already hate."
    },
    {
      "verse": "5",
      "text": "For example, two men may go to the forest to cut wood. As one man cuts wood with his axe, the metal part of the axe flies off. It hits the other man and it kills him. Then the killer can run to the nearest of the three cities. He will be safe there."
    },
    {
      "verse": "6",
      "text": "If there was no safe city near enough, the killer might not escape safely. The dead person's relative might chase him, catch him and kill him. But the killer did not deserve to die. He had made a mistake. He had killed someone that he did not already hate."
    },
    {
      "verse": "7",
      "text": "So I command you to choose three cities to be safe cities for yourselves."
    },
    {
      "verse": "8",
      "text": "The Lord your God promised your ancestors to give you more land to live in. When all that land belongs to you,"
    },
    {
      "verse": "9",
      "text": "you must continue to obey all the commands that I am giving you today. You must continue to love the Lord your God and live in a way that pleases him. Then, when your land becomes bigger, you must choose three more cities to be safe cities."
    },
    {
      "verse": "10",
      "text": "You must not punish with death people who are not guilty. That would make you guilty yourselves. That must not happen in the land that the Lord your God is giving you."
    },
    {
      "verse": "11",
      "text": "But perhaps somebody does hate another person. He may hide himself so that he can catch his enemy. Then he may attack him and kill him. After that, he may run to one of the safe cities."
    },
    {
      "verse": "12",
      "text": "If he does that, the leaders of his own town must fetch him back. They must bring him to the dead person's relative. He must die as his punishment."
    },
    {
      "verse": "13",
      "text": "Do not be sorry for him. You must punish murderers with death. Then Israel will not be guilty of evil acts. If you do that, everything will be well for you."
    },
    {
      "verse": "14",
      "text": "When you go to live in the land that the Lord your God is giving to you, each family will receive their piece of land. You must never move the stones that show the edge of your neighbour's land. It has always belonged to them."
    },
    {
      "verse": "15",
      "text": "If only one person says that he has seen someone do something wrong, that is not enough. There must be at least two or three people who saw the sin. Then the judge may say that the person is guilty."
    },
    {
      "verse": "16",
      "text": "Somebody may accuse another person because he wants to hurt him. He tells lies against him."
    },
    {
      "verse": "17",
      "text": "Then both of them must stand in front of the judges that the Lord has chosen. Those are the priests and the judges who have authority at that time."
    },
    {
      "verse": "18",
      "text": "The judges must be careful to discover who is telling the truth. The person may be speaking lies against another Israelite to accuse him."
    },
    {
      "verse": "19",
      "text": "If he is telling lies, you must punish him in the same way that he wanted to punish the other Israelite. You must remove evil things like this from among yourselves."
    },
    {
      "verse": "20",
      "text": "Then everyone else will hear what has happened. They will be afraid to do any more evil things like that."
    },
    {
      "verse": "21",
      "text": "Do not be sorry for people who are guilty. Punish people as they deserve: a life for a life, an eye for an eye, a tooth for a tooth, a hand for a hand, a foot for a foot."
    },
    {
      "verse": "2",
      "text": "Make the land into three separate regions. Then choose three special cities, one city in each region."
    },
    {
      "verse": "3",
      "text": "Build good roads to each city so that people can easily travel to them. Then anyone who kills a person can run to one of these cities to be safe."
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "Do not be afraid when you go out to fight a war against your enemies. You may see that their armies have more horses, chariots and soldiers than you have. Do not be afraid of them! Remember that the Lord your God is with you. He rescued you from Egypt."
    },
    {
      "verse": "2",
      "text": "As you prepare to fight a battle, the priest must come to speak to your soldiers."
    },
    {
      "verse": "3",
      "text": "He must say, ‘Israelites, listen to me! Today you will fight against your enemies. Do not be afraid. Be brave! Do not shake with fear because your enemy is so strong."
    },
    {
      "verse": "4",
      "text": "The Lord your God is going into battle with you. He will fight for you against your enemies. He will cause you to win. ’"
    },
    {
      "verse": "5",
      "text": "Then the officers must say to the soldiers, ‘Has any of you built a new house but he has not yet asked God to bless it? If so, he may go home. If he does not, he may die in the battle. Then someone else will ask God to bless his home."
    },
    {
      "verse": "6",
      "text": "Has anyone planted a field with grapes but he has not yet picked any fruit? He also may go home. If he does not, he may die in the battle. Then someone else will enjoy the fruit."
    },
    {
      "verse": "7",
      "text": "Has anyone promised to marry a woman? If he has not married her yet, he may go home too. If not, he may die in the battle. Then another man will marry her. ’"
    },
    {
      "verse": "8",
      "text": "Then the officers must also say to the soldiers, ‘Is any of you afraid? Does anyone not feel brave? He may go home. Then he will not cause other men to be afraid like him. ’"
    },
    {
      "verse": "9",
      "text": "When the officers have finished speaking to the army, they must choose other officers to lead the groups of soldiers."
    },
    {
      "verse": "10",
      "text": "Before you start to attack a city, you must offer peace to the people who live there. Tell them what they must do to stop you attacking them."
    },
    {
      "verse": "11",
      "text": "If they agree, they will open the city's gates to let you go in. Then all the people in the city will become your slaves, to do hard work for you."
    },
    {
      "verse": "12",
      "text": "But they may refuse to agree. They may start to fight against you. If they do that, you must put your soldiers all around the city."
    },
    {
      "verse": "13",
      "text": "The Lord your God will give the city to you. Then you must kill all the men there."
    },
    {
      "verse": "14",
      "text": "But you can take for yourselves the women, the children, the animals and other valuable things in the city. You can take all these things from your enemies that God gives to you."
    },
    {
      "verse": "15",
      "text": "You must do this to all the cities that are far away from you. But it is different for the cities that belong to the nations of Canaan where you will live."
    },
    {
      "verse": "16",
      "text": "You will take for yourselves the cities in the land that the Lord your God is giving to you as your home. In those cities, you must kill everything that is alive, people and animals."
    },
    {
      "verse": "17",
      "text": "You must completely destroy all the Hittites, the Amorites, the Canaanites, the Perizzites, the Hivites and the Jebusites. The Lord your God has commanded you to do this to the people of those nations."
    },
    {
      "verse": "18",
      "text": "If not, they would teach you all the evil things that they do to worship their gods. They would cause you to do bad things against the Lord your God."
    },
    {
      "verse": "19",
      "text": "Perhaps you are preparing to attack a city. Your soldiers may have their camp around the city for a long time. If so, you must not cut down the fruit trees. Then you can eat the fruit from them. These trees are not people, like your enemies! So do not attack them!"
    },
    {
      "verse": "20",
      "text": "But you can cut down the other trees that do not provide any food. You can use the wood to make things that will help you to attack the city. You can do this until you go into the city and you take it for yourselves."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "In the land that the Lord your God is giving to you, you may find someone's dead body lying in a field. Someone has killed him but you do not know who the murderer is."
    },
    {
      "verse": "2",
      "text": "Your leaders and your judges must then go to the field. They must measure how far the place is from the nearest towns."
    },
    {
      "verse": "3",
      "text": "Then the leaders from the town that is nearest to the body must take a young cow that has never done work on a farm."
    },
    {
      "verse": "4",
      "text": "They must lead the cow down to a valley where no one has ploughed the ground or planted seed. There must be a stream of water in the valley. There they must break the cow's neck."
    },
    {
      "verse": "5",
      "text": "The Levite priests must go there too. The Lord your God has chosen them to serve him and to ask him to bless his people. They also decide as judges what is right."
    },
    {
      "verse": "6",
      "text": "After the leaders of the town have broken the cow's neck, they must wash their hands over it."
    },
    {
      "verse": "7",
      "text": "Then they will say, ‘We did not kill this person. We did not see who killed him."
    },
    {
      "verse": "8",
      "text": "Please Lord, accept this animal from your people, Israel, that you have rescued. Do not say that we are guilty of this murder. This person did not deserve to die like this. ’When they do that, the Lord will accept their gift and he will forgive you."
    },
    {
      "verse": "9",
      "text": "In this way, you will not be guilty of the murder. You will remove this evil act from among you. You must do what the Lord says is right."
    },
    {
      "verse": "10",
      "text": "When you go to fight a battle against your enemies, the Lord your God will give you power over them. You will take some of them as prisoners."
    },
    {
      "verse": "11",
      "text": "You may see among them a beautiful woman that you want to take as your wife."
    },
    {
      "verse": "12",
      "text": "Then you must bring her into your home. She must cut the hair off her head. She must cut her fingernails."
    },
    {
      "verse": "13",
      "text": "She must change the clothes that she was wearing when you found her. Let her live in your house and weep for her parents for a whole month. Then you may have sex with her. You will be her husband and she will be your wife."
    },
    {
      "verse": "14",
      "text": "Later, you may not be pleased with her. If so, you must let her go wherever she wants. You must never sell her or make her become a slave. You must not do that, because you have made her have sex with you, as your wife."
    },
    {
      "verse": "15",
      "text": "A man may have two wives, but he may love only one of them. Each wife may give birth to a son. The firstborn son may be the son of the wife that he does not love."
    },
    {
      "verse": "16",
      "text": "But when the man shares his things with his children, he must promise this: After his death, the firstborn son will receive what he should have. The man may not choose to give the double share of his things to the son of the wife that he loves."
    },
    {
      "verse": "17",
      "text": "He must recognize that his firstborn son is the son of the wife that he does not love. This son was the first son born to that man. So he must receive the double share of his father's things. That is what God's Law says must happen."
    },
    {
      "verse": "18",
      "text": "Perhaps a man has a son who refuses to obey his parents. They punish him to teach him what is right, but he refuses to listen to them."
    },
    {
      "verse": "19",
      "text": "If so, his parents must take their son to the leaders at the city gate."
    },
    {
      "verse": "20",
      "text": "They must say to the leaders, ‘This is our son. He refuses to obey us. He does not do what we tell him. He only wants to do what will please himself. He drinks too much and he becomes drunk. ’"
    },
    {
      "verse": "21",
      "text": "Then all the men of the city must throw stones at the son until he is dead. In this way, you must remove all evil things like that from among you. Then all Israel's people will hear about what has happened. They will be afraid."
    },
    {
      "verse": "22",
      "text": "A person may do an evil thing so that you punish him with death. If you have hung his dead body on a tree,"
    },
    {
      "verse": "23",
      "text": "you must not leave it there during the night. Be careful to bury it on the same day that he died. If someone's body is hanging on a tree, it shows that God has cursed him. So do not leave it there. The Lord your God is giving the land to you so that it belongs to you. So do not let evil things spoil your land."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "You may see your neighbour's cow or sheep that has become lost. If so, do not look the other way. You must catch the animal. You must take it back to your neighbour."
    },
    {
      "verse": "2",
      "text": "Perhaps the man does not live near you. Perhaps you do not know who the animal belongs to. If so, take the animal to your own home and keep it safe there. When the man comes to look for his animal, give it to him."
    },
    {
      "verse": "3",
      "text": "You must do the same thing if you find someone's donkey or clothes or anything else. You must not refuse to help."
    },
    {
      "verse": "4",
      "text": "Perhaps your neighbour's donkey or his cow has fallen on the road. If you see it lying there, do not look the other way. You must help the man to lift the animal so that it can stand."
    },
    {
      "verse": "5",
      "text": "A woman must not wear the same clothes that men wear. A man must not wear clothes that make him look like a woman. The Lord your God hates people who do this."
    },
    {
      "verse": "6",
      "text": "You may find a bird's nest beside the road. It may be in a tree or on the ground. If the mother bird is sitting on eggs or on young birds, you must not take the mother away from them."
    },
    {
      "verse": "7",
      "text": "You may take the young birds for yourself. But you must let the mother bird go free. If you do that, everything will be well with you. You will have a long life."
    },
    {
      "verse": "8",
      "text": "If you build a new house, you must make a wall around the edge of the flat roof. Then if someone falls off the roof and dies, you will not be guilty for his death."
    },
    {
      "verse": "9",
      "text": "You must not plant any other crops between the vines in your vineyard. If you do that, none of the food or the grapes will belong to you."
    },
    {
      "verse": "10",
      "text": "You must not tie an ox and a donkey together to pull a plough."
    },
    {
      "verse": "11",
      "text": "You must not mix wool and linen together to make your clothes."
    },
    {
      "verse": "12",
      "text": "You must fix tassels on the four corners of your coat."
    },
    {
      "verse": "13",
      "text": "Perhaps a man will marry a woman, and he has sex with her. Later he decides he no longer wants her to be his wife."
    },
    {
      "verse": "14",
      "text": "He may then tell lies against her to say that she is bad. He may say, ‘I married this woman, and I had sex with her. Then I discovered that she had already had sex before I married her. ’"
    },
    {
      "verse": "15",
      "text": "If that happens, the woman's parents must bring the cloth that she slept on with her husband. They must take it to the leaders of the town to show them."
    },
    {
      "verse": "16",
      "text": "The woman's father must say to the leaders, ‘I gave my daughter to this man to be his wife. But now he does not like her."
    },
    {
      "verse": "17",
      "text": "He accuses her that she is bad. He says, “I discovered that your daughter had sex before I married her. ” But look at her cloth. This shows that she had never had sex before. ’ Then her parents must hold the cloth in front of the leaders of the town."
    },
    {
      "verse": "18",
      "text": "The leaders must then take hold of the man. They must punish him."
    },
    {
      "verse": "19",
      "text": "pieces of silver to the young woman's father. The man has told lies. He has accused a pure Israelite girl to say that she is bad. After that, she will continue to be his wife. He may never send her away as long as he lives."
    },
    {
      "verse": "20",
      "text": "But perhaps the husband has spoken the truth. Perhaps his new wife cannot show that she had not had sex before."
    },
    {
      "verse": "21",
      "text": "If so, the leaders must take her to the entrance of her father's house. The men of the town must throw stones at her there, until she dies. She has done a very bad thing that brings shame on Israel. She has had sex like a prostitute while she lived in her father's house. You must remove evil acts like this from among you."
    },
    {
      "verse": "22",
      "text": "You may discover a man who is having sex with another man's wife. If so, you must punish both the man and the woman with death. In this way, you will remove such evil acts from Israel."
    },
    {
      "verse": "23",
      "text": "Perhaps a man may meet a young woman in a town. She has already promised to marry another man, but the man has sex with her."
    },
    {
      "verse": "24",
      "text": "If so, you must take both of them to the gate of that town. You must throw stones at both of them there, until they die. The young woman is guilty because she did not shout aloud for help. They were in the town, so someone would have heard her. The man is guilty because he had sex with the future wife of another man. In this way, you will remove evil acts from among you."
    },
    {
      "verse": "25",
      "text": "But perhaps a man may meet a young woman in a field in the country. She has already promised to marry another man. But the man is stronger than her and he has sex with her. If that happens, only the man must die."
    },
    {
      "verse": "26",
      "text": "Do not punish the young woman. She does not deserve to die. The man's act is like a man who attacks and murders another person."
    },
    {
      "verse": "27",
      "text": "The man met the young woman in a field. When she shouted for help, nobody heard her because it happened in the country. There was no one there to rescue her."
    },
    {
      "verse": "28",
      "text": "Perhaps a man may meet a girl who has not had sex with anyone before. She has not yet promised to marry anyone. The man may be too strong and he has sex with her."
    },
    {
      "verse": "29",
      "text": "If that happens, the man must pay 50 pieces of silver to the girl's father. He must also marry the girl because he has had sex with her. He may never send her away as long as he lives."
    },
    {
      "verse": "30",
      "text": "A man must not marry a woman who was his father's wife. That would bring shame on his father."
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "Perhaps a man has sex parts that someone has destroyed or spoiled. That man cannot join with the Lord's people when they meet together."
    },
    {
      "verse": "2",
      "text": "If someone was born when his parents were not properly married, he cannot join with the Lord's people. His descendants may not meet with the Lord's people to worship the Lord either. That will continue to the tenth generation of the man's descendants."
    },
    {
      "verse": "3",
      "text": "Ammonite and Moabite people also cannot join with the Lord's people when they come together to worship him. Even the tenth generation of their descendants can never do this."
    },
    {
      "verse": "4",
      "text": "The people of those nations refused to help you when you were leaving Egypt. They did not give you food or water. Also, they paid Beor's son Balaam to curse you. He came from Pethor in Mesopotamia."
    },
    {
      "verse": "5",
      "text": "But the Lord your God refused to listen to Balaam. He refused to curse you. Instead, he blessed you. The Lord your God did that because he loves you."
    },
    {
      "verse": "6",
      "text": "You must never do anything to help these two nations. Do not let them live in peace."
    },
    {
      "verse": "7",
      "text": "But do not hate anyone from Edom. The Edomites have the same ancestor as you. Do not hate an Egyptian person. You once lived as foreigners in Egypt."
    },
    {
      "verse": "8",
      "text": "The third generation of their descendants can join with the Lord's people when they meet together to worship him."
    },
    {
      "verse": "9",
      "text": "Your soldiers may be living in tents while they fight against your enemies. They must keep away from anything that makes them unclean."
    },
    {
      "verse": "10",
      "text": "While a man is asleep, semen may come from his sex part. That makes him unclean so he must go outside the camp. He must stay there all day."
    },
    {
      "verse": "11",
      "text": "In the evening, he must wash himself. At sunset he can return into the camp."
    },
    {
      "verse": "12",
      "text": "You must choose a special place outside the camp. Use that place as your toilet."
    },
    {
      "verse": "13",
      "text": "Always carry a small spade with your other tools. When you go to the toilet, dig a hole with your spade. Then bury your dung in it and cover it with earth."
    },
    {
      "verse": "14",
      "text": "For the Lord your God moves among you in your camp. He keeps you safe from your enemies so that you win against them. So make sure that your camp is a holy place. The Lord must not see anything that would bring shame on you. Do not make him turn away from you."
    },
    {
      "verse": "15",
      "text": "Someone's slave may escape from his master and come to you. If that happens, do not send him back to his master."
    },
    {
      "verse": "16",
      "text": "He can live anywhere among you. He may choose to live in any of your towns that he likes. Do not be cruel to him."
    },
    {
      "verse": "17",
      "text": "No Israelite man or woman must ever become a prostitute at places where people worship their gods."
    },
    {
      "verse": "18",
      "text": "You must not bring the money that people pay to these prostitutes into the Lord's temple. Do not use it to offer a gift that you have promised to the Lord your God. He hates prostitutes, both men and women."
    },
    {
      "verse": "19",
      "text": "You may lend money or food or anything else to another Israelite. But do not ask him to give you back more than you lent to him."
    },
    {
      "verse": "20",
      "text": "You can ask a foreign person to pay back more, but not an Israelite. If you obey this command, the Lord your God will bless you. When you live in your new land, God will bless everything that you do."
    },
    {
      "verse": "21",
      "text": "If you promise to give something to the Lord your God, be careful to bring your gift soon. If you do not bring it, that is a sin. The Lord will certainly demand it from you."
    },
    {
      "verse": "22",
      "text": "You may choose not to promise any gift. That is not a sin."
    },
    {
      "verse": "23",
      "text": "But whatever you promise to do, you must be careful to do it. If you choose to promise a gift to the Lord your God, give it soon."
    },
    {
      "verse": "24",
      "text": "If you go into your neighbour's vineyard, you may eat some of the grapes. You may eat as many grapes as you want, but do not carry any away in a basket."
    },
    {
      "verse": "25",
      "text": "If you go into your neighbour's field of grain, you may eat some of it. You may pick some grain with your hands, but do not use a knife to cut it down."
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "Perhaps a man will marry a woman and then he discovers something that brings shame on her. So she does not please him any more. He must write a letter to say that they are no longer married. He gives the letter to his wife. Then he can send her away from his house."
    },
    {
      "verse": "2",
      "text": "After she has left his house, she might marry another man."
    },
    {
      "verse": "3",
      "text": "Later, her second husband may also not like her any more. So he also gives her a letter to finish the marriage. He sends her away from his house too. Or perhaps her second husband dies."
    },
    {
      "verse": "4",
      "text": "If that happens, her first husband must not marry her again. That is because she has had sex with another man. To marry her again would be a sin that the Lord hates. You must not do sins like that in the land that the Lord your God is giving to you as your new home."
    },
    {
      "verse": "5",
      "text": "When a man has just married, do not send him away to fight in the army. Do not make him work at jobs in other places. He should stay at home for one year. Then he can make his new wife very happy."
    },
    {
      "verse": "6",
      "text": "When you lend money to people, you may take something from them as a guarantee. But do not take the stones that they use to make grain into flour. Do not take either of the stones. People need both those stones to make food to stay alive. So do not take away their life."
    },
    {
      "verse": "7",
      "text": "A man might take hold of another Israelite and make him his slave. He might try to sell him as a slave. Anyone who does that must die. You must remove evil things from among you."
    },
    {
      "verse": "8",
      "text": "If you have leprosy, be very careful! Do everything that the Levite priests tell you to do. You must obey everything that I have commanded them."
    },
    {
      "verse": "9",
      "text": "Remember what the Lord your God did to Miriam after you left Egypt."
    },
    {
      "verse": "10",
      "text": "If you lend something to your neighbour you may take something from him as a guarantee. But do not go into his house to take it."
    },
    {
      "verse": "11",
      "text": "You must wait outside the house. Then your neighbour can bring out what he has chosen to give you."
    },
    {
      "verse": "12",
      "text": "If the person is poor, do not take his coat and keep it with you all night."
    },
    {
      "verse": "13",
      "text": "You must always give his coat back to him before sunset. Then he can sleep in it to keep himself warm. He will ask God to bless you because you have been kind. The Lord your God will know that you have done the right thing."
    },
    {
      "verse": "14",
      "text": "Do not be cruel to any poor or helpless person who works for you. Be kind to him, whether he is an Israelite or a foreigner who lives in one of your towns."
    },
    {
      "verse": "15",
      "text": "You must pay him for his work every day before sunset. Remember that he is poor. He needs the money to stay alive. If you do not pay him, he may complain against you to the Lord. The Lord would say that you are guilty of a sin."
    },
    {
      "verse": "16",
      "text": "You must not punish fathers with death for the sins that their children do. You must not punish children with death for the sins that their fathers do. Each person must die only because of his own sins."
    },
    {
      "verse": "17",
      "text": "Remember to be completely fair to foreigners and to children who have no family. If you lend money to a widow, do not take her coat as a guarantee."
    },
    {
      "verse": "18",
      "text": "Remember that you were slaves in Egypt and the Lord your God rescued you from there. That is why I am commanding you to do these things."
    },
    {
      "verse": "19",
      "text": "At harvest time, you might forget to bring in all the crops from your fields. Do not go back to pick up all the grain. Leave it there for foreigners, widows and children who have no family. If you do that, the Lord your God will bless you in all your work."
    },
    {
      "verse": "20",
      "text": "When you knock the olives off your trees, shake each branch only once. Leave the olives that remain for foreigners, widows and children who have no family."
    },
    {
      "verse": "21",
      "text": "When you pick your grapes, pick only once from each vine. Leave the grapes that remain for foreigners, widows and children who have no family."
    },
    {
      "verse": "22",
      "text": "Remember that you were slaves in Egypt. That is why I am commanding you to do all these things."
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "When there is an argument between two people, they must both go to the judges. Then the judges will decide which of the two people is right. They will decide the punishment for the guilty person."
    },
    {
      "verse": "2",
      "text": "The judge may decide that his officers should beat the guilty person as punishment. The judge will make him lie down on the ground. Then he will watch as his officers beat the guilty person. They will hit him as many times as he deserves because of his wicked act."
    },
    {
      "verse": "3",
      "text": "times as his punishment. If it is more than that, nobody would respect him any more."
    },
    {
      "verse": "4",
      "text": "Do not tie shut the mouth of your ox while it walks on your grain to prepare it for you."
    },
    {
      "verse": "5",
      "text": "Perhaps two brothers live together in the same place. One of the brothers may die before he has any son. If that happens, his widow must not marry anyone who does not belong to the family. Instead, the other brother must marry her. That is the right thing for him to do for his dead brother."
    },
    {
      "verse": "6",
      "text": "The first son that the widow gives birth to will be the son of her first husband. His family's name will not disappear from Israel."
    },
    {
      "verse": "7",
      "text": "But the man may not want to marry his brother's widow. If so, this is what the widow must do: She must go to the leaders when they meet at the town gate. She must say, ‘My dead husband's brother refuses to do his duty for me. He does not want his brother to have any descendants so that his family's name will continue. ’"
    },
    {
      "verse": "8",
      "text": "Then the town's leaders must call the man to come to them. They must talk to him. Perhaps he will continue to say, ‘I do not want to marry her! ’"
    },
    {
      "verse": "9",
      "text": "If that happens, his brother's widow must go near him, as the leaders watch. She must pull off one of his shoes and then she must spit in his face. She must say, ‘This is what we do to a man who will not give descendants to his dead brother! ’"
    },
    {
      "verse": "10",
      "text": "After that, people will call that man's family, ‘the family of the man who lost his shoe. ’"
    },
    {
      "verse": "11",
      "text": "Perhaps two men are fighting each other. The wife of one of them comes to help him. She tries to save him from his enemy who is attacking him. Perhaps she takes hold of the man's sex parts."
    },
    {
      "verse": "12",
      "text": "If she does that, you must cut off her hand as punishment. Do not be sorry for her."
    },
    {
      "verse": "13",
      "text": "Do not try to cheat people when you weigh or measure things. Do not carry with you two different stone weights, one light one and one heavy one."
    },
    {
      "verse": "14",
      "text": "Do not keep in your house two different bowls to measure things, one big one and one small one."
    },
    {
      "verse": "15",
      "text": "You must keep true and honest weights. You must have bowls that measure things correctly. If you do that you will live for a long time in the land that the Lord your God is giving to you."
    },
    {
      "verse": "16",
      "text": "The Lord your God hates anyone who cheats other people and is not honest."
    },
    {
      "verse": "17",
      "text": "Remember what the Amalekites did to you when you came out of Egypt."
    },
    {
      "verse": "18",
      "text": "They attacked you when you were tired and weak. They killed all the people who were walking slowly at the back of your group. They were not afraid of God."
    },
    {
      "verse": "19",
      "text": "But the Lord your God will chase away all your enemies. He will give you a safe place to rest in the land that he is giving to you as your new home. When he does that, do not forget to destroy all the Amalekites. Make sure that nobody in the whole world will remember them any more."
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "You will soon go into the land that the Lord your God is giving to you. It will belong to you as your home."
    },
    {
      "verse": "2",
      "text": "This is what you must do the first time that the land provides food for you: At harvest time, when you bring in your crops, put some in a basket. Take it to the special place that the Lord your God will choose for people to worship him."
    },
    {
      "verse": "3",
      "text": "Go to the priest who has authority at that time. Say to him, ‘Today, I say to the Lord our God that I am now living in the land that he promised to us. He made that promise to our ancestors. ’"
    },
    {
      "verse": "4",
      "text": "Then the priest will take the basket from you. He will put it down in front of the altar of the Lord your God."
    },
    {
      "verse": "5",
      "text": "Then you must say this, so that the Lord your God hears you: ‘My ancestor was an Aramean who moved from place to place. He went to Egypt to live there as a foreigner. At that time, his family was small. But while he lived in Egypt, his family became a great nation of many powerful people."
    },
    {
      "verse": "6",
      "text": "But the Egyptian people were cruel to us. They made us work very hard for them."
    },
    {
      "verse": "7",
      "text": "So we prayed to the Lord, the God of our ancestors. He heard our prayers. He saw that we were in trouble. He saw that we had to do very hard work for cruel people."
    },
    {
      "verse": "8",
      "text": "So the Lord used his great strength and power to bring us out of Egypt. He did powerful miracles which caused the Egyptians to be afraid."
    },
    {
      "verse": "9",
      "text": "Then he brought us to this place. He gave us this land where there is plenty of food and drink, enough for everyone."
    },
    {
      "verse": "10",
      "text": "So now I am bringing the first food that has grown in my fields. You, Lord, have given it to me. ’Then you must put the basket down in front of the Lord's altar. Worship him there."
    },
    {
      "verse": "11",
      "text": "In that way, you will enjoy a meal to say ‘thank you’ for all the good things that the Lord your God has given to you and your family. Share your meal with the Levites and the foreign people who live among you."
    },
    {
      "verse": "12",
      "text": "Every third year you must keep safe a tenth part of all your crops. In the third year, you must give that tithe to the Levites, the foreigners who live among you, widows and the children who have no family. Then everyone who lives in your towns can eat all the food that they need."
    },
    {
      "verse": "13",
      "text": "Then you can say to the Lord your God, ‘None of the tithe that belongs to you remains in my house. I have done what you commanded me to do. I have given it to the Levites, foreigners, widows and the children who have no family. I have not forgotten to obey your commands."
    },
    {
      "verse": "14",
      "text": "I have not eaten any of this special food when I was weeping for someone who had died. I did not touched any of it while I was unclean. I have not offered any of it to give honour to a dead person. I have obeyed you completely. I have done everything that you commanded me to do."
    },
    {
      "verse": "15",
      "text": "Please look down from your home in heaven and bless your people, Israel. Please bless the land that you have given to us. You promised our ancestors that you would do that. It is a land where there is plenty of food and drink, enough for everyone. ’"
    },
    {
      "verse": "16",
      "text": "Today, the Lord your God commands you to obey these laws and these rules. So be careful to obey them with all your mind and with all your strength."
    },
    {
      "verse": "17",
      "text": "Today, you have said clearly that the Lord is your God. You have agreed to live in a way that pleases him. You have agreed that you will obey his rules, his commands and his laws. You will do everything that he has told you to do."
    },
    {
      "verse": "18",
      "text": "Today the Lord has accepted you to be his own special people. He already promised that he would do that. As his people, you must obey all his commands."
    },
    {
      "verse": "19",
      "text": "If you do that, he will make you greater than all the other nations that he has made. Other nations will see that you are great. They will praise you and give you honour. You will be a nation that belongs to the Lord your God as his own special people. He has promised to do this."
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "Moses and the leaders of Israel said to the people, ‘Obey all these commands that I am giving you today."
    },
    {
      "verse": "2",
      "text": "You will soon go across the Jordan River and go into the land that the Lord your God is giving to you. When you are there, you must put up some large stones on Mount Ebal. Cover them with thick white paint."
    },
    {
      "verse": "3",
      "text": "Then write on them all these laws and teaching. You must do that when you go across the river into the land that the Lord your God is giving to you. It is a land where there is plenty of food and drink, enough for everyone. He promised your ancestors that he would give it to you."
    },
    {
      "verse": "4",
      "text": "After you go across the Jordan River, you must put these stones on Mount Ebal. Cover them with white paint. Do as I am telling you today."
    },
    {
      "verse": "5",
      "text": "Then you must build an altar there to worship the Lord your God. Do not use iron tools to cut the stones for the altar."
    },
    {
      "verse": "6",
      "text": "Use whole stones that you find to build it. Then offer burnt offerings to the Lord your God on the altar."
    },
    {
      "verse": "7",
      "text": "You must also offer friendship offerings there. Eat them with joy as you meet with the Lord your God."
    },
    {
      "verse": "8",
      "text": "Write all the words of this law on the stones that you will put there. Be sure to write them very clearly. ’"
    },
    {
      "verse": "9",
      "text": "Then Moses and the Levite priests said to all the Israelites, ‘Be quiet and listen carefully! Today, you have become the people who belong to the Lord your God."
    },
    {
      "verse": "10",
      "text": "Obey him. Obey his commands and his rules that I am giving you today. ’"
    },
    {
      "verse": "11",
      "text": "On the same day, Moses commanded the people,"
    },
    {
      "verse": "12",
      "text": "‘After you have gone across the Jordan River, these tribes must stand on Mount Gerizim: Simeon, Levi, Judah, Issachar, Joseph and Benjamin. They will bless the people."
    },
    {
      "verse": "13",
      "text": "These tribes must stand on Mount Ebal: Reuben, Gad, Asher, Zebulun, Dan and Naphtali. They will speak aloud God's curses. ’"
    },
    {
      "verse": "14",
      "text": "The Levites will shout this with a loud voice to all the Israelites:"
    },
    {
      "verse": "15",
      "text": "‘God will curse anyone who makes any image of a god and who worships it secretly. The Lord hates all idols that people make with metal or with wood. ’ Then all the people will say, ‘Yes, we agree! ’"
    },
    {
      "verse": "16",
      "text": "‘God will curse anyone who does not respect his parents. ’ Then all the people will say, ‘Yes, we agree! ’"
    },
    {
      "verse": "17",
      "text": "‘God will curse anyone who moves the stones at the edge of his neighbour's land. ’ Then all the people will say, ‘Yes, we agree! ’"
    },
    {
      "verse": "18",
      "text": "‘God will curse anyone who leads a blind person along the wrong path. ’ Then all the people will say, ‘Yes, we agree! ’"
    },
    {
      "verse": "19",
      "text": "‘God will curse anyone who stops foreigners, widows or children who have no family from receiving justice. ’ Then all the people will say, ‘Yes, we agree! ’"
    },
    {
      "verse": "20",
      "text": "‘God will curse any man who has sex with his father's wife. That would bring shame on his father. ’ Then all the people will say, ‘Yes, we agree! ’"
    },
    {
      "verse": "21",
      "text": "‘God will curse any man who has sex with any animal. ’ Then all the people will say, ‘Yes, we agree! ’"
    },
    {
      "verse": "22",
      "text": "‘God will curse any man who has sex with his sister, whether she is his father's daughter or his mother's daughter. ’ Then all the people will say, ‘Yes, we agree! ’"
    },
    {
      "verse": "23",
      "text": "‘God will curse any man who has sex with his wife's mother. ’ Then all the people will say, ‘Yes, we agree! ’"
    },
    {
      "verse": "24",
      "text": "‘God will curse anyone who murders anyone secretly. ’ Then all the people will say, ‘Yes, we agree! ’"
    },
    {
      "verse": "25",
      "text": "‘God will curse anyone who receives a bribe to kill someone who has done nothing wrong. ’ Then all the people will say, ‘Yes, we agree! ’"
    },
    {
      "verse": "26",
      "text": "‘God will curse anyone who refuses to obey all the words of this law. ’ Then all the people will say, ‘Yes, we agree! ’"
    }
  ],
  "28": [
    {
      "verse": "1",
      "text": "Today I am giving you the commands of the Lord your God. You must be careful to obey all of them completely. If you do that, he will make you greater than any other nation of people in the world."
    },
    {
      "verse": "2",
      "text": "If you obey the Lord your God, he will bless you in very many ways."
    },
    {
      "verse": "3",
      "text": "God will bless you in your cities and in your fields."
    },
    {
      "verse": "4",
      "text": "God will bless your children and the crops that you grow. Your cows and your sheep will have many babies."
    },
    {
      "verse": "5",
      "text": "God will bless you with lots of grain to make bread."
    },
    {
      "verse": "6",
      "text": "God will bless you in your homes and when you go outside."
    },
    {
      "verse": "7",
      "text": "When your enemies attack you, the Lord will knock them down. They will come from one direction to attack you, but they will run away from you in seven different directions!"
    },
    {
      "verse": "8",
      "text": "The Lord will bless you with lots of food to store. He will bless all the work that you do. He will bless you very much in the land that he is giving to you."
    },
    {
      "verse": "9",
      "text": "The Lord will continue to help you as his special people, as he has promised to do. But you must obey his commands. You must live in a way that pleases him."
    },
    {
      "verse": "10",
      "text": "If you do that, everyone in the world will see that you belong to the Lord. They will respect you with fear."
    },
    {
      "verse": "11",
      "text": "The Lord will give you many children. Your animals will have many babies. Your fields will give you a lot of food. The Lord will do this in the land that he promised your ancestors he would give you."
    },
    {
      "verse": "12",
      "text": "The Lord will send rain from the clouds where he stores it. He will cause the rain to fall at the time when the land needs it. He will bless all the work that you do. You will lend money to the people of many nations. But you will not need anyone to lend money to you."
    },
    {
      "verse": "13",
      "text": "The Lord will make you the leaders of other people. You will not have to follow at the back. You will become more powerful, not weaker. But you must obey the commands of the Lord your God. I am telling you today, you must be very careful to do that."
    },
    {
      "verse": "14",
      "text": "You must continue to obey all the commands that I am giving you today. Do not turn away from them to do anything else. Do not try to worship other gods."
    },
    {
      "verse": "15",
      "text": "But if you refuse to listen to the Lord your God, all these curses will happen to you. So be careful to obey all his commands and rules that I am giving you today. If you do not obey the Lord, these curses will happen to you:"
    },
    {
      "verse": "16",
      "text": "God will curse you in your cities and in your fields."
    },
    {
      "verse": "17",
      "text": "God will curse you so that you have no grain to make bread."
    },
    {
      "verse": "18",
      "text": "God will curse your children and the crops that you grow. Your cows and your sheep will not give birth to healthy babies."
    },
    {
      "verse": "19",
      "text": "God will curse you in your homes and when you go outside."
    },
    {
      "verse": "20",
      "text": "If you do evil things and you turn away from the Lord, he will curse you. He will confuse your thoughts in everything that you do. He will turn against you so that you quickly come to an end."
    },
    {
      "verse": "21",
      "text": "The Lord will make you very ill so that you do not get better again. He will completely remove you from the land that you are now going into."
    },
    {
      "verse": "22",
      "text": "The Lord will give you many kinds of disease. Your bodies will become weak and very hot. They will grow big and have a lot of pain. He will send great heat and there will be no rain. Your crops will all become spoiled. You will have all this pain until you die."
    },
    {
      "verse": "23",
      "text": "There will be no clouds in the sky above to give any rain. The ground under your feet will be as hard as iron."
    },
    {
      "verse": "24",
      "text": "There will be clouds of dust instead of rain. Dirt will come down from the sky until it has destroyed you."
    },
    {
      "verse": "25",
      "text": "The Lord will let your enemies knock you down. You will attack them from one direction, but you will run away from them in seven directions. When the people of other nations see what has happened to you, they will see it is a terrible thing."
    },
    {
      "verse": "26",
      "text": "Your dead bodies will be food for all the birds and the wild animals. No one will be there to chase them away."
    },
    {
      "verse": "27",
      "text": "The Lord will cause you to have boils on your bodies. That is what he did to the Egyptians. He will also cause you to have tumours and other bad diseases on your skin. You will not be able to get well again."
    },
    {
      "verse": "28",
      "text": "The Lord will make you crazy and blind. He will confuse your thoughts."
    },
    {
      "verse": "29",
      "text": "Even at midday, you will not see your way. You will be in the dark, like a blind person. You will not be able to go anywhere, whatever you do. Every day, people will be cruel to you. People will rob you. No one will be there to save you."
    },
    {
      "verse": "30",
      "text": "A woman will promise to marry you. But another man will take her and have sex with her. You will build a house, but you will not live in it. You will plant a garden, but you will never eat the fruit that grows in it."
    },
    {
      "verse": "31",
      "text": "Someone will kill your bull while you watch. But you will not eat any of the meat. As you watch, someone will take your donkey from you. He will never give it back to you. Your enemies will take your sheep for themselves. There will be no one there to help you."
    },
    {
      "verse": "32",
      "text": "Foreign people will take your children away to be their slaves. Every day, you will look for them to come back to you. But you will have no power to do anything."
    },
    {
      "verse": "33",
      "text": "Strangers will eat the food that you have worked hard to grow in your fields. People will be cruel to you for the rest of your lives."
    },
    {
      "verse": "34",
      "text": "When you see what is happening to you, you will become crazy."
    },
    {
      "verse": "35",
      "text": "The Lord will cause you to have boils on your knees and on your legs. They will give you much pain and they will never get better. They will soon cover your whole body, from your toes to the top of your head."
    },
    {
      "verse": "36",
      "text": "When you choose a king for yourselves, the Lord will send you and him away to a foreign country. It will be a place that neither you nor your ancestors have ever heard about. There you will serve gods that people have made from stone and wood."
    },
    {
      "verse": "37",
      "text": "The Lord will send you away to live among foreign people. When they see what has happened to you, they will all see that it is terrible. They will tell stories about you and they will laugh at you."
    },
    {
      "verse": "38",
      "text": "You will plant many seeds in your fields, but you will not have much food at harvest time. Instead, locusts will eat your crops."
    },
    {
      "verse": "39",
      "text": "You will plant vineyards to grow grapes. You will take care of the plants. But you will not drink any wine or bring in any grapes. Instead, worms will eat them."
    },
    {
      "verse": "40",
      "text": "Olive trees will grow everywhere in your land, but you will never use any oil from them. The olives will drop off the trees before they are ready to pick."
    },
    {
      "verse": "41",
      "text": "You will give birth to sons and daughters, but you will lose them. Enemies will take them away as prisoners."
    },
    {
      "verse": "42",
      "text": "Crowds of locusts will eat all your trees and the food from your fields."
    },
    {
      "verse": "43",
      "text": "Foreign people who live among you will become stronger and stronger. They will have more and more power over you, as you become weaker."
    },
    {
      "verse": "44",
      "text": "They will lend money to you, but you will not lend money to them. They will become your leaders. You will have to follow behind them."
    },
    {
      "verse": "45",
      "text": "All these curses will happen to you. They will be like an enemy that chases after you, catches you, and destroys you. That will happen to you, if you refuse to obey the Lord your God. If you do not obey his commands and his rules that he has given to you, these troubles will happen to you."
    },
    {
      "verse": "46",
      "text": "They will show that God is very angry with you. You and your descendants will know that for ever."
    },
    {
      "verse": "47",
      "text": "The Lord has given you many good things. But you have not agreed to serve the Lord your God with joy."
    },
    {
      "verse": "48",
      "text": "So you will serve your enemies that the Lord will send to attack you. You will be hungry and thirsty. You will be so poor that you do not even have clothes to wear. Your enemies will make you work so hard that they will destroy you."
    },
    {
      "verse": "49",
      "text": "The Lord will bring a nation from far away in the world to attack you. You will not understand their language. They will come quickly to attack you, like an eagle that comes down from the sky."
    },
    {
      "verse": "50",
      "text": "They will have angry faces. They will not be kind to anyone, even old people and young children."
    },
    {
      "verse": "51",
      "text": "They will eat your young animals and the crops from your fields, until they have destroyed you. They will not leave any food for you. You will have no grain, no wine, no olive oil, no young cows, no lambs. They will take everything from you until they destroy you."
    },
    {
      "verse": "52",
      "text": "They will attack all your towns, everywhere in the land that the Lord your God has given to you. They will knock down the strong walls that you thought would keep you safe. They will make their camps around your towns until they can take the towns for themselves."
    },
    {
      "verse": "53",
      "text": "When that happens, you will have no food, because your enemy's soldiers are all around your town. You will be so hungry that you eat your own children. Those are the sons and daughters that the Lord your God has given to you."
    },
    {
      "verse": "54",
      "text": "Even the best and kindest man among you will turn against his brother. He will turn against the wife that he loves and against his children who are still alive."
    },
    {
      "verse": "55",
      "text": "He will be so hungry that he eats meat from his own child, because there is no other food. He will not share it with any of his own family. He will do that because your enemy is so strong. The soldiers will stop any food from coming into your towns."
    },
    {
      "verse": "56",
      "text": "Even the best and kindest woman among you will turn against the husband that she loves. She will turn against her sons and daughters. She has been rich enough to have everything that she needs."
    },
    {
      "verse": "57",
      "text": "But now she will be so hungry that she will eat her new baby and the afterbirth. She will eat them secretly because there is nothing else for her to eat. She will not share anything with her family because your enemy will be too strong. The soldiers will stop any food from coming into your towns."
    },
    {
      "verse": "58",
      "text": "Be careful to obey all the words of this law that I have written in this scroll. Always respect the Lord your God. Give him the honour that his great name deserves."
    },
    {
      "verse": "59",
      "text": "If you refuse to do that, the Lord will punish you and your descendants more and more. You will have lots of pain and many kinds of terrible disease that will not get better."
    },
    {
      "verse": "60",
      "text": "He will cause you to have all the same diseases that hurt the Egyptians and that made you very afraid. Those diseases will never leave you alone."
    },
    {
      "verse": "61",
      "text": "The Lord will also cause you to have many other terrible diseases. This scroll of God's Law does not say anything about those diseases, but they will destroy you completely."
    },
    {
      "verse": "62",
      "text": "At one time, you were as many people as the stars in the sky. But if you do not obey the Lord your God, only a few of you will remain alive."
    },
    {
      "verse": "63",
      "text": "At one time, the Lord was happy to help you with good things. He gave you many children. But if you do not obey him, he will be happy to destroy you. He will remove you from the land that will soon become your new home."
    },
    {
      "verse": "64",
      "text": "If that happens, the Lord will send you away to live among many other nations, all over the world. There you will worship other gods. They are gods that people have made from wood and from stone. Neither you nor your ancestors have ever known those gods before."
    },
    {
      "verse": "65",
      "text": "When you live among those nations, you will not be happy. You will not find a home where you can live safely in peace. The Lord will cause you to have troubles in your mind. Your eyes will not see well. You will be sad and upset."
    },
    {
      "verse": "66",
      "text": "You will be in danger of death all the time. You will be afraid in the day and at night. You will never know if you will live for one more day."
    },
    {
      "verse": "67",
      "text": "Every morning you will say, ‘I want the night to come quickly! ’ And every evening you will say, ‘I want the morning to come quickly! ’ You will say that because of all the terrible things that you see."
    },
    {
      "verse": "68",
      "text": "The Lord told you that you must never travel on the road back to Egypt. But he will send you back to Egypt in ships. In Egypt, you will try to sell yourselves to your enemies, as slaves. But no one will agree to buy you."
    }
  ],
  "29": [
    {
      "verse": "1",
      "text": "The Lord commanded Moses to tell the Israelites the words of his covenant with them. He made this covenant with them in Moab's country, as well as the covenant that he had made with them at Sinai."
    },
    {
      "verse": "2",
      "text": "This is what Moses said to all the Israelites when they met together: You have seen everything that the Lord did in Egypt. You saw how he punished Egypt's king, his officers and his whole country."
    },
    {
      "verse": "3",
      "text": "You saw the miracles which the Lord did to show his great power."
    },
    {
      "verse": "4",
      "text": "But until now the Lord has not let you understand why he did that. You saw and you heard those things, but you did not understand."
    },
    {
      "verse": "5",
      "text": "The Lord says, ‘I led you through this desert for 40 years. In all that time, your clothes and your shoes have not become spoiled."
    },
    {
      "verse": "6",
      "text": "You did not eat any bread. You did not drink any wine or beer. I helped you so that you would know that I am the Lord your God. ’"
    },
    {
      "verse": "7",
      "text": "When we arrived here, King Sihon of Heshbon and King Og of Bashan attacked us. But we won against them."
    },
    {
      "verse": "8",
      "text": "We took their land and we gave it to the tribes of Reuben, Gad and half the tribe of Manasseh. That would be their new home."
    },
    {
      "verse": "9",
      "text": "So be careful to obey the words of this covenant. If you are faithful, everything that you do will go well."
    },
    {
      "verse": "10",
      "text": "The Lord your God sees all of you today as you stand here. He sees your leaders, your important men, your officers and all Israelite men."
    },
    {
      "verse": "11",
      "text": "He sees your children and your wives. He sees the foreign people who live among you and who cut wood and carry water for you."
    },
    {
      "verse": "12",
      "text": "You are standing here to agree to the covenant that the Lord your God is making with you today. You must promise to obey it."
    },
    {
      "verse": "13",
      "text": "By this covenant, the Lord says again today that you are his people and he is your God. He has already made that promise to you and to your ancestors, Abraham, Isaac and Jacob."
    },
    {
      "verse": "16",
      "text": "You remember how we lived when we were in Egypt. You remember how we travelled through other countries as we came here."
    },
    {
      "verse": "17",
      "text": "You saw the useless gods that people of other nations worship. They worship idols that they make from wood, stone, silver and gold."
    },
    {
      "verse": "18",
      "text": "So be very careful that you do not turn away from the Lord our God to worship the gods of those nations. No man, woman, clan or tribe among you must ever want to do that. That would be like the root of a plant that gives fruits which are full of poison."
    },
    {
      "verse": "19",
      "text": "Nobody who hears the message of this covenant should think that they can go against it. Someone might say to himself, ‘I do not have to obey this covenant. I will be safe, whatever happens. God will still bless me. ’ A person who thinks like that will bring trouble on everyone and on everything."
    },
    {
      "verse": "20",
      "text": "The Lord will never forgive that person. He will be very angry with him. The Lord will punish him in all the terrible ways that are written in this book. The Lord will destroy him completely so that his family name comes to an end."
    },
    {
      "verse": "21",
      "text": "The Lord will make that person separate from all the Israelite tribes and he will punish him very much. All the troubles that the Lord promises in this covenant will happen to that person, as this book of God's Law says."
    },
    {
      "verse": "22",
      "text": "Then, in future years, your descendants will see that many troubles have come to your land. They will see that the Lord has made people very ill. Foreign people who come from countries far away will also see what has happened."
    },
    {
      "verse": "23",
      "text": "The whole land will become spoiled with salt and sulphur. No one will plant seed in it, because nothing will grow there. Even grass will not grow on it. The land will be useless, like the cities that the Lord destroyed when he was very angry with them. Those cities were Sodom and Gomorrah, Admah and Zeboiim."
    },
    {
      "verse": "24",
      "text": "The people of all other nations who see this will ask, ‘Why has the Lord destroyed this land? Why was he so angry with the people who lived there? ’"
    },
    {
      "verse": "25",
      "text": "People will answer, ‘Because these people turned away from the covenant that the Lord had made with them. He is the God that their ancestors worshipped. He made a covenant with them when he brought them out of Egypt."
    },
    {
      "verse": "26",
      "text": "But they turned away from him and they worshipped other gods. They served gods that they had not known before. They were gods that the Lord did not give them to worship."
    },
    {
      "verse": "27",
      "text": "So the Lord was angry with the people in this land. He punished them with all the terrible troubles that are written in this book."
    },
    {
      "verse": "28",
      "text": "That is why the Lord removed them from their land. He was very angry with them. So he threw them out to a foreign country. We see that they are still there today. ’"
    },
    {
      "verse": "29",
      "text": "Some secret things belong to the Lord our God. He does not let us understand everything. But he has shown us many things clearly. Those things belong to us and to our descendants for all time. They are the words of his Law that we need to obey."
    },
    {
      "verse": "14",
      "text": "The Lord our God is making this strong covenant with you people who are standing here with him today. But it is not only with you."
    },
    {
      "verse": "15",
      "text": "He also makes this covenant with those people who are not here today."
    }
  ],
  "30": [
    {
      "verse": "1",
      "text": "I have told you about the ways that God may bless you and the ways that he may curse you. If you do not obey the Lord your God, he will send you away to live in many foreign countries. When that happens, you will think about what I have said."
    },
    {
      "verse": "2",
      "text": "Then you and your children may decide to turn back to the Lord. You may choose to obey him completely in everything that you think and in everything that you do. That is what I am commanding you to do today."
    },
    {
      "verse": "3",
      "text": "If you do that, the Lord your God will bring you back home and he will forgive you. He will turn to help you again. He will bring you back from the countries where he sent you to live."
    },
    {
      "verse": "4",
      "text": "He will bring back even those of you who live in countries that are very far away. You will all come back to live together again."
    },
    {
      "verse": "5",
      "text": "He will bring you back to the land that belonged to your ancestors. It will belong to you as your home. He will help you even more than he helped your ancestors. He will make you more in number than your ancestors were."
    },
    {
      "verse": "6",
      "text": "The Lord your God will change you so that you want to serve him. He will do that for your descendants too. Then you will love him completely in everything that you think and in everything that you do. You will continue to live in your land."
    },
    {
      "verse": "7",
      "text": "When that happens, the Lord your God will punish your enemies with all these terrible troubles, instead of you. He will punish the people who hate you and do cruel things to you."
    },
    {
      "verse": "8",
      "text": "You will turn back to the Lord. You will obey all his commands that I am giving you today."
    },
    {
      "verse": "9",
      "text": "The Lord your God will cause all your work to go very well. He will give you many children. Your animals will give birth to many babies. Lots of crops will grow in your fields. The Lord will be happy to help you again, as he was happy to help your ancestors."
    },
    {
      "verse": "10",
      "text": "But you must obey his commands and his rules that are written in this book of his Law. You must turn back to him. You must serve him in everything that you think and in everything that you do."
    },
    {
      "verse": "11",
      "text": "The command that I am giving you today is not too difficult for you. It is not too far away from you."
    },
    {
      "verse": "12",
      "text": "God does not keep it in heaven. So you do not have to ask, ‘Who will go up to heaven to find it and bring it down to us? Who will explain it to us so that we can obey it? ’"
    },
    {
      "verse": "13",
      "text": "It is not far away across the sea. So you do not have to ask, ‘Who will go across the sea to fetch it for us? Who will explain it to us so that we can obey it? ’"
    },
    {
      "verse": "14",
      "text": "No! God's message is very near to you. It is in your mouth and in your mind. So you must do what it teaches you to do."
    },
    {
      "verse": "15",
      "text": "Look! You must choose between the things that I am offering you today. You may choose to have life and many good things. Or you may choose to have death and many troubles."
    },
    {
      "verse": "16",
      "text": "I am commanding you today to love the Lord your God. Live in a way that pleases him. Obey his commands, his rules and his laws. If you do that, you will live. You will become a nation of many people. The Lord your God will bless you in the land that you are going into as your new home."
    },
    {
      "verse": "17",
      "text": "But you will have trouble if you turn away from God and you do not obey him. If you decide to serve other gods and to worship them,"
    },
    {
      "verse": "18",
      "text": "you will certainly come to an end. After you go across the Jordan River, you will not live very long in that land. That is what I am telling you today."
    },
    {
      "verse": "19",
      "text": "Today, I want the sky and the earth to hear what I have said to you. I have told you what you may choose. You may choose life or death. You may choose the Lord to bless you or to curse you. Choose life today, so that you and your descendants will live!"
    },
    {
      "verse": "20",
      "text": "Yes, love the Lord your God. Obey him and serve him faithfully. He is the one who gives you life. He will let you live for a long time in the land that he is giving to you. That is the land that he promised to your ancestors, Abraham, Isaac and Jacob."
    }
  ],
  "31": [
    {
      "verse": "1",
      "text": "Then Moses went out and he spoke to all the Israelites."
    },
    {
      "verse": "2",
      "text": "He said to them, ‘I am now 120 years old. I can no longer continue to lead you. The Lord has told me that I will not go across the Jordan River."
    },
    {
      "verse": "3",
      "text": "But the Lord your God himself will go across the river in front of you. He will destroy the nations who live in that land. Then you will live there instead of them. Joshua will lead you across the river, as the Lord has said."
    },
    {
      "verse": "4",
      "text": "The Lord will do to those nations the same things that he did to Sihon and to Og, the Amorite kings. He destroyed them and their land."
    },
    {
      "verse": "5",
      "text": "The Lord will give you power over them. Then you must do to them everything that I have told you to do."
    },
    {
      "verse": "6",
      "text": "Be strong and be brave! Do not be afraid of those people, because the Lord your God goes with you. He will always be there to help you. He will never leave you. ’"
    },
    {
      "verse": "7",
      "text": "Then Moses fetched Joshua. While all the Israelites listened, Moses said this to Joshua:‘Be strong and very brave! You will go with these people into the land that the Lord promised to give to their ancestors. You will give them the land which will be their new home."
    },
    {
      "verse": "8",
      "text": "The Lord himself goes in front of you. He will always be with you, to help you. He will never leave you. So do not be afraid. Be brave! ’"
    },
    {
      "verse": "9",
      "text": "Moses wrote down all the rules of God's Law. He gave them to the Levite priests who carry the Lord's Covenant Box. He also gave them to the leaders of the Israelites."
    },
    {
      "verse": "12",
      "text": "Bring all the men, women and children together. Also bring the foreign people who live in your towns. They must all hear God's Law as it is read to them. Then they can learn to respect and obey the Lord your God. They will be careful to obey all the teaching of his Law."
    },
    {
      "verse": "13",
      "text": "Their children will hear this Law for the first time. They will learn to respect and obey the Lord your God. You must do this for as long as you live in the land. You will soon go across the Jordan River to live there. ’"
    },
    {
      "verse": "14",
      "text": "The Lord said to Moses, ‘You will soon die. Fetch Joshua and come with him to the Tent of Meeting. When you meet with me there, I will give Joshua authority to be the leader of my people. ’So Moses and Joshua went to meet the Lord at his special tent. So Moses and Joshua went to meet the Lord at his special tent."
    },
    {
      "verse": "15",
      "text": "The Lord appeared in a pillar of cloud. The cloud was above the door of the tent."
    },
    {
      "verse": "16",
      "text": "The Lord said to Moses, ‘You will soon die. After you die, the people will soon go away from me. They will start to worship foreign gods of the land where they are going. They will turn against me. They will not obey the covenant that I made with them."
    },
    {
      "verse": "17",
      "text": "When that happens, I will be very angry with them. I will leave them. I will refuse to help them until they are destroyed. Many bad things will happen to them so that they are in great trouble. Then they will say, “These bad things have happened to us because our God is no longer with us. ”"
    },
    {
      "verse": "18",
      "text": "But at that time I will certainly refuse to help them. That is because of all the wicked things that they will have done. They will start to worship other gods."
    },
    {
      "verse": "19",
      "text": "Now write down this song that I will give to you. Teach the Israelites to sing it. Its words will show them that they are guilty because they have not obeyed me."
    },
    {
      "verse": "20",
      "text": "I will take them into this land, where there is plenty of food and drink, enough for everyone. It is the land that I promised to give to their ancestors. When they live there, they will eat as much food as they want. They will be fat and healthy. But then they will start to worship other gods. They will turn against me. They will not obey the covenant that I made with them."
    },
    {
      "verse": "21",
      "text": "Many bad things will happen to them so that they are in great trouble. Then this song will show them that they are guilty. Their descendants will never forget it. Even now, I know what they are thinking. I know what they want to do, even before I take them into the land that I have promised to them. ’"
    },
    {
      "verse": "22",
      "text": "So Moses wrote down this song on that same day. He taught it to the Israelites."
    },
    {
      "verse": "23",
      "text": "Then the Lord made Joshua, the son of Nun, the new leader. He said to Joshua, ‘Be strong and very brave! You will lead the Israelites into the land that I have promised to give them. I will be with you to help you. ’"
    },
    {
      "verse": "24",
      "text": "Moses finished writing all the words of God's Law in a book."
    },
    {
      "verse": "25",
      "text": "Then he said to the Levites who carried the Lord's Covenant Box,"
    },
    {
      "verse": "26",
      "text": "‘Take this book of God's Law. Put it next to the Covenant Box of the Lord your God. It must remain there, so that the Israelites will know when they are guilty."
    },
    {
      "verse": "27",
      "text": "I know that they are a proud people who do not want to obey me. All the time that I have been living among them, they have turned against the Lord. After my death, they will turn against him even more!"
    },
    {
      "verse": "28",
      "text": "Now bring to me all the leaders and officers of your tribes. I want to tell them about all these things. And I want the sky and the earth to hear what I will say to them."
    },
    {
      "verse": "29",
      "text": "I know that, after my death, you will do more and more wicked things. You will turn away from the good things that I have commanded you to do. In future days, you will do wicked things against the Lord. Because of that, you will have great trouble. You will make the Lord angry because of the things that you do. ’"
    },
    {
      "verse": "30",
      "text": "Then Moses spoke the words of this song, from the beginning to the end. All the Israelites met together and they listened to him."
    },
    {
      "verse": "10",
      "text": "Then Moses said to them, ‘You must read this Law to all the Israelites. Read it every seven years at the Feast of Huts, in the year when you forgive people's debts."
    },
    {
      "verse": "11",
      "text": "At that time all the Israelites will go to the place that the Lord your God will choose. When they meet there to worship the Lord, they must listen to this Law."
    }
  ],
  "32": [
    {
      "verse": "1",
      "text": "Sky and earth, listen to my words! Hear what I am saying!"
    },
    {
      "verse": "2",
      "text": "My teaching will be like the rain that falls. My messages will help the people who hear them, as rain helps new grass to grow. My messages will help the people who hear them, as rain helps new grass to grow."
    },
    {
      "verse": "3",
      "text": "I will praise the Lord's name. Everyone must know that our God is very great! Everyone must know that our God is very great!"
    },
    {
      "verse": "4",
      "text": "He is the strong Rock where we can be safe. Everything that he does is perfect. He only does what is right and fair. We can trust him to be faithful. Everything that he does is perfect. He only does what is right and fair. We can trust him to be faithful."
    },
    {
      "verse": "5",
      "text": "But you, his people, have not served him faithfully. Because of your sins, you cannot continue to be his children. You have turned against him. You enjoy doing bad things. Because of your sins, you cannot continue to be his children. You have turned against him. You enjoy doing bad things."
    },
    {
      "verse": "6",
      "text": "You are fools who do not understand what is right. You should not do these things against the Lord. He is your Father, the one who created you. He made you become a strong nation. You should not do these things against the Lord. He is your Father, the one who created you. He made you become a strong nation."
    },
    {
      "verse": "7",
      "text": "Remember what happened a long time ago. Think about the lives of your ancestors. Ask your father or the old men. They will tell you what happened in the past. Think about the lives of your ancestors. Ask your father or the old men. They will tell you what happened in the past."
    },
    {
      "verse": "8",
      "text": "The Most High God gave land to be the home of each nation. When he made people into separate groups, he decided where their borders should be. He did that to match the number of angels in heaven. When he made people into separate groups, he decided where their borders should be. He did that to match the number of angels in heaven."
    },
    {
      "verse": "9",
      "text": "But the Lord himself takes care of his own people. Jacob's descendants are his special people. Jacob's descendants are his special people."
    },
    {
      "verse": "10",
      "text": "The Lord found them in a desert place. It was a place where strong winds blew and nobody lived. He took care of them and he kept them safe. He protected them, like someone protects their own eyes. It was a place where strong winds blew and nobody lived. He took care of them and he kept them safe. He protected them, like someone protects their own eyes."
    },
    {
      "verse": "11",
      "text": "The Lord took care of his people, like an eagle takes care of its babies. As an eagle flies with its babies on its back, the Lord helped his people to be safe. like an eagle takes care of its babies. As an eagle flies with its babies on its back, the Lord helped his people to be safe."
    },
    {
      "verse": "12",
      "text": "The Lord alone was a guide for his people. He needed no foreign god to help him. He needed no foreign god to help him."
    },
    {
      "verse": "13",
      "text": "The Lord helped them to travel over the high places in the land. He fed them with food from the fields. He made them strong with honey from the rocks. He gave them olive oil from trees in ground with many stones. He fed them with food from the fields. He made them strong with honey from the rocks. He gave them olive oil from trees in ground with many stones."
    },
    {
      "verse": "14",
      "text": "Their cows and their goats gave them plenty of milk and butter. Their lambs, sheep and goats became fat, so they ate the best meat. They ate the best bread from their wheat. They drank the best wine from their grapes. Their lambs, sheep and goats became fat, so they ate the best meat. They ate the best bread from their wheat. They drank the best wine from their grapes."
    },
    {
      "verse": "15",
      "text": "The Israelites became rich and fat. They turned against God. They were full of good food, but they turned away from God. He was the one who made them. He was the strong Rock who kept them safe. But they no longer respected him. They turned against God. They were full of good food, but they turned away from God. He was the one who made them. He was the strong Rock who kept them safe. But they no longer respected him."
    },
    {
      "verse": "16",
      "text": "They worshipped foreign gods. So the Lord became angry and jealous. They made idols which he hated. So the Lord became angry and jealous. They made idols which he hated."
    },
    {
      "verse": "17",
      "text": "They offered sacrifices to demons, instead of to God. They worshipped new gods which they had not known before. Your ancestors had never respected those gods. They worshipped new gods which they had not known before. Your ancestors had never respected those gods."
    },
    {
      "verse": "18",
      "text": "You forgot about your strong Rock, the God who gave you life. the God who gave you life."
    },
    {
      "verse": "19",
      "text": "When the Lord saw this, he turned away from them. His sons and daughters had made him angry. His sons and daughters had made him angry."
    },
    {
      "verse": "20",
      "text": "He said, ‘I will not continue to help them. I will see what happens to them when I leave them alone. They are children who do not obey me. They have not served me faithfully. I will see what happens to them when I leave them alone. They are children who do not obey me. They have not served me faithfully."
    },
    {
      "verse": "21",
      "text": "They have made me jealous as they serve false gods. They have made me angry as they worship useless idols. So I will make them jealous as I help a useless nation. I will make them angry as I bless a foolish nation. They have made me angry as they worship useless idols. So I will make them jealous as I help a useless nation. I will make them angry as I bless a foolish nation."
    },
    {
      "verse": "22",
      "text": "I will become so angry that I punish them very much. I will destroy them like a hot fire. It will be like a fire that reaches deep down into the place of dead people. It will destroy the ground and everything that grows on it. It will burn deep down to the foundations of the mountains. I will destroy them like a hot fire. It will be like a fire that reaches deep down into the place of dead people. It will destroy the ground and everything that grows on it. It will burn deep down to the foundations of the mountains."
    },
    {
      "verse": "23",
      "text": "I will cause them to have many kinds of trouble. I will attack them like a soldier who shoots all his arrows. I will attack them like a soldier who shoots all his arrows."
    },
    {
      "verse": "24",
      "text": "They will become weak and hungry. They will have bad diseases that give them much pain. I will cause wild animals to attack them. Snakes will bite them and they will die. They will have bad diseases that give them much pain. I will cause wild animals to attack them. Snakes will bite them and they will die."
    },
    {
      "verse": "25",
      "text": "If they go out of their homes, their enemies will kill them. If they stay at home, they will die from fear. Young men and young women will die. Babies and old men will also die. If they stay at home, they will die from fear. Young men and young women will die. Babies and old men will also die."
    },
    {
      "verse": "26",
      "text": "I wanted to remove my people completely, so that nobody would ever remember them. so that nobody would ever remember them."
    },
    {
      "verse": "27",
      "text": "But then their enemies would boast. They would not understand. They would say, “We have destroyed these people with our own strength! The Lord has not done this! ” ’ They would not understand. They would say, “We have destroyed these people with our own strength! The Lord has not done this! ” ’"
    },
    {
      "verse": "28",
      "text": "Israel is a nation without wisdom. They do not understand what will happen to them. They do not understand what will happen to them."
    },
    {
      "verse": "29",
      "text": "If they were wise, they would understand. They would know what would happen to them in the end. They would know what would happen to them in the end."
    },
    {
      "verse": "30",
      "text": "One man can chase away 1, 000 of my people! Two men can chase away 10, 000 of them! How can that happen? God, their strong Rock, has left them. The Lord has given their enemies power over them. Two men can chase away 10, 000 of them! How can that happen? God, their strong Rock, has left them. The Lord has given their enemies power over them."
    },
    {
      "verse": "31",
      "text": "The gods of our enemies are not strong like our Rock. Even our enemies know that their own gods are weak. Even our enemies know that their own gods are weak."
    },
    {
      "verse": "32",
      "text": "Our enemies are like grapes full of poison. They are like grapes that have grown in the fields of Sodom and Gomorrah. They are like grapes that have grown in the fields of Sodom and Gomorrah."
    },
    {
      "verse": "33",
      "text": "The wine from their grapes kills people, like dangerous poison from snakes. like dangerous poison from snakes."
    },
    {
      "verse": "34",
      "text": "The Lord says, ‘I will not forget to punish Israel's enemies. I have already decided what I will do, and I will do it! I have already decided what I will do, and I will do it!"
    },
    {
      "verse": "35",
      "text": "When the right time comes, I will punish them as they deserve. They will suddenly falland great trouble will quickly destroy them. ’ I will punish them as they deserve. They will suddenly fall and great trouble will quickly destroy them. ’"
    },
    {
      "verse": "36",
      "text": "At that time, the Lord will bring justice for his people. He will forgive his servants. He will rescue them when he sees that they are weak, and very few of them remain, as slaves or free people. He will forgive his servants. He will rescue them when he sees that they are weak, and very few of them remain, as slaves or free people."
    },
    {
      "verse": "37",
      "text": "Then the Lord will ask his people, ‘Why could your gods not help you? Those were the gods that you thought would keep you safe. ‘Why could your gods not help you? Those were the gods that you thought would keep you safe."
    },
    {
      "verse": "38",
      "text": "You fed them with the best part of your sacrifices. You let them drink the wine from your offerings. So they should be there to help you! They should keep you safe! You let them drink the wine from your offerings. So they should be there to help you! They should keep you safe!"
    },
    {
      "verse": "39",
      "text": "Realize the truth! I alone am God. There is no other god as well as me. I can kill and I can give life. I can hurt people and I can make them well again. Nobody can stop me doing what I choose to do. There is no other god as well as me. I can kill and I can give life. I can hurt people and I can make them well again. Nobody can stop me doing what I choose to do."
    },
    {
      "verse": "40",
      "text": "I lift up my hand to heaven and I make this strong promise:“I promise you this, as surely as I live for ever: “I promise you this, as surely as I live for ever:"
    },
    {
      "verse": "41",
      "text": "I will make my sword very sharp. It will move like lightning as I hold it in my hand. I will punish my enemies as they deserve. I will pay back everyone who hates me. It will move like lightning as I hold it in my hand. I will punish my enemies as they deserve. I will pay back everyone who hates me."
    },
    {
      "verse": "42",
      "text": "My arrows will have blood all over them. My sword will cut into the bodies of my enemies. Everyone that I take hold of will die. I will cut off the heads of their leaders. ” ’ My sword will cut into the bodies of my enemies. Everyone that I take hold of will die. I will cut off the heads of their leaders. ” ’"
    },
    {
      "verse": "43",
      "text": "So you people of other nations, join with God's people to praise him! He will punish those who have killed his servants. He will punish all his enemies. But he will forgive the sins of his people, and he will make their land clean again. join with God's people to praise him! He will punish those who have killed his servants. He will punish all his enemies. But he will forgive the sins of his people, and he will make their land clean again."
    },
    {
      "verse": "44",
      "text": "Moses went and he spoke all the words of this song to the Israelites. He did this together with Joshua, son of Nun."
    },
    {
      "verse": "45",
      "text": "When Moses had finished speaking all these words,"
    },
    {
      "verse": "46",
      "text": "he said to the people, ‘Remember carefully the message that I have spoken to you today. You must teach these words to your children. They must learn to obey all the words of God's Law."
    },
    {
      "verse": "47",
      "text": "These are not just useless words. This is a message that gives life! If you obey it, you will live for many years in the land on the other side of the Jordan River. That is the land that will be your new home. ’"
    },
    {
      "verse": "48",
      "text": "On the same day, the Lord said to Moses,"
    },
    {
      "verse": "49",
      "text": "‘Go up into the hill country of Abarim in Moab's land. Climb Mount Nebo where you can see Jericho city on the other side of the river. Look at the land of Canaan. I am giving this land to the Israelites as their new home."
    },
    {
      "verse": "50",
      "text": "You will die on Mount Nebo, as your brother Aaron died on Mount Hor."
    },
    {
      "verse": "51",
      "text": "Both of you refused to obey me at the waters of Meribah Kadesh, in the Zin desert. You did not show the Israelites that you respected me as God."
    },
    {
      "verse": "52",
      "text": "So you will not go into the land that I am giving to the Israelites. You will only see it from far away. ’"
    }
  ],
  "33": [
    {
      "verse": "1",
      "text": "Before his death, God's servant Moses spoke this blessing to all the Israelites. ‘The Lord came from Sinai. He appeared to his people like the sun that rises over the hills of Edom. He shone on his people from Mount Paran. Thousands of angels came with him. In his right hand, he held his Law that burned with fire."
    },
    {
      "verse": "2",
      "text": "He said this:‘The Lord came from Sinai. He appeared to his peoplelike the sun that rises over the hills of Edom. He shone on his people from Mount Paran. Thousands of angels came with him. In his right hand, he held his Law that burned with fire."
    },
    {
      "verse": "3",
      "text": "Yes, the Lord loves his people. He takes care of all his holy people. They sit near to him and they listen to his teaching. He takes care of all his holy people. They sit near to him and they listen to his teaching."
    },
    {
      "verse": "4",
      "text": "Moses gave us the Lord's teaching. It is very valuable to us, the descendants of Jacob. It is very valuable to us, the descendants of Jacob."
    },
    {
      "verse": "5",
      "text": "When the leaders of the people and all the tribes met together, the Lord became king of Israel. the Lord became king of Israel."
    },
    {
      "verse": "6",
      "text": "I pray this for the tribe of Reuben: May they continue to live and have many descendants. May they continue to live and have many descendants."
    },
    {
      "verse": "7",
      "text": "I pray this for the tribe of Judah: Lord, please listen to their prayers for help. May they join again with the other tribes. Please make them strong, so that they can fight against their enemies. Lord, please listen to their prayers for help. May they join again with the other tribes. Please make them strong, so that they can fight against their enemies."
    },
    {
      "verse": "8",
      "text": "I pray this for the tribe of Levi: Lord, your Urim and Thummim belong to your faithful servants, the Levites. You tested them at Massah. You argued with them at the springs of water at Meribah. Lord, your Urim and Thummim belong to your faithful servants, the Levites. You tested them at Massah. You argued with them at the springs of water at Meribah."
    },
    {
      "verse": "9",
      "text": "The Levites left their own familiesso that they could serve you well. They obeyed your word. They were faithful to your covenant. so that they could serve you well. They obeyed your word. They were faithful to your covenant."
    },
    {
      "verse": "10",
      "text": "They teach your rules and your laws to Jacob's descendants, the Israelites. They offer incense to you, as a sweet smell. They burn offerings on your altar. They offer incense to you, as a sweet smell. They burn offerings on your altar."
    },
    {
      "verse": "11",
      "text": "Lord, please bless their work. May everything that they do give you pleasure. Knock down anyone who attacks them. Destroy all their enemies completely. May everything that they do give you pleasure. Knock down anyone who attacks them. Destroy all their enemies completely."
    },
    {
      "verse": "12",
      "text": "I pray this for the tribe of Benjamin: The Lord loves the tribe of Benjamin. They will live with him and they will be safe. The Lord protects them all the time. He keeps them near to him. The Lord loves the tribe of Benjamin. They will live with him and they will be safe. The Lord protects them all the time. He keeps them near to him."
    },
    {
      "verse": "13",
      "text": "I pray this for the tribe of Joseph: Lord, please bless their land. Send rain from the sky above, and springs of water from under the ground. Lord, please bless their land. Send rain from the sky above, and springs of water from under the ground."
    },
    {
      "verse": "14",
      "text": "May the sun give them a good harvest of food, with the best crops every month. with the best crops every month."
    },
    {
      "verse": "15",
      "text": "May they have a harvest of good fruitsfrom the mountains and hills that have been there since long ago. from the mountains and hills that have been there since long ago."
    },
    {
      "verse": "16",
      "text": "Please fill their land with many good things. Lord who appeared in the burning bush, please be kind to them. Please bless Joseph's descendants. He became a leader, separate from his brothers. May this blessing be like a crown on his head! Lord who appeared in the burning bush, please be kind to them. Please bless Joseph's descendants. He became a leader, separate from his brothers. May this blessing be like a crown on his head!"
    },
    {
      "verse": "17",
      "text": "Joseph is as strong as a bull. He has horns like a wild ox. Those two horns are the armies of Ephraim and Manasseh! With them, he attacks other nations. He chases them to the edges of the world. He has horns like a wild ox. Those two horns are the armies of Ephraim and Manasseh! With them, he attacks other nations. He chases them to the edges of the world."
    },
    {
      "verse": "18",
      "text": "I pray this for the tribes of Zebulun and Issachar: Be happy, Zebulun's people, as you travel far from home. Be happy, Issachar's people, as you live in your homes. Be happy, Zebulun's people, as you travel far from home. Be happy, Issachar's people, as you live in your homes."
    },
    {
      "verse": "19",
      "text": "They will call other people to come to their mountain. They will offer the right sacrifices there. They will become rich from their work on the seas, and from things that are hidden in the sand on the shore. They will offer the right sacrifices there. They will become rich from their work on the seas, and from things that are hidden in the sand on the shore."
    },
    {
      "verse": "20",
      "text": "I pray this for the tribe of Gad: Praise the Lord, who will give more land to Gad's people! Gad lives there like a hungry lion. He will tear off the arm or the head of his enemies. Praise the Lord, who will give more land to Gad's people! Gad lives there like a hungry lion. He will tear off the arm or the head of his enemies."
    },
    {
      "verse": "21",
      "text": "He has chosen the best part of the land for himself. When Israel's leaders met together, Gad's tribe received the land that a leader deserves. Gad's people obeyed the Lord's good laws. They obeyed the Lord's commands for Israel. When Israel's leaders met together, Gad's tribe received the land that a leader deserves. Gad's people obeyed the Lord's good laws. They obeyed the Lord's commands for Israel."
    },
    {
      "verse": "22",
      "text": "I pray this for the tribe of Dan: Dan's tribe is like a young lion. They jump out from Bashan to attack their enemies. Dan's tribe is like a young lion. They jump out from Bashan to attack their enemies."
    },
    {
      "verse": "23",
      "text": "I pray this for the tribe of Naphtali: The Lord has blessed Naphtali's tribe very much. He has been very kind to them. Land in the west and in the south will belong to them. The Lord has blessed Naphtali's tribe very much. He has been very kind to them. Land in the west and in the south will belong to them."
    },
    {
      "verse": "24",
      "text": "I pray this for the tribe of Asher: May the Lord bless Asher's tribe more than the other tribes. May their brothers be pleased with them. May Asher's people be rich enough to wash their feet in olive oil. May the Lord bless Asher's tribe more than the other tribes. May their brothers be pleased with them. May Asher's people be rich enough to wash their feet in olive oil."
    },
    {
      "verse": "25",
      "text": "They will use iron and bronze to make the gates of their towns strong. May they be strong for as long as they live. May they be strong for as long as they live."
    },
    {
      "verse": "26",
      "text": "Israelites, there is no god like your God. He rides across the sky to help you. He travels with great authority on the clouds. He rides across the sky to help you. He travels with great authority on the clouds."
    },
    {
      "verse": "27",
      "text": "He is the God who lives for ever. He is the safe place where you can hide. His strong arms are always there, to hold you safely. He will chase away your enemies as you attack them. He says to you, “Destroy them! ” He is the safe place where you can hide. His strong arms are always there, to hold you safely. He will chase away your enemies as you attack them. He says to you, “Destroy them! ”"
    },
    {
      "verse": "28",
      "text": "So Israel's people can now live safely. Jacob's descendants have a safe place to live. They have a land that will give them grain and wine. Rain falls from the sky to make the ground wet. Jacob's descendants have a safe place to live. They have a land that will give them grain and wine. Rain falls from the sky to make the ground wet."
    },
    {
      "verse": "29",
      "text": "Israelites, how happy you are! There is no other nation like you. The Lord himself has rescued you. He is the one who keeps you safe, like a soldier's shield. He is like a sword that you use to win against your enemies. Your enemies will fall down with fear in front of you. You will walk all over them. ’"
    }
  ],
  "34": [
    {
      "verse": "1",
      "text": "Then Moses went up from Moab's desert land. He climbed up Mount Nebo to the top of Pisgah mountain. Jericho city was on the other side of the Jordan River. The Lord showed him the whole land, from the region of Gilead to Dan in the north."
    },
    {
      "verse": "2",
      "text": "He saw all the land that would belong to Naphtali, Ephraim, Manasseh and Judah, as far as the Mediterranean Sea in the west."
    },
    {
      "verse": "3",
      "text": "He saw the Negev desert in the south. He saw the valley that goes from Jericho as far as Zoar. Jericho is called ‘The city of palm trees’."
    },
    {
      "verse": "4",
      "text": "Then the Lord said to Moses, ‘This is the land that I promised to Abraham, Isaac and Jacob. I told them that I would give it to their descendants. Now I have let you see the land, but you will not go across the river into it. ’"
    },
    {
      "verse": "5",
      "text": "So Moses, the Lord's servant, died there in Moab. The Lord had said that this would happen."
    },
    {
      "verse": "6",
      "text": "The Lord buried Moses in a valley in Moab, near the town of Beth-Peor. But even today, no one knows the place where God buried him."
    },
    {
      "verse": "7",
      "text": "years old when he died. But he could still see well. His body was still strong."
    },
    {
      "verse": "8",
      "text": "days because of Moses' death. They wept in Moab's desert land until the time for them to be sad came to an end."
    },
    {
      "verse": "9",
      "text": "Moses had already chosen Nun's son, Joshua, to take his place as the leader of the Israelites. So the Lord had filled Joshua with wisdom. The Israelites listened to Joshua. They obeyed the commands that the Lord had given to Moses."
    },
    {
      "verse": "10",
      "text": "There has never been another prophet in Israel like Moses. The Lord spoke to him, face to face."
    },
    {
      "verse": "11",
      "text": "Moses did the miracles that the Lord had sent him to do in Egypt. Those miracles showed the Lord's power to Pharaoh and his officers, and to all the people in his country."
    },
    {
      "verse": "12",
      "text": "No other prophet has shown such great power and authority for all the Israelites to see."
    }
  ]
};
