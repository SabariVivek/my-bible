module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "The Lord spoke a message to Jonah, Amittai's son."
    },
    {
      "verse": "2",
      "text": "He said, ‘Go now to the great city of Nineveh. Tell the people in the city that I know how wicked they are. Tell them that I will punish them because of their sins. ’"
    },
    {
      "verse": "3",
      "text": "But Jonah did not want to obey the Lord's command. He decided to run away to Tarshish. He went down to Joppa. There he found a ship that was ready to sail to Tarshish. After he had paid for the journey, he got into the ship. He wanted to go on the ship to Tarshish, to get far away from the Lord."
    },
    {
      "verse": "4",
      "text": "Then the Lord sent a strong wind on the sea. The storm was so powerful that it almost broke the ship into pieces."
    },
    {
      "verse": "5",
      "text": "The sailors were very frightened. Each of them called out to his own god for help. They threw into the sea all the things that the ship carried. They wanted to make the ship as light as they could. Jonah had gone down into the bottom of the ship. He was lying down and he was asleep."
    },
    {
      "verse": "6",
      "text": "The ship's captain went to Jonah. He said, ‘Why are you sleeping like that? Get up now! Call to your god for help! Maybe he will listen to us and we will not die. ’"
    },
    {
      "verse": "7",
      "text": "Then the sailors said to each other, ‘We should throw dice to find out who has brought all this trouble to us. ’ So they threw dice. The dice showed that Jonah had caused the storm."
    },
    {
      "verse": "8",
      "text": "So they said to Jonah, ‘Tell us, who has caused all this trouble for us? What is your job? Where do you come from? What country do you live in? Who is your family? ’"
    },
    {
      "verse": "9",
      "text": "Jonah answered them, ‘I am a Hebrew man. I worship the Lord who is the God of heaven. He made the sea and the land. ’"
    },
    {
      "verse": "10",
      "text": "This made the sailors even more afraid. Jonah had already told them that he was running away from the Lord. So they said to him, ‘Why did you do a thing like that? ’"
    },
    {
      "verse": "11",
      "text": "The waves in the sea were becoming bigger because of the storm. So the sailors asked Jonah, ‘What should we do to you so that the sea becomes quiet? ’"
    },
    {
      "verse": "12",
      "text": "Jonah replied, ‘Pick me up and throw me into the sea. Then the sea will become quiet. It is because of me that you are in danger from this great storm. ’"
    },
    {
      "verse": "13",
      "text": "But the sailors did not do what Jonah said. Instead, they tried to use oars to drive the ship back to the land. But the storm was too strong and they could not do that."
    },
    {
      "verse": "14",
      "text": "So the sailors called aloud to the Lord. They prayed, ‘Lord, please do not punish us with death if we have to kill this man! Do not say that we are guilty because we have killed someone who has done nothing wrong. Lord, we know that you have sent this storm because you wanted to do it. ’"
    },
    {
      "verse": "15",
      "text": "Then the sailors took hold of Jonah and they threw him into the sea. The storm stopped and the sea became quiet."
    },
    {
      "verse": "16",
      "text": "When they saw what had happened, the sailors became very afraid of the Lord's power. They offered a sacrifice to him and they promised that they would serve him."
    },
    {
      "verse": "17",
      "text": "But the Lord sent a great fish to swallow Jonah. Jonah was inside the fish's stomach for three days and three nights."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "From inside the fish's stomach, Jonah prayed to the Lord his God."
    },
    {
      "verse": "2",
      "text": "He said, ‘When I was in trouble, I called out to the Lord, and he answered my prayer. Yes, I called out to you for help from the deep hole of death, and you heard my prayer. ‘When I was in trouble, I called out to the Lord, and he answered my prayer. Yes, I called out to you for help from the deep hole of death, and you heard my prayer."
    },
    {
      "verse": "3",
      "text": "You threw me into the deep water, and I fell into the middle of the sea. The deep water covered me. You sent big waves to roll over me. and I fell into the middle of the sea. The deep water covered me. You sent big waves to roll over me."
    },
    {
      "verse": "4",
      "text": "I said to myself, “You have sent me far away from you. Now I will never see your holy temple again. ” “You have sent me far away from you. Now I will never see your holy temple again. ”"
    },
    {
      "verse": "5",
      "text": "The deep water of the sea covered me, so that my life was in danger. The plants in the sea were all around my head. so that my life was in danger. The plants in the sea were all around my head."
    },
    {
      "verse": "6",
      "text": "I went very deep in the water, as far as the bottom of the mountains. Deep in the earth, I was in a prison, and its gates had shut for ever. But, Lord, my God, you brought me up from that deep hole. as far as the bottom of the mountains. Deep in the earth, I was in a prison, and its gates had shut for ever. But, Lord, my God, you brought me up from that deep hole."
    },
    {
      "verse": "7",
      "text": "When my life was nearly gone, I prayed to you, Lord. In your holy temple, you heard my prayer for help. In your holy temple, you heard my prayer for help."
    },
    {
      "verse": "8",
      "text": "Idols cannot help. People who worship them have turned away from a faithful God. People who worship them have turned away from a faithful God."
    },
    {
      "verse": "9",
      "text": "But as for me, I will sing to thank you. I will offer a sacrifice to you. I will do everything that I have promised to do. The Lord is the one who saves people! ’ I will offer a sacrifice to you. I will do everything that I have promised to do. The Lord is the one who saves people! ’"
    },
    {
      "verse": "10",
      "text": "Then the Lord told the great fish to spit Jonah out from its stomach. So it dropped Jonah onto the shore."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "The Lord spoke to Jonah a second time."
    },
    {
      "verse": "2",
      "text": "He said, ‘Now go to that great city, Nineveh. Tell the people there the message that I will give to you. ’"
    },
    {
      "verse": "3",
      "text": "Jonah obeyed the Lord and he went to Nineveh. Nineveh was a very large city. Somebody would need three days to walk all through it. Nineveh was a very large city. Somebody would need three days to walk all through it."
    },
    {
      "verse": "4",
      "text": "When Jonah arrived in Nineveh, he walked for one day into the city. Then he shouted out to the people, ‘After 40 more days, God will destroy Nineveh. ’"
    },
    {
      "verse": "5",
      "text": "The people who lived in Nineveh believed God's message. They told everyone that they must not eat any food for several days. Everyone had to wear sackcloth to show that they were sorry. The most important people and the ordinary people all did that."
    },
    {
      "verse": "6",
      "text": "The king of Nineveh heard about God's message. He got up from his throne and he removed his royal clothes. He dressed himself in sackcloth and he sat in ashes on the ground."
    },
    {
      "verse": "7",
      "text": "Then the king sent this message to all the people in Nineveh. He said, ‘This command comes from the king and his officers. No person or any of your animals may eat any food or drink any water."
    },
    {
      "verse": "8",
      "text": "Everyone must wear sackcloth. You must cover all your animals with sackcloth too. Everyone must pray to God with all their strength. You must all stop doing bad and cruel things."
    },
    {
      "verse": "9",
      "text": "Then perhaps God may agree to forgive us. He may decide that he will not be angry with us. Then perhaps we will not all die. ’"
    },
    {
      "verse": "10",
      "text": "God saw what the people in Nineveh did. He saw that they stopped doing evil things. He had said that he would punish them for their sins. But now he decided that he would not destroy them."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "But Jonah was not happy when God decided not to destroy Nineveh. He became very angry."
    },
    {
      "verse": "2",
      "text": "He prayed to the Lord. He said, ‘Lord, this is what I thought would happen when I was still at home. So I decided to run away to Tarshish, so that you could not be kind to the people of Nineveh. I know that you are a God who is very kind and you forgive people. You do not become angry quickly. You always show your faithful love for people. Even when you have said that you will punish people, you decide that you will not do it."
    },
    {
      "verse": "3",
      "text": "Lord, please kill me now! I would rather die than continue to live. ’"
    },
    {
      "verse": "4",
      "text": "The Lord replied to Jonah, ‘You are not right to be so angry. ’"
    },
    {
      "verse": "5",
      "text": "Jonah went out of Nineveh. He built a little hut on the east side of the city. He sat in the shade of the hut. He waited to see what would happen to the city."
    },
    {
      "verse": "6",
      "text": "The Lord God made a little plant grow there. He caused it to grow up over Jonah's head to give him shade from the hot sun. This comforted Jonah in his trouble. Jonah was very happy about the plant."
    },
    {
      "verse": "7",
      "text": "But at dawn the next day, God sent a worm to attack the plant. So then the plant died."
    },
    {
      "verse": "8",
      "text": "When the sun rose, God caused a hot wind to blow from the east. The hot sun shone on Jonah's head so that he became very weak. He wanted to die. He said, ‘I would rather die than continue to live. ’"
    },
    {
      "verse": "9",
      "text": "But God said to Jonah, ‘You are not right to be so angry about the plant. ’Jonah said, ‘I am right to be angry! I am so angry that I want to die. ’ Jonah said, ‘I am right to be angry! I am so angry that I want to die. ’"
    },
    {
      "verse": "10",
      "text": "But the Lord said to Jonah, ‘You are upset about what happened to this little plant. But you did not plant it. You did not help it to grow. It grew up quickly during one night and by the next night it had died. You are sorry about such a little thing!"
    },
    {
      "verse": "11",
      "text": "So it is right for me to be sorry about Nineveh. It is a great city. More than 120, 000 people live in it. They cannot understand the difference between what is right and what is wrong. They also have many farm animals. ’"
    }
  ]
};