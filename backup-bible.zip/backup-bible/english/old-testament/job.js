module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "There was a man who lived in a place called Uz. His name was Job. He was a good and honest man. He was afraid to make God angry. He refused to do evil things."
    },
    {
      "verse": "2",
      "text": "Job had seven sons and three daughters."
    },
    {
      "verse": "3",
      "text": "He had 7, 000 sheep and 3, 000 camels. He had 500 pairs of oxen and 500 donkeys. He also had many servants. He was the richest person in the east part of the world."
    },
    {
      "verse": "4",
      "text": "Each of Job's sons would give parties for each other in their homes. They sent messages to their three sisters to come and eat the feast with them."
    },
    {
      "verse": "5",
      "text": "After each party, Job would ask his children to come and visit him. He wanted to make them clean again if they were guilty of bad things. He thought, ‘Perhaps they have done something that is bad. Perhaps they have thought bad things against God. ’ So he would get up early in the morning. He would offer a burnt offering as a sacrifice for each of his children. Job always did this after each party that his children had."
    },
    {
      "verse": "6",
      "text": "One day, the angels came to meet with the Lord in heaven. Satan also came and he stood there with them."
    },
    {
      "verse": "7",
      "text": "The Lord said to Satan, ‘Where have you come from? ’ Satan replied, ‘I have been travelling all over the earth. I have been watching the things that happen there. ’"
    },
    {
      "verse": "8",
      "text": "Then the Lord said to Satan, ‘You have seen Job, who is my servant. What do you think about him? There is no one on earth that is like him. He is a good and honest man. He is afraid to make me angry. He refuses to do evil things. ’"
    },
    {
      "verse": "9",
      "text": "Satan answered the Lord, ‘There is a very good reason why Job obeys you."
    },
    {
      "verse": "10",
      "text": "You do not let any bad things happen to him. You keep him, his family and all his things safe. You have given him success with everything that he does. His many farm animals are everywhere!"
    },
    {
      "verse": "11",
      "text": "You should take away from him all the things that he has. Then he will certainly curse you very strongly. ’"
    },
    {
      "verse": "12",
      "text": "So the Lord said to Satan, ‘I agree to give you power over all the things that belong to Job. But you must do nothing to hurt Job himself. ’After that, Satan went away. After that, Satan went away."
    },
    {
      "verse": "13",
      "text": "One day, Job's sons and daughters were at a party in the home of his oldest son."
    },
    {
      "verse": "14",
      "text": "A servant brought a message to Job. He said, ‘We were using your oxen to plough the fields. Your donkeys were eating grass beside them."
    },
    {
      "verse": "15",
      "text": "Some men from Sheba suddenly came and they attacked us. They took away all your oxen and your donkeys. They also killed all your other servants. I was the only one who escaped. I ran here to tell you what has happened. ’"
    },
    {
      "verse": "16",
      "text": "That servant was still speaking, when another servant arrived. He said to Job, ‘God has sent lightning down from the sky. It has killed your sheep and your servants. I was the only one who escaped. I ran here to tell you what has happened. ’"
    },
    {
      "verse": "17",
      "text": "Before that servant had finished speaking, a third servant arrived. He said to Job, ‘Some robbers from Chaldea suddenly attacked us. They took away all your camels and they killed your servants. I was the only one who escaped. I ran here to tell you what has happened. ’"
    },
    {
      "verse": "18",
      "text": "That servant was still speaking, when a fourth servant arrived. He said to Job, ‘Your children were eating a feast at a party in the home of your oldest son."
    },
    {
      "verse": "19",
      "text": "Suddenly there was a strong storm that came from the desert. The wind destroyed the house where your children were. The house fell on them and it killed them. I was the only one who escaped. I ran here to tell you what has happened. ’"
    },
    {
      "verse": "20",
      "text": "When Job heard this news he was very upset. He tore his clothes and he cut off all his hair. Then he bent down low on the ground to worship God."
    },
    {
      "verse": "21",
      "text": "He said, ‘When I was born, I had nothing. When I die, I will take nothing with me. The Lord has given me all the things that I have. The Lord may choose to take those things away. I will continue to praise the name of the Lord! ’"
    },
    {
      "verse": "22",
      "text": "Even after all these things had happened, Job still did not do anything bad. He did not say that God had done something wrong to him."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Another time, the angels came again to meet with the Lord. Satan also came with them to meet the Lord."
    },
    {
      "verse": "2",
      "text": "The Lord said to Satan, ‘Where have you come from? ’ Satan replied, ‘I have been travelling all over the earth. I have been watching the things that happen there. ’"
    },
    {
      "verse": "3",
      "text": "Then the Lord said to Satan, ‘You have seen Job, who is my servant. What do you think about him? There is no one on earth who is like him. He is a good and honest man. He is afraid to make me angry. He refuses to do evil things. Because of what you said, I allowed you to attack him. But he did not deserve that. He has continued to do what is right. ’"
    },
    {
      "verse": "4",
      "text": "Satan answered the Lord, ‘A man will always take care of his own body. He would do anything to save his own life."
    },
    {
      "verse": "5",
      "text": "So now cause Job to have great pain in his own body. Then he will certainly curse you very strongly. ’"
    },
    {
      "verse": "6",
      "text": "So the Lord said to Satan, ‘I agree to give you power over Job himself. But you must not cause his death. ’"
    },
    {
      "verse": "7",
      "text": "So Satan went away. He caused Job to have boils all over his body. They hurt him everywhere, from the bottom of his feet to the top of his head."
    },
    {
      "verse": "8",
      "text": "Job was very upset and he sat down among some ashes. He used a piece of a broken pot to remove the bad bits of skin."
    },
    {
      "verse": "9",
      "text": "His wife said to him, ‘You cannot continue to trust God! Instead, you should curse God and then die. ’ In all his trouble, Job never said any wrong things against God."
    },
    {
      "verse": "10",
      "text": "Job replied, ‘Do not talk like a fool! We take the good things that God gives us. So we should not be surprised if he sends us trouble as well. ’In all his trouble, Job never said any wrong things against God."
    },
    {
      "verse": "11",
      "text": "Three of Job's friends heard news about his trouble. One friend was called Eliphaz, who came from Teman. The second friend was called Bildad, who came from Shuah. The third friend was called Zophar, who came from Naamah. They came from their own homes to meet together. They wanted to show Job that they were sorry about his trouble. They went to visit him to comfort him."
    },
    {
      "verse": "12",
      "text": "When they could see Job from far away, they did not easily recognize him. They began to weep very loudly. They were so upset that they tore their clothes. They threw dust into the air and on their heads."
    },
    {
      "verse": "13",
      "text": "For a whole week, they sat on the ground near Job. They knew that his pain was very bad. So all that time, they did not say anything to him."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "Finally, Job decided to speak. He cursed the day when he was born."
    },
    {
      "verse": "2",
      "text": "This is what Job said:"
    },
    {
      "verse": "3",
      "text": "‘Forget the day of my birth. Forget the night when a son was born to my parents. Forget the night when a son was born to my parents."
    },
    {
      "verse": "4",
      "text": "That day should be completely dark, with no light to shine on it! God in heaven above should not even think about it. with no light to shine on it! God in heaven above should not even think about it."
    },
    {
      "verse": "5",
      "text": "That day should remain in a dark shadow. Clouds should cover it so that everywhere is black. Clouds should cover it so that everywhere is black."
    },
    {
      "verse": "6",
      "text": "Remove that night completely! It should no longer be a date among the days of the year. Remove that day from the months of the year. It should no longer be a date among the days of the year. Remove that day from the months of the year."
    },
    {
      "verse": "7",
      "text": "Do not let women become pregnant on that night. Nobody should be happy! Nobody should be happy!"
    },
    {
      "verse": "8",
      "text": "People who know how to curse days should curse that day. They should wake up Leviathan, the monster from the sea, to attack it. They should wake up Leviathan, the monster from the sea, to attack it."
    },
    {
      "verse": "9",
      "text": "The stars of early morning should be dark on that day. Do not let the sun shine at dawn, so that there is no end to the dark night. Do not let the sun shine at dawn, so that there is no end to the dark night."
    },
    {
      "verse": "10",
      "text": "I curse that day because it allowed me to be born. It brought me into a life of trouble. It brought me into a life of trouble."
    },
    {
      "verse": "11",
      "text": "It would have been better if I had died at birth. I should have been born dead. I should have been born dead."
    },
    {
      "verse": "12",
      "text": "Instead, my mother held me on her knees. I drank from her breasts. I drank from her breasts."
    },
    {
      "verse": "13",
      "text": "If I had died at birth, I would now be resting in peace."
    },
    {
      "verse": "14",
      "text": "I would be resting with kings and rulers. They lived in beautiful houses which are now heaps of stones. They lived in beautiful houses which are now heaps of stones."
    },
    {
      "verse": "15",
      "text": "I would be with princes who once were very rich. Their palaces were full of gold and silver. Their palaces were full of gold and silver."
    },
    {
      "verse": "16",
      "text": "My parents should have buried me, like a child that is born dead. I would never have seen the light of day. like a child that is born dead. I would never have seen the light of day."
    },
    {
      "verse": "17",
      "text": "After death, wicked people can no longer cause any trouble. People who have become tired can rest. People who have become tired can rest."
    },
    {
      "verse": "18",
      "text": "Even prisoners can enjoy a time of peace. No guards are there to shout at them. No guards are there to shout at them."
    },
    {
      "verse": "19",
      "text": "Great people and ordinary people are all there together. Slaves have no master that they must obey. Slaves have no master that they must obey."
    },
    {
      "verse": "20",
      "text": "I am suffering very much. Why does God let me wake up each day? I am very upset, so why does God continue to let me live? Why does God let me wake up each day? I am very upset, so why does God continue to let me live?"
    },
    {
      "verse": "21",
      "text": "People like me only want to die. But death does not come. They would rather die than find valuable gold. They would rather die than find valuable gold."
    },
    {
      "verse": "22",
      "text": "When their life finally finishes, they are very happy. They are happy to go into their graves. They are happy to go into their graves."
    },
    {
      "verse": "23",
      "text": "So why do I continue to live? God has stopped me moving forward in life. I cannot see which way to go. God has stopped me moving forward in life. I cannot see which way to go."
    },
    {
      "verse": "24",
      "text": "I am crying instead of eating. My tears pour out like a river of water. My tears pour out like a river of water."
    },
    {
      "verse": "25",
      "text": "The things that frighten me most have happened to me."
    },
    {
      "verse": "26",
      "text": "Because of all the trouble that has happened to me, I cannot rest. I have no peace in my mind. ’"
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Eliphaz, who came from Teman, decided to speak. He said this to Job:"
    },
    {
      "verse": "2",
      "text": "‘Please be patient and listen to what I say. Allow me to speak, because I cannot remain quiet. Allow me to speak, because I cannot remain quiet."
    },
    {
      "verse": "3",
      "text": "Listen! You have taught many people. You have helped weak people to be strong. You have helped weak people to be strong."
    },
    {
      "verse": "4",
      "text": "With your words, you have saved people from danger. You have helped people who are in trouble to be brave. You have helped people who are in trouble to be brave."
    },
    {
      "verse": "5",
      "text": "But now you are the person who has trouble. You yourself are not patient. Trouble has come to you and you feel afraid. You yourself are not patient. Trouble has come to you and you feel afraid."
    },
    {
      "verse": "6",
      "text": "But you respect God's authority, so you should trust him. You live in an honest way, so you should still hope for better things. so you should trust him. You live in an honest way, so you should still hope for better things."
    },
    {
      "verse": "7",
      "text": "Think about this: People who are not guilty of sin do not suddenly die. God does not destroy people who do good things. People who are not guilty of sin do not suddenly die. God does not destroy people who do good things."
    },
    {
      "verse": "8",
      "text": "I will tell you what I have seen. Trouble comes to people who do wicked things. They receive the punishment that they deserve. Trouble comes to people who do wicked things. They receive the punishment that they deserve."
    },
    {
      "verse": "9",
      "text": "God destroys them with his breath. His anger is like a storm that blows them away. His anger is like a storm that blows them away."
    },
    {
      "verse": "10",
      "text": "Lions are strong animals that roar loudly. But if God breaks a lion's teeth, it cannot eat. But if God breaks a lion's teeth, it cannot eat."
    },
    {
      "verse": "11",
      "text": "Even the strongest lion will die if it has nothing to eat. The young lions will run away from their mother to find food. The young lions will run away from their mother to find food."
    },
    {
      "verse": "12",
      "text": "One night I heard a quiet voice. Someone spoke to me and told me a secret. Someone spoke to me and told me a secret."
    },
    {
      "verse": "13",
      "text": "I was asleep, but my dreams woke me."
    },
    {
      "verse": "14",
      "text": "I was very afraid. Even my bones were shaking. Even my bones were shaking."
    },
    {
      "verse": "15",
      "text": "A wind was blowing over my face. The hair on my skin stood up. The hair on my skin stood up."
    },
    {
      "verse": "16",
      "text": "Something stopped and it stood in front of me. I could not recognize its shape. Then I heard a quiet voice say: I could not recognize its shape. Then I heard a quiet voice say:"
    },
    {
      "verse": "17",
      "text": "“No human is righteous when he stands in front of God. He cannot be pure in front of his Maker. He cannot be pure in front of his Maker."
    },
    {
      "verse": "18",
      "text": "God knows that even his angels make mistakes. They may do foolish things. They may do foolish things."
    },
    {
      "verse": "19",
      "text": "God used clay to make bodies for us who are humans. We came from the dust of the earth. We are as weak as moths. We came from the dust of the earth. We are as weak as moths."
    },
    {
      "verse": "20",
      "text": "We are alive in the morning, and when evening comes we may be dead. People disappear for ever. No one even knows about it. and when evening comes we may be dead. People disappear for ever. No one even knows about it."
    },
    {
      "verse": "21",
      "text": "They no longer have their valuable things. They suddenly die and they are still not wise. ” ’"
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "‘Shout for help, Job! But no one will answer you. None of the angels will come to help you. None of the angels will come to help you."
    },
    {
      "verse": "2",
      "text": "Foolish people may be angry and jealous. That is what kills them. That is what kills them."
    },
    {
      "verse": "3",
      "text": "I have seen fools who seemed to be successful. But suddenly a curse destroyed their homes. But suddenly a curse destroyed their homes."
    },
    {
      "verse": "4",
      "text": "Their children are never truly safe. The judge says that they are guilty, and nobody saves them from punishment. The judge says that they are guilty, and nobody saves them from punishment."
    },
    {
      "verse": "5",
      "text": "Hungry people take their crops to eat. They even take them from among the weeds. Thirsty people take the fool's money for themselves. They even take them from among the weeds. Thirsty people take the fool's money for themselves."
    },
    {
      "verse": "6",
      "text": "Problems do not grow like plants in our fields. Trouble does not come up from the ground. Trouble does not come up from the ground."
    },
    {
      "verse": "7",
      "text": "But trouble comes to everyone, as soon as they are born. It is as certain as smoke that rises from a fire. It is as certain as smoke that rises from a fire."
    },
    {
      "verse": "8",
      "text": "I suggest that you ask God to help you. You should tell him about your problems. You should tell him about your problems."
    },
    {
      "verse": "9",
      "text": "He does great things that nobody can understand. He does more miracles than anyone can count. He does more miracles than anyone can count."
    },
    {
      "verse": "10",
      "text": "He gives rain for the earth. He sends water for the fields. He sends water for the fields."
    },
    {
      "verse": "11",
      "text": "He gives honour to humble people. When people are suffering, he puts them in a safe place. When people are suffering, he puts them in a safe place."
    },
    {
      "verse": "12",
      "text": "He stops the ideas of clever people. They cannot do what they want to do. They cannot do what they want to do."
    },
    {
      "verse": "13",
      "text": "When wise people try to do clever things, he causes those things to give them trouble. He quickly stops their clever ideas. he causes those things to give them trouble. He quickly stops their clever ideas."
    },
    {
      "verse": "14",
      "text": "In the middle of the day, it becomes dark for those people. At midday, they see no better than blind people. At midday, they see no better than blind people."
    },
    {
      "verse": "15",
      "text": "He saves poor people when wicked people attack them. He rescues weak people from the power of strong people. He rescues weak people from the power of strong people."
    },
    {
      "verse": "16",
      "text": "So poor people can hope for justice. Wicked people have to be quiet. Wicked people have to be quiet."
    },
    {
      "verse": "17",
      "text": "If Almighty God warns you to do what is right, he has blessed you. So do not be upset when he decides to do that. he has blessed you. So do not be upset when he decides to do that."
    },
    {
      "verse": "18",
      "text": "He may cause you to have pain, but he will make you well again. He may hurt you, but he will also give you health. but he will make you well again. He may hurt you, but he will also give you health."
    },
    {
      "verse": "19",
      "text": "If trouble comes to you six times, he will rescue you. No bad thing will hurt you, as often as it happens. No bad thing will hurt you, as often as it happens."
    },
    {
      "verse": "20",
      "text": "If there is a time of famine, he will keep you alive. He will protect you from death in a time of war. he will keep you alive. He will protect you from death in a time of war."
    },
    {
      "verse": "21",
      "text": "If people insult you, he will take care of you. When people attack you, you will not be afraid. When people attack you, you will not be afraid."
    },
    {
      "verse": "22",
      "text": "In times of danger and famine, you will be brave. You will not be afraid of wild animals. You will not be afraid of wild animals."
    },
    {
      "verse": "23",
      "text": "The stones in your fields will not give you trouble. The wild animals will not attack you. The wild animals will not attack you."
    },
    {
      "verse": "24",
      "text": "You will know that your home is strong and safe. When you check all your land, you will see that all your animals are safe. When you check all your land, you will see that all your animals are safe."
    },
    {
      "verse": "25",
      "text": "You will know that your children will be very many. You will have as many descendants as the grass that grows in the ground. You will have as many descendants as the grass that grows in the ground."
    },
    {
      "verse": "26",
      "text": "You will not die until you are old. You will grow with strength until you die, like crops that grow until the time of harvest. You will grow with strength until you die, like crops that grow until the time of harvest."
    },
    {
      "verse": "27",
      "text": "We have thought carefully about these things. We know that they are true. So listen to what we say. Accept it and it will be good for you. ’"
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "Then Job replied:"
    },
    {
      "verse": "2",
      "text": "‘I am so upset that nobody could measure it! My problems are too many to weigh! My problems are too many to weigh!"
    },
    {
      "verse": "3",
      "text": "They are heavier than all the sand on the shore of the sea. That is why I did not think carefully before I spoke. That is why I did not think carefully before I spoke."
    },
    {
      "verse": "4",
      "text": "Almighty God has shot his arrows into me. Their poison is now deep inside me. God has sent me many troubles that make me afraid. Their poison is now deep inside me. God has sent me many troubles that make me afraid."
    },
    {
      "verse": "5",
      "text": "A wild donkey does not complain when it has grass to eat. An ox is quiet when it has its food. An ox is quiet when it has its food."
    },
    {
      "verse": "6",
      "text": "You cannot enjoy food that has no salt in it. The white part of an egg is not nice to eat on its own. The white part of an egg is not nice to eat on its own."
    },
    {
      "verse": "7",
      "text": "I cannot eat that kind of food. It makes me ill. It makes me ill."
    },
    {
      "verse": "8",
      "text": "I want God to give me what I ask him for. I want him to answer my prayer. I want him to answer my prayer."
    },
    {
      "verse": "9",
      "text": "I would like him to destroy me. He should kill me himself. He should kill me himself."
    },
    {
      "verse": "10",
      "text": "Then I would have peace. I would be happy. I have received much cruel pain. But I have always obeyed the words of the holy God. I would be happy. I have received much cruel pain. But I have always obeyed the words of the holy God."
    },
    {
      "verse": "11",
      "text": "I am not strong enough to hope for my life to become any better. There is no reason for me to continue my life. There is no reason for me to continue my life."
    },
    {
      "verse": "12",
      "text": "I am not as strong as stones. My body is not strong like bronze. My body is not strong like bronze."
    },
    {
      "verse": "13",
      "text": "I no longer have strength to help myself. There is nowhere that I can go to get help. There is nowhere that I can go to get help."
    },
    {
      "verse": "14",
      "text": "When a man has no hope, his friends should be kind to him. They should help him, even if he no longer respects God Almighty. his friends should be kind to him. They should help him, even if he no longer respects God Almighty."
    },
    {
      "verse": "15",
      "text": "But you, my friends, have not helped me when I need you. You are like streams that quickly become dry. There is no water when you need it. You are like streams that quickly become dry. There is no water when you need it."
    },
    {
      "verse": "16",
      "text": "In the spring, ice and deep snow covers them."
    },
    {
      "verse": "17",
      "text": "But in the hot summer time, all the water disappears. Those streams become completely dry. Those streams become completely dry."
    },
    {
      "verse": "18",
      "text": "Travellers leave the road to look for water. They find no water to drink and they die in the desert. They find no water to drink and they die in the desert."
    },
    {
      "verse": "19",
      "text": "Travellers from Tema look everywhere for these streams. Traders from Sheba hope to find water. Traders from Sheba hope to find water."
    },
    {
      "verse": "20",
      "text": "They are very upset, because they expected to find water. But when they arrive, they are disappointed. But when they arrive, they are disappointed."
    },
    {
      "verse": "21",
      "text": "My friends, you have become like those streams. You see my great problem, and you are afraid. You see my great problem, and you are afraid."
    },
    {
      "verse": "22",
      "text": "I have never said to you, “Give me something to help me. Please use some of your money to rescue me. ” Please use some of your money to rescue me. ”"
    },
    {
      "verse": "23",
      "text": "I have not asked you to save me from the power of my enemy. Or to pay cruel people to let me go free. Or to pay cruel people to let me go free."
    },
    {
      "verse": "24",
      "text": "Teach me the truth, and I will listen carefully. Explain to me the mistakes that I have made. Explain to me the mistakes that I have made."
    },
    {
      "verse": "25",
      "text": "True words may give pain to the person who listens to them. But the things that you say against me mean nothing. But the things that you say against me mean nothing."
    },
    {
      "verse": "26",
      "text": "You are warning me because of what I say. I have no hope and you think that my words are empty. I have no hope and you think that my words are empty."
    },
    {
      "verse": "27",
      "text": "You would play a game to win a child who has no family. You would even sell your friends to become rich yourselves. You would even sell your friends to become rich yourselves."
    },
    {
      "verse": "28",
      "text": "But now, please look at me. I will not tell you any lies. I will not tell you any lies."
    },
    {
      "verse": "29",
      "text": "Change what you are saying about me. Do not say that I am guilty. Think again, for I am truly a good person. Do not say that I am guilty. Think again, for I am truly a good person."
    },
    {
      "verse": "30",
      "text": "I have not spoken any lies. I know what is right and what is wrong."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "People have to work very hard on this earth. They have to work every day, like servants. They have to work every day, like servants."
    },
    {
      "verse": "2",
      "text": "A servant waits for the end of the day so that he can rest. A worker waits for his master to pay him. A worker waits for his master to pay him."
    },
    {
      "verse": "3",
      "text": "But there is nothing for me to wait for. I wait for many months and nothing happens. Every night, I am always sad. I wait for many months and nothing happens. Every night, I am always sad."
    },
    {
      "verse": "4",
      "text": "When I lie down at night to sleep, I think, “How soon will the night end? ”But the night continues and I cannot sleep. Finally, dawn comes. I think, “How soon will the night end? ” But the night continues and I cannot sleep. Finally, dawn comes."
    },
    {
      "verse": "5",
      "text": "There are worms all over my body. All of my skin is painful. There are dirty sores all over it. All of my skin is painful. There are dirty sores all over it."
    },
    {
      "verse": "6",
      "text": "My life is passing very fast. Each day passes too quickly to see it! The days of my life will finish, and I cannot hope for anything to get better. Each day passes too quickly to see it! The days of my life will finish, and I cannot hope for anything to get better."
    },
    {
      "verse": "7",
      "text": "Remember, God, that my life is as short as a breath. I know that I will never be happy again. I know that I will never be happy again."
    },
    {
      "verse": "8",
      "text": "People who can see me now will not see me any more. You will look for me, but I will not be there. You will look for me, but I will not be there."
    },
    {
      "verse": "9",
      "text": "Clouds disappear and you never see them again. That is like people who die and go into their graves. They do not come back again. That is like people who die and go into their graves. They do not come back again."
    },
    {
      "verse": "10",
      "text": "They do not come back to live in their homes. People forget about them. People forget about them."
    },
    {
      "verse": "11",
      "text": "So I must continue to speak. I will tell you how upset I am. I am angry because of what has happened to me. So I must complain. I will tell you how upset I am. I am angry because of what has happened to me. So I must complain."
    },
    {
      "verse": "12",
      "text": "Why do you have to watch me, God, like a guard? Do you think that I am a dangerous monster from the sea? Do you think that I am a dangerous monster from the sea?"
    },
    {
      "verse": "13",
      "text": "When I lie down to sleep, I hope that my pain will be less. I hope that my pain will be less."
    },
    {
      "verse": "14",
      "text": "But even then you give me dreams that frighten me. I have visions which make me very afraid. I have visions which make me very afraid."
    },
    {
      "verse": "15",
      "text": "I would like someone to stop me breathing! Death would be better than life. Death would be better than life."
    },
    {
      "verse": "16",
      "text": "My life is useless. I do not want to live for ever. My life is only a short breath. So let me be alone. I do not want to live for ever. My life is only a short breath. So let me be alone."
    },
    {
      "verse": "17",
      "text": "Why do you think that people are important? Why do you watch us so carefully? Why do you watch us so carefully?"
    },
    {
      "verse": "18",
      "text": "You never leave us alone. You test us every moment of every day. You test us every moment of every day."
    },
    {
      "verse": "19",
      "text": "You never look the other way. You never leave me alone, even for a moment. You never leave me alone, even for a moment."
    },
    {
      "verse": "20",
      "text": "You carefully watch what people do. Even if I have done something wrong, it should not cause any trouble for you. So why do you choose to punish me? Even if I have done something wrong, it should not cause any trouble for you. So why do you choose to punish me?"
    },
    {
      "verse": "21",
      "text": "You should agree to forgive my sins. You should say that I am not guilty. I will soon die and I will go into my grave. Then you will carefully look for me, but I will not be there. ’"
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Job's friend Bildad, who came from Shuah, decided to speak. He said this to Job:"
    },
    {
      "verse": "2",
      "text": "‘You should not continue to talk like this. Your words are like a wind that blows strongly. Your words are like a wind that blows strongly."
    },
    {
      "verse": "3",
      "text": "Surely you know that God is fair. The Almighty God never changes right things into wrong things. The Almighty God never changes right things into wrong things."
    },
    {
      "verse": "4",
      "text": "Your children did things that were wrong. That is why God punished them. That is why God punished them."
    },
    {
      "verse": "5",
      "text": "But you should pray to Almighty God. You should ask him to help you. You should ask him to help you."
    },
    {
      "verse": "6",
      "text": "If you are honest and live in the right way, God will do something to help you. He will give you a family againthat will bring you honour. God will do something to help you. He will give you a family again that will bring you honour."
    },
    {
      "verse": "7",
      "text": "You will be successful in the future, with more riches than you had before. with more riches than you had before."
    },
    {
      "verse": "8",
      "text": "Think about the people who lived before us. Study the things that our ancestors learned. Study the things that our ancestors learned."
    },
    {
      "verse": "9",
      "text": "We have not lived for very long, so we do not know very much. Our lives are like shadows that quickly disappear. so we do not know very much. Our lives are like shadows that quickly disappear."
    },
    {
      "verse": "10",
      "text": "But the people who lived before us can teach you. They can tell you the things that they have learned. They can tell you the things that they have learned."
    },
    {
      "verse": "11",
      "text": "Some plants only grow tall in wet ground. Reeds only grow well where there is water. Reeds only grow well where there is water."
    },
    {
      "verse": "12",
      "text": "If the water is no longer there, they will quickly die. They will die before they are ready for people to cut them. They become useless more quickly than grass. they will quickly die. They will die before they are ready for people to cut them. They become useless more quickly than grass."
    },
    {
      "verse": "13",
      "text": "People who turn away from God are like those plants. Their hope quickly disappears. Their hope quickly disappears."
    },
    {
      "verse": "14",
      "text": "They trust in useless things to help them. Those things are as weak as a spider's web. Those things are as weak as a spider's web."
    },
    {
      "verse": "15",
      "text": "If they expect something like that to help them, it will fall down and leave them. If they take hold of it, it will not keep them safe. it will fall down and leave them. If they take hold of it, it will not keep them safe."
    },
    {
      "verse": "16",
      "text": "People who turn away from God are like weeds. When there is plenty of water and the sun shines on them, they grow all over the garden. When there is plenty of water and the sun shines on them, they grow all over the garden."
    },
    {
      "verse": "17",
      "text": "Their roots grow around a heap of stones. They have a strong home among the rocks. They have a strong home among the rocks."
    },
    {
      "verse": "18",
      "text": "But finally, someone pulls those weeds out of the ground. When that happens, nobody knows that the weeds were ever there. When that happens, nobody knows that the weeds were ever there."
    },
    {
      "verse": "19",
      "text": "People who are like weeds only have that kind of joy. When they disappear, other weeds grow in their place. When they disappear, other weeds grow in their place."
    },
    {
      "verse": "20",
      "text": "Listen! God never turns away from a man who is not guilty. Nor will he ever help wicked people. Nor will he ever help wicked people."
    },
    {
      "verse": "21",
      "text": "He will surely make you happy again. You will be able to laugh and shout with joy. You will be able to laugh and shout with joy."
    },
    {
      "verse": "22",
      "text": "People who hate you will be ashamed. Wicked people will have nowhere to live. ’"
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "Then Job replied. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘The things that you have said are true. But nobody can show God that he is completely good. But nobody can show God that he is completely good."
    },
    {
      "verse": "3",
      "text": "It is not possible to argue with God. God can ask 1, 000 questions that we cannot answer. God can ask 1, 000 questions that we cannot answer."
    },
    {
      "verse": "4",
      "text": "God is very wise and he is very powerful. It is impossible to argue against him and win. It is impossible to argue against him and win."
    },
    {
      "verse": "5",
      "text": "He has the power to move mountains suddenly. When he is angry he can knock them down. When he is angry he can knock them down."
    },
    {
      "verse": "6",
      "text": "He shakes the earth, to move it from its proper place. The foundations of the earth shake! to move it from its proper place. The foundations of the earth shake!"
    },
    {
      "verse": "7",
      "text": "He may command the sun not to shine during the day. He may stop the stars shining at night. He may stop the stars shining at night."
    },
    {
      "verse": "8",
      "text": "God alone put the whole sky in its place. He marches over the waves of the sea. He marches over the waves of the sea."
    },
    {
      "verse": "9",
      "text": "He put the groups of stars in their places. He made the Bear, Orion, and the Pleiades. He put the groups of stars in the southern sky. He made the Bear, Orion, and the Pleiades. He put the groups of stars in the southern sky."
    },
    {
      "verse": "10",
      "text": "He does great things that we cannot understand. He does more wonderful things than we can count. He does more wonderful things than we can count."
    },
    {
      "verse": "11",
      "text": "When God passes in front of me, I do not see him. If he moves further away, I do not see where he has gone. I do not see him. If he moves further away, I do not see where he has gone."
    },
    {
      "verse": "12",
      "text": "If God decides to take something, nobody can stop him. Nobody can ask him, “What are you doing? ” nobody can stop him. Nobody can ask him, “What are you doing? ”"
    },
    {
      "verse": "13",
      "text": "If God is angry, he will not stop. He destroys Rahab and the other monsters of the sea. He destroys Rahab and the other monsters of the sea."
    },
    {
      "verse": "14",
      "text": "So I can never give an answer to God. There are no words that I can use to argue with him. There are no words that I can use to argue with him."
    },
    {
      "verse": "15",
      "text": "Even if I am completely right, I cannot answer him. He is my judge. I can only ask him to be kind to me. I cannot answer him. He is my judge. I can only ask him to be kind to me."
    },
    {
      "verse": "16",
      "text": "He might agree to meet with me in court. But I do not believe that he would listen to me. But I do not believe that he would listen to me."
    },
    {
      "verse": "17",
      "text": "He would attack me with a strong storm. He would hurt me even more, for no reason. He would hurt me even more, for no reason."
    },
    {
      "verse": "18",
      "text": "He would not allow me to breathe quietly. Instead, he would make me very upset. Instead, he would make me very upset."
    },
    {
      "verse": "19",
      "text": "If I tried to fight God, he is much stronger than I am. And if I ask for justice, who can bring God to court? he is much stronger than I am. And if I ask for justice, who can bring God to court?"
    },
    {
      "verse": "20",
      "text": "I am right. I have not done anything that is wrong. But my words would say that I am guilty. But my words would say that I am guilty."
    },
    {
      "verse": "21",
      "text": "I have not done anything that is wrong. But it does not matter what happens to me. My life is not important to me. But it does not matter what happens to me. My life is not important to me."
    },
    {
      "verse": "22",
      "text": "The same thing happens to good people and to wicked people. So I say, “God destroys people who are not guiltyas well as those who are guilty. ” So I say, “God destroys people who are not guilty as well as those who are guilty. ”"
    },
    {
      "verse": "23",
      "text": "When disease comes, people may die suddenly. God laughs at good people who suffer like that. God laughs at good people who suffer like that."
    },
    {
      "verse": "24",
      "text": "A wicked man may have power to rule a nation. Then God stops the judges from being fair. It must be God who does that. Who else could it be? Then God stops the judges from being fair. It must be God who does that. Who else could it be?"
    },
    {
      "verse": "25",
      "text": "The days of my life are passing very quickly, like a fast runner. None of my days makes me happy. like a fast runner. None of my days makes me happy."
    },
    {
      "verse": "26",
      "text": "My days go past like a fast boat on a river. They move quickly like an eaglewhen it flies down to catch its food. They move quickly like an eagle when it flies down to catch its food."
    },
    {
      "verse": "27",
      "text": "I may try to be happy and to smile. I may try to forget about my troubles. I may try to forget about my troubles."
    },
    {
      "verse": "28",
      "text": "Even then, I will be afraid of all my pain. God, I know that you think I am guilty. God, I know that you think I am guilty."
    },
    {
      "verse": "29",
      "text": "So, if I am guilty, it is useless to do anything about it. it is useless to do anything about it."
    },
    {
      "verse": "30",
      "text": "I might wash myself with pure water. I might clean my hands with soap. I might clean my hands with soap."
    },
    {
      "verse": "31",
      "text": "But then God would throw me down into a dirty hole. Even my own clothes would be ashamed of me! Even my own clothes would be ashamed of me!"
    },
    {
      "verse": "32",
      "text": "God is not a human, as I am. So I cannot answer him. We cannot argue with each other in court. So I cannot answer him. We cannot argue with each other in court."
    },
    {
      "verse": "33",
      "text": "There is nobody who can decide which of us is right. Nobody has authority to judge both of us. Nobody has authority to judge both of us."
    },
    {
      "verse": "34",
      "text": "Nobody can stop God from punishing me. If that were possible, I would not be afraid any more. If that were possible, I would not be afraid any more."
    },
    {
      "verse": "35",
      "text": "I would speak to God and I would not be afraid. But now I cannot do that."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "I do not want to live any longer. I must continue to complain. I am very upset and I have to speak about it. I must continue to complain. I am very upset and I have to speak about it."
    },
    {
      "verse": "2",
      "text": "This is what I will say to God:“Do not say that I am guilty. Tell me what bad things you think I have done. “Do not say that I am guilty. Tell me what bad things you think I have done."
    },
    {
      "verse": "3",
      "text": "Your own hands created me. So you should not be cruel to me. It is not right. Instead, you are kind to wicked people. You help them to do the bad things that they want to do. So you should not be cruel to me. It is not right. Instead, you are kind to wicked people. You help them to do the bad things that they want to do."
    },
    {
      "verse": "4",
      "text": "Do you see things as people see them? Are your eyes only like human eyes? Are your eyes only like human eyes?"
    },
    {
      "verse": "5",
      "text": "Is your life like a human life? It is surely not as short as that! It is surely not as short as that!"
    },
    {
      "verse": "6",
      "text": "So why do you want to discover all my sins? Why do you hurry to do that? Why do you hurry to do that?"
    },
    {
      "verse": "7",
      "text": "You know that I am not guilty. But you also know that no one can save me from your power. But you also know that no one can save me from your power."
    },
    {
      "verse": "8",
      "text": "Your own hands have made me who I am. But now you are completely destroying me. But now you are completely destroying me."
    },
    {
      "verse": "9",
      "text": "Remember that you made me, like someone who uses clay to make things. Will you now make me become dust again? like someone who uses clay to make things. Will you now make me become dust again?"
    },
    {
      "verse": "10",
      "text": "You poured me like milk into my mother. There you put my body together, like milk that becomes cheese. There you put my body together, like milk that becomes cheese."
    },
    {
      "verse": "11",
      "text": "You joined my bones together, and you covered them with skin. and you covered them with skin."
    },
    {
      "verse": "12",
      "text": "You gave me life and you loved me faithfully. You took care of me and you kept me safe. You took care of me and you kept me safe."
    },
    {
      "verse": "13",
      "text": "But now I know what you have been thinking. I have discovered your secret. I have discovered your secret."
    },
    {
      "verse": "14",
      "text": "You were watching me to see if I did wrong things. Then you would refuse to forgive me. Then you would refuse to forgive me."
    },
    {
      "verse": "15",
      "text": "If I am guilty of sin, that brings terrible trouble to me. But if I am righteous, I still feel ashamed. Whatever I do, I have nothing but shameand my life is full of trouble. that brings terrible trouble to me. But if I am righteous, I still feel ashamed. Whatever I do, I have nothing but shame and my life is full of trouble."
    },
    {
      "verse": "16",
      "text": "If I try to be brave, you chase me like a hungry lion. You show your power to hurt me. you chase me like a hungry lion. You show your power to hurt me."
    },
    {
      "verse": "17",
      "text": "You find more reasons to attack me. You become more and more angry with me. You attack me with even greater power. You become more and more angry with me. You attack me with even greater power."
    },
    {
      "verse": "18",
      "text": "Why did you let me be born? I should have died before anyone saw me. I should have died before anyone saw me."
    },
    {
      "verse": "19",
      "text": "It would have been better if I had not been born. Or they should have put me in my grave, immediately after my birth. Or they should have put me in my grave, immediately after my birth."
    },
    {
      "verse": "20",
      "text": "I will only live for a few more days. So leave me alone! Then I may be happy for a moment. So leave me alone! Then I may be happy for a moment."
    },
    {
      "verse": "21",
      "text": "I will soon go to the dark place where there is no hope. I will never come back from that place. I will never come back from that place."
    },
    {
      "verse": "22",
      "text": "I will go to that very dark place where there are only shadows. In that place, it is still dark when the light shines. ” ’"
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "Job's friend Zophar, who came from Naamah, decided to speak. He said this to Job:"
    },
    {
      "verse": "2",
      "text": "‘Someone must answer all these words that you have spoken. You have talked a lot, but that does not mean that you are right. You have talked a lot, but that does not mean that you are right."
    },
    {
      "verse": "3",
      "text": "Your proud words will not cause other people to say nothing. We must make you ashamed when you laugh at us. We must make you ashamed when you laugh at us."
    },
    {
      "verse": "4",
      "text": "You have said, “The things that I teach are true. God knows that I am a good man. ” God knows that I am a good man. ”"
    },
    {
      "verse": "5",
      "text": "So God himself should answer you. He should tell you what he thinks. He should tell you what he thinks."
    },
    {
      "verse": "6",
      "text": "He would show you the secret of wisdom. True wisdom is not easy to understand. But you must understand this: God is punishing you less than you deserve. True wisdom is not easy to understand. But you must understand this: God is punishing you less than you deserve."
    },
    {
      "verse": "7",
      "text": "You cannot discover everything about God. You cannot know how powerful he is. You cannot know how powerful he is."
    },
    {
      "verse": "8",
      "text": "His power goes higher than the sky. You cannot do anything about that. His power goes deeper than the place of death. You cannot know all about that. You cannot do anything about that. His power goes deeper than the place of death. You cannot know all about that."
    },
    {
      "verse": "9",
      "text": "The truth about God is wider than the whole earth. It goes far beyond the sea. It goes far beyond the sea."
    },
    {
      "verse": "10",
      "text": "God may catch you and put you in prison. He may accuse you in a court. Nobody can stop him doing that. He may accuse you in a court. Nobody can stop him doing that."
    },
    {
      "verse": "11",
      "text": "God knows the people who are not honest. He sees the evil things that they do. He sees the evil things that they do."
    },
    {
      "verse": "12",
      "text": "Wild donkeys never give birth to human children. And foolish people never become wise! And foolish people never become wise!"
    },
    {
      "verse": "13",
      "text": "As for you, Job, you should be faithful to God. Raise your hands and pray to God. Raise your hands and pray to God."
    },
    {
      "verse": "14",
      "text": "If you want to do an evil thing, stop yourself from doing it. Do not let people do wrong things in your home. stop yourself from doing it. Do not let people do wrong things in your home."
    },
    {
      "verse": "15",
      "text": "Do what I say. Then you will not be ashamed any more. Instead, you will be strong. You will not be afraid. Instead, you will be strong. You will not be afraid."
    },
    {
      "verse": "16",
      "text": "You will forget about your trouble. It will be like water that has disappeared. You will not remember it. It will be like water that has disappeared. You will not remember it."
    },
    {
      "verse": "17",
      "text": "You will have a happy lifethat is brighter than the sun at noon. Even if trouble makes it dark, it will still seem like a bright morning. that is brighter than the sun at noon. Even if trouble makes it dark, it will still seem like a bright morning."
    },
    {
      "verse": "18",
      "text": "You will be safe as you trust God. God will protect you. You will be able to rest safely. God will protect you. You will be able to rest safely."
    },
    {
      "verse": "19",
      "text": "When you lie down to sleep, you will not be afraid of anyone. Many people will ask you to help them. you will not be afraid of anyone. Many people will ask you to help them."
    },
    {
      "verse": "20",
      "text": "But wicked people will not find any help. They cannot escape from their troubles. They can only hope to die. ’"
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "Then Job replied. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘You people think that you know everything. You think that there will be no wisdom after you die. You think that there will be no wisdom after you die."
    },
    {
      "verse": "3",
      "text": "But I understand things as well as you. You are no better than I am. Everyone knows the things that you have been saying. You are no better than I am. Everyone knows the things that you have been saying."
    },
    {
      "verse": "4",
      "text": "I am a person who prayed to God and he answered me. But my friends now laugh at me. I have always lived completely in the right way. But still my friends laugh at me. But my friends now laugh at me. I have always lived completely in the right way. But still my friends laugh at me."
    },
    {
      "verse": "5",
      "text": "Some people never have any troubles. They think that people who suffer are fools. If people are in trouble, they knock them down! They think that people who suffer are fools. If people are in trouble, they knock them down!"
    },
    {
      "verse": "6",
      "text": "But robbers seem to live in peace. They cause God to be angrybut they think that they are safe. They trust their own strength as their god. They cause God to be angry but they think that they are safe. They trust their own strength as their god."
    },
    {
      "verse": "7",
      "text": "Ask the animals and they will teach you. The birds in the sky would tell you the truth. The birds in the sky would tell you the truth."
    },
    {
      "verse": "8",
      "text": "Speak to the earth and it will teach you. The fish in the sea would tell you what is right. The fish in the sea would tell you what is right."
    },
    {
      "verse": "9",
      "text": "Any of them could tell you that the Lord has done this."
    },
    {
      "verse": "10",
      "text": "He has authority over the life of all the animals. He gives breath to all people so that they can live. He gives breath to all people so that they can live."
    },
    {
      "verse": "11",
      "text": "We use our mouths to taste food. And we use our ears to test what we hear. And we use our ears to test what we hear."
    },
    {
      "verse": "12",
      "text": "Old people are often wise. People who have lived for a long time understand things better. People who have lived for a long time understand things better."
    },
    {
      "verse": "13",
      "text": "God is wise and he is also powerful. He understands things and he gives good advice. He understands things and he gives good advice."
    },
    {
      "verse": "14",
      "text": "If God destroys something, nobody can repair it. If God puts someone in prison, that person cannot escape. nobody can repair it. If God puts someone in prison, that person cannot escape."
    },
    {
      "verse": "15",
      "text": "If God stops the rain, the land becomes dry. If he sends lots of rain, there are floods. If he sends lots of rain, there are floods."
    },
    {
      "verse": "16",
      "text": "God has strength and wisdom. He has power over people who tell lies, and the people that they deceive. He has power over people who tell lies, and the people that they deceive."
    },
    {
      "verse": "17",
      "text": "He causes clever people to become ashamed. He causes leaders to do foolish things. He causes leaders to do foolish things."
    },
    {
      "verse": "18",
      "text": "He takes authority away from kings. He dresses them like slaves. He dresses them like slaves."
    },
    {
      "verse": "19",
      "text": "He causes priests to become ashamed. He removes the power of important people. He removes the power of important people."
    },
    {
      "verse": "20",
      "text": "He stops faithful men from giving advice. He removes the wisdom of old men. He removes the wisdom of old men."
    },
    {
      "verse": "21",
      "text": "He causes rulers to be ashamed. He destroys the power of strong men. He destroys the power of strong men."
    },
    {
      "verse": "22",
      "text": "He shows people things that have been secrets. He shines light into dark places. He shines light into dark places."
    },
    {
      "verse": "23",
      "text": "He can make nations become great. He can also destroy them. He can make their land become bigger. He can also send their people away to other places. He can also destroy them. He can make their land become bigger. He can also send their people away to other places."
    },
    {
      "verse": "24",
      "text": "He stops the world's leaders from understanding things properly. He sends them to travel through empty deserts. He sends them to travel through empty deserts."
    },
    {
      "verse": "25",
      "text": "They try to walk in the dark, without any light. He causes them to walk like drunk men."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "I have seen all these things with my own eyes. I have heard everything that you have said. I have understood it. I have heard everything that you have said. I have understood it."
    },
    {
      "verse": "2",
      "text": "I know as much as you do. You are no better than I am. You are no better than I am."
    },
    {
      "verse": "3",
      "text": "But I want to speak to the Almighty God. I need to show him that I am right. I need to show him that I am right."
    },
    {
      "verse": "4",
      "text": "What you say about me is only lies. You would be useless as doctors. You would be useless as doctors."
    },
    {
      "verse": "5",
      "text": "It would be better if you said nothing. That would be a wise thing for you to do. That would be a wise thing for you to do."
    },
    {
      "verse": "6",
      "text": "Listen now to what I have to say. Listen carefully to the words that I speak. Listen carefully to the words that I speak."
    },
    {
      "verse": "7",
      "text": "You think that you can tell lies to speak on behalf of God! Your lies are not helping God. Your lies are not helping God."
    },
    {
      "verse": "8",
      "text": "You are trying to win the argument for God. But you are not being honest when you do that. But you are not being honest when you do that."
    },
    {
      "verse": "9",
      "text": "If God asks you questions, would he find that you speak the truth? Or would you try to deceive him, as you deceive other people? would he find that you speak the truth? Or would you try to deceive him, as you deceive other people?"
    },
    {
      "verse": "10",
      "text": "When you speak on God's behalf, you may think that your lies are a secret. But God will still punish you. you may think that your lies are a secret. But God will still punish you."
    },
    {
      "verse": "11",
      "text": "His great power will frighten you. You will be very afraid of him. You will be very afraid of him."
    },
    {
      "verse": "12",
      "text": "Your wise teaching is worth no more than ashes. Your arguments are weak and useless. Your arguments are weak and useless."
    },
    {
      "verse": "13",
      "text": "So be quiet now and let me speak. Then we will see what happens to me. Then we will see what happens to me."
    },
    {
      "verse": "14",
      "text": "I am ready for my life to be in danger. I must take that risk. I must take that risk."
    },
    {
      "verse": "15",
      "text": "Even if God kills me, I will still trust him. I will tell him why I am not guilty. I will tell him why I am not guilty."
    },
    {
      "verse": "16",
      "text": "I am brave enough to stand in front of God. No wicked person would be able to do that. So it shows that I am not guilty. No wicked person would be able to do that. So it shows that I am not guilty."
    },
    {
      "verse": "17",
      "text": "Listen carefully to my words. Hear what I have to say. Hear what I have to say."
    },
    {
      "verse": "18",
      "text": "I know what I want to say. I am ready to explain why I am not guilty. I am ready to explain why I am not guilty."
    },
    {
      "verse": "19",
      "text": "Nobody can show that I have done wrong things. If anyone can do that, I will be quiet. I will be ready to die. If anyone can do that, I will be quiet. I will be ready to die."
    },
    {
      "verse": "20",
      "text": "God, please do two things that will help me. If you do those things, I will no longer hide from you. If you do those things, I will no longer hide from you."
    },
    {
      "verse": "21",
      "text": "Please stop punishing me. And stop causing me to be so afraid of you. And stop causing me to be so afraid of you."
    },
    {
      "verse": "22",
      "text": "Tell me to come and stand in front of you. Then I will answer you. Or allow me to speak first. Then you will reply to me. Then I will answer you. Or allow me to speak first. Then you will reply to me."
    },
    {
      "verse": "23",
      "text": "Tell me how many wrong things I have done. Show me what my sins are. Show me what my sins are."
    },
    {
      "verse": "24",
      "text": "Why do you hide yourself from me? Why do you think that I am your enemy? Why do you think that I am your enemy?"
    },
    {
      "verse": "25",
      "text": "I am as weak as a leaf that the wind can blow away. But you still want to frighten me. I am as useless as chaff, but you still attack me. But you still want to frighten me. I am as useless as chaff, but you still attack me."
    },
    {
      "verse": "26",
      "text": "You write down things to accuse me. You punish me for the sins I did when I was young. You punish me for the sins I did when I was young."
    },
    {
      "verse": "27",
      "text": "You tie my feet with chains. You watch me carefully wherever I go. You put marks on my feet. You watch me carefully wherever I go. You put marks on my feet."
    },
    {
      "verse": "28",
      "text": "So my life is slowly disappearing. It is like a coat that moths are eating."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "Everyone that a woman gives birth to lives only for a short time. The days of his life are full of trouble. The days of his life are full of trouble."
    },
    {
      "verse": "2",
      "text": "He is like a flower that growsand then it soon dies. His life quickly disappears like a shadow. and then it soon dies. His life quickly disappears like a shadow."
    },
    {
      "verse": "3",
      "text": "I am only a human like that, so why do you watch me so carefully? Why do you want to bring me into a court to judge me? so why do you watch me so carefully? Why do you want to bring me into a court to judge me?"
    },
    {
      "verse": "4",
      "text": "People are not clean and pure. Nobody can change them to become pure. Nobody can change them to become pure."
    },
    {
      "verse": "5",
      "text": "You have decided how long people should live. You control the number of months that each person will live. Nobody can live any longer than that. You control the number of months that each person will live. Nobody can live any longer than that."
    },
    {
      "verse": "6",
      "text": "So do not watch us! Leave us alone! We must work for the time that you have decided. Please leave us to work in peace. We must work for the time that you have decided. Please leave us to work in peace."
    },
    {
      "verse": "7",
      "text": "If someone cuts down a tree, the tree may not die. New branches may grow from it. the tree may not die. New branches may grow from it."
    },
    {
      "verse": "8",
      "text": "Its roots in the ground may be old. The part of the tree that remains may be nearly dead. The part of the tree that remains may be nearly dead."
    },
    {
      "verse": "9",
      "text": "But if only a little water comes near to it, it will start to grow again. It will make new branches, like a young plant. it will start to grow again. It will make new branches, like a young plant."
    },
    {
      "verse": "10",
      "text": "But when people lose their strength and they die, that is the end. After they die, where do they go? that is the end. After they die, where do they go?"
    },
    {
      "verse": "11",
      "text": "When the water disappears from a lake or a river, they become dry. they become dry."
    },
    {
      "verse": "12",
      "text": "It is the same with people when they die. They will never rise to live again. As long as the sky remains above the earth, they will continue to sleep in death. They will never rise to live again. As long as the sky remains above the earth, they will continue to sleep in death."
    },
    {
      "verse": "13",
      "text": "Please hide me in the place where dead people go! Hide me there until you are no longer angry. Decide how long I must be there, and then remember me again! Hide me there until you are no longer angry. Decide how long I must be there, and then remember me again!"
    },
    {
      "verse": "14",
      "text": "If a man dies, will he live again? If I knew that, I would suffer patiently. I would wait until my troubles have finished. If I knew that, I would suffer patiently. I would wait until my troubles have finished."
    },
    {
      "verse": "15",
      "text": "You would call me and I would answer you. You would want to see me again, because your own hands created me. You would want to see me again, because your own hands created me."
    },
    {
      "verse": "16",
      "text": "You would watch me carefully, but you would not make a note of my sins. but you would not make a note of my sins."
    },
    {
      "verse": "17",
      "text": "You would forgive me for my sins. You would hide them away. You would hide them away."
    },
    {
      "verse": "18",
      "text": "But mountains fall down and they break into pieces, Rocks fall down from their places. Rocks fall down from their places."
    },
    {
      "verse": "19",
      "text": "Stones become sand when water pours over them. Floods wash away soil. In the same way, you remove hope from a person's life. Floods wash away soil. In the same way, you remove hope from a person's life."
    },
    {
      "verse": "20",
      "text": "Finally, you bring his life to an end. He leaves this world. You change his face in deathand you send him away. He leaves this world. You change his face in death and you send him away."
    },
    {
      "verse": "21",
      "text": "If his sons become famous, he does not know about it. If they become ashamed, he does not know that either. he does not know about it. If they become ashamed, he does not know that either."
    },
    {
      "verse": "22",
      "text": "A dead person thinks only about himself. He feels his own pain and he is very sad. ’"
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "Then Eliphaz, the man from Teman, replied to Job. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘If you were wise, you would not answer us with such silly ideas. The words that come out from inside you are only a hot wind! you would not answer us with such silly ideas. The words that come out from inside you are only a hot wind!"
    },
    {
      "verse": "3",
      "text": "No wise man would argue in such a useless way. The things that you say do not mean anything. The things that you say do not mean anything."
    },
    {
      "verse": "4",
      "text": "You show that you do not respect God. You turn other people away from him. You turn other people away from him."
    },
    {
      "verse": "5",
      "text": "It is your sin that causes you to speak like that. You try to say clever things that will deceive people. You try to say clever things that will deceive people."
    },
    {
      "verse": "6",
      "text": "I do not need to show that you are guilty. Your own words show that you are wrong. Your own words show that you are wrong."
    },
    {
      "verse": "7",
      "text": "You were not the first human to be born. You were not alive when God made the hills. You were not alive when God made the hills."
    },
    {
      "verse": "8",
      "text": "You do not know God's secret plans. You are not the only wise person in the world. You are not the only wise person in the world."
    },
    {
      "verse": "9",
      "text": "You do not know any more than we know. We understand as much as you do. We understand as much as you do."
    },
    {
      "verse": "10",
      "text": "The old men agree with us. They are older and wiser even than your father. They are older and wiser even than your father."
    },
    {
      "verse": "11",
      "text": "You think that God's kind words are not important. But they should be enough for you. But they should be enough for you."
    },
    {
      "verse": "12",
      "text": "You have allowed your thoughts to confuse you. We can see in your eyes that you are very angry. We can see in your eyes that you are very angry."
    },
    {
      "verse": "13",
      "text": "Why are you so angry against God? You should not say such wicked things. You should not say such wicked things."
    },
    {
      "verse": "14",
      "text": "No one who is human can be truly pure and righteous."
    },
    {
      "verse": "15",
      "text": "God does not even trust his own angels. He knows that they make mistakes. He knows that they make mistakes."
    },
    {
      "verse": "16",
      "text": "So he certainly will not trust people. People are wicked and cannot think true thoughts. They like to do evil things, as if they are drinking water! People are wicked and cannot think true thoughts. They like to do evil things, as if they are drinking water!"
    },
    {
      "verse": "17",
      "text": "So listen to me. I will explain something to you. I will tell you what I have seen. I will tell you what I have seen."
    },
    {
      "verse": "18",
      "text": "These are things that wise men have taught me. They did not hide the truth. They learned these things from their ancestors. They did not hide the truth. They learned these things from their ancestors."
    },
    {
      "verse": "19",
      "text": "They were the people who received the land. No foreigners were there to deceive them. No foreigners were there to deceive them."
    },
    {
      "verse": "20",
      "text": "They knew this: A wicked person will have trouble all his life. Anyone who is cruel will suffer every year that he lives. A wicked person will have trouble all his life. Anyone who is cruel will suffer every year that he lives."
    },
    {
      "verse": "21",
      "text": "He will hear things that frighten him. He may think that he is safe, but robbers will attack him. He may think that he is safe, but robbers will attack him."
    },
    {
      "verse": "22",
      "text": "He is afraid to go out in the dark. He thinks that someone may kill him. He thinks that someone may kill him."
    },
    {
      "verse": "23",
      "text": "The wicked person walks about to look for food. He says, “Where is it? ”He knows that he cannot escape from trouble. He says, “Where is it? ” He knows that he cannot escape from trouble."
    },
    {
      "verse": "24",
      "text": "He is afraid and confused. Trouble is ready to attack him, like a king with his army. Trouble is ready to attack him, like a king with his army."
    },
    {
      "verse": "25",
      "text": "That happens to the person who turns against God. He thinks that he is greater than Almighty God. He thinks that he is greater than Almighty God."
    },
    {
      "verse": "26",
      "text": "He is proud enough to attack God. He holds a big shield as he runs to attack God! He holds a big shield as he runs to attack God!"
    },
    {
      "verse": "27",
      "text": "He eats too muchand his whole body is very fat. and his whole body is very fat."
    },
    {
      "verse": "28",
      "text": "He lives in a town that is empty. No one else lives in the houses there. The buildings will soon fall downand they will become heaps of stones. No one else lives in the houses there. The buildings will soon fall down and they will become heaps of stones."
    },
    {
      "verse": "29",
      "text": "He will not be rich. He will lose his valuable things. Everything that he has will disappear. He will lose his valuable things. Everything that he has will disappear."
    },
    {
      "verse": "30",
      "text": "When it becomes dark, he will not be able to escape. He will be like a tree that fire has burned. God's breath will blow him away! he will not be able to escape. He will be like a tree that fire has burned. God's breath will blow him away!"
    },
    {
      "verse": "31",
      "text": "He may trust in useless things to save him. But he is deceiving himself. Any help that he receives will also be useless. But he is deceiving himself. Any help that he receives will also be useless."
    },
    {
      "verse": "32",
      "text": "Before he is old, his life will end. Like a tree that makes no leaves, he will have no success in life. his life will end. Like a tree that makes no leaves, he will have no success in life."
    },
    {
      "verse": "33",
      "text": "He will be like a vine that loses its grapes. They fall off before they are ready to eat. He will be like an olive tree that loses its flowers, so that no olives grow on it. They fall off before they are ready to eat. He will be like an olive tree that loses its flowers, so that no olives grow on it."
    },
    {
      "verse": "34",
      "text": "People who turn away from God are like that. They have no family to live after them. If they use the money from bribes to build their homes, fire will destroy those homes. They have no family to live after them. If they use the money from bribes to build their homes, fire will destroy those homes."
    },
    {
      "verse": "35",
      "text": "They make plans to cause trouble, so that evil things happen. Lies are what come out from inside them. ’"
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "Then Job replied. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘I have heard all these things before. You are not making my troubles any better. You are making them worse! You are not making my troubles any better. You are making them worse!"
    },
    {
      "verse": "3",
      "text": "Please stop speaking useless words. Why do you talk to me like that? Why do you talk to me like that?"
    },
    {
      "verse": "4",
      "text": "If you were suffering like I am, I could say the same things to you. I could speak for a long timeabout the wrong things that you have done. I could shake my headand laugh at you. I could say the same things to you. I could speak for a long time about the wrong things that you have done. I could shake my head and laugh at you."
    },
    {
      "verse": "5",
      "text": "But, instead, I would help you to be strong. I would say things to comfort you. I would say things to comfort you."
    },
    {
      "verse": "6",
      "text": "But now, if I speak, my pain does not become any better. If I stop speaking, my pain continues to be there. my pain does not become any better. If I stop speaking, my pain continues to be there."
    },
    {
      "verse": "7",
      "text": "God, you have made me very weak. You have destroyed my family. You have destroyed my family."
    },
    {
      "verse": "8",
      "text": "You have taken hold of me. Because of my troubles, people think that I am guilty. Because my body is so thin, people think that I have done bad things. Because of my troubles, people think that I am guilty. Because my body is so thin, people think that I have done bad things."
    },
    {
      "verse": "9",
      "text": "God attacks me and he punishes me because he is angry. He shows his anger like a wild animal. He has become my enemy. He shows his anger like a wild animal. He has become my enemy."
    },
    {
      "verse": "10",
      "text": "People insult me and they laugh at me. They hit me on my face. They all join together to attack me. They hit me on my face. They all join together to attack me."
    },
    {
      "verse": "11",
      "text": "God has allowed evil men to take hold of me. He has put me under the power of wicked men. He has put me under the power of wicked men."
    },
    {
      "verse": "12",
      "text": "I was living in peace, but then God destroyed me. He took hold of my neckand he shook me to pieces. He decided to shoot his arrows at me. but then God destroyed me. He took hold of my neck and he shook me to pieces. He decided to shoot his arrows at me."
    },
    {
      "verse": "13",
      "text": "His arrows come from all around me. They go deep into my bodyand my blood pours out on the ground. But God still does not feel sorry for me. They go deep into my body and my blood pours out on the ground. But God still does not feel sorry for me."
    },
    {
      "verse": "14",
      "text": "He attacks me again and again. He rushes to attack me like a strong fighter. He rushes to attack me like a strong fighter."
    },
    {
      "verse": "15",
      "text": "I have used sackcloth to make my clothes. I am no longer proud of my strength, and I sit in the dust. I am no longer proud of my strength, and I sit in the dust."
    },
    {
      "verse": "16",
      "text": "I have cried so much that my face is red. There are dark circles around my eyes. There are dark circles around my eyes."
    },
    {
      "verse": "17",
      "text": "But I have not been cruel. And when I pray, I speak honestly to God. And when I pray, I speak honestly to God."
    },
    {
      "verse": "18",
      "text": "The earth should not hide my blood! People should remember how I have suffered. They should not forget that I asked for justice. People should remember how I have suffered. They should not forget that I asked for justice."
    },
    {
      "verse": "19",
      "text": "But even now, I know that I have a friend in heaven. He knows that I am not guilty. He speaks on my behalf. He knows that I am not guilty. He speaks on my behalf."
    },
    {
      "verse": "20",
      "text": "My friends have turned against me. I cry with many tears as I pray to God. I cry with many tears as I pray to God."
    },
    {
      "verse": "21",
      "text": "I need someone to speak to God on my behalf. He should ask God not to punish me, as someone might try to help his friends. He should ask God not to punish me, as someone might try to help his friends."
    },
    {
      "verse": "22",
      "text": "I only have a few more years to live. I will die and I will never again return to this earth."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "I am very weak and I will soon die. Then my friends will bury me in my grave. Then my friends will bury me in my grave."
    },
    {
      "verse": "2",
      "text": "All around me, people are laughing at me. I have to watch them as they insult me. I have to watch them as they insult me."
    },
    {
      "verse": "3",
      "text": "God, please help me to become free again. Nobody else will pay the price to do that for me. Nobody else will pay the price to do that for me."
    },
    {
      "verse": "4",
      "text": "You have stopped my friends from thinking properly. So do not allow them to win the argument. So do not allow them to win the argument."
    },
    {
      "verse": "5",
      "text": "People may turn against their friendsto get things for themselves. If they do that, their children should become blind. to get things for themselves. If they do that, their children should become blind."
    },
    {
      "verse": "6",
      "text": "You have caused people to insult me, like that proverb says. People even spit at my face. like that proverb says. People even spit at my face."
    },
    {
      "verse": "7",
      "text": "I have cried so much that my eyes have become weak. My body is so thin that I am like a shadow. My body is so thin that I am like a shadow."
    },
    {
      "verse": "8",
      "text": "Good people are upset, when they see what is happening to me. They are angry with those who turn away from you. when they see what is happening to me. They are angry with those who turn away from you."
    },
    {
      "verse": "9",
      "text": "Righteous people continue to do things that are right. People who do good things become stronger. People who do good things become stronger."
    },
    {
      "verse": "10",
      "text": "But you, my friends, come here! Try again to help me, all of you! I will not find a wise man among you. Try again to help me, all of you! I will not find a wise man among you."
    },
    {
      "verse": "11",
      "text": "I will not live for many more days. I will never do the things that I wanted to do. I will never do the things that I wanted to do."
    },
    {
      "verse": "12",
      "text": "My friends say, “It is day”, when it is still night. They do not know the difference between light and dark. when it is still night. They do not know the difference between light and dark."
    },
    {
      "verse": "13",
      "text": "The only home that I hope to go to is my grave. I will lie down to sleep there in the dark. I will lie down to sleep there in the dark."
    },
    {
      "verse": "14",
      "text": "I will say to the grave, “You are my father. ”I will say to the worms that eat me, “Hello, my mother. Hello, my sister. ” “You are my father. ” I will say to the worms that eat me, “Hello, my mother. Hello, my sister. ”"
    },
    {
      "verse": "15",
      "text": "I can hope for nothing that is better than that. No one can find anything better for me. No one can find anything better for me."
    },
    {
      "verse": "16",
      "text": "When I go to the world of dead people, all my hope will have finished. Everything that I had hoped for will lie with me in the dust. ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "Then Bildad, the man from Shuah, replied. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘You should not continue to talk like that! Stop and think carefully. Then we can talk. Stop and think carefully. Then we can talk."
    },
    {
      "verse": "3",
      "text": "You should not think that we are as foolish as cows."
    },
    {
      "verse": "4",
      "text": "You are so angry that you are hurting yourself. You will never change the way that things happen in the world. Your anger will not cause the earth to shake, or any rocks to move from their places. You will never change the way that things happen in the world. Your anger will not cause the earth to shake, or any rocks to move from their places."
    },
    {
      "verse": "5",
      "text": "The light of a wicked person's life will stop shining. His fire will no longer burn brightly. His fire will no longer burn brightly."
    },
    {
      "verse": "6",
      "text": "His tent will be dark. The lamp that gives him light will stop burning. The lamp that gives him light will stop burning."
    },
    {
      "verse": "7",
      "text": "Once he was strongbut now his legs are weak. His own ideas cause him to fall down. but now his legs are weak. His own ideas cause him to fall down."
    },
    {
      "verse": "8",
      "text": "He does not know where he is goingand he walks into a dangerous trap. and he walks into a dangerous trap."
    },
    {
      "verse": "9",
      "text": "A trap catches his footand he cannot move. and he cannot move."
    },
    {
      "verse": "10",
      "text": "Someone has hidden a rope on the ground. It catches him as he walks along. It catches him as he walks along."
    },
    {
      "verse": "11",
      "text": "Everywhere a wicked person goes, things frighten him. He cannot escape from them. things frighten him. He cannot escape from them."
    },
    {
      "verse": "12",
      "text": "Now he is hungryand his strength has disappeared. Terrible trouble is ready to take hold of himwhenever it has the chance. and his strength has disappeared. Terrible trouble is ready to take hold of him whenever it has the chance."
    },
    {
      "verse": "13",
      "text": "A bad disease eats his skin. It causes his arms and his legs to become uselessand he dies. It causes his arms and his legs to become useless and he dies."
    },
    {
      "verse": "14",
      "text": "Then he has to leave his tentwhere he had lived safely. He will have to meet the terrible king of death. where he had lived safely. He will have to meet the terrible king of death."
    },
    {
      "verse": "15",
      "text": "Other people will live in his tent. They have used sulphur to burn all his things. They have used sulphur to burn all his things."
    },
    {
      "verse": "16",
      "text": "He is like a tree whose roots have become dry, and its branches have fallen off. and its branches have fallen off."
    },
    {
      "verse": "17",
      "text": "Nobody remembers that he ever lived. They have forgotten his name. They have forgotten his name."
    },
    {
      "verse": "18",
      "text": "The wicked person has had to leave this world. He has gone from a place where there is lightto a place where it is dark. He has gone from a place where there is light to a place where it is dark."
    },
    {
      "verse": "19",
      "text": "He has no children or grandchildren. He has no family to live in his home. He has no family to live in his home."
    },
    {
      "verse": "20",
      "text": "All people are very upsetwhen they see what has happened to him. Wherever they live, they are very upset. when they see what has happened to him. Wherever they live, they are very upset."
    },
    {
      "verse": "21",
      "text": "I know that this is what happens to the homes of evil people. It happens to people who turn away from God. ’"
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "Then Job replied. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘Please stop speaking to me like that! Your words continue to make me suffer. Your words continue to make me suffer."
    },
    {
      "verse": "3",
      "text": "You have insulted me many, many times. You should be ashamed to attack me like that. You should be ashamed to attack me like that."
    },
    {
      "verse": "4",
      "text": "I might have done things that are wrong. But even if that might be true, those wrong things have not hurt you. But even if that might be true, those wrong things have not hurt you."
    },
    {
      "verse": "5",
      "text": "You think that you are better people than I am. Because I have all these troubles, you say that I must be guilty. Because I have all these troubles, you say that I must be guilty."
    },
    {
      "verse": "6",
      "text": "But you should realize that God has caused all my troubles. He is the one who has caught me in his trap. He is the one who has caught me in his trap."
    },
    {
      "verse": "7",
      "text": "If I shout, “Help me, I am in trouble! ”nobody answers me. I shout to get help, but nobody comes to give me justice. nobody answers me. I shout to get help, but nobody comes to give me justice."
    },
    {
      "verse": "8",
      "text": "God has stopped meso that I cannot move forward. He has made my path darkso that I cannot see the way to go. so that I cannot move forward. He has made my path dark so that I cannot see the way to go."
    },
    {
      "verse": "9",
      "text": "He has taken away my honourso that nobody respects me. so that nobody respects me."
    },
    {
      "verse": "10",
      "text": "Everywhere that I go, God is there to attack me. He is ready to destroy me. He has taken away my hope, as if he has dug a tree out of the ground. He is ready to destroy me. He has taken away my hope, as if he has dug a tree out of the ground."
    },
    {
      "verse": "11",
      "text": "He is very angry against me. He attacks me as if I am his enemy. He attacks me as if I am his enemy."
    },
    {
      "verse": "12",
      "text": "His whole army is coming to attack me! They build a road so that they can reach me. They are all around me. They build a road so that they can reach me. They are all around me."
    },
    {
      "verse": "13",
      "text": "God has caused my brothers to stay away from me. My friends do not want to meet me. My friends do not want to meet me."
    },
    {
      "verse": "14",
      "text": "My relatives have left me. My best friends have forgotten me. My best friends have forgotten me."
    },
    {
      "verse": "15",
      "text": "Visitors who stayed in my housenow think that I am a stranger. Even my servants think that I am a foreigner. now think that I am a stranger. Even my servants think that I am a foreigner."
    },
    {
      "verse": "16",
      "text": "I tell my servant to come to mebut he does not come. I ask him to help me, but he does nothing. but he does not come. I ask him to help me, but he does nothing."
    },
    {
      "verse": "17",
      "text": "My wife moves away from the smell of my breath. My brothers stay away from me. My brothers stay away from me."
    },
    {
      "verse": "18",
      "text": "Even young children insult me. When I stand up, they laugh at me. When I stand up, they laugh at me."
    },
    {
      "verse": "19",
      "text": "My best friends hate me. People that I love have turned against me. People that I love have turned against me."
    },
    {
      "verse": "20",
      "text": "My body is now only skin and bones. I still breathe but I am only just alive. I still breathe but I am only just alive."
    },
    {
      "verse": "21",
      "text": "Please be kind to me, my friends. God has caused me to suffer, so please be kind to me. God has caused me to suffer, so please be kind to me."
    },
    {
      "verse": "22",
      "text": "Do not punish me as God is punishing me. You have already caused me to suffer enough. You have already caused me to suffer enough."
    },
    {
      "verse": "23",
      "text": "Someone should write down the words that I speak. My words should be written on a scroll. My words should be written on a scroll."
    },
    {
      "verse": "24",
      "text": "If someone uses an iron tool to write them on a rock, that would be good. Then they would never disappear. that would be good. Then they would never disappear."
    },
    {
      "verse": "25",
      "text": "As for me, I know that my Redeemer lives. I know that, in the end, he will stand on the earth. I know that, in the end, he will stand on the earth."
    },
    {
      "verse": "26",
      "text": "Illness may completely destroy my skin. But after that happens, I know that in this body I will see God. But after that happens, I know that in this body I will see God."
    },
    {
      "verse": "27",
      "text": "I will see him for myself, with my own eyes. It makes me feel weak inside as I think about it! with my own eyes. It makes me feel weak inside as I think about it!"
    },
    {
      "verse": "28",
      "text": "My friends, you should not think of ways to make me suffer even more. You say that I have caused my own trouble. You say that I have caused my own trouble."
    },
    {
      "verse": "29",
      "text": "Instead, you yourselves should be afraid of punishment! When God is angry with someone, he punishes that person. Then you will know that he is the one who judges people. ’"
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "Then Zophar replied to Job. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘I am very upset by the things that you have said. So I must say more to answer you. So I must say more to answer you."
    },
    {
      "verse": "3",
      "text": "You have said things that insult me. But now I know how to reply to you. But now I know how to reply to you."
    },
    {
      "verse": "4",
      "text": "I am sure that you know this fact. It has been true from long ago, since people first lived on the earth. It has been true from long ago, since people first lived on the earth."
    },
    {
      "verse": "5",
      "text": "You know that a wicked person is only happy for a short time. His joy continues only for a moment. His joy continues only for a moment."
    },
    {
      "verse": "6",
      "text": "He may think that he is more important than other people. He may be proud of the honour that he receives. He may be proud of the honour that he receives."
    },
    {
      "verse": "7",
      "text": "But he will disappear for ever, like dung that people throw away. His friends will ask, “Where is he? ” like dung that people throw away. His friends will ask, “Where is he? ”"
    },
    {
      "verse": "8",
      "text": "He will disappear like a dream that quickly goes away. Nobody can find him any more. Nobody can find him any more."
    },
    {
      "verse": "9",
      "text": "People who knew him will never see him again. His family will no longer recognize him. His family will no longer recognize him."
    },
    {
      "verse": "10",
      "text": "His children will have to give things back to poor people. Those are the valuable things that he took from them. Those are the valuable things that he took from them."
    },
    {
      "verse": "11",
      "text": "He still had the strength of a young man. But his strength will die with him when he lies in his grave. But his strength will die with him when he lies in his grave."
    },
    {
      "verse": "12",
      "text": "He enjoys the wicked things that he does. They are like something sweet in his mouth. They are like something sweet in his mouth."
    },
    {
      "verse": "13",
      "text": "He continues to enjoy wicked things, like the taste of sweet food that he keeps in his mouth. like the taste of sweet food that he keeps in his mouth."
    },
    {
      "verse": "14",
      "text": "But those things will become poison that hurts him. Like bitter food that goes into his stomach. Like bitter food that goes into his stomach."
    },
    {
      "verse": "15",
      "text": "Like a person who is sick and loses the food from his stomach, God will cause the wicked person to lose all his riches. God will cause the wicked person to lose all his riches."
    },
    {
      "verse": "16",
      "text": "He will drink the poison of snakes. A dangerous snake will bite him and it will kill him. A dangerous snake will bite him and it will kill him."
    },
    {
      "verse": "17",
      "text": "He will never enjoy the good things that the earth provides. He will not enjoy the honey and milk which pours out like rivers of water. He will not enjoy the honey and milk which pours out like rivers of water."
    },
    {
      "verse": "18",
      "text": "He will have to give back everything that he owned. He will not enjoy the things that he has worked for. He will not enjoy the things that he has worked for."
    },
    {
      "verse": "19",
      "text": "This will happen because he has been cruel to poor people. He has refused to help them. He has taken houses for himself that do not belong to him. He has refused to help them. He has taken houses for himself that do not belong to him."
    },
    {
      "verse": "20",
      "text": "He will always want to have more things for himself. He takes anything that he wants to have. He takes anything that he wants to have."
    },
    {
      "verse": "21",
      "text": "Now nothing remains for him to take. So his riches will come to an end. So his riches will come to an end."
    },
    {
      "verse": "22",
      "text": "When he has everything that he wants, trouble suddenly comes to him. trouble suddenly comes to him."
    },
    {
      "verse": "23",
      "text": "When he is filling himself with good food, God will punish him. God will be very angry with him. God will attack the wicked person so that he suffers. God will punish him. God will be very angry with him. God will attack the wicked person so that he suffers."
    },
    {
      "verse": "24",
      "text": "He may escape from a soldier who has an iron sword. But then a soldier will shoot a bronze arrow into him. But then a soldier will shoot a bronze arrow into him."
    },
    {
      "verse": "25",
      "text": "He pulls the arrow out of his back. His blood makes its sharp point shine brightly. He is very afraid. His blood makes its sharp point shine brightly. He is very afraid."
    },
    {
      "verse": "26",
      "text": "All his riches disappear in the dark. God will send a fire to destroy him. It will destroy all his things that remain. God will send a fire to destroy him. It will destroy all his things that remain."
    },
    {
      "verse": "27",
      "text": "The heavens will show that he is guilty. People on earth will speak against him. People on earth will speak against him."
    },
    {
      "verse": "28",
      "text": "A flood will destroy his houseand everything that he has. That will happen on the day when God punishes peoplebecause he is angry with them. and everything that he has. That will happen on the day when God punishes people because he is angry with them."
    },
    {
      "verse": "29",
      "text": "That is how God punishes wicked people. God has decided to punish them as they deserve. ’"
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "Then Job replied. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘Listen carefully to the things that I am saying. You can only help me if you do that. You can only help me if you do that."
    },
    {
      "verse": "3",
      "text": "Be patient with me so that I can speak. After you have heard what I say, you may choose to laugh at me. After you have heard what I say, you may choose to laugh at me."
    },
    {
      "verse": "4",
      "text": "It is not people that I want to argue with. So I have good reason to be upset. So I have good reason to be upset."
    },
    {
      "verse": "5",
      "text": "When you look at me, you should be upset. You should cover your mouth with your hand. You should cover your mouth with your hand."
    },
    {
      "verse": "6",
      "text": "I think about what has happened to me. It makes me very afraid. My body shakes with fear. It makes me very afraid. My body shakes with fear."
    },
    {
      "verse": "7",
      "text": "Why do wicked people continue to live for a long time? The older they become, the more power they have. The older they become, the more power they have."
    },
    {
      "verse": "8",
      "text": "They see their own children grow and become strong. Their children also have strong families. Their children also have strong families."
    },
    {
      "verse": "9",
      "text": "They are safe in their homesand they are not afraid. God does not punish them. and they are not afraid. God does not punish them."
    },
    {
      "verse": "10",
      "text": "Their cows give birth safely to many calves."
    },
    {
      "verse": "11",
      "text": "Their children run and play. They jump like young lambs. They jump like young lambs."
    },
    {
      "verse": "12",
      "text": "They enjoy the music of tambourines and harps. They sing with joy to the sound of flutes. They sing with joy to the sound of flutes."
    },
    {
      "verse": "13",
      "text": "Wicked people have plenty of money through their whole lives. Even when they die, they do not suffer. Even when they die, they do not suffer."
    },
    {
      "verse": "14",
      "text": "They say to God, “Leave us alone! We do not want to know about your ways. We do not want to know about your ways."
    },
    {
      "verse": "15",
      "text": "We do not need to serve the Almighty God. If we pray to him, there is nothing he can do to help us. ” If we pray to him, there is nothing he can do to help us. ”"
    },
    {
      "verse": "16",
      "text": "They think that they have made themselves rich. But it is not true. So I do not listen to the things that wicked people say. But it is not true. So I do not listen to the things that wicked people say."
    },
    {
      "verse": "17",
      "text": "It seems that wicked people enjoy a long life. They do not often have many troubles. When God is angry with them, he does not cause them to suffer. They do not often have many troubles. When God is angry with them, he does not cause them to suffer."
    },
    {
      "verse": "18",
      "text": "He does not blow them away, like the wind blows dry grass. They do not disappear like chaff that a storm blows away. like the wind blows dry grass. They do not disappear like chaff that a storm blows away."
    },
    {
      "verse": "19",
      "text": "You may say, “God will punish a wicked person's childrenwith the punishment that he deserves. ”But I say that God should punish the wicked person himself. Then he will realize that he is wicked. with the punishment that he deserves. ” But I say that God should punish the wicked person himself. Then he will realize that he is wicked."
    },
    {
      "verse": "20",
      "text": "Wicked people should receive their own punishment. They should see that Almighty God is angry with them. They should see that Almighty God is angry with them."
    },
    {
      "verse": "21",
      "text": "After wicked people have died, it does not matter to them if their family suffers. it does not matter to them if their family suffers."
    },
    {
      "verse": "22",
      "text": "No one can teach God what he should do. He himself judges the most powerful rulers. He himself judges the most powerful rulers."
    },
    {
      "verse": "23",
      "text": "One person has good health all his life. Even when he is ready to die, he still lives a safe and happy life. Even when he is ready to die, he still lives a safe and happy life."
    },
    {
      "verse": "24",
      "text": "He eats good food and his body is strong."
    },
    {
      "verse": "25",
      "text": "But another person is sad all his life, until he dies. No good things ever happen to him. No good things ever happen to him."
    },
    {
      "verse": "26",
      "text": "But they all die one dayand their bodies lie under the ground. Worms cover their bodies, whoever they are. and their bodies lie under the ground. Worms cover their bodies, whoever they are."
    },
    {
      "verse": "27",
      "text": "I know what you are thinking. You want to show that I am guilty. You want to show that I am guilty."
    },
    {
      "verse": "28",
      "text": "You say, “You see that the rich person no longer has a house. Wicked people no longer have homes to live in. ” Wicked people no longer have homes to live in. ”"
    },
    {
      "verse": "29",
      "text": "But you should ask people who travel to different places. You should listen to the things that they say. You should listen to the things that they say."
    },
    {
      "verse": "30",
      "text": "They would tell you that wicked people do not always suffer. When trouble comes, they continue to be safe. When God is angry with people, wicked people escape punishment. When trouble comes, they continue to be safe. When God is angry with people, wicked people escape punishment."
    },
    {
      "verse": "31",
      "text": "No one speaks against themto say that they are guilty. No one punishes themfor the bad things that they have done. to say that they are guilty. No one punishes them for the bad things that they have done."
    },
    {
      "verse": "32",
      "text": "When a wicked person dies, people bury him with honour. Guards watch over his grave. people bury him with honour. Guards watch over his grave."
    },
    {
      "verse": "33",
      "text": "A big crowd of people come to his funeral. They make a heap of earth over his body, in the valley where he rests happily. They make a heap of earth over his body, in the valley where he rests happily."
    },
    {
      "verse": "34",
      "text": "So your useless words do not comfort me. Your answers are all lies! ’"
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "Then Eliphaz, the man from Teman, replied. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘Nothing that a man can do will help God. Even a wise man cannot help God. Even a wise man cannot help God."
    },
    {
      "verse": "3",
      "text": "If you are a righteous person, it does nothing to help Almighty God. If you live a completely good life, it still does not help him. it does nothing to help Almighty God. If you live a completely good life, it still does not help him."
    },
    {
      "verse": "4",
      "text": "It is not because you respect and obey Godthat he punishes you. It is not because you are a good personthat he accuses you. that he punishes you. It is not because you are a good person that he accuses you."
    },
    {
      "verse": "5",
      "text": "No! It is because you are a very wicked person. You have done too many evil things for anyone to count them. That is why he is punishing you. You have done too many evil things for anyone to count them. That is why he is punishing you."
    },
    {
      "verse": "6",
      "text": "You took things from your friends when you lent money to them. You had no reason to do that. You even took away the only clothes that poor people were wearing. You had no reason to do that. You even took away the only clothes that poor people were wearing."
    },
    {
      "verse": "7",
      "text": "When you met people who were weak and tired, you did not give them any water to drink. You refused to feed hungry people. you did not give them any water to drink. You refused to feed hungry people."
    },
    {
      "verse": "8",
      "text": "You were a powerful man, with land that belonged to you. People respected you. Your land gave you a good life. with land that belonged to you. People respected you. Your land gave you a good life."
    },
    {
      "verse": "9",
      "text": "But you refused to help widows. You were cruel to children who have no family. You were cruel to children who have no family."
    },
    {
      "verse": "10",
      "text": "That is why you have so many troubles. That is why you shake with fear. That is why you shake with fear."
    },
    {
      "verse": "11",
      "text": "It seems to you that you are in the darkand you cannot see. You feel as if a flood of deep water covers you. and you cannot see. You feel as if a flood of deep water covers you."
    },
    {
      "verse": "12",
      "text": "God lives high above us in heaven. Look up at the stars and see how high they are! Look up at the stars and see how high they are!"
    },
    {
      "verse": "13",
      "text": "So you say, “God does not know about us. He cannot judge us, because darkness hides us from him. He cannot judge us, because darkness hides us from him."
    },
    {
      "verse": "14",
      "text": "Thick clouds cover him, so that he does not see us. He moves around high above the sky. ” so that he does not see us. He moves around high above the sky. ”"
    },
    {
      "verse": "15",
      "text": "Job, you must not continue to turn against God. That is the way that evil people lived long ago. That is the way that evil people lived long ago."
    },
    {
      "verse": "16",
      "text": "Those people died before they should have done. A great flood of water took them away. They had no safe place to stand. A great flood of water took them away. They had no safe place to stand."
    },
    {
      "verse": "17",
      "text": "They said to God, “Leave us alone! ”They thought that Almighty God could not hurt them. They thought that Almighty God could not hurt them."
    },
    {
      "verse": "18",
      "text": "But it was God who gave them many good things to enjoy. So I cannot accept the ideas of wicked people. So I cannot accept the ideas of wicked people."
    },
    {
      "verse": "19",
      "text": "God punishes wicked people. When righteous people see that happen, they are happy. Good people then laugh at wicked people. When righteous people see that happen, they are happy. Good people then laugh at wicked people."
    },
    {
      "verse": "20",
      "text": "They say, “God has destroyed our enemies. He has burned all their valuable things in a fire. ” He has burned all their valuable things in a fire. ”"
    },
    {
      "verse": "21",
      "text": "So, Job, agree to accept God's ways. Have peace in your mind about him. Then you will again have good success. Have peace in your mind about him. Then you will again have good success."
    },
    {
      "verse": "22",
      "text": "Listen to his teaching. Remember carefully what he tells you. Remember carefully what he tells you."
    },
    {
      "verse": "23",
      "text": "Turn back to the Almighty God, so that you become strong again. Stop all the evil things that happen in your house. so that you become strong again. Stop all the evil things that happen in your house."
    },
    {
      "verse": "24",
      "text": "Throw away your gold things. Throw your pure gold among the rocks in the streams. Throw your pure gold among the rocks in the streams."
    },
    {
      "verse": "25",
      "text": "Then the Almighty God will be like gold for you. He will be like your valuable silver. He will be like your valuable silver."
    },
    {
      "verse": "26",
      "text": "You will be happy that Almighty God is your friend. You will look up to him to help you. You will look up to him to help you."
    },
    {
      "verse": "27",
      "text": "You will pray to him, and he will answer you. You will do the things that you have promised to him. You will do the things that you have promised to him."
    },
    {
      "verse": "28",
      "text": "You will be able to do everything that you decide to do. Light from God will show you the right way to go. Light from God will show you the right way to go."
    },
    {
      "verse": "29",
      "text": "You will pray for God to help people who are in trouble. God will save those people who are humble. God will save those people who are humble."
    },
    {
      "verse": "30",
      "text": "God will rescue even people who are guilty. Because you do what is right, God will save those people. ’"
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "Then Job replied. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘I continue to complain against Godbecause I am still angry today. God continues to punish meeven when I cry in pain. because I am still angry today. God continues to punish me even when I cry in pain."
    },
    {
      "verse": "3",
      "text": "I would like to know where to find him. Then I could go to the place where he lives. Then I could go to the place where he lives."
    },
    {
      "verse": "4",
      "text": "I would tell him why I am not guilty. I would say many things to explain this to him. I would say many things to explain this to him."
    },
    {
      "verse": "5",
      "text": "Then I would know how he would answer me. I would understand what he would say to me. I would understand what he would say to me."
    },
    {
      "verse": "6",
      "text": "Would God use his great power to argue against me? No! He would listen carefully to me. No! He would listen carefully to me."
    },
    {
      "verse": "7",
      "text": "Honest people can explain things to him. So he would judge me in a fair way. He would let me go free. So he would judge me in a fair way. He would let me go free."
    },
    {
      "verse": "8",
      "text": "I look for God in the east, but he is not there. I do not find him in the west either. I do not find him in the west either."
    },
    {
      "verse": "9",
      "text": "When he does his work in the north, I do not see him. When he moves to the south, I still cannot find him anywhere. I do not see him. When he moves to the south, I still cannot find him anywhere."
    },
    {
      "verse": "10",
      "text": "But he knows the way that I live. When he has finished testing me, he will see that I am pure. I will be as pure as gold. When he has finished testing me, he will see that I am pure. I will be as pure as gold."
    },
    {
      "verse": "11",
      "text": "I have always lived in the way that God showed me. I have obeyed him faithfully. I have not turned away from his teaching. I have obeyed him faithfully. I have not turned away from his teaching."
    },
    {
      "verse": "12",
      "text": "I have been careful to obey his commands. His words are more important to me than my food. His words are more important to me than my food."
    },
    {
      "verse": "13",
      "text": "But he is always true to himself. Nobody can change him. Whatever he wants to do, he does. Nobody can change him. Whatever he wants to do, he does."
    },
    {
      "verse": "14",
      "text": "He will do to me everything that he has decided to do. He has plans to do many things like this. He has plans to do many things like this."
    },
    {
      "verse": "15",
      "text": "Because of that, I am afraid of him. When I think about all these things, I am very afraid. I am afraid of him. When I think about all these things, I am very afraid."
    },
    {
      "verse": "16",
      "text": "God has made me become weak with fear. Almighty God has frightened me. Almighty God has frightened me."
    },
    {
      "verse": "17",
      "text": "Because of all my troubles, I seem to be in a very dark place. The darkness seems to cover me. But I will not be afraid to speak."
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "Why has Almighty God not yet decided the timewhen he will judge wicked people? People who serve him faithfully continue to wait for justice. when he will judge wicked people? People who serve him faithfully continue to wait for justice."
    },
    {
      "verse": "2",
      "text": "Wicked men move the stones that show the edge of their neighbour's land. They take their neighbour's land and his sheep for themselves. They take their neighbour's land and his sheep for themselves."
    },
    {
      "verse": "3",
      "text": "They take away a donkeythat belongs to a child who has no family. They take an ox away from a widow, when they lend money to her. that belongs to a child who has no family. They take an ox away from a widow, when they lend money to her."
    },
    {
      "verse": "4",
      "text": "They stop poor people from receiving justice. Poor people have to run away from them and hide. Poor people have to run away from them and hide."
    },
    {
      "verse": "5",
      "text": "Poor people have to look for food to eat, like wild donkeys in the desert. They have to find food for their children to eat. like wild donkeys in the desert. They have to find food for their children to eat."
    },
    {
      "verse": "6",
      "text": "They find grain in the fields of other people. They pick grapes that remain in the vineyards of wicked people. They pick grapes that remain in the vineyards of wicked people."
    },
    {
      "verse": "7",
      "text": "They have no clothes to wear during the cold nights. They sleep without anything to cover themselves. They sleep without anything to cover themselves."
    },
    {
      "verse": "8",
      "text": "The rain that falls in the mountains makes them very wet. So they hide among the rocks where they try to keep dry. So they hide among the rocks where they try to keep dry."
    },
    {
      "verse": "9",
      "text": "When wicked people lend money to poor people, they even take a child whose father has died away from his mother. they even take a child whose father has died away from his mother."
    },
    {
      "verse": "10",
      "text": "Poor people have to go out with no clothes to wear. They are hungry while they carry the crops of other people. They are hungry while they carry the crops of other people."
    },
    {
      "verse": "11",
      "text": "They squeeze oil from olivesthat grow in the fields of other people. They also make wine from other people's grapes. But they themselves are thirsty. that grow in the fields of other people. They also make wine from other people's grapes. But they themselves are thirsty."
    },
    {
      "verse": "12",
      "text": "In the cities, people who are dying cry with pain. They call for help, but God does not punish the people who have hurt them. They call for help, but God does not punish the people who have hurt them."
    },
    {
      "verse": "13",
      "text": "Some people refuse to live in the light. They do not understand it. They do not go along the good way that it shows to them. They do not understand it. They do not go along the good way that it shows to them."
    },
    {
      "verse": "14",
      "text": "Murderers rob people when it is still dark. They kill poor, weak people during the night. They kill poor, weak people during the night."
    },
    {
      "verse": "15",
      "text": "Adulterers wait until it is becoming dark. They think that no one will see them. They cover their facesso that no one will recognize them. They think that no one will see them. They cover their faces so that no one will recognize them."
    },
    {
      "verse": "16",
      "text": "Robbers go into people's homes in the darkto take away their things. But they stay inside during the day. They never go out in the light. to take away their things. But they stay inside during the day. They never go out in the light."
    },
    {
      "verse": "17",
      "text": "They all like to do evil things at night, rather than in the light of morning. They are not afraid of things that happen in the dark, as other people are. rather than in the light of morning. They are not afraid of things that happen in the dark, as other people are."
    },
    {
      "verse": "18",
      "text": "You may say, “Floods of water carry away wicked people. God curses the land that belongs to them. Nobody goes to work in their vineyards. God curses the land that belongs to them. Nobody goes to work in their vineyards."
    },
    {
      "verse": "19",
      "text": "Snow soon disappearswhen the weather is very hot or very dry. In the same way, death quickly takes away people who do bad things. when the weather is very hot or very dry. In the same way, death quickly takes away people who do bad things."
    },
    {
      "verse": "20",
      "text": "Their mothers soon forget them. Worms eat their bodies. No one remembers those wicked people. They are like dead trees that people have cut down. Worms eat their bodies. No one remembers those wicked people. They are like dead trees that people have cut down."
    },
    {
      "verse": "21",
      "text": "Those wicked people are cruel to women who have no children. They are not kind to widows. They are not kind to widows."
    },
    {
      "verse": "22",
      "text": "But God uses his strength to remove powerful people. When he attacks wicked people, their lives are in his hands. When he attacks wicked people, their lives are in his hands."
    },
    {
      "verse": "23",
      "text": "God allows them to feel safe. But he is always watching everything that they do. But he is always watching everything that they do."
    },
    {
      "verse": "24",
      "text": "Wicked people may have success for a short time, but suddenly they disappear! Like everyone else, they fall to the ground. They become like crops that people cut down at harvest time. ” but suddenly they disappear! Like everyone else, they fall to the ground. They become like crops that people cut down at harvest time. ”"
    },
    {
      "verse": "25",
      "text": "What I have said is true. Nobody can say that I am telling lies. You cannot think that my words are useless. ’"
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "Then Bildad, the man from Shuah, replied. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘God rules everythingand we should be afraid of his great power. In heaven above he causes there to be peace. and we should be afraid of his great power. In heaven above he causes there to be peace."
    },
    {
      "verse": "3",
      "text": "The number of angels in his armies are too many to count. His light shines over everyone. His light shines over everyone."
    },
    {
      "verse": "4",
      "text": "No human is righteous when he stands in front of God. He cannot be pure. He cannot be pure."
    },
    {
      "verse": "5",
      "text": "When God looks at the moon and the stars, they do not seem to be pure and bright. they do not seem to be pure and bright."
    },
    {
      "verse": "6",
      "text": "So when God looks at us humans, we do not seem important to him. To him, we are as useless as worms. ’"
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "Then Job replied. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘Do not think that you have helped me, a weak and helpless man. Nothing that you have said makes me feel stronger. a weak and helpless man. Nothing that you have said makes me feel stronger."
    },
    {
      "verse": "3",
      "text": "What good advice have you given meto make me wise? You have not really shown me how clever you are! to make me wise? You have not really shown me how clever you are!"
    },
    {
      "verse": "4",
      "text": "Someone must have helped you to say these wise words. Who has put all these thoughts in your minds? Who has put all these thoughts in your minds?"
    },
    {
      "verse": "5",
      "text": "Dead people shake with fear. They are under the deep waters. They are under the deep waters."
    },
    {
      "verse": "6",
      "text": "God sees everything that happensin the place of dead people. Nothing can hide that terrible place from him. in the place of dead people. Nothing can hide that terrible place from him."
    },
    {
      "verse": "7",
      "text": "He puts the skies in their place in the north, so that they cover empty space. He hangs the earth in the skiesand it stays there. so that they cover empty space. He hangs the earth in the skies and it stays there."
    },
    {
      "verse": "8",
      "text": "He fills the clouds with water. They become heavy but they do not break. They become heavy but they do not break."
    },
    {
      "verse": "9",
      "text": "When the moon is big and round, he hides it. He causes clouds to cover it. He causes clouds to cover it."
    },
    {
      "verse": "10",
      "text": "He marks the border between the sea and the sky. It is the place where the night finishes and the day begins. It is the place where the night finishes and the day begins."
    },
    {
      "verse": "11",
      "text": "When God is angry, he shouts at the pillars under the sky. When they hear his command, they shake with fear. he shouts at the pillars under the sky. When they hear his command, they shake with fear."
    },
    {
      "verse": "12",
      "text": "He used his power to control the sea. He used his wisdom to destroy Rahab, the great sea monster. He used his wisdom to destroy Rahab, the great sea monster."
    },
    {
      "verse": "13",
      "text": "He used his breath to make the sky become bright. With his hand he cut the great sea snakeas it ran away. With his hand he cut the great sea snake as it ran away."
    },
    {
      "verse": "14",
      "text": "These are only a few of the things that God does. We only know about a few small things. If he used all of his power, we could never understand. ’"
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "Job continued to speak. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘Almighty God has not been fair to me. He has caused my life to be very sad. As surely as he lives, I promise this: He has caused my life to be very sad. As surely as he lives, I promise this:"
    },
    {
      "verse": "3",
      "text": "As long as God's Spirit gives me life,"
    },
    {
      "verse": "4",
      "text": "I will never speak any lies. I will always be honest. I will always be honest."
    },
    {
      "verse": "5",
      "text": "I will never agree that you, my three friends, are right. Until the day of my death, I will continue to say what I know is right. Until the day of my death, I will continue to say what I know is right."
    },
    {
      "verse": "6",
      "text": "I will never agree that I am guilty. During all of my life, my thoughts do not say that I am doing anything wrong. During all of my life, my thoughts do not say that I am doing anything wrong."
    },
    {
      "verse": "7",
      "text": "I pray that God will punish my enemiesas he punishes all wicked people. They do bad things to me, so they deserve punishment. as he punishes all wicked people. They do bad things to me, so they deserve punishment."
    },
    {
      "verse": "8",
      "text": "When God chooses to remove wicked people, they cannot hope for any good thing. God will cause them to die. they cannot hope for any good thing. God will cause them to die."
    },
    {
      "verse": "9",
      "text": "When they are in trouble and they pray for help, God will not listen to them. God will not listen to them."
    },
    {
      "verse": "10",
      "text": "People like that are not happy that Almighty God is their friend. They do not like to pray to him all the time. They do not like to pray to him all the time."
    },
    {
      "verse": "11",
      "text": "I will teach you about the power of Almighty God. I will explain to you what he is thinking. I will explain to you what he is thinking."
    },
    {
      "verse": "12",
      "text": "You yourselves have all seen what God has done. So you should stop saying all these useless things! So you should stop saying all these useless things!"
    },
    {
      "verse": "13",
      "text": "I will tell you what Almighty God does to wicked people. He punishes cruel people as they deserve. He punishes cruel people as they deserve."
    },
    {
      "verse": "14",
      "text": "Wicked people may have many children, but they will die in war. Their children will never have enough food to eat. but they will die in war. Their children will never have enough food to eat."
    },
    {
      "verse": "15",
      "text": "Illness will kill any children who continue to live. Their widows will not weep when they are dead. Their widows will not weep when they are dead."
    },
    {
      "verse": "16",
      "text": "Wicked people may have lots of money. They may have silver like heaps of sand. They may have more clothes than they could ever wear. They may have silver like heaps of sand. They may have more clothes than they could ever wear."
    },
    {
      "verse": "17",
      "text": "But one day righteous people will wear those clothes. Honest people will share the silver among themselves. Honest people will share the silver among themselves."
    },
    {
      "verse": "18",
      "text": "The houses that wicked people build are not strong. They are as weak as a spider's web, or a shepherd's hut, They are as weak as a spider's web, or a shepherd's hut,"
    },
    {
      "verse": "19",
      "text": "Their riches quickly disappear. They are rich when they go to sleep, but poor when they wake up. They are rich when they go to sleep, but poor when they wake up."
    },
    {
      "verse": "20",
      "text": "Troubles come to them like a flood of water, and they are very afraid. A storm comes in the night to carry them away. and they are very afraid. A storm comes in the night to carry them away."
    },
    {
      "verse": "21",
      "text": "The east wind picks them up and takes then far away. It removes them from their homes. It removes them from their homes."
    },
    {
      "verse": "22",
      "text": "It is a strong wind that hits wicked peopleand it never stops. It continues to beat them as they try to escape. and it never stops. It continues to beat them as they try to escape."
    },
    {
      "verse": "23",
      "text": "The cruel wind laughs at themas they run away in fear. ’"
    }
  ],
  "28": [
    {
      "verse": "1",
      "text": "‘If people want to find silver, they can dig it out of the ground. They also have places where they can make gold pure. they can dig it out of the ground. They also have places where they can make gold pure."
    },
    {
      "verse": "2",
      "text": "They know how to take iron from under the ground. They can also use heat to get copper from rocks. They can also use heat to get copper from rocks."
    },
    {
      "verse": "3",
      "text": "People take light into dark places under the ground. They look carefully for valuable metals. They look carefully for valuable metals."
    },
    {
      "verse": "4",
      "text": "They dig deep holes in the groundfar away from places where people live. Other people do not know about those places. People hang on ropes as they go deep down into the earth. far away from places where people live. Other people do not know about those places. People hang on ropes as they go deep down into the earth."
    },
    {
      "verse": "5",
      "text": "We grow our food on the earth above. But deep under the ground, people use fire to break the rocks. But deep under the ground, people use fire to break the rocks."
    },
    {
      "verse": "6",
      "text": "Sapphires come from the rocks in those places. The dust there contains gold. The dust there contains gold."
    },
    {
      "verse": "7",
      "text": "Even eagles or other birds with good eyesdo not see those places. do not see those places."
    },
    {
      "verse": "8",
      "text": "Lions and other wild animals do not walk there."
    },
    {
      "verse": "9",
      "text": "People break into the hard rocks. They turn over rocks under the mountains. They turn over rocks under the mountains."
    },
    {
      "verse": "10",
      "text": "They cut holes through the rocks. They discover stones that are very valuable. They discover stones that are very valuable."
    },
    {
      "verse": "11",
      "text": "They look carefully in the springs of waterwhere rivers start. They bring into the light things that were hidden away. where rivers start. They bring into the light things that were hidden away."
    },
    {
      "verse": "12",
      "text": "But as for wisdom, people do not know where to find it. They cannot learn how to understand things properly. people do not know where to find it. They cannot learn how to understand things properly."
    },
    {
      "verse": "13",
      "text": "Humans do not understand the value of wisdom. They cannot find it in this world where people live. They cannot find it in this world where people live."
    },
    {
      "verse": "14",
      "text": "Wisdom is not in the sea. Even in the deepest sea, no one will find it. Even in the deepest sea, no one will find it."
    },
    {
      "verse": "15",
      "text": "Nobody can buy wisdom. You may have lots of gold and silver, but you can never buy wisdom. You may have lots of gold and silver, but you can never buy wisdom."
    },
    {
      "verse": "16",
      "text": "All the pure gold from Ophir will not be enough to buy it. It is worth more than valuable onyx or sapphires. It is worth more than valuable onyx or sapphires."
    },
    {
      "verse": "17",
      "text": "Neither gold nor beautiful glass is as valuable as wisdom. A whole pot full of gold could not buy it. A whole pot full of gold could not buy it."
    },
    {
      "verse": "18",
      "text": "As for coral and jasper, they are not nearly as valuable as wisdom. Its price is more than the price of rubies. they are not nearly as valuable as wisdom. Its price is more than the price of rubies."
    },
    {
      "verse": "19",
      "text": "Topaz from Ethiopia is not as valuable as wisdom. No one can buy it, not even with pure gold. No one can buy it, not even with pure gold."
    },
    {
      "verse": "20",
      "text": "So where can we find wisdom? Where can we learn to understand things properly? Where can we learn to understand things properly?"
    },
    {
      "verse": "21",
      "text": "We cannot see where it is. No person or animal can see it. No bird that flies in the sky can see it. No person or animal can see it. No bird that flies in the sky can see it."
    },
    {
      "verse": "22",
      "text": "In the place of death, they say, “We have heard only a little about wisdom, and where to find it. ” “We have heard only a little about wisdom, and where to find it. ”"
    },
    {
      "verse": "23",
      "text": "Only God knows the way to find wisdom. Only he knows where it is. Only he knows where it is."
    },
    {
      "verse": "24",
      "text": "He can see to the ends of the earth. He knows what happens everywhere in the world. He knows what happens everywhere in the world."
    },
    {
      "verse": "25",
      "text": "He decided how strong the wind must be. He decided the size of the seas. He decided the size of the seas."
    },
    {
      "verse": "26",
      "text": "He made a command for the rainto decide where it should fall. He chose where storms should go and make thunder. to decide where it should fall. He chose where storms should go and make thunder."
    },
    {
      "verse": "27",
      "text": "Then he thought about wisdom and its value. He prepared it and he tested it. He prepared it and he tested it."
    },
    {
      "verse": "28",
      "text": "God said this to us humans:“If you want to be wise, learn to respect the Lord with fear. If you want to understand things properly, turn away from evil acts. ” ’"
    }
  ],
  "29": [
    {
      "verse": "1",
      "text": "Job continued to speak. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘I would like my life to be as it was before, many months ago. At that time, God took care of me. many months ago. At that time, God took care of me."
    },
    {
      "verse": "3",
      "text": "He was my guide, as if he had a lamp to show me the way. His light kept me safeas I walked in dark places. as if he had a lamp to show me the way. His light kept me safe as I walked in dark places."
    },
    {
      "verse": "4",
      "text": "I was strong and well. God was my friendand he protected my home. God was my friend and he protected my home."
    },
    {
      "verse": "5",
      "text": "At that time, Almighty God was still with me. My children were near me. My children were near me."
    },
    {
      "verse": "6",
      "text": "I got plenty of milk from my cows, so that my life was easy. My olive trees gave me lots of oil. so that my life was easy. My olive trees gave me lots of oil."
    },
    {
      "verse": "7",
      "text": "I would go to the gate of the city, and sit there as one of the leaders. and sit there as one of the leaders."
    },
    {
      "verse": "8",
      "text": "When young men saw me, they would move to the side. Even the old men would stand up to respect me. they would move to the side. Even the old men would stand up to respect me."
    },
    {
      "verse": "9",
      "text": "The city's rulers would stop speaking. They would cover their mouths with their hands. They would cover their mouths with their hands."
    },
    {
      "verse": "10",
      "text": "The important leaders would be quiet. They would not want to say anything. They would not want to say anything."
    },
    {
      "verse": "11",
      "text": "Everyone was very pleasedto listen to the things that I said. They respected mewhen they saw the things that I did. to listen to the things that I said. They respected me when they saw the things that I did."
    },
    {
      "verse": "12",
      "text": "When poor people cried for help, I rescued them. I helped childrenwho had no family that could help them. I rescued them. I helped children who had no family that could help them."
    },
    {
      "verse": "13",
      "text": "People who were near to death praised me for my help. Widows were happy when I helped them. Widows were happy when I helped them."
    },
    {
      "verse": "14",
      "text": "I always did what was right, like good clothes that I wore. I was fair and honest, like my coat and my hat. like good clothes that I wore. I was fair and honest, like my coat and my hat."
    },
    {
      "verse": "15",
      "text": "If people were blind, I would be their guide. If people could not walk, I would fetch things for them. I would be their guide. If people could not walk, I would fetch things for them."
    },
    {
      "verse": "16",
      "text": "If poor people needed help, I helped them like their father would do. I spoke on behalf of strangersto help them get justice. I helped them like their father would do. I spoke on behalf of strangers to help them get justice."
    },
    {
      "verse": "17",
      "text": "I destroyed the power of wicked people. I rescued the people that they had attacked. I rescued the people that they had attacked."
    },
    {
      "verse": "18",
      "text": "At that time, I thought, “I will live to be an old man. After a long life, I will die in my own home. “I will live to be an old man. After a long life, I will die in my own home."
    },
    {
      "verse": "19",
      "text": "My body is strong and well, like a tree that always has plenty of water. like a tree that always has plenty of water."
    },
    {
      "verse": "20",
      "text": "People will continue to give me honour. Each day I will have new strength. ” Each day I will have new strength. ”"
    },
    {
      "verse": "21",
      "text": "People waited patiently to hear to my advice. They listened carefully to what I said. They listened carefully to what I said."
    },
    {
      "verse": "22",
      "text": "After I had spoken, they did not say any more. They listened to every wordand they thought about it. they did not say any more. They listened to every word and they thought about it."
    },
    {
      "verse": "23",
      "text": "They would wait for me to speak to them, like people who wait for rain to fall. My words would make them happy, like rain in spring that makes a farmer happy. like people who wait for rain to fall. My words would make them happy, like rain in spring that makes a farmer happy."
    },
    {
      "verse": "24",
      "text": "They were surprised when I smiled at them. My smile made them happy. My smile made them happy."
    },
    {
      "verse": "25",
      "text": "As their leader, I told them what they should do. I was like a king who leads his soldiers. When they were sad, I would comfort them. ’"
    }
  ],
  "30": [
    {
      "verse": "1",
      "text": "‘But now it is different. Men who are younger than I am laugh at me. I would not even trust their fathersto take care of my sheep. Men who are younger than I am laugh at me. I would not even trust their fathers to take care of my sheep."
    },
    {
      "verse": "2",
      "text": "The work that those old men could do was no help to me. They no longer were strong. They no longer were strong."
    },
    {
      "verse": "3",
      "text": "They were weak and thin because they were hungry. They had to look for food in the desert at night. They found roots to eat in dry places. They had to look for food in the desert at night. They found roots to eat in dry places."
    },
    {
      "verse": "4",
      "text": "They pulled up plants in the desertas their food. They burned the roots of bushesto keep themselves warm. as their food. They burned the roots of bushes to keep themselves warm."
    },
    {
      "verse": "5",
      "text": "People chased them away from their towns, as if they were shouting at robbers. as if they were shouting at robbers."
    },
    {
      "verse": "6",
      "text": "They had to live in dry valleys, among the rocks, or in caves. among the rocks, or in caves."
    },
    {
      "verse": "7",
      "text": "They cried aloud like animals among the bushes. They hid together under the thorn bushes. They hid together under the thorn bushes."
    },
    {
      "verse": "8",
      "text": "They were foolish people that nobody respected. People chased them away from their land. People chased them away from their land."
    },
    {
      "verse": "9",
      "text": "But now their sons sing songs that insult me. They tell jokes about me. They tell jokes about me."
    },
    {
      "verse": "10",
      "text": "They hate meand they do not come near me. When they see me, they spit at my face. and they do not come near me. When they see me, they spit at my face."
    },
    {
      "verse": "11",
      "text": "God has made me weak and helpless. People do to me anything that they want to do. People do to me anything that they want to do."
    },
    {
      "verse": "12",
      "text": "From one side, the crowd attacks me. They make me run away. They are like an army that builds a roadto come and attack me. They make me run away. They are like an army that builds a road to come and attack me."
    },
    {
      "verse": "13",
      "text": "They stop me from escaping. They are ready to destroy me. They do not need anyone to help them. They are ready to destroy me. They do not need anyone to help them."
    },
    {
      "verse": "14",
      "text": "I cannot stop them when they attack me. They rush forward to knock me down. They rush forward to knock me down."
    },
    {
      "verse": "15",
      "text": "So I am always afraid. My honour has disappearedas if a strong wind has blown it away. My riches have also gone, like a cloud that passes across the sky. My honour has disappeared as if a strong wind has blown it away. My riches have also gone, like a cloud that passes across the sky."
    },
    {
      "verse": "16",
      "text": "Now I know that my life will soon end. Every day I continue to suffer. Every day I continue to suffer."
    },
    {
      "verse": "17",
      "text": "At night, my bones are painful. The pain is always there in my body. The pain is always there in my body."
    },
    {
      "verse": "18",
      "text": "God has used his power to take hold of me. He has held my shirt around my neck. He has held my shirt around my neck."
    },
    {
      "verse": "19",
      "text": "He has thrown me down into the mud. I am no better than dust and ashes on the ground. I am no better than dust and ashes on the ground."
    },
    {
      "verse": "20",
      "text": "I call aloud to you, God, but you do not answer me. When I stand to pray, you only look at me. but you do not answer me. When I stand to pray, you only look at me."
    },
    {
      "verse": "21",
      "text": "You have become cruel to me. You have used your strength to attack me. You have used your strength to attack me."
    },
    {
      "verse": "22",
      "text": "You take hold of me and you carry me away, like a strong wind that blows. You use a storm to destroy me. like a strong wind that blows. You use a storm to destroy me."
    },
    {
      "verse": "23",
      "text": "I know that you are already taking me to my death. Everyone who lives has to go to that place. Everyone who lives has to go to that place."
    },
    {
      "verse": "24",
      "text": "When someone is weak and in trouble, people do not usually try to hurt him. When someone calls aloud for help, they do not refuse to help him. people do not usually try to hurt him. When someone calls aloud for help, they do not refuse to help him."
    },
    {
      "verse": "25",
      "text": "When other people were in trouble, I wept for them. When I saw poor peopleit made me very upset. I wept for them. When I saw poor people it made me very upset."
    },
    {
      "verse": "26",
      "text": "But when I hoped for good things to happen, trouble came instead. When I looked for light to shine on me, everything became dark. trouble came instead. When I looked for light to shine on me, everything became dark."
    },
    {
      "verse": "27",
      "text": "I hurt inside me all the time. Every day I suffer from pain. Every day I suffer from pain."
    },
    {
      "verse": "28",
      "text": "Illness has caused my skin to become black. It is not the sun that has made that happen. I stand up in the public meeting placeand I call aloud for help. It is not the sun that has made that happen. I stand up in the public meeting place and I call aloud for help."
    },
    {
      "verse": "29",
      "text": "I have become like the jackals and the ostriches. My sad voice sounds like them. My sad voice sounds like them."
    },
    {
      "verse": "30",
      "text": "My skin has become black, and bits of skin fall off. My body is hot with fever. and bits of skin fall off. My body is hot with fever."
    },
    {
      "verse": "31",
      "text": "Now, when I make music with my harp, I only sing funeral songs. When I make music with my flute, I do it for people who are weeping. ’"
    }
  ],
  "31": [
    {
      "verse": "1",
      "text": "‘I have made a promise with myselfabout how I look at young women. I will never think that I want to have sex with them. about how I look at young women. I will never think that I want to have sex with them."
    },
    {
      "verse": "2",
      "text": "Anyone who does that should expect God to punish them. Almighty God in heaven above punishes people who do wrong things. Almighty God in heaven above punishes people who do wrong things."
    },
    {
      "verse": "3",
      "text": "He sends trouble to people who do wicked things. He punishes those people who do evil things. He punishes those people who do evil things."
    },
    {
      "verse": "4",
      "text": "God sees all the things that I do. He carefully watches how I live my life. He carefully watches how I live my life."
    },
    {
      "verse": "5",
      "text": "He must know that I am an honest man. I have never tried to deceive people. I have never tried to deceive people."
    },
    {
      "verse": "6",
      "text": "So he should judge me in a fair way. He should realize that I am not guilty. He should realize that I am not guilty."
    },
    {
      "verse": "7",
      "text": "God seems to think that I have not lived in the right way. He may think that I have wanted bad thingswhen they looked nice to me. Or perhaps I have done something else that was wrong. He may think that I have wanted bad things when they looked nice to me. Or perhaps I have done something else that was wrong."
    },
    {
      "verse": "8",
      "text": "If am really guilty of these things, someone else should eat the crops that I have planted. They should destroy all the crops in my fields. someone else should eat the crops that I have planted. They should destroy all the crops in my fields."
    },
    {
      "verse": "9",
      "text": "I have not wanted to love any womanexcept my wife. I have not hidden outside my friend's houseto wait for his wife to be alone. except my wife. I have not hidden outside my friend's house to wait for his wife to be alone."
    },
    {
      "verse": "10",
      "text": "If I had done those things, my wife should prepare food for another man. It would be right for other men to have sex with her. my wife should prepare food for another man. It would be right for other men to have sex with her."
    },
    {
      "verse": "11",
      "text": "I would not have been faithful to my wife. I would have done a wicked thingand I would deserve punishment. I would have done a wicked thing and I would deserve punishment."
    },
    {
      "verse": "12",
      "text": "If I loved another woman, it would be like a dangerous fire. It would destroy everything that I have worked hard to get. it would be like a dangerous fire. It would destroy everything that I have worked hard to get."
    },
    {
      "verse": "13",
      "text": "When my servants complain against me, I have always been fair to them. I have always been fair to them."
    },
    {
      "verse": "14",
      "text": "If I had been cruel to them, God would be right to punish me. When God judges me, I would have no answer to excuse myself. God would be right to punish me. When God judges me, I would have no answer to excuse myself."
    },
    {
      "verse": "15",
      "text": "God made me and he made my servants too. God brought us all to birth. God brought us all to birth."
    },
    {
      "verse": "16",
      "text": "I have never refused to help people who are poor. I have always helped widowsto hope for good things. I have always helped widows to hope for good things."
    },
    {
      "verse": "17",
      "text": "I have never kept all my food for myself. I have always shared it with children who have no family. I have always shared it with children who have no family."
    },
    {
      "verse": "18",
      "text": "Since I was a young man, I have helped those children like a father. All my life I have helped widows too. I have helped those children like a father. All my life I have helped widows too."
    },
    {
      "verse": "19",
      "text": "I have seen people without enough clothes to keep them warm, or without a coat to wear. or without a coat to wear."
    },
    {
      "verse": "20",
      "text": "Then I would give them clothes. The wool from my sheep would keep them warm. And they all thanked me. The wool from my sheep would keep them warm. And they all thanked me."
    },
    {
      "verse": "21",
      "text": "I have not turned against children who have no family, even when the city judges agreed with me. even when the city judges agreed with me."
    },
    {
      "verse": "22",
      "text": "God should punish me if these things are not true. I would accept the punishment that I deserve. I would accept the punishment that I deserve."
    },
    {
      "verse": "23",
      "text": "I was afraid of the trouble that God might bring to me. So I could not do these bad things, because God is so great and powerful. So I could not do these bad things, because God is so great and powerful."
    },
    {
      "verse": "24",
      "text": "I have not trusted in money or in gold. I have never thought that they would make me strong. I have never thought that they would make me strong."
    },
    {
      "verse": "25",
      "text": "When I was very rich, I was not proud about it. I did not think that I had worked hard to deserve it. I was not proud about it. I did not think that I had worked hard to deserve it."
    },
    {
      "verse": "26",
      "text": "I have looked at the sun when it shines brightly. And I have seen the moon when it is very beautiful. And I have seen the moon when it is very beautiful."
    },
    {
      "verse": "27",
      "text": "But I have never wanted to worship themor to give them honour. or to give them honour."
    },
    {
      "verse": "28",
      "text": "If I had done that, I would not have been faithful to God in heaven. I would have deserved punishment for that sin. I would not have been faithful to God in heaven. I would have deserved punishment for that sin."
    },
    {
      "verse": "29",
      "text": "I do not laugh at my enemieswhen they suffer. If my enemy has troubles, it does not make me happy. when they suffer. If my enemy has troubles, it does not make me happy."
    },
    {
      "verse": "30",
      "text": "I have not cursed my enemies, to ask God to kill them. That would have caused a sin to come from my mouth! to ask God to kill them. That would have caused a sin to come from my mouth!"
    },
    {
      "verse": "31",
      "text": "None of the people who work in my house have ever said, “Job has not welcomed strangers into his house. He has not shared his food with them. ” “Job has not welcomed strangers into his house. He has not shared his food with them. ”"
    },
    {
      "verse": "32",
      "text": "Travellers may come to sleep in my house. They do not have to sleep outside in the street. They do not have to sleep outside in the street."
    },
    {
      "verse": "33",
      "text": "I do not try to hide my sins, as some people do. as some people do."
    },
    {
      "verse": "34",
      "text": "I am not afraid of what people think about me. Even if a great crowd of people speak against me, I do not stay inside my house and keep quiet. Even if a great crowd of people speak against me, I do not stay inside my house and keep quiet."
    },
    {
      "verse": "35",
      "text": "I want someone to listen to me! All the things that I say are true. Almighty God should give me an answer! I need to know what I have done that is wrong. He should write down the reason why I am guilty! All the things that I say are true. Almighty God should give me an answer! I need to know what I have done that is wrong. He should write down the reason why I am guilty!"
    },
    {
      "verse": "36",
      "text": "Then I would show that paper clearly on my shoulders. I would be proud to wear it like a crown on my head. I would be proud to wear it like a crown on my head."
    },
    {
      "verse": "37",
      "text": "I would explain to God everything that I have done. I would stand in front of him without fear, like a ruler. I would stand in front of him without fear, like a ruler."
    },
    {
      "verse": "38",
      "text": "I have not grown crops on land that does not belong to me. The land itself would accuse me if that were true. The land itself would accuse me if that were true."
    },
    {
      "verse": "39",
      "text": "I have always paid for the foodthat other people have worked to grow. I have never cheated the farmersso that they suffered. that other people have worked to grow. I have never cheated the farmers so that they suffered."
    },
    {
      "verse": "40",
      "text": "If I have ever done any of those things, then may thorn bushes grow in my fields instead of wheat. May weeds grow in my fields instead of barley. ’That is the end of the things that Job said."
    }
  ],
  "32": [
    {
      "verse": "1",
      "text": "Job would not agree that he had done anything that was wrong. So his three friends refused to argue with him any more."
    },
    {
      "verse": "2",
      "text": "Another man was also there. His name was Elihu, Barakel's son. Barakel was a descendant of Buz. He belonged to Ram's clan. Elihu became very angry with Job. He was angry because Job continued to say that he was not guilty. Job said that God was wrong to punish him."
    },
    {
      "verse": "3",
      "text": "Elihu was also angry with Job's three friends. They had not been able to find an answer to Job's problem. But they still said that Job was guilty."
    },
    {
      "verse": "4",
      "text": "Elihu had waited for Job's three friends to speak before he spoke to Job himself. He waited because he was younger than them."
    },
    {
      "verse": "5",
      "text": "But he became angry when Job's three friends had nothing more to say. So he finally decided to speak."
    },
    {
      "verse": "6",
      "text": "Barakel's son, Elihu, said this:‘I am young and you are old. So I was afraid to tell you what I was thinking. ‘I am young and you are old. So I was afraid to tell you what I was thinking."
    },
    {
      "verse": "7",
      "text": "I thought, “Older men should speak. They have lived for many years and they should share their wisdom. ” They have lived for many years and they should share their wisdom. ”"
    },
    {
      "verse": "8",
      "text": "But it is a person's spirit that helps them to understand things. Almighty God has to put his breath into them. Almighty God has to put his breath into them."
    },
    {
      "verse": "9",
      "text": "Not all old people are wise. Old people do not always understand what is right. Old people do not always understand what is right."
    },
    {
      "verse": "10",
      "text": "So I say, “Listen to me. I too will explain what I know. ” I too will explain what I know. ”"
    },
    {
      "verse": "11",
      "text": "Yes, I waited for you all to speak. I listened to your wise thoughts, as you tried to find the right words to say. I listened to your wise thoughts, as you tried to find the right words to say."
    },
    {
      "verse": "12",
      "text": "I listened carefully to you, as you argued with Job. But none of you could show Job that he was wrong. None of you was able to answer his problems. as you argued with Job. But none of you could show Job that he was wrong. None of you was able to answer his problems."
    },
    {
      "verse": "13",
      "text": "So do not say, “We are wise. ”Do not say, “God must show Job that he is wrong. People cannot do that. ” Do not say, “God must show Job that he is wrong. People cannot do that. ”"
    },
    {
      "verse": "14",
      "text": "Job was not speaking to me about his problems. So I will not answer him in the way that you did. So I will not answer him in the way that you did."
    },
    {
      "verse": "15",
      "text": "Now they are upset! They have no more answers to give. There is nothing more that they can say. They have no more answers to give. There is nothing more that they can say."
    },
    {
      "verse": "16",
      "text": "I have waited for them, and now they say nothing. They stand there and they have no more answers. and now they say nothing. They stand there and they have no more answers."
    },
    {
      "verse": "17",
      "text": "So now I will say what I think. I, too, will tell you what I know. I, too, will tell you what I know."
    },
    {
      "verse": "18",
      "text": "There are many things that I want to say. The spirit inside me causes me to speak. The spirit inside me causes me to speak."
    },
    {
      "verse": "19",
      "text": "I cannot keep quiet any longer! I am like a bag that is full of new wine. I am ready to break so that everything pours out! I am like a bag that is full of new wine. I am ready to break so that everything pours out!"
    },
    {
      "verse": "20",
      "text": "So I have to speak or I will become ill. I must open my mouth and reply to you. I must open my mouth and reply to you."
    },
    {
      "verse": "21",
      "text": "I will be fair in what I say. I will not give honour to anyone to get their help. I will not give honour to anyone to get their help."
    },
    {
      "verse": "22",
      "text": "I am too honest to do that. If I am not fair, God, my Maker, would quickly remove me. ’"
    }
  ],
  "33": [
    {
      "verse": "1",
      "text": "‘But now, Job, listen to the things that I will tell you. Listen carefully to everything that I will say. Listen carefully to everything that I will say."
    },
    {
      "verse": "2",
      "text": "I will speak to you now. I am ready to tell you what I think. I am ready to tell you what I think."
    },
    {
      "verse": "3",
      "text": "I am an honest man, so you can believe what I say. I will tell you what I know is true. I will tell you what I know is true."
    },
    {
      "verse": "4",
      "text": "The Spirit of Almighty God has made me. His breath gives me life. His breath gives me life."
    },
    {
      "verse": "5",
      "text": "Answer me now, Job, if you can. Prepare yourself. Be ready to explain your problem to me. Prepare yourself. Be ready to explain your problem to me."
    },
    {
      "verse": "6",
      "text": "Listen! When God looks at us, we are the same as each other. God used clay to make both of us. we are the same as each other. God used clay to make both of us."
    },
    {
      "verse": "7",
      "text": "So you should not be afraid of me. I will not do anything to hurt you. I will not do anything to hurt you."
    },
    {
      "verse": "8",
      "text": "I have heard the things that you have said, Job. This is what I heard you say: This is what I heard you say:"
    },
    {
      "verse": "9",
      "text": "“I am not guilty. I have not done anything that is wrong. I am pure and clean. I am pure and clean."
    },
    {
      "verse": "10",
      "text": "But God has decided to punish me! He attacks me as if I am his enemy. He attacks me as if I am his enemy."
    },
    {
      "verse": "11",
      "text": "He has tied my feet with chains. He always watches me to see where I go. ” He always watches me to see where I go. ”"
    },
    {
      "verse": "12",
      "text": "But now I tell you this, Job: You are not right! God is greater than any human. God is greater than any human."
    },
    {
      "verse": "13",
      "text": "So you should not argue against him. You should not say, “God does not answer any of my questions. ” You should not say, “God does not answer any of my questions. ”"
    },
    {
      "verse": "14",
      "text": "God does speak to people. He speaks to them in many different ways. But often people do not recognize his voice. He speaks to them in many different ways. But often people do not recognize his voice."
    },
    {
      "verse": "15",
      "text": "Sometimes God speaks to people in dreams and visions. He speaks to them at night, while they sleep in bed. He speaks to them at night, while they sleep in bed."
    },
    {
      "verse": "16",
      "text": "He tells them about things that will happen. He warns them about terrible things, so that they are afraid. He warns them about terrible things, so that they are afraid."
    },
    {
      "verse": "17",
      "text": "He tells them to turn away from their sins. He tells them not to be proud. He tells them not to be proud."
    },
    {
      "verse": "18",
      "text": "He keeps people safe from death, so that they do not go to their graves. so that they do not go to their graves."
    },
    {
      "verse": "19",
      "text": "Or God may warn people with a painful illness. He may make their bodies hurt all the time. He may make their bodies hurt all the time."
    },
    {
      "verse": "20",
      "text": "Then they do not want to eat anything. They cannot eat even the best food. They cannot eat even the best food."
    },
    {
      "verse": "21",
      "text": "Their bodies become very thin. People can even see their bones. People can even see their bones."
    },
    {
      "verse": "22",
      "text": "They will soon die and go to their graves. Death is waiting to take them away. Death is waiting to take them away."
    },
    {
      "verse": "23",
      "text": "But perhaps an angel may cometo help one of those people. He may speak on behalf of God, as a special angel among the many thousands of God's angels. The angel may tell that personhow to live in a way that is right. to help one of those people. He may speak on behalf of God, as a special angel among the many thousands of God's angels. The angel may tell that person how to live in a way that is right."
    },
    {
      "verse": "24",
      "text": "Then God will be kind to that person. God will say, “Save that person, so that he does not go to his grave. I have found someone to pay the price for his life. So keep him alive. ” God will say, “Save that person, so that he does not go to his grave. I have found someone to pay the price for his life. So keep him alive. ”"
    },
    {
      "verse": "25",
      "text": "Then that person's body will become healthy again. He will be strong, like a young man. He will be strong, like a young man."
    },
    {
      "verse": "26",
      "text": "When he prays to God, God will be happy to answer him. He will again worship God with joy. And God will give him a good way of life again. God will be happy to answer him. He will again worship God with joy. And God will give him a good way of life again."
    },
    {
      "verse": "27",
      "text": "That person will say clearly to everyone, “I did things that were not right. I did wrong things, but God did not punish me as I deserved. “I did things that were not right. I did wrong things, but God did not punish me as I deserved."
    },
    {
      "verse": "28",
      "text": "God rescued me from death, so that I did not go to my grave. Now I will enjoy life in the light. ” so that I did not go to my grave. Now I will enjoy life in the light. ”"
    },
    {
      "verse": "29",
      "text": "God does all these things for people. He does them many times. He does them many times."
    },
    {
      "verse": "30",
      "text": "He saves a person from death, so that he does not go to his grave. He gives light to that person, so that he may enjoy his life. so that he does not go to his grave. He gives light to that person, so that he may enjoy his life."
    },
    {
      "verse": "31",
      "text": "Job, listen carefully to me. Be quiet, and I will speak to you. Be quiet, and I will speak to you."
    },
    {
      "verse": "32",
      "text": "After that, you may answer me, if you have something to say. If I could say that you have not done anything wrong, that would make me happy. if you have something to say. If I could say that you have not done anything wrong, that would make me happy."
    },
    {
      "verse": "33",
      "text": "But if you have nothing to say, then listen to me. Be quiet and I will teach you how to be wise. ’"
    }
  ],
  "34": [
    {
      "verse": "1",
      "text": "Elihu continued speaking and he said this:"
    },
    {
      "verse": "2",
      "text": "‘You men who are so wise and who know so much, listen to me. Hear what I have to say. listen to me. Hear what I have to say."
    },
    {
      "verse": "3",
      "text": "You recognize nice food when you eat it. So you should recognize the value of my words. So you should recognize the value of my words."
    },
    {
      "verse": "4",
      "text": "We should decide among ourselves what is right. We should agree together what is good. We should agree together what is good."
    },
    {
      "verse": "5",
      "text": "Job has said, “I am not guilty. But God refuses to judge me in a fair way. But God refuses to judge me in a fair way."
    },
    {
      "verse": "6",
      "text": "I am right, but nobody believes me. I have not done anything wrong, but I am sufferingand I am near to death. ” but nobody believes me. I have not done anything wrong, but I am suffering and I am near to death. ”"
    },
    {
      "verse": "7",
      "text": "There has never been a man like Job! He laughs at God as easily as he drinks water. He laughs at God as easily as he drinks water."
    },
    {
      "verse": "8",
      "text": "He is a friend of wicked people, and people who do evil things. and people who do evil things."
    },
    {
      "verse": "9",
      "text": "Job says, “If anyone tries to please God, it does not help them at all. ” it does not help them at all. ”"
    },
    {
      "verse": "10",
      "text": "So listen to me, you men who understand so much. Almighty God can never do anything that is wrong or wicked! Almighty God can never do anything that is wrong or wicked!"
    },
    {
      "verse": "11",
      "text": "He judges people fairlyas he sees the things that they do. He gives people what they deserve. as he sees the things that they do. He gives people what they deserve."
    },
    {
      "verse": "12",
      "text": "It is true! Almighty God does not do wicked things. He never refuses to judge people in a fair way. He never refuses to judge people in a fair way."
    },
    {
      "verse": "13",
      "text": "God's great power did not come from anyone else! He himself has authority over the whole world. He himself has authority over the whole world."
    },
    {
      "verse": "14",
      "text": "God could decide to remove life from the world. He could take back his spirit and his breath. He could take back his spirit and his breath."
    },
    {
      "verse": "15",
      "text": "If he did that, everyone that is alive would die. As humans, we would become dirt again. As humans, we would become dirt again."
    },
    {
      "verse": "16",
      "text": "If you really understand things, Job, listen to me. Hear what I have to say. Hear what I have to say."
    },
    {
      "verse": "17",
      "text": "If God refused to do what is right, he could not rule the world. He is the powerful Judge who knows what is right. But you say that he is guilty! he could not rule the world. He is the powerful Judge who knows what is right. But you say that he is guilty!"
    },
    {
      "verse": "18",
      "text": "It is God who may say to a king, “You are useless! ”He may say to rulers, “You are wicked! ” He may say to rulers, “You are wicked! ”"
    },
    {
      "verse": "19",
      "text": "God created everyone. He is not more kind to important peoplethan he is to other people. He does not help rich peoplemore than he helps poor people. He is not more kind to important people than he is to other people. He does not help rich people more than he helps poor people."
    },
    {
      "verse": "20",
      "text": "Anyone may die suddenly, in the middle of the night. God may shake them, so that they die. He easily removes even the most powerful people. in the middle of the night. God may shake them, so that they die. He easily removes even the most powerful people."
    },
    {
      "verse": "21",
      "text": "He watches the way that each person lives. He sees what they do every day. He sees what they do every day."
    },
    {
      "verse": "22",
      "text": "People who do wicked things cannot hide themselves. There is no place dark enough for them to hide from God. There is no place dark enough for them to hide from God."
    },
    {
      "verse": "23",
      "text": "God does not have to tell people when they must come to him, so that he can judge them. so that he can judge them."
    },
    {
      "verse": "24",
      "text": "He destroys powerful people, and he chooses other people to take their place. He does not have to ask them anything. and he chooses other people to take their place. He does not have to ask them anything."
    },
    {
      "verse": "25",
      "text": "He already knows the things that they have done. In the night, he removes their power, and he destroys them. In the night, he removes their power, and he destroys them."
    },
    {
      "verse": "26",
      "text": "He punishes thembecause they have done wicked things. He does that where everyone can see. because they have done wicked things. He does that where everyone can see."
    },
    {
      "verse": "27",
      "text": "Those powerful people have turned away from God. They have not respected his commands. They have not respected his commands."
    },
    {
      "verse": "28",
      "text": "They were cruel to poor people, so that God saw what was happening. God heard those poor peoplewhen they called to him for help. so that God saw what was happening. God heard those poor people when they called to him for help."
    },
    {
      "verse": "29",
      "text": "But if God decides to do nothing, no one can say that he is wrong. If he hides himself, no one can see him. But he still rules over people and over nations. no one can say that he is wrong. If he hides himself, no one can see him. But he still rules over people and over nations."
    },
    {
      "verse": "30",
      "text": "God does not let men rule, if they do not respect his ways. He stops them from causing trouble to the people. if they do not respect his ways. He stops them from causing trouble to the people."
    },
    {
      "verse": "31",
      "text": "Someone could say to God, “I am guilty, and I have received my punishment. But I will not do any more wrong things. and I have received my punishment. But I will not do any more wrong things."
    },
    {
      "verse": "32",
      "text": "Show me the sins that I have donewhen I did not know about them. If I have done wrong things, I will not do them again. ” when I did not know about them. If I have done wrong things, I will not do them again. ”"
    },
    {
      "verse": "33",
      "text": "But you, Job, refuse to accept God's justice. Do you expect God to do what you think is right? But you must choose what you will say. I cannot decide for you. So tell us what you are thinking now. Do you expect God to do what you think is right? But you must choose what you will say. I cannot decide for you. So tell us what you are thinking now."
    },
    {
      "verse": "34",
      "text": "Wise people will agree with me. When they hear my words, they will say, When they hear my words, they will say,"
    },
    {
      "verse": "35",
      "text": "��Job speaks like a fool who knows nothing. He only says useless things. ” He only says useless things. ”"
    },
    {
      "verse": "36",
      "text": "Yes Job, you speak to us like a wicked person. So you should continue to suffer for ever! So you should continue to suffer for ever!"
    },
    {
      "verse": "37",
      "text": "You have not only done wrong things, you have also turned against God. You have shown that you do not respect us. You have said many things that insult God. ’"
    }
  ],
  "35": [
    {
      "verse": "1",
      "text": "Elihu continued to speak to Job. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘The things that you say cannot be true. You say, “I am more right than God is. ” You say, “I am more right than God is. ”"
    },
    {
      "verse": "3",
      "text": "But you also say, “If I do nothing wrong, God does not bless me. No good thing comes to me. ” God does not bless me. No good thing comes to me. ”"
    },
    {
      "verse": "4",
      "text": "Now I will give you an answer. I will also speak to the friends who are with you. I will also speak to the friends who are with you."
    },
    {
      "verse": "5",
      "text": "Look up at the sky to see what is there. Look at the clouds that are so high above you. Look at the clouds that are so high above you."
    },
    {
      "verse": "6",
      "text": "If you do something that is wrong, it does not hurt God. Even if you do many wrong things, it does nothing to him. it does not hurt God. Even if you do many wrong things, it does nothing to him."
    },
    {
      "verse": "7",
      "text": "If you are righteous, that does nothing to help God. He does not receive anything that he needs from you. that does nothing to help God. He does not receive anything that he needs from you."
    },
    {
      "verse": "8",
      "text": "If you do wicked things, it is other people who suffer, not God. And if you do good things, you are only helping other people. it is other people who suffer, not God. And if you do good things, you are only helping other people."
    },
    {
      "verse": "9",
      "text": "When people suffer, they call aloud for help. They cry for helpwhen powerful people attack them. they call aloud for help. They cry for help when powerful people attack them."
    },
    {
      "verse": "10",
      "text": "But none of them says, “I want God to help me. He made me. He gives me songs to sing in dark nights. He made me. He gives me songs to sing in dark nights."
    },
    {
      "verse": "11",
      "text": "God teaches us more things than he teaches to the animals. He makes us wiser than the birds. ” He makes us wiser than the birds. ”"
    },
    {
      "verse": "12",
      "text": "Finally, they call for help. But God does not answer them, because they are proud and wicked people. But God does not answer them, because they are proud and wicked people."
    },
    {
      "verse": "13",
      "text": "Their prayers mean nothing. Almighty God does not even listen to them. Almighty God does not even listen to them."
    },
    {
      "verse": "14",
      "text": "So God will certainly not listen to you, Job, when you say that you cannot see him. You say that you have explained your problem to him. You are waiting for him to give you an answer. when you say that you cannot see him. You say that you have explained your problem to him. You are waiting for him to give you an answer."
    },
    {
      "verse": "15",
      "text": "You also say that God does not become angrywith people who do wrong things. You say that he does not punish bad people. with people who do wrong things. You say that he does not punish bad people."
    },
    {
      "verse": "16",
      "text": "So, Job, you do not understand what you are saying. You speak a lot of wordsbut they do not mean anything. ’"
    }
  ],
  "36": [
    {
      "verse": "1",
      "text": "Elihu continued to speak to Job. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘Be patient a little bit longer, so that I can teach you some more. I still have more to sayto show you that God is right. so that I can teach you some more. I still have more to say to show you that God is right."
    },
    {
      "verse": "3",
      "text": "I will tell you the many different things that I know. I will show you that God, my Maker, is completely fair. I will show you that God, my Maker, is completely fair."
    },
    {
      "verse": "4",
      "text": "Everything that I say to you is true. I am speaking to you as someone who knows everything. I am speaking to you as someone who knows everything."
    },
    {
      "verse": "5",
      "text": "God is very powerfulbut he does not turn anyone away. When he decides to do something, he surely does it. but he does not turn anyone away. When he decides to do something, he surely does it."
    },
    {
      "verse": "6",
      "text": "He does not allow wicked people to continue to live. But he is always fair to those who are poor and weak. But he is always fair to those who are poor and weak."
    },
    {
      "verse": "7",
      "text": "He takes care of righteous people. He gives them authority to rule like kings. He gives them honour for ever. He gives them authority to rule like kings. He gives them honour for ever."
    },
    {
      "verse": "8",
      "text": "People who do wrong things may suffer in prison. Chains may hold their legs so that they cannot move. Chains may hold their legs so that they cannot move."
    },
    {
      "verse": "9",
      "text": "When that happens, God shows them what they have done. He shows them their sins. They have done wrong things because they are proud. God shows them what they have done. He shows them their sins. They have done wrong things because they are proud."
    },
    {
      "verse": "10",
      "text": "He tells them this to warn them. They must turn away from wicked things. They must turn away from wicked things."
    },
    {
      "verse": "11",
      "text": "They must obey him and agree to serve him. If they do that, they will have everything that they need. They will enjoy all the days that they live. If they do that, they will have everything that they need. They will enjoy all the days that they live."
    },
    {
      "verse": "12",
      "text": "But if they refuse to listen to God, they will go to their graves. They will dieand they still will not understand what is right. they will go to their graves. They will die and they still will not understand what is right."
    },
    {
      "verse": "13",
      "text": "People who turn away from God are always angry. Even when God punishes them, they do not pray for help. Even when God punishes them, they do not pray for help."
    },
    {
      "verse": "14",
      "text": "They die while they are still young. Their lives finish in shame. They live among the male prostitutes who serve false gods. Their lives finish in shame. They live among the male prostitutes who serve false gods."
    },
    {
      "verse": "15",
      "text": "But God rescues people who suffer. He uses their troubles to teach them about himself. He uses their troubles to teach them about himself."
    },
    {
      "verse": "16",
      "text": "God has called you out of your troubles, Job. He wants you to live in a safe placewhere you have no problems. He wants you to have a comfortable lifewith plenty of good food to eat. He wants you to live in a safe place where you have no problems. He wants you to have a comfortable life with plenty of good food to eat."
    },
    {
      "verse": "17",
      "text": "But now you have a lot of trouble, because God is punishing you as wicked people deserve. God is right and fair to judge you like that. because God is punishing you as wicked people deserve. God is right and fair to judge you like that."
    },
    {
      "verse": "18",
      "text": "Be very careful! Do not let anyone use their riches to deceive you. Do not let them pay you a lot of moneyto do something that is wrong. Do not let anyone use their riches to deceive you. Do not let them pay you a lot of money to do something that is wrong."
    },
    {
      "verse": "19",
      "text": "Even if you become rich, that would not keep you safe. Even if you were strong and powerful, that would not keep trouble away from you. that would not keep you safe. Even if you were strong and powerful, that would not keep trouble away from you."
    },
    {
      "verse": "20",
      "text": "Do not wait for the night to hide what you want to do. That is the time when people disappear from their homes. That is the time when people disappear from their homes."
    },
    {
      "verse": "21",
      "text": "Be careful! Do not try to do wicked things. God has sent these troubles to test you. He wants to stop you doing evil things. God has sent these troubles to test you. He wants to stop you doing evil things."
    },
    {
      "verse": "22",
      "text": "Yes, God is very powerful. There is no teacher as good as he is. There is no teacher as good as he is."
    },
    {
      "verse": "23",
      "text": "Nobody can tell him what he should do. No one can say to him, “You have done things that are wrong. ” No one can say to him, “You have done things that are wrong. ”"
    },
    {
      "verse": "24",
      "text": "People sing songs to praise Godfor the things that he has done. You also should remember to praise him. for the things that he has done. You also should remember to praise him."
    },
    {
      "verse": "25",
      "text": "People everywhere have seen the things that God has done. But we look at them from far away. But we look at them from far away."
    },
    {
      "verse": "26",
      "text": "Yes, God is very great! We cannot know him completely. Nobody can count the number of his years! We cannot know him completely. Nobody can count the number of his years!"
    },
    {
      "verse": "27",
      "text": "It is God who pulls up water from the earthto make the clouds. Then he causes it to become rain. to make the clouds. Then he causes it to become rain."
    },
    {
      "verse": "28",
      "text": "The rain pours down from the clouds. There is plenty for the people on the earth. There is plenty for the people on the earth."
    },
    {
      "verse": "29",
      "text": "Who understands how the clouds move across the sky? How does the noise of thunder come from God's home? How does the noise of thunder come from God's home?"
    },
    {
      "verse": "30",
      "text": "Look at the lightning that God sends all over the sky! But he causes the bottom of the sea to remain dark. But he causes the bottom of the sea to remain dark."
    },
    {
      "verse": "31",
      "text": "This is the way that God rules the people of the world. He sends the rain to give them plenty of food. He sends the rain to give them plenty of food."
    },
    {
      "verse": "32",
      "text": "He sends his lightning like an arrow. He commands it to hit the right place. He commands it to hit the right place."
    },
    {
      "verse": "33",
      "text": "He sends thunder to show that a storm is coming. Even the cows know what is happening. ’"
    }
  ],
  "37": [
    {
      "verse": "1",
      "text": "‘When I hear the noise of a storm like that, I shake with fear. I shake with fear."
    },
    {
      "verse": "2",
      "text": "Listen carefully to the sound of God's voice, when he speaks like thunder. when he speaks like thunder."
    },
    {
      "verse": "3",
      "text": "He sends lightning across the whole sky. Its light reaches everywhere on the earth. Its light reaches everywhere on the earth."
    },
    {
      "verse": "4",
      "text": "After the lightning comes the sound of his voice. He roars like the great sound of thunder. When he speaks like that, the storm never stops. He roars like the great sound of thunder. When he speaks like that, the storm never stops."
    },
    {
      "verse": "5",
      "text": "When God's voice speaks, he causes wonderful things to happen. He does great things that we cannot understand. he causes wonderful things to happen. He does great things that we cannot understand."
    },
    {
      "verse": "6",
      "text": "He tells the snow to fall to the earth. He tells the rain to pour downand make the ground wet. He tells the rain to pour down and make the ground wet."
    },
    {
      "verse": "7",
      "text": "He does that to show people what he can do. He causes everyone to stop their own work. He causes everyone to stop their own work."
    },
    {
      "verse": "8",
      "text": "The wild animals have to hide in a safe place. They have to stay in their homes. They have to stay in their homes."
    },
    {
      "verse": "9",
      "text": "The strong wind of a storm comes from the place where it starts. Cold winds blow strongly from the north. Cold winds blow strongly from the north."
    },
    {
      "verse": "10",
      "text": "The cold wind is like God's breath. He causes ice to cover the rivers and the lakes. He causes ice to cover the rivers and the lakes."
    },
    {
      "verse": "11",
      "text": "He fills the clouds with lots of water. He sends the lightning through the clouds. He sends the lightning through the clouds."
    },
    {
      "verse": "12",
      "text": "The clouds move around across the whole earth. They go wherever God sends them. He tells them what they must do. They go wherever God sends them. He tells them what they must do."
    },
    {
      "verse": "13",
      "text": "He may send a storm as punishment for his land. Or he may send it to show his love for his people. Or he may send it to show his love for his people."
    },
    {
      "verse": "14",
      "text": "Listen carefully to what I am telling you, Job. Stop and think about the wonderful things that God does. Stop and think about the wonderful things that God does."
    },
    {
      "verse": "15",
      "text": "Do you know how God commands the storms? Do you know how he sends the bright lightning from the clouds? Do you know how he sends the bright lightning from the clouds?"
    },
    {
      "verse": "16",
      "text": "Can you explain how the clouds hang in the sky? God knows everything perfectlyand he does these wonderful things. God knows everything perfectly and he does these wonderful things."
    },
    {
      "verse": "17",
      "text": "When the hot wind blows from the south, nothing moves on the earth. Your body is too hot in the clothes that you wear. nothing moves on the earth. Your body is too hot in the clothes that you wear."
    },
    {
      "verse": "18",
      "text": "God puts the clouds across the whole sky, like a metal mirror that shines brightly. Can you also do that? No! like a metal mirror that shines brightly. Can you also do that? No!"
    },
    {
      "verse": "19",
      "text": "Tell us, Job, what things we should say to God. We cannot argue with him, because our minds are in a dark place. We cannot argue with him, because our minds are in a dark place."
    },
    {
      "verse": "20",
      "text": "Should I tell God that I want to speak to him? That would be the end of me! That would be the end of me!"
    },
    {
      "verse": "21",
      "text": "Now the wind has blown all the clouds away. The sun shines brightly in the sky. It is too bright for us to look at. The sun shines brightly in the sky. It is too bright for us to look at."
    },
    {
      "verse": "22",
      "text": "God comes with his bright glory from the north! His glory is all around him. It makes us afraid. His glory is all around him. It makes us afraid."
    },
    {
      "verse": "23",
      "text": "Almighty God is so great that we cannot come near to him. He is very powerful. But he always does what is right and fair. He is not cruel to people. He is very powerful. But he always does what is right and fair. He is not cruel to people."
    },
    {
      "verse": "24",
      "text": "So people respect God with fear. He does not listen to those who think that they are wise. ’"
    }
  ],
  "38": [
    {
      "verse": "1",
      "text": "The Lord spoke to Job from the middle of the storm. This is what he said:"
    },
    {
      "verse": "2",
      "text": "‘Who do you think you are? Why do you ask questions about my wisdom? You speak many words, but you do not understand anything. Why do you ask questions about my wisdom? You speak many words, but you do not understand anything."
    },
    {
      "verse": "3",
      "text": "Prepare yourself for a difficult job! I will ask you some questions and you must answer them. I will ask you some questions and you must answer them."
    },
    {
      "verse": "4",
      "text": "Were you with me when I made the world? If you think you are so clever, tell me all about it! If you think you are so clever, tell me all about it!"
    },
    {
      "verse": "5",
      "text": "It was me who decided the size of the world. You surely must know that! I measured it as I made it. You surely must know that! I measured it as I made it."
    },
    {
      "verse": "6",
      "text": "Tell me how I fixed the foundations of the earth. Who made it stay in its right place? I did! Who made it stay in its right place? I did!"
    },
    {
      "verse": "7",
      "text": "At the dawn of that day, the stars sang together. They sang for joy with all the angels. They sang for joy with all the angels."
    },
    {
      "verse": "8",
      "text": "When the sea poured out of the ground, I decided where its borders should be. I kept the water in its right place. I decided where its borders should be. I kept the water in its right place."
    },
    {
      "verse": "9",
      "text": "I caused the clouds to come over the sea. I covered it with complete darkness. I covered it with complete darkness."
    },
    {
      "verse": "10",
      "text": "I put a border around the sea. I locked it in its place. I locked it in its place."
    },
    {
      "verse": "11",
      "text": "I said to the sea, “This is as far as you can come. You may come no further. Your powerful waves must stop there! ” You may come no further. Your powerful waves must stop there! ”"
    },
    {
      "verse": "12",
      "text": "But you, Job, did you ever command the morning to begin? No! You have never in your whole life told the sun when it should rise. No! You have never in your whole life told the sun when it should rise."
    },
    {
      "verse": "13",
      "text": "You have not told the light of day to cover the earth. You have not told it to chase away the wicked things that happen in the night. You have not told it to chase away the wicked things that happen in the night."
    },
    {
      "verse": "14",
      "text": "When the light of day comes, people see the land clearly. Its shape and colours show like bright clothes. people see the land clearly. Its shape and colours show like bright clothes."
    },
    {
      "verse": "15",
      "text": "The light of day is too bright for wicked people. It destroys their power to do cruel things. It destroys their power to do cruel things."
    },
    {
      "verse": "16",
      "text": "You have not gone to the springsthat fill the seas with water. You have not walked on the bottom of the deep seas. that fill the seas with water. You have not walked on the bottom of the deep seas."
    },
    {
      "verse": "17",
      "text": "Nobody has showed you the gates of death. People go through them to that very dark place. People go through them to that very dark place."
    },
    {
      "verse": "18",
      "text": "You do not understand the great size of the earth. If you know all about that, tell me! If you know all about that, tell me!"
    },
    {
      "verse": "19",
      "text": "You do not know where light comes from. You do not know where darkness has its home. You do not know where darkness has its home."
    },
    {
      "verse": "20",
      "text": "Can you take them to the places where they belong? Do you know the roads that go there? Do you know the roads that go there?"
    },
    {
      "verse": "21",
      "text": "Surely you must know all this, because you have lived for so long! It seems that you were already bornwhen I created these things! because you have lived for so long! It seems that you were already born when I created these things!"
    },
    {
      "verse": "22",
      "text": "Have you visited the place where I keep all the snow? Or the place where I keep the hail? Or the place where I keep the hail?"
    },
    {
      "verse": "23",
      "text": "I keep the snow and the hail ready to use. I use them in times of trouble and wars. I use them in times of trouble and wars."
    },
    {
      "verse": "24",
      "text": "You do not know where lightning comes from. Or where the east wind startswhen it blows across the earth. Or where the east wind starts when it blows across the earth."
    },
    {
      "verse": "25",
      "text": "I make a path for the storms to travel along. I tell the thunder and the strong rain which way to go. I tell the thunder and the strong rain which way to go."
    },
    {
      "verse": "26",
      "text": "I cause rain to fall in places where no person lives. It makes even a desert become a wet place. It makes even a desert become a wet place."
    },
    {
      "verse": "27",
      "text": "The rain falls on dry ground where nothing grows. It causes grass to grow there again. It causes grass to grow there again."
    },
    {
      "verse": "28",
      "text": "Do you know if the rain has a father? Who is a father to the dew? Who is a father to the dew?"
    },
    {
      "verse": "29",
      "text": "Who is a mother to the ice? Who gives birth to the frost that makes the air so cold? Who gives birth to the frost that makes the air so cold?"
    },
    {
      "verse": "30",
      "text": "It causes the water to become as hard as stone. The water of the sea also becomes ice. The water of the sea also becomes ice."
    },
    {
      "verse": "31",
      "text": "You cannot make the stars of the Pleiades stay in their places. You cannot change the shape of Orion. You cannot change the shape of Orion."
    },
    {
      "verse": "32",
      "text": "You bring out the groups of starsfor people to see at different times of the year. You cannot put the stars of the Great Bear and the Little Bearin their right places in the sky. for people to see at different times of the year. You cannot put the stars of the Great Bear and the Little Bear in their right places in the sky."
    },
    {
      "verse": "33",
      "text": "You do not know the rules that the stars above obey. You cannot make the earth obey those rules. You cannot make the earth obey those rules."
    },
    {
      "verse": "34",
      "text": "You cannot shout commands to the clouds. You cannot tell them to pour down their rain, so that a flood of water covers you. You cannot tell them to pour down their rain, so that a flood of water covers you."
    },
    {
      "verse": "35",
      "text": "You cannot send the lightningto hit the place that you want it to go. The lightning does not say to you, “We are ready to go wherever you want. ” to hit the place that you want it to go. The lightning does not say to you, “We are ready to go wherever you want. ”"
    },
    {
      "verse": "36",
      "text": "Who has given people wisdom, so that they understand things with their minds? so that they understand things with their minds?"
    },
    {
      "verse": "37",
      "text": "Is anyone wise enough to count the clouds? Can anyone cause the clouds to pour down rain from above? Can anyone cause the clouds to pour down rain from above?"
    },
    {
      "verse": "38",
      "text": "The rain causes the dust of the dry ground to become hard. The dry soil becomes pieces of mud. The dry soil becomes pieces of mud."
    },
    {
      "verse": "39",
      "text": "When the lions become hungry, can you find food for the young lions to eat? can you find food for the young lions to eat?"
    },
    {
      "verse": "40",
      "text": "You cannot do that for themwhen they sit in their caves. You cannot help them as they hide in the bushes, ready to attack other animals. when they sit in their caves. You cannot help them as they hide in the bushes, ready to attack other animals."
    },
    {
      "verse": "41",
      "text": "You cannot find food for the ravens to eat. You cannot help them when their babies cry to mebecause they are weak and hungry. ’"
    }
  ],
  "39": [
    {
      "verse": "1",
      "text": "‘Job, do you know that time when the goats on the mountains give birth? Do you watch the wild deer when their babies are born? Do you watch the wild deer when their babies are born?"
    },
    {
      "verse": "2",
      "text": "Can you count the number of months that these animals are pregnant? How long must they wait until they give birth? How long must they wait until they give birth?"
    },
    {
      "verse": "3",
      "text": "They bend down low to the ground. They give birth to the babies that they have carried inside them. They give birth to the babies that they have carried inside them."
    },
    {
      "verse": "4",
      "text": "The young animals growand they become strong in the fields. Then they leave their parentsand they do not return to them. and they become strong in the fields. Then they leave their parents and they do not return to them."
    },
    {
      "verse": "5",
      "text": "Did you send out the wild donkeysto go wherever they want? to go wherever they want?"
    },
    {
      "verse": "6",
      "text": "No! It was me who gave them the desert as their home. I let them live in places where the ground has salt. I let them live in places where the ground has salt."
    },
    {
      "verse": "7",
      "text": "They stay far away from the busy cities. They do not allow anyone to make them work. They do not allow anyone to make them work."
    },
    {
      "verse": "8",
      "text": "Instead, they live on the hills, where they find fresh plants to eat. where they find fresh plants to eat."
    },
    {
      "verse": "9",
      "text": "Can you tell a wild ox to work for you? No! At night, it will not stay to feed at your farm. No! At night, it will not stay to feed at your farm."
    },
    {
      "verse": "10",
      "text": "It will not let you tie it to a plough. It will not agree to prepare your fields in the valleys. It will not agree to prepare your fields in the valleys."
    },
    {
      "verse": "11",
      "text": "A wild ox is very strong. But you cannot trust it to help you with your difficult work. But you cannot trust it to help you with your difficult work."
    },
    {
      "verse": "12",
      "text": "It will not help you to bring in your harvest of grain. It will not take the grain to your threshing floor. It will not take the grain to your threshing floor."
    },
    {
      "verse": "13",
      "text": "When an ostrich is happy, it waves its wings. But it cannot use its wings to fly, as a stork can do. it waves its wings. But it cannot use its wings to fly, as a stork can do."
    },
    {
      "verse": "14",
      "text": "A mother ostrich leaves her eggs on the ground. She lets the sand cause them to be warm. She lets the sand cause them to be warm."
    },
    {
      "verse": "15",
      "text": "She does not realize that people or wild animalsmight break the eggs with their feet. might break the eggs with their feet."
    },
    {
      "verse": "16",
      "text": "She does not take care of her babies, as if they did not belong to her. She does not worry that all her work might be useless. as if they did not belong to her. She does not worry that all her work might be useless."
    },
    {
      "verse": "17",
      "text": "This is because I did not give wisdom to ostriches. I did not give them minds that understand things. I did not give them minds that understand things."
    },
    {
      "verse": "18",
      "text": "But when an ostrich begins to run, it can run very fast. It can run faster than a horseand someone who rides on it. it can run very fast. It can run faster than a horse and someone who rides on it."
    },
    {
      "verse": "19",
      "text": "Did you, Job, give horses their strength? Did you give them the long hair that they have on their necks? Did you give them the long hair that they have on their necks?"
    },
    {
      "verse": "20",
      "text": "You did not make horses able to jump like locusts. They frighten people when they blow air out through their noses. They frighten people when they blow air out through their noses."
    },
    {
      "verse": "21",
      "text": "They stamp their feet on the ground, as they prepare to go to a battle. They are ready to go and attack the enemy. as they prepare to go to a battle. They are ready to go and attack the enemy."
    },
    {
      "verse": "22",
      "text": "A horse is brave and it is not afraid of anything. It does not run away from the enemy's weapons. It does not run away from the enemy's weapons."
    },
    {
      "verse": "23",
      "text": "The soldier who is riding ithas his arrows ready at the horse's side. Swords and spears shine brightly in the sun. has his arrows ready at the horse's side. Swords and spears shine brightly in the sun."
    },
    {
      "verse": "24",
      "text": "The horse shakes with joyas it runs to the battle. When the battle trumpet makes its noise, the horse wants to run even faster! as it runs to the battle. When the battle trumpet makes its noise, the horse wants to run even faster!"
    },
    {
      "verse": "25",
      "text": "When it hears the sound of the trumpet, it makes a happy noise. From far away, it recognizes the smell of the battle. It hears the army officers as they shout their commands. it makes a happy noise. From far away, it recognizes the smell of the battle. It hears the army officers as they shout their commands."
    },
    {
      "verse": "26",
      "text": "Was it your wisdom, Job, that taught hawks how to fly? No! You could not teach them to fly towards the south in winter. No! You could not teach them to fly towards the south in winter."
    },
    {
      "verse": "27",
      "text": "Do eagles wait for your commandto fly high into the sky? No! You could not teach them how to build their nestshigh up in the mountains. to fly high into the sky? No! You could not teach them how to build their nests high up in the mountains."
    },
    {
      "verse": "28",
      "text": "They live among the highest rocks. That is where they stay at night. They are safe on the sharp rocks. That is where they stay at night. They are safe on the sharp rocks."
    },
    {
      "verse": "29",
      "text": "From the high rocks, eagles look for their food. They see small animals far away, that they can catch and eat. eagles look for their food. They see small animals far away, that they can catch and eat."
    },
    {
      "verse": "30",
      "text": "They come together around the bodies of dead animals. The young eagles drink the blood. ’"
    }
  ],
  "40": [
    {
      "verse": "1",
      "text": "The Lord said to Job,"
    },
    {
      "verse": "2",
      "text": "‘Do you still want to argue with me, the Almighty God? You say that I have not been fair. Now you must explain what you mean. ’ You say that I have not been fair. Now you must explain what you mean. ’"
    },
    {
      "verse": "3",
      "text": "Then Job answered the Lord. This is what he said:"
    },
    {
      "verse": "4",
      "text": "‘I am only a foolish man. I cannot answer your questions. I cover my mouth with my handso that I say nothing. I cannot answer your questions. I cover my mouth with my hand so that I say nothing."
    },
    {
      "verse": "5",
      "text": "I have already spoken too many times. I will say no more. ’ I will say no more. ’"
    },
    {
      "verse": "6",
      "text": "Then the Lord spoke to Job from inside the storm. This is what he said:"
    },
    {
      "verse": "7",
      "text": "‘Prepare yourself for a difficult job! I will ask you some more questions and you must answer them. I will ask you some more questions and you must answer them."
    },
    {
      "verse": "8",
      "text": "Do you say that I am not a fair judge? Do you want to show that I am guilty, not you? Then you could say that you are right. Do you want to show that I am guilty, not you? Then you could say that you are right."
    },
    {
      "verse": "9",
      "text": "Do you have the same power to do great things as I have? Can you speak with a voice as loud as thunder? I can! Can you speak with a voice as loud as thunder? I can!"
    },
    {
      "verse": "10",
      "text": "If you think that you can do all this, show how great you are! Show everyone your power and your glory! show how great you are! Show everyone your power and your glory!"
    },
    {
      "verse": "11",
      "text": "Show everyone your great anger! Look at all the people who like to boastand bring them down low! Look at all the people who like to boast and bring them down low!"
    },
    {
      "verse": "12",
      "text": "Yes, cause all the proud people to be humble. Knock down wicked people to the ground. Knock down wicked people to the ground."
    },
    {
      "verse": "13",
      "text": "Bury them all together in the dust of the ground. Cover their faces and put them in their graves. Cover their faces and put them in their graves."
    },
    {
      "verse": "14",
      "text": "If you can do these things, Job, I will praise you. I will agree that you have the power to save yourself. I will praise you. I will agree that you have the power to save yourself."
    },
    {
      "verse": "15",
      "text": "Listen! I created the monsters called Behemoth. I made you and I made them too. They eat grass, as cows do. I made you and I made them too. They eat grass, as cows do."
    },
    {
      "verse": "16",
      "text": "But look at the strength of their legs and their body!"
    },
    {
      "verse": "17",
      "text": "Their tails are like the branches of a cedar tree. Their legs are thick and very strong. Their legs are thick and very strong."
    },
    {
      "verse": "18",
      "text": "Their bones are like sticks made of bronze. Their legs are as strong as iron. Their legs are as strong as iron."
    },
    {
      "verse": "19",
      "text": "These monsters are some of the greatest animals that I have made. But I who made them can take my swordand go near to them. But I who made them can take my sword and go near to them."
    },
    {
      "verse": "20",
      "text": "They eat the grass that grows on the hills. That is where the wild animals play. That is where the wild animals play."
    },
    {
      "verse": "21",
      "text": "They lie down under the thorn trees. They hide among the reeds at the edge of the water. They hide among the reeds at the edge of the water."
    },
    {
      "verse": "22",
      "text": "They rest in the shadow of the thorn trees, and among the willow trees beside the water. and among the willow trees beside the water."
    },
    {
      "verse": "23",
      "text": "Even when the river is deep and dangerous, these monsters are not afraid. The water of the Jordan River may cover their mouths, but they still feel safe. these monsters are not afraid. The water of the Jordan River may cover their mouths, but they still feel safe."
    },
    {
      "verse": "24",
      "text": "There is no way that anyone can catch one of them. No one can make its eyes blind. No one can put a ring in its nose and lead it away. ’"
    }
  ],
  "41": [
    {
      "verse": "1",
      "text": "‘It is the same with the sea monsters called Leviathan. Can you catch them with a hook? Can you use a rope to keep their mouths shut? Can you catch them with a hook? Can you use a rope to keep their mouths shut?"
    },
    {
      "verse": "2",
      "text": "Can you tie a rope through their noses? Can you put a hook into their mouths. Can you put a hook into their mouths."
    },
    {
      "verse": "3",
      "text": "No! They will not ask you nicely to be kindand let them go free. and let them go free."
    },
    {
      "verse": "4",
      "text": "They will not make any agreement with you. You cannot make them your slavesto work for you as long as they live. You cannot make them your slaves to work for you as long as they live."
    },
    {
      "verse": "5",
      "text": "Leviathan is not something to enjoy at home, like a bird. You cannot tie it with a rope, so that your girls can play with it. You cannot tie it with a rope, so that your girls can play with it."
    },
    {
      "verse": "6",
      "text": "Traders do not buy it at the market. They do not cut it up to sell it. They do not cut it up to sell it."
    },
    {
      "verse": "7",
      "text": "Job, can you throw spears into Leviathan's body to kill it? Can you shoot arrows into its head? Can you shoot arrows into its head?"
    },
    {
      "verse": "8",
      "text": "If you try to take hold of it, you will never forget the fight! You will never try to do that again! you will never forget the fight! You will never try to do that again!"
    },
    {
      "verse": "9",
      "text": "If anyone hopes to catch it, he is deceiving himself. As soon as he sees it, he no longer feels so brave! he is deceiving himself. As soon as he sees it, he no longer feels so brave!"
    },
    {
      "verse": "10",
      "text": "No one is brave enough to wake it. So is anyone brave enough to argue against me? So is anyone brave enough to argue against me?"
    },
    {
      "verse": "11",
      "text": "Nobody has ever won against meto make me pay them anything. Everything in the whole world belongs to me. to make me pay them anything. Everything in the whole world belongs to me."
    },
    {
      "verse": "12",
      "text": "I must tell you how strong Leviathan's legs are. Their bodies are very strongand they have a wonderful shape. Their bodies are very strong and they have a wonderful shape."
    },
    {
      "verse": "13",
      "text": "Nobody is able to remove their thick skin. It is like armour that nobody can cut through. It is like armour that nobody can cut through."
    },
    {
      "verse": "14",
      "text": "Nobody is strong enough to open its mouth. Its teeth make everyone afraid. Its teeth make everyone afraid."
    },
    {
      "verse": "15",
      "text": "Its back is like rows of shields. They are as hard as stone with no spaces between them. They are as hard as stone with no spaces between them."
    },
    {
      "verse": "16",
      "text": "Each shield is very near the next one. Not even air can pass between them. Not even air can pass between them."
    },
    {
      "verse": "17",
      "text": "They are strongly joined together, and nothing can pull them apart. and nothing can pull them apart."
    },
    {
      "verse": "18",
      "text": "When Leviathan breathes out loudly, bright light shines from its nose. Its eyes shine like the red sun at dawn. bright light shines from its nose. Its eyes shine like the red sun at dawn."
    },
    {
      "verse": "19",
      "text": "Fire comes out from its mouth. Bright flames shoot out! Bright flames shoot out!"
    },
    {
      "verse": "20",
      "text": "Smoke pours out from its nose, like reeds that burn under a pot. like reeds that burn under a pot."
    },
    {
      "verse": "21",
      "text": "Its breath is hot enough to light a fire! Flames pour out of its mouth. Flames pour out of its mouth."
    },
    {
      "verse": "22",
      "text": "Its neck is very strong. Wherever it goes, people shake with fear. Wherever it goes, people shake with fear."
    },
    {
      "verse": "23",
      "text": "There are no weak places in its skin. Its skin is as hard as iron. Its skin is as hard as iron."
    },
    {
      "verse": "24",
      "text": "It is cruel and it has no fear. Its heart is as hard as stone. Its heart is as hard as stone."
    },
    {
      "verse": "25",
      "text": "Even the bravest people are afraidwhen Leviathan appears. They run away when it starts to move. when Leviathan appears. They run away when it starts to move."
    },
    {
      "verse": "26",
      "text": "If you hit it with a sword, you will not hurt it. Spears, arrows and knives will be useless. you will not hurt it. Spears, arrows and knives will be useless."
    },
    {
      "verse": "27",
      "text": "It can easily break iron or bronze weapons. It breaks them as easily as grass or soft wood. It breaks them as easily as grass or soft wood."
    },
    {
      "verse": "28",
      "text": "If you shoot arrows at it, it will not run away. If you use a sling to throw stones at it, the stones will hurt it no more than bits of chaff. it will not run away. If you use a sling to throw stones at it, the stones will hurt it no more than bits of chaff."
    },
    {
      "verse": "29",
      "text": "If you hit it with a heavy stick, that hurts it no more than a piece of straw. If you throw a spear at it, it laughs! that hurts it no more than a piece of straw. If you throw a spear at it, it laughs!"
    },
    {
      "verse": "30",
      "text": "Its stomach has sharp pieces, like bits of a pot that someone has broken. When it moves along, it ploughs the soil under it. like bits of a pot that someone has broken. When it moves along, it ploughs the soil under it."
    },
    {
      "verse": "31",
      "text": "When it swims in the deep water of the sea, the water seems to boil. It makes big waves, like oil that is boiling in a pot. the water seems to boil. It makes big waves, like oil that is boiling in a pot."
    },
    {
      "verse": "32",
      "text": "As it swims, the water behind it shines. It makes waves that look like white hair on the sea. It makes waves that look like white hair on the sea."
    },
    {
      "verse": "33",
      "text": "There is no other animal like it in the whole world. It is not afraid of anything. It is not afraid of anything."
    },
    {
      "verse": "34",
      "text": "It does not respect any other great animal. It rules as king over all the proud animals. ’"
    }
  ],
  "42": [
    {
      "verse": "1",
      "text": "Then Job replied to the Lord. He said this:"
    },
    {
      "verse": "2",
      "text": "‘I know that you can do all things. You can do anything that you want to do. Nobody can stop you. You can do anything that you want to do. Nobody can stop you."
    },
    {
      "verse": "3",
      "text": "You asked me, “Why do you ask questions about my wisdom, when you do not understand anything? ”It is true. I was speaking about things that I do not understand. They are things that are too wonderful for me to know. when you do not understand anything? ” It is true. I was speaking about things that I do not understand. They are things that are too wonderful for me to know."
    },
    {
      "verse": "4",
      "text": "You said to me, “Listen carefully to what I will say. I will ask you questions and you must answer them. ” I will ask you questions and you must answer them. ”"
    },
    {
      "verse": "5",
      "text": "In the past, I had heard about you from other people. Now I have seen you for myself. Now I have seen you for myself."
    },
    {
      "verse": "6",
      "text": "So I am ashamed of the things that I said. I sit here in dirt and in ashesto show you that I am very sorry. ’ I sit here in dirt and in ashes to show you that I am very sorry. ’"
    },
    {
      "verse": "7",
      "text": "When the Lord had spoken to Job, he said this to Eliphaz, the man from Teman:‘I am very angry with you and with your two friends. The things that my servant Job has said about me are true. But the things that you said were not right."
    },
    {
      "verse": "8",
      "text": "You three men must now go to Job. Take seven bulls and seven male sheep with you. Burn them as sacrifices for yourselves. After you have done that, my servant Job will pray for you. I will answer his prayer. Then I will not punish you as you deserve because of your foolish words. My servant Job has spoken the truth about me, but you have not. ’"
    },
    {
      "verse": "9",
      "text": "So Eliphaz, the man from Teman, Bildad, the man from Shuah, and Zophar, the man from Naamah, did what the Lord had told them to do. And the Lord answered Job's prayer."
    },
    {
      "verse": "10",
      "text": "After Job prayed for his three friends, the Lord made him a rich man again. He gave Job twice as many things as he had before."
    },
    {
      "verse": "11",
      "text": "Then Job's brothers and sisters came to eat a big meal with him in his house. People who had been Job's friends came also. They all told him that they were sad about his troubles. They were upset because the Lord had caused him to suffer. Each of them gave Job a piece of silver and a gold ring."
    },
    {
      "verse": "12",
      "text": "After this, the Lord blessed Job more than in the beginning of his life. All these animals belonged to Job: 14, 000 sheep, 6, 000 camels, 1, 000 pairs of oxen, and 1, 000 female donkeys."
    },
    {
      "verse": "13",
      "text": "He had seven sons and three daughters."
    },
    {
      "verse": "14",
      "text": "The daughters' names were Jemimah, Keziah, and Keren-Happuch."
    },
    {
      "verse": "15",
      "text": "They were the most beautiful women in the whole land of Uz. Job said that they should receive some of his things after he died, along with their brothers."
    },
    {
      "verse": "16",
      "text": "years after this. He was still alive when his grandchildren and their grandchildren were born."
    },
    {
      "verse": "17",
      "text": "So when Job died, he had lived for a long time."
    }
  ]
};