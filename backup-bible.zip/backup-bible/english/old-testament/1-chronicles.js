module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "Adam, Seth, Enosh,"
    },
    {
      "verse": "2",
      "text": "Kenan, Mahalalel, Jared,"
    },
    {
      "verse": "3",
      "text": "Enoch, Methuselah, Lamech, Noah."
    },
    {
      "verse": "4",
      "text": "Noah's sons were Shem, Ham and Japheth."
    },
    {
      "verse": "5",
      "text": "Japheth's sons were: Gomer, Magog, Madai, Javan, Tubal, Meshech and Tiras."
    },
    {
      "verse": "6",
      "text": "Gomer's sons were: Ashkenaz, Riphath and Togarmah."
    },
    {
      "verse": "7",
      "text": "Javan's sons were: Elishah, Tarshish, the Kittim people and the Rodanim people."
    },
    {
      "verse": "8",
      "text": "Ham's sons were: Cush, Mizraim, Put and Canaan."
    },
    {
      "verse": "9",
      "text": "Cush's sons were: Seba, Havilah, Sabta, Raamah and Sabteca. Raamah's sons were: Sheba and Dedan. Raamah's sons were: Sheba and Dedan."
    },
    {
      "verse": "10",
      "text": "Cush was also the father of Nimrod. Nimrod became the first brave soldier in the world."
    },
    {
      "verse": "11",
      "text": "Mizraim was the ancestor of the Ludites, Anamites, Lehabites, Naphtuhites,"
    },
    {
      "verse": "12",
      "text": "Pathrusites, Kasluhites and Caphtorites. The Philistines were descendants of the Kasluhites."
    },
    {
      "verse": "13",
      "text": "Canaan's firstborn son was Sidon. Canaan was also the ancestor of the Hittites,"
    },
    {
      "verse": "14",
      "text": "Jebusites, Amorites, Girgashites,"
    },
    {
      "verse": "15",
      "text": "Hivites, Arkites, Sinites,"
    },
    {
      "verse": "16",
      "text": "Arvadites, Zemarites and Hamathites."
    },
    {
      "verse": "17",
      "text": "Shem's sons were: Elam, Asshur, Arphaxad, Lud and Aram. Aram's sons were: Uz, Hul, Gether and Meshech. Aram's sons were: Uz, Hul, Gether and Meshech."
    },
    {
      "verse": "18",
      "text": "Arpachshad was the father of Shelah, and Shelah was the father of Eber."
    },
    {
      "verse": "19",
      "text": "Eber had two sons. The name of one son was Peleg. When he was alive, people began to live in different places on the earth. That is why his name was Peleg. Peleg's brother's name was Joktan."
    },
    {
      "verse": "20",
      "text": "Joktan was the father of Almodad, Sheleph, Hazarmaveth, Jerah,"
    },
    {
      "verse": "21",
      "text": "Hadoram, Uzal, Diklah,"
    },
    {
      "verse": "22",
      "text": "Ebal, Abimael, Sheba,"
    },
    {
      "verse": "23",
      "text": "Ophir, Havilah and Jobab. All those men were Joktan's sons."
    },
    {
      "verse": "24",
      "text": "Shem's descendants included Arpachshad, Shelah,"
    },
    {
      "verse": "25",
      "text": "Eber, Peleg, Reu,"
    },
    {
      "verse": "26",
      "text": "Serug, Nahor, Terah"
    },
    {
      "verse": "27",
      "text": "and then Abram. Abram's name became Abraham."
    },
    {
      "verse": "28",
      "text": "Abraham's sons were: Isaac and Ishmael."
    },
    {
      "verse": "29",
      "text": "These were their descendants: Ishmael's firstborn son was Nebaioth. His other sons were: Kedar, Adbeel, Mibsam, Ishmael's firstborn son was Nebaioth."
    },
    {
      "verse": "30",
      "text": "Mishma, Dumah, Massa, Hadad, Tema,"
    },
    {
      "verse": "31",
      "text": "Jetur, Naphish and Kedemah. Those men were Ishmael's sons."
    },
    {
      "verse": "32",
      "text": "Abraham's slave wife Keturah gave birth to these sons: Zimran, Jokshan, Medan, Midian, Ishbak and Shuah. Jokshan's sons were: Sheba and Dedan. Jokshan's sons were: Sheba and Dedan."
    },
    {
      "verse": "33",
      "text": "Midian's sons were: Ephah, Epher, Hanoch, Abida and Eldaah. All those men were descendants of Keturah. All those men were descendants of Keturah."
    },
    {
      "verse": "34",
      "text": "Abraham was the father of Isaac. Isaac's sons were: Esau and Israel. Isaac's sons were: Esau and Israel."
    },
    {
      "verse": "35",
      "text": "Esau's sons were: Eliphaz, Reuel, Jeush, Jalam and Korah."
    },
    {
      "verse": "36",
      "text": "Eliphaz's sons were: Teman, Omar, Zepho, Gatam, Kenaz and Amalek who was born to Timna."
    },
    {
      "verse": "37",
      "text": "Reuel's sons were: Nahath, Zerah, Shammah and Mizzah."
    },
    {
      "verse": "38",
      "text": "Seir's sons were: Lotan, Shobal, Zibeon, Anah, Dishon, Ezer and Dishan."
    },
    {
      "verse": "39",
      "text": "Lotan's sons were: Hori and Homam. Lotan's sister was Timna."
    },
    {
      "verse": "40",
      "text": "Shobal's sons were: Alvan, Manahath, Ebal, Shepho and Onam. Zibeon's sons were: Aiah and Anah. Zibeon's sons were: Aiah and Anah."
    },
    {
      "verse": "41",
      "text": "Anah's son was Dishon. Dishon's sons were: Hemdan, Eshban, Ithran and Keran. Dishon's sons were: Hemdan, Eshban, Ithran and Keran."
    },
    {
      "verse": "42",
      "text": "Ezer's sons were: Bilhan, Zaavan and Jaakan. Dishan's sons were: Uz and Aran. Dishan's sons were: Uz and Aran."
    },
    {
      "verse": "43",
      "text": "These kings ruled in Edom before any kings ruled over Israel: Bela son of Beor. The name of his city was Dinhabah. Bela son of Beor. The name of his city was Dinhabah."
    },
    {
      "verse": "44",
      "text": "When Bela died, Zerah's son Jobab ruled in Edom. He was from Bozrah."
    },
    {
      "verse": "45",
      "text": "When Jobab died, Husham then ruled. He was from the land of the Temanites."
    },
    {
      "verse": "46",
      "text": "When Husham died, Bedad's son Hadad then ruled. Bedad had won the war against the Midianites in the region of Moab. The name of his city was Avith."
    },
    {
      "verse": "47",
      "text": "When Hadad died, Samlah then ruled. He was from Masrekah."
    },
    {
      "verse": "48",
      "text": "When Samlah died, Shaul then ruled. He was from Rehoboth on the river."
    },
    {
      "verse": "49",
      "text": "When Shaul died, Akbor's son Baal-Hanan then ruled."
    },
    {
      "verse": "50",
      "text": "When Baal-Hanan died, Hadad then ruled. The name of his city was Pau. Hadad's wife was Mehetabel. She was Matred's daughter. Matred was the daughter of Me-Zahab."
    },
    {
      "verse": "51",
      "text": "King Hadad also died. The leaders of the clans of Edom were: Timna, Alvah, Jetheth,"
    },
    {
      "verse": "52",
      "text": "Oholibamah, Elah, Pinon,"
    },
    {
      "verse": "53",
      "text": "Kenaz, Teman, Mibzar,"
    },
    {
      "verse": "54",
      "text": "Magdiel and Iram. Those men were the leaders of Edom."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "The sons of Israel were: Reuben, Simeon, Levi, Judah, Issachar, Zebulun,"
    },
    {
      "verse": "2",
      "text": "Dan, Joseph, Benjamin, Naphtali, Gad and Asher."
    },
    {
      "verse": "3",
      "text": "Judah's sons were: Er, Onan and Shelah. Their mother was Bath-shua, who was a woman from Canaan. Judah's firstborn son Er did things that the Lord saw were evil. So the Lord killed him."
    },
    {
      "verse": "4",
      "text": "Judah had sex with Er's widow, Tamar. She gave birth to two sons for Judah, Perez and Zerah. Judah was the father of five sons."
    },
    {
      "verse": "5",
      "text": "Perez's sons were: Hezron and Hamul."
    },
    {
      "verse": "6",
      "text": "Zerah's five sons were: Zimri, Ethan, Heman, Calcol and Dara."
    },
    {
      "verse": "7",
      "text": "Carmi's son was Achar. Achar caused a lot of trouble for Israel. He took for himself things that belonged to God."
    },
    {
      "verse": "8",
      "text": "Ethan's son was Azariah."
    },
    {
      "verse": "9",
      "text": "Hezron's sons were: Jerahmeel, Ram and Caleb."
    },
    {
      "verse": "10",
      "text": "Ram became the father of Amminadab. Amminadab became the father of Nahshon. Nahshon was the leader of Judah's tribe."
    },
    {
      "verse": "11",
      "text": "Nahshon became the father of Salma. Salma became the father of Boaz."
    },
    {
      "verse": "12",
      "text": "Boaz became the father of Obed. Obed became the father of Jesse."
    },
    {
      "verse": "13",
      "text": "Jesse's firstborn son was Eliab. His second son was Abinadab, and his third son was Shimea."
    },
    {
      "verse": "14",
      "text": "His fourth son was Nethanel and his fifth son was Raddai."
    },
    {
      "verse": "15",
      "text": "His sixth son was Ozem and his seventh son was David."
    },
    {
      "verse": "16",
      "text": "Their sisters were Zeruiah and Abigail. Zeruiah's three sons were Abishai, Joab and Asahel."
    },
    {
      "verse": "17",
      "text": "Abigail gave birth to Amasa. Amasa's father was Jether, a descendant of Ishmael."
    },
    {
      "verse": "18",
      "text": "Hezron's son Caleb married Azubah, who was also called Jerioth. Her sons were Jesher, Shobab and Ardon."
    },
    {
      "verse": "19",
      "text": "When Azubah died, Caleb married Ephrath. She gave birth to a son called Hur."
    },
    {
      "verse": "20",
      "text": "Hur became the father of Uri. Uri became the father of Bezalel."
    },
    {
      "verse": "21",
      "text": "After some time, when Hezron was 60 years old, he married Makir's daughter. She was Gilead's sister. Hezron had sex with her and she gave birth to a son called Segub."
    },
    {
      "verse": "22",
      "text": "Segub became the father of Jair. Jair ruled 23 towns in the region of Gilead. All those people were descendants of Gilead's father, Makir."
    },
    {
      "verse": "23",
      "text": "But later Geshur and Aram attacked Jair's towns and took them for themselves. They also took Kenath and the 60 small towns around it. All those people were descendants of Gilead's father, Makir."
    },
    {
      "verse": "24",
      "text": "After Hezron died, Caleb married his father's widow, Ephrathah. She gave birth to a son for him. His name was Ashhur, and he became the father of Tekoa."
    },
    {
      "verse": "25",
      "text": "Hezron's firstborn son was Jerahmeel. Jerahmeel's sons were: Ram (his firstborn son), Bunah, Oren, Ozem and Ahijah."
    },
    {
      "verse": "26",
      "text": "Jerahmeel had another wife, called Atarah. She gave birth to Onam."
    },
    {
      "verse": "27",
      "text": "The sons of Jerahmeel's firstborn son, Ram, were: Maaz, Jamin and Eker."
    },
    {
      "verse": "28",
      "text": "Onam's sons were: Shammai and Jada. Shammai's sons were: Nadab and Abishur. Shammai's sons were: Nadab and Abishur."
    },
    {
      "verse": "29",
      "text": "Abishur's wife was called Abihail. She gave birth to Ahban and Molid."
    },
    {
      "verse": "30",
      "text": "Nadab's sons were: Seled and Appaim. When Seled died, he had no sons."
    },
    {
      "verse": "31",
      "text": "Appaim's son was Ishi. Ishi's son was Sheshan. Sheshan's son was Ahlai."
    },
    {
      "verse": "32",
      "text": "The sons of Jada, Shammai's brother, were: Jether and Jonathan. When Jether died, he had no sons."
    },
    {
      "verse": "33",
      "text": "Jonathan's sons were: Peleth and Zaza. All those men were Jerahmeel's descendants. All those men were Jerahmeel's descendants."
    },
    {
      "verse": "34",
      "text": "Sheshan did not have any sons but he did have daughters. He had a servant from Egypt called Jarha."
    },
    {
      "verse": "35",
      "text": "Sheshan gave his daughter to his servant Jarha, to be his wife. She gave birth to a son for him, called Attai."
    },
    {
      "verse": "36",
      "text": "Attai became the father of Nathan. Nathan became the father of Zabad."
    },
    {
      "verse": "37",
      "text": "Zabad became the father of Ephlal. Ephlal became the father of Obed."
    },
    {
      "verse": "38",
      "text": "Obed became the father of Jehu. Jehu became the father of Azariah."
    },
    {
      "verse": "39",
      "text": "Azariah became the father of Helez. Helez became the father of Eleasah."
    },
    {
      "verse": "40",
      "text": "Eleasah became the father of Sismai. Sismai became the father of Shallum."
    },
    {
      "verse": "41",
      "text": "Shallum became the father of Jekamiah. Jekamiah became the father of Elishama."
    },
    {
      "verse": "42",
      "text": "The sons of Jerahmeel's brother, Caleb, were: Mesha, his firstborn son. Mesha became the father of Ziph. His son Mareshah became the father of Hebron."
    },
    {
      "verse": "43",
      "text": "Hebron's sons were: Korah, Tappuah, Rekem and Shema."
    },
    {
      "verse": "44",
      "text": "Shema became the father of Raham, who became the father of Jorkeam. Rekem became the father of Shammai."
    },
    {
      "verse": "45",
      "text": "Shammai's son was Maon, who became the father of Beth-Zur."
    },
    {
      "verse": "46",
      "text": "Caleb had a slave wife called Ephah. She gave birth to Haran, Moza and Gazez. Haran became the father of Gazez."
    },
    {
      "verse": "47",
      "text": "Jahdai's sons were: Regem, Jotham, Geshan, Pelet, Ephah and Shaaph."
    },
    {
      "verse": "48",
      "text": "Caleb's other slave wife Maakah gave birth to Sheber, Tirhanah,"
    },
    {
      "verse": "49",
      "text": "Shaaph and Sheva. Shaaph became the father of Madmannah. Sheva became the father of Makbenah and Gibea. Caleb had a daughter called Aksah."
    },
    {
      "verse": "52",
      "text": "The sons of Shobal, the ancestor of Kiriath-Jearim, were: Haroeh, half the Manahath people"
    },
    {
      "verse": "53",
      "text": "and the clans of Kiriath-Jearim: the Ithrites, Puthites, Shumathites and Mishraites. The Zorathites and Eshtaolites were descendants of these clans."
    },
    {
      "verse": "54",
      "text": "Salma's descendants were: the people of Bethlehem, the people of Netophath, the clan of Atroth-Beth-Joab, half the Manahath people and the Zorites."
    },
    {
      "verse": "55",
      "text": "His descendants also included the people who lived in Jabez. They were people who could write down important things. Their clans were called the Tirathites, Shimeathites and Sucathites. These clans were descendants of Hammath, the Kenite man. He was also the ancestor of the Rekabites."
    },
    {
      "verse": "50",
      "text": "Those people were Caleb's descendants. The sons of Ephrath's firstborn son, Hur, were: Shobal, Salma and Hareph. Shobal became the ancestor of Kiriath-Jearim. Salma became the ancestor of Bethlehem. Hareph became the ancestor of Beth-Gader."
    },
    {
      "verse": "51",
      "text": "The sons of Ephrath's firstborn son, Hur, were: Shobal, Salma and Hareph. Shobal became the ancestor of Kiriath-Jearim. Salma became the ancestor of Bethlehem. Hareph became the ancestor of Beth-Gader."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "These sons of David were born in Hebron: The firstborn son was Amnon. His mother was Ahinoam from Jezreel. The second son was Daniel. His mother was Abigail from Carmel."
    },
    {
      "verse": "2",
      "text": "The third son was Absalom. His mother was Maakah, the daughter of Talmai, king of Geshur. The fourth son was Adonijah. His mother was Haggith."
    },
    {
      "verse": "3",
      "text": "The fifth son was Shephatiah. His mother was Abital. The sixth son was Ithream. His mother was David's wife, Eglah."
    },
    {
      "verse": "4",
      "text": "Those six sons of David were all born in Hebron. David ruled in Hebron for seven years and six months. Then he ruled in Jerusalem for 33 years."
    },
    {
      "verse": "5",
      "text": "These are the names of David's sons who were born in Jerusalem: Shimea, Shobab, Nathan and Solomon. The mother of these four sons was Ammiel's daughter, Bathsheba."
    },
    {
      "verse": "6",
      "text": "David had nine other sons: Ibhar, Elishama, Eliphelet,"
    },
    {
      "verse": "7",
      "text": "Nogah, Nepheg, Japhia,"
    },
    {
      "verse": "8",
      "text": "Elishama, Eliada and Eliphelet."
    },
    {
      "verse": "9",
      "text": "Those were all the sons of David's wives. Tamar was their sister. He also had slave wives who gave birth to sons for him."
    },
    {
      "verse": "10",
      "text": "Solomon's son was Rehoboam. Rehoboam's son was Abijah. Abijah's son was Asa. Asa's son was Jehoshaphat."
    },
    {
      "verse": "11",
      "text": "Jehoshaphat's son was Jehoram. Jehoram's son was Ahaziah. Ahaziah's son was Joash."
    },
    {
      "verse": "12",
      "text": "Joash's son was Amaziah. Amaziah's son was Azariah. Azariah's son was Jotham."
    },
    {
      "verse": "13",
      "text": "Jotham's son was Ahaz. Ahaz's son was Hezekiah. Hezekiah's son was Manasseh."
    },
    {
      "verse": "14",
      "text": "Manasseh's son was Amon. Amon's son was Josiah."
    },
    {
      "verse": "15",
      "text": "Josiah's sons: His firstborn son was Johanan. His second son was Jehoiakim. His third son was Zedekiah. His fourth son was Shallum."
    },
    {
      "verse": "16",
      "text": "Jehoiakim's son was Jehoiachin. Jehoiachin's son was Zedekiah."
    },
    {
      "verse": "17",
      "text": "Jeconiah's enemies took him away as their prisoner. His sons were: Shealtiel,"
    },
    {
      "verse": "18",
      "text": "Malkiram, Pedaiah, Shenazzar, Jekamiah, Hoshama and Nedabiah."
    },
    {
      "verse": "19",
      "text": "Pedaiah's sons were: Zerubbabel and Shimei. Zerubbabel's sons were: Meshullam and Hananiah. Their sister was Shelomith."
    },
    {
      "verse": "20",
      "text": "Zerubbabel also had five other sons: Hashubah, Ohel, Berekiah, Hasadiah and Jushab-Hesed."
    },
    {
      "verse": "21",
      "text": "The descendants of Hananiah were: Pelatiah and Jeshaiah. Jeshaiah's son was Rephaiah. Rephaiah's son was Arnan. Arnan's son was Obadiah. Obadiah's son was Shecaniah."
    },
    {
      "verse": "22",
      "text": "The six descendants of Shecaniah were Shemaiah and his sons: Hattush, Igal, Bariah, Neariah and Shaphat."
    },
    {
      "verse": "23",
      "text": "Neariah's three sons were: Elioenai, Hizkiah and Azrikam."
    },
    {
      "verse": "24",
      "text": "Elioenai seven sons were: Hodaviah, Eliashib, Pelaiah, Akkub, Johanan, Delaiah and Anani."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Judah's descendants were: Perez, Hezron, Carmi, Hur and Shobal."
    },
    {
      "verse": "2",
      "text": "Shobal's son Reaiah became the father of Jahath. Jahath became the father of Ahumai and Lahad. Those were the ancestors of the Zorathite clans."
    },
    {
      "verse": "5",
      "text": "Tekoa's father Ashhur had two wives called Helah and Naarah."
    },
    {
      "verse": "6",
      "text": "The sons of Ashhur and his wife Naarah were: Ahuzzam, Hepher, Temeni and Haahashtari."
    },
    {
      "verse": "7",
      "text": "The sons of Ashhur and his wife Helah were: Zereth, Izhar, Ethnan"
    },
    {
      "verse": "8",
      "text": "and Koz. Koz became the father of Anub, Hazzobebah and the clans of Harum's son, Aharhel."
    },
    {
      "verse": "9",
      "text": "Another of Judah's descendants was called Jabez. People respected him more than his brothers. His mother called him Jabez, because she said, ‘I had a lot of pain at his birth. ’"
    },
    {
      "verse": "10",
      "text": "Jabez prayed to Israel's God for help. He said, ‘Please bless me very much and give me more land. Please take care of me so that nothing hurts me and I do not have pain. ’ God did what Jabez had prayed for."
    },
    {
      "verse": "11",
      "text": "Kelub, Shuhah's brother, became the father of Mehir. Mehir became the father of Eshton."
    },
    {
      "verse": "12",
      "text": "Eshton became the father of Beth-Rapha, Paseah and Tehinnah. Tehinnah became the father of Ir-Nahash. Those people lived at Recah."
    },
    {
      "verse": "13",
      "text": "The sons of Kenaz were: Othniel and Seraiah. Othniel's sons were: Hathath and Meonothai."
    },
    {
      "verse": "14",
      "text": "Meonothai became the father of Ophrah. Seraiah became the father of Joab. Joab was the ancestor of the people who live in Ge-Harashim. Those people had special skills to make things. Seraiah became the father of Joab. Joab was the ancestor of the people who live in Ge-Harashim. Those people had special skills to make things."
    },
    {
      "verse": "15",
      "text": "The sons of Jephunneh's son Caleb were: Iru, Elah and Naam. Elah's son was Kenaz."
    },
    {
      "verse": "16",
      "text": "Jehallelel's sons were: Ziph, Ziphah, Tiria and Asarel."
    },
    {
      "verse": "19",
      "text": "Hodiah's wife was Naham's sister. She gave birth to two sons. One of them became the father of Keilah, the ancestor of the Garmites. The other son became the father of Eshtemoa, the ancestor of the Maakathites."
    },
    {
      "verse": "20",
      "text": "Shimon's sons were: Amnon, Rinnah, Ben-Hanan and Tilon. Ishi's descendants were Zoheth and Ben-Zoheth. Ishi's descendants were Zoheth and Ben-Zoheth."
    },
    {
      "verse": "23",
      "text": "Those people made pots. They lived in Netaim and Gederah. They lived there and they worked for the king."
    },
    {
      "verse": "24",
      "text": "Simeon's descendants were: Nemuel, Jamin, Jarib, Zerah and Shaul."
    },
    {
      "verse": "25",
      "text": "Shaul's son was Shallum. Shallum's son was Mibsam. Mibsam's son was Mishma."
    },
    {
      "verse": "26",
      "text": "Mishma's descendants were his son Hammuel, Hammuel's son Zaccur, and Zaccur's son Shimei."
    },
    {
      "verse": "27",
      "text": "sons and six daughters. But his brothers did not have many children. So their clan did not become as large as the people of Judah's tribe."
    },
    {
      "verse": "28",
      "text": "Shimei's descendants lived in these cities and towns: Beersheba, Moladah, Hazar-Shual,"
    },
    {
      "verse": "29",
      "text": "Bilhah, Ezem, Tolad,"
    },
    {
      "verse": "30",
      "text": "Bethuel, Hormah, Ziklag,"
    },
    {
      "verse": "31",
      "text": "Beth-Marcaboth, Hazar-Susim, Beth-Biri and Shaaraim. They lived in those places until David became king."
    },
    {
      "verse": "32",
      "text": "They also lived in these five villages: Etam, Ain, Rimmon, Token and Ashan."
    },
    {
      "verse": "33",
      "text": "There were also other villages round the same towns, as far as Baalath town. Those were the places where they lived. They wrote down a list of the names of their ancestors."
    },
    {
      "verse": "34",
      "text": "The leaders of their clans were: Meshobab, Jamlech, Amaziah's son Joshah,"
    },
    {
      "verse": "35",
      "text": "Joel, Jehu (son of Joshibiah, who was the son of Seraiah and grandson of Asiel),"
    },
    {
      "verse": "36",
      "text": "Elioenai, Jaakobah, Jeshohaiah, Asaiah, Adiel, Jesimiel, Benaiah"
    },
    {
      "verse": "37",
      "text": "and Ziza. Ziza was the son of Shiphi, who was the son of Allon and grandson of Jedaiah. Jedaiah was the son of Shimri and grandson of Shemaiah."
    },
    {
      "verse": "38",
      "text": "Those men were the leaders of their clans. Their families became very large."
    },
    {
      "verse": "39",
      "text": "They travelled to the east side of the valley to find grass for their sheep to eat. They went as far as Gedor."
    },
    {
      "verse": "40",
      "text": "They found good fields that had plenty of grass. The soil was good and the place was large. There were no troubles in that region. Some descendants of Ham had been living there."
    },
    {
      "verse": "41",
      "text": "When Hezekiah was the king of Judah, those leaders of Simeon's clans attacked the people who lived there. Some of those people were called Meunites. The men of Simeon destroyed their homes and they killed all the people. So even today none of those people still live there. Simeon's people lived there instead, because there was good grass for their sheep."
    },
    {
      "verse": "42",
      "text": "Later, another 500 men of Simeon's tribe went to the hill country of Seir. Their leaders were Ishi's sons: Pelatiah, Neariah, Rephaiah and Uzziel."
    },
    {
      "verse": "43",
      "text": "They killed all the descendants of Amalek who were still alive. They took their land and they still live there now."
    },
    {
      "verse": "3",
      "text": "Caleb's wife Ephrathah gave birth to their firstborn son, Hur. Hur was the ancestor of the people of Bethlehem. His three sons were Etam, Penuel and Ezer. Etam's sons were: Jezreel, Ishma and Idbash. Their sister was Hazzelelponi. Penuel became the father of Gedor."
    },
    {
      "verse": "4",
      "text": "Ezer became the father of Hushah. Etam's sons were: Jezreel, Ishma and Idbash. Their sister was Hazzelelponi. Penuel became the father of Gedor. Ezer became the father of Hushah."
    },
    {
      "verse": "17",
      "text": "Ezrah's sons were: Jether, Mered, Epher and Jalon. Mered married Bithiah. Her father was the king of Egypt. The children of Mered and Bithiah were: Miriam, Shammai and Ishbah. Ishbah became the father of Eshtemoa. Mered had another wife who belonged to Judah's tribe. Her sons were Jered, Heber and Jekuthiel. Jered became the father of Gedor. Heber became the father of Soco. And Jekuthiel became the father of Zanoah."
    },
    {
      "verse": "18",
      "text": "Mered married Bithiah. Her father was the king of Egypt. The children of Mered and Bithiah were: Miriam, Shammai and Ishbah. Ishbah became the father of Eshtemoa. Mered had another wife who belonged to Judah's tribe. Her sons were Jered, Heber and Jekuthiel. Jered became the father of Gedor. Heber became the father of Soco. And Jekuthiel became the father of Zanoah."
    },
    {
      "verse": "21",
      "text": "These were the sons of Judah's son, Shelah: Er, Laadah, Jokim, Joash, Saraph and Jashubi-Lehem. Er became the father of Lecah. Laadah became the father of Mareshah. Joash and Saraph both married women from Moab and they returned to live in Lehem."
    },
    {
      "verse": "22",
      "text": "Other clans that were descendants of Shelah worked with linen at Beth-Ashbea, and some lived in Cozeba. (These lists are from old history books. )."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Reuben was Israel's firstborn son. That is, Reuben was born first. But he had sex with his father's slave wife. So his father took away the benefits that belong to a firstborn son. Instead, Israel gave those benefits to his son Joseph's sons. So Reuben does not have the first place in the list of Israel's sons."
    },
    {
      "verse": "2",
      "text": "Judah became stronger than all his brothers. Israel's ruler came from his tribe. But it was Joseph who received the benefits that belong to the firstborn son."
    },
    {
      "verse": "3",
      "text": "The sons of Reuben, Israel's oldest son, were: Hanoch, Pallu, Hezron and Carmi."
    },
    {
      "verse": "4",
      "text": "Joel's descendants were: His son Shemaiah. Shemaiah's son Gog. Gog's son Shimei."
    },
    {
      "verse": "5",
      "text": "Shimei's son Micah. Micah's son Reaiah. Reaiah's son Baal."
    },
    {
      "verse": "6",
      "text": "Baal's son Beerah. Beerah was a leader of Reuben's tribe. Tiglath-Pileser, king of Assyria, took him away to Assyria as his prisoner."
    },
    {
      "verse": "7",
      "text": "The lists of Reuben's descendants include these leaders of their clans: Jeiel was the first, then Zechariah and Bela."
    },
    {
      "verse": "8",
      "text": "Bela was the son of Azaz. Azaz was the son of Shema. Shema was the son of Joel. Reuben's people lived in the region of Aroer, as far north as Nebo and Baal-Meon."
    },
    {
      "verse": "9",
      "text": "Their east border was the desert that goes all the way to the Euphrates River. They had too many animals to feed in the region of Gilead. So they had to live in all those other places too."
    },
    {
      "verse": "10",
      "text": "When Saul was Israel's king, the men of Reuben's tribe attacked the Hagrites. They won the fight. Then they moved into their land to live. That was the whole region that was east of Gilead."
    },
    {
      "verse": "11",
      "text": "Gad's descendants lived in the region of Bashan, near the people of Reuben's tribe. Their land went as far as Salecah town in the east."
    },
    {
      "verse": "12",
      "text": "Joel was the most important leader. Shapham was the second leader. Janai and Shaphat were also leaders in Bashan."
    },
    {
      "verse": "13",
      "text": "Their relatives in each of their seven clans were: Michael, Meshullam, Sheba, Jorai, Jacan, Zia and Eber."
    },
    {
      "verse": "14",
      "text": "They were all descendants of Abihail. Abihail was Huri's son. Huri was Jaroah's son. Jaroah was Gilead's son. Gilead was Michael's son. Michael was Jeshishai's son. Jeshishai was Jahdo's son. Jahdo was the son of Buz."
    },
    {
      "verse": "15",
      "text": "Ahi, son of Abdiel and grandson of Guni, was the leader of their clan."
    },
    {
      "verse": "16",
      "text": "Gad's descendants lived in Gilead, in Bashan, and in the small towns near there. They also lived in the whole land of Sharon where there was grass to feed their animals."
    },
    {
      "verse": "17",
      "text": "The names of Gad's descendants were written down at the time when Jotham was king of Judah and Jeroboam was king of Israel."
    },
    {
      "verse": "18",
      "text": "The tribes of Reuben, Gad and half of the tribe of Manasseh had a large army. They had 44, 760 brave soldiers who knew how to fight well. Their weapons were shields, swords, and bows and arrows."
    },
    {
      "verse": "19",
      "text": "They attacked the Hagrites and the people in Jetur, Naphish and Nodab."
    },
    {
      "verse": "20",
      "text": "God helped their army to fight against their enemies. He put the Hagrites under their power, as well as the other people who fought with them. The soldiers of Manasseh, Reuben and Gad called out to God for help during the battle. God answered their prayers because they trusted him."
    },
    {
      "verse": "21",
      "text": "They took all their enemies' animals. They included 50, 000 camels, 250, 000 sheep and 2, 000 donkeys. They also caught 100, 000 people as their prisoners."
    },
    {
      "verse": "22",
      "text": "They killed many of their enemy's soldiers because God was fighting for them. Reuben, Gad and half of Manasseh's tribe took the land where the Hagrites had lived. They continued to live there until the exile of Judah's people."
    },
    {
      "verse": "23",
      "text": "Half of Manasseh's tribe lived in the region of Bashan, on the east side of the Jordan River. Their borders were Baal-Hermon, Senir and Hermon mountain. They became very many people."
    },
    {
      "verse": "24",
      "text": "These men were the leaders of their clans: Epher, Ishi, Eliel, Azriel, Jeremiah, Hodaviah and Jahdiel. They were brave soldiers and people respected them. They were leaders of their clans."
    },
    {
      "verse": "25",
      "text": "But they turned away from the God that their ancestors had worshipped. He had chased the other nations out of the land where his people now lived. But now they started to worship the gods of those nations."
    },
    {
      "verse": "26",
      "text": "So the God of Israel caused King Pul of Assyria to attack their land. That king is also called King Tiglath-Pileser. He won the fight against the people of Reuben, Gad and the half tribe of Manasseh. He took them away as his prisoners to Halah, to Habor, to Hara and to the Gozan river. They are still living there, even today."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "Levi's sons were: Gershon, Kohath and Merari."
    },
    {
      "verse": "2",
      "text": "Kohath's sons were: Amram, Izhar, Hebron and Uzziel."
    },
    {
      "verse": "3",
      "text": "Amram's children were: Aaron, Moses and Miriam. Aaron's sons were: Nadab, Abihu, Eleazar and Ithamar. Aaron's sons were: Nadab, Abihu, Eleazar and Ithamar."
    },
    {
      "verse": "4",
      "text": "Eleazar became the father of Phinehas. Phinehas became the father of Abishua."
    },
    {
      "verse": "5",
      "text": "Abishua became the father of Bukki. Bukki became the father of Uzzi."
    },
    {
      "verse": "6",
      "text": "Uzzi became the father of Zerahiah. Zerahiah became the father of Meraioth."
    },
    {
      "verse": "7",
      "text": "Meraioth became the father of Amariah. Amariah became the father of Ahitub."
    },
    {
      "verse": "8",
      "text": "Ahitub became the father of Zadok. Zadok became the father of Ahimaaz."
    },
    {
      "verse": "9",
      "text": "Ahimaaz became the father of Azariah. Azariah became the father of Johanan."
    },
    {
      "verse": "10",
      "text": "Johanan became the father of Azariah. Azariah served God as a priest in the temple that Solomon built in Jerusalem."
    },
    {
      "verse": "11",
      "text": "Azariah became the father of Amariah. Amariah became the father of Ahitub."
    },
    {
      "verse": "12",
      "text": "Ahitub became the father of Zadok. Zadok became the father of Shallum."
    },
    {
      "verse": "13",
      "text": "Shallum became the father of Hilkiah. Hilkiah became the father of Azariah."
    },
    {
      "verse": "14",
      "text": "Azariah became the father of Seraiah. Seraiah became the father of Jehozadak."
    },
    {
      "verse": "15",
      "text": "Jehozadak went into exile with the people from Jerusalem and the rest of Judah. The Lord used Nebuchadnezzar to take them away to Babylon."
    },
    {
      "verse": "16",
      "text": "Levi's sons were: Gershon, Kohath and Merari."
    },
    {
      "verse": "17",
      "text": "The names of Gershon's sons were Libni and Shimei."
    },
    {
      "verse": "18",
      "text": "Kohath's sons were: Amram, Izhar, Hebron and Uzziel."
    },
    {
      "verse": "19",
      "text": "Merari's sons were: Mahli and Mushi. These are the ancestors of the clans of the Levites: These are the ancestors of the clans of the Levites:"
    },
    {
      "verse": "20",
      "text": "Gershon's descendants were his son Libni, Libni's son Jahath and Jahath's son Zimmah."
    },
    {
      "verse": "21",
      "text": "Zimmah's son was Joah. Joah's son was Iddo. Iddo's son was Zerah. Zerah's son was Jeatherai."
    },
    {
      "verse": "22",
      "text": "Kohath's descendants were his son Amminadab, Amminadab's son Korah and Korah's son Assir."
    },
    {
      "verse": "23",
      "text": "Assir's son was Elkanah. Elkanah's son was Ebiasaph. Ebiasaph's son was Assir."
    },
    {
      "verse": "24",
      "text": "Assir's son was Tahath. Tahath's son was Uriel. Uriel's son was Uzziah. Uzziah's son was Shaul."
    },
    {
      "verse": "25",
      "text": "Elkanah's other sons were Amasai and Ahimoth."
    },
    {
      "verse": "26",
      "text": "Ahimoth's son was Elkanah. Elkanah's son was Zophai. Zophai's son was Nahath."
    },
    {
      "verse": "27",
      "text": "Nahath's son was Eliab. Eliab's son was Jeroham. Jeroham's son was Elkanah."
    },
    {
      "verse": "28",
      "text": "Samuel's firstborn son was Joel and his second son was Abijah."
    },
    {
      "verse": "29",
      "text": "Merari's descendants were his son Mahli, Mahli's son Libni, Libni's son Shimei and Shimei's son Uzzah."
    },
    {
      "verse": "30",
      "text": "Uzzah's son was Shimea. Shimea's son was Haggiah. Haggiah's son was Asaiah."
    },
    {
      "verse": "31",
      "text": "After David put God's Covenant Box in the Lord's house, he chose some men to lead the music there."
    },
    {
      "verse": "32",
      "text": "They used music to serve the Lord in his special tent where he met with his people. After King Solomon built the Lord's temple in Jerusalem, they served the Lord there. They obeyed the rules that told them how to do their work."
    },
    {
      "verse": "33",
      "text": "These are the leaders of the music and their sons: From Kohath's clan: Heman the singer. He was Joel's son. Joel was Samuel's son."
    },
    {
      "verse": "34",
      "text": "Samuel was Elkanah's son. Elkanah was Jeroham's son. Jeroham was Eliel's son. Eliel was Toah's son."
    },
    {
      "verse": "35",
      "text": "Toah was Zuph's son. Zuph was Elkanah's son. Elkanah was Mahath's son. Mahath was Amasai's son."
    },
    {
      "verse": "36",
      "text": "Amasai was Elkanah's son. Elkanah was Joel's son. Joel was Azariah's son. Azariah was Zephaniah's son."
    },
    {
      "verse": "37",
      "text": "Zephaniah was Tahath's son. Tahath was Assir's son. Assir was Ebiasaph's son. Ebiasaph was Korah's son."
    },
    {
      "verse": "38",
      "text": "Korah was Izhar's son. Izhar was Kohath's son. Kohath was Levi's son. Levi was Israel's son."
    },
    {
      "verse": "39",
      "text": "Heman worked with his relative, Asaph. Asaph was Heman's helper. He was Berekiah's son. Berekiah was Shimea's son."
    },
    {
      "verse": "40",
      "text": "Shimea was Michael's son. Michael was Baaseiah's son. Baaseiah was Malkijah's son."
    },
    {
      "verse": "41",
      "text": "Malkijah was Ethni's son. Ethni was Zerah's son. Zerah was Adaiah's son."
    },
    {
      "verse": "42",
      "text": "Adaiah was Ethan's son. Ethan was Zimmah's son. Zimmah was Shimei's son."
    },
    {
      "verse": "43",
      "text": "Shimei was Jahath's son. Jahath was Gershon's son. Gershon was Levi's son."
    },
    {
      "verse": "44",
      "text": "Other relatives of Heman and Asaph worked with them. They belonged to Merari's clan and they stood on the left side. Kishi's son Ethan led this group. Kishi was Abdi's son. Abdi was Malluch's son."
    },
    {
      "verse": "45",
      "text": "Malluch was Hashabiah's son. Hashabiah was Amaziah's son. Amaziah was Hilkiah's son."
    },
    {
      "verse": "46",
      "text": "Hilkiah was Amzi's son. Amzi was Bani's son. Bani was Shemer's son."
    },
    {
      "verse": "47",
      "text": "Shemer was Mahli's son. Mahli was Mushi's son. Mushi was Merari's son. Merari was Levi's son."
    },
    {
      "verse": "48",
      "text": "All the other Levites also had jobs to do in God's special tent."
    },
    {
      "verse": "49",
      "text": "Only Aaron and his descendants served God as priests. They offered sacrifices to God on the altar for burnt offerings. They also burned sweet oils on the altar for incense. That was their work in the Most Holy Place. They made sacrifices so that God would forgive the sins of the Israelites. They did all this in the way that God's servant Moses had commanded."
    },
    {
      "verse": "50",
      "text": "These were Aaron's descendants: Eleazar was Aaron's son. Phinehas was Eleazar's son. Abishua was Phinehas's son."
    },
    {
      "verse": "51",
      "text": "Bukki was Abishua's son. Uzzi was Bukki's son. Zerahiah was Uzzi's son."
    },
    {
      "verse": "52",
      "text": "Meraioth was Zerahiah's son. Amariah was Meraioth's son. Ahitub was Amariah's son."
    },
    {
      "verse": "53",
      "text": "Zadok was Ahitub's son. Ahimaaz was Zadok's son."
    },
    {
      "verse": "54",
      "text": "Aaron's descendants belonged to the clan of Levi's son, Kohath. When the leaders used lots to divide the land, Kohath's clan received the first part of the land. These places belonged to them:"
    },
    {
      "verse": "55",
      "text": "They had Hebron city in Judah's land. They had the fields around the city."
    },
    {
      "verse": "56",
      "text": "But Jephunneh's son, Caleb, had the villages around the city, with their fields."
    },
    {
      "verse": "57",
      "text": "Aaron's descendants received these towns with the fields around them: Hebron (a safe city), Libnah, Jattir, Eshtemoa,"
    },
    {
      "verse": "58",
      "text": "Hilen, Debir,"
    },
    {
      "verse": "59",
      "text": "Ashan, Juttah and Beth-Shemesh."
    },
    {
      "verse": "60",
      "text": "They also received some towns in land that belonged to Benjamin's tribe. They received these towns with the fields around them: Gibeon, Geba, Alemeth and Anathoth. So there were 13 towns for Aaron's descendants to live in. towns for Aaron's descendants to live in."
    },
    {
      "verse": "61",
      "text": "The other people who were Kohath's descendants received ten towns in land that belonged to the half tribe of Manasseh. They used lots to choose the towns."
    },
    {
      "verse": "62",
      "text": "Gershon's descendants received 13 towns. The lots showed which towns they would receive. Their towns were in land that belonged to the tribes of Issachar, Asher and Naphtali, as well as in Manasseh's land in the region of Bashan, on the east side of the Jordan River."
    },
    {
      "verse": "63",
      "text": "Merari's descendants received 12 towns. The lots showed which towns they would receive. Their towns were in land that belonged to the tribes of Reuben, Gad and Zebulun."
    },
    {
      "verse": "64",
      "text": "So the Israelites gave those towns and the fields around them to the Levites."
    },
    {
      "verse": "65",
      "text": "They used lots to choose these towns, including the towns in land that belonged to the tribes of Judah, Simeon and Benjamin."
    },
    {
      "verse": "66",
      "text": "Descendants of Kohath received towns in land that belonged to Ephraim's tribe. They received these towns with the fields around them:"
    },
    {
      "verse": "67",
      "text": "Shechem (a safe city in the hill country of Ephraim), Gezer,"
    },
    {
      "verse": "68",
      "text": "Jokmeam, Beth-Horon,"
    },
    {
      "verse": "69",
      "text": "Aijalon and Gath-Rimmon."
    },
    {
      "verse": "70",
      "text": "The other descendants of Kohath received towns in land that belonged to the half tribe of Manasseh. They received Aner with its fields and Bileam with its fields."
    },
    {
      "verse": "71",
      "text": "The descendants of Gershon received these towns in land that belonged to the other half tribe of Manasseh: Golan in Bashan with its fields and Ashtaroth with its fields."
    },
    {
      "verse": "72",
      "text": "They also received towns in land that belonged to Issachar's tribe. They received these towns and the fields around them: Kedesh, Daberath,"
    },
    {
      "verse": "73",
      "text": "Ramoth and Anem."
    },
    {
      "verse": "74",
      "text": "They received these towns in land that belonged to Asher's tribe: Mashal with its fields, Abdon with its fields,"
    },
    {
      "verse": "75",
      "text": "Hukok with its fields and Rehob with its fields."
    },
    {
      "verse": "76",
      "text": "They received these towns in land that belonged to Naphtali's tribe: Kedesh in Galilee with its fields, Hammon with its fields and Kiriathaim with its fields."
    },
    {
      "verse": "77",
      "text": "The rest of Levi's descendants, who belonged to Merari's clan, received these towns: In land that belonged to Zebulun's tribe they received Rimmono with its fields and Tabor with its fields."
    },
    {
      "verse": "78",
      "text": "They also received towns in land that belonged to Reuben's tribe on the east side of the Jordan River, beyond Jericho city. They received these towns and the fields around them: Bezer in the desert, Jahzah,"
    },
    {
      "verse": "79",
      "text": "Kedemoth and Mephaath."
    },
    {
      "verse": "80",
      "text": "They received these towns in land that belonged to Gad's tribe: Ramoth in Gilead with its fields, Mahanaim with its fields,"
    },
    {
      "verse": "81",
      "text": "Heshbon with its fields and Jazer with its fields."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "Issachar had four sons. They were Tola, Puah, Jashub and Shimron."
    },
    {
      "verse": "2",
      "text": "Tola's sons were Uzzi, Rephaiah, Jeriel, Jahmai, Ibsam and Samuel. They were leaders of their clans. Among Tola's descendants there were 22, 600 brave soldiers when David was king."
    },
    {
      "verse": "3",
      "text": "Uzzi's son was Izrahiah. Izrahiah's sons were Michael, Obadiah, Joel and Isshiah. All those five men in Uzzi's family were leaders."
    },
    {
      "verse": "4",
      "text": "The books of their clans show that they had many wives and sons. They had 36, 000 men who were ready to fight in the army."
    },
    {
      "verse": "5",
      "text": "The books of the clans of Issachar show that they had 87, 000 brave soldiers."
    },
    {
      "verse": "6",
      "text": "Benjamin had three sons. They were Bela, Becher and Jediael."
    },
    {
      "verse": "7",
      "text": "Bela had five sons. They were Ezbon, Uzzi, Uzziel, Jerimoth and Iri. They were leaders of their clans. The books of their ancestors show that they had 22, 034 brave soldiers."
    },
    {
      "verse": "8",
      "text": "Becher's sons were Zemirah, Joash, Eliezer, Elioenai, Omri, Jeremoth, Abijah, Anathoth and Alemeth. All those men were sons of Becher."
    },
    {
      "verse": "9",
      "text": "The books of their ancestors include a list of those clan leaders. Also the books show that they had 22, 200 brave soldiers."
    },
    {
      "verse": "10",
      "text": "Jediael's son was Bilhan. Bilhan's sons were Jeush, Benjamin, Ehud, Kenaanah, Zethan, Tarshish and Ahishahar."
    },
    {
      "verse": "11",
      "text": "All those sons of Jediael were leaders of their clans. They had 17, 200 brave soldiers who were ready to fight in the army."
    },
    {
      "verse": "12",
      "text": "Shuppim and Huppim were descendants of Ir. The people called the Hushim were descendants of Aher."
    },
    {
      "verse": "13",
      "text": "Naphtali's sons were Jahziel, Guni, Jezer and Shallum. They were Bilhah's grandsons."
    },
    {
      "verse": "14",
      "text": "These are Manasseh's descendants. Manasseh had a woman that he lived with. She was from the country called Syria. She was the mother of Asriel and Makir. Makir was Gilead's father."
    },
    {
      "verse": "15",
      "text": "Makir's wife was one of the Huppim and Shuppim people. His sister's name was Maakah. Zelophehad was another descendant of Makir. Zelophehad had only daughters."
    },
    {
      "verse": "16",
      "text": "Makir's wife Maakah had a son and she called him Peresh. Peresh's brother was Sheresh and Sheresh's sons were Ulam and Rekem."
    },
    {
      "verse": "17",
      "text": "Ulam's son was Bedan. These were the sons of Gilead. Gilead was the son of Makir and Makir was Manasseh's son."
    },
    {
      "verse": "18",
      "text": "Hammoleketh was Gilead's sister. And she had sons called Ishhod, Abiezer and Mahlah."
    },
    {
      "verse": "19",
      "text": "The sons of Shemida were Ahian, Shechem, Likhi and Aniam."
    },
    {
      "verse": "20",
      "text": "These are the names of Ephraim's descendants. Ephraim's son was Shuthelah. Shuthelah's son was Bered and Bered's son was Tahath. Tahath's son was Eleadah and Eleadah's son was Tahath."
    },
    {
      "verse": "21",
      "text": "Tahath's son was Zabad and Zabad's son was Shuthelah. Ezer and Elead were also sons of Ephraim. They went to Gath and they tried to take some cows and sheep from there. So some men who were born in that city killed them."
    },
    {
      "verse": "22",
      "text": "Their father Ephraim cried for them and he was sad for many days. And his family came to help him."
    },
    {
      "verse": "23",
      "text": "Then Ephraim had sex with his wife and they had another son. Ephraim called him Beriah. That name means ‘trouble’. Ephraim chose that name because of his family's troubles."
    },
    {
      "verse": "24",
      "text": "Beriah's daughter was Sheerah. She built Lower and Higher Beth-Horon. And she built Uzzen-Sheerah."
    },
    {
      "verse": "25",
      "text": "And Beriah's son was Rephah. And Rephah's son was Resheph. Resheph's son was Telah and Telah's son was Tahan."
    },
    {
      "verse": "26",
      "text": "Tahan's son was Ladan. Ladan's son was Ammihud and Ammihud's son was Elishama."
    },
    {
      "verse": "27",
      "text": "Elishama's son was Nun and Joshua was the son of Nun."
    },
    {
      "verse": "28",
      "text": "Ephraim's descendants lived in Bethel and in the villages near it. And they had land there. Also they lived in Naaran in the east. And they lived in Gezer and in the villages near it. Those places were in the west. Also, they lived in Shechem and in the villages near it. And they lived in Ayyah and in the villages near it."
    },
    {
      "verse": "29",
      "text": "Along the borders of the land which belonged to Manasseh's descendants were other towns. They included Beth-Shan and the villages near it and Taanach and its villages. They also included Megiddo and its villages and Dor and its villages. The descendants of Joseph (son of Israel) lived in those towns and villages."
    },
    {
      "verse": "30",
      "text": "Asher's sons were Imnah, Ishvah, Ishvi and Beriah and their sister was Serah."
    },
    {
      "verse": "31",
      "text": "Beriah's sons were Heber and Malkiel and Malkiel was Birzaith's father."
    },
    {
      "verse": "32",
      "text": "Heber was the father of Japhlet, Shomer, Hotham and their sister Shua."
    },
    {
      "verse": "33",
      "text": "Japhlet's sons were Pasach, Bimhal and Ashvath. They were Japhlet's sons."
    },
    {
      "verse": "34",
      "text": "Shemer's sons were Ahi, Rohgah, Hubbah and Aram."
    },
    {
      "verse": "35",
      "text": "Shemer's brother was Helem and Helem's sons were Zophah, Imna, Shelesh and Amal."
    },
    {
      "verse": "38",
      "text": "Jether's sons were Jephunneh, Pispah and Ara."
    },
    {
      "verse": "39",
      "text": "Ulla's sons were Arah, Hanniel and Rizia."
    },
    {
      "verse": "40",
      "text": "All those men were descendants of Asher. They were leaders of their clans. They were great and brave soldiers and great leaders. They had 26, 000 men ready to fight in the army. There were lists that showed those men's names with their clans."
    },
    {
      "verse": "36",
      "text": "Zophah's sons were Suah, Harnepher, Shual, Beri, Imrah, Bezer, Hod, Shamma, Shilshah, Ithran and Beera."
    },
    {
      "verse": "37",
      "text": "."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Benjamin became the father of Bela, his firstborn son. Ashbel was his second son. Aharah was his third son."
    },
    {
      "verse": "2",
      "text": "Nohah was his fourth son. Rapha was his fifth son."
    },
    {
      "verse": "3",
      "text": "Bela's sons were: Addar, Gera, Abihud,"
    },
    {
      "verse": "4",
      "text": "Abishua, Naaman, Ahoah,"
    },
    {
      "verse": "5",
      "text": "Gera, Shephuphan and Huram."
    },
    {
      "verse": "6",
      "text": "Here is a list of the descendants of Ehud who were the leaders of their clans. They were living in Geba, but they had to leave there and move to Manahath."
    },
    {
      "verse": "7",
      "text": "Ehud's descendants were: Naaman, Ahijah and Gera. It was Gera who led them to Manahath. He became the father of Uzza and Ahihud."
    },
    {
      "verse": "14",
      "text": "Beriah's descendants were: Ahio, Shashak, Jeremoth,"
    },
    {
      "verse": "15",
      "text": "Zebadiah, Arad, Eder,"
    },
    {
      "verse": "16",
      "text": "Michael, Ishpah and Joha."
    },
    {
      "verse": "17",
      "text": "Elpaal's descendants were: Zebadiah, Meshullam, Hizki, Heber,"
    },
    {
      "verse": "18",
      "text": "Ishmerai, Izliah and Jobab."
    },
    {
      "verse": "19",
      "text": "Shimei's descendants were: Jakim, Zikri, Zabdi,"
    },
    {
      "verse": "20",
      "text": "Elienai, Zillethai, Eliel,"
    },
    {
      "verse": "21",
      "text": "Adaiah, Beraiah and Shimrath."
    },
    {
      "verse": "22",
      "text": "Shashak's descendants were: Ishpan, Eber, Eliel,"
    },
    {
      "verse": "23",
      "text": "Abdon, Zikri, Hanan,"
    },
    {
      "verse": "24",
      "text": "Hananiah, Elam, Anthothijah,"
    },
    {
      "verse": "25",
      "text": "Iphdeiah and Penuel."
    },
    {
      "verse": "26",
      "text": "Jeroham's descendants were: Shamsherai, Shehariah, Athaliah,"
    },
    {
      "verse": "27",
      "text": "Jaareshiah, Elijah and Zikri."
    },
    {
      "verse": "28",
      "text": "The history books show that all those men were leaders of their clans. They lived in Jerusalem."
    },
    {
      "verse": "29",
      "text": "Gibeon's father lived in Gibeon town. His wife's name was Maakah."
    },
    {
      "verse": "30",
      "text": "His firstborn son was Abdon. His other sons were Zur, Kish, Baal, Nadab,"
    },
    {
      "verse": "31",
      "text": "Gedor, Ahio, Zeker and Mikloth."
    },
    {
      "verse": "32",
      "text": "Mikloth became the father of Shimeah. They lived near their relatives in Jerusalem."
    },
    {
      "verse": "33",
      "text": "Ner became the father of Kish. Kish became the father of Saul. Saul became the father of Jonathan, Malki-Shua, Abinadab and Esh-Baal."
    },
    {
      "verse": "34",
      "text": "Jonathan's son was Merib-Baal. Merib-Baal became the father of Micah."
    },
    {
      "verse": "35",
      "text": "Micah's sons were: Pithon, Melech, Tarea and Ahaz."
    },
    {
      "verse": "36",
      "text": "Ahaz became the father of Jehoaddah. Jehoaddah became the father of Alemeth, Azmaveth and Zimri. Zimri became the father of Moza."
    },
    {
      "verse": "37",
      "text": "Moza became the father of Binea. Binea's son was Raphah. Raphah's son was Eleasah. Eleasah's son was Azel."
    },
    {
      "verse": "38",
      "text": "Azel had six sons: Azrikam, Bokeru, Ishmael, Sheariah, Obadiah and Hanan. That is the list of Azel's sons."
    },
    {
      "verse": "39",
      "text": "Azel's brother was Eshek. Eshek's sons were: Ulam, his firstborn son, then Jeush and then Eliphelet."
    },
    {
      "verse": "40",
      "text": "Ulam's sons were brave soldiers. They could shoot arrows very well. They had 150 sons and grandsons. All those men were descendants of Benjamin."
    },
    {
      "verse": "8",
      "text": "Shaharaim and his wife Hushim had sons called Abitub and Elpaal. In Moab, Shaharaim sent away his two wives, Hushim and Baara."
    },
    {
      "verse": "9",
      "text": "After that, Shaharaim married Hodesh."
    },
    {
      "verse": "10",
      "text": "They had sons called Jobab, Zibia, Mesha, Malcam, Jeuz, Sakia and Mirmah."
    },
    {
      "verse": "11",
      "text": "They were leaders of their clans."
    },
    {
      "verse": "12",
      "text": "Elpaal's sons were: Eber, Misham, Shemed, Beriah and Shema. Shemed built the towns of Ono and Lod, and the villages around them."
    },
    {
      "verse": "13",
      "text": "Beriah and Shema were leaders of the clans that lived in Aijalon city. They chased the people of Gath out of their city."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "All the Israelites' names were included in the lists of their ancestors. Those lists are written in the history book about Israel's kings. The people of Judah had turned away from the Lord. Their enemies took them away to Babylon as their prisoners."
    },
    {
      "verse": "2",
      "text": "The first people who returned to their home towns after that were some priests, Levites, servants in the temple and other Israelites."
    },
    {
      "verse": "5",
      "text": "From the clan of Judah's son Shelah, there were Asaiah and his sons. Asaiah was the oldest son in his family."
    },
    {
      "verse": "6",
      "text": "From the clan of Judah's son Zerah, there was Jeuel. There were 690 people from Judah's tribe who returned. people from Judah's tribe who returned."
    },
    {
      "verse": "7",
      "text": "From Benjamin's tribe, there was: Sallu, the son of Meshullam and grandson of Hodaviah, who was Hassenuah's son."
    },
    {
      "verse": "8",
      "text": "There was also Jeroham's son Ibneiah, Elah the son of Uzzi and grandson of Mikri's, and Meshullam, son of Shephatiah and grandson of Reuel, who was Ibnijah's son."
    },
    {
      "verse": "9",
      "text": "people from Benjamin's tribe who returned. Their names are written in the lists of their ancestors. All those men were leaders of their clans."
    },
    {
      "verse": "10",
      "text": "The priests who returned to live in Jerusalem were: Jedaiah, Jehoiarib, Jakin and Azariah."
    },
    {
      "verse": "11",
      "text": "Azariah was Hilkiah's son. Hilkiah was Meshullam's son. Meshullam was Zadok's son. Zadok was Meraioth's son. Meraioth was Ahitub's son. Ahitub was the most important officer in God's temple."
    },
    {
      "verse": "12",
      "text": "There was also Adaiah, the son of Jeroham and grandson of Pashhur, who was Malkijah's son. And there was Maasai, the son of Adiel and grandson of Jahzerah. Jahzerah was Meshullam's son. Meshullam was Meshillemith's son, and Meshillemith was Immer's son."
    },
    {
      "verse": "13",
      "text": "There were 1, 760 priests and their relatives who returned. They were leaders of their clans. They were able to do their jobs well as they served God in his temple."
    },
    {
      "verse": "14",
      "text": "From the Levites, there were: Shemaiah, the son of Hasshub and grandson of Azrikam, who was Hashabiah's son. Hashabiah belonged to Merari's clan."
    },
    {
      "verse": "15",
      "text": "There was Bakbakkar, Heresh, Galal and Mattaniah, the son of Mica and grandson of Zikri, who was a descendant of Asaph."
    },
    {
      "verse": "16",
      "text": "There was also Obadiah, the son of Shemaiah and grandson of Galal, who was Jeduthun's son. And there was Berekiah, the son of Asa and grandson of Elkanah. Elkanah had lived in the villages of the Netophath people."
    },
    {
      "verse": "17",
      "text": "The Levite guards at the gates of the temple were: Shallum, Akkub, Talmon, Ahiman and their relatives. Shallum was their leader."
    },
    {
      "verse": "18",
      "text": "Those guards stood at the King's Gate on the east side of the temple."
    },
    {
      "verse": "19",
      "text": "Shallum was the son of Kore and grandson of Ebiasaph, who belonged to Korah's clan. Shallum and his relatives from Korah's clan were guards at the entrance of the Lord's Holy Place. Their ancestors had also been guards at the entrance of the Lord's special tent."
    },
    {
      "verse": "20",
      "text": "Eleazar's son Phinehas had been the leader of the guards at one time. The Lord was with Phinehas to help him."
    },
    {
      "verse": "21",
      "text": "Meshelemiah's son Zechariah was also a guard at the entrance of the tent where the Lord met with his people."
    },
    {
      "verse": "22",
      "text": "guards for the gates of the temple. Their names were written in the lists of their ancestors, for each village where they lived. King David and the prophet Samuel had chosen their ancestors to do this important work as guards."
    },
    {
      "verse": "23",
      "text": "Those men and their descendants had to stand as guards at the gates of the Lord's Holy Place, which had been a special tent."
    },
    {
      "verse": "24",
      "text": "The guards stood on the four sides of the Lord's house: the east, west, north and south sides."
    },
    {
      "verse": "25",
      "text": "Their relatives lived in their villages. They came to Jerusalem to help with the work as guards. Each time that they came, they worked there for seven days."
    },
    {
      "verse": "26",
      "text": "There were four faithful Levite guards who led the work. They kept safe the rooms in God's house where they stored valuable things and money."
    },
    {
      "verse": "27",
      "text": "They stayed at their places around God's house during each night. It was their work to keep it safe. Each morning they would use their key to open the gates."
    },
    {
      "verse": "28",
      "text": "Some of the guards kept safe the valuable things that the priests used when they served the Lord. The guards counted those things when the priests brought them in. They counted them again when the priests took them out."
    },
    {
      "verse": "29",
      "text": "Some other guards kept safe the tools and the valuable things that were in the Holy Place. Some guards took care of the flour, wine, olive oil, incense and spices."
    },
    {
      "verse": "30",
      "text": "But it was the work of some of the priests to mix the spices."
    },
    {
      "verse": "31",
      "text": "Mattithiah was a Levite who belonged to Korah's clan. His work was to prepare the bread that they used as offerings."
    },
    {
      "verse": "32",
      "text": "Other Levites who belonged to Kohath's clan prepared the bread for the special table. The priests put this bread on the special table in the Holy Place each Sabbath day."
    },
    {
      "verse": "33",
      "text": "Some of the Levites were musicians in the temple. The leaders of those clans lived in rooms at the temple. They needed to do their work as musicians during the night, as well as during the day. So they did not have other jobs to do in the temple."
    },
    {
      "verse": "34",
      "text": "Those men were the leaders of the Levite clans. Their names are written in the lists of their clans' ancestors. They lived in Jerusalem."
    },
    {
      "verse": "35",
      "text": "Gibeon's father, Jeiel, lived in Gibeon town. His wife's name was Maakah."
    },
    {
      "verse": "36",
      "text": "His firstborn son was Abdon. His other sons were Zur, Kish, Baal, Ner, Nadab,"
    },
    {
      "verse": "37",
      "text": "Gedor, Ahio, Zechariah and Mikloth."
    },
    {
      "verse": "38",
      "text": "Mikloth became the father of Shimeam. They lived near their relatives in Jerusalem."
    },
    {
      "verse": "39",
      "text": "Ner became the father of Kish. Kish became the father of Saul. Saul became the father of Jonathan, Malki-Shua, Abinadab and Esh-Baal."
    },
    {
      "verse": "40",
      "text": "Jonathan's son was Merib-Baal. Merib-Baal became the father of Micah."
    },
    {
      "verse": "41",
      "text": "Micah's sons were: Pithon, Melech, Tahrea and Ahaz."
    },
    {
      "verse": "42",
      "text": "Ahaz became the father of Jadah. Jadah became the father of Alemeth, Azmaveth and Zimri. Zimri became the father of Moza. Jadah became the father of Alemeth, Azmaveth and Zimri. Zimri became the father of Moza."
    },
    {
      "verse": "43",
      "text": "Moza became the father of Binea. Binea's son was Rephaiah. Rephaiah's son was Eleasah. Eleasah's son was Azel."
    },
    {
      "verse": "44",
      "text": "Azel had six sons: Azrikam, Bokeru, Ishmael, Sheariah, Obadiah and Hanan. That is the list of Azel's sons."
    },
    {
      "verse": "3",
      "text": "Some people from the tribes of Judah, Benjamin, Ephraim and Manasseh lived in Jerusalem. Those people included: Uthai, son of Ammihud and grandson of Omri. Omri was Imri's son. Imri was Bani's son. Bani was a descendant of Judah's son, Perez."
    },
    {
      "verse": "4",
      "text": "Those people included: Uthai, son of Ammihud and grandson of Omri. Omri was Imri's son. Imri was Bani's son. Bani was a descendant of Judah's son, Perez."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "The Philistines fought against the Israelites. The Israelites ran away, and the Philistines killed many of them on Gilboa mountain."
    },
    {
      "verse": "2",
      "text": "The Philistines chased after Saul and his sons to catch them. They killed Saul's sons Jonathan, Abinadab and Malki-Shua."
    },
    {
      "verse": "3",
      "text": "The Philistines were fighting the battle all around Saul. Some of their soldiers saw Saul and they shot their arrows at him. The arrows hurt Saul very much."
    },
    {
      "verse": "4",
      "text": "Saul said to the young man who carried his armour, ‘Kill me now with your sword. I do not want these foreign men to come and be cruel to me. ’ But the young man would not agree to kill Saul because he was too afraid. So Saul took his own sword and he threw himself onto it so that he died."
    },
    {
      "verse": "5",
      "text": "The young man saw that Saul was dead. So he threw himself onto his own sword and he died too."
    },
    {
      "verse": "6",
      "text": "So Saul died there, with his three sons. His whole family died together."
    },
    {
      "verse": "7",
      "text": "All the Israelites who lived in Jezreel valley saw that their army had run away from the Philistines. They also saw that Saul and his sons were dead. So they left their towns and they ran away. Then the Philistines came to live in those towns."
    },
    {
      "verse": "8",
      "text": "On the day after the battle, the Philistines came to take all the valuable things from the dead soldiers. They found the dead bodies of Saul and his sons on Gilboa mountain."
    },
    {
      "verse": "9",
      "text": "They removed everything from Saul's dead body. They took away his head and his weapons. Then they sent men through all the country of the Philistines with the news of Saul's death. These men told the news to all their people and to their idols as well."
    },
    {
      "verse": "10",
      "text": "They put Saul's weapons in the temple of their gods. They hung his head in the temple of their god, Dagon."
    },
    {
      "verse": "11",
      "text": "All the Israelites who lived in Jabesh Gilead heard about what the Philistines had done to Saul's body."
    },
    {
      "verse": "12",
      "text": "So all their brave soldiers went to fetch the dead bodies of Saul and his sons. They took them to Jabesh Gilead. They buried the bones under the large tree there. The people in Jabesh Gilead did not eat any food for seven days because they were so sad."
    },
    {
      "verse": "13",
      "text": "Saul died because he turned away from the Lord. He did not obey the Lord's commands. He even tried to get advice from the spirits of dead people."
    },
    {
      "verse": "14",
      "text": "He did not ask the Lord to tell him what he should do. So the Lord punished him with death. The Lord gave the kingdom of Israel to Jesse's son, David, instead."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "Then all the Israelites came to David at Hebron. They said to him, ‘We all belong to the same family as you do."
    },
    {
      "verse": "2",
      "text": "In the past, even when Saul was our king, you led the Israelites in war. The Lord your God said to you, “You will take care of my people, as a shepherd takes care of his sheep. You will rule over my people, Israel. ” ’"
    },
    {
      "verse": "3",
      "text": "So King David made an agreement with the leaders of Israel when they came to him at Hebron. They made promises in the Lord's name. Then they anointed David to be king over Israel. The Lord had told Samuel that this would happen."
    },
    {
      "verse": "4",
      "text": "David and the whole Israelite army marched to attack Jerusalem. At that time, the city was called Jebus. The people who lived there were called Jebusites."
    },
    {
      "verse": "5",
      "text": "The Jebusites said to David, ‘You will never get into our city. ’ But David did get in and he took Zion, the city's strong place. It is now called the City of David."
    },
    {
      "verse": "6",
      "text": "David had said to his soldiers, ‘The man who attacks the Jebusites first will become the captain of my army. ’ Zeruiah's son Joab attacked first. So he became the captain of the army."
    },
    {
      "verse": "7",
      "text": "David went to live in the strong place of the city. So people called it ‘The City of David’."
    },
    {
      "verse": "8",
      "text": "David built more houses all around it, from the edge of the hill to the city's walls. Joab built up again the other buildings in the city."
    },
    {
      "verse": "9",
      "text": "David became more and more powerful because the Lord Almighty was with him."
    },
    {
      "verse": "10",
      "text": "These were the leaders of David's brave soldiers. They helped to make David's kingdom strong, so that he ruled over all the people in Israel. That is what the Lord had promised. Jashobeam belonged to Hakmoni's clan. He was the leader of David's officers. He used his spear to fight against 300 men in one battle and he killed all of them."
    },
    {
      "verse": "11",
      "text": "This is the list of David's brave soldiers: Jashobeam belonged to Hakmoni's clan. He was the leader of David's officers. He used his spear to fight against 300 men in one battle and he killed all of them."
    },
    {
      "verse": "12",
      "text": "Eleazar was also a leader among the ‘Three Brave Soldiers’. He was Dodo's son, who belonged to Ahoah's clan."
    },
    {
      "verse": "13",
      "text": "Eleazar was with David at Pas-Dammim. The Philistine soldiers were ready to attack the Israelites. There was a field there with a lot of barley. The Israelites ran away from the Philistines."
    },
    {
      "verse": "14",
      "text": "But David and Eleazar stood in the middle of the field to stop the Philistines taking it for themselves. They killed the Philistines. The Lord saved them. He caused them to win a great battle."
    },
    {
      "verse": "15",
      "text": "leaders among David's soldiers. Three of them went to be with David at Adullam's cave where there was a big rock. A group of Philistine soldiers had made their camp in Rephaim valley. That was one of the great things that those three brave soldiers did."
    },
    {
      "verse": "16",
      "text": "David was in his strong safe place. A group of Philistine soldiers had made their home in Bethlehem."
    },
    {
      "verse": "17",
      "text": "David was very thirsty. He said, ‘I want someone to bring water from the well near Bethlehem's gate for me to drink. ’"
    },
    {
      "verse": "18",
      "text": "So the three soldiers fought through the Philistine camp and they reached Bethlehem's gate. They took some water from the well there and they carried it back to David. But he refused to drink it. He poured it on the ground as an offering to the Lord."
    },
    {
      "verse": "19",
      "text": "He said, ‘God knows that it is not right for me to drink this water. It would seem like the blood of the brave men who fetched it for me. The Philistines might have killed them on the way. ’ So David refused to drink it. That was one of the great things that those three brave soldiers did."
    },
    {
      "verse": "20",
      "text": "Joab's brother Abishai was the leader of David's 30 great soldiers. One time, he used his spear to fight 300 men and he killed them all. So he became as famous as the ‘Three Brave Soldiers’."
    },
    {
      "verse": "21",
      "text": "He was not one of the ‘Three Brave Soldiers’ but he received more honour than the other 30 great soldiers. So he became their leader."
    },
    {
      "verse": "22",
      "text": "Jehoiada's son, Benaiah, was also one of David's brave soldiers. He came from Kabzeel and he did many great things. He killed two of Moab's best soldiers. He also went down into a deep hole to kill a lion when snow was on the ground."
    },
    {
      "verse": "23",
      "text": "Benaiah also killed a very big Egyptian man who was 2. 3 metres tall. The Egyptian held a spear that was thick and heavy, like a big tree. Benaiah attacked him with a heavy stick. He took the spear from the Egyptian's hand and he used it to kill him."
    },
    {
      "verse": "24",
      "text": "Those were some things that Jehoiada's son Benaiah did. He became as famous as the ‘Three Brave Soldiers’."
    },
    {
      "verse": "25",
      "text": "great soldiers, but he did not belong to the ‘Three Brave Soldiers’. David made him the leader of his own special soldiers who were his guards."
    },
    {
      "verse": "26",
      "text": "These men were also David's great soldiers: Joab's brother Asahel. Elhanan, Dodo's son, from Bethlehem."
    },
    {
      "verse": "27",
      "text": "Shammoth, from Harod's clan. Helez, from Pelon's clan."
    },
    {
      "verse": "28",
      "text": "Ira, Ikkesh's son, from Tekoa. Abiezer, from Anathoth."
    },
    {
      "verse": "29",
      "text": "Sibbekai, from Hushah's clan. Ilai, from Ahoah's clan."
    },
    {
      "verse": "30",
      "text": "Maharai, from Netophah. Heled, Baanah's son, also from Netophah."
    },
    {
      "verse": "31",
      "text": "Ithai, Ribai's son, from Gibeah, in the land that belonged to Benjamin's tribe. Benaiah, from Pirathon."
    },
    {
      "verse": "32",
      "text": "Hurai, from the valleys near Gaash. Abiel, from Arbah's clan."
    },
    {
      "verse": "33",
      "text": "Azmaveth, from Baharum. Eliahba, from Shaalbon."
    },
    {
      "verse": "34",
      "text": "Hashem's sons, who were Gizonites. Shagee's son Jonathan, from Harar."
    },
    {
      "verse": "35",
      "text": "Sachar's son Ahiam, also from Harar. Ur's son Eliphal."
    },
    {
      "verse": "36",
      "text": "Hepher, from Mekerath. Ahijah, from Pelon's clan."
    },
    {
      "verse": "37",
      "text": "Hezro, from Carmel. Ezbai's son Naarai."
    },
    {
      "verse": "38",
      "text": "Nathan's brother Joel. Hagri's son Mibhar."
    },
    {
      "verse": "39",
      "text": "Zelek, from Ammon. Naharai, from Beeroth. He carried Joab's weapons. (Joab was the son of Zeruiah. )"
    },
    {
      "verse": "40",
      "text": "Ira and Gareb, from Jattir."
    },
    {
      "verse": "41",
      "text": "Uriah, the Hittite. Ahlai's son Zabad."
    },
    {
      "verse": "42",
      "text": "Shiza's son Adina, from Reuben's tribe. He was the leader of Reuben's soldiers. He had 30 brave soldiers with him."
    },
    {
      "verse": "43",
      "text": "Maakah's son Hanan. Joshaphat, from Mithna."
    },
    {
      "verse": "44",
      "text": "Uzzia, from Ashterath. Shama and Jeiel, sons of Hotham, from Aroer."
    },
    {
      "verse": "45",
      "text": "Shimri's son Jediael. Jediael's brother Joha, from Tiz."
    },
    {
      "verse": "46",
      "text": "Eliel, from Mahavah. Elnaam's sons, Jeribai and Joshaviah. Ithmah, from Moab."
    },
    {
      "verse": "47",
      "text": "Eliel and Obed. Jaasiel, from Zobah."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "David went to Ziklag town because King Saul, the son of Kish, had chased him away. Many brave men went to David there. They were some of the brave soldiers who helped David to fight in war."
    },
    {
      "verse": "2",
      "text": "They could shoot with bows and arrows. They could use slings to throw stones with either their right hand or their left hand. They were relatives of Saul, from Benjamin's tribe. Their names were:"
    },
    {
      "verse": "3",
      "text": "Ahiezer, their leader, and his brother Joash. They were sons of Shemaah, who was from Gibeah town. Jeziel and Pelet, the sons of Azmaveth. Beracah. Jehu, from Anathoth town."
    },
    {
      "verse": "4",
      "text": "Ishmaiah, from Gibeon town. He was the leader of the 30 great soldiers. Jeremiah, Jahaziel, Johanan and Jozabad, who was from Gederah."
    },
    {
      "verse": "5",
      "text": "Eluzai, Jerimoth, Bealiah, Shemariah and Shephatiah, who was from Hariph."
    },
    {
      "verse": "6",
      "text": "Elkanah, Isshiah, Azarel, Joezer and Jashobeam. They belonged to Korah's clan."
    },
    {
      "verse": "7",
      "text": "Joelah and Zebadiah, the sons of Jeroham from Gedor town."
    },
    {
      "verse": "8",
      "text": "Many soldiers from Gad's tribe joined David's army at his strong place in the desert. These men were brave soldiers who knew how to fight well. They could use shields and spears. They could fight like lions. They could run as fast as deer on the mountains."
    },
    {
      "verse": "9",
      "text": "Ezer was their leader. After him there were: Obadiah (2), Eliab (3),"
    },
    {
      "verse": "10",
      "text": "Mishmannah (4), Jeremiah (5),"
    },
    {
      "verse": "11",
      "text": "Attai (6), Eliel (7),"
    },
    {
      "verse": "12",
      "text": "Johanan (8), Elzabad (9),"
    },
    {
      "verse": "13",
      "text": "Jeremiah (10), and Makbannai (11)."
    },
    {
      "verse": "14",
      "text": "These descendants of Gad were leaders in the army. The least important officer among them led 100 soldiers. The greatest officer led 1, 000 soldiers."
    },
    {
      "verse": "15",
      "text": "Those men went across to the west side of the Jordan River during the first month of the year. At that time the water in the river was very deep and wide. They chased away the people who lived in the valleys on both sides of the river."
    },
    {
      "verse": "16",
      "text": "Some other men from the tribes of Benjamin and Judah also came to David in his strong place."
    },
    {
      "verse": "17",
      "text": "David went out to meet them. He said to them, ‘I hope that you have come here as my friends. If you have come to help me, I will make an agreement with you. But I hope that you have not come here to help my enemies and to tell them where I am hiding. I have not done anything wrong. So I pray that the God of our ancestors will see what you do. He will punish you as you deserve! ’"
    },
    {
      "verse": "18",
      "text": "Then God's Spirit came to Amasai with power. He was the leader of the 30 great soldiers. He said, ‘We will serve you, David, Jesse's son. We have come to help you! May God bless you! May God bless those who help you! Yes, your God will help you. ’So David accepted them as his friends. He made them officers in his army. ‘We will serve you, David, Jesse's son. We have come to help you! May God bless you! May God bless those who help you! Yes, your God will help you. ’ So David accepted them as his friends. He made them officers in his army."
    },
    {
      "verse": "19",
      "text": "Some men from Manasseh's tribe also joined David's army. That was at the time when David joined with the Philistines to fight against Saul. But David and his men were not able to help the Philistines like that. That was because the leaders of the Philistines decided to send David and his men away. They said, ‘David may turn against us and go to help his master Saul, instead. If he does that, we will all be dead! ’"
    },
    {
      "verse": "20",
      "text": "So David returned to Ziklag. These men from Manasseh's tribe joined David's army at that time: Adnah, Jozabad, Jediael, Michael, Jozabad, Elihu and Zillethai. Each of them had been the leader of 1, 000 soldiers in Saul's army."
    },
    {
      "verse": "21",
      "text": "All those men were brave soldiers and they became officers in David's army. They helped David to fight against the enemy's soldiers when they attacked."
    },
    {
      "verse": "22",
      "text": "Every day more men came to help David. So his army became very large and powerful, like God's own army."
    },
    {
      "verse": "23",
      "text": "This is a list of the soldiers who joined David's army at Hebron. They came with their officers and they were ready to fight. They wanted to help David become king of Israel instead of Saul. The Lord had promised that this would happen."
    },
    {
      "verse": "24",
      "text": "From Judah's tribe, there were 6, 800 men who carried shields and spears. They knew how to fight well."
    },
    {
      "verse": "25",
      "text": "From Simeon's tribe, there were 7, 100 strong men who knew how to fight well."
    },
    {
      "verse": "26",
      "text": "From Levi's tribe, there were 4, 600 men."
    },
    {
      "verse": "27",
      "text": "Jehoiada was the leader of the men who were Aaron's descendants. He brought 3, 700 men with him."
    },
    {
      "verse": "28",
      "text": "Zadok was also in that group. He was a brave young soldier. There were also 22 officers who belonged to his clan."
    },
    {
      "verse": "29",
      "text": "From Benjamin's tribe that Saul belonged to, there were 3, 000 men. Most of those men had served Saul faithfully until that time."
    },
    {
      "verse": "30",
      "text": "From Ephraim's tribe, there were 20, 800 men who were brave soldiers. The people in their clans respected them very much."
    },
    {
      "verse": "31",
      "text": "From the half tribe of Manasseh on the west side of the Jordan River, there were 18, 000 men. Their clans had chosen those men to go and help David become their king."
    },
    {
      "verse": "32",
      "text": "From Issachar's tribe, there were 200 officers and their relatives who obeyed their commands. Those officers understood that this was an important time for Israel. They knew what Israel should do."
    },
    {
      "verse": "33",
      "text": "From Zebulun's tribe, there were 50, 000 brave men who were ready to fight. They knew how to use many different kinds of weapons. They were completely faithful to David."
    },
    {
      "verse": "34",
      "text": "From Naphtali's tribe, there were 1, 000 officers and 37, 000 men who carried shields and spears."
    },
    {
      "verse": "35",
      "text": "From Dan's tribe, there were 28, 600 men who were ready for war."
    },
    {
      "verse": "36",
      "text": "From Asher's tribe there were 40, 000 soldiers who were ready for war."
    },
    {
      "verse": "37",
      "text": "From the east side of the Jordan River, there were 120, 000 soldiers who knew how to use many different kinds of weapons. Those men belonged to the tribes of Reuben, Gad and the other half tribe of Manasseh."
    },
    {
      "verse": "38",
      "text": "All those men were soldiers who were ready to fight in war. They came to David in Hebron because they wanted to make him king to rule all Israel. All the other Israelites also agreed that David should become king."
    },
    {
      "verse": "39",
      "text": "The men stayed there with David for three days. Their relatives had prepared a lot of food for them. So they enjoyed a big feast together."
    },
    {
      "verse": "40",
      "text": "People also came from places as far away as Issachar, Zebulun and Naphtali. They brought food on donkeys, camels, mules and oxen. So there was plenty of flour to make bread, and lots of figs, raisins, wine, olive oil, cows and sheep. All the Israelites had a very happy party!"
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "David spoke with the officers of his army. Some of them were the leaders of 1, 000 men. Other officers were the leaders of 100 men."
    },
    {
      "verse": "2",
      "text": "Then David said to all the Israelites who were present, ‘I think that we should send a message to our relatives in all the regions of Israel. That should include the priests and the Levites in the towns where they live. We should ask all those people to meet with us here. We will do it if you agree that it is a good idea, and if the Lord our God wants us to do it."
    },
    {
      "verse": "3",
      "text": "We should bring back the Covenant Box of our God. While Saul was king, we did not use it to ask God about things. ’"
    },
    {
      "verse": "4",
      "text": "All the people there agreed that this was a good idea. They realized that it was the right thing to do."
    },
    {
      "verse": "5",
      "text": "So David brought together all the Israelites. They came from everywhere in Israel, from the Shihor River in Egypt, and as far as Lebo-Hamath. They came to bring God's Covenant Box back from Kiriath-Jearim."
    },
    {
      "verse": "6",
      "text": "David and all the Israelites went to Baalah, a town in Judah. (Baalah is also called Kiriath-Jearim. ) They went to bring the Covenant Box of God from there to Jerusalem. The Israelites called it by the name of the Lord. He sits as King between the two cherubs that are on the top of the Covenant Box."
    },
    {
      "verse": "7",
      "text": "The people put God's Covenant Box on a new cart. They took it out of Abinadab's house. Uzzah and Ahio were leading the cart."
    },
    {
      "verse": "8",
      "text": "David and all the Israelites were singing and dancing with all their strength to praise God. They made music with harps, lyres, tambourines, cymbals and trumpets."
    },
    {
      "verse": "9",
      "text": "They reached the place of Kidon's threshing floor. There the oxen that were pulling the cart almost fell. So Uzzah reached out to hold the Covenant Box to stop it falling."
    },
    {
      "verse": "10",
      "text": "The Lord was very angry with Uzzah because he had touched the Covenant Box. He knocked Uzzah down to the ground. Uzzah died there, beside God's Covenant Box."
    },
    {
      "verse": "11",
      "text": "David was angry because the Lord had punished Uzzah. So he called that place ‘Perez Uzzah’. That is still its name today."
    },
    {
      "verse": "12",
      "text": "So David now became afraid of God. He said, ‘God's Covenant Box is too holy to take with me. ’"
    },
    {
      "verse": "13",
      "text": "So he did not take the Covenant Box to the City of David to be with him there. Instead, he took it to the house of Obed-Edom, who came from Gath."
    },
    {
      "verse": "14",
      "text": "God's Covenant Box stayed in the home of Obed-Edom's family for three months. During that time, the Lord blessed Obed-Edom's family and everything that he had."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "Then Hiram, king of Tyre, sent some of his men to David. They brought wood from Lebanon's cedar trees. Men who could work with stone and with wood also came. They built a palace for David."
    },
    {
      "verse": "2",
      "text": "David realized that the Lord had made him strong as king over Israel. He knew that God had made his kingdom great, to help his people, the Israelites."
    },
    {
      "verse": "3",
      "text": "When David lived in Jerusalem, he married more wives. He became the father of more sons and daughters."
    },
    {
      "verse": "4",
      "text": "These are the names of David's children who were born in Jerusalem: Shammua, Shobab, Nathan, Solomon,"
    },
    {
      "verse": "5",
      "text": "Ibhar, Elishua, Elpelet,"
    },
    {
      "verse": "6",
      "text": "Nogah, Nepheg, Japhia,"
    },
    {
      "verse": "7",
      "text": "Elishama, Beeliada and Eliphelet."
    },
    {
      "verse": "8",
      "text": "The Philistines heard the news that David had now become king over all Israel. So their whole army went to look for him to catch him. When David heard about this, he went out to attack them. The Lord answered him, ‘Yes, go and attack the Philistines. I will help you to win against them. ’"
    },
    {
      "verse": "9",
      "text": "The Philistine soldiers arrived at Rephaim valley. They attacked the people there."
    },
    {
      "verse": "10",
      "text": "David asked God, ‘Should I go and attack the Philistines? Will you put them under my power? ’The Lord answered him, ‘Yes, go and attack the Philistines. I will help you to win against them. ’"
    },
    {
      "verse": "11",
      "text": "So David and his men went to Baal Perazim. There they won the fight against the Philistines in that place. David said, ‘God has helped me to sweep away my enemy like a flood of water. ’ So they called that place Baal Perazim."
    },
    {
      "verse": "12",
      "text": "The Philistines did not take their idols with them when they ran away. David told his men to destroy the idols in a fire."
    },
    {
      "verse": "13",
      "text": "Once again, the Philistines attacked the people who lived in the valley."
    },
    {
      "verse": "14",
      "text": "So David again asked God what he should do. This time God told him, ‘Do not march straight towards them. Instead, go round behind them. Then attack them from the other side, where the poplar trees are."
    },
    {
      "verse": "15",
      "text": "When you hear a noise in the tops of the trees like marching men, go out to attack them. Then you will know that God has gone in front of you. He will knock down the Philistine army for you. ’"
    },
    {
      "verse": "16",
      "text": "So David did as God had commanded him to do. His men chased the Philistine army all the way from Gibeon to Gezer."
    },
    {
      "verse": "17",
      "text": "So David became famous in every country. The Lord caused the people of every nation to be afraid of David."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "David built houses for himself in the City of David. He put up a tent as a place where he would put God's Covenant Box."
    },
    {
      "verse": "2",
      "text": "Then David said, ‘Only the Levites may carry God's Covenant Box. The Lord chose them to do that. He chose them to serve him for ever. ’"
    },
    {
      "verse": "3",
      "text": "David brought all the Israelites together in Jerusalem. He said that they should bring the Lord's Covenant Box to the place that he had prepared for it."
    },
    {
      "verse": "4",
      "text": "Then David brought together the descendants of Aaron and the other Levites. They were:"
    },
    {
      "verse": "5",
      "text": "From Kohath's clan, 120 people with their leader, Uriel."
    },
    {
      "verse": "6",
      "text": "From Merari's clan, 220 people with their leader, Asaiah."
    },
    {
      "verse": "7",
      "text": "From Gershon's clan, 130 people with their leader, Joel."
    },
    {
      "verse": "8",
      "text": "From Elizaphan's clan, 200 people with their leader, Shemaiah."
    },
    {
      "verse": "9",
      "text": "From Hebron's clan, 80 people with their leader, Eliel."
    },
    {
      "verse": "10",
      "text": "From Uzziel's clan, 112 people with their leader, Amminadab."
    },
    {
      "verse": "11",
      "text": "Then David told the priests Zadok and Abiathar to come to him. He also told these Levites to come: Uriel, Asaiah, Joel, Shemaiah, Eliel and Amminadab."
    },
    {
      "verse": "12",
      "text": "David said to them, ‘You are the leaders of the Levites' clans. You and your relatives must make yourselves holy. Then you will be able to carry the Covenant Box of the Lord, Israel's God. You must bring it to the place that I have prepared for it."
    },
    {
      "verse": "13",
      "text": "The first time that we tried to bring it here, you did not carry it. Because of that, the Lord our God punished us. He did that because we did not ask him about the proper way to carry it. ’"
    },
    {
      "verse": "14",
      "text": "So the priests and the other Levites made themselves holy. Then they could carry the Covenant Box of the Lord, Israel's God."
    },
    {
      "verse": "15",
      "text": "The Levites carried God's Covenant Box with its poles on their shoulders. That is how God had commanded Moses that they should carry it."
    },
    {
      "verse": "16",
      "text": "David told the leaders of the Levites to choose some of their relatives to be musicians. Some would sing songs. Some would make music with lyres, harps and cymbals. They would sing loud and happy songs."
    },
    {
      "verse": "17",
      "text": "The Levites chose Joel's son Heman. They also chose Berekiah's son Asaph, who was a relative of Heman. And they chose Kushaiah's son Ethan, who belonged to Merari's clan."
    },
    {
      "verse": "18",
      "text": "They also chose another group of Levites to help them. They were: Zechariah, Ben, Jaaziel, Shemiramoth, Jehiel, Unni, Eliab, Benaiah, Maaseiah, Mattithiah, Eliphelehu, Mikneiah, as well as two temple guards, Obed-Edom and Jeiel."
    },
    {
      "verse": "19",
      "text": "They chose these musicians to make music with bronze cymbals: Heman, Asaph and Ethan."
    },
    {
      "verse": "20",
      "text": "They chose these musicians to make music in a special way with harps: Zechariah, Aziel, Shemiramoth, Jehiel, Unni, Eliab, Maaseiah and Benaiah."
    },
    {
      "verse": "21",
      "text": "They chose these musicians to make music in a special way with lyres: Mattithiah, Eliphelehu, Mikneiah, Obed-Edom, Jeiel and Azaziah."
    },
    {
      "verse": "22",
      "text": "Kenaniah was the leader of the musicians. They chose him to do that because he had good skill in music."
    },
    {
      "verse": "23",
      "text": "Berekiah and Elkanah were guards to keep the Covenant Box safe."
    },
    {
      "verse": "24",
      "text": "The priests Shebaniah, Joshaphat, Nethanel, Amasai, Zechariah, Benaiah and Eliezer walked in front of God's Covenant Box. They made a loud noise with trumpets as they went. Obed-Edom and Jehiah were also guards for the Covenant Box."
    },
    {
      "verse": "25",
      "text": "So David, the leaders of Israel and the army officers went to fetch the Lord's Covenant Box from Obed-Edom's house. They were very happy as they took it from there to Jerusalem."
    },
    {
      "verse": "26",
      "text": "The Lord helped the Levites who were carrying his Covenant Box. So they offered seven bulls and seven male sheep as sacrifices to the Lord."
    },
    {
      "verse": "27",
      "text": "David was wearing a robe that was made of good linen. All the Levites who were carrying the Covenant Box also wore linen clothes. So did the musicians and Kenaniah, their leader. David also wore a linen ephod over his robe."
    },
    {
      "verse": "28",
      "text": "In that way, all the Israelites brought the Lord's Covenant Box to Jerusalem. They were shouting. They were making loud music with trumpets, cymbals, lyres and harps."
    },
    {
      "verse": "29",
      "text": "While they where bringing the Lord's Covenant Box into the City of David, Saul's daughter Michal looked out through a window. She saw that King David was dancing because he was so happy. Michal felt ashamed of him."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "David had put up a special tent for God's Covenant Box, so they took it there. They put it in its place inside the tent. Then they offered burnt offerings and friendship offerings to God."
    },
    {
      "verse": "2",
      "text": "After David had offered those sacrifices, he prayed that the Lord would bless the people."
    },
    {
      "verse": "3",
      "text": "Then he gave a gift to every Israelite man and woman. Each person received a loaf of bread, some dates and some raisins."
    },
    {
      "verse": "4",
      "text": "Then David chose some Levites to serve the Lord at the Covenant Box. They would lead prayers and songs to thank the Lord, Israel's God, and to praise him."
    },
    {
      "verse": "5",
      "text": "Asaph was the leader of that group and Zechariah was the second leader. Then there were Jeiel, Shemiramoth, Jehiel, Mattithiah, Eliab, Benaiah, Obed-Edom and Jeiel. Those men made music with harps and lyres. Asaph used the cymbals."
    },
    {
      "verse": "6",
      "text": "The priests Benaiah and Jahaziel would make a noise with trumpets in front of God's Covenant Box many times each day."
    },
    {
      "verse": "7",
      "text": "On that day, David first told Asaph and the other Levites to sing this song to thank the Lord:"
    },
    {
      "verse": "8",
      "text": "Thank the Lord! Make his name famous! Tell people in all the nations what he has done. Make his name famous! Tell people in all the nations what he has done."
    },
    {
      "verse": "9",
      "text": "Sing songs and make musicto praise him! Tell people about the miracles that he has done. to praise him! Tell people about the miracles that he has done."
    },
    {
      "verse": "10",
      "text": "Boast about his holy name. Everybody who wants to worship the Lord should be very happy! Everybody who wants to worship the Lord should be very happy!"
    },
    {
      "verse": "11",
      "text": "Ask the Lord to help you! Ask him to give you strength. Always try to be near himand worship him. Ask him to give you strength. Always try to be near him and worship him."
    },
    {
      "verse": "12",
      "text": "Remember the great things that he has done. Remember his miracles, and the commands that he has spoken. Remember his miracles, and the commands that he has spoken."
    },
    {
      "verse": "13",
      "text": "You are the descendants of God's servant, Israel. You are Jacob's descendants, and God has chosen you to be his people. You are Jacob's descendants, and God has chosen you to be his people."
    },
    {
      "verse": "14",
      "text": "He is the Lord our God. He rules the whole earth with justice. He rules the whole earth with justice."
    },
    {
      "verse": "15",
      "text": "Always remember the covenant that he has made with us. He made that promise to continue for ever. He made that promise to continue for ever."
    },
    {
      "verse": "16",
      "text": "That is the promise that he made to Abraham, and that he also made to Isaac. and that he also made to Isaac."
    },
    {
      "verse": "17",
      "text": "He repeated it to Jacob as a law. It was a covenant with Israel's peoplethat would continue for ever. It was a covenant with Israel's people that would continue for ever."
    },
    {
      "verse": "18",
      "text": "He promised, ‘I will give the land of Canaan to you. It will belong to you and to your descendants. ’ It will belong to you and to your descendants. ’"
    },
    {
      "verse": "19",
      "text": "At one time, God's people were only a few. They lived in Canaan as strangers. They lived in Canaan as strangers."
    },
    {
      "verse": "20",
      "text": "They travelled among different nationsand different kingdoms. and different kingdoms."
    },
    {
      "verse": "21",
      "text": "But the Lord did not let anyone hurt them. He punished kings, to keep his people safe. He punished kings, to keep his people safe."
    },
    {
      "verse": "22",
      "text": "He said, ‘Do not even touch the people that I have chosen to be mine. Do not hurt my prophets. ’ Do not hurt my prophets. ’"
    },
    {
      "verse": "23",
      "text": "Sing to the Lord, all the world. Every day, tell people the message that he has rescued us. Every day, tell people the message that he has rescued us."
    },
    {
      "verse": "24",
      "text": "Tell the other nations that he is very great. Tell all of them about the great things that he has done. Tell all of them about the great things that he has done."
    },
    {
      "verse": "25",
      "text": "Yes, the Lord is great! Everyone should praise him, as he deserves. People should respect him with fear, more than all other gods. Everyone should praise him, as he deserves. People should respect him with fear, more than all other gods."
    },
    {
      "verse": "26",
      "text": "All the other nations' gods are useless idols. But the Lord made the heavens. But the Lord made the heavens."
    },
    {
      "verse": "27",
      "text": "We see that he is a very great king. Strength and joy are in his home. Strength and joy are in his home."
    },
    {
      "verse": "28",
      "text": "You people of other nations, recognize that the Lord is great and powerful. recognize that the Lord is great and powerful."
    },
    {
      "verse": "29",
      "text": "Agree that the Lord's name is great. Bring a gift to offer to him in his temple. Worship the Lord, who is beautiful and holy. Bring a gift to offer to him in his temple. Worship the Lord, who is beautiful and holy."
    },
    {
      "verse": "30",
      "text": "Everyone on earth must shake with fear in front of him. He has fixed the world in its place, so that nothing can shake it. He has fixed the world in its place, so that nothing can shake it."
    },
    {
      "verse": "31",
      "text": "The earth and the sky should be happy! The people of all nations should say, ‘The Lord rules as king! ’ The people of all nations should say, ‘The Lord rules as king! ’"
    },
    {
      "verse": "32",
      "text": "The sea and everything in it should shout aloud! The fields and all their crops should shout with joy! The fields and all their crops should shout with joy!"
    },
    {
      "verse": "33",
      "text": "Then all the trees in the forests will also sing, because they are so happy. They will be happy because the Lord is comingto judge the earth. because they are so happy. They will be happy because the Lord is coming to judge the earth."
    },
    {
      "verse": "34",
      "text": "Thank the Lord, because he is good. His faithful love will always be with us. His faithful love will always be with us."
    },
    {
      "verse": "35",
      "text": "Say to him, ‘God, you are the one who rescues us! Please save us now! Bring us safely home from among the other nations. Then we will thank you! We will shout aloud to praise your holy name. ’ Please save us now! Bring us safely home from among the other nations. Then we will thank you! We will shout aloud to praise your holy name. ’"
    },
    {
      "verse": "36",
      "text": "Praise the Lord, Israel's God, as he deserves! Praise him now and for ever! Then all the people said, ‘Amen! We agree! Praise the Lord! ’ as he deserves! Praise him now and for ever! Then all the people said, ‘Amen! We agree! Praise the Lord! ’"
    },
    {
      "verse": "37",
      "text": "King David had chosen Asaph and his relatives to serve the Lord at the Covenant Box. They must do that each day, as the rules said that they should do."
    },
    {
      "verse": "38",
      "text": "They included Obed-Edom and 68 men from his clan. Jeduthun's son, Obed-Edom and Hosah were guards at the entrance of the tent."
    },
    {
      "verse": "39",
      "text": "Zadok and the other priests served the Lord at the tabernacle in Gibeon. That was still the place where the Israelites worshipped God."
    },
    {
      "verse": "40",
      "text": "Their job was to offer burnt offerings as sacrifices to the Lord on the big altar there. They did that every morning and every evening, as the law of the Lord commanded. The Israelites had to obey that law."
    },
    {
      "verse": "41",
      "text": "Heman and Jeduthun were with them at the tabernacle in Gibeon. There were also other Levites that David had chosen to help them. Their special job was to give thanks to the Lord with songs, because his faithful love continues for ever."
    },
    {
      "verse": "42",
      "text": "Heman and Jeduthun also had authority for the trumpets, the cymbals and the other musical instruments. The musicians used them to praise God with their music. Jeduthun's sons stood as guards at the entrance of the tabernacle."
    },
    {
      "verse": "43",
      "text": "After that, all the people left to return to their homes. David also went home to ask God to bless his family."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "King David was living in his palace. One day, he said to Nathan the prophet, ‘Now I am living in a beautiful palace that is made of cedar wood. But the Lord's Covenant Box is still in a tent. ’"
    },
    {
      "verse": "2",
      "text": "Nathan replied to David, ‘Do what you think is right. God will help you. ’"
    },
    {
      "verse": "3",
      "text": "But that night God said to Nathan,"
    },
    {
      "verse": "4",
      "text": "‘Go and tell my servant David, “The Lord says this: You are not the right man to build a house for me to live in."
    },
    {
      "verse": "5",
      "text": "From the time that I brought the Israelites safely out of Egypt until now, I have never lived in a house. I have lived in a tent as my home as I travelled from place to place."
    },
    {
      "verse": "6",
      "text": "I have moved about to many different places with the Israelites. I chose leaders to take care of my people, like shepherds take care of their sheep. But I never said to any of them, ‘You should have built a beautiful house of cedar wood for me. ’ ”"
    },
    {
      "verse": "7",
      "text": "So tell my servant David that the Lord Almighty says this: “I took you from the fields where you were taking care of sheep. I took you from there to become the ruler of my people Israel."
    },
    {
      "verse": "8",
      "text": "I have been with you everywhere that you have gone. I destroyed all your enemies that were attacking you. Now I will make you famous. Your name will be as great as the names of the earth's greatest men."
    },
    {
      "verse": "9",
      "text": "I have chosen a place where my people Israel will live. I have put them in that place, were they can be safe. They will not be afraid of trouble from any enemy. Wicked people will not hurt them any more. That happened in the past,"
    },
    {
      "verse": "10",
      "text": "from the time that I chose leaders to rule my people Israel. But now I will cause all your enemies to be weak. I say to you, David: the Lord will give you descendants who will rule as kings after you. That will be the royal house that I build for you."
    },
    {
      "verse": "11",
      "text": "When you die, people will bury you in the grave of your ancestors. Then I will choose your descendant, one of your own sons, to become king. I will make his kingdom strong."
    },
    {
      "verse": "12",
      "text": "He is the man who will build a house for me. And I will cause his descendants to rule as kings for ever."
    },
    {
      "verse": "13",
      "text": "I will be his father and he will be my son. I will never remove my faithful love from him, as I took it away from the king who ruled before you."
    },
    {
      "verse": "14",
      "text": "I will cause him to rule my people and my kingdom for ever. Someone from his family will always be king. ” ’"
    },
    {
      "verse": "15",
      "text": "Nathan told David the whole message that the Lord had shown to him."
    },
    {
      "verse": "16",
      "text": "Then King David went into the Lord's tent. He sat down and he prayed to the Lord. He said, ‘Lord, my God, I am not a special person and my family is not special. You have helped me very much and I do not deserve it."
    },
    {
      "verse": "17",
      "text": "And you have done more than that, my God. You have made a promise about the descendants of my family in the future. You, Lord God, have spoken to me as if I am a very important man."
    },
    {
      "verse": "18",
      "text": "I am your servant and you know me completely. You have given great honour to me. There is nothing more that I can say."
    },
    {
      "verse": "19",
      "text": "Lord, you have chosen to do all these great things for me, your servant. You are telling me what you have promised to do."
    },
    {
      "verse": "20",
      "text": "There is nobody like you, Lord. You alone are God. What we have heard about you is true!"
    },
    {
      "verse": "21",
      "text": "There is no other nation on earth like your people, Israel. We are the nation that you rescued so that we would belong to you. You did that to show that your name is great. You did great miracles as you rescued your people from Egypt. You chased out the nations who wanted to stop them."
    },
    {
      "verse": "22",
      "text": "You chose Israel to be your own people for all time. You, Lord became our God."
    },
    {
      "verse": "23",
      "text": "Lord, please do the things that you have promised to do for me, your servant, and for my family. Continue to do for ever what you have promised to do,"
    },
    {
      "verse": "24",
      "text": "so that people see your promises are true. Then people will always give honour to your great name. They will say, “The Lord Almighty is Israel's God. ” And David's descendants will continue to serve you as kings."
    },
    {
      "verse": "25",
      "text": "My God, you have made this promise to me, your servant. You have said that I will always have descendants who will rule. That is the house that you will build for me. Because you have said that, I was not afraid to pray to you."
    },
    {
      "verse": "26",
      "text": "Lord, you are the true God! You have promised these good things to me, your servant."
    },
    {
      "verse": "27",
      "text": "Now please bless my family and my descendants. Then we will serve you faithfully for ever. Yes, Lord, you have blessed my descendants, and I know that you will continue to bless them for ever. ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "After some time, David attacked the Philistines and he won against them. He took Gath city and the villages around it from the Philistines."
    },
    {
      "verse": "2",
      "text": "David also won a battle against the Moabites. They were now under David's authority and they paid taxes to him."
    },
    {
      "verse": "3",
      "text": "David also won a battle against Hadadezer, king of Zobah. He won land as far as Hamath. That happened when Hadadezer took his army to the Euphrates river to show that he had authority there."
    },
    {
      "verse": "4",
      "text": "David took from Hadadezer 1, 000 chariots and 7, 000 men who drove them. He also caught 20, 000 of Hadadezer's other soldiers. David kept 100 horses that pulled chariots. But he cut the legs of the other horses so that they could not run."
    },
    {
      "verse": "5",
      "text": "The Syrians from Damascus sent an army to help King Hadadezer of Zobah. But David killed 22, 000 soldiers of the Syrian army. The Lord helped David to win all the battles that he fought."
    },
    {
      "verse": "6",
      "text": "David put some of his soldiers in Damascus to keep his authority over the Syrian people. They had to pay taxes to King David. The Lord helped David to win all the battles that he fought."
    },
    {
      "verse": "7",
      "text": "David took the gold shields that Hadadezer's officers had carried. He brought the shields to Jerusalem."
    },
    {
      "verse": "8",
      "text": "David also took a lot of bronze things from Tebah and Cun. Those towns had belonged to Hadadezer towns. Later, Solomon used that bronze to make the big bath in the temple that was called ‘the Sea’. He also used the bronze to make pillars and other things for the temple."
    },
    {
      "verse": "9",
      "text": "Tou, the king of Hamath, heard news that David had won the battle against the whole army of King Hadadezer of Zobah."
    },
    {
      "verse": "10",
      "text": "There had been a war between King Hadadezer and King Tou. So Tou sent his son, Hadoram, to say ‘hello’ to King David. He wanted to praise David because he had won the battle against King Hadadezer. He also sent many gifts of gold, silver and bronze to David."
    },
    {
      "verse": "11",
      "text": "King David took those gifts and he offered them to the Lord. He also offered to the Lord all the silver and gold things that he had taken from other nations. Those nations were Edom, Moab, the Ammonites, the Philistines and the Amalekites."
    },
    {
      "verse": "12",
      "text": "Zeruiah's son Abishai killed 18, 000 men from Edom in the Valley of Salt. The Lord helped David to win all the battles that he fought."
    },
    {
      "verse": "13",
      "text": "He put groups of his soldiers in Edom, so that David had authority over all the Edomites. The Lord helped David to win all the battles that he fought."
    },
    {
      "verse": "14",
      "text": "David ruled over all Israel. He did everything that was right and fair for all his people."
    },
    {
      "verse": "15",
      "text": "Zeruiah's son Joab was the leader of Israel's army. Ahilud's son Jehoshaphat wrote down the important things that happened."
    },
    {
      "verse": "16",
      "text": "Ahitub's son Zadok and Abiathar's son Ahimelech were priests. Shavsha was David's secretary."
    },
    {
      "verse": "17",
      "text": "Jehoiada's son Benaiah was the leader of David's personal guards. David's sons were his most important officers."
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "After some time, Nahash, the king of the Ammonites, died. His son became the new king."
    },
    {
      "verse": "2",
      "text": "David thought, ‘Nahash was kind to me, so I will be kind to his son Hanun. ’ So David sent some of his officers to give a message to Hanun. David wanted to tell Hanun that he was sorry that his father Nahash had died. David's officers took his kind message to the land of the Ammonites."
    },
    {
      "verse": "3",
      "text": "But the leaders of the Ammonites said to Hanun, ‘David has sent his officers to you with a kind message. But do not think that he really wants to give honour to your father. No, he has sent his men to look at our land. They want to see how they can attack our country and take it for themselves. ’"
    },
    {
      "verse": "4",
      "text": "So Hanun took hold of David's officers. He cut off their hair. He also cut off the lower half of their clothes up to their hips. Then he sent them away."
    },
    {
      "verse": "5",
      "text": "Some people came to tell David what had happened. His officers were very ashamed. So David sent men to them with a message. King David said, ‘Stay in Jericho city until your beards have grown again. Then you can return here. ’"
    },
    {
      "verse": "6",
      "text": "The Ammonites realized that they had caused David to be very angry. So King Hanun and his people made an agreement with the people of Aram-Naharaim, Aram-Maacah and Zobah. The Ammonites sent them about 34, 000 kilograms of silver to get their help with chariots and their drivers."
    },
    {
      "verse": "7",
      "text": "They had 32, 000 chariots to use in the battle. They also received help from the king of Maakah and his army. All these men made their camp near Medeba. At the same time King Hanun had brought together the Ammonite soldiers from their towns. They were all ready to fight."
    },
    {
      "verse": "8",
      "text": "David heard news about this. So he sent Joab with all the soldiers in his army to fight against them."
    },
    {
      "verse": "9",
      "text": "The Ammonite soldiers marched out from their city. They stood at the entrance of their city and they were ready to fight. The other kings and their soldiers stayed in the fields near the city."
    },
    {
      "verse": "10",
      "text": "Joab saw that there were two groups of the enemy's soldiers. They were ready to attack his army from different sides. So he chose some of Israel's best soldiers. Joab himself led them to attack the Syrian soldiers in the fields."
    },
    {
      "verse": "11",
      "text": "He told his brother Abishai to lead the rest of Israel's army to fight against the Ammonites."
    },
    {
      "verse": "12",
      "text": "Joab said to Abishai, ‘If the Syrian soldiers are too strong for me, you must come to rescue me. But if the Ammonites are too strong for you, I will come to rescue you."
    },
    {
      "verse": "13",
      "text": "Be strong! We must be brave as we fight on behalf of our people and the cities of our God. The Lord will do what he decides is good. ’"
    },
    {
      "verse": "14",
      "text": "Then Joab and his group of soldiers went to fight against the Syrians. As they marched towards the Syrian soldiers, they ran away. So Joab returned to Jerusalem."
    },
    {
      "verse": "15",
      "text": "The Ammonites saw that the Syrians were running away from Joab. So they also ran away from his brother Abishai's men. They went back into their city. So Joab returned to Jerusalem."
    },
    {
      "verse": "16",
      "text": "The Syrian soldiers realized that Israel had won the battle against them. So they sent men with a message to fetch more soldiers to help them. More Syrian soldiers came from the other side of the Euphrates river. Shophach, the captain of Hadadezer's army, led them."
    },
    {
      "verse": "17",
      "text": "David heard about what was happening. So he took all Israel's soldiers across the Jordan River. David led his army to attack the Syrian soldiers. The Syrians also prepared to fight. When the battle started,"
    },
    {
      "verse": "18",
      "text": "the Syrians ran away from the Israelites. David and his army killed 7, 000 Syrians who drove chariots. They killed 40, 000 other Syrian soldiers. They also killed Shophach, the captain of the Syrian army."
    },
    {
      "verse": "19",
      "text": "The kings who were under King Hadadezer's authority saw that Israel had won the battle. So they made an agreement with David that they would not fight against Israel any more. They agreed to be under David's authority. After that, the Syrians would no longer agree to help the Ammonites."
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "In the spring, Joab led the Israelite army out to fight. That was the time of year when kings go out to fight battles. Joab and his army attacked the land of the Ammonites and he won against them. He put his soldiers around Rabbah city so that they could attack it. But David had stayed in Jerusalem. Joab attacked Rabbah and he destroyed its buildings."
    },
    {
      "verse": "2",
      "text": "When David came, he took the crown off the Ammonite king's head. The crown was made of gold. It weighed 34 kilograms. There was a valuable jewel fixed on it. David's men then put the crown on David's head. David also took a lot of valuable things from the city. Then David and all his army returned to Jerusalem."
    },
    {
      "verse": "3",
      "text": "He brought the people out from the city to do hard work for him. He made them cut wood with saws, and use iron tools and axes. He did the same thing to the people of all the other Ammonite cities. Then David and all his army returned to Jerusalem."
    },
    {
      "verse": "4",
      "text": "Some time after that, the Israelites fought a battle against the Philistines at Gezer. In that battle, Sibbecai from Hushah killed Sippai. Sippai was a descendant of Rapha. So Israel won against the Philistines."
    },
    {
      "verse": "5",
      "text": "In another battle against the Philistines, Jair's son Elhanan killed Lahmi. Lahmi was the brother of Goliath who came from Gath. He had a spear that was very thick and heavy, like a big tree."
    },
    {
      "verse": "6",
      "text": "There was another battle at Gath. Another descendant of Rapha fought against the Israelites there. He was a very large man. He had six fingers on each hand and six toes on each foot."
    },
    {
      "verse": "7",
      "text": "He shouted to insult the Israelite soldiers. So Jonathan, the son of David's brother Shimea, killed him."
    },
    {
      "verse": "8",
      "text": "Those Philistines were descendants of Rapha and they lived in Gath. David and his soldiers killed all of them."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "Then Satan caused David to bring trouble to Israel. He caused David to count all the men in Israel."
    },
    {
      "verse": "2",
      "text": "So David said to Joab and to the officers in his army, ‘Go and count the men everywhere in Israel, from Beersheba to Dan. Then come and give me a report. I want to know how many men there are. ’"
    },
    {
      "verse": "3",
      "text": "But Joab replied, ‘I pray that the Lord will make your army grow 100 times bigger! All your men are your faithful servants, my lord the king. But why do you want to do this? You will cause all Israel to become guilty. ’"
    },
    {
      "verse": "4",
      "text": "But Joab had to obey the king's command. So Joab left. He went through all Israel and then he returned to Jerusalem."
    },
    {
      "verse": "5",
      "text": "Joab reported to David about the number of soldiers who could fight. There were 1, 100, 000 men in all Israel who could fight with swords. There were 470, 000 men in Judah who could fight with swords."
    },
    {
      "verse": "6",
      "text": "But the king's command had seemed disgusting to Joab. So he did not count the men from the tribes of Levi and Benjamin."
    },
    {
      "verse": "7",
      "text": "God was also angry because David had done this thing. So he decided to punish Israel."
    },
    {
      "verse": "8",
      "text": "Then David said to God, ‘What I have done was a bad sin. Please forgive me. I have done a foolish thing. ’"
    },
    {
      "verse": "9",
      "text": "Gad was David's prophet. The Lord said to him,"
    },
    {
      "verse": "10",
      "text": "‘Go and give my message to David: “There are three ways that I could punish you. You must choose one of them, and that is what I will do to punish you. ” ’"
    },
    {
      "verse": "11",
      "text": "So Gad went to David and he said to him, ‘This is what the Lord says: “You must choose one of these punishments."
    },
    {
      "verse": "12",
      "text": "You may choose to have three years when there will be a famine. Or you may choose to have three months when you have to run away from your enemies' swords so that they do not kill you. Or you may choose to have three days when a very bad disease comes to your people. The angel of the Lord would kill many people in every part of Israel. ” Now decide which punishment you will choose. I will take your answer to God, who sent me with this message. ’"
    },
    {
      "verse": "13",
      "text": "David said to Gad, ‘I am very upset. I do not want men to punish me. The Lord is kind and he forgives people. So it is better if he punishes me. ’"
    },
    {
      "verse": "14",
      "text": "So the Lord caused a very bad disease to kill people in Israel. 70, 000 Israelite men died."
    },
    {
      "verse": "15",
      "text": "God sent his angel to destroy Jerusalem. But as the angel started to kill people, the Lord saw what was happening. He decided to stop the punishment that he was causing. He said to the angel who was killing the people, ‘That is enough. Stop what you are doing! ’ When the Lord said that, his angel was standing near the threshing floor of Araunah the Jebusite."
    },
    {
      "verse": "16",
      "text": "David looked up and he saw the Lord's angel. The angel was standing between the earth and the sky. He had his sword in his hand and it was pointing towards Jerusalem. David and the leaders fell down with their faces towards the ground. They were wearing clothes that were made of rough sackcloth."
    },
    {
      "verse": "17",
      "text": "David said to God, ‘I am the person who has done an evil thing. I told Joab to count the number of men in my army. These people have followed me like sheep that follow a shepherd. They have not done anything wrong. Lord my God, you should only punish me and my family. But please take this disease away from your people. ’"
    },
    {
      "verse": "18",
      "text": "Then the angel of the Lord said to Gad, ‘Tell David to go up to the threshing floor of Araunah the Jebusite. Build an altar there to worship the Lord. ’"
    },
    {
      "verse": "19",
      "text": "So David obeyed the Lord's message that Gad had spoken to him."
    },
    {
      "verse": "20",
      "text": "Araunah and his four sons were threshing wheat. Araunah turned around and he saw the Lord's angel. His sons hid themselves."
    },
    {
      "verse": "21",
      "text": "Then David came to meet Araunah. When Araunah saw David, he came out from the threshing floor. He bent down low in front of David, with his face towards the ground."
    },
    {
      "verse": "22",
      "text": "David said to Araunah, ‘Let me buy this threshing floor from you. I want to build an altar here to worship the Lord. Then he will stop this bad disease from killing the people. I will pay you the whole price for the land. ’"
    },
    {
      "verse": "23",
      "text": "Araunah replied, ‘My lord the king, please take it for yourself. You may do what you would like to do. Look, I will give you the bulls for the burnt offerings. You can use the wood from these tools for the fire. Take my wheat to make an offering to the Lord. I will give all these things to you. ’"
    },
    {
      "verse": "24",
      "text": "But King David said to Araunah, ‘No, I must pay you the whole price. I cannot offer something that belongs to you as a sacrifice to the Lord. I cannot offer to him a burnt offering that has cost me nothing. ’"
    },
    {
      "verse": "25",
      "text": "gold coins to buy the place."
    },
    {
      "verse": "26",
      "text": "Then he built an altar there to worship the Lord. He offered burnt offerings and friendship offerings on it. He prayed to the Lord and the Lord answered him. The Lord sent fire from the sky to burn up the sacrifice on the altar."
    },
    {
      "verse": "27",
      "text": "Then the Lord told the angel to put his sword away into its pocket."
    },
    {
      "verse": "28",
      "text": "David saw that the Lord had answered his prayer at the threshing floor of Araunah the Jebusite. So he offered sacrifices to God there."
    },
    {
      "verse": "29",
      "text": "At that time the Lord's tabernacle was at Gibeon, where the Israelites worshipped God. The tabernacle was the special tent that Moses had made in the wilderness. The altar for burnt offerings was also at Gibeon."
    },
    {
      "verse": "30",
      "text": "But David was not able to go there to meet with the Lord, because he was afraid of the sword of the Lord's angel."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "Then David said, ‘This is the place where the temple of the Lord God will be. The altar for Israel's burnt offerings will also be here. ’"
    },
    {
      "verse": "2",
      "text": "So David told his officers to bring together all the foreign men who lived in Israel. He chose some of them to cut the stones to build God's house. They would cut the stones to have the right shape."
    },
    {
      "verse": "3",
      "text": "He supplied a lot of iron to make things for the temple. That was for nails and bars to fix the doors at the entrances. He also supplied more bronze than they could weigh."
    },
    {
      "verse": "4",
      "text": "The people from Tyre and Sidon had brought a lot of cedar wood to David. So he provided for the temple more pieces of cedar wood than anyone could count."
    },
    {
      "verse": "5",
      "text": "David said, ‘The Lord's temple must be great and beautiful. It must be famous, so that the people of every nation see how great it is. My son Solomon is young and he has no special skills. So I must prepare everything for him to build the temple. ’So before David died, he prepared all these things. So before David died, he prepared all these things."
    },
    {
      "verse": "6",
      "text": "David sent someone to fetch his son, Solomon. He told him that he must build a temple for the Lord, Israel's God."
    },
    {
      "verse": "7",
      "text": "He said to Solomon, ‘My son, I really wanted to build a house for the Lord my God, to give honour to him."
    },
    {
      "verse": "8",
      "text": "But the Lord said to me, “You have killed many people in the battles that you have fought. So you yourself will not build a house to give me honour. I have seen all the blood of the people that you have killed."
    },
    {
      "verse": "9",
      "text": "But you will have a son who will be a man who lives in peace. I will cause all his enemies to leave him in peace. Yes, his name will be Solomon. While he is king, I will cause Israel to enjoy peace. I will keep them safe from their enemies."
    },
    {
      "verse": "10",
      "text": "He will build a temple to give honour to my name. He will become my son and I will become his father. I will give him descendants to rule Israel as kings for ever. ”"
    },
    {
      "verse": "11",
      "text": "So, my son, I pray that the Lord will be with you. He will do what he has promised. He will help you to build a temple for the Lord your God."
    },
    {
      "verse": "12",
      "text": "I also pray that the Lord will make you wise so that you understand things properly. I pray that you will obey the Law of the Lord your God as you rule over Israel."
    },
    {
      "verse": "13",
      "text": "You will be successful, if you carefully obey the Lord's commands and rules. Those are the laws that the Lord gave to Moses for Israel. Be strong! Be brave! Do not be afraid, but continue to be strong!"
    },
    {
      "verse": "14",
      "text": "Look! I have been careful to prepare the things that you will need to build the Lord's temple. I have got 4, 000 tons of gold and 40, 000 tons of silver. I have more bronze and iron than anyone can weigh. I have plenty of wood and stone. You will need to get even more than this."
    },
    {
      "verse": "15",
      "text": "You have many workers with special skills. Some know how to cut stone. Others know how to build with stones or with wood. There are men who have skills to make many different kinds of things."
    },
    {
      "verse": "16",
      "text": "They can use gold, silver, bronze and iron to make things. You have more workers than you can count! So now you must start the work! I pray that the Lord will be with you to help you. ’"
    },
    {
      "verse": "17",
      "text": "Then David sent messages to all the leaders in Israel. He commanded them to help his son Solomon."
    },
    {
      "verse": "18",
      "text": "He said to them, ‘You know that the Lord your God is with you. He has kept you safe from all your enemies. He has put the people who live in this region under my authority. So now the Lord and his people rule over all those nations."
    },
    {
      "verse": "19",
      "text": "So you must serve the Lord your God with all that you are. Start the work! Begin to build the Lord God's holy place. Then you can put the Lord's Covenant Box there, as well as the other holy things. You will put them in the temple that you have built to give honour to the Lord's name. ’"
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "David was old and his life had nearly finished. He chose his son Solomon to rule over Israel as king."
    },
    {
      "verse": "2",
      "text": "He brought together all Israel's leaders, as well as the priests and the Levites."
    },
    {
      "verse": "3",
      "text": "years old or older. There were 38, 000 men."
    },
    {
      "verse": "4",
      "text": "David said, ‘24, 000 of these Levite men must have authority for the work of the Lord's temple. 6, 000 of them will be officers and judges."
    },
    {
      "verse": "5",
      "text": "4, 000 of them will be guards at the gates of the temple. 4, 000 of them will use music to praise the Lord. They will use the musical instruments that I have provided for them. ’"
    },
    {
      "verse": "6",
      "text": "David made the Levites into three separate groups. Each group had descendants from one of Levi's sons: Gershon, Kohath and Merari."
    },
    {
      "verse": "7",
      "text": "From Gershon's clan there were Ladan and Shimei."
    },
    {
      "verse": "8",
      "text": "Ladan's three sons were: Jehiel, the firstborn, then Zetham and Joel."
    },
    {
      "verse": "9",
      "text": "Shimei's three sons were: Shelomoth, Haziel and Haran. Those men were the leaders of Ladan's family. Those men were the leaders of Ladan's family."
    },
    {
      "verse": "10",
      "text": "Shimei had four more sons: Jahath, Ziza, Jeush and Beriah."
    },
    {
      "verse": "11",
      "text": "Jahath was the oldest son and Ziza was the second. But Jeush and Beriah did not have many sons. So the officers counted them together as one family."
    },
    {
      "verse": "12",
      "text": "Kohath's four sons were: Amram, Izhar, Hebron and Uzziel."
    },
    {
      "verse": "13",
      "text": "Amram's sons were Aaron and Moses. The Lord chose Aaron and his descendants for special work for all time. Their work was to offer special holy things to the Lord. They would offer sacrifices to the Lord. They would serve him in the temple. And they would use his name to bless the people. The Lord chose Aaron and his descendants for special work for all time. Their work was to offer special holy things to the Lord. They would offer sacrifices to the Lord. They would serve him in the temple. And they would use his name to bless the people."
    },
    {
      "verse": "14",
      "text": "The tribe of Levi included the sons of Moses, God's servant."
    },
    {
      "verse": "15",
      "text": "Moses' sons were Gershom and Eliezer."
    },
    {
      "verse": "16",
      "text": "Gershom's oldest son was Shebuel."
    },
    {
      "verse": "17",
      "text": "Eliezer's son was Rehabiah. He was the leader of the family. Eliezer had no other sons, but Rehabiah had many descendants."
    },
    {
      "verse": "18",
      "text": "From the family of Kohath's second son Izhar, Shelomith was the leader."
    },
    {
      "verse": "19",
      "text": "Hebron had four sons: Jeriah was the leader, Amariah was second, Jahaziel was third and Jekameam was fourth."
    },
    {
      "verse": "20",
      "text": "Uzziel had two sons: Micah was the leader and Isshiah was second."
    },
    {
      "verse": "21",
      "text": "Merari's sons were Mahli and Mushi. Mahli's sons were Eleazar and Kish. Mahli's sons were Eleazar and Kish."
    },
    {
      "verse": "22",
      "text": "Eleazar died without any sons. He had only daughters. Kish's sons, who were their cousins, married them."
    },
    {
      "verse": "23",
      "text": "Mushi's three sons were: Mahli, Eder and Jeremoth."
    },
    {
      "verse": "24",
      "text": "Those were the leaders of the Levites' clans, family by family. The Israelites carefully recorded the names of all the men who were 20 years old or older. From that age, they each had their work to do in the Lord's temple."
    },
    {
      "verse": "25",
      "text": "David had said, ‘Now the Lord, Israel's God, has given rest to his people. He has his home in Jerusalem for all time."
    },
    {
      "verse": "26",
      "text": "So the Levites no longer need to carry the tabernacle to different places. They do not need to carry all the things that are used to serve God. ’"
    },
    {
      "verse": "27",
      "text": "years old or older and could work in the temple. Those were David's last words before he died."
    },
    {
      "verse": "28",
      "text": "The Levites' work was to help Aaron's descendants as they served the Lord in his temple. They took care of the temple's yards and its small rooms. They made the Lord's special things clean and holy. They did the work that was necessary to serve God in his temple."
    },
    {
      "verse": "29",
      "text": "They took care of the special bread for the table in the holy place. They kept the flour for the grain offerings, for the flat bread that they made without yeast and for the special cakes. They weighed and they measured all the things for the bread and the cakes."
    },
    {
      "verse": "30",
      "text": "Every morning they stood in their places to thank the Lord and to praise him. They did the same thing every evening."
    },
    {
      "verse": "31",
      "text": "They also did that when the priests offered burnt offerings to the Lord. That happened on Sabbath days, at New Moon festivals and on other special days. The correct number of Levites must be there to serve the Lord at all times, as the rules commanded."
    },
    {
      "verse": "32",
      "text": "In that way, the Levites had authority to take care of the special tent and the holy place. They helped their relatives, Aaron's descendants, as they served the Lord in his temple."
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "Aaron's descendants, the priests, were in the following groups. Aaron's four sons were: Nadab, Abihu, Eleazar and Ithamar."
    },
    {
      "verse": "2",
      "text": "But Nadab and Abihu died before their father died. They had no sons. So Eleazar and Ithamar served God as priests."
    },
    {
      "verse": "3",
      "text": "Zadok and Ahimelech helped David to put Aaron's descendants into groups. Zadok was a descendant of Eleazar. Ahimelech was a descendant of Ithamar. They told each group what their work would be to serve God."
    },
    {
      "verse": "4",
      "text": "There were more leaders among Eleazar's descendants than among Ithamar's descendants. So from Eleazar's descendants, there were 16 groups with their leaders. From Ithamar's descendants there were eight groups with their leaders."
    },
    {
      "verse": "5",
      "text": "They used lots to decide the work of each group. The families of both Eleazar and Ithamar included officers for the temple as well as priests."
    },
    {
      "verse": "6",
      "text": "Shemaiah was the secretary who wrote down the names in each group. He was the son of Nethanel, a Levite. Shemaiah wrote down the names while the king and his officers watched. Zadok the priest, Abiathar's son Ahimelech and the leaders of the priests' clans and of the other Levite clans were also watching. When they threw the lots, they would choose a family from Eleazar's descendants, then a family from Ithamar's descendants, and so on."
    },
    {
      "verse": "7",
      "text": "This is the list of the group leaders as they chose them, one by one:1. Jehoiarib2. Jedaiah3. Harim4. Seorim5. Malkijah6. Mijamin7. Hakkoz8. Abijah9. Jeshua10. Shecaniah11. Eliashib12. Jakim13. Huppah14. Jeshebeab15. Bilgah16. Immer17. Hezir18. Happizzez19. Pethahiah20. Jehezkel21. Jakin22. Gamul23. Delaiah24. Maaziah."
    },
    {
      "verse": "8",
      "text": "Abijah"
    },
    {
      "verse": "9",
      "text": "Jeshua"
    },
    {
      "verse": "10",
      "text": "Shecaniah"
    },
    {
      "verse": "11",
      "text": "Eliashib"
    },
    {
      "verse": "12",
      "text": "Jakim"
    },
    {
      "verse": "13",
      "text": "Huppah"
    },
    {
      "verse": "14",
      "text": "Jeshebeab"
    },
    {
      "verse": "15",
      "text": "Bilgah"
    },
    {
      "verse": "16",
      "text": "Immer"
    },
    {
      "verse": "17",
      "text": "Hezir"
    },
    {
      "verse": "18",
      "text": "Happizzez"
    },
    {
      "verse": "19",
      "text": "Each of these leaders, with their group, had their jobs to do in the temple. They had to obey the rules that their ancestor Aaron had given. The Lord, Israel's God, had told him what they must do."
    },
    {
      "verse": "20",
      "text": "The leaders of the other Levite families included: Shubael, from Amram's descendants. Jehdeiah, from Shubael's descendants. That is the list of the Levites, with the leaders of each family."
    },
    {
      "verse": "21",
      "text": "From Rehabiah's descendants: Isshiah, the firstborn son."
    },
    {
      "verse": "22",
      "text": "From Izhar's descendants: Shelomoth. From Shelomoth's descendants: Jahath."
    },
    {
      "verse": "23",
      "text": "Hebron's four sons were: Jeriah, the firstborn son, then Amariah, the second son, Jahaziel, the third son, and Jekameam, the fourth son."
    },
    {
      "verse": "24",
      "text": "Uzziel's son Micah and his son Shamir."
    },
    {
      "verse": "25",
      "text": "Micah's brother Isshiah and his son Zechariah."
    },
    {
      "verse": "26",
      "text": "Merari's sons were: Mahli, Mushi and Jaaziah."
    },
    {
      "verse": "27",
      "text": "Merari's descendants by his son Jaaziah were: Beno, Shoham, Zaccur and Ibri."
    },
    {
      "verse": "28",
      "text": "Mahli's son Eleazar had no sons."
    },
    {
      "verse": "29",
      "text": "Kish's son was Jerahmeel."
    },
    {
      "verse": "30",
      "text": "Mushi's sons were: Mahli, Eder and Jerimoth. That is the list of the Levites, with the leaders of each family."
    },
    {
      "verse": "31",
      "text": "They also used lots to choose their different jobs, as their relatives, Aaron's descendants, had done. King David, Zadok, Ahimelech and the family leaders of the priests and the other Levites watched them. They chose work for the family leaders in the same way that they did for their younger brothers."
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "David and the army officers chose some Levites to serve God as musicians. They belonged to the families of Asaph, Heman and Jeduthun. They chose these men to speak messages from God while they made music with harps, lyres and cymbals. Here is a list of the men that they chose for this work:"
    },
    {
      "verse": "2",
      "text": "From Asaph's sons, there were: Zaccur, Joseph, Nethaniah and Asarelah. Asaph had authority over their work. He would speak a message from God when the king told him to do that."
    },
    {
      "verse": "3",
      "text": "From Jeduthun's sons, there were six musicians: Gedaliah, Zeri, Jeshaiah, Shimei, Hashabiah and Mattithiah. Their father Jeduthun had authority over their work. He spoke messages from God while he made music with a harp. He also sang to thank the Lord and to praise him."
    },
    {
      "verse": "4",
      "text": "From Heman's sons, there were: Bukkiah, Mattaniah, Uzziel, Shebuel, Jerimoth, Hananiah, Hanani, Eliathah, Giddalti, Romamti-Ezer, Joshbekashah, Mallothi, Hothir and Mahazioth."
    },
    {
      "verse": "5",
      "text": "All those men were sons of Heman, the king's prophet. God had promised to give Heman many children who would give him honour. God gave him 14 sons and three daughters."
    },
    {
      "verse": "6",
      "text": "All these musicians were under the authority of their fathers. They used cymbals, harps and lyres to make music to worship the Lord in his temple. The king had authority over Asaph, Jeduthun and Heman."
    },
    {
      "verse": "7",
      "text": "All those men had skills to make good music, as well as their relatives. There were 288 Levites who served the Lord as musicians."
    },
    {
      "verse": "8",
      "text": "They used lots to decide the right work for each musician. They chose work for everyone in the same way: the young men and the older men, the teachers and the students."
    },
    {
      "verse": "9",
      "text": "groups of musicians. There were 12 musicians in each group and each group had its leader. These were the names of the leaders of each group, from the first to the last that they chose:1. Asaph's descendant Joseph, with his sons and his relatives. 2. Gedaliah, with his sons and his relatives. 3. Zaccur, with his sons and his relatives. 4. Izri, with his sons and his relatives. 5. Nethaniah, with his sons and his relatives. 6. Bukkiah, with his sons and his relatives. 7. Jesarelah, with his sons and his relatives. 8. Jeshaiah with his sons and his relatives. 9. Mattaniah with his sons and his relatives. 10. Shimei with his sons and his relatives. 11. Azarel with his sons and his relatives. 12. Hashabiah with his sons and his relatives. 13. Shubael with his sons and his relatives. 14. Mattithiah with his sons and his relatives. 15. Jeremoth with his sons and his relatives. 16. Hananiah with his sons and his relatives. 17. Joshbekashah with his sons and his relatives. 18. Hanani with his sons and his relatives. 19. Mallothi with his sons and his relatives. 20. Eliathah with his sons and his relatives. 21. Hothir with his sons and his relatives. 22. Giddalti with his sons and his relatives. 23. Mahazioth with his sons and his relatives. 24. Romamti-Ezer with his sons and his relatives."
    },
    {
      "verse": "10",
      "text": "Asaph's descendant Joseph, with his sons and his relatives. Gedaliah, with his sons and his relatives."
    },
    {
      "verse": "11",
      "text": "Zaccur, with his sons and his relatives."
    },
    {
      "verse": "12",
      "text": "Izri, with his sons and his relatives."
    },
    {
      "verse": "13",
      "text": "Nethaniah, with his sons and his relatives."
    },
    {
      "verse": "14",
      "text": "Bukkiah, with his sons and his relatives."
    },
    {
      "verse": "15",
      "text": "Jesarelah, with his sons and his relatives."
    },
    {
      "verse": "16",
      "text": "Jeshaiah, with his sons and his relatives."
    },
    {
      "verse": "17",
      "text": "Mattaniah, with his sons and his relatives."
    },
    {
      "verse": "18",
      "text": "Shimei, with his sons and his relatives."
    },
    {
      "verse": "19",
      "text": "Azarel, with his sons and his relatives."
    },
    {
      "verse": "20",
      "text": "Hashabiah, with his sons and his relatives."
    },
    {
      "verse": "21",
      "text": "Shubael, with his sons and his relatives."
    },
    {
      "verse": "22",
      "text": "Mattithiah, with his sons and his relatives."
    },
    {
      "verse": "23",
      "text": "Jeremoth, with his sons and his relatives."
    },
    {
      "verse": "24",
      "text": "Hananiah, with his sons and his relatives."
    },
    {
      "verse": "25",
      "text": "Joshbekashah, with his sons and his relatives."
    },
    {
      "verse": "26",
      "text": "Hanani, with his sons and his relatives."
    },
    {
      "verse": "27",
      "text": "Mallothi, with his sons and his relatives."
    },
    {
      "verse": "28",
      "text": "Eliathah, with his sons and his relatives."
    },
    {
      "verse": "29",
      "text": "Hothir, with his sons and his relatives."
    },
    {
      "verse": "30",
      "text": "Giddalti, with his sons and his relatives."
    },
    {
      "verse": "31",
      "text": "Mahazioth with his sons and his relatives. Romamti-Ezer with his sons and his relatives."
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "These are the groups of guards for the entrances of the temple: From Korah's descendants there was Kore's son Meshelemiah, who was a descendant of Asaph. From Korah's descendants there was Kore's son Meshelemiah, who was a descendant of Asaph."
    },
    {
      "verse": "2",
      "text": "Meshelemiah's seven sons were: Zechariah (his firstborn son), then Jediael (his second son), Zebadiah (his third son), Jathniel (his fourth son),"
    },
    {
      "verse": "3",
      "text": "Elam (his fifth son), Jehohanan (his sixth son) and Eliehoenai (his seventh son)."
    },
    {
      "verse": "4",
      "text": "Obed-Edom's sons were: Shemaiah (his firstborn son), Jehozabad (his second son), Joah (his third son), Sachar (his fourth son), Nethanel (his fifth son),"
    },
    {
      "verse": "5",
      "text": "Ammiel (his sixth son), Issachar (his seventh son) and Peullethai (his eighth son). God blessed Obed-Edom with those eight sons."
    },
    {
      "verse": "8",
      "text": "descendants of Obed-Edom. People respected them, as well as their sons and their relatives. They could all do their work well."
    },
    {
      "verse": "9",
      "text": "sons and relatives. People respected them as men who could work well."
    },
    {
      "verse": "10",
      "text": "From Merari's descendants there was Hosah. He had four sons: Shimri was his firstborn son. His father chose him to be the leader among his sons, but he was not the oldest of them."
    },
    {
      "verse": "11",
      "text": "Hilkiah was Hosah's second son, Tebaliah was his third son and Zechariah was his fourth son. 13 men from among Hosah's sons and relatives worked as guards for the temple."
    },
    {
      "verse": "12",
      "text": "Each group of guards had a leader. Like the other Levites, each group had a job to do as they served the Lord in his temple."
    },
    {
      "verse": "13",
      "text": "They used lots to decide which family group would be the guards for each gate of the temple. They chose the jobs for everyone in the same way, important people and ordinary people."
    },
    {
      "verse": "14",
      "text": "They chose Shelemiah's group to be guards for the East gate. They chose his son Zechariah's group for the North gate. Zechariah was a wise man who gave good advice."
    },
    {
      "verse": "15",
      "text": "They chose Obed-Edom's group to be guards at the South gate. They chose his sons to be guards for the rooms where they kept valuable things."
    },
    {
      "verse": "16",
      "text": "They chose Shuppim's group and Hosah's group to be guards at the West gate, as well as the Shalleketh Gate on the higher road. They chose the times for each group of guards to work each day."
    },
    {
      "verse": "17",
      "text": "Six Levites watched the east side of the temple. Four men watched the north side and four men watched the south side. Two guards worked together at each room where they kept valuable things."
    },
    {
      "verse": "18",
      "text": "There were four guards on the road near the yard at the west side of the temple. And there were two guards in the yard."
    },
    {
      "verse": "19",
      "text": "That was the work of the different groups of guards who were descendants of Korah and Merari."
    },
    {
      "verse": "20",
      "text": "Other Levites kept the valuable things in the temple safe. That included the money and the gifts that people had offered to God."
    },
    {
      "verse": "21",
      "text": "One group of these men were descendants of Ladan, who belonged to Gershon's clan. These were the leaders of those families: Jehieli,"
    },
    {
      "verse": "22",
      "text": "and his sons, Zetham and Joel (his younger brother). They had authority for the rooms where they kept the money and other valuable things in the Lord's temple."
    },
    {
      "verse": "23",
      "text": "The other guards for those rooms were descendants of Amram, Izhar, Hebron and Uzziel."
    },
    {
      "verse": "24",
      "text": "Shebuel was a descendant of Moses' son Gershom. He was the leader with authority to keep the money safe."
    },
    {
      "verse": "25",
      "text": "His relatives were descendants of Gershom's brother Eliezer. They were: Eliezer's son Rehabiah, Rebaiah's son Jeshaiah, Jeshaiah's son Joram, Joram's son Zikri, and Zikri's son Shelomoth."
    },
    {
      "verse": "26",
      "text": "Shelomoth and his relatives had authority for all the holy things that people had offered as gifts to God. King David, the leaders of clans and army officers had given those things to God."
    },
    {
      "verse": "27",
      "text": "When the Israelites won battles, they took valuable things from their enemies. They brought some of those things to the Lord's temple to make it strong."
    },
    {
      "verse": "28",
      "text": "There were also gifts that Samuel the prophet, Kish's son Saul, Ner's son Abner and Zeruiah's son Joab had offered to the Lord. Shelomoth and his relatives had authority to keep safe everything that had been offered to the Lord."
    },
    {
      "verse": "29",
      "text": "There were also descendants of Izhar: Kenaniah and his sons did not work in the temple. Instead they served as judges and officers in different places in Israel."
    },
    {
      "verse": "30",
      "text": "There were descendants of Hebron: Hashabiah and his relatives served as officers on the west side of the Jordan River. There were 1, 700 of those men who could work well. They had authority for the work the people did to serve the Lord and the king."
    },
    {
      "verse": "31",
      "text": "Jeriah was the leader among Hebron's descendants. The records of their ancestors showed that this was true. When David had been king for 40 years, people read those records carefully. They realized that there were descendants of Hebron who were living at Jazer in Gilead region, and people respected them very much."
    },
    {
      "verse": "32",
      "text": "There were 2, 700 men from Jeriah's clan who were good leaders in their families. King David chose them to be officers with authority for the tribes of Reuben, Gad and the half tribe of Manasseh. They had authority for all the work that people did to serve the Lord and the king."
    },
    {
      "verse": "6",
      "text": "Obed-Edom's son Shemaiah had four sons. They were called Othni, Rephael, Obed and Elzabad. They were leaders in their clan, because they were brave men."
    },
    {
      "verse": "7",
      "text": "People respected them very much. People also respected their relatives, Elihu and Semakiah."
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "This is a list of the men from Israel's families who served as soldiers in the army. Some were leaders of their families. Some were officers who led 1, 000 soldiers or officers who led 100 soldiers. Other men were officers who served the king in different ways. Each month of the year, a group of 24, 000 men served the king as soldiers."
    },
    {
      "verse": "2",
      "text": "Zabdiel's son Jashobeam was the leader of the first group of 24, 000 soldiers. They worked in the first month of each year."
    },
    {
      "verse": "3",
      "text": "Jashobeam was a descendant of Perez. He was leader of all the army officers for the first month."
    },
    {
      "verse": "4",
      "text": "Dodai was the leader of the second group of 24, 000 soldiers. They worked in the second month. Dodai belonged to Ahoah's clan. Mikloth was the leader who helped him."
    },
    {
      "verse": "5",
      "text": "Benaiah was the leader of the third group of 24, 000 soldiers. They worked in the third month. Benaiah was the son of Jehoiada, the priest."
    },
    {
      "verse": "6",
      "text": "great soldiers and his whole group. His son was Ammizabad."
    },
    {
      "verse": "7",
      "text": "Asahel was the leader of the fourth group of 24, 000 soldiers. They worked in the fourth month. Asahel was Joab's brother. His son Zebadiah was the leader of the group after him."
    },
    {
      "verse": "8",
      "text": "Shamhuth, from Izrah's clan, was the leader of the fifth group of 24, 000 soldiers. They worked in the fifth month."
    },
    {
      "verse": "9",
      "text": "Ira was the leader of the sixth group of 24, 000 soldiers. They worked in the sixth month. Ira was the son of Ikkesh from Tekoa."
    },
    {
      "verse": "10",
      "text": "Helez was the leader of the seventh group of 24, 000 soldiers. They worked in the seventh month. He belonged to Pelon's clan, in the tribe of Ephraim."
    },
    {
      "verse": "11",
      "text": "Sibbecai was the leader of the eighth group of 24, 000 soldiers. They worked in the eighth month. Sibbecai was a descendant of Zerah, who came from Hushah."
    },
    {
      "verse": "12",
      "text": "Abiezer was the leader of the ninth group of 24, 000 soldiers. They worked in the ninth month. Abiezer came from Anathoth, in the tribe of Benjamin."
    },
    {
      "verse": "13",
      "text": "Maharai was the leader of the tenth group of 24, 000 soldiers. They worked in the tenth month. Maharai was a descendant of Zerah, who came from Netophah."
    },
    {
      "verse": "14",
      "text": "Benaiah was the leader of the 11th group of 24, 000 soldiers. They worked in the 11th month. Benaiah came from Pirathon, in the tribe of Ephraim."
    },
    {
      "verse": "15",
      "text": "Heldai was the leader of the 12th group of 24, 000 soldiers. They worked in the 12th month. He was a descendant of Othniel, who came from Netophah."
    },
    {
      "verse": "16",
      "text": "This is a list of the officers who had authority over Israel's tribes: For Reuben: Zikri's son, Eliezer. For Simeon: Maakah's son, Shephatiah. Those were the officers who led the tribes of Israel."
    },
    {
      "verse": "17",
      "text": "For Levi: Kemuel's son, Hashabiah. Zadok had authority over the descendants of Aaron."
    },
    {
      "verse": "18",
      "text": "For Judah: Elihu, a brother of David. For Issachar: Michael's son, Omri."
    },
    {
      "verse": "19",
      "text": "For Zebulun: Obadiah's son, Ishmaiah. For Naphtali: Azriel's son, Jerimoth."
    },
    {
      "verse": "20",
      "text": "For Ephraim Hoshea's son, Azaziah. For the half tribe of Manasseh in the west: Pedaiah's son, Joel."
    },
    {
      "verse": "21",
      "text": "For the half tribe of Manasseh in Gilead: Zechariah's son, Iddo. For Benjamin: Abner's son, Jaasiel."
    },
    {
      "verse": "22",
      "text": "For Dan: Jeroham's son, Azarel. Those were the officers who led the tribes of Israel."
    },
    {
      "verse": "23",
      "text": "The Lord had promised to make Israel a nation with as many people as there are stars in the sky. So King David did not count the men who were less than 20 years old."
    },
    {
      "verse": "24",
      "text": "Zeruiah's son Joab had begun to count the men. He did not finish counting them because the Lord started to punish Israel. So nobody wrote the number in the history book about King David's life."
    },
    {
      "verse": "25",
      "text": "Adiel's son Azmaveth had authority over the places in the palace where the king stored his valuable things. Uzziah's son Jonathan had authority over the places in the different regions of Israel where the king stored his things. Those places were in towns, in villages and in strong towers. Uzziah's son Jonathan had authority over the places in the different regions of Israel where the king stored his things. Those places were in towns, in villages and in strong towers."
    },
    {
      "verse": "26",
      "text": "Kelub's son Ezri had authority over the men who worked in the king's fields."
    },
    {
      "verse": "27",
      "text": "Shimei from Ramah had authority over the men who worked in the king's vineyards. Zabdi from Shepham had authority over the men who stored wine in the vineyards. Zabdi from Shepham had authority over the men who stored wine in the vineyards."
    },
    {
      "verse": "28",
      "text": "Baal-Hanan from Geder had authority over the trees in the low hills in the west. They were olive trees and fig trees. Joash had authority over the places where they stored the olive oil. Joash had authority over the places where they stored the olive oil."
    },
    {
      "verse": "29",
      "text": "Shitrai from Sharon had authority to take care of the king's cows that were in Sharon. Adlai's son Shaphat had authority to take care of the king's cows that were in the valleys. Adlai's son Shaphat had authority to take care of the king's cows that were in the valleys."
    },
    {
      "verse": "30",
      "text": "Obil, a descendant of Ishmael, had authority for the king's camels. Jehdeiah from Meronoth had authority for the donkeys. Jehdeiah from Meronoth had authority for the donkeys."
    },
    {
      "verse": "31",
      "text": "Jaziz, a descendant of Hagar, had authority to take care of the king's sheep and goats. These were the officers who had authority to take care of King David's things. These were the officers who had authority to take care of King David's things."
    },
    {
      "verse": "32",
      "text": "David's uncle, Jonathan, was a wise man who gave good advice. He wrote down records. Hakmoni's son Jehiel taught the king's sons. Hakmoni's son Jehiel taught the king's sons."
    },
    {
      "verse": "33",
      "text": "Ahithophel was the king's advisor, and Hushai, from Arki, was also the king's friend. Joab was the captain who led the king's army."
    },
    {
      "verse": "34",
      "text": "After Ahithophel died, Benaiah's son Jehoiada became the king's advisor. After him, Abiathar became his advisor. Joab was the captain who led the king's army."
    }
  ],
  "28": [
    {
      "verse": "1",
      "text": "David told all Israel's officers to come and meet with him in Jerusalem. They included: The officers who had authority over Israel's tribes. The leaders of the army groups that served the king. The army officers who led groups of 1, 000 soldiers or 100 soldiers. The officers who had authority for the king's valuable things and animals. The officers who had authority for the animals and things that belonged to the king's sons. The officers in the king's palace. The brave army officers and soldiers."
    },
    {
      "verse": "2",
      "text": "King David stood up and he said, ‘Listen to me, my people. I wanted to build a house where we could put the Lord's Covenant Box. It would be like a place for our God to rest his feet. I prepared the things that I would need to build a temple."
    },
    {
      "verse": "3",
      "text": "But God said to me, “You are a fighter and you have killed many people in war. So you must not build a house to give honour to my name. ”"
    },
    {
      "verse": "4",
      "text": "But it was the Lord, Israel's God, who chose me to become Israel's king. He chose my family to rule Israel for all time. First, he chose the tribe of Judah to be the leader of Israel's people. Then he chose my father's family from among the clans of Judah. Finally, he chose me from among my father's sons. He made me king to rule over all Israel."
    },
    {
      "verse": "5",
      "text": "The Lord has given me many sons. Now he has chosen my son Solomon from among them to rule over his kingdom, Israel."
    },
    {
      "verse": "6",
      "text": "The Lord said to me, “Your son Solomon will build my temple and the yards around it. I have chosen him to become my son. And I will become his father."
    },
    {
      "verse": "7",
      "text": "He must always continue to obey my commands and my laws, as he now does. If he is careful to do that, I will make his kingdom strong for all time. ”"
    },
    {
      "verse": "8",
      "text": "I am telling you this now, while we meet together as the Lord's people. All Israel's people, as well as our God, know what I have said. You must be careful to obey all the commands of the Lord your God. Then this good land will continue to be your home. And after you die it will belong to your descendants for ever."
    },
    {
      "verse": "9",
      "text": "As for you, Solomon, my son, keep near to your father's God. Be happy to serve him faithfully in every way. The Lord knows what you are thinking. He understands all your thoughts. If you turn to him, you will find him. But if you turn away from him, he will leave you alone for ever."
    },
    {
      "verse": "10",
      "text": "You must realize that the Lord has chosen you to build a temple to be his special home. Now you must be strong! Do this work. ’"
    },
    {
      "verse": "11",
      "text": "Then David gave his son Solomon the plans for the temple buildings. That included the entrance room, the rooms to store things, the upstairs rooms and the inside rooms. And it included the Most Holy Place where the Covenant Box would be."
    },
    {
      "verse": "12",
      "text": "David showed Solomon the ideas that God had put in his mind. He gave him the plans for the yards around the Lord's temple and the rooms around the yards. There were also plans of the rooms to store the valuable things and the gifts that people had offered to God."
    },
    {
      "verse": "13",
      "text": "David gave Solomon the rules for the work of the priests and Levites. He gave him a list of the different kinds of work that each group must do in the Lord's temple. He also gave him a list of the special things that were used to serve the Lord in the temple."
    },
    {
      "verse": "14",
      "text": "He told Solomon the weight of gold and the weight of silver that he must use to make some of those special things. David also gave Solomon the plan for the gold images of cherubs for the Lord's Covenant Box. They would have wings that touched each other above the lid of the Covenant Box. They would be like a chariot for the Lord."
    },
    {
      "verse": "15",
      "text": "That included the weight of gold for the lampstands and for their lamps. It also included the weight of silver for the silver lampstands and for their lamps. Each lampstand was different because they would use it for a different purpose."
    },
    {
      "verse": "16",
      "text": "It included the weight of gold to make the special table where the priests would put the special bread. And it included the weight of silver to make the silver tables."
    },
    {
      "verse": "17",
      "text": "It also included the weight of pure gold to make the forks, dishes, cups and small bowls. Each gold bowl had its own weight. There was also the weight of silver for each of the silver bowls."
    },
    {
      "verse": "18",
      "text": "And there was the weight of pure gold for the altar to burn incense. David also gave Solomon the plan for the gold images of cherubs for the Lord's Covenant Box. They would have wings that touched each other above the lid of the Covenant Box. They would be like a chariot for the Lord."
    },
    {
      "verse": "19",
      "text": "David said, ‘I have written down everything about these things, as the Lord told me to do. He helped me to understand how these plans would work. ’"
    },
    {
      "verse": "20",
      "text": "David said to his son Solomon, ‘Be strong and brave to do this work. The Lord God, my God, is with you to help you. He will not leave you alone. So do not be afraid. He will stay with you until you have finished all the work to build his temple."
    },
    {
      "verse": "21",
      "text": "Look! Here are the groups of priests and Levites who are ready to serve the Lord in the temple. The men with special skills are ready to help you with the work. The officers and all the people are ready to do what you tell them to do. ’"
    }
  ],
  "29": [
    {
      "verse": "1",
      "text": "Then King David spoke to all the people who were meeting together. He said, ‘God has clearly chosen my son Solomon to do this great work. But he is still young and he has no special skills. It is a very important work for him to build the temple. It will not be a palace for people, but for the Lord God himself!"
    },
    {
      "verse": "2",
      "text": "I have tried to provide the things that he will need to build the temple for my God. They include gold, silver, bronze, iron and wood to make things. I have also given many valuable stones, including onyx, antimony and other jewels, as well as a lot of marble."
    },
    {
      "verse": "3",
      "text": "I want very much to build a beautiful temple for my God. So I have added my own gold and silver to help to build it. I have added that to the other things that I have provided for God's holy temple."
    },
    {
      "verse": "4",
      "text": "tons of the best gold and 260 tons of pure silver to cover the walls of the buildings."
    },
    {
      "verse": "5",
      "text": "Workers with special skills can also use that gold and silver to make beautiful things. So now, who else will make a gift today to serve the Lord? ’"
    },
    {
      "verse": "6",
      "text": "Then the Israelite leaders and officers agreed to offer gifts to help the Lord's work. They included the leaders of clans and the leaders of Israel's tribes, the army officers who led 1, 000 men and who led 100 men, and the officers with authority for the king's work."
    },
    {
      "verse": "7",
      "text": "They gave these gifts for God's temple:190 tons of gold. 10, 000 gold coins. 380 tons of silver. 675 tons of bronze. 3, 750 tons of iron."
    },
    {
      "verse": "8",
      "text": "People who had valuable stones gave them for the Lord's house. Jehiel from Gershon's clan stored them in a safe place."
    },
    {
      "verse": "9",
      "text": "The people were very happy that their leaders gave these things. They were pleased to give to help the Lord's work. King David was also very happy."
    },
    {
      "verse": "10",
      "text": "David praised the Lord in front of all the people who had met together. He said, ‘We praise you Lord, the God of our ancestor, Israel. You deserve that people praise you for ever! ‘We praise you Lord, the God of our ancestor, Israel. You deserve that people praise you for ever!"
    },
    {
      "verse": "11",
      "text": "Lord, you are great, powerful and beautiful! You rule as king over everything in heaven and on earth. Yes, Lord, everything belongs in your kingdom! You rule as king over everything in heaven and on earth. Yes, Lord, everything belongs in your kingdom!"
    },
    {
      "verse": "12",
      "text": "You are the one who gives people riches and honour. You rule over everything. You have great strength and power, so you are able to make people strong and famous. You rule over everything. You have great strength and power, so you are able to make people strong and famous."
    },
    {
      "verse": "13",
      "text": "So we thank you, our God. We praise your great name! We praise your great name!"
    },
    {
      "verse": "14",
      "text": "But I and my people are like nothing. How are we able to give all these gifts to help your work? Everything that we have comes from you. So we are giving back to you things that already belong to you."
    },
    {
      "verse": "15",
      "text": "We are like strangers and foreign people who live in your world. Our ancestors also lived in that way. We live here only for a short time and then we disappear, like a shadow. We know that we will die one day."
    },
    {
      "verse": "16",
      "text": "Lord, our God, we have given these things to build a temple for you, to give honour to your holy name. But all these valuable things come from you. They already belong to you."
    },
    {
      "verse": "17",
      "text": "My God, I know that you look carefully at our thoughts. You are pleased when we want to do things that are right. And I really do want to offer all these things to you. I know that your people who have met together here are happy. I can see that they are pleased to give these things to you."
    },
    {
      "verse": "18",
      "text": "Lord, you are the God of our ancestors Abraham, Isaac and Israel. Please help us, your people, to continue to obey you. Help us to serve you faithfully."
    },
    {
      "verse": "19",
      "text": "Please help my son Solomon to want to obey you. Help him to obey all your commands, rules and laws. Help him to work well to build your temple. I have prepared the things that he will need to do that. ’"
    },
    {
      "verse": "20",
      "text": "Then David spoke to all the people who were meeting there together. He told them, ‘Now praise the Lord, your God! ’ So all the people praised the Lord, the God of their ancestors. They bent down low to worship the Lord. They gave honour to the Lord and also to the king."
    },
    {
      "verse": "21",
      "text": "On the next day, they offered sacrifices to the Lord. They made burnt offerings of 1, 000 bulls, 1, 000 male sheep and 1, 000 lambs. They made the proper drink offerings with those sacrifices. They also offered many other sacrifices on behalf of all the Israelites."
    },
    {
      "verse": "22",
      "text": "They ate a big feast to give honour to the Lord and they were very happy. Then they anointed David's son Solomon to be the next king, with the Lord's blessing. That was the second time that they had chosen him as their king. They also anointed Zadok to be priest."
    },
    {
      "verse": "23",
      "text": "So Solomon sat on the Lord's throne as king, in his father David's place. Everything went well for him as king. All the people in Israel obeyed him."
    },
    {
      "verse": "24",
      "text": "All King David's officers, his brave soldiers and all of his sons promised to serve King Solomon faithfully."
    },
    {
      "verse": "25",
      "text": "The Lord caused all the people in Israel to respect Solomon as a great king. They gave him much honour, more than any king that had ruled Israel before him."
    },
    {
      "verse": "26",
      "text": "Jesse's son David had ruled over all Israel as king."
    },
    {
      "verse": "27",
      "text": "years. He ruled for seven years in Hebron. Then he ruled for 33 years in Jerusalem."
    },
    {
      "verse": "28",
      "text": "He was an old man when he died. During his long life, God gave him riches as well as honour. Then David's son Solomon became king instead of him."
    },
    {
      "verse": "29",
      "text": "The prophets Samuel, Nathan and Gad wrote history books about all the things that King David did. They wrote down everything that he did as king, from the beginning to the end."
    },
    {
      "verse": "30",
      "text": "The books tell us how he ruled with great power. They tell us about the things that happened to him. They also tell us about the things that happened in Israel and in the other kingdoms in that region."
    }
  ]
};
