module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "King Nebuchadnezzar of Babylon came to Jerusalem with his army. He put his soldiers around the city to attack it. This happened when Jehoiakim had been king of Judah for nearly three years."
    },
    {
      "verse": "2",
      "text": "The Lord God gave Nebuchadnezzar power over King Jehoiakim. Nebuchadnezzar took away some special things that belonged in God's temple in Jerusalem. He took those things back to Babylon. He put them among the valuable things in the temple of his own god."
    },
    {
      "verse": "3",
      "text": "Nebuchadnezzar had an officer who was called Ashpenaz. Ashpenaz had authority over the king's other officers. One day, Nebuchadnezzar said to Ashpenaz, ‘Bring some of the Israelite men to me. Choose some men from the king of Judah's family, and choose some men from the other important Israelite families. ’"
    },
    {
      "verse": "4",
      "text": "Nebuchadnezzar wanted young men who were strong and handsome. They must be clever so that they could learn and understand things quickly. They must be good enough to become King Nebuchadnezzar's servants. They would learn the language of Babylon, and they would read its books."
    },
    {
      "verse": "5",
      "text": "Every day, King Nebuchadnezzar sent special food for these men to eat. It was the same food and wine that he had for himself. His officers would teach the young men for three years. After that, the young men would be ready to serve the king."
    },
    {
      "verse": "6",
      "text": "Some of the young men from Judah that Ashpenaz chose were Daniel, Hananiah, Mishael and Azariah."
    },
    {
      "verse": "7",
      "text": "The king's officer gave new names to them. Daniel was called Belteshazzar. Hananiah was called Shadrach. Mishael was called Meshach. Azariah was called Abednego."
    },
    {
      "verse": "8",
      "text": "But Daniel decided that God did not want him to eat the king's food and wine. He knew that it might be against God's rules. So he asked the king's special officer that he might not have to eat the king's food."
    },
    {
      "verse": "9",
      "text": "God had already caused the officer to like Daniel and to be kind to him."
    },
    {
      "verse": "10",
      "text": "But the officer said to Daniel, ‘I am afraid of the king, who is my master. He has chosen the food that he wants you to eat. If you eat different food, you might become weaker than the other young men. If the king sees that, he might kill me! ’"
    },
    {
      "verse": "11",
      "text": "The officer had chosen a guard to watch Daniel, Hananiah, Mishael and Azariah. So Daniel spoke to this man."
    },
    {
      "verse": "12",
      "text": "He said, ‘Please sir, watch us for ten days. Give us only vegetables to eat and water to drink."
    },
    {
      "verse": "13",
      "text": "After ten days, see what our faces and our bodies look like. Also see what the other young men who eat the king's food look like. When you look at them and you look at us, you can decide what to do with us. ’"
    },
    {
      "verse": "14",
      "text": "The guard agreed to what they said. He watched them for ten days."
    },
    {
      "verse": "15",
      "text": "After ten days, their faces seemed more handsome than the young men who ate the king's food. Their bodies also seemed to be fatter."
    },
    {
      "verse": "16",
      "text": "So the guard no longer gave them the king's food and wine to eat. He gave vegetables and water to them instead."
    },
    {
      "verse": "17",
      "text": "God helped these four young men to become clever and wise. While they studied, he helped them to learn from many different books. They could understand many things. Daniel could also understand the meaning of all kinds of dreams."
    },
    {
      "verse": "18",
      "text": "King Nebuchadnezzar had said that the young men must study for three years. After that time finished, the king's officer took them to the king."
    },
    {
      "verse": "19",
      "text": "The king spoke with all the young men. He discovered that there was nobody else like Daniel, Hananiah, Mishael and Azariah. So they became the king's servants."
    },
    {
      "verse": "20",
      "text": "Whenever the king needed help to understand something important, these men showed how wise they were. They knew ten times more than any of the king's other wise men. Those men used magic or they studied the stars to know what would happen in the future. They came from all the different countries that Nebuchadnezzar ruled."
    },
    {
      "verse": "21",
      "text": "And Daniel lived in Babylon until the year when Cyrus became king."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "When Nebuchadnezzar had been king for two years, he had many dreams. He had trouble in his mind and he could not sleep."
    },
    {
      "verse": "2",
      "text": "He told his servants that they must bring the magicians, enchanters, diviners and wise men to him. He wanted them to explain his dream. So they came in and they stood in front of the king."
    },
    {
      "verse": "3",
      "text": "Then the king said to them, ‘I have had a dream that gives me trouble in my mind. I want to know what the dream means. ’"
    },
    {
      "verse": "4",
      "text": "Then the wise men answered the king. (This is in the Aramaic language. ) They said, ‘King, live for ever! We are your servants. Tell us the dream. Then we will tell you what it means. ’"
    },
    {
      "verse": "5",
      "text": "The king replied to the wise men, ‘I have decided what to do. You must tell me what my dream was. Then you must tell me what it means. If not, I will punish you with death! My soldiers will cut you into pieces. They will knock down your houses so that they become heaps of stones."
    },
    {
      "verse": "6",
      "text": "You must tell me about the dream and you must tell me what it means. If you do that, I will give to you many gifts and great honour. So you must tell me my dream, and tell me what it means. ’"
    },
    {
      "verse": "7",
      "text": "They answered the king again, ‘We are your servants, so please tell us your dream. Then we will tell you what it means. ’"
    },
    {
      "verse": "8",
      "text": "The king said to them, ‘You know that I will not change my mind. So you are just trying to get more time."
    },
    {
      "verse": "9",
      "text": "If you do not tell me the dream, I will certainly punish you with death. You have agreed among yourselves to tell me lies. You want to deceive me until you can think of something better. So now, tell me the dream. Then I will believe you when you tell me what it means. ’"
    },
    {
      "verse": "10",
      "text": "The wise men answered the king, ‘There is nobody on earth who can know your dream! No king has ever asked anyone to do anything like this. No magician, enchanter or wise man could do that. Even the greatest and most powerful king has never asked anyone to do this."
    },
    {
      "verse": "11",
      "text": "You are asking us to do something much too difficult! Nobody can do it, except the gods. And they do not live among men. ’"
    },
    {
      "verse": "12",
      "text": "This made the king very angry. So he said to his soldiers, ‘Kill all the wise men in Babylon. ’"
    },
    {
      "verse": "13",
      "text": "He sent a message to command them to kill all his wise men. Some men went to look for Daniel and his friends too. They wanted to punish them with death."
    },
    {
      "verse": "14",
      "text": "But Daniel spoke carefully to Arioch. He was the captain of the king's soldiers who had gone to kill the wise men of Babylon."
    },
    {
      "verse": "15",
      "text": "Daniel said to Arioch, ‘Why is the king's command so cruel? ’ Then Arioch explained everything to Daniel."
    },
    {
      "verse": "16",
      "text": "So Daniel went to see the king. He asked the king for more time. Then he would be able to tell the king what the dream meant."
    },
    {
      "verse": "17",
      "text": "Then Daniel went to his home. He told his friends, Hananiah, Mishael and Azariah what had happened. ‘Praise God's great name for ever! He has great wisdom and great power."
    },
    {
      "verse": "18",
      "text": "He told them that they should pray to God in heaven. They should pray that God would help them with this problem. They should ask God to keep them safe. Then they would not die with all the other wise men of Babylon."
    },
    {
      "verse": "19",
      "text": "During the night, Daniel had a vision. God showed him the secret of the king's dream. Then Daniel praised the God of heaven."
    },
    {
      "verse": "20",
      "text": "He said, ‘Praise God's great name for ever! He has great wisdom and great power."
    },
    {
      "verse": "21",
      "text": "He makes things happen at the right time. He gives to some kings authority to rule. And he takes that authority away from other kings. He causes some people to become wise. He helps people to understand the things that they learn. He gives to some kings authority to rule. And he takes that authority away from other kings. He causes some people to become wise. He helps people to understand the things that they learn."
    },
    {
      "verse": "22",
      "text": "He explains difficult problems and secret things. He knows about all things, even when they are in dark places. He himself lives in the light. He knows about all things, even when they are in dark places. He himself lives in the light."
    },
    {
      "verse": "23",
      "text": "My ancestors' God, I thank you and I praise you! You have made me wiseand you have made me strong. We asked you to help us, and now you have shown me your answer. You have explained the king's problem to us. So I thank you. ’ I thank you and I praise you! You have made me wise and you have made me strong. We asked you to help us, and now you have shown me your answer. You have explained the king's problem to us. So I thank you. ’"
    },
    {
      "verse": "24",
      "text": "So Daniel went to see Arioch, the king's officer. The king had told Arioch to kill all the wise men of Babylon. But Daniel said to him, ‘Do not kill Babylon's wise men. Take me to the king. Then I will tell the king what his dream means. ’"
    },
    {
      "verse": "25",
      "text": "Then Arioch quickly took Daniel to meet the king. He said, ‘I have found this man, who is one of the people that you brought from Judah. He can tell you, sir, what your dream means. ’"
    },
    {
      "verse": "26",
      "text": "The king spoke to Daniel, whose other name was Belteshazzar. He asked Daniel, ‘Can you tell me my dream? And can you tell me what it means? ’"
    },
    {
      "verse": "27",
      "text": "Daniel answered the king, ‘Sir, your dream is a secret. No wise men, enchanters, magicians or diviners can tell you about it."
    },
    {
      "verse": "28",
      "text": "But there is a God in heaven. He explains secret things. In your dream, he has shown you what will happen in future years. Now I will tell you the dream and the visions that you had while you lay on your bed."
    },
    {
      "verse": "29",
      "text": "While you lay on your bed, you dreamed about future times. God explains secret things, and he has shown you what will happen in future years."
    },
    {
      "verse": "30",
      "text": "I am not more wise than other people. But God has explained your secret dream to me, because he wants you to know what it means. He wants you to understand the thoughts in your mind. ’"
    },
    {
      "verse": "31",
      "text": "Daniel said, ‘In your dream, you saw in front of you a statue with a man's shape. It was very big and very bright. It frightened people very much."
    },
    {
      "verse": "32",
      "text": "Its head was made from pure gold. The top of its body and its arms were made from silver. Its lower body was made from bronze."
    },
    {
      "verse": "33",
      "text": "The statue's legs were made from iron. Its feet had parts made from iron and parts made from clay."
    },
    {
      "verse": "34",
      "text": "While you looked, someone cut out a large stone from a mountain. But no human hand did this. The stone hit the statue on its iron and clay feet. The stone broke them into pieces."
    },
    {
      "verse": "35",
      "text": "Then the iron, the clay, the bronze, the silver and the gold all broke into pieces. They became like chaff that the wind blows away. Nobody could see any of those pieces any more. But the stone that had hit the statue became a large mountain. It filled the whole earth. ’"
    },
    {
      "verse": "36",
      "text": "Daniel continued to say, ‘That was your dream, King Nebuchadnezzar. Now we will tell you what it means."
    },
    {
      "verse": "37",
      "text": "You are a great king who rules over other kings. The God of heaven has given you authority to rule. He has given you power, strength and honour."
    },
    {
      "verse": "38",
      "text": "He has put all the people of this world, the wild animals and the birds under your power. He has given you authority to rule them all, in every place that they live. You are like the head of gold that you saw in your dream."
    },
    {
      "verse": "39",
      "text": "After you, there will be another kingdom. It will not be as great as your kingdom. Then a third kingdom will come. It will be like the bronze part of the statue. It will also rule the whole earth."
    },
    {
      "verse": "40",
      "text": "Then there will be a fourth kingdom. It will be as strong as iron which breaks everything into pieces. Like iron, that kingdom will destroy the other kingdoms."
    },
    {
      "verse": "41",
      "text": "In your dream, you saw that the statue's feet and toes had parts of clay and parts of iron. This shows that this kingdom will not be united as one. Some parts will be strong, like iron. The iron that you saw shows that strength."
    },
    {
      "verse": "42",
      "text": "But the iron parts of the statue were mixed with clay parts. This shows that the fourth kingdom will be strong in some parts and weak in other parts."
    },
    {
      "verse": "43",
      "text": "You saw iron and clay that were mixed together. The two parts of that kingdom will try to become united by marriage. But that will not help them to stay together as one. Iron cannot mix properly with clay."
    },
    {
      "verse": "44",
      "text": "During the time when those kings rule, the God of heaven will begin a new kingdom. That kingdom will continue for ever. No other people will ever have power over it. It will break up all those other kingdoms and it will destroy them. And it will continue for ever. In your dream, King Nebuchadnezzar, the great God has shown you what will happen in future years. I have told you the dream, and I have told you what it means. You can be sure that all this is true. ’"
    },
    {
      "verse": "45",
      "text": "You saw the stone that came from the mountain. It was not a human hand that cut it out. That stone broke the iron, the bronze, the clay, the silver and the gold into pieces. In your dream, King Nebuchadnezzar, the great God has shown you what will happen in future years. I have told you the dream, and I have told you what it means. You can be sure that all this is true. ’"
    },
    {
      "verse": "46",
      "text": "Then King Nebuchadnezzar bent down with his face towards the ground. He gave honour to Daniel. He commanded his servants to offer sacrifices and to burn incense to praise Daniel."
    },
    {
      "verse": "47",
      "text": "The king said to Daniel, ‘It is true that your God rules all other gods. He rules over kings and he explains secret things. I know this because you were able to explain this dream to me. ’"
    },
    {
      "verse": "48",
      "text": "Then the king made Daniel an important officer. He also gave Daniel many valuable gifts. He gave Daniel authority to rule over the whole region of Babylon. Daniel also became the most important officer with authority over all the wise men in Babylon."
    },
    {
      "verse": "49",
      "text": "Daniel asked the king to give important jobs to Shadrach, Meshach and Abednego. So the king gave them authority over the region of Babylon. But Daniel himself stayed in the king's palace."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "King Nebuchadnezzar caused his workers to make a gold statue. It was 30 metres high and 3 metres wide. He built it on the flat land called Dura, in the Babylon region."
    },
    {
      "verse": "2",
      "text": "Then King Nebuchadnezzar sent a message to all his government officers. He told them to meet together in the place where the statue was. He wanted them to see that he had built a great statue."
    },
    {
      "verse": "3",
      "text": "So all the officers came. Those were the rulers, the judges, the wise people, and all the leaders in the different regions of the Babylon nation. They all came together to give honour to the statue that King Nebuchadnezzar had built."
    },
    {
      "verse": "4",
      "text": "Then an officer shouted aloud, ‘Listen to me, you people from every country and nation, who speak different languages! The king makes this command:"
    },
    {
      "verse": "5",
      "text": "Listen for the sound of music from trumpets, flutes, lyres, harps or any other kind of music. When you hear the music, you must bend down low towards the ground. You must worship the gold statue that King Nebuchadnezzar has built."
    },
    {
      "verse": "6",
      "text": "The king will punish anyone who does not do that. His soldiers will throw them immediately into a very hot fire. ’"
    },
    {
      "verse": "7",
      "text": "So, when all the people heard the different kinds of music, they obeyed. The people from every country and nation, who spoke different languages all bent down low. They worshipped the gold statue that King Nebuchadnezzar had built."
    },
    {
      "verse": "8",
      "text": "Then some wise men went to the king. They told him bad things against the Jews."
    },
    {
      "verse": "9",
      "text": "They said to the king, ‘King, live for ever!"
    },
    {
      "verse": "10",
      "text": "You made a rule. You said that everyone must listen for the sound of the special music. When they hear it, they must bend down and they must worship the gold statue."
    },
    {
      "verse": "11",
      "text": "You said that you would punish everyone who does not obey you. You said you would throw them into the middle of a very hot fire."
    },
    {
      "verse": "12",
      "text": "But there are some Jewish men who do not obey you. They are Shadrach, Meshach and Abednego. You gave them authority to take care of everything in Babylon region. Those men do not respect your authority. They do not give honour to your gods. They do not worship your gold statue. ’"
    },
    {
      "verse": "13",
      "text": "When King Nebuchadnezzar heard this, he was very angry. He told his servants to bring Shadrach, Meshach and Abednego to him. So they brought those men to stand in front of the king."
    },
    {
      "verse": "14",
      "text": "Nebuchadnezzar said to them, ‘Shadrach, Meshach and Abednego, is it true that you do not give honour to my gods? And you do not worship the gold statue that I have built?"
    },
    {
      "verse": "15",
      "text": "Next time you hear the sound of the special music, you must obey my rule. You must bend down and you must worship the statue that I have built. If you do not worship the statue, my servants will throw you immediately into the middle of a very hot fire. There is no god who can save you from my power. ’"
    },
    {
      "verse": "16",
      "text": "Shadrach, Meshach and Abednego answered the king, ‘King Nebuchadnezzar, we do not need to say anything to show you that we are not guilty."
    },
    {
      "verse": "17",
      "text": "We serve a great God. If you throw us into the very hot fire, he is able to keep us safe. Yes, sir, he will keep us safe from your power too."
    },
    {
      "verse": "18",
      "text": "But even if he does not save us, we still would not serve your gods. And we will not worship the gold statue that you have built. We want you to understand that very clearly, sir. ’"
    },
    {
      "verse": "19",
      "text": "Then Nebuchadnezzar was even more angry with Shadrach, Meshach and Abednego. His face became red. He said to his servants, ‘Make the fire in the oven seven times hotter than usual. ’"
    },
    {
      "verse": "20",
      "text": "He told the strongest men in his army, ‘Tie up Shadrach, Meshach and Abednego. Then throw them into the very hot fire! ’"
    },
    {
      "verse": "21",
      "text": "So the soldiers tied up Shadrach, Meshach and Abednego with ropes. They were still wearing their coats, their hats and their other clothes when the soldiers took hold of them. The soldiers threw them into the middle of the hot fire with all their clothes on."
    },
    {
      "verse": "22",
      "text": "The soldiers needed to obey the king in a hurry. The fire was very hot. As a result, flames from the fire killed the men who threw Shadrach, Meshach and Abednego into it."
    },
    {
      "verse": "23",
      "text": "So the three men, Shadrach, Meshach and Abednego, fell into the middle of the hot fire. The ropes still held them very strongly."
    },
    {
      "verse": "24",
      "text": "What King Nebuchadnezzar saw next surprised him very much. He jumped up and he shouted to his officers, ‘We tied up three men and we threw them into the fire. Isn't that right? ’ The officers answered the king, ‘Yes, sir, we certainly did that. ’"
    },
    {
      "verse": "25",
      "text": "The king said, ‘But I see four men walking about in the fire! No ropes are holding them and the fire has not hurt them. The fourth man seems like a son of the gods. ’"
    },
    {
      "verse": "26",
      "text": "King Nebuchadnezzar went near to the door of the oven where the very hot fire was. He shouted aloud to the men inside, ‘Shadrach, Meshach and Abednego, I see that you are servants of the powerful God who rules over everything. Now come out here! ’So Shadrach, Meshach and Abednego came out of the fire."
    },
    {
      "verse": "27",
      "text": "Then the king's officers, his wise men and the government rulers and leaders came near to the three men. They saw that the fire had not hurt Shadrach, Meshach or Abednego. The fire had not even burnt their hair or their clothes. They did not even have any smell from the fire."
    },
    {
      "verse": "28",
      "text": "Then King Nebuchadnezzar said, ‘Praise the God that Shadrach, Meshach and Abednego serve! He sent his angel to keep his servants safe. They continued to trust in their God. So they did not obey the command that I had made as king. They would not agree to serve any other god except their own God. They would rather have died than worship any other god."
    },
    {
      "verse": "29",
      "text": "No other god can save people like their God has done for them. So I make a command for the people of every nation who speak any language. They must never say anything against the God of Shadrach, Meshach and Abednego. If anyone does that, my soldiers will cut them into pieces. They will knock down those people's houses so that they become heaps of stones. ’"
    },
    {
      "verse": "30",
      "text": "Then the king gave more authority to Shadrach, Meshach and Abednego to rule in the region of Babylon."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "This is a message from King Nebuchadnezzar. I am sending this message to everyone in the world, the people in every nation, who speak every language. I hope that you all may have good and happy lives. I am sending this message to everyone in the world, the people in every nation, who speak every language. I hope that you all may have good and happy lives."
    },
    {
      "verse": "2",
      "text": "I am happy to tell you about the powerful God who rules over everything. He has done miracles and great things for me. He has done miracles and great things for me."
    },
    {
      "verse": "3",
      "text": "His miracles show his great strength. They are very powerful. His kingdom will continue for ever. He will always rule. They are very powerful. His kingdom will continue for ever. He will always rule."
    },
    {
      "verse": "4",
      "text": "I, Nebuchadnezzar, was at home in my palace. I was comfortable and happy. Everything was very good for me."
    },
    {
      "verse": "5",
      "text": "Then I had a dream that made me very afraid. The thoughts in my mind gave me great trouble as I lay on my bed."
    },
    {
      "verse": "6",
      "text": "So I told all the wise men in Babylon to come to me. I wanted them to tell me what the dream meant."
    },
    {
      "verse": "7",
      "text": "When the magicians, enchanters, wise men and diviners came to me, I told them the dream. But none of them could tell me what the dream meant."
    },
    {
      "verse": "8",
      "text": "Last of all, Daniel came to me and I told him the dream. I call him Belteshazzar, like my god's name. The spirit of the holy gods is in this man, Daniel."
    },
    {
      "verse": "9",
      "text": "I said to him, ‘Belteshazzar you are the leader of my wise men. I know that the spirit of the holy gods is in you. I know that no secret is too difficult for you to explain. Here is the dream that I saw. Tell me what it means."
    },
    {
      "verse": "10",
      "text": "This is the vision that I saw in my mind while I lay on my bed. I saw a tree there in front of me. It stood in the middle of the earth and it was very tall."
    },
    {
      "verse": "11",
      "text": "The tree grew taller and stronger. Its top touched the sky, so that everyone in the world could see it."
    },
    {
      "verse": "12",
      "text": "It had beautiful leaves and lots of fruits. There was enough food on it for everyone. Wild animals could live in its shade. Birds lived in its branches. It gave food for every living thing."
    },
    {
      "verse": "13",
      "text": "The vision in my mind continued while I lay on my bed. I saw a holy angel that came down from heaven."
    },
    {
      "verse": "14",
      "text": "The angel shouted aloud, “Cut down the tree. Cut off its branches. Tear off its leaves. Let its fruits go away to other places. The animals that are under the tree must run away. The birds that are in its branches must fly away."
    },
    {
      "verse": "15",
      "text": "But leave the base of the tree and its roots in the ground. Tie iron and bronze round it. Then leave it there in the grass. Make him wet with dew from the sky. Cause him to live with the animals in the fields of grass."
    },
    {
      "verse": "16",
      "text": "Take his human mind away from him. Instead, give him the mind of an animal for seven years."
    },
    {
      "verse": "17",
      "text": "The holy angels who take care of the earth have decided this. It is their command. Now everyone will be sure that the powerful God above rules over human kingdoms. He gives authority to rule to anyone that he chooses. He causes humble men to rule as kings. ” ’"
    },
    {
      "verse": "18",
      "text": "Then I said to Belteshazzar, ‘This is the dream that I, King Nebuchadnezzar, had. Now, you must tell me what it means. None of the wise men in any region of my kingdom can tell me what it means. But you can tell me, because the spirit of the holy gods is in you. ’"
    },
    {
      "verse": "19",
      "text": "Daniel, whose other name was Belteshazzar, was upset for a short time. His thoughts caused him a lot of trouble. The king said, ‘Belteshazzar, do not let the dream or what it means cause you trouble. ’Then Belteshazzar answered the king. ‘Sir, I would like the dream to be about your enemies and not about you."
    },
    {
      "verse": "20",
      "text": "You saw a tree that grew very tall and strong until its top touched the sky. Everyone in the world could see it."
    },
    {
      "verse": "21",
      "text": "It had beautiful leaves and lots of fruits. There was enough food on it for everyone. The wild animals lived under its shade. The birds built their nests in its branches."
    },
    {
      "verse": "22",
      "text": "You, the king, are like that tree. You have become great and strong. Your power reaches up to the sky. Your authority reaches to the ends of the world."
    },
    {
      "verse": "23",
      "text": "In your dream, you saw a holy angel who came down from heaven. He said, “Cut down the tree and destroy it. But leave the base of the tree and its roots in the ground. Tie iron and bronze round it. Then leave it in the grass. Make him wet with dew from the sky. Cause him to live in the fields with the wild animals for seven years. ”"
    },
    {
      "verse": "24",
      "text": "Now sir, this is what the dream means. The powerful God above has decided what he will do to my lord, the king."
    },
    {
      "verse": "25",
      "text": "People will chase you away from the city, so that you have to live with the wild animals. You will eat grass like cows do. Dew from the sky will make you wet. You will live in that way for seven years. Then you will understand that the powerful God above rules over human kingdoms. He gives authority to rule to anyone that he chooses."
    },
    {
      "verse": "26",
      "text": "The command was to leave the base of the tree and its roots in the ground. This means that you will be king again later. But before that, you will have to understand that it is God in heaven who rules."
    },
    {
      "verse": "27",
      "text": "So King Nebuchadnezzar, please do as I suggest. Stop doing bad things. Start to do things that are right. Turn away from your sins. Instead, be kind to poor people. Then, perhaps, you will continue to be comfortable and happy. ’"
    },
    {
      "verse": "28",
      "text": "All this happened to King Nebuchadnezzar."
    },
    {
      "verse": "29",
      "text": "One year later, he was walking on the flat roof of the king's palace in Babylon."
    },
    {
      "verse": "30",
      "text": "The king said, ‘Look how great Babylon is! It is the city that I have built to be my home as king. It shows that I am a great and powerful king! ’"
    },
    {
      "verse": "31",
      "text": "While King Nebuchadnezzar was still boasting about his power, he heard a voice from heaven. It said, ‘I am speaking to you, King Nebuchadnezzar. I have taken away your authority to rule as king!"
    },
    {
      "verse": "32",
      "text": "People will chase you away from the city so that you live with the wild animals. You will eat grass as cows do. I will cause you to live like that for seven years. Then you will understand that the powerful God above rules over human kingdoms. He gives authority to rule to anyone that he chooses. ’"
    },
    {
      "verse": "33",
      "text": "Immediately the message given to Nebuchadnezzar really happened. People chased him away from the city. He ate grass as cows do. Dew from the sky made his body wet. His hair grew very long, like the feathers of an eagle. His feet became like a bird's feet."
    },
    {
      "verse": "34",
      "text": "At the end of that time, I, Nebuchadnezzar, looked up towards heaven. My own mind returned to me again. I praised the powerful God above who lives for ever. I worshipped him as a great God. His kingdom will continue for ever. He will always have authority to rule. His kingdom will continue for ever. He will always have authority to rule."
    },
    {
      "verse": "35",
      "text": "All the people on the earth seem like nothing to him. He does whatever he wants among the angels in heaven, and among the people on the earth too. Nobody can stop him. Nobody can ask him, ‘Why are you doing that? ’ He does whatever he wants among the angels in heaven, and among the people on the earth too. Nobody can stop him. Nobody can ask him, ‘Why are you doing that? ’"
    },
    {
      "verse": "36",
      "text": "When my own mind returned to me, I also received my authority again as king. People respected me as a great king again. My officers and important men came back to work with me. I ruled again over my kingdom. I became even greater than I was before."
    },
    {
      "verse": "37",
      "text": "Now I, Nebuchadnezzar, praise the King of heaven as a great God. He always does what is right and fair. When people are proud, he can cause them to become humble."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "King Belshazzar gave a big party for 1, 000 important people in his country. He drank wine with all of them."
    },
    {
      "verse": "2",
      "text": "When he had drunk a lot of wine, he spoke to his servants. He commanded them to bring the valuable gold and silver cups, so that the people could drink from them. His father, King Nebuchadnezzar, had taken those cups from God's temple in Jerusalem. King Belshazzar wanted to drink from them, as well as his important friends, his wives and his other women."
    },
    {
      "verse": "3",
      "text": "So his servants brought the gold and silver cups that had come from God's temple in Jerusalem. Then the king, his wives, his other women and all the important people drank wine from those cups."
    },
    {
      "verse": "4",
      "text": "While they drank the wine, they praised their gods. Their gods were idols that were made from gold, silver, bronze, iron, wood and stone."
    },
    {
      "verse": "5",
      "text": "While they were doing that, the fingers of a human hand appeared. They wrote on the wall of the king's palace, near the light that stood in the room. The king watched the hand while it wrote."
    },
    {
      "verse": "6",
      "text": "When he saw it, his face became white. He was very afraid. His knees shook and his legs became weak."
    },
    {
      "verse": "7",
      "text": "The king called for his enchanters, his wise men and his diviners to come. When they arrived, the king said to them, ‘Who can read these words? Who can tell me what they mean? Whoever can do that, I will make him great. I will put valuable purple clothes on him and he will have a gold chain around his neck. I will make him the third ruler in the kingdom. ’"
    },
    {
      "verse": "8",
      "text": "Then all the king's wise men came in, but they could not read the words. They could not tell the king what the words meant."
    },
    {
      "verse": "9",
      "text": "So King Belshazzar became even more afraid. His face became even whiter. His officers did not know what to do."
    },
    {
      "verse": "10",
      "text": "The king's mother heard the voices of the king and his officers. So she came into the room where they were having the party. She said to the king, ‘King, live for ever! Do not be afraid. Do not shake with fear!"
    },
    {
      "verse": "11",
      "text": "There is a man in your kingdom who has the spirit of the holy gods in him. When your father was alive, this man showed that he was very wise, like the gods. He could understand secret things. Your father, Nebuchadnezzar, made him the leader of all the magicians, wise men, enchanters and diviners."
    },
    {
      "verse": "12",
      "text": "His name was Daniel, but the king called him Belteshazzar. He was very clever and he knew many things. He could explain what dreams mean. He could find the answer to difficult problems. Send somebody to bring Daniel here. He will tell you what these words mean. ’"
    },
    {
      "verse": "13",
      "text": "So they brought Daniel to stand in front of the king. The king said to him, ‘Are you one of the men that my father, the king, brought here from Judah? Is your name Daniel?"
    },
    {
      "verse": "14",
      "text": "I have heard that the spirit of the gods is in you. You are very wise and clever. I have heard that you understand many things."
    },
    {
      "verse": "15",
      "text": "I told my wise men and enchanters to read these words. I asked them to tell me what the words mean. But they could not explain the message to me."
    },
    {
      "verse": "16",
      "text": "I have heard that you can tell people what their dreams mean. And I have heard that you can find the answer to difficult problems. So can you read these words? Can you tell me what they mean? If you can do that, then I will put valuable purple clothes on you. You will have a gold chain around your neck. You will become the third ruler in the kingdom. ’"
    },
    {
      "verse": "17",
      "text": "Then Daniel answered the king, ‘You can keep your gifts for yourself. You can make someone else important. But I will read the words for the king, and I will tell him what they mean."
    },
    {
      "verse": "18",
      "text": "I tell you this, King Belshazzar. The powerful God who rules over everything gave authority to your father, Nebuchadnezzar, to rule as king. God made him very great and very famous, so that he ruled with power. People respected him as a great king."
    },
    {
      "verse": "19",
      "text": "Because God made him so great, the people in every nation, who spoke every language, were very afraid of him. If he wanted to kill someone, he could kill them. And if he wanted to save someone, he could let them live. If he wanted to make someone important, he did that. And if he wanted to make someone poor, he did that too."
    },
    {
      "verse": "20",
      "text": "But he became very proud and he boasted about his power. So God took away his kingdom. People did not respect him any longer as king."
    },
    {
      "verse": "21",
      "text": "They chased him away from his home. His mind became like an animal's mind. He lived with the wild donkeys. He ate grass like cows do. Dew from the sky made his body wet. He lived in that way until he understood that the powerful God above rules over human kingdoms. God gives authority to rule to anyone that he chooses."
    },
    {
      "verse": "22",
      "text": "King Belshazzar, you are Nebuchadnezzar's son, and you knew all that. But you did not become humble."
    },
    {
      "verse": "23",
      "text": "You thought that you were greater than the Lord of heaven. So you told your servants to bring the valuable cups that belong to God's temple. You yourself, your wives, your other women and your important friends drank wine from those cups. You praised your gods that were made from silver, gold, bronze, iron, wood and stone. Those are idols that cannot see or hear. They cannot understand anything. But you worshipped them instead of the true God. He is the God who gives life to you. He has power over everything that you do."
    },
    {
      "verse": "24",
      "text": "Because of that, God sent the hand that wrote this message."
    },
    {
      "verse": "25",
      "text": "These are the words: Mene, Mene, Tekel and Parsin."
    },
    {
      "verse": "26",
      "text": "This is what the words mean: Mene means “counted”. It shows that God has counted the days of your kingdom. Now these days are finished. Your kingdom has come to an end."
    },
    {
      "verse": "27",
      "text": "Tekel means “weighed”. It shows that God has weighed you. But the scales show that you are too light."
    },
    {
      "verse": "28",
      "text": "Peres means “separate”. It shows that God has cut your kingdom into two separate parts. He has given it to the people from Media and Persia. ’"
    },
    {
      "verse": "29",
      "text": "When Belshazzar heard that, he caused his servants to put purple clothes on Daniel. They put a gold chain round his neck to show that he was an important person. The king told everyone that Daniel had become the third ruler in the kingdom."
    },
    {
      "verse": "30",
      "text": "That same night, Belshazzar, the king of the Babylonians, died. His enemies killed him."
    },
    {
      "verse": "31",
      "text": "Then Darius from Media received power as king. He was 62 years old."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "men to rule the regions of his nation. Together, they would rule the whole kingdom."
    },
    {
      "verse": "2",
      "text": "He also chose three other men to be his officers. He gave them authority over the 120 rulers. The king wanted to be sure that they were working well. Daniel was one of the three officers."
    },
    {
      "verse": "3",
      "text": "Daniel did his work much better than the other officers and rulers. He was very good at his job. Daniel was so good that the king wanted to make him ruler over the whole kingdom."
    },
    {
      "verse": "4",
      "text": "The other officers and rulers were jealous. They wanted to find something bad about Daniel so that they could tell the king. They watched how Daniel worked to serve the king. But they could not find that he did any wrong thing. That was because Daniel was good and honest. He always did everything properly."
    },
    {
      "verse": "5",
      "text": "Then these men said to each other, ‘We cannot find anything that Daniel does wrong in his work. We must find something that he does to obey the laws of his God. ’"
    },
    {
      "verse": "6",
      "text": "So the officers and rulers agreed together what they would do. They went to the king and they said, ‘King Darius, live for ever!"
    },
    {
      "verse": "7",
      "text": "All the officers in the kingdom have decided on a good idea. All the rulers, the judges, the wise people, and the leaders in the different regions agree. We think that the king should make a strong law. For 30 days, people must pray only to you, the king. If they pray to any other person or god, you must punish them. Your servants must throw them into the cave where your lions live."
    },
    {
      "verse": "8",
      "text": "You should write down this law and then you should write your name on it, as king. Then it will be a law of the Medes and the Persians which nobody can change. ’"
    },
    {
      "verse": "9",
      "text": "King Darius agreed. He wrote his name on this new law."
    },
    {
      "verse": "10",
      "text": "Daniel heard that the king had written this new law. Then he went home. He went upstairs to his room where the windows opened in the direction of Jerusalem. He bent down on his knees and he prayed to God, and he thanked God. He did that three times every day, in the same way that he had always done before."
    },
    {
      "verse": "11",
      "text": "Then the officers and rulers who were jealous of Daniel went to see what he would do. They saw that Daniel was praying to God and he was asking God for help. The king answered them, ‘It is true. It is a law of the Medes and the Persians and nobody can change it. ’"
    },
    {
      "verse": "12",
      "text": "So they went to tell the king about this. They said, ‘Remember that you wrote a new law. You commanded that for 30 days, nobody must pray to any god or person, except to you, the king. If anyone prays to someone else, your servants must throw them into the cave where your lions live. ’The king answered them, ‘It is true. It is a law of the Medes and the Persians and nobody can change it. ’"
    },
    {
      "verse": "13",
      "text": "Then the officers said to the king, ‘But Daniel does not obey your new law. He is one of the men that they brought here from Judah. He does not respect you or your law. He still prays three times every day to his God. ’"
    },
    {
      "verse": "14",
      "text": "When the king heard this, he was very sad. He tried to think of a way to save Daniel. Until sunset, the king thought about what he could do to save Daniel."
    },
    {
      "verse": "15",
      "text": "Then the officers agreed together and they went back to the king. They said, ‘Remember, sir, that nobody can change a law that the king has made. It is a law of the Medes and the Persians. ’"
    },
    {
      "verse": "16",
      "text": "So the king sent his servants to fetch Daniel. Then they threw Daniel into the cave where the lions lived. The king said to Daniel, ‘You have always continued to serve your God. I am sure that he will save you. ’"
    },
    {
      "verse": "17",
      "text": "They took a big stone and they covered the top of the lions' cave. The king put a mark on the stone with his ring of authority. He also marked it with the rings of his important men. This meant that nobody could move the big stone to save Daniel."
    },
    {
      "verse": "18",
      "text": "Then the king returned to his palace. He ate no food. Nobody brought anything to him to give him pleasure. He was unable to sleep."
    },
    {
      "verse": "19",
      "text": "The king got up very early in the morning, at sunrise. He hurried to the cave where the lions were."
    },
    {
      "verse": "20",
      "text": "When he got near to the cave, he was very upset. He shouted to Daniel, ‘Daniel, you have continued to worship the living God, as his servant. Was your God able to save you from the lions? ’"
    },
    {
      "verse": "21",
      "text": "Then Daniel said to the king, ‘King, live for ever!"
    },
    {
      "verse": "22",
      "text": "My God sent his angel, and he shut the lions' mouths. So the lions have not hurt me. God knows that I have done no wrong thing. I have not done anything to hurt you, the king, either. ’"
    },
    {
      "verse": "23",
      "text": "The king was very happy when he heard Daniel's voice. He told his servants that they must pull Daniel up out of the lions' cave. So they lifted him out. When they looked at him, they saw that the lions had not hurt him at all. Daniel had trusted in his God, so God had kept him safe."
    },
    {
      "verse": "24",
      "text": "Then the king gave a command to his servants. They brought the jealous men who had said bad things against Daniel. They threw them into the lions' cave, together with their wives and their children. Before they reached the floor of the cave, the lions attacked them. They broke all their bones into pieces."
    },
    {
      "verse": "25",
      "text": "After that, King Darius wrote to all the people of every nation, who spoke all languages. He wrote:‘I hope that you all have good and happy lives. ‘I hope that you all have good and happy lives."
    },
    {
      "verse": "26",
      "text": "I have made a law for every part of my kingdom. All people must respect the God that Daniel serves. They must respect him with fear. He is the God who always lives. He will continue for ever. Nobody will ever destroy his kingdom. He will rule for ever. He is the God who always lives. He will continue for ever. Nobody will ever destroy his kingdom. He will rule for ever."
    },
    {
      "verse": "27",
      "text": "He rescues his people and he keeps them safe. He does powerful miracles in the heavens and on the earth. He has saved Daniel from the lions' power! ’ He does powerful miracles in the heavens and on the earth. He has saved Daniel from the lions' power! ’"
    },
    {
      "verse": "28",
      "text": "So Daniel continued to have authority while Darius was king, and also when Cyrus from Persia became king."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "In the first year that King Belshazzar ruled Babylon, Daniel had a dream. He saw visions in his head while he lay on his bed. He wrote down what he saw in the dream."
    },
    {
      "verse": "2",
      "text": "Daniel wrote, ‘I had a vision at night. I saw the four winds of the sky. They caused big waves in the great sea."
    },
    {
      "verse": "3",
      "text": "Then four large animals came out of the sea. They were all different from each other."
    },
    {
      "verse": "4",
      "text": "The first animal seemed like a lion, but it had the wings of an eagle. As I watched, someone pulled its wings off. They lifted it up and it stood on two feet like a man. They gave a man's mind to it."
    },
    {
      "verse": "5",
      "text": "Then I saw a second animal. It seemed like a bear. It raised itself up on one side and it had three ribs between its teeth. Someone said to it, “Stand up and eat the meat from many bodies. ”"
    },
    {
      "verse": "6",
      "text": "Then I saw another animal. It seemed like a leopard, but it had four wings on its back. They were like a bird's wings. This animal had four heads. It received authority to rule."
    },
    {
      "verse": "7",
      "text": "Then, while I looked, I saw a fourth animal in my vision. It was a terrible animal that was very strong. It had large iron teeth. It ate things and it broke them into pieces. It used its feet to stamp on everything else. It was different from the other animals. It had ten horns."
    },
    {
      "verse": "8",
      "text": "I was thinking about the horns and what they might mean. Then I saw another little horn that came up among the other ten horns. It pulled out three of those other horns to make room for itself. This little horn had eyes that looked like a man's eyes. It had a mouth that spoke proud words."
    },
    {
      "verse": "9",
      "text": "While I looked, people put some thrones in their places. Then the God who has ruled for ever sat on his throne. His clothes were as white as snow. His hair was white like pure wool. His throne and the wheels under it burned with flames of fire. Then the God who has ruled for ever sat on his throne. His clothes were as white as snow. His hair was white like pure wool. His throne and the wheels under it burned with flames of fire."
    },
    {
      "verse": "10",
      "text": "A river of fire poured out from the place where he was sitting. Thousands of servants were ready to do whatever he wanted. Many more thousands stood around, ready to serve him. Then the meeting of the court began. Someone opened the books to see what was in them. Thousands of servants were ready to do whatever he wanted. Many more thousands stood around, ready to serve him. Then the meeting of the court began. Someone opened the books to see what was in them."
    },
    {
      "verse": "11",
      "text": "I continued to watch as the little horn was speaking proud words. While I watched, someone killed the fourth animal. They threw its body into the fire. The fire destroyed it."
    },
    {
      "verse": "12",
      "text": "The other animals also lost their power to rule, but they could continue to live for a certain time."
    },
    {
      "verse": "13",
      "text": "I continued to watch in my vision at night and this is what I saw: I saw someone who seemed like a son of man. He was coming towards me, with the clouds of the sky around him. He came near to the God who has ruled for ever. People took him to stand in front of God. I saw someone who seemed like a son of man. He was coming towards me, with the clouds of the sky around him. He came near to the God who has ruled for ever. People took him to stand in front of God."
    },
    {
      "verse": "14",
      "text": "God gave him great honour and authority to rule as king. The people of all nations and those who spoke every language agreed to serve him. He has authority to rule for ever. He will never stop being king. Nobody will be able to destroy his kingdom. The people of all nations and those who spoke every language agreed to serve him. He has authority to rule for ever. He will never stop being king. Nobody will be able to destroy his kingdom."
    },
    {
      "verse": "15",
      "text": "I, Daniel, had much trouble in my mind. The things that I saw in my vision frightened me."
    },
    {
      "verse": "16",
      "text": "So I spoke to someone who was standing near God's throne. I asked him to explain what all these things meant. He told me the meaning of my vision."
    },
    {
      "verse": "17",
      "text": "He said, “The four large animals are four kings. They will rule kingdoms on the earth."
    },
    {
      "verse": "18",
      "text": "But the holy people of the Most High God will receive authority to rule as kings. God's kingdom will belong to them for ever. ”"
    },
    {
      "verse": "19",
      "text": "Then I wanted to know about the fourth animal. It was different from all the other animals. It was a terrible animal that made me very afraid. It had large iron teeth and feet with sharp bronze claws. It ate things and it broke them into pieces. It used its feet to stamp on everything else."
    },
    {
      "verse": "20",
      "text": "I wanted to know the meaning of the ten horns on its head. I also wanted to know about the little horn that came up among them. It pushed out three of the other horns. This horn had eyes, and a mouth that spoke proud words. The little horn seemed to be greater than the other horns."
    },
    {
      "verse": "21",
      "text": "While I was watching, the little horn attacked God's holy people. It was winning the fight against them."
    },
    {
      "verse": "22",
      "text": "But then the God who has ruled for ever arrived. As judge, he said that the holy people of the Most High God were good and right. Then the time came for God's holy people to receive the kingdom, so that it belonged to them."
    },
    {
      "verse": "23",
      "text": "The person that I had asked told me this: “The fourth animal shows that there will be a fourth kingdom on the earth. It will be different from all the other kingdoms. It will use its power to destroy the whole earth. It will stamp on everything and break them into pieces."
    },
    {
      "verse": "24",
      "text": "The ten horns show that ten kings will rule that kingdom. After them, another king will come to rule. He will be different from the other kings. He will get power over three kings."
    },
    {
      "verse": "25",
      "text": "He will insult the Most High God. He will be cruel to God's holy people. He will try to change the days for God's festivals and the laws about them. God's people will be under his power for three and a half times."
    },
    {
      "verse": "26",
      "text": "Then God's court will be ready to judge him. He will lose his authority to rule as king. That will be the end of his kingdom for ever!"
    },
    {
      "verse": "27",
      "text": "Then the holy people who belong to the Most High God will receive authority to rule as kings. They will have authority over all the kingdoms of the earth and all their great power. The kingdom of the Most High God will continue for ever. All rulers will serve him and obey him. ”"
    },
    {
      "verse": "28",
      "text": "That is a report of everything that I saw in my vision. It caused me, Daniel, to have much trouble in my mind and my face became white. But I did not tell anyone about these things. ’"
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "In the third year that King Belshazzar ruled Babylonia, I, Daniel, had another vision. That was after the vision that I had seen before."
    },
    {
      "verse": "2",
      "text": "In this vision, I saw that I was in the strong city of Susa, in Elam region. I was standing near the Ulai river."
    },
    {
      "verse": "3",
      "text": "I looked up and I saw a male sheep that had two long horns. It was standing beside the river. One of its horns was longer than the other one. The longer horn came up later than the shorter horn."
    },
    {
      "verse": "4",
      "text": "The sheep ran towards the west, the north and the south. He used his horns to push away all other animals. No other animal could stop him. Nobody could save them from his power. He did whatever he wanted to do. He boasted about his great strength."
    },
    {
      "verse": "5",
      "text": "While I was thinking about this, I saw a male goat that was coming from the west. It ran quickly across the earth. Its feet did not even touch the ground. The goat had a large horn between its eyes."
    },
    {
      "verse": "6",
      "text": "It came towards the male sheep that had two horns. I had seen that sheep as it stood beside the river. The goat was very angry. It ran to attack the sheep with all its strength."
    },
    {
      "verse": "7",
      "text": "I saw it as it attacked the sheep. It was so angry that it hit the sheep very hard. It broke off the sheep's two horns. The sheep had no power to stop the goat. The goat knocked the sheep down to the ground and it stamped on the sheep. Nobody could save the sheep from the power of the goat."
    },
    {
      "verse": "8",
      "text": "The male goat boasted even more about its power. Its large horn became very strong. But then the horn broke. Four other large horns came up in its place. Each of these horns pointed in a different direction."
    },
    {
      "verse": "9",
      "text": "Then a little horn grew out of one of these large horns. It grew to become very big. Its power reached towards the south, towards the east and towards the Beautiful Land."
    },
    {
      "verse": "10",
      "text": "Its power became so great that it reached up into heaven. It attacked heaven's army and the stars in the sky. It threw some of them down to the ground and it stamped on them."
    },
    {
      "verse": "11",
      "text": "It boasted that it was more powerful than the Captain of heaven's army. It stopped people from offering their sacrifices to God each day. It destroyed God's temple."
    },
    {
      "verse": "12",
      "text": "God's people accepted the rule of the horn, because they had turned against God. They offered their sacrifices to the horn, instead of to God. The horn stopped people from believing the truth. It was able to do everything that it wanted to do."
    },
    {
      "verse": "13",
      "text": "Then I heard two angels as they talked to each other. One angel asked, ‘How long will the things in this vision continue to happen? How long will this disgusting thing stop the sacrifices each day? How long will it stand against God and stamp on his temple and his army? ’"
    },
    {
      "verse": "14",
      "text": "The other angel answered, ‘It will continue for 2, 300 evenings and mornings. After that, God's temple will be clean again. ’"
    },
    {
      "verse": "15",
      "text": "When I, Daniel, had seen the vision, I tried to understand it. Then someone came to stand in front of me. He seemed like a man."
    },
    {
      "verse": "16",
      "text": "I heard a person's voice. It was coming across the Ulai river. The voice said, ‘Gabriel, help this man to understand the vision. ’"
    },
    {
      "verse": "17",
      "text": "So Gabriel came towards me, where I was standing. I was very afraid and I fell down onto the ground. He said to me, ‘You, as a human, need to understand that the vision is about the end of time. ’"
    },
    {
      "verse": "18",
      "text": "While Gabriel spoke to me I was lying with my face on the ground. I was asleep. But he touched me and he caused me to stand up."
    },
    {
      "verse": "19",
      "text": "Then he said to me, ‘I will tell you what will happen at the end of time. It will be a time when God is very angry. The vision shows what will happen at the time that God has chosen. That will be the time for everything to finish."
    },
    {
      "verse": "20",
      "text": "You saw a male sheep with two horns. Those horns mean the kingdoms of Media and Persia."
    },
    {
      "verse": "21",
      "text": "The male goat means the kingdom of Greece. The large horn between its eyes means the first king of Greece."
    },
    {
      "verse": "22",
      "text": "When that large horn broke, four horns grew in its place. Those horns show that the nation of Greece will become four separate kingdoms. But they will not be as powerful as the first kingdom."
    },
    {
      "verse": "23",
      "text": "Near the end of the time when those kings rule, the people will be completely wicked. Then a proud, cruel king will appear. He will deceive people."
    },
    {
      "verse": "24",
      "text": "He will become very strong, but this will not be a result of his own power. He will completely destroy many things. He will be successful in everything that he does. He will destroy powerful leaders and the holy people who belong to God."
    },
    {
      "verse": "25",
      "text": "Because he is clever, he will completely deceive people. He will boast about his power. People will think that they are safe, but he will kill many of them. He will stand against the Ruler of all rulers. But God will destroy him, without human help."
    },
    {
      "verse": "26",
      "text": "This vision about the evenings and the mornings is true. I have told you what it means. But keep the vision as a secret now. It will be a long time before these things happen. ’"
    },
    {
      "verse": "27",
      "text": "After I, Daniel, saw this vision, I became very weak. I was sick for many days. Then I got up. I returned to my work to serve the king. The vision caused me to be very upset. I could not understand it."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "This is what happened in the first year that Darius ruled Babylonia. He was the son of Xerxes, a descendant of the Medes. He became the king of Babylonia."
    },
    {
      "verse": "2",
      "text": "In the first year that Darius was king, I, Daniel, was reading God's book. I read the message that the Lord had given to his prophet, Jeremiah. He told Jeremiah that Jerusalem would continue to be a heap of stones for 70 years."
    },
    {
      "verse": "3",
      "text": "So I turned to my Lord God, to ask him for help. I prayed to him and I ate no food. I wore clothes of rough sackcloth. I put ashes on myself to show that I was upset."
    },
    {
      "verse": "4",
      "text": "I prayed to the Lord my God. I agreed that we were guilty and I prayed this prayer:‘Our Lord, you are a great God and we give you honour. In your covenant, you have promised to love your people. You continue to be faithful to those people who love you and obey your commands."
    },
    {
      "verse": "5",
      "text": "We have done bad things that are wicked and evil. We have turned against you. We have not obeyed your laws and your teaching."
    },
    {
      "verse": "6",
      "text": "We did not listen to your servants, the prophets. They spoke your message to our kings, to our rulers and to our ancestors. They spoke to all the people of our nation."
    },
    {
      "verse": "7",
      "text": "Our Lord, you always do what is right. Today we are very ashamed. The people of Judah, Jerusalem and all Israel have not been faithful to you. You have sent our people away to many countries. Some are near and some are far away. We are all ashamed because we have turned away from you."
    },
    {
      "verse": "8",
      "text": "Our kings, our leaders and our ancestors have turned away from you, Lord. So we are very ashamed."
    },
    {
      "verse": "9",
      "text": "Our Lord God, we have turned against you. But you are kind and you forgive people."
    },
    {
      "verse": "10",
      "text": "We have not obeyed the Lord our God. You sent your servants, the prophets, to give us your laws. But we have not lived in the way that your laws taught us."
    },
    {
      "verse": "11",
      "text": "All the people of Israel have turned away from your laws. We have refused to obey you. Your servant Moses gave us your laws. He warned us about your punishments. Now you have punished us in the way that he said. We have turned away from you."
    },
    {
      "verse": "12",
      "text": "So you have done what you promised to do to us and to our rulers. You have caused us to have terrible trouble. You have punished Jerusalem with more trouble than has ever happened to any other city."
    },
    {
      "verse": "13",
      "text": "All this trouble has come to us in the way that Moses wrote in the book of your laws. But we have still not tried to please you, the Lord our God. We have not turned away from our sins. We have not learned your true teaching."
    },
    {
      "verse": "14",
      "text": "So you were ready to punish us with this trouble. You are always right in everything that you do. You are right to punish us because we have not obeyed you."
    },
    {
      "verse": "15",
      "text": "Our Lord God, you used your great power to bring your people safely out of Egypt. You are still famous today because of what you did then. We know that we have done things that are wrong and wicked."
    },
    {
      "verse": "16",
      "text": "Our Lord, please stop being angry with us. Stop punishing your own city, Jerusalem, your holy mountain. Because of our sins and the evil things that our ancestors did, other people insult us. All the people who live near us laugh at Jerusalem and your people. So please do what is right, as you always do."
    },
    {
      "verse": "17",
      "text": "Our God, please accept my prayer. Please do what I have asked for. Your temple is now a heap of stones. Please bless it again, so that people will know that you are great."
    },
    {
      "verse": "18",
      "text": "Listen to us, my God. Our towns have become heaps of stones. See what has happened to the city that belongs to you. We do not ask you to do this because we are righteous people. We ask you because you are very kind."
    },
    {
      "verse": "19",
      "text": "Lord, please listen! Lord, please forgive us. Lord, please do what we have asked you to do. My God, please do it quickly, so that people give you honour. Help your city and your people who belong to you. ’"
    },
    {
      "verse": "20",
      "text": "I continued to pray and tell God about our sins. I agreed that I had done wrong things, and that my people, the Israelites, had also done wrong things. I asked the Lord my God to help Jerusalem, his holy mountain."
    },
    {
      "verse": "21",
      "text": "While I was praying, Gabriel came towards me. He was the same man that I had seen in the first vision. He flew quickly to me at the time of the evening sacrifice."
    },
    {
      "verse": "22",
      "text": "He said to me, ‘Daniel, I have come to teach you, so that you can understand these things."
    },
    {
      "verse": "23",
      "text": "As soon as you started to pray, God sent his message. I have come to tell you the message, because you are very important to God. Listen carefully, so that you understand the meaning of your vision."
    },
    {
      "verse": "24",
      "text": "God has decided the time of punishment for your people and your holy city. It will continue for 70 weeks. That will finish the punishment for their sins. The people will no longer turn against God. They will have paid the price for their sins. God will cause them to live for ever in a way that is right. God will show that the visions and messages of the prophets are true. The Most Holy Place will belong to God again."
    },
    {
      "verse": "25",
      "text": "I want you, Daniel, to understand this properly. There will be a command to build Jerusalem again. Then 7 weeks will pass, and 62 weeks will also pass. After that, a ruler that God has chosen will arrive. People will build the city of Jerusalem again. It will have streets and a strong wall around it. But there will be a lot of trouble at that time."
    },
    {
      "verse": "26",
      "text": "weeks have passed, people will kill the ruler that God had chosen. He will have nothing. Then a foreign ruler and his army will attack the city and the temple. He will destroy them quickly, like a flood of water. War and terrible trouble will continue until the end that God has decided."
    },
    {
      "verse": "27",
      "text": "The foreign ruler will make an agreement with many people. That agreement will continue for one week. In the middle of that week, he will stop the sacrifices and offerings in the temple. Instead, he will put a disgusting thing there that causes trouble. It will remain there until God finally destroys the ruler who destroys. His end will happen at the time that God has decided. ’"
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "In the third year that King Cyrus ruled Persia, God gave a message to Daniel. (Daniel's other name was Belteshazzar. ) The message was true. It was about a great war. Daniel had a vision which helped him to understand the message."
    },
    {
      "verse": "2",
      "text": "At that time I, Daniel, was very sad for three weeks."
    },
    {
      "verse": "3",
      "text": "I did not eat any special food. I ate no meat and I drank no wine. I did not put any sweet oil on my skin or my hair until the three weeks had finished."
    },
    {
      "verse": "4",
      "text": "On the 24th day of the first month, I was standing beside the great Tigris river."
    },
    {
      "verse": "5",
      "text": "I looked up. I saw a man who was wearing good linen clothes. He also wore a belt made of pure gold."
    },
    {
      "verse": "6",
      "text": "His body was bright like a jewel. His face shone like lightning. His eyes were like flames of fire. His arms and his feet shone like bright bronze. When he spoke, his voice was very loud, like the sound of many people's voices."
    },
    {
      "verse": "7",
      "text": "Only I, Daniel, saw this vision. The people who were with me did not see anything. But they became very afraid. They ran away to hide themselves."
    },
    {
      "verse": "8",
      "text": "So I was there alone to see this great vision. All my strength disappeared. My face became very white. I was very weak."
    },
    {
      "verse": "9",
      "text": "I listened to the man's voice. When I heard him, I fell down, with my face on the ground. I was completely asleep."
    },
    {
      "verse": "10",
      "text": "Then a hand touched me. It helped me to get up on my hands and knees."
    },
    {
      "verse": "11",
      "text": "The man said, ‘Daniel, God loves you very much. Listen carefully to what I say to you. Stand up now, because God has sent me to you. ’ When he said this, I stood up. But my body was still shaking."
    },
    {
      "verse": "12",
      "text": "Then he said to me, ‘Daniel, do not be afraid. God has listened to your prayers since the time that you first turned to him. You wanted to understand about God. You put yourself under his authority. So I have come to bring the answer to your prayers."
    },
    {
      "verse": "13",
      "text": "days. Then Michael came to help me. He is one of God's most important angels. He helped me because the ruler of Persia was keeping me there."
    },
    {
      "verse": "14",
      "text": "Now I have come to explain what will happen to your people in the future. The vision is about a future time. ’"
    },
    {
      "verse": "15",
      "text": "While he was saying this to me, I was looking down at the ground. I could not speak."
    },
    {
      "verse": "16",
      "text": "Then someone who looked like a man touched my lips. I opened my mouth and I was able to speak again. So I said to the person who stood in front of me, ‘Sir, the vision makes me very afraid. My strength has disappeared."
    },
    {
      "verse": "17",
      "text": "I am your servant, sir. I am too weak to speak with you. It is difficult for me to breathe. ’"
    },
    {
      "verse": "18",
      "text": "The angel who looked like a man touched me again. That made me stronger."
    },
    {
      "verse": "19",
      "text": "He said to me, ‘Do not be afraid. God loves you very much. Have peace in your mind. Now be strong and brave! ’ When he said this, I felt stronger. I said, ‘Sir, please speak to me now. You have made me strong again. ’"
    },
    {
      "verse": "20",
      "text": "Then the angel said to me, ‘I will tell you why I have come to you. I will explain to you what the words in the book of God's truth mean. But now I must return to fight a battle against the ruler of Persia. After I have won that battle, the ruler of Greece will appear."
    },
    {
      "verse": "21",
      "text": "Only Michael will help me. He is the angel who keeps your own people safe. Nobody else will be there to help me fight against God's enemies."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "I myself helped Michael in the first year that Darius ruled as king. I fought with Michael against his enemies. ’"
    },
    {
      "verse": "2",
      "text": "Then the angel said to Daniel, ‘Now I will tell you the truth about what will happen. There will be three more kings who rule Persia. After them, there will be a fourth king. He will be richer than all the other kings who ruled before him. He will become very powerful because of his riches. Then he will tell other nations that they must attack the kingdom of Greece."
    },
    {
      "verse": "3",
      "text": "Then a great king will appear. He will rule with great power. He will do whatever he wants to do."
    },
    {
      "verse": "4",
      "text": "While he rules powerfully like that, his kingdom will quickly break into four parts. Those parts will be in all directions. His descendants will not rule his kingdom. Instead, other people will rule as kings, but their kingdoms will not be as powerful."
    },
    {
      "verse": "5",
      "text": "Then the king who rules in the south will become strong. But one of his own army officers will become even stronger. That officer will rule a greater kingdom than the king of the south."
    },
    {
      "verse": "6",
      "text": "After some years, the king of the south and the king of the north will agree to be friends. The king of the south's daughter will go to marry the king of the north. That would make their agreement strong. But the plan will fail. She will lose her authority. Her husband will no longer rule as king. Someone will kill her, her husband, her child and the servants who helped her."
    },
    {
      "verse": "7",
      "text": "Later, someone from her family will become king of the south. He will attack the army of the king of the north. He will go into that king's strong city. He will win the battle against the king of the north."
    },
    {
      "verse": "8",
      "text": "He will take the images of their gods back to Egypt with him. He will also take away valuable things that they had made from gold and silver. Then for several years, he will not attack the king of the north again."
    },
    {
      "verse": "9",
      "text": "After that, the king of the north will take his army into the land that the king of the south rules. But they will cause him to return to his own country."
    },
    {
      "verse": "10",
      "text": "Then his sons will prepare to fight a war. They will bring together a large army. Their soldiers will march forward like a powerful river. They will fight a battle all the way into the strong place of their enemy."
    },
    {
      "verse": "11",
      "text": "Then the king of the south will be very angry. He will march with his army to fight against the king of the north. The king from the north will also have a large army, but the king of the south will win the battle."
    },
    {
      "verse": "12",
      "text": "The king of the south will boast that he has destroyed this large army. He will be proud that he has killed thousands of people. But he will not continue to win battles."
    },
    {
      "verse": "13",
      "text": "The king of the north will again bring together a large army. It will be even bigger than the army that he had before. After a few years, he will march forward with his great army and all their many weapons."
    },
    {
      "verse": "14",
      "text": "At that time, many people will turn against the king of the south. Violent men from your own people in Israel will also be ready to attack him. This would make the vision become true. They will fight against him, but they will fail."
    },
    {
      "verse": "15",
      "text": "Then the king from the north will march south with his army. He will build up heaps of earth around the walls of a strong city. He will take the city for himself. The soldiers of the kingdom in the south will not be able to stop him. Even their best soldiers will not be strong enough to win the fight."
    },
    {
      "verse": "16",
      "text": "The king who attacked from the north will do whatever he wants to do. Nobody will be able to stop him. He will march into the Beautiful Land. He will have the power to destroy it."
    },
    {
      "verse": "17",
      "text": "The king from the north will decide to march south with all his kingdom's strong army. He will make an agreement with the king of the south. He will give one of his daughters to marry the king of the south. He will try to destroy that kingdom, but his plan will fail. His daughter will not be able to do anything to help him."
    },
    {
      "verse": "18",
      "text": "After this, he will decide to attack the countries near the sea. He will take many of their cities for himself. But an officer of a foreign army will stop him. He will cause the king of the north to stop boasting. He will no longer be proud but he will be ashamed."
    },
    {
      "verse": "19",
      "text": "So the king of the north will return to the strong cities in his own country. But he will lose his power and he will fall. Nobody will ever see him again."
    },
    {
      "verse": "20",
      "text": "Then another king will rule in the north. He will try to make his kingdom even greater. He will send out a cruel man to take taxes from people. But that king will soon die. This will not happen in a battle or because people are angry with him."
    },
    {
      "verse": "21",
      "text": "The king who rules after him will be an evil man. He will not belong to the royal family, so he should not be the king. He will deceive people to make himself the king. It will happen at a time when people think that they are safe."
    },
    {
      "verse": "22",
      "text": "He will quickly destroy any army that tries to attack him. He will even kill the leader of God's covenant."
    },
    {
      "verse": "23",
      "text": "He will agree to be friends with other leaders. But then he will deceive them. He will become more and more powerful, but he will rule only a few people."
    },
    {
      "verse": "24",
      "text": "His army will suddenly attack a region that is very rich. The king will do things that none of his ancestors did. He will take valuable things from his enemies when he fights against them. He will share those things with the men who help him. He will make plans to attack strong cities. But he will only be able to do this for a short time."
    },
    {
      "verse": "25",
      "text": "The evil king of the north will bring together a large, strong army. He will feel brave enough to attack the king of the south. The king of the south will fight against him with an even larger and more powerful army. But the king of the south will not be able to win the battle. His own men will turn against him."
    },
    {
      "verse": "26",
      "text": "Even those who eat the king's food will try to kill him. Many of his soldiers will die in the battle. His army will run away."
    },
    {
      "verse": "27",
      "text": "These two kings will sit at the same table to make plans. But they will deceive each other with evil lies. Their plans will be useless. God has already decided when their time as kings will finish."
    },
    {
      "verse": "28",
      "text": "Then the king of the north will return to his own country. He will take many valuable things with him. As he returns, he will cause trouble for the people who obey God's covenant. He will do whatever he wants to do against them. Then he will continue his journey back to his own country."
    },
    {
      "verse": "29",
      "text": "At the time that God chooses, the king will attack the south again. This time the result will be different from the first time."
    },
    {
      "verse": "30",
      "text": "People will come in ships from the west to attack him. He will be afraid and he will turn back. He will be angry as he travels home. So he will cause more trouble for the people who obey God's covenant. He will give honour to those people who turn away from the holy covenant."
    },
    {
      "verse": "31",
      "text": "He will send his soldiers to attack Jerusalem's strong place. They will go into the holy place of the temple and they will make it unclean. They will stop people from offering the sacrifices each day. They will put a disgusting thing that causes trouble in the holy place."
    },
    {
      "verse": "32",
      "text": "The king will deceive the people who are no longer faithful to God. He will make them help him. But the people who are still faithful to God will work hard to stop him."
    },
    {
      "verse": "33",
      "text": "Wise Israelite leaders will teach many other people. But these teachers will suffer for some time. People will kill them in battle, or with fire. People will rob them. People will put some of them in prison."
    },
    {
      "verse": "34",
      "text": "When God's people are in a time of trouble, they will receive a little help. Many people will join them who are not their true friends."
    },
    {
      "verse": "35",
      "text": "Some of the wise leaders will suffer. As a result, God will make them clean and pure. This will continue until the time for the end. God has decided when that time will come."
    },
    {
      "verse": "36",
      "text": "The king will do whatever he wants to do. He will say that he is greater than any god. He will even say proud things to insult the God who rules all other gods. He will be successful until the time when God's anger finishes. God will finish doing what he has decided to do."
    },
    {
      "verse": "37",
      "text": "This king will not respect the gods that his ancestors worshipped. He will not even respect the god that women love. He will not respect any god. He will think that he is greater than all the gods."
    },
    {
      "verse": "38",
      "text": "Instead, he will give honour to the god that makes cities strong and safe. His ancestors did not know that god. But he will give gold, silver, jewels and other valuable gifts as offerings to that god."
    },
    {
      "verse": "39",
      "text": "He will ask a foreign god to help him as he attacks the strongest cities of his enemies. He will give great honour to those people who accept him as their leader. He will give them authority to rule many people. He will give them land because they have helped him."
    },
    {
      "verse": "40",
      "text": "At the time of the end, the king of the south will attack him. The king of the north will fight against him very strongly. He will march out quickly with chariots and soldiers who ride on horses. He will also have many ships. His army will attack many countries. He will go through those countries like a strong flood of water."
    },
    {
      "verse": "41",
      "text": "He will march into the Beautiful Land. He will kill many thousands of the people there. But these people will escape from his power: the people of Edom and Moab, and the leaders of Ammon."
    },
    {
      "verse": "42",
      "text": "He will have power over many countries. The country of Egypt will not escape."
    },
    {
      "verse": "43",
      "text": "He will take away from Egypt the gold, silver and other valuable things. The people of Libya and Ethiopia will be under his power."
    },
    {
      "verse": "44",
      "text": "But he will become afraid when he hears news from the east and the north. It will cause him to be very angry. He will go with his army to destroy many people."
    },
    {
      "verse": "45",
      "text": "He will put up his royal tents between the seas, at the holy mountain. But he will die there and nobody will help him. ’"
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "Then the angel said to me, ‘At that time God's great angel Michael will come. He is the leader who takes care of your people. There will be a time of great trouble. It will be worse than any trouble that has happened since God first made your nation. But many of your own people will escape from that trouble. Those are all the people whose names are written in the book."
    },
    {
      "verse": "2",
      "text": "Many dead people who lie under the ground will become alive again. Some of them will receive life that continues for ever with God. But other people will receive shame that continues for ever."
    },
    {
      "verse": "3",
      "text": "People who are wise will shine like the bright sky. Those who help many people to do what is right will also shine brightly for ever. They will shine like the stars in the sky at night."
    },
    {
      "verse": "4",
      "text": "Daniel, you must now close this message. Put seals on the book so that nobody can open it until it is time for the end of this world. Many people will try to understand about these things. They will travel everywhere to get more knowledge. ’"
    },
    {
      "verse": "5",
      "text": "After the angel said this, I, Daniel, looked up. I saw two other people. One of them stood on the same side of the river as me. The other one stood on the other side of the river."
    },
    {
      "verse": "6",
      "text": "One of them spoke to the man who wore linen clothes and who now stood above the river. He asked that man, ‘How long will it be until these wonderful things finish? ’"
    },
    {
      "verse": "7",
      "text": "The man who wore linen clothes lifted up both his hands towards the sky. I heard him make a strong promise with the authority of God, who lives for ever. He said, ‘It will continue for three and a half times. Then the enemies of God's holy people will finally lose their power. That will be the end of all these events. ’"
    },
    {
      "verse": "8",
      "text": "I heard the man's words, but I did not understand. So I said, ‘Sir, how will all these things finally finish? ’"
    },
    {
      "verse": "9",
      "text": "He said to me, ‘You must go now, Daniel. This message will remain secret until it is time for the end of this world. The seals will keep the book closed."
    },
    {
      "verse": "10",
      "text": "The time of trouble will cause many people to become clean and pure. But wicked people will continue to do evil things. No wicked people will understand what God is doing. But wise people will understand."
    },
    {
      "verse": "11",
      "text": "People will suffer for 1, 290 days during that time of trouble. It will start from the time when people can no longer offer their sacrifices each day in the temple. That is when the enemy will put a disgusting thing that causes trouble in the holy place."
    },
    {
      "verse": "12",
      "text": "But God will bless all those people who remain faithful until the 1, 335 days come to an end."
    },
    {
      "verse": "13",
      "text": "You yourself must serve God faithfully until the end of your life. You will die. But at the end of time you will rise to live again. Then you will receive the good things that God has prepared for you. ’"
    }
  ]
};