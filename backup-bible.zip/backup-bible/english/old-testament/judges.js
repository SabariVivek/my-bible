module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "After Joshua had died, the Israelites asked the Lord, ‘Which of our tribes should be the first to attack the Canaanites? ’"
    },
    {
      "verse": "2",
      "text": "The Lord replied, ‘Judah should attack first. I will give the land to them, to take for themselves. ’"
    },
    {
      "verse": "3",
      "text": "The men of Judah's tribe said to their cousins, the men of Simeon's tribe, ‘Join with us to fight against the Canaanites. Help us to take the land that God has given to our tribe. Then we will help you to take the land that belongs to your tribe. ’ So the men of Simeon's tribe joined with the men of Judah's tribe."
    },
    {
      "verse": "4",
      "text": "They attacked the Canaanites and the Perizzites at Bezek. The Lord helped them to win against 10, 000 Canaanite and Perizzite fighters."
    },
    {
      "verse": "5",
      "text": "In the battle, they found King Adoni-Bezek and they attacked him there."
    },
    {
      "verse": "6",
      "text": "The king ran away, but the Israelites caught him. They cut off his thumbs and his big toes."
    },
    {
      "verse": "7",
      "text": "King Adoni-Bezek said, ‘God has punished me because I did the same thing to 70 other kings. I cut off their thumbs and big toes. I made them pick up bits of food to eat under my table. ’ The Israelites took King Adoni-Bezek back to Jerusalem. He died there."
    },
    {
      "verse": "8",
      "text": "Judah's army then attacked Jerusalem. They took the city for themselves. They killed the people who lived there and they burnt down the buildings."
    },
    {
      "verse": "9",
      "text": "Then they went to fight against the Canaanites who lived in the hill country, in the Negev and in the low hills in the west."
    },
    {
      "verse": "10",
      "text": "They attacked the people who lived in Hebron. They won the fight against the clans of Sheshai, Ahiman and Talmai. Hebron was called Kiriath Arba at that time."
    },
    {
      "verse": "11",
      "text": "Then they went to attack the people who lived in Debir. It was called Kiriath Sepher at that time."
    },
    {
      "verse": "12",
      "text": "Caleb said, ‘If a brave man attacks and takes Kiriath Sepher, he can marry my daughter, Acsah. ’"
    },
    {
      "verse": "13",
      "text": "Othniel attacked the city and he took it. He was the son of Caleb's younger brother Kenaz. So Caleb gave his daughter Acsah to Othniel, to be his wife."
    },
    {
      "verse": "14",
      "text": "After this, Acsah told Othniel that they should ask her father to give them some land. She went to see her father, Caleb. As she got off her donkey, Caleb asked her, ‘What would you like me to do for you? ’"
    },
    {
      "verse": "15",
      "text": "She replied, ‘Please be kind and give me a special gift. You have given me some land in the Negev desert. Now please give me a place with springs so that I have water for the land. ’ So Caleb gave her some land with springs, on high land and on low land."
    },
    {
      "verse": "16",
      "text": "The Kenites were descendants of Moses' wife's father. They left Jericho with Judah's people to live in the region of Arad, in the Negev desert."
    },
    {
      "verse": "17",
      "text": "Then Judah's men joined with their cousins, Simeon's men, to attack the Canaanites who lived in Zephath. They completely destroyed the city. They gave it a new name, ‘Hormah’."
    },
    {
      "verse": "18",
      "text": "Judah's men also took for themselves the cities of Gaza, Ashkelon and Ekron, as well as the land around those cities."
    },
    {
      "verse": "19",
      "text": "The Lord helped the men of Judah so that they took the towns in the hill country for themselves. But they could not win against the people who lived on the lower land near the sea. Those people had iron chariots to help them fight."
    },
    {
      "verse": "20",
      "text": "Caleb received Hebron for his family, as Moses had promised him. Caleb had chased out the three clans of Anak who lived there."
    },
    {
      "verse": "21",
      "text": "The men of Benjamin's tribe could not chase out the Jebusites who lived in Jerusalem. As a result, the Jebusites continue to live in Jerusalem with the people of Benjamin."
    },
    {
      "verse": "22",
      "text": "The men of Joseph's tribes attacked Bethel. The Lord helped them to do this."
    },
    {
      "verse": "23",
      "text": "Bethel had been called Luz. They sent some men to look secretly at the city."
    },
    {
      "verse": "24",
      "text": "Those men saw a man who was leaving the city. They said to him, ‘If you show us how our soldiers can get into the city, we will keep you safe. ’"
    },
    {
      "verse": "25",
      "text": "So the man showed them a secret entrance to the city. The men of Joseph's tribes killed all the people in the city. But they kept the man and his family safe."
    },
    {
      "verse": "26",
      "text": "He went to the land of the Hittites. He built a city there. He called it Luz, and that is still its name."
    },
    {
      "verse": "27",
      "text": "But the men of Manasseh's tribe could not chase out the people of these five cities: Beth Shan, Taanach, Dor, Ibleam and Megiddo. The Canaanites who lived there were strong. So they continued to live in those cities and the regions around them."
    },
    {
      "verse": "28",
      "text": "When the Israelites had a strong army, they made the Canaanites do hard work for them. But they could never chase the Canaanites away completely."
    },
    {
      "verse": "29",
      "text": "The men of Ephraim's tribe could not chase out the Canaanites who lived in Gezer. Those Canaanites continued to live among the people of Ephraim in Gezer."
    },
    {
      "verse": "30",
      "text": "The men of Zebulun's tribe could not chase away the people who lived in Kitron and Nahalol. But they made the Canaanites who lived among them do hard work for them."
    },
    {
      "verse": "31",
      "text": "The men of Asher's tribe could not chase out the Canaanites who lived in Acco, Sidon, Ahlab, Aczib, Helbah, Aphek and Rehob."
    },
    {
      "verse": "32",
      "text": "Because of this, Asher's people continued to live among the Canaanites."
    },
    {
      "verse": "33",
      "text": "The men of Naphtali's tribe could not chase out the Canaanites who lived in Beth Shemesh and Beth Anath. They too continued to live among the Canaanites in the land. But the Canaanites who lived in Beth Shemesh and Beth Anath had to do hard work for the Israelites."
    },
    {
      "verse": "34",
      "text": "The Amorites were too strong for the men of Dan's tribe. So Dan's people had to live in the hill country. The Amorites would not let them live in the low land."
    },
    {
      "verse": "35",
      "text": "The Amorites were also strong enough to keep Mount Heres, Aijalon and Shaalbim for themselves. But when the Israelite army became stronger, they made the Amorites do hard work for them."
    },
    {
      "verse": "36",
      "text": "The border of the Amorites' land went from Scorpion Hill and it continued beyond Sela."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "The angel of the Lord went from Gilgal to Bokim. He said, ‘I have brought you out from Egypt. I brought you here to this land that I promised to give to your ancestors. I said that I would always do for you what I promised in my Covenant."
    },
    {
      "verse": "2",
      "text": "I told you not to make any agreement with the people who live in this land. I told you to destroy the altars where they worship their gods. But you have not done as I told you. Why have you not obeyed me?"
    },
    {
      "verse": "3",
      "text": "So now I tell you, I will not chase the Canaanites away so that you can take their land. Instead, they will cause trouble for you. Their false gods will cause you to turn away from me. ’"
    },
    {
      "verse": "4",
      "text": "When the Lord's angel had said this, the Israelites began to weep loudly."
    },
    {
      "verse": "5",
      "text": "They called that place Bokim. They offered sacrifices to the Lord there."
    },
    {
      "verse": "6",
      "text": "Joshua sent the people away. Each Israelite tribe went to take the part of the land that would belong to them."
    },
    {
      "verse": "7",
      "text": "The Israelites continued to serve the Lord while Joshua and the old men were still alive. Joshua and those men had seen the great things that the Lord had done to help Israel."
    },
    {
      "verse": "8",
      "text": "Then the Lord's servant Joshua, the son of Nun, died at 110 years old."
    },
    {
      "verse": "9",
      "text": "The people buried him in the land that had been given to his family. That was at Timnath Heres, in Ephraim's hill country, on the north side of Gaash mountain."
    },
    {
      "verse": "10",
      "text": "All the people of Joshua's generation died. The younger people no longer served the Lord. They themselves had not seen the great things that he had done to help Israel."
    },
    {
      "verse": "11",
      "text": "The Israelites did things that the Lord saw were evil. They worshipped the idols of Baal."
    },
    {
      "verse": "12",
      "text": "They turned away from the Lord God that their ancestors had worshipped. He was the one who had brought them safely out of Egypt. Instead, they served the false gods of the people who lived near them. They worshipped those gods and the Lord became very angry."
    },
    {
      "verse": "13",
      "text": "They turned away from the Lord and they worshipped the idols of Baal and Ashtoreth instead."
    },
    {
      "verse": "14",
      "text": "The Lord was very angry with the Israelites and he punished them. He sent robbers to attack them and take their animals and their food. He put them under the power of their enemies who lived around them. They were not strong enough to fight against their enemies."
    },
    {
      "verse": "15",
      "text": "When the Israelites went to fight against their enemies, the Lord turned against them. He punished them, as he said he would do. So the Israelites were in great trouble."
    },
    {
      "verse": "16",
      "text": "After that, the Lord chose judges to lead his people. These leaders rescued the Israelites from their enemies who were robbing them."
    },
    {
      "verse": "17",
      "text": "But the people did not obey their leaders. They refused to serve the Lord faithfully. Instead, they worshipped false gods. They did not live in the way that their ancestors had lived. Their ancestors had obeyed the Lord's commands, but they refused to obey him."
    },
    {
      "verse": "18",
      "text": "Every time that the Lord chose a judge to lead them, the Lord helped the leader to rescue them from their enemies. While the leader was still alive, the Lord was kind to them. When the Israelites called out to the Lord for help, he was sorry for them. He saw the cruel things that their enemies were doing to give them pain."
    },
    {
      "verse": "19",
      "text": "But when the leader died, the people would stop serving the Lord. They would do even more wicked things than their fathers had done. They would serve false gods and they would worship them. They refused to stop doing the wicked things that they wanted to do."
    },
    {
      "verse": "20",
      "text": "Because of this, the Lord became very angry with the Israelites. He said, ‘This nation of my people has not obeyed the covenant that I made with their ancestors."
    },
    {
      "verse": "21",
      "text": "So I will not chase out the nations that are still living in the land. They are the people who were still there when Joshua died."
    },
    {
      "verse": "22",
      "text": "I will use those nations to test the Israelites. I will see if my people will live carefully, in the way that I have shown them. That is the way that their ancestors lived. ’"
    },
    {
      "verse": "23",
      "text": "So the Lord let some of the Canaanite nations continue to live in the land. He did not chase them all away. He did not put them all under Joshua's power."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "The Lord allowed some nations to stay in Canaan. He would use them to test the Israelites who had not yet fought wars in Canaan."
    },
    {
      "verse": "2",
      "text": "He wanted to teach the young men of Israel how to fight their enemies, because they had not fought battles before."
    },
    {
      "verse": "3",
      "text": "The nations who remained were: the Philistines, with their five kings, all the Canaanites, the Sidonians, the Hivites who lived in the Lebanon mountains, from Mount Baal Hermon to Lebo-Hamath."
    },
    {
      "verse": "4",
      "text": "These nations were still there to test the Israelites. The Lord wanted to know if his people would obey his commands. Those were the commands that he had told Moses to give to the ancestors of the Israelites."
    },
    {
      "verse": "5",
      "text": "So the Israelites lived among those other nations, the Canaanites, Hittites, Amorites, Perizzites, Hivites and Jebusites."
    },
    {
      "verse": "6",
      "text": "Some Israelites married young women from these nations. They also let their daughters marry Canaanite men. As a result, the Israelites started to worship the Canaanite gods."
    },
    {
      "verse": "7",
      "text": "The Israelites forgot to serve the Lord their God. They did things that he saw were evil. They worshipped idols of Baal and Asherah."
    },
    {
      "verse": "8",
      "text": "The Lord was very angry with the Israelites. He let King Cushan-Rishathaim of Aram Naharaim attack them. They were under his power for eight years."
    },
    {
      "verse": "9",
      "text": "Then the Israelites called out to the Lord for help. So he chose Othniel to be their leader. He was the son of Kenaz, Caleb's younger brother. Othniel rescued them from their enemies."
    },
    {
      "verse": "10",
      "text": "The Lord's Spirit gave Othniel power to lead Israel. Othniel led them to fight against King Cushan-Rishathaim of Aram. The Lord helped Othniel to win the battle against the king."
    },
    {
      "verse": "11",
      "text": "As a result, the land of Israel had peace for 40 years. Then Kenaz's son Othniel died."
    },
    {
      "verse": "12",
      "text": "Once again the Israelites did things that the Lord saw were evil. Because of this, the Lord gave Eglon, the king of Moab, power over Israel."
    },
    {
      "verse": "13",
      "text": "King Eglon made an agreement with the Ammonites and the Amalekites to join together to attack Israel. They attacked Jericho, ‘The City of Palm Trees’, and they took it for themselves."
    },
    {
      "verse": "14",
      "text": "The Israelites were under King Eglon's power for 18 years."
    },
    {
      "verse": "15",
      "text": "Again the Israelites called out to the Lord for help. He chose Ehud to be their leader. He was the son of Gera, from Benjamin's tribe. Ehud's strong hand was his left hand. The Israelites sent him to pay their taxes to King Eglon of Moab."
    },
    {
      "verse": "16",
      "text": "Ehud made a short sword that was sharp on both sides. He tied it to the top of his right leg and he hid it under his coat."
    },
    {
      "verse": "17",
      "text": "He took the money to give to King Eglon, who was a very fat man."
    },
    {
      "verse": "18",
      "text": "After Ehud had given the money to the king, he sent back home the men who had carried it."
    },
    {
      "verse": "19",
      "text": "But when Ehud reached the stone idols at Gilgal, he turned round to go back to the king. He said to King Eglon, ‘I have a secret message for you, sir! ’ So the king said, ‘Leave us alone. ’ All his servants went out."
    },
    {
      "verse": "20",
      "text": "The king was now sitting alone in his cool room on the roof of the palace. Ehud went near to the king and he said, ‘I have a message from God for you. ’ The king started to get up from his chair."
    },
    {
      "verse": "21",
      "text": "Then Ehud used his left hand to take the sword from his right leg. He pushed it deep into the king's stomach."
    },
    {
      "verse": "22",
      "text": "The king's fat covered the whole sword, even its handle. Its point came out through the king's back. Ehud did not pull out the sword. He left it there."
    },
    {
      "verse": "23",
      "text": "Ehud went out of the room and he locked the doors. Then he escaped from the palace."
    },
    {
      "verse": "24",
      "text": "The king's servants came up to the room on the roof. They saw that the doors were locked. They thought that the king was using the toilet inside."
    },
    {
      "verse": "25",
      "text": "They waited for a long time and they started to worry. But the king still did not open the doors of his room. So they took the key and they opened the doors. Then they saw their master, the king! He was lying on the floor and he was dead."
    },
    {
      "verse": "26",
      "text": "While the servants were waiting outside the king's room, Ehud had escaped. He went past the stone idols, and he ran to Seirah."
    },
    {
      "verse": "27",
      "text": "When he arrived there in the hill country of Ephraim, he made a loud noise with a trumpet. He led the Israelites down from the hills."
    },
    {
      "verse": "28",
      "text": "He said to them, ‘Follow me! The Lord will put your enemy, the Moabites, under your power! ’ The Israelites followed him to the Jordan River, near the border of Moab. They would not let anyone go across the river."
    },
    {
      "verse": "29",
      "text": "That day they killed about 10, 000 Moabite soldiers. They were all strong, brave fighters, but none of them escaped."
    },
    {
      "verse": "30",
      "text": "The Israelites won the fight against Moab that day. The land of Israel had peace for 80 years."
    },
    {
      "verse": "31",
      "text": "After this, Anath's son Shamgar became Israel's leader. One time, he used a stick with a sharp point to kill 600 Philistines. He rescued the Israelites from their enemies, as Ehud had done."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "After Ehud died, the Israelites again did things that the Lord saw were evil."
    },
    {
      "verse": "2",
      "text": "So the Lord put them under the power of King Jabin. He was a Canaanite king who ruled in Hazor. The leader of Jabin's army was called Sisera. Sisera lived in Harosheth Haggoyim."
    },
    {
      "verse": "3",
      "text": "iron chariots for his army. He used his power to be cruel to the Israelites for 20 years. So they called out to the Lord for help."
    },
    {
      "verse": "4",
      "text": "At that time, Lappidoth's wife Deborah was leading the Israelites. She was a prophetess."
    },
    {
      "verse": "5",
      "text": "She would sit under a palm tree between Ramah and Bethel to judge people's problems. That was in the hill country of Ephraim. The Israelites would come to her when they had arguments. She would decide who was right."
    },
    {
      "verse": "6",
      "text": "One day, Deborah told Abinoam's son Barak to come to her. He lived in Kedesh, a town in Naphtali. She said to Barak, ‘The Lord, Israel's God, has given you this command: “March to Mount Tabor with 10, 000 men who belong to the tribes of Naphtali and Zebulun."
    },
    {
      "verse": "7",
      "text": "I will deceive Sisera, the leader of King Jabin's army. He will go to the Kishon river with his great army and all their chariots. I will put them all under your power. ” ’"
    },
    {
      "verse": "8",
      "text": "Barak said to Deborah, ‘I will go if you will come with me. But if you do not agree to go, I will not go either. ’"
    },
    {
      "verse": "9",
      "text": "Deborah said, ‘Yes, I will go with you. But you will not receive honour for the battle. Instead, the Lord will put Sisera under the power of a woman. ’So Deborah went with Barak to Kedesh."
    },
    {
      "verse": "10",
      "text": "Barak told the men from Zebulun and Naphtali to go with him to Kedesh. 10, 000 men came to follow him. Deborah also went with him."
    },
    {
      "verse": "11",
      "text": "A certain Kenite man called Heber, did not live with the other Kenites. They were descendants of Hobab, the father of Moses' wife. Heber was living in a tent beside the big tree in Zaanannim, near Kedesh."
    },
    {
      "verse": "12",
      "text": "Sisera heard news that Abinoam's son Barak had gone up to Mount Tabor."
    },
    {
      "verse": "13",
      "text": "So he gave a command to all his soldiers. He told them to go with him from Harosheth Haggoyim to the Kishon river. They had 900 iron chariots."
    },
    {
      "verse": "14",
      "text": "Then Deborah said to Barak, ‘Get ready! This is the day that the Lord will put Sisera under your power! The Lord will lead you into battle! ’So Barak led his 10, 000 soldiers down from Mount Tabor."
    },
    {
      "verse": "15",
      "text": "When they started to attack, the Lord caused Sisera and all his army with their chariots to have great trouble. The Israelites chased them with their swords. Sisera jumped off his chariot and he ran away."
    },
    {
      "verse": "16",
      "text": "Barak and his soldiers chased after Sisera's army and their chariots. They chased them to Harosheth Haggoyim. They killed Sisera's whole army. Not one of their soldiers was still alive!"
    },
    {
      "verse": "17",
      "text": "Sisera himself ran to hide in the tent of Heber's wife, Jael. He did that because King Jabin of Hazor had agreed to be friends with Heber's family."
    },
    {
      "verse": "18",
      "text": "Jael came out of her tent to say ‘hello’ to Sisera. She said to him, ‘Please come into my tent, sir. You can rest safely here. Do not be afraid. ’ So Sisera went into her tent to rest. Jael put a cloth over him."
    },
    {
      "verse": "19",
      "text": "Sisera said to her, ‘I am thirsty. Please give me some water to drink. ’ She gave him some milk from a leather bottle. Then she covered him again with the cloth."
    },
    {
      "verse": "20",
      "text": "Sisera said to her, ‘Stand at the door of your tent and watch. If someone comes to ask if anyone is here, say, “No. ” ’"
    },
    {
      "verse": "21",
      "text": "But Heber's wife Jael got a tent peg and a hammer. Sisera was very tired and he was asleep. Jael used the hammer to hit the peg into the side of Sisera's head. The peg went through his head into the ground. Sisera died."
    },
    {
      "verse": "22",
      "text": "Barak had been chasing Sisera. Jael went out of her tent to say ‘hello’ to him. She said to Barak, ‘Come here! I will show you the man that you are looking for. ’ Barak went with her into the tent. He saw Sisera there. He was lying on the ground and he was dead. Barak saw the peg that had gone through Sisera's head."
    },
    {
      "verse": "23",
      "text": "On that day, God caused King Jabin of Canaan to be very ashamed because the Israelites had won against his army."
    },
    {
      "verse": "24",
      "text": "From that time, the Israelite army became stronger, and King Jabin became weaker. Finally, the Israelites destroyed him."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "On that day Deborah sang this song, with Abinoam's son Barak:"
    },
    {
      "verse": "2",
      "text": "‘The leaders of Israel led their people out. The people were happy to follow them to the battle. Praise the Lord! The people were happy to follow them to the battle. Praise the Lord!"
    },
    {
      "verse": "3",
      "text": "Hear this, you kings! Listen, you rulers! I will sing to worship the Lord. Yes, I will praise him with a song. He is the Lord, Israel's God. I will sing to worship the Lord. Yes, I will praise him with a song. He is the Lord, Israel's God."
    },
    {
      "verse": "4",
      "text": "Lord, you came from Seir mountains. Yes, you marched from the land of Edom. As you came, the earth shook. Rain poured down from the clouds in the sky. Yes, you marched from the land of Edom. As you came, the earth shook. Rain poured down from the clouds in the sky."
    },
    {
      "verse": "5",
      "text": "The mountains shook when you appeared, as they shook at Sinai mountain when you showed your power. You are the Lord, the God of Israel. as they shook at Sinai mountain when you showed your power. You are the Lord, the God of Israel."
    },
    {
      "verse": "6",
      "text": "When Anath's son Shamgar ruled the land, nobody travelled on the roads. When Jael ruled, people walked on secret paths, because they were afraid. nobody travelled on the roads. When Jael ruled, people walked on secret paths, because they were afraid."
    },
    {
      "verse": "7",
      "text": "Nobody lived in the small villages. Then I, Deborah, became their leader. I became like a mother for Israel's people, to keep them safe. Then I, Deborah, became their leader. I became like a mother for Israel's people, to keep them safe."
    },
    {
      "verse": "8",
      "text": "When the Israelites chose new gods to worship, enemies attacked their cities. No one in Israel was ready to fight. Not one of their 40, 000 soldiers had a shield or a spear. enemies attacked their cities. No one in Israel was ready to fight. Not one of their 40, 000 soldiers had a shield or a spear."
    },
    {
      "verse": "9",
      "text": "I thank God for Israel's leaders, and the people who are ready to fight our enemies. Praise the Lord! and the people who are ready to fight our enemies. Praise the Lord!"
    },
    {
      "verse": "10",
      "text": "Listen to me, you rich people who ride on white donkeys, with beautiful cloths to sit on. And you people who walk along the road, you should listen too! with beautiful cloths to sit on. And you people who walk along the road, you should listen too!"
    },
    {
      "verse": "11",
      "text": "Listen to the voices of the singers near the wells of water. They sing about the great things that the Lord has done. They tell how Israel's soldiers have won against their enemies. Then the Lord's people marched down to the city gates. They sing about the great things that the Lord has done. They tell how Israel's soldiers have won against their enemies. Then the Lord's people marched down to the city gates."
    },
    {
      "verse": "12",
      "text": "“Wake up, Deborah! Wake up and sing a song! Get up, Barak, son of Abinoam! Take your enemies away as your prisoners. ” Get up, Barak, son of Abinoam! Take your enemies away as your prisoners. ”"
    },
    {
      "verse": "13",
      "text": "The faithful men who remained returned to their leaders. The Lord's people came to me. They were ready to fight against our enemies. The Lord's people came to me. They were ready to fight against our enemies."
    },
    {
      "verse": "14",
      "text": "Some men of Ephraim's tribe came to help, from the land where Amalek lived. They followed men of Benjamin's tribe, with their soldiers. Leaders also came from Makir. Army officers came from Zebulun's tribe. from the land where Amalek lived. They followed men of Benjamin's tribe, with their soldiers. Leaders also came from Makir. Army officers came from Zebulun's tribe."
    },
    {
      "verse": "15",
      "text": "The leaders of Issachar's tribe were with Deborah. Yes, the men of Issachar joined with Barak. Barak led them into the valley. But the men of Reuben's tribe could not decide what to do. Yes, the men of Issachar joined with Barak. Barak led them into the valley. But the men of Reuben's tribe could not decide what to do."
    },
    {
      "verse": "16",
      "text": "Instead, they stayed to take care of their sheep. Did they want to listen to the shepherds as they called out to their sheep? The clans of Reuben's tribe could not agree what they should do. Did they want to listen to the shepherds as they called out to their sheep? The clans of Reuben's tribe could not agree what they should do."
    },
    {
      "verse": "17",
      "text": "The men of Gilead stayed at home, on the east side of the Jordan River. The men of Dan's tribe stayed with their ships. The men of Asher's tribe also stayed in their homes near the sea. on the east side of the Jordan River. The men of Dan's tribe stayed with their ships. The men of Asher's tribe also stayed in their homes near the sea."
    },
    {
      "verse": "18",
      "text": "But the men of Zebulun's tribe were not afraid to die in war. The men of Naphtali's tribe were also ready to attack the enemy. The men of Naphtali's tribe were also ready to attack the enemy."
    },
    {
      "verse": "19",
      "text": "Kings of Canaan came and they fought against us. They attacked us at Taanach, near the stream at Megiddo. But they could not take any valuable silver from us. They attacked us at Taanach, near the stream at Megiddo. But they could not take any valuable silver from us."
    },
    {
      "verse": "20",
      "text": "Even the stars fought against Sisera! They travelled across the sky to attack him. They travelled across the sky to attack him."
    },
    {
      "verse": "21",
      "text": "The Kishon river carried away Sisera's soldiers. It used its power to stop them. So I will be brave and I will continue to fight! It used its power to stop them. So I will be brave and I will continue to fight!"
    },
    {
      "verse": "22",
      "text": "As for the horses of Sisera's army, their feet made a loud noise as they ran away. their feet made a loud noise as they ran away."
    },
    {
      "verse": "23",
      "text": "The Lord's angel says, “Punish Meroz! Punish the people who live there, because they did not come to help the Lord. They did not agree to fight against the Lord's strong enemy. ” Punish the people who live there, because they did not come to help the Lord. They did not agree to fight against the Lord's strong enemy. ”"
    },
    {
      "verse": "24",
      "text": "But Jael should receive great honour! Jael, the wife of Heber the Kenite, should receive more honour than all other women who live in tents. Jael, the wife of Heber the Kenite, should receive more honour than all other women who live in tents."
    },
    {
      "verse": "25",
      "text": "Sisera asked her for water to drink, and she gave him milk. She gave him the best cream in a beautiful bowl. She gave him the best cream in a beautiful bowl."
    },
    {
      "verse": "26",
      "text": "She took a tent peg in her left hand. She took a worker's hammer in her right hand. She hit the peg through Sisera's head. She broke his skull. She broke it completely. She knocked the sharp peg through his head. She took a worker's hammer in her right hand. She hit the peg through Sisera's head. She broke his skull. She broke it completely. She knocked the sharp peg through his head."
    },
    {
      "verse": "27",
      "text": "He fell to the floor at her feet. He lay there and he did not move. He died at the place where he fell. Jael had killed him! He lay there and he did not move. He died at the place where he fell. Jael had killed him!"
    },
    {
      "verse": "28",
      "text": "Sisera's mother looked out from the window of her house. She waited for Sisera to return. She said, “His chariot has taken a long time to come! Why do I not yet hear the sound of his horse's feet? ” She waited for Sisera to return. She said, “His chariot has taken a long time to come! Why do I not yet hear the sound of his horse's feet? ”"
    },
    {
      "verse": "29",
      "text": "Her wise ladies replied, and she herself thought the same thing: and she herself thought the same thing:"
    },
    {
      "verse": "30",
      "text": "“They are taking valuable things from their enemies. They are sharing the things between them. Each soldier will bring one or two women for himself. Sisera's share will be some beautiful cloth. Yes, he is bringing pieces of valuable cloth, and a beautiful necklace for me! That is why he is so late to return home. ” They are sharing the things between them. Each soldier will bring one or two women for himself. Sisera's share will be some beautiful cloth. Yes, he is bringing pieces of valuable cloth, and a beautiful necklace for me! That is why he is so late to return home. ”"
    },
    {
      "verse": "31",
      "text": "I pray that all your enemies will die as Sisera died, Lord! But I pray that those who love you will shine brightly. May they be strong like the sun at dawn. ’After that, there was peace in Israel for 40 years."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "The Israelites did things that the Lord saw were evil. So the Lord put them under the power of the Midianites for seven years."
    },
    {
      "verse": "2",
      "text": "They used their power to be cruel to the Israelites. The Israelites built huts in the hills to live in. They hid themselves in caves and other safe places."
    },
    {
      "verse": "3",
      "text": "When they planted seeds to grow food, their enemies would attack them. The Midianites, Amalekites and people from the east would come to rob them."
    },
    {
      "verse": "4",
      "text": "They made their camps on Israel's land. They took all their crops, as far south as Gaza. They left nothing for the Israelites to eat. They took away their sheep, cows and donkeys."
    },
    {
      "verse": "5",
      "text": "The groups of enemies came with their animals. They put up their tents all across the land. They came like a cloud of locusts. They were too many to count as they arrived on their camels. They took everything that grew on the land."
    },
    {
      "verse": "6",
      "text": "Because of the Midianites, the Israelites became poor and weak. So they called out to the Lord for help."
    },
    {
      "verse": "7",
      "text": "When the Israelites asked the Lord to rescue them from the Midianites,"
    },
    {
      "verse": "8",
      "text": "he sent a prophet to them. The prophet said to them, ‘This is what the Lord, Israel's God, says: “I brought you out of Egypt, where you were slaves."
    },
    {
      "verse": "9",
      "text": "I saved you from the power of the Egyptians and all those who were cruel to you. I chased away your enemies and I gave their land to you."
    },
    {
      "verse": "10",
      "text": "I said to you, ‘I am the Lord your God. You are now living in the land of the Amorites, but you must not worship their gods. ’ But you have not obeyed me. ” ’"
    },
    {
      "verse": "11",
      "text": "The Lord's angel came to sit under a big oak tree in Ophrah. It belonged to Joash, from Abiezer's clan. When the angel arrived, Joash's son Gideon was threshing wheat. He was doing it in a winepress because he wanted to hide his food from the Midianites."
    },
    {
      "verse": "12",
      "text": "The Lord's angel appeared to Gideon. He said to him, ‘The Lord is with you, brave fighter. ’"
    },
    {
      "verse": "13",
      "text": "Gideon replied, ‘But sir, if the Lord is with us, why has all this trouble happened to us? Our ancestors told us about all the great things that the Lord did for them. They told us how he brought them safely out of Egypt. But the Lord has not helped us like that. He has turned away from us. He has put us under the power of the Midianites. ’"
    },
    {
      "verse": "14",
      "text": "The Lord himself then said to Gideon, ‘Go now and use the strength that you have. Rescue Israel from the power of the Midianites. I myself am sending you to do this. ’"
    },
    {
      "verse": "15",
      "text": "Gideon said, ‘But sir, how can I rescue Israel? Look at me! My clan is the weakest in the tribe of Manasseh. And I am the youngest person in my family. ’"
    },
    {
      "verse": "16",
      "text": "The Lord answered him, ‘Understand that I will be with you! You will destroy the Midianites as if they were only one man. ’"
    },
    {
      "verse": "17",
      "text": "Gideon replied, ‘If you are pleased with me, please do something special. I want to know that you really are the Lord who is speaking to me."
    },
    {
      "verse": "18",
      "text": "Please stay here so that I can bring a gift for you. ’ The Lord answered, ‘I will stay here until you come back. ’"
    },
    {
      "verse": "19",
      "text": "Gideon went home and he cooked a young goat. He also used an ephah of flour to make some flat bread. He put the meat in a basket and he put the soup in a pot. He took the food to the one who was sitting under the oak tree."
    },
    {
      "verse": "20",
      "text": "God's angel said to him, ‘Put the meat and the bread on this rock. Pour the soup over them. ’ Gideon did what the angel told him to do."
    },
    {
      "verse": "21",
      "text": "Then the Lord's angel touched the meat and the bread with the end of the stick that he held in his hand. Fire came from the rock and it burnt up the meat and the bread. Then the Lord's angel disappeared."
    },
    {
      "verse": "22",
      "text": "Gideon realized that he had been talking to the Lord's angel. He cried out, ‘Oh no! Almighty Lord, I have seen your angel, face to face. ’"
    },
    {
      "verse": "23",
      "text": "But the Lord said to him, ‘Do not worry. Do not be afraid. You will not die because of this. ’"
    },
    {
      "verse": "24",
      "text": "So Gideon built an altar there to give honour to the Lord. He called it ‘The Lord is Peace’. The altar is still there, in Ophrah, on the land of Abiezer's clan."
    },
    {
      "verse": "25",
      "text": "On the same night, the Lord said to Gideon, ‘Take your father's bull from among his animals. Also take a second bull, one that is seven years old. Use them to pull down your father's altar to Baal. Also cut down the Asherah pole that is there."
    },
    {
      "verse": "26",
      "text": "Then build an altar in their place to give honour to the Lord your God. Build it in the proper way, on top of that hill. Then use the wood from the Asherah pole to burn the second bull as a burnt offering to me. ’"
    },
    {
      "verse": "27",
      "text": "So Gideon took ten of his servants, and he did what the Lord had said. He was afraid of the people in his father's family and the men of the town. So he did this at night, not in the day."
    },
    {
      "verse": "28",
      "text": "Early the next morning, the men of the town saw that someone had destroyed Baal's altar. They saw that someone had cut down the Asherah pole. They saw that someone had burned the second bull as a sacrifice on a new altar."
    },
    {
      "verse": "29",
      "text": "They asked each other, ‘Who has done this? ’ They asked many people until someone told them, ‘Joash's son Gideon has done this. ’"
    },
    {
      "verse": "30",
      "text": "Then the men of the town said to Joash, ‘Bring Gideon out of your house. We must punish him with death. He has destroyed Baal's altar, and he has cut down the Asherah pole that was beside it. ’"
    },
    {
      "verse": "31",
      "text": "Joash said to the angry men who were against him, ‘Are you trying to save Baal because he is in trouble? Why should you do that? Anyone who tries to help Baal will die before tomorrow arrives. If Baal really is a god, he should fight for himself. It is his altar that someone has pulled down! ’"
    },
    {
      "verse": "32",
      "text": "So after that, people called Gideon ‘Jerub-Baal’. That was because Joash had said, ‘Baal should fight for himself. He himself should punish the person who pulled down his altar. ’"
    },
    {
      "verse": "33",
      "text": "At that time, the Midianites, Amalekites and people of the east made an agreement to fight together. They crossed the Jordan River and they made their camp in the Jezreel valley."
    },
    {
      "verse": "34",
      "text": "Then the Lord's Spirit came to Gideon with power. Gideon made a loud noise with a trumpet. He called the men of Abiezer's clan to follow him."
    },
    {
      "verse": "35",
      "text": "He sent men to take a message to Manasseh's tribe. He told them to send their men to join him. He also told the men of the tribes of Asher, Zebulun and Naphtali to come and join him too. They all came to meet with Gideon."
    },
    {
      "verse": "36",
      "text": "Gideon said to God, ‘I want to know that you will do what you have promised to me. If you will really use me to rescue Israel, please show me that it is true."
    },
    {
      "verse": "37",
      "text": "I will do this: I will put the wool of a sheep's skin out on the stone floor. During the night, please cause the dew to make it wet. If it is wet but the ground around it is dry, I will know that it is true. You will use me to rescue Israel, as you have promised. ’"
    },
    {
      "verse": "38",
      "text": "That is what happened. When Gideon got up the next morning, the wool was wet. Gideon squeezed water out of it. It was enough to fill a bowl!"
    },
    {
      "verse": "39",
      "text": "Then Gideon said to God. ‘Please do not be angry with me. Let me ask you to do one more thing. I will put out the sheep's wool again to see what happens. This time please make the ground wet with dew, but keep only the wool dry. ’"
    },
    {
      "verse": "40",
      "text": "That night God did what Gideon had asked. The sheep's wool was dry, but the ground around it was wet with dew."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "Gideon and his army got up the next morning. They marched to the spring of water at Harod. They made their camp near there. The Midianite army made their camp in the valley near the hill of Moreh. They were north of the Israelite army."
    },
    {
      "verse": "2",
      "text": "The Lord said to Gideon, ‘You have too many men in your army. When I put the Midianites under your power, your soldiers may boast about their own strength. They may say that they have won the battle themselves."
    },
    {
      "verse": "3",
      "text": "So say to the men, “If you are very afraid of the battle and you are shaking with fear, you may go. ” ’ So 22, 000 men left that place and they went home. But 10, 000 soldiers remained with Gideon."
    },
    {
      "verse": "4",
      "text": "Then the Lord said to Gideon, ‘There are still too many men. Take them to the spring of water to drink. I will test them for you there. If I say, “This man should go with you, ” then take him. But if I say, “This man should not go with you, ” then do not take him. ’"
    },
    {
      "verse": "5",
      "text": "So Gideon took the men to the spring of water. The Lord said to Gideon, ‘Put the men who use their tongues to drink like a dog in one group. Put the men who go down on their knees to drink in another group. ’"
    },
    {
      "verse": "6",
      "text": "men used their tongues to drink the water. The other men all went down on their knees to drink."
    },
    {
      "verse": "7",
      "text": "The Lord said to Gideon, ‘I will use those 300 men to rescue you and put the Midianites under your power. Let all the other men return to their homes. ’"
    },
    {
      "verse": "8",
      "text": "men with him. He took the food and trumpets from the other men and he gave it to the 300 men. Then Gideon sent the other men home. The camp of the Midianite army was in the valley below the Israelites."
    },
    {
      "verse": "9",
      "text": "That night the Lord said to Gideon, ‘Get up now. Go down and attack the camp of the Midianites. I have put them under your power."
    },
    {
      "verse": "10",
      "text": "But if you are afraid to attack them now, take your servant Purah down to their camp."
    },
    {
      "verse": "11",
      "text": "Listen to what the Midianites are saying to each other. That will make you brave enough to attack them. ’ So Gideon took Purah with him to the edge of the Midianite army's camp, where they had guards."
    },
    {
      "verse": "12",
      "text": "The valley was full of Midianites, Amalekites and all the people from the east. They covered the ground like locusts. There were too many men to count. Their camels also were more than the sand on the shore of the sea."
    },
    {
      "verse": "13",
      "text": "When Gideon came nearer, he heard a Midianite soldier tell his friend about a dream. The soldier said, ‘In my dream, I saw a loaf of bread that was rolling into our camp. It hit one of our tents and it knocked the tent down to the ground! ’"
    },
    {
      "verse": "14",
      "text": "The other soldier replied, ‘This dream is telling us about Joash's son Gideon, the leader of the Israelites. It shows us that he has the power to kill us. God has put Midian and all our army under his power! ’"
    },
    {
      "verse": "15",
      "text": "When Gideon heard this news about the dream and its meaning, he praised God. He returned to the Israelites' camp. He shouted to his men, ‘Get up now! The Lord has put Midian's army under your power! ’"
    },
    {
      "verse": "16",
      "text": "men into three separate groups. He gave a trumpet and an empty pot to each soldier. Each man put a burning branch into his pot."
    },
    {
      "verse": "17",
      "text": "Gideon said to his men, ‘Watch me carefully. When we get near to the enemy's camp, you must do the same thing that I do."
    },
    {
      "verse": "18",
      "text": "You will be all around the camp. I and my group of men will make a noise with our trumpets. Then you must also make a noise with your trumpets. Then shout, “We are fighting for the Lord and for Gideon! ” ’"
    },
    {
      "verse": "19",
      "text": "men with him to the edge of the Midianites' camp. It was the middle of the night. A new group of Midianite guards had just started their work. Gideon's men made a loud noise with their trumpets. They also broke the pots that they were holding."
    },
    {
      "verse": "20",
      "text": "Then all three groups of Israelite soldiers made a noise with their trumpets that they held in the right hands. They broke their pots and they held their burning branches in their left hands. Then they shouted, ‘Fight for the Lord and for Gideon! ’"
    },
    {
      "verse": "21",
      "text": "They all stood in their places around the Midianites' camp. Then the whole Midianite army ran away! They were shouting as they ran as fast as they could run."
    },
    {
      "verse": "22",
      "text": "When Gideon's 300 men made a noise with their trumpets, it confused the Midianites everywhere in their camp. The Lord caused them to attack one another with their swords. Their army ran away to Beth Shittah, on the road towards Zererah. They ran as far as the border of Abel Meholah, near Tabbath."
    },
    {
      "verse": "23",
      "text": "Then Gideon told men from the tribes of Naphtali, Asher and Manasseh to chase the Midianites."
    },
    {
      "verse": "24",
      "text": "Then Gideon sent men to the hill country of Ephraim with this message: ‘Come down to the valleys and stop the Midianites from escaping. Put guards on all the places where people go across the streams and rivers. Do that on the Jordan River as far as Beth Barah. ’ So all the men of Ephraim's tribe came together. They put guards on the Jordan River and the streams, as far as Beth Barah."
    },
    {
      "verse": "25",
      "text": "They caught the two leaders of the Midianite army, Oreb and Zeeb. They killed Oreb at the rock of Oreb. They killed Zeeb at the winepress of Zeeb. They continued to chase the Midianites. They took the heads of Oreb and Zeeb to Gideon, who was now on the east side of the Jordan River."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "The men of Ephraim's tribe asked Gideon, ‘Why have you insulted us? You should have called us to join with you to fight against the Midianites. ’ They were very angry and they argued with Gideon. When Gideon said that, the men of Ephraim stopped being angry."
    },
    {
      "verse": "2",
      "text": "Gideon said to them, ‘What you did in the fight was more important than what I was able to do. My family started the battle, but your tribe finished the job!"
    },
    {
      "verse": "3",
      "text": "God chose you to take power over the leaders of Midian's army. You killed Oreb and Zeeb! Nothing that I did was as great as that! ’When Gideon said that, the men of Ephraim stopped being angry."
    },
    {
      "verse": "4",
      "text": "men were weak and tired. But they went across the Jordan and they continued to chase the Midianites."
    },
    {
      "verse": "5",
      "text": "Gideon said to the men of Succoth, ‘Please give my soldiers some food to eat. They are very tired. We are chasing the kings of Midian, Zebah and Zalmunna, to catch them. ’"
    },
    {
      "verse": "6",
      "text": "The city leaders of Succoth said, ‘You have not yet caught Zebah and Zalmunna. We will not give you any food until you have done that. ’"
    },
    {
      "verse": "7",
      "text": "Gideon replied, ‘Because you say that, I will return here. When the Lord has put Zebah and Zalmunna under my power, I will come back to punish you. I will beat you with thorn branches that will tear your skin to pieces! ’"
    },
    {
      "verse": "8",
      "text": "Gideon continued his journey to Peniel. He asked their people for food too. But they gave him the same answer as the men of Succoth."
    },
    {
      "verse": "9",
      "text": "Gideon also warned the men of Peniel, ‘When I have won the fight against my enemies, I will return. Then I will destroy your strong tower. ’"
    },
    {
      "verse": "10",
      "text": "Zebah and Zalmunna had 15, 000 men with them in Karkor. They were the only men left of their great army from the east. 120, 000 of their soldiers had died in the battle."
    },
    {
      "verse": "11",
      "text": "Gideon went along a road near the desert. It was east of Nobah and Jogbehah. He attacked the enemy's army by surprise."
    },
    {
      "verse": "12",
      "text": "The two kings of Midian, Zebah and Zalmunna, ran away. Gideon chased after them and he caught them. The whole Midianite army ran away in fear."
    },
    {
      "verse": "13",
      "text": "Then Gideon left the place of the battle to return home. He went along the road across Heres hills."
    },
    {
      "verse": "14",
      "text": "He caught a young man who came from Succoth. He asked him about the leaders of Succoth. The young man wrote down the names of 77 leaders and officers of the city."
    },
    {
      "verse": "15",
      "text": "Gideon went to Succoth with Zebah and Zalmunna. He said to the leaders, ‘Now I have brought these kings to you! You insulted me! You said, “We will not give your tired men any food until you have caught Zebah and Zalmunna. ” ’"
    },
    {
      "verse": "16",
      "text": "Then Gideon took hold of Succoth's leaders. He beat them with thorn branches to punish them."
    },
    {
      "verse": "17",
      "text": "He also went to Peniel and he destroyed their tower. He killed the men of that city."
    },
    {
      "verse": "18",
      "text": "Then Gideon said to Zebah and Zalmunna, ‘Tell me about the men that you killed at Tabor. What kind of men were they? ’ The kings answered, ‘They were like you. They looked like the sons of kings. ’"
    },
    {
      "verse": "19",
      "text": "Gideon said, ‘Those were my brothers, my own mother's sons. If you had not killed my brothers, I would not kill you. I promise you that, as surely as the Lord lives. ’"
    },
    {
      "verse": "20",
      "text": "Gideon said to his oldest son, Jether, ‘Kill them now! ’ But Jether was only a boy. He was too afraid to do anything. So Gideon did kill them. He took away the silver images from the necks of their camels."
    },
    {
      "verse": "21",
      "text": "Zebah and Zalmunna said to Gideon, ‘Kill us yourself! Let us see if you are brave enough to do that! ’So Gideon did kill them. He took away the silver images from the necks of their camels."
    },
    {
      "verse": "22",
      "text": "After that, the Israelites said to Gideon, ‘Rule over us as our king! You, your son and your grandson should rule us. You have rescued us from Midian's power. ’"
    },
    {
      "verse": "23",
      "text": "But Gideon said to them, ‘I will not agree to rule over you. Nor will my son rule over you. The Lord will rule over you. ’"
    },
    {
      "verse": "24",
      "text": "Gideon also said, ‘I will ask you only to do one thing for me. Each of you should give me one ear-ring from the things that you took from our enemies. ’ (The Midianites wore gold ear-rings because they were descendants of Ishmael. )"
    },
    {
      "verse": "25",
      "text": "The people replied, ‘We are happy to give them to you. ’So they put a coat on the ground. Each man threw a ring onto it."
    },
    {
      "verse": "26",
      "text": "kilograms. They also had valuable silver images and jewels. They had valuable clothes that the kings of Midian wore and necklaces from the camels."
    },
    {
      "verse": "27",
      "text": "Gideon used the gold to make an image of an ephod. He put it in Ophrah, where he lived. All the Israelites came there and they worshipped the image. It caused them to turn away from the true God. It became like a trap that caught Gideon and his family."
    },
    {
      "verse": "28",
      "text": "The Israelites now had complete power over the Midianites. The Midianites were too ashamed to fight against them. While Gideon was alive, the land of Israel had peace for 40 years."
    },
    {
      "verse": "29",
      "text": "Then Gideon went back home to live."
    },
    {
      "verse": "30",
      "text": "He had many wives. They gave birth to 70 sons for him."
    },
    {
      "verse": "31",
      "text": "Gideon also had a slave wife who lived in Shechem. She gave birth to a son for him. Gideon called him Abimelech."
    },
    {
      "verse": "32",
      "text": "Joash's son Gideon died when he was very old. People buried him in the grave of his father, Joash. That was in Ophrah, on the land of Abiezer's clan."
    },
    {
      "verse": "33",
      "text": "Soon after Gideon died, the Israelites stopped being faithful to the Lord. They started to worship the idols of Baal again. They chose Baal-Berith to be their new god."
    },
    {
      "verse": "34",
      "text": "They no longer served the Lord their God. They forgot that he had saved them from all the enemies who lived around them."
    },
    {
      "verse": "35",
      "text": "The Israelites did not remain faithful to Gideon's family either. They did not remember all the good things that he had done to help Israel."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "Gideon's son Abimelech went to Shechem to speak to his mother's brothers. He said to them and to her family's clan,"
    },
    {
      "verse": "2",
      "text": "‘Say this to the leaders of Shechem: “You should not agree to let all of Gideon's 70 sons rule over you. It would be better for you to have only one man rule over you. Remember that I belong to your own family. ” ’"
    },
    {
      "verse": "3",
      "text": "Abimelech's mother's family told the men of Shechem what Abimelech had said. They agreed that Abimelech would be a good ruler for them. They said, ‘He is our brother. ’"
    },
    {
      "verse": "4",
      "text": "pieces of silver from the temple of their god, Baal-Berith. Abimelech used this money to pay some wicked men to help him."
    },
    {
      "verse": "5",
      "text": "He went to his father's home in Ophrah. He killed his 70 brothers, the sons of Gideon. He killed them all on one rock. But Jotham, Gideon's youngest son, hid himself and he escaped."
    },
    {
      "verse": "6",
      "text": "Then the leaders of Shechem and Beth Millo met together. They took Abimelech to the oak tree near the pillar of rock in Shechem. There they made Abimelech king."
    },
    {
      "verse": "7",
      "text": "When Jotham heard the news of what had happened, he climbed to the top of Mount Gerizim. He stood there and he shouted to the people, ‘Leaders of Shechem, listen to me! Then perhaps God will listen to you."
    },
    {
      "verse": "8",
      "text": "One day, the trees decided to choose a king for themselves. They said to the olive tree, “Be our king. ”"
    },
    {
      "verse": "9",
      "text": "But the olive tree replied, “My oil pleases men and even the gods. I will not stop making my oil so that I can rule over all you other trees! ”"
    },
    {
      "verse": "10",
      "text": "Then the trees said to the fig tree, “Come and be our king. ”"
    },
    {
      "verse": "11",
      "text": "The fig tree replied, “I will not stop making my good, sweet figs so that I can rule over you. ”"
    },
    {
      "verse": "12",
      "text": "Then the trees said to the vine, “Come and be our king. ”"
    },
    {
      "verse": "13",
      "text": "But the vine answered, “Wine from my grapes makes gods and people happy. I will not stop making wine so that I can rule over you. ”"
    },
    {
      "verse": "14",
      "text": "Finally, the trees said to the thorn bush, “Come and be our king. ”"
    },
    {
      "verse": "15",
      "text": "The thorn bush said to the trees, “If you really want to choose me as your king, come here. Hide under my branches to keep safe. If not, I will cause fire to come out from the thorn bush. It will burn up all the big cedar trees in Lebanon! ”"
    },
    {
      "verse": "16",
      "text": "When you chose Abimelech to be your king, you have not been faithful to Gideon and his family. You have not given Gideon the honour that he deserves."
    },
    {
      "verse": "17",
      "text": "My father Gideon fought to save you. He did not try to keep his own life safe. He rescued you from the power of the Midianites."
    },
    {
      "verse": "18",
      "text": "But you have turned against my father's family today. You killed his 70 sons on one rock. You have made Abimelech king because he belongs to your family. He is the son of my father's slave wife."
    },
    {
      "verse": "19",
      "text": "If you have really been faithful to Gideon and his family today, I pray that Abimelech will make you happy! I pray that you will make Abimelech happy, too!"
    },
    {
      "verse": "20",
      "text": "But if you have not been faithful, I pray that Abimelech will destroy you! I pray that his fire will completely burn up the leaders of Shechem and Beth Millo. And I pray that fire from you leaders will completely destroy Abimelech! ’"
    },
    {
      "verse": "21",
      "text": "After he said that, Jotham ran away to Beer. He lived there because he was afraid of his brother, Abimelech."
    },
    {
      "verse": "22",
      "text": "Abimelech ruled Israel for three years."
    },
    {
      "verse": "23",
      "text": "Then God caused the leaders of Shechem to turn against Abimelech. They were no longer friends."
    },
    {
      "verse": "24",
      "text": "God did this to punish Abimelech because he had killed his brothers, Gideon's 70 sons. The leaders of Shechem were also guilty for their murder, because they had helped Abimelech."
    },
    {
      "verse": "25",
      "text": "The leaders of Shechem no longer obeyed Abimelech. They sent men to hide in the hills near Shechem. Those men robbed everyone who travelled on that road. But someone told Abimelech about this."
    },
    {
      "verse": "26",
      "text": "Ebed's son Gaal went to live in Shechem with his brothers. The leaders of Shechem started to trust Gaal as their leader."
    },
    {
      "verse": "27",
      "text": "They went out of the city to pick grapes in their fields. They squeezed the grapes to make wine. They went to the temple of their god and they had a party. They ate a lot of food and they drank a lot of wine. At their party, they cursed Abimelech."
    },
    {
      "verse": "28",
      "text": "Gaal said, ‘Why does Abimelech think he is so great? There is no reason why the people of Shechem should serve him! He is a son of Gideon and he does not really belong here. Zebul only serves Abimelech as his officer. Instead we should be faithful to Hamor's descendants. He is the ancestor of Shechem's clan."
    },
    {
      "verse": "29",
      "text": "If I were the leader of these people, I would remove Abimelech as king. I would say to him, “Make your army strong and try to fight against us! ” ’"
    },
    {
      "verse": "30",
      "text": "Some people told Zebul, the town's officer, what Gaal had said. Zebul was very angry when he heard this."
    },
    {
      "verse": "31",
      "text": "He sent men secretly to Abimelech with a message. They told him, ‘Ebed's son Gaal and his brothers have come to live in Shechem. They are causing the people of the city to turn against you."
    },
    {
      "verse": "32",
      "text": "So you must come here in the night with your men. Hide in the fields outside the city."
    },
    {
      "verse": "33",
      "text": "When the sun rises in the morning, quickly attack the city. When Gaal and his men come out to fight, you can do to them whatever you want. ’"
    },
    {
      "verse": "34",
      "text": "So Abimelech and all his soldiers came out at night. They hid in four groups outside Shechem."
    },
    {
      "verse": "35",
      "text": "The next morning, Gaal stood beside the city gate. Abimelech and his men came out from the places where they were hiding."
    },
    {
      "verse": "36",
      "text": "Gaal saw them. He said to Zebul, ‘Look! There are men coming down from the tops of the hills. ’ Zebul replied, ‘No, you are wrong. You can see shadows in the hills. They only look like men. ’"
    },
    {
      "verse": "37",
      "text": "Gaal said again, ‘Look! I can really see men who are coming down from the middle of the land. There is another group of men who are coming along the road from the Diviner's Oak Tree. ’"
    },
    {
      "verse": "38",
      "text": "Then Zebul said to Gaal, ‘What has happened to your proud words now? You boasted when you said, “Abimelech is nobody! We should not serve him. ” Here are the men that you insulted as useless! So now go out and fight them! ’"
    },
    {
      "verse": "39",
      "text": "Gaal led the men of Shechem out of the city to fight against Abimelech."
    },
    {
      "verse": "40",
      "text": "Abimelech chased after him. Gaal and his men ran back to the city. But Abimelech and his men caught and killed many of them before they reached the city gate."
    },
    {
      "verse": "41",
      "text": "Abimelech went back to live in Arumah. Zebul made Gaal and his brothers leave Shechem."
    },
    {
      "verse": "42",
      "text": "The next day, the people of Shechem went out into the fields around the city. Abimelech heard about this."
    },
    {
      "verse": "43",
      "text": "He took his men with him. He made them hide in three groups in the fields. When he saw the people coming out of the city, he and his men attacked them."
    },
    {
      "verse": "44",
      "text": "Abimelech and his group of soldiers ran to stand at the city gate. They stopped people going back into the city. The other two groups attacked the people in the fields and killed them."
    },
    {
      "verse": "45",
      "text": "Abimelech attacked the city all that day. He took the city and he killed all the people who lived there. Then he destroyed the city. He put salt all over it as a curse."
    },
    {
      "verse": "46",
      "text": "The city's leaders who lived in the tower of Shechem heard the news. They went to hide in the strong building of El-berith's temple."
    },
    {
      "verse": "47",
      "text": "Somebody told Abimelech that all the leaders were there together in the temple."
    },
    {
      "verse": "48",
      "text": "He took all his men up to Mount Zalmon. He used an axe to cut some branches off a tree. He put the branches on his shoulders. Then he said to his men, ‘Be quick! Do the same thing as you have seen me do! ’"
    },
    {
      "verse": "49",
      "text": "So all the men cut branches and they followed Abimelech. They put the branches around the strong building. Then they brought fire to burn down the building. There were about 1, 000 men and women in the tower of Shechem. They all died in the fire."
    },
    {
      "verse": "50",
      "text": "Then Abimelech and his men went to Thebez. They made their camp around the city to attack it."
    },
    {
      "verse": "51",
      "text": "There was a strong tower in the middle of the city. All the leaders of the city, as well as all the men and women, ran there to hide. They locked the door. They went up onto the roof of the tower."
    },
    {
      "verse": "52",
      "text": "Abimelech and his men came to attack the tower. Abimelech went near to the door of the tower, to put a fire there."
    },
    {
      "verse": "53",
      "text": "A woman on the roof dropped a heavy rock down on his head. It broke Abimelech's skull."
    },
    {
      "verse": "54",
      "text": "Abimelech quickly said to the young man who carried his weapons, ‘Take hold of your sword and kill me! I do not want people to say that a woman killed me! ’ So the young man killed him with his sword."
    },
    {
      "verse": "55",
      "text": "When the Israelites saw that Abimelech was dead, they went home."
    },
    {
      "verse": "56",
      "text": "That was how God punished Abimelech. He had done an evil thing against his father when he killed his 70 brothers."
    },
    {
      "verse": "57",
      "text": "God was also punishing the people of Shechem for the evil things that they had done. When Gideon's son Jotham had cursed them, he said that these things would happen."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "After Abimelech's death, another man became Israel's leader, to rescue them. He was Tola, the son of Puah and grandson of Dodo. He belonged to Issachar's tribe. He lived in Shamir, in the hill country of Ephraim."
    },
    {
      "verse": "2",
      "text": "years. Then he died and they buried him in Shamir."
    },
    {
      "verse": "3",
      "text": "After Tola, Jair of Gilead became Israel's leader. He led Israel for 22 years."
    },
    {
      "verse": "4",
      "text": "sons. They rode on 30 donkeys and they ruled 30 towns in Gilead. These towns are still called Havvoth-Jair (Jair's villages)."
    },
    {
      "verse": "5",
      "text": "Then Jair died and they buried him in Kamon."
    },
    {
      "verse": "6",
      "text": "The Israelites again did things that the Lord saw were evil. They worshipped idols of Baal and Ashtoreth. They also worshipped the gods of Syria, Sidon and Moab, as well as the gods of the Ammonites and the Philistines. They turned away from the Lord and they did not serve him any more."
    },
    {
      "verse": "7",
      "text": "The Lord became angry with the Israelites. He put them under the power of the Ammonites and the Philistines."
    },
    {
      "verse": "8",
      "text": "That year they attacked the Israelites who lived in the Gilead region, on the east side of the Jordan River. That was the land where the Amorites lived. They were cruel to the Israelites for 18 years."
    },
    {
      "verse": "9",
      "text": "Then the Ammonites went across the Jordan River to fight against the tribes of Judah, Benjamin and Ephraim. The Israelites were in a lot of trouble."
    },
    {
      "verse": "10",
      "text": "Then the Israelites called out to the Lord for help. They said, ‘We have turned against you. We have worshipped the idols of Baal instead of you. ’"
    },
    {
      "verse": "13",
      "text": "But now you have turned away from me and you worship other gods instead. So I will not rescue you again."
    },
    {
      "verse": "14",
      "text": "Go and ask those other gods to help you! They are the gods that you have chosen, so let them rescue you from your trouble! ’"
    },
    {
      "verse": "15",
      "text": "But the Israelites said to the Lord, ‘We are guilty. Punish us in whatever way you think is right, but please rescue us now. ’"
    },
    {
      "verse": "16",
      "text": "Then they threw away all the idols of foreign gods that they had been worshipping. They began to worship the Lord again. Finally, the Lord decided to help them, because he saw how upset they were."
    },
    {
      "verse": "17",
      "text": "The Ammonite army came to Gilead and they made their camp there. The Israelite army also came and they made their camp in Mizpah."
    },
    {
      "verse": "18",
      "text": "The leaders of the people of Gilead asked each other, ‘Who will lead us to attack the Ammonites? Any man who agrees to do that will become the leader of everyone who lives in Gilead. ’"
    },
    {
      "verse": "11",
      "text": "The Lord replied, ‘I have saved you many times when you called to me for help."
    },
    {
      "verse": "12",
      "text": "I saved you from the power of the Egyptians, the Amorites, the Ammonites, the Philistines, the Sidonians, the Amalekites and the Midianites."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "Jephthah of Gilead was a brave soldier. His father's name was Gilead, but his mother was a prostitute."
    },
    {
      "verse": "2",
      "text": "Gilead's wife also gave birth to sons for him. When they were older, they sent Jephthah away from the family home. They said to him, ‘You will not receive any of our father's things when he dies. You are the son of a prostitute, not our mother. ’"
    },
    {
      "verse": "3",
      "text": "So Jephthah ran away from his brothers. He went to live in the land of Tob. Other men joined the group that Jephthah led. They did not obey any laws."
    },
    {
      "verse": "4",
      "text": "Some time later, the Ammonite soldiers came to fight against Israel."
    },
    {
      "verse": "5",
      "text": "When the Ammonites attacked, the leaders of Gilead went to bring Jephthah from the land of Tob."
    },
    {
      "verse": "6",
      "text": "They said to him, ‘Come and lead our army to fight against the Ammonites. ’"
    },
    {
      "verse": "7",
      "text": "Jephthah said to them, ‘Before this, you hated me. You made me leave my father's house. So why do you come to me for help, now that you are in trouble? ’"
    },
    {
      "verse": "8",
      "text": "The leaders of Gilead replied, ‘But we really need you to help us. Please join us to fight against the Ammonites. Then we will make you the leader of everyone who lives in Gilead. ’"
    },
    {
      "verse": "9",
      "text": "Jephthah said to them, ‘So, you are saying that I should come back home to fight with you against the Ammonites. You are saying that if the Lord gives them to me, I will be your leader. Is that really true? ’"
    },
    {
      "verse": "10",
      "text": "The leaders of Gilead said, ‘We promise to do that. The Lord will judge between us if we do not do what you have said. ’"
    },
    {
      "verse": "11",
      "text": "So Jephthah went back with them to Gilead. The people made him their ruler and leader of their army. In Mizpah, Jephthah repeated his promise to the Lord."
    },
    {
      "verse": "12",
      "text": "Jephthah sent men with a message to the Ammonite king. He asked, ‘Why have you come to fight against our people? What have we done to make you angry? ’"
    },
    {
      "verse": "13",
      "text": "The Ammonite king answered Jephthah's men, ‘You Israelites came here from Egypt and you took our land on the east side of the Jordan River. You have taken for yourselves all our land from the Arnon river in the south to the Jabbok river in the north. You have taken it all, as far as the Jordan River in the west. Now give it back to us, so that we do not need to fight for it. ’"
    },
    {
      "verse": "14",
      "text": "Jephthah sent the men back to the Ammonite king."
    },
    {
      "verse": "15",
      "text": "They said to him, ‘This is what Jephthah says: “Israel did not take for themselves the land of Moab, or the land of the Ammonites."
    },
    {
      "verse": "16",
      "text": "When the Israelites left Egypt, they went through the desert as far as the Red Sea. Then they travelled to Kadesh."
    },
    {
      "verse": "17",
      "text": "Then they sent a message to the king of Edom. They asked him, ‘Please let us travel through your land. ’ But the king of Edom refused to let them do that. The Israelites sent the same message to the king of Moab. He also refused to agree. So the Israelites stayed at Kadesh."
    },
    {
      "verse": "18",
      "text": "Next, the Israelites went through the desert, around the edge of Edom and Moab. They arrived on the east side of Moab's land. They put up their tents on the other side of the Arnon river, which was the border of Moab's land. They did not go into Moab."
    },
    {
      "verse": "19",
      "text": "Sihon was the Amorite king who ruled in Heshbon. The Israelites sent a message to him. They asked him, ‘Please let us travel through your land to our own place. ’"
    },
    {
      "verse": "20",
      "text": "But King Sihon did not trust the Israelites. He would not let them travel through his land. He brought his whole army to meet together at Jahaz. Then he fought against the Israelites."
    },
    {
      "verse": "21",
      "text": "The Lord, Israel's God, put Sihon and his whole army under the power of the Israelites. The Israelites won the fight against the Amorites. They took the Amorites' land for themselves."
    },
    {
      "verse": "22",
      "text": "The land went from the Arnon river in the south to the Jabbok river in the north. It went from the desert in the east to the Jordan River in the west."
    },
    {
      "verse": "23",
      "text": "You should realize that the Lord, Israel's God, chased out the Amorites. He has done that so that his own people, the Israelites, can live there. So why do you think that you can take it from them?"
    },
    {
      "verse": "24",
      "text": "You may take the land that your god Chemosh gives to you. We will live in the land that the Lord our God has given to us."
    },
    {
      "verse": "25",
      "text": "Do you think that you are better than Zippor's son Balak, king of Moab? He was not brave enough to argue with the Israelites or to fight against them."
    },
    {
      "verse": "26",
      "text": "years! They have lived in Heshbon and Aroer and the villages around those towns. They have lived in all the towns along the Arnon river too. In all that time, you have not tried to take back those places for yourselves."
    },
    {
      "verse": "27",
      "text": "I have not done anything to hurt you. You are the one who is doing something wrong if you attack us. The Lord himself is the judge! He will decide whether the Israelites or the Ammonites are doing what is right. ” ’"
    },
    {
      "verse": "28",
      "text": "The Ammonite king refused to listen to the message that Jephthah had sent to him."
    },
    {
      "verse": "29",
      "text": "Then the Lord's Spirit took hold of Jephthah. Jephthah travelled through the land of Gilead and of Manasseh. He arrived at Mizpah in Gilead and he prepared to fight against the Ammonites."
    },
    {
      "verse": "30",
      "text": "Jephthah promised the Lord, ‘Please let us win the battle against the Ammonites."
    },
    {
      "verse": "31",
      "text": "Then, when I return home safely, I will give you a burnt offering. Whatever is first to come out through the door of my house as I arrive, I will offer it to you as a sacrifice. ’"
    },
    {
      "verse": "32",
      "text": "Then Jephthah went to attack the Ammonites. The Lord put them under his power."
    },
    {
      "verse": "33",
      "text": "Jephthah destroyed them all the way from Aroer to Minnith. He took 20 Ammonite cities, as far as Abel Karamim. He completely destroyed them! So the Israelites had complete power over the Ammonites."
    },
    {
      "verse": "34",
      "text": "After that, Jephthah returned to his home in Mizpah. As he arrived, his daughter came out to meet him. She was dancing and making music with a tambourine. She was Jephthah's only child. He had no other son or daughter."
    },
    {
      "verse": "35",
      "text": "When Jephthah saw her, he was so upset that he tore his clothes. He said, ‘Oh no! My daughter! You have made me very sad. I made a serious promise to the Lord and I must do what I promised. ’"
    },
    {
      "verse": "36",
      "text": "She said to her father, ‘You have made a promise to the Lord. You must do to me what you told him you would do. The Lord gave you the power to punish your enemies, the Ammonites. So you must do what you promised him."
    },
    {
      "verse": "37",
      "text": "But please allow me to do this one thing. Let me walk in the hills with my friends for two months. I need time to be sad because I will die before I can marry a man. ’"
    },
    {
      "verse": "38",
      "text": "Jephthah said, ‘You may go. ’ He sent her away from home for two months. She and her friends walked in the hills. They wept together because she would never marry."
    },
    {
      "verse": "39",
      "text": "After two months she returned to her father, Jephthah. He did what he had promised to the Lord. His daughter never married."
    },
    {
      "verse": "40",
      "text": "Because of that, the young women of Israel now go into the hills for four days every year. They do that to remember the daughter of Jephthah, the man from Gilead."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "The men of Ephraim's tribe joined together to make an army. They crossed over the Jordan River to Zaphon. They said to Jephthah, ‘Why did you go to fight against the Ammonites without us? You should have asked us to go with you. Now we will burn down your house with you inside it! ’"
    },
    {
      "verse": "2",
      "text": "Jephthah replied, ‘I did ask for your help! That was when my people and I first had a quarrel with the Ammonites. But you refused to rescue us."
    },
    {
      "verse": "3",
      "text": "When I realized that you would not come to help us, we attacked the Ammonites ourselves. I put my life in danger. But the Lord put the Ammonites under my power. So why have you come to attack me now? ’"
    },
    {
      "verse": "4",
      "text": "Jephthah brought together all the men of Gilead. They fought against the men of Ephraim's tribe. The men of Gilead won the fight. They were angry because the men of Ephraim had insulted them. They had said, ‘You people of Gilead have run away to live on the land of Ephraim and Manasseh. ’"
    },
    {
      "verse": "5",
      "text": "After that, Gilead's army put guards at the places where people could go across the Jordan River. They wanted to stop people from Ephraim going across the river. If one of Ephraim's soldiers was trying to escape, they would ask him, ‘Do you belong to Ephraim's tribe? ’ The man would say, ‘No, I do not! ’"
    },
    {
      "verse": "6",
      "text": "Then they would tell him, ‘Say, “Shibboleth! ” ’ People from Ephraim could not say that word properly. So if the man said, ‘Sibboleth, ’ they would take hold of him and kill him. That day, they killed 42, 000 soldiers of Ephraim at those places on the Jordan River."
    },
    {
      "verse": "7",
      "text": "Jephthah led Israel for six years. Then he died and they buried him in his own town in Gilead."
    },
    {
      "verse": "8",
      "text": "After Jephthah died, Ibzan of Bethlehem led Israel."
    },
    {
      "verse": "9",
      "text": "sons and 30 daughters. He let his daughters marry men from other clans. He also brought 30 young women from other clans to marry his sons. Ibzan led Israel for seven years."
    },
    {
      "verse": "10",
      "text": "Then he died and they buried him in Bethlehem."
    },
    {
      "verse": "11",
      "text": "After he died, Elon from Zebulun led Israel for ten years."
    },
    {
      "verse": "12",
      "text": "Then Elon died and they buried him in Aijalon, a town in the land of Zebulun's tribe."
    },
    {
      "verse": "13",
      "text": "After Elon, Hillel's son Abdon led Israel. He came from Pirathon."
    },
    {
      "verse": "14",
      "text": "sons and 30 grandsons. They rode on 70 donkeys. Abdon led Israel for eight years."
    },
    {
      "verse": "15",
      "text": "Then he died. They buried him at Pirathon, a town in the land of Ephraim's tribe. That was in the hill country of the Amalekites."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "The Israelites again did things that the Lord saw were evil. So he put them under the power of the Philistines for 40 years."
    },
    {
      "verse": "2",
      "text": "There was a man who belonged to Dan's tribe. His name was Manoah and he lived in Zorah. His wife had no children and she could not give birth."
    },
    {
      "verse": "3",
      "text": "The Lord's angel appeared to her. He said, ‘You have not been able to give birth to any children until now. But you will become pregnant and you will give birth to a son."
    },
    {
      "verse": "4",
      "text": "You must not drink any wine or any beer. You must not eat any food that is unclean."
    },
    {
      "verse": "5",
      "text": "Yes, you will give birth to a son. You must never cut the boy's hair. He is to be a Nazirite. He will belong to God from the time that he is born. He will begin to rescue the Israelites from the power of the Philistines. ’"
    },
    {
      "verse": "6",
      "text": "The woman went quickly to tell her husband. She said, ‘A man of God came to me. He looked like an angel that God had sent with a message. I was afraid of him. I did not ask where he came from. He did not tell me his name."
    },
    {
      "verse": "7",
      "text": "He said to me, “You will become pregnant and you will give birth to a son. You must not drink any wine or beer. You must not eat any food that is unclean. The boy will belong to me as a Nazirite from his birth until the day that he dies! ” ’"
    },
    {
      "verse": "8",
      "text": "Manoah prayed to the Lord, ‘Lord, please send the man of God to come to us again. Let him teach us how we should take care of this boy who will be born. ’"
    },
    {
      "verse": "9",
      "text": "God did what Manoah had asked. The angel came again to visit Manoah's wife. She was resting in the fields and her husband was not with her."
    },
    {
      "verse": "10",
      "text": "She ran to tell her husband, ‘Come quickly! The man who came to me the other day has appeared to me again! ’"
    },
    {
      "verse": "11",
      "text": "Manoah got up and he followed his wife. When he met the man, he asked him, ‘Are you the man who talked to my wife? ’ The man said, ‘Yes, I am. ’"
    },
    {
      "verse": "12",
      "text": "Then Manoah asked him, ‘When what you promised happens, how should the boy live? What kind of work will he do? ’"
    },
    {
      "verse": "13",
      "text": "The Lord's angel answered, ‘Your wife must be careful to do everything that I told her."
    },
    {
      "verse": "14",
      "text": "She must not eat anything that comes from vines. She must not drink wine or beer. She must not eat any food that is unclean. She must obey everything that I have commanded her to do. ’"
    },
    {
      "verse": "15",
      "text": "Manoah said to the Lord's angel, ‘Please stay here with us. We would like to cook a young goat for you to eat. ’"
    },
    {
      "verse": "16",
      "text": "The angel replied, ‘Even if I stay with you, I will not eat your food. But you may prepare a burnt offering as a sacrifice to the Lord. ’ The angel said that because Manoah had not realized that he was the Lord's angel."
    },
    {
      "verse": "17",
      "text": "Then Manoah asked the Lord's angel, ‘What is your name? When what you have promised happens, we will want to give you honour. ’"
    },
    {
      "verse": "18",
      "text": "The angel replied, ‘You should not ask what my name is. It is too great for you to understand. ’"
    },
    {
      "verse": "19",
      "text": "Then Manoah took a young goat and a grain offering. He offered them on a rock as a sacrifice to the Lord. While Manoah and his wife watched, the Lord surprised them with a miracle."
    },
    {
      "verse": "20",
      "text": "As the flames of fire rose up from the sacrifice to the sky, the Lord's angel went up in the flames. When Manoah and his wife saw this, they fell down with their faces towards the ground."
    },
    {
      "verse": "21",
      "text": "The Lord's angel did not appear to them again. Manoah then realized that their visitor was the Lord's own angel."
    },
    {
      "verse": "22",
      "text": "He said to his wife, ‘We are sure to die! We have seen God! ’"
    },
    {
      "verse": "23",
      "text": "But his wife said to him, ‘The Lord accepted our burnt offering and our grain offering. He would not have done that if he wanted to kill us. He would not have shown us all these great things. He would not have told us about what will happen to us. ’"
    },
    {
      "verse": "24",
      "text": "Manoah's wife gave birth to a son. She gave him the name ‘Samson’. The child grew to become a man, and the Lord blessed him."
    },
    {
      "verse": "25",
      "text": "The Lord's Spirit began to give Samson strength when he was living in Mahaneh Dan. That place was between Zorah and Eshtaol."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "One day Samson went to Timnah. Samson saw a young Philistine woman."
    },
    {
      "verse": "2",
      "text": "When he returned home, he said to his father and mother, ‘I have seen a young Philistine woman in Timnah and I want to marry her. Please get her for me as my wife. ’"
    },
    {
      "verse": "3",
      "text": "His parents replied, ‘You do not need to go to the Philistines to get a wife. They are not the Lord's people. There is surely someone among our own relatives or other Israelites that you would like to marry. ’ But Samson said to his father, ‘You must get her for me. She is the right girl for me to marry. ’"
    },
    {
      "verse": "4",
      "text": "Samson's parents did not realize that the Lord was causing this to happen. The Lord wanted to prepare a way for the Israelites to attack the Philistines, because the Philistines were ruling over Israel at that time."
    },
    {
      "verse": "5",
      "text": "Samson went to Timnah, and his parents went too. When he reached some vineyards near Timnah, an angry young lion ran out to attack him."
    },
    {
      "verse": "6",
      "text": "The Lord's Spirit gave Samson great strength. He tore the lion into pieces with his hands. He made it seem very easy, as if he was killing a goat. But he did not tell his father or his mother what he had done."
    },
    {
      "verse": "7",
      "text": "Then Samson continued on his journey to Timnah. He spoke with the young woman, and she pleased him very much."
    },
    {
      "verse": "8",
      "text": "Some time later, Samson returned to Timnah to marry the young woman. He turned off the path to look at the lion's body. Inside it, there was a crowd of bees and some honey."
    },
    {
      "verse": "9",
      "text": "He took the honey out with his hands. He ate it as he walked along. Then he went to his parents. He gave some of the honey to them and they ate it. But he did not tell them that he had taken it from the body of the dead lion."
    },
    {
      "verse": "10",
      "text": "Then Samson's father went to Timnah for Samson's marriage. Samson prepared a party for the people there. All the young men did this when they married."
    },
    {
      "verse": "11",
      "text": "When the Philistines saw what Samson was doing, they sent 30 young men to be his friends."
    },
    {
      "verse": "12",
      "text": "Samson said to them, ‘Listen to this clever question. Try to give me an answer before my party finishes in seven days. If you answer the question, I will give you 30 linen shirts and 30 sets of clothes."
    },
    {
      "verse": "13",
      "text": "But if you cannot tell me the answer, you will give me 30 linen shirts and 30 sets of clothes. ’ The young men said, ‘Tell us your question. ’"
    },
    {
      "verse": "14",
      "text": "Samson said to them:‘Out of the one who eats came something to eat. Out of the strong one came something sweet. ’After three days, the Philistine men could not find the answer. ‘Out of the one who eats came something to eat. Out of the strong one came something sweet. ’ After three days, the Philistine men could not find the answer."
    },
    {
      "verse": "15",
      "text": "On the fourth day they said to Samson's wife, ‘Find a way to make your husband tell you the answer. If you do not, we will use fire to destroy your father's house, with you inside it! Did you ask us to come to your marriage party to make us poor? ’"
    },
    {
      "verse": "16",
      "text": "Then Samson's wife went to him and she wept. She said to him, ‘It seems that you hate me. You do not really love me. You have asked my friends a clever question, but you have not told me the answer. ’Samson said to her, ‘I have not told the answer even to my father or mother. So why should I tell you? ’ Samson said to her, ‘I have not told the answer even to my father or mother. So why should I tell you? ’"
    },
    {
      "verse": "17",
      "text": "Samson's wife continued to weep like that all the days of the party. Finally, she gave him so much trouble that he told her the answer on the seventh day. Then she told the young men the answer to Samson's question."
    },
    {
      "verse": "18",
      "text": "Before sunset on the seventh day, the men of the town gave their answer to Samson:‘There is nothing sweeter than honey! There is nothing stronger than a lion! ’Samson said to them, ‘You have used my young cow to do your work! Without her you would not have found the answer to my question. ’ ‘There is nothing sweeter than honey! There is nothing stronger than a lion! ’ Samson said to them, ‘You have used my young cow to do your work! Without her you would not have found the answer to my question. ’"
    },
    {
      "verse": "19",
      "text": "The Lord's Spirit took hold of Samson. He went to Ashkelon and he killed 30 Philistine men there. He took all their clothes and he gave them to the 30 men who had answered his question. He was still very angry as he went back to his family's home."
    },
    {
      "verse": "20",
      "text": "Samson's wife became the wife of the man who had been his special friend at the party."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "Later, Samson went to visit his wife at the time of the wheat harvest. He took a young goat with him as a gift. He said to her father, ‘I am going into my wife's room to sleep with her. ’ But her father stopped him."
    },
    {
      "verse": "2",
      "text": "He said, ‘I was sure that you hated my daughter. So I have given her to your special friend to be his wife. Look at her younger sister. She is more beautiful. Take her as your wife, instead. ’"
    },
    {
      "verse": "3",
      "text": "Samson said, ‘This time I will not be guilty when I punish the Philistines! ’"
    },
    {
      "verse": "4",
      "text": "foxes. He tied the foxes in pairs by their tails. He tied some dry grass to each pair of tails."
    },
    {
      "verse": "5",
      "text": "Then he lit the grass with fire. He made the foxes run through the fields where the wheat was growing. The fire destroyed all the Philistines' crops, whether they had already cut it down or not. The fire also destroyed their vines and their olive trees."
    },
    {
      "verse": "6",
      "text": "The Philistines asked, ‘Who did this? ’ People said to them, ‘It was Samson, the man who married the young woman in Timnah. He did it because her father gave her to Samson's special friend instead of Samson. ’So the Philistines went and burned the man and his daughter to death."
    },
    {
      "verse": "7",
      "text": "Samson said to them, ‘Because you have done this, I will punish you. I will not stop until your punishment is complete. ’ After that, Samson went to live in a cave in the rock of Etam."
    },
    {
      "verse": "8",
      "text": "He attacked them with great strength. He killed many of them. After that, Samson went to live in a cave in the rock of Etam."
    },
    {
      "verse": "9",
      "text": "The Philistine army went to attack Judah. They made their camp near Lehi and they prepared to fight."
    },
    {
      "verse": "10",
      "text": "The men of Judah asked them, ‘Why have you come to attack us? ’ The Philistines replied, ‘We have come to catch Samson and take him as our prisoner. We need to punish him in the same way that he has punished us. ’"
    },
    {
      "verse": "11",
      "text": "Then 3, 000 men of Judah went to the cave where Samson was hiding. They said to him, ‘You know that the Philistines are our rulers. You are causing them to give us trouble. ’Samson said, ‘I have only done to them as they did to me. ’ Samson said, ‘I have only done to them as they did to me. ’"
    },
    {
      "verse": "12",
      "text": "The men of Judah said to him, ‘We have come to tie you up as our prisoner. We must let the Philistines take you away. ’Samson said, ‘Promise me that you will not kill me yourselves. ’ Samson said, ‘Promise me that you will not kill me yourselves. ’"
    },
    {
      "verse": "13",
      "text": "They said, ‘We agree. We will only tie you up and give you to them. We promise that we will not kill you. ’So they tied him up with two new ropes. They took him with them away from the cave. So they tied him up with two new ropes. They took him with them away from the cave."
    },
    {
      "verse": "14",
      "text": "When they arrived at Lehi, the Philistine soldiers shouted happily as they came towards him. But the Lord's Spirit gave Samson great strength. The ropes that tied his arms broke in pieces. They seemed as weak as grass that burns in a fire. They fell from his hands."
    },
    {
      "verse": "15",
      "text": "He saw a bone from the skull of a donkey that had just died. He picked it up and he used it to kill 1, 000 Philistine soldiers."
    },
    {
      "verse": "16",
      "text": "Then Samson sang this song:‘I have used a donkey's skull to kill 1, 000 men. I have made them like many heaps of dead donkeys! ’ ‘I have used a donkey's skull to kill 1, 000 men. I have made them like many heaps of dead donkeys! ’"
    },
    {
      "verse": "17",
      "text": "After that, he threw away the bone from the donkey's skull. So people called that place ‘Ramath Lehi’."
    },
    {
      "verse": "18",
      "text": "Samson was now very thirsty. He called out to the Lord for help. He said, ‘You have helped me to win a great battle. Should I now die because I am so thirsty? Then these Philistines would do whatever they want to me. ’"
    },
    {
      "verse": "19",
      "text": "So God caused a hole to open in the ground near Lehi. Water poured out of it. Samson drank some water and he became strong again. Samson called the spring of water ‘En Hakkore’. It is still there in Lehi."
    },
    {
      "verse": "20",
      "text": "years while the Philistines continued to rule the land."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "One day, Samson went to Gaza. He met a prostitute there and he slept with her."
    },
    {
      "verse": "2",
      "text": "The people of Gaza heard that Samson was in their city. The men met together and they waited for Samson to leave. They hid themselves all night at the gate of the city. They waited there quietly and they thought, ‘We will kill him at dawn when he tries to leave the city. ’"
    },
    {
      "verse": "3",
      "text": "But Samson only stayed with the woman until the middle of the night. Then he got up and he went to leave through the city gate. He took hold of its doors and the two posts that held them. He pulled them all down together, with the metal bar that locked them. He carried them all in one piece on his shoulders. He left them at the top of the hill near Hebron."
    },
    {
      "verse": "4",
      "text": "Some time later, Samson met a woman who was called Delilah. She lived in Sorek valley. Samson loved her."
    },
    {
      "verse": "5",
      "text": "The rulers of the Philistines went to visit Delilah. They said to her, ‘Do something clever to discover what makes Samson so strong. We want to find a way to take hold of him and tie him up. If you do that, we will each give you 1, 100 pieces of silver. ’"
    },
    {
      "verse": "6",
      "text": "So Delilah said to Samson, ‘Please tell me what makes you so strong. How could someone tie you up so that you become helpless? ’"
    },
    {
      "verse": "7",
      "text": "Samson replied, ‘Someone would have to use seven new strings for bows. The strings must not have become dry. If they use those strings to tie me up, I will become weak, like other men. ’"
    },
    {
      "verse": "8",
      "text": "So the Philistine rulers gave Delilah seven new strings for bows. She used them to tie Samson up while he was asleep."
    },
    {
      "verse": "9",
      "text": "Some Philistine men hid in a room of her house. Then she shouted, ‘Samson, the Philistines are here! ’ But he broke the seven strings very easily. They were like thin cotton that a fire burns. So they did not discover the secret about his strength."
    },
    {
      "verse": "10",
      "text": "Delilah said to Samson, ‘You have deceived me as if I was a fool! Tell me the truth! How can someone really make you weak? ’"
    },
    {
      "verse": "11",
      "text": "Samson said to her, ‘They would have to use new ropes that no one has used. If they tie me up with those, I will become weak, like other men. ’"
    },
    {
      "verse": "12",
      "text": "So Delilah took some new ropes and she tied Samson up with them. Some Philistine men were hiding in the room, as they did before. Then she shouted, ‘Samson, the Philistines are here! ’ But he broke the ropes off his arms, as if they were thin string."
    },
    {
      "verse": "13",
      "text": "Then Delilah said to Samson, ‘You have deceived me again as if I was a fool. Now you must tell me the truth. Tell me how someone can make you weak. ’Samson replied, ‘You see that my long hair is tied in seven tails. You must tie them into the cloth that is on the loom. Fix them there very strongly. If you do that, I will become weak, like other men. ’"
    },
    {
      "verse": "14",
      "text": "Delilah did this while Samson was asleep. She took the seven tails of his hair and she tied them into the cloth on the loom. She fixed them with a strong peg. Then she shouted, ‘Samson, the Philistines are here! ’ He woke up and he pulled out the peg. He tore his hair away from the cloth on the loom so that he was free."
    },
    {
      "verse": "15",
      "text": "Then Delilah said to him, ‘I realize that you do not really love me, because you will not tell me your secret. You have deceived me three times, as if I was a fool. You have refused to tell me what makes you so strong. ’"
    },
    {
      "verse": "16",
      "text": "She continued to say the same thing to Samson many times. Her words made Samson very upset. He felt that he wanted to die."
    },
    {
      "verse": "17",
      "text": "Finally, Samson told her his secret. He said to her, ‘No one has ever cut my hair. Even before I was born, I belonged to God as a Nazirite. If someone cuts off my hair, I would have no more strength. I would become as weak as any other man. ’"
    },
    {
      "verse": "18",
      "text": "Delilah realized that Samson had told her the truth. So she sent a message to the rulers of the Philistines. She told them, ‘Samson has now told me his secret. So come back once more. ’ So the Philistine rulers went to visit Delilah again. They took their pieces of silver with them."
    },
    {
      "verse": "19",
      "text": "Delilah made Samson sleep with his head on her knees. She called a man to come and he cut off the seven tails of Samson's hair. This made Samson helpless, so that he had no more strength."
    },
    {
      "verse": "20",
      "text": "Then Delilah shouted, ‘Samson, the Philistines are here! ’ He woke up and he thought, ‘I will make myself free as I have always done before. ’ But he did not realize that the Lord had gone away from him."
    },
    {
      "verse": "21",
      "text": "The Philistines took hold of Samson. They cut out his eyes. They tied him up with bronze chains. They made him do hard work as their prisoner. He had to push a heavy stone to make grain into flour."
    },
    {
      "verse": "22",
      "text": "But after they had cut off Samson's hair, it began to grow again."
    },
    {
      "verse": "23",
      "text": "One day, the rulers of the Philistines met together to have a big feast. They offered a great sacrifice to their god, Dagon. They said, ‘Dagon has put our enemy, Samson, under our power. ’"
    },
    {
      "verse": "24",
      "text": "When the people saw what had happened to Samson, they praised their god. They said, ‘Our god has let us catch our enemy. He was the enemy who destroyed our land and who killed many of us. ’"
    },
    {
      "verse": "25",
      "text": "The people were very happy at the feast. They shouted, ‘Bring Samson here for us to see him! He can help us to enjoy our party. ’So they brought Samson out of the prison. The people were happy to see him. They made him stand between the pillars of the temple."
    },
    {
      "verse": "26",
      "text": "A young man held Samson's hand to lead him. Samson said to him, ‘Put me where I can touch the pillars which hold up the temple's roof. I want to rest my body on them. ’"
    },
    {
      "verse": "27",
      "text": "The temple was full of men and women, as well as all the Philistine rulers. About 3, 000 people were on the roof as they watched Samson. They were laughing at him."
    },
    {
      "verse": "28",
      "text": "Samson prayed to the Lord, ‘Remember me, Almighty Lord. Please make me strong again one more time. I want to punish the Philistines because they cut out my two eyes. ’"
    },
    {
      "verse": "29",
      "text": "Then Samson put his hands on the two pillars in the centre of the building. He put his right hand on one pillar and his left hand on the other pillar. He got ready to push."
    },
    {
      "verse": "30",
      "text": "Samson shouted out, ‘Let me die with the Philistines! ’ Then he pushed the pillars with all his strength. The temple fell down on the rulers and all the other people in it. In that way, Samson killed more people as he died than he had killed while he lived."
    },
    {
      "verse": "31",
      "text": "Then his brothers and all his father's family came to get his body. They carried it back home. They buried him in the grave of his father, Manoah. That was between Zorah and Eshtaol. Samson had led Israel for 20 years."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "There was a man who lived in the hill country of Ephraim. His name was Micah. His mother said, ‘Thank you, my son. I pray that the Lord will bless you. ’"
    },
    {
      "verse": "2",
      "text": "He said to his mother, ‘I know about the 1, 100 pieces of silver that somebody took from you. You cursed the person who had robbed you and I heard you. Look! Here are the pieces of silver. I took them myself. But now I am giving them back to you. ’His mother said, ‘Thank you, my son. I pray that the Lord will bless you. ’"
    },
    {
      "verse": "3",
      "text": "When Micah gave the 1, 100 pieces of silver back to his mother, she said, ‘I will now give this silver to the Lord. We will use it to make an image and a metal idol. In that way, I will give it back to you, my son. ’"
    },
    {
      "verse": "4",
      "text": "So Micah's mother took 200 pieces of silver. She gave them to a man who used silver to make things. He made an image and an idol for her. She put them in Micah's house."
    },
    {
      "verse": "5",
      "text": "Micah had a special room to worship his gods. He made an ephod and some more idols for it. He chose one of his sons to be a priest to serve his gods."
    },
    {
      "verse": "6",
      "text": "At that time, Israel had no king to rule over them. Everyone did what they thought was right."
    },
    {
      "verse": "7",
      "text": "There was a young man who lived in Bethlehem, a town in Judah. He was a Levite."
    },
    {
      "verse": "8",
      "text": "He left Bethlehem to look for another place to live. As he travelled in the hill country of Ephraim, he arrived at Micah's house."
    },
    {
      "verse": "9",
      "text": "Micah asked him, ‘Where have you come from? ’ The man replied, ‘I am a Levite who was living in Bethlehem in Judah. Now I am looking for a new place to live. ’"
    },
    {
      "verse": "10",
      "text": "Micah said, ‘Stay here with me. You will be my advisor and my priest. I will pay you ten pieces of silver each year, as well as your clothes and food. ’"
    },
    {
      "verse": "11",
      "text": "So the Levite agreed to stay with Micah. He became like a son for Micah."
    },
    {
      "verse": "12",
      "text": "Micah gave the young man what he needed. The Levite became Micah's priest and he lived in Micah's home."
    },
    {
      "verse": "13",
      "text": "Then Micah said, ‘Now I know that the Lord will bless me, because I have this Levite as my own priest. ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "At that time, Israel had no king to rule over them. The people of Dan's tribe were looking for some land where they could live. They had not yet taken the land that would be their home among Israel's tribes."
    },
    {
      "verse": "2",
      "text": "So the men of Dan sent five soldiers from the clans of their tribe to explore the land. The leaders sent them out from Zorah and Eshtaol. They told them, ‘Go and find some land for us. ’The five men went into the hill country of Ephraim. They came to Micah's house and they stayed there for a night."
    },
    {
      "verse": "3",
      "text": "While they were at Micah's house, they recognized the voice of the young Levite. So they went in and they asked him, ‘Who brought you here? What are you doing in this place? Why are you here? ’"
    },
    {
      "verse": "4",
      "text": "He told them what Micah had done for him. He said, ‘He pays me to work for him as his priest. ’"
    },
    {
      "verse": "5",
      "text": "So they said to him, ‘Please ask God if our journey will have a good result. ’"
    },
    {
      "verse": "6",
      "text": "Micah's priest answered, ‘Yes, do not worry. The Lord will be with you on your journey. ’"
    },
    {
      "verse": "7",
      "text": "So the five men continued on their journey. They arrived at Laish. They saw that it was a safe place to live. The people of Laish were not afraid of any trouble. They lived in peace, like the Sidonians do. Their land gave them everything that they needed, so they were rich. They lived a long way from the Sidonians, and there were no other people who would help them."
    },
    {
      "verse": "8",
      "text": "The five men of Dan's tribe returned to Zorah and Eshtaol. Their relatives asked them, ‘What did you find? ’"
    },
    {
      "verse": "9",
      "text": "They answered, ‘We should go now and attack them! We saw their land, and it is very good. Do not sit there and wait! Go quickly and take the land for yourselves."
    },
    {
      "verse": "10",
      "text": "When you attack, you will see that the people there think that they are safe. Their land is very big and it has everything that we need. God will surely give it to you. ’"
    },
    {
      "verse": "11",
      "text": "men of Dan's tribe prepared for the fight. They marched out from Zorah and Eshtaol with their weapons."
    },
    {
      "verse": "12",
      "text": "On their way, they made their camp at Kiriath-Jearim in Judah. That place on the west side of Kiriath-Jearim is still called Mahaneh Dan."
    },
    {
      "verse": "13",
      "text": "From there they travelled through the hill country of Ephraim. They arrived at Micah's house."
    },
    {
      "verse": "14",
      "text": "The five men who had explored the land of Laish said to their relatives, ‘Do you know that in one of these houses there is an ephod, some small idols, an image and a metal idol. Think carefully and decide what to do. ’"
    },
    {
      "verse": "15",
      "text": "So they went into Micah's house, where the young Levite was living. They said ‘hello’ to him."
    },
    {
      "verse": "16",
      "text": "men of Dan stood at the gate with their weapons."
    },
    {
      "verse": "17",
      "text": "The five men who had explored the land went inside. They took all the idols, the image and the priest's ephod. While they did that, the Levite priest was standing at the gate with the 600 soldiers."
    },
    {
      "verse": "18",
      "text": "When the priest saw that the five men were taking the things from the house, he asked them, ‘What are you doing? ’"
    },
    {
      "verse": "19",
      "text": "They said to him, ‘Be quiet! Do not say a word. Come with us. You will be our advisor and our priest. That will be much better for you. You will serve a whole Israelite tribe, instead of only one man's family. ’"
    },
    {
      "verse": "20",
      "text": "So the priest was happy. He joined the group of men from Dan's tribe. He took the ephod, the idols and the image with him."
    },
    {
      "verse": "21",
      "text": "They left Micah's house to continue their journey. They followed after their children, their animals and all their other things."
    },
    {
      "verse": "22",
      "text": "After they had travelled some way, Micah realized what had happened. He brought together his neighbours and they chased after the men of Dan. When they reached them,"
    },
    {
      "verse": "23",
      "text": "they shouted to them. The men of Dan turned around and they said to Micah, ‘What is the problem? Why have you brought all these men? ’"
    },
    {
      "verse": "24",
      "text": "Micah replied, ‘You have taken away the gods that I made. You have also taken my priest. Now I have nothing left. You should not ask me, “What is the problem? ” ’"
    },
    {
      "verse": "25",
      "text": "The men of Dan said to Micah, ‘Do not argue with us! If you say any more, some of our men may become very angry. They might attack you. You and your family might all die! ’"
    },
    {
      "verse": "26",
      "text": "Then the men of Dan continued on their journey. Micah realized that they were too strong for him. So he turned around and he went home."
    },
    {
      "verse": "27",
      "text": "The men of Dan took the idols that Micah had made, as well as his priest. Then they arrived at Laish. The people who lived there were not expecting any trouble. The soldiers of Dan attacked the people with their weapons and they killed them. They destroyed the city with fire."
    },
    {
      "verse": "28",
      "text": "No one came to rescue the people of Laish. The city was a long way from Sidon. They had no other friends to help them. Laish was in a valley near Beth Rehob. The Danites built the city again and they lived there."
    },
    {
      "verse": "29",
      "text": "They called the city Dan, because that was the name of their ancestor. He had been one of Israel's 12 sons. Before that, the city's name was Laish."
    },
    {
      "verse": "30",
      "text": "The people of Dan worshipped Micah's idol. Jonathan served as priest for the tribe of Dan. He was a descendant of Moses' son, Gershom. He and his descendants served there as priests until Israel's enemies took them away into exile."
    },
    {
      "verse": "31",
      "text": "They continued to worship Micah's idol in Dan all the time that God's special tent was in Shiloh."
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "At that time, Israel had no king to rule over them. There was a Levite who was living in the hill country of Ephraim, far away from any towns. He took a woman from Bethlehem in Judah to be his slave wife."
    },
    {
      "verse": "2",
      "text": "But she became angry with him. She left him and she returned to her father's house in Bethlehem. After she had been there four months,"
    },
    {
      "verse": "3",
      "text": "her husband went to find her. He wanted to ask her to return home with him. He took his servant and two donkeys with him. When he arrived, she took him into her father's house. Her father was happy to see him."
    },
    {
      "verse": "4",
      "text": "He asked the Levite to stay there with them, and he stayed for three days. They ate food and they drank wine together. The Levite slept there."
    },
    {
      "verse": "5",
      "text": "On the fourth day they got up early. The Levite was ready to leave with his wife. But the woman's father said to the Levite, ‘Eat some food so that you are strong for your journey. Then you may go. ’"
    },
    {
      "verse": "6",
      "text": "So the two men sat down and they ate a meal together. Then the woman's father said to the Levite, ‘Stay here one more night. Then we can continue to be happy together. ’"
    },
    {
      "verse": "7",
      "text": "The Levite got up to go, but his wife's father made him stay."
    },
    {
      "verse": "8",
      "text": "The Levite got up early in the morning of the fifth day. He was ready to leave. But the woman's father said, ‘Make yourself strong with some food. Wait until this afternoon and then you can go. ’ So the two of them ate a meal together."
    },
    {
      "verse": "9",
      "text": "The Levite prepared to leave with his wife and his male servant. Then her father said, ‘Look! It is nearly evening already. Sleep here tonight. The day is almost over. Stay one more night and enjoy yourself. Early tomorrow morning you can leave on your journey to go home. ’"
    },
    {
      "verse": "10",
      "text": "But the Levite did not want to stay there for another night. So he left with his two donkeys and his wife. They travelled as far as Jebus, which is now called Jerusalem."
    },
    {
      "verse": "11",
      "text": "When they arrived near to Jebus, it was getting dark. The servant said to his master, ‘Let us stay in this city of the Jebusites. We can sleep here for the night. ’"
    },
    {
      "verse": "12",
      "text": "The Levite replied, ‘No, we should not stay in a foreign city. The people who live here are not Israelites. We will go on to Gibeah. ’"
    },
    {
      "verse": "13",
      "text": "He said to his servant, ‘Let us try to reach Gibeah or Ramah. Then we can stay in one of those places for the night. ’"
    },
    {
      "verse": "14",
      "text": "So they continued on their journey. It was sunset when they came near to Gibeah, in Benjamin's land."
    },
    {
      "verse": "15",
      "text": "They decided to stay there for the night. They went into the city. They sat down in the public place in the middle of the city. But no one took them in to their home to sleep for the night."
    },
    {
      "verse": "16",
      "text": "That evening, there was an old man who was returning home from his work in the fields. He was from the hill country of Ephraim but he was living in Gibeah at that time."
    },
    {
      "verse": "17",
      "text": "He saw the Levite traveller in the public place. He asked, ‘Where are you travelling to? Where have you come from? ’"
    },
    {
      "verse": "18",
      "text": "The Levite answered, ‘We are travelling from Bethlehem in Judah to the hill country of Ephraim, far from other towns. That is where I live. I needed to go to Bethlehem and now I am returning home. But no one has taken me into his house to sleep."
    },
    {
      "verse": "19",
      "text": "We have straw and food for our donkeys. We have food and wine for myself, my wife and my servant. We have everything that we need. ’"
    },
    {
      "verse": "20",
      "text": "The old man said, ‘Do not worry. I will take care of you. Please come into my house, but do not stay for the night in this public place. ’"
    },
    {
      "verse": "21",
      "text": "So the old man took the Levite into his house, and he fed the donkeys. When they had washed their feet, they ate a meal."
    },
    {
      "verse": "22",
      "text": "They were enjoying their time together. Suddenly, some wicked men who lived in the city came to the house. They stood all around it and they hit the door hard. They shouted to the old man who lived there, ‘Bring out the man who came to visit you. We want to have sex with him. ’"
    },
    {
      "verse": "23",
      "text": "The old man went outside to them. He said to them, ‘Friends, do not try to do this very evil thing! This man is a visitor in my house. Do not do such a wicked thing."
    },
    {
      "verse": "24",
      "text": "Look! Here is my daughter. She has never had sex with anyone before. Here is my visitor's slave wife too. I will bring them outside to you. Then you can do whatever cruel things you want to do to them. But do not do such a terrible thing to this man. ’"
    },
    {
      "verse": "25",
      "text": "But the men would not agree to this. So the Levite took hold of his slave wife and he pushed her outside. They made her have sex with them all night and they were very cruel to her. At dawn, they let her go."
    },
    {
      "verse": "26",
      "text": "She went back to the house where her master was staying. She fell down at the door and she lay there until it became light."
    },
    {
      "verse": "27",
      "text": "When her master got up in the morning, he opened the door. He was ready to continue his journey. He saw the woman who was his wife lying on the ground outside the door. She was trying to reach the door with her hands."
    },
    {
      "verse": "28",
      "text": "He said to her, ‘Get up. It is time to go! ’ But she did not answer. Then he put her on his donkey and he started on his way home."
    },
    {
      "verse": "29",
      "text": "When he arrived home, he picked up a knife. He cut his slave wife's body into 12 pieces. Then he sent them to each of Israel's 12 tribes."
    },
    {
      "verse": "30",
      "text": "Everyone who saw what he had done said, ‘In all the time since the Israelites left Egypt, nothing as bad as this has ever happened before. We have never seen anything like it. Think carefully about it. We must decide what to do! ’"
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "Then all the Israelites agreed to come together. They came from everywhere in Israel, from Dan in the north as far as Beersheba in the south. They also came from the Gilead region on the east side of the Jordan River. They all came together at Mizpah, to meet with the Lord. Then the Israelites asked, ‘Tell us how this evil thing happened. ’"
    },
    {
      "verse": "2",
      "text": "The leaders of all Israel's tribes stood there with the people of God. There were 400, 000 Israelite men who had their weapons, ready to fight."
    },
    {
      "verse": "3",
      "text": "By this time, the people of Benjamin's tribe had heard the news that the other tribes were meeting in Mizpah. Then the Israelites asked, ‘Tell us how this evil thing happened. ’"
    },
    {
      "verse": "4",
      "text": "So the Levite, the husband of the dead woman, told them. He said, ‘My slave wife and I arrived in Gibeah to sleep there for the night. It is a town that belongs to the people of Benjamin's tribe."
    },
    {
      "verse": "5",
      "text": "That night some important men of Gibeah came to the house to attack me. They stood all around the house. They wanted to kill me, but they took hold of my wife instead. They made her have sex with them, and she died."
    },
    {
      "verse": "6",
      "text": "pieces. I sent the pieces everywhere in the land of Israel. I did this to show what a terrible thing these men had done."
    },
    {
      "verse": "7",
      "text": "So now all you people of Israel must decide what you will do about it. ’"
    },
    {
      "verse": "8",
      "text": "All the people stood up together. They all promised, ‘None of us will go home. Not one of us will return to his house."
    },
    {
      "verse": "9",
      "text": "Instead, this is what we will do to the people of Gibeah. We will use lots to decide who should attack the city."
    },
    {
      "verse": "10",
      "text": "men in each tribe. We will take 100 men from every 1, 000 men, and 1, 000 men from every 10, 000 men. Those men will find food for the other soldiers. That will be their job. Then the other soldiers will be able to attack Gibeah. They will punish Gibeah's people as they deserve for the terrible thing that they have done. ’"
    },
    {
      "verse": "11",
      "text": "So all the Israelites agreed together that they would attack Gibeah, in the land of Benjamin."
    },
    {
      "verse": "12",
      "text": "The Israelite tribes sent men with a message to all the places in Benjamin. They said, ‘You must know that some of your men have done an evil thing."
    },
    {
      "verse": "13",
      "text": "Send those wicked men of Gibeah out to us. We must punish them with death. Only that will remove this terrible sin from Israel. ’But the people of Benjamin did not agree to do that."
    },
    {
      "verse": "14",
      "text": "Instead, they came from all their towns and they met together at Gibeah to fight against the other Israelites."
    },
    {
      "verse": "15",
      "text": "26, 000 soldiers came to Gibeah with their weapons, ready to fight. There were also 700 brave soldiers already in Gibeah."
    },
    {
      "verse": "16",
      "text": "In Benjamin's army there were 700 men who used their left hands to fight. Each of them could use a sling to throw a stone at a very small thing. They could even hit a hair!"
    },
    {
      "verse": "17",
      "text": "The other Israelite tribes, without Benjamin, had an army of 400, 000 soldiers who knew how to use their weapons."
    },
    {
      "verse": "18",
      "text": "They went to Bethel. They asked God which tribe should go first to attack Benjamin's army. The Lord replied, ‘Judah must go first. ’"
    },
    {
      "verse": "19",
      "text": "The next morning, the Israelites got up and they prepared to attack Gibeah."
    },
    {
      "verse": "20",
      "text": "The Israelite army marched forward to fight against Benjamin's army. They stood in their places around the city."
    },
    {
      "verse": "21",
      "text": "Benjamin's soldiers came out of Gibeah to attack. They killed 22, 000 Israelites in the battle that day."
    },
    {
      "verse": "24",
      "text": "The Israelites went to fight against Benjamin's army on the second day."
    },
    {
      "verse": "25",
      "text": "This time, when the soldiers of Benjamin came out of Gibeah to attack them, they killed another 18, 000 Israelite soldiers in the battle."
    },
    {
      "verse": "26",
      "text": "Then the whole Israelite army went back to Bethel to meet with the Lord. They sat there and they wept. They did not eat any food that day until evening. They offered burnt offerings and peace offerings to the Lord."
    },
    {
      "verse": "29",
      "text": "This time, the Israelites made some of their soldiers hide in places around Gibeah."
    },
    {
      "verse": "30",
      "text": "On the third day, their other soldiers stood in the same places as before. They were ready to fight."
    },
    {
      "verse": "31",
      "text": "The soldiers of Benjamin came out of Gibeah to attack them. But the Israelites moved away from the city so that Benjamin's soldiers chased after them. The men of Benjamin began to kill the Israelites, as they had done before. They killed about 30 Israelites in the fields and on the roads that went to Bethel and Gibeah."
    },
    {
      "verse": "32",
      "text": "The soldiers of Benjamin were saying, ‘We are winning against them, as we have done before! ’ But the Israelites were saying, ‘We will continue to run away so that their soldiers chase us. We will lead them away from the city onto the roads. ’"
    },
    {
      "verse": "33",
      "text": "When the men of Israel reached Baal Tamar, they stopped there. They stood in their places, ready to fight. At the same time, the Israelite soldiers who had hidden themselves on the west side of Gibeah ran out of their places."
    },
    {
      "verse": "34",
      "text": "10, 000 Israelite soldiers who knew how to fight well attacked Gibeah. There was a big battle. The men of Benjamin did not realize that they were in a lot of trouble."
    },
    {
      "verse": "35",
      "text": "The Lord destroyed Benjamin's army as the Israelites attacked them. Israel's soldiers killed more than 25, 000 soldiers of Benjamin's army that day."
    },
    {
      "verse": "36",
      "text": "Finally, the men of Benjamin realized that they had lost the battle. This is how it happened: Israel's soldiers let Benjamin's army chase after them. They trusted the soldiers who were hiding around Gibeah to attack the city."
    },
    {
      "verse": "39",
      "text": "Then the other Israelite soldiers would turn round to attack the soldiers who were chasing them. Benjamin's soldiers had begun to kill the Israelites. When they had killed about 30 of them, they said, ‘Look! We are winning again, as we always do! ’"
    },
    {
      "verse": "40",
      "text": "Then they turned and they saw the tall pillar of smoke. It was rising from their city up to the sky."
    },
    {
      "verse": "41",
      "text": "The Israelite soldiers saw the sign and they attacked the soldiers of Benjamin. The men of Benjamin suddenly became very afraid. They realized that they were in a lot of trouble."
    },
    {
      "verse": "42",
      "text": "So they ran away on the road towards the desert while the Israelites chased after them. But they could not escape from the Israelites. Israelite men came out from their towns and killed them in the battle."
    },
    {
      "verse": "43",
      "text": "They attacked Benjamin's soldiers from all sides and they continued to chase them. They were killing them all the way to a place on the east of Gibeah."
    },
    {
      "verse": "44",
      "text": "They killed 18, 000 strong soldiers of Benjamin's tribe."
    },
    {
      "verse": "45",
      "text": "The rest of Benjamin's soldiers ran towards the desert, as far as the rock of Rimmon. The Israelites killed 5, 000 of them as they ran along the roads. They chased them to Gidom, and they killed 2, 000 more of Benjamin's soldiers there."
    },
    {
      "verse": "46",
      "text": "On that day, 25, 000 soldiers of Benjamin's tribe died. They were all brave men who knew how to fight well."
    },
    {
      "verse": "47",
      "text": "soldiers turned and ran away to the rock of Rimmon. They stayed there for four months."
    },
    {
      "verse": "48",
      "text": "The Israelites returned to the land that belonged to Benjamin's tribe. They killed the people and animals in all the towns there. As they came to each town, they destroyed it with fire."
    },
    {
      "verse": "22",
      "text": "The Israelite soldiers told each other to be brave. They went to meet with the Lord and they wept until the evening."
    },
    {
      "verse": "23",
      "text": "They asked the Lord, ‘Should we march out again to fight against our relatives, the men of Benjamin? ’ The Lord said, ‘Yes, attack them. ’ So they went to stand in the same places around the city as they had done the day before."
    },
    {
      "verse": "27",
      "text": "The Covenant Box was in Bethel at that time. Phinehas, son of Eleazar and grandson of Aaron, was the priest who served the Lord there. The Israelites asked the Lord, ‘Should we march out to fight against our relatives, the men of Benjamin, again? Or should we leave them? ’ The Lord said, ‘Attack them."
    },
    {
      "verse": "28",
      "text": "Tomorrow I will put them under your power. ’."
    },
    {
      "verse": "37",
      "text": "The Israelites had agreed a sign with their men who were hiding. When those men ran into Gibeah and they destroyed everything there, they would make the sign."
    },
    {
      "verse": "38",
      "text": "They would light a big fire so that the smoke went up into the sky."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "The Israelites had made a promise to the Lord at Mizpah. They agreed together, ‘None of us will allow our daughters to marry a man of Benjamin's tribe. ’"
    },
    {
      "verse": "2",
      "text": "After the war against Benjamin's army, the people went to Bethel to meet with God. They sat there until evening. They could not stop weeping loudly."
    },
    {
      "verse": "3",
      "text": "They said, ‘Lord, Israel's God, why has this terrible thing happened in Israel? We have lost one whole tribe of Israel. ’"
    },
    {
      "verse": "4",
      "text": "The next morning, the people got up early. They built an altar. They offered burnt offerings and peace offerings to the Lord there."
    },
    {
      "verse": "5",
      "text": "Then the Israelites asked, ‘Which people from Israel's tribes did not join us when we all met together at Mizpah? ’ They asked this because they had made a serious promise at Mizpah. They had said, ‘We must punish with death anyone who does not join us here to meet with the Lord. ’"
    },
    {
      "verse": "6",
      "text": "The Israelites were very upset about what had happened to Benjamin's tribe. They said, ‘We have destroyed a whole tribe of Israel. They were our relatives."
    },
    {
      "verse": "7",
      "text": "How can we find women to marry the few men who are left? We all made a serious promise to the Lord that we would not let them marry our daughters. ’"
    },
    {
      "verse": "8",
      "text": "So they asked, ‘When we met with the Lord at Mizpah, which people from all Israel's tribes did not come with us? ’ They realized that no one from Jabesh Gilead had come to the meeting."
    },
    {
      "verse": "9",
      "text": "When they had counted the people, there had been no men from Jabesh Gilead among them."
    },
    {
      "verse": "10",
      "text": "So all the Israelites decided to send an army of 12, 000 soldiers to attack Jabesh Gilead. They commanded them, ‘Use your swords to kill everyone there, including the women and children."
    },
    {
      "verse": "11",
      "text": "This is what you must do: Kill every male and every woman who has slept with a man. But do not kill the women who have never had sex. ’"
    },
    {
      "verse": "12",
      "text": "The Israelite army attacked Jabesh Gilead. They found 400 young women who had not had sex with anyone. They took the women back to their camp at Shiloh in Canaan."
    },
    {
      "verse": "13",
      "text": "Then all the Israelites sent a message of peace to the men of Benjamin who were still at the rock of Rimmon."
    },
    {
      "verse": "14",
      "text": "So the men returned from the rock at that time. The Israelites gave the women of Jabesh Gilead that they had not killed to them. But there were not enough women for all the men of Benjamin."
    },
    {
      "verse": "15",
      "text": "The Israelite people were very sad about what had happened to Benjamin's tribe. The Lord had caused their tribe to become very weak."
    },
    {
      "verse": "16",
      "text": "The Israelite leaders asked, ‘How can we find wives for the other men of Benjamin? We killed all their own women."
    },
    {
      "verse": "17",
      "text": "Benjamin's people who are still alive must have children. If they do not, their whole tribe will disappear."
    },
    {
      "verse": "18",
      "text": "But we cannot allow our daughters to marry them. We promised that we would never do that. We said, “God himself will punish anyone who allows his daughter to marry a man of Benjamin. ”"
    },
    {
      "verse": "19",
      "text": "But every year there is a big feast at Shiloh to give honour to the Lord. That will happen soon. ’Shiloh is north of Bethel and south of Lebonah. It is on the east side of the road from Bethel to Shechem."
    },
    {
      "verse": "20",
      "text": "The Israelites told the men of Benjamin, ‘Go there and hide in the vineyards."
    },
    {
      "verse": "21",
      "text": "Watch carefully. When the young women of Shiloh come out to dance at the feast, run out from the vineyards. Each of you should catch one of the young women of Shiloh. Take them home to the land of Benjamin to be your wives."
    },
    {
      "verse": "22",
      "text": "Their fathers or their brothers may come to us and complain. If they do, we will say, “Please agree to help the men of Benjamin. We could not find a wife for each of them in the war. You did not choose to give your daughters to them, so you will not be guilty. The men of Benjamin caught them and took them away. ” ’"
    },
    {
      "verse": "23",
      "text": "men of Benjamin did. Each of them caught a young woman as she was dancing at the feast. They took them home to their own land to be their wives. They built their towns again and they lived in them."
    },
    {
      "verse": "24",
      "text": "After that, the Israelites left there. They went back home to the places where their tribes and their clans lived."
    },
    {
      "verse": "25",
      "text": "At that time, Israel had no king to rule over them. Everyone did what they thought was right."
    }
  ]
};