module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "The Lord spoke to Moses from the Tent of Meeting. He told him the rules that Israel's people must obey."
    },
    {
      "verse": "2",
      "text": "The Lord said, ‘Speak to Israel's people. Tell them this. When a person gives an animal to the Lord, it must be a cow or a sheep or a goat."
    },
    {
      "verse": "3",
      "text": "A person may want to give a gift to the Lord. That gift must be a male animal from his group of animals. It must be perfect. He must burn the whole animal as a gift to the Lord. The person must bring it to the door of the Tent of Meeting. If he does, the Lord will accept his gift."
    },
    {
      "verse": "4",
      "text": "The person must put his hand on the animal's head. Then he must kill it. The animal's death will pay for the person's sins."
    },
    {
      "verse": "5",
      "text": "The person must kill the young bull in front of the Lord. The priests who are the sons of Aaron will take the blood. They will throw it onto the sides of the altar. That is the altar near to the door of the Tent of Meeting."
    },
    {
      "verse": "6",
      "text": "The person must take the skin from the dead animal and then he must cut up the meat."
    },
    {
      "verse": "7",
      "text": "The sons of Aaron the priest will light a fire on the altar. Then they will put wood on it."
    },
    {
      "verse": "8",
      "text": "The priests will put the pieces of meat on the fire. They will put the head and the fat on the fire with the meat."
    },
    {
      "verse": "9",
      "text": "The person must wash the legs and the inside parts with water. Then the priest will burn the whole animal on the altar. The smell of it while it is burning will give the Lord pleasure."
    },
    {
      "verse": "10",
      "text": "A person may want to give a sheep or a goat as a gift to God. It must be a male animal. It must be perfect."
    },
    {
      "verse": "11",
      "text": "The person must kill it at the north side of the altar. The priests will throw the blood onto the sides of the altar in front of the Lord."
    },
    {
      "verse": "12",
      "text": "The person must cut the animal up. The priests will take the pieces of meat, the head and the fat. They will put them on the fire that is burning on the altar."
    },
    {
      "verse": "13",
      "text": "The person must wash the legs and the inside parts with water. The priest will burn the whole animal on the altar. It is a burnt offering. The smell of it while it is burning will give the Lord pleasure."
    },
    {
      "verse": "14",
      "text": "If a person wants to give a bird to the Lord, it must be a dove or a pigeon."
    },
    {
      "verse": "15",
      "text": "The priest will bring the bird to the altar. He will tear off the head and he will burn it on the altar. The priest will pour the blood onto the side of the altar."
    },
    {
      "verse": "16",
      "text": "Then the priest will remove the part of the bird where the food is stored. He will throw it on the east side of the altar, with the ashes."
    },
    {
      "verse": "17",
      "text": "He will hold the parts that the bird uses to fly. And then he will tear open the body. But he must not tear it completely. He will burn all of it on the fire that is on the altar. The smell of it while it is burning will give the Lord pleasure."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "A person may want to give grain as a gift to the Lord. He must make it into flour. He must put oil and incense on the flour."
    },
    {
      "verse": "2",
      "text": "He must take it to Aaron's sons, the priests. The priest will take some of the flour and oil and all the incense in his hand. He will burn them on the altar as a gift to the Lord. The smell of them while they are burning will give the Lord pleasure."
    },
    {
      "verse": "3",
      "text": "The flour that he did not burn is for the priests. It is very holy. That is because it is part of an offering to the Lord."
    },
    {
      "verse": "4",
      "text": "A person must not use yeast if he bakes his gift of grain. He must make cakes or biscuits with flour and oil."
    },
    {
      "verse": "5",
      "text": "He must not use yeast if he cooks his cake on a flat plate. He must make it with flour and oil."
    },
    {
      "verse": "6",
      "text": "He must break the cake into pieces. He must pour oil on it. It is a gift to God."
    },
    {
      "verse": "7",
      "text": "A person must use flour and oil to cook the cake in a pot."
    },
    {
      "verse": "8",
      "text": "He must give the cake to the priest. The priest will take it to the altar."
    },
    {
      "verse": "9",
      "text": "He will take a piece of it and he will burn it in the fire. It is a gift to the Lord. The smell of it while it is burning will give the Lord pleasure."
    },
    {
      "verse": "10",
      "text": "The part of the cake that he did not burn is for the priests. That is because it is most holy, part of a burnt offering to the Lord."
    },
    {
      "verse": "11",
      "text": "A person must not use yeast when he gives a gift of grain to the Lord. He must not give yeast or honey for the priests to burn as gifts to the Lord."
    },
    {
      "verse": "12",
      "text": "He can give them as the first part of his harvest. He must not burn them on the fire. He cannot use them to give the Lord pleasure."
    },
    {
      "verse": "13",
      "text": "A person must put salt in all his gifts of grain. Salt is a mark of God's promise to Israel's people."
    },
    {
      "verse": "14",
      "text": "A person may want to give the first part of his harvest to the Lord. He must break the grains into pieces and he must cook them in a fire."
    },
    {
      "verse": "15",
      "text": "They are a gift, so he must put oil and incense on them."
    },
    {
      "verse": "16",
      "text": "The priest will burn a part of the grain with all the incense. It is a burnt offering to the Lord."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "A person might want to give a friendship offering to the Lord. He must take a perfect animal from his group of animals. The animal can be male or female."
    },
    {
      "verse": "2",
      "text": "The person must put his hand on the animal's head. Then he must kill it at the door of the Tent of Meeting. Aaron's sons the priests will throw the blood onto the sides of the altar."
    },
    {
      "verse": "3",
      "text": "The person must burn some pieces of the animal as a gift to the Lord. It is a friendship offering."
    },
    {
      "verse": "4",
      "text": "He must bring all the fat from inside the animal. And he must bring the kidneys with their fat and the best piece of the liver."
    },
    {
      "verse": "5",
      "text": "The priests, Aaron's sons, will take the pieces. They must put them on top of the gift on the altar. The smell of them while they are burning will give the Lord pleasure."
    },
    {
      "verse": "6",
      "text": "If a person wants to give a sheep to the Lord as a friendship offering, it must be perfect. The person can give a male animal or a female animal to the Lord."
    },
    {
      "verse": "7",
      "text": "If it is a young sheep he must offer it to the Lord."
    },
    {
      "verse": "8",
      "text": "He must put his hand on its head. Then he must kill it at the front of the Tent of Meeting. Aaron's sons will throw the blood onto the sides of the altar."
    },
    {
      "verse": "9",
      "text": "The person must cut the tail off the animal. He must give the tail and all the fat from inside the body to the Lord."
    },
    {
      "verse": "10",
      "text": "He must also give the kidneys and the best piece of the liver."
    },
    {
      "verse": "11",
      "text": "The priest will burn them as food on the altar. They are a burnt offering to the Lord."
    },
    {
      "verse": "12",
      "text": "A person may offer a goat to the Lord."
    },
    {
      "verse": "13",
      "text": "The person must put his hand on the goat's head. Then he must kill it at the front of the Tent of Meeting. Then Aaron's sons will throw the blood onto the sides of the altar."
    },
    {
      "verse": "14",
      "text": "The person must take all the fat round the inside parts. He must give it to the Lord for a burnt offering."
    },
    {
      "verse": "15",
      "text": "He must also give the kidneys with the fat on them and the best piece of the liver."
    },
    {
      "verse": "16",
      "text": "The priest will burn them as food on the altar. The smell of them while they are burning will give the Lord pleasure."
    },
    {
      "verse": "17",
      "text": "Israel's people must not eat any fat or drink any blood. This rule is for them and for their children everywhere. They must obey this rule always. ’"
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Say to Israel's people, “A man may sin, when he did not really want to sin against the Lord. This is what that person must do."
    },
    {
      "verse": "3",
      "text": "The man may be a priest that you have anointed. If that is true, his sins will cause the people to sin. He must bring a young bull as a gift to the Lord."
    },
    {
      "verse": "4",
      "text": "The priest must bring the young bull to the door of the Lord's Tent of Meeting. He must put his hand on the animal's head. And then he must kill it in front of the Lord."
    },
    {
      "verse": "5",
      "text": "The priest that you have anointed must carry some of the blood into the Tent of Meeting."
    },
    {
      "verse": "6",
      "text": "He must put his finger in the blood. He must shake it in front of the holy curtain seven times in front of the Lord."
    },
    {
      "verse": "7",
      "text": "He must put some of the blood on the horns of the incense altar in front of the Lord. The priest must pour the blood that he did not use onto the floor in front of the altar. That altar is near the door outside the Tent of Meeting."
    },
    {
      "verse": "8",
      "text": "He must cut all the fat from inside the dead animal."
    },
    {
      "verse": "9",
      "text": "He must also cut out the kidneys and the best piece of the liver. He must take them from inside the animal."
    },
    {
      "verse": "10",
      "text": "He must burn the fat on the altar. The priest does this when the people give a friendship offering to God."
    },
    {
      "verse": "11",
      "text": "He must take up the skin and all the meat. He must take the head, the legs and all the inside pieces. He must include the stomach."
    },
    {
      "verse": "12",
      "text": "The priest must take all the pieces to a clean place outside the camp. He must put them on the ashes and he must burn them on a wood fire."
    },
    {
      "verse": "13",
      "text": "All of the people might do bad things when they did not really want to do them. They might not obey some of the Lord's rules. They will have sinned, even if they did not know this."
    },
    {
      "verse": "14",
      "text": "When they do know about it they must bring a young bull to the Tent of Meeting. The animal is a sin offering."
    },
    {
      "verse": "15",
      "text": "The leaders of the people must put their hands on the young bull's head. Then they must kill it in front of the Lord."
    },
    {
      "verse": "16",
      "text": "The priest will take some of the blood into the Tent of Meeting."
    },
    {
      "verse": "17",
      "text": "He will put his finger in the blood. He must shake it in front of the Lord and the holy curtain seven times."
    },
    {
      "verse": "18",
      "text": "He will take some of the blood. Then he will put it on the horns of the altar that is in front of the Lord. He will pour the blood that he did not use onto the floor. He must pour it in front of the burnt offering altar. This altar is outside the door of the Tent of Meeting."
    },
    {
      "verse": "19",
      "text": "The priest will cut all the fat from the dead animal. And he will burn all the fat on the altar of burnt offering."
    },
    {
      "verse": "20",
      "text": "He will do with this bull what he did with the bull for the sin offering. This is how the priest will atone for the sins of the people. God will forgive them when the priest does this."
    },
    {
      "verse": "21",
      "text": "The priest will take the dead animal outside the camp. He will put it on the ashes from the altar fire. He will burn the animal as he did the first bull. This is the sin offering for all the people."
    },
    {
      "verse": "22",
      "text": "A leader might do bad things when he did not really want to do them. He has sinned if he does not obey one of the Lord's rules."
    },
    {
      "verse": "23",
      "text": "People will tell him that he has done wrong things. So then he must give a male goat to God. The animal must be perfect."
    },
    {
      "verse": "24",
      "text": "He must put his hand on the goat's head and then he must kill it. He must do this where they kill animals in front of the Lord for the burnt offering. It is a sin offering."
    },
    {
      "verse": "25",
      "text": "The priest will put his finger in the blood of the dead animal. He will put some of it on the horns of the altar. He will pour the blood that he did not use onto the ground. He will pour it in front of the altar."
    },
    {
      "verse": "26",
      "text": "Then the priest will cut all the fat from the goat. And he will burn it on the altar. He will do this as he did for the friendship offering. This is how the priest will make atonement for the leader's sin. Then God will forgive the leader."
    },
    {
      "verse": "27",
      "text": "One of the people might do bad things when he did not really want to do them. He did not obey one of the Lord's rules. That person has sinned."
    },
    {
      "verse": "28",
      "text": "They will tell him that he has done bad things. Then he must give a female goat to God. The animal must be perfect."
    },
    {
      "verse": "29",
      "text": "He must put his hand on the goat's head. Then he must kill it by the altar of burnt offering."
    },
    {
      "verse": "30",
      "text": "The priest will put his finger in the blood of the goat. He will put some of it on the altar's corners. He will pour out the blood that he did not use. He will pour it onto the ground in front of the altar."
    },
    {
      "verse": "31",
      "text": "The priest will cut all the fat from the goat as he did with the friendship offering. And he will burn it on the altar. This will make atonement for the wrong things that the person has done. The smell of it while it is burning will give the Lord pleasure. Then the Lord will forgive the person."
    },
    {
      "verse": "32",
      "text": "If a person wants to give a young sheep to God, it must be a female. It must be perfect."
    },
    {
      "verse": "33",
      "text": "He must put his hand on the animal's head. He will kill it at the altar of burnt offering."
    },
    {
      "verse": "34",
      "text": "The priest will put his finger in the blood of the sheep. He will take some of it and he will put it on the horns of the altar. He will pour the blood that he did not use on the ground in front of the altar."
    },
    {
      "verse": "35",
      "text": "The priest will cut all the fat from the sheep as he did with the friendship offering. He will burn it on the altar. He must burn it on top of the burnt offerings. This is how the priest will make atonement for the person's sin. Then the Lord will forgive the person."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "A person may know about something that is wrong. He may not speak about it at a public meeting. That person is sinning."
    },
    {
      "verse": "2",
      "text": "God has said that some animals and insects are not clean. A person may touch a dead animal or an insect like that. If he does, he is doing something wrong. It is a sin even if he did not really want to touch it."
    },
    {
      "verse": "3",
      "text": "A person may touch something that another person has made bad. If he does, he is doing something wrong. He might not know that it is bad, but he is still doing a wrong thing."
    },
    {
      "verse": "4",
      "text": "A person is doing a wrong thing if he says any careless promise. The promise might be good or bad. People will tell him that he has not obeyed God's rules. Then he will know that he has sinned."
    },
    {
      "verse": "5",
      "text": "A person must tell the priest if he has done any of these things."
    },
    {
      "verse": "6",
      "text": "He must give a sheep or a goat for a sin offering. Then the Lord will not be angry with him. The priest will kill the animal as a sacrifice to atone for that sin."
    },
    {
      "verse": "7",
      "text": "A person may not have money to buy a sheep or a goat. If he does not, he must buy two doves or two pigeons. He must give them to the Lord. One bird will be a sin offering. The second bird will be a burnt offering."
    },
    {
      "verse": "8",
      "text": "The priest will bring one of the birds to the altar. It is the sin offering. He will break the neck of the bird, but he will not pull the head off."
    },
    {
      "verse": "9",
      "text": "He will shake some of the blood onto the side of the altar. He will pour the blood that he did not shake onto the floor. He must pour it in front of the altar."
    },
    {
      "verse": "10",
      "text": "The priest will burn the other bird. God will not be angry with the man when the priest does this."
    },
    {
      "verse": "11",
      "text": "A person may not have money to buy two doves or two pigeons. If he does not, he must give a tenth of an ephah (about two litres) of flour. He must not put oil or incense on the flour because it is a sin offering."
    },
    {
      "verse": "12",
      "text": "He must take it to the priest. The priest will burn some of the flour on the altar as a special part of the flour. It is a sin offering to the Lord."
    },
    {
      "verse": "13",
      "text": "He will forgive the person when the priest does this. The flour that he did not burn is like the grain offering. It belongs to the priests. ” ’"
    },
    {
      "verse": "14",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "15",
      "text": "‘If a person does not obey the Lord's holy rules he is sinning. He must give a male sheep to the Lord. He must do this even if he did not know that he had sinned. It is a gift to the Lord to pay for his sins. It must be a perfect male animal. It must be worth the correct amount of money."
    },
    {
      "verse": "16",
      "text": "He must also give money worth one fifth more. The person must give the sheep and the money to the priest. The priest will sacrifice the sheep. It is an atonement for the wrong things that the person has done. God will forgive the person."
    },
    {
      "verse": "17",
      "text": "A person might do wrong things against the Lord. But the person might not know that they were wrong. He is sinning."
    },
    {
      "verse": "18",
      "text": "When he knows about it, he must bring a sheep to the priest. The animal must be a perfect male. The sheep must be worth the right amount of money. The priest will give the sheep to the Lord. It will be an atonement for the wrong things that the person has done. Then the Lord will forgive the person."
    },
    {
      "verse": "19",
      "text": "The sheep is an offering because the person did not obey the Lord. ’"
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘A person may take something that is not his. Or he may find it and keep it. He may tell his friend that he has not taken it. He might not give him the correct price for something. But then he is not obeying the Lord."
    },
    {
      "verse": "3",
      "text": "A person may speak words that are not true. That is a sin. A person may keep something that belongs to another person. He does not give it back. That is a wrong thing to do. He might find something and then he might say that it is his. If it is not his, he is not obeying God."
    },
    {
      "verse": "4",
      "text": "He has done something that is wrong. So he must show that he is sorry. He must give back anything that is not his. He must give back anything that he has found. He must give back anything that he has kept. He must give it to the person to whom it belongs."
    },
    {
      "verse": "5",
      "text": "He must give back everything and one fifth more. He must also, on the same day, give a gift to the Lord."
    },
    {
      "verse": "6",
      "text": "He must bring a sheep to the priest. The sheep must be a perfect male animal. The sheep must be worth the right amount of money."
    },
    {
      "verse": "7",
      "text": "The priest will give the sheep to the Lord. It is an atonement for the wrong things that the person has done. Then the Lord will forgive the person. ’"
    },
    {
      "verse": "8",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "9",
      "text": "‘Tell Aaron and his sons my rules. They must burn these gifts on the altar. The fire must burn all night."
    },
    {
      "verse": "10",
      "text": "When the morning comes, the priest must dress himself in his linen clothes. The linen must be next to his skin. He must take the ashes from the fire and he must put them at the side of the altar."
    },
    {
      "verse": "11",
      "text": "Then he must dress himself in other clothes. He must carry the ashes outside the camp and he must put them in a special place."
    },
    {
      "verse": "12",
      "text": "The fire that is on the altar must never stop burning. Every morning the priest must put wood on it. He must also put on it the gifts and the fat of the friendship offerings."
    },
    {
      "verse": "13",
      "text": "The fire must always burn. It must not go out."
    },
    {
      "verse": "14",
      "text": "These are the rules for the gift of grain. Aaron's sons must bring it in front of the altar to give to the Lord."
    },
    {
      "verse": "15",
      "text": "A priest must take some of the flour and oil. He must mix this special part with incense and he must burn all of it on the altar. The smell of them while they are burning will give the Lord pleasure."
    },
    {
      "verse": "16",
      "text": "The priests will make into bread the flour that he did not burn. They must not use yeast to make the bread. They must eat the bread in a holy place, in the yard outside the Tent of Meeting."
    },
    {
      "verse": "17",
      "text": "The bread is for the priests because it is a holy part of a gift. It is holy, like the offerings for sin. And it is like the gifts when somebody does anything wrong."
    },
    {
      "verse": "18",
      "text": "Any son, grandson or male of Aaron's family can eat the bread. It is his usual part of the burnt offerings to the Lord. A person who touches the bread will become holy. ’"
    },
    {
      "verse": "19",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "20",
      "text": "‘When Aaron is anointed, Aaron and his sons must give an offering to the Lord. It must be a tenth of an ephah (about two litres) of best flour. They must bring half of it in the morning and half of it in the evening."
    },
    {
      "verse": "21",
      "text": "They must mix it with oil and they must cook it on a flat plate. Then they must break it into pieces and they must offer it to the Lord. The smell of it will give the Lord pleasure."
    },
    {
      "verse": "22",
      "text": "The son whom they will anoint to take Aaron's place must prepare the offering."
    },
    {
      "verse": "23",
      "text": "All of the gifts that the priests give to God must be burnt completely. Nobody should eat them. ’"
    },
    {
      "verse": "24",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "25",
      "text": "‘Tell Aaron and his sons this rule. When a person does wrong things he must give an animal to the Lord. The animal will be holy. The person must kill the animal at the north side of the altar. That is where they kill the offerings for sin."
    },
    {
      "verse": "26",
      "text": "The priest who offered it will eat his part of the gift in a holy place. That is the yard outside the Tent of Meeting."
    },
    {
      "verse": "27",
      "text": "If anyone or anything touches the meat they will become holy. If the blood touches the clothes of a person, he must wash them in a holy place."
    },
    {
      "verse": "28",
      "text": "If a person cooks the meat in a clay pot, he must break the pot. He must break it when he has cooked the meat. If a person cooks the meat in a metal pot, he must wash the pot. He must wash it well when he has cooked the meat. And he must wash it again with clean water."
    },
    {
      "verse": "29",
      "text": "The meat is holy. Only the priests' sons can eat it."
    },
    {
      "verse": "30",
      "text": "They must take the blood of a sin offering into the Tent of Meeting. It is a sacrifice to atone for sin. Nobody should eat any of that offering. The priest must burn it."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "These are the rules for a most holy offering. A person may be sorry for the wrong things that he has done. That person must obey these rules."
    },
    {
      "verse": "2",
      "text": "The priest must kill an animal at the north side of the altar. He must throw the blood onto the sides of the altar."
    },
    {
      "verse": "3",
      "text": "The priest will bring all the fat from the tail and the inside parts to the altar."
    },
    {
      "verse": "4",
      "text": "He will bring the kidneys and the best piece of the liver."
    },
    {
      "verse": "5",
      "text": "Then he will burn the pieces on the altar. They are a gift to the Lord to make a person clean from sin."
    },
    {
      "verse": "6",
      "text": "Aaron's sons can eat the meat that is not burnt. They must eat it in a holy place because it is most holy."
    },
    {
      "verse": "7",
      "text": "The rules are the same for sacrifices for sin and for a person who is sorry for his sins. The gifts of meat are for the priest who brings them to the altar."
    },
    {
      "verse": "8",
      "text": "The skin of the animal is for the priest."
    },
    {
      "verse": "9",
      "text": "People may give gifts of grain that they cooked in an oven or on a flat plate. They should give them all to the priest."
    },
    {
      "verse": "10",
      "text": "Grain that is dry is also a gift. And grain that a man mixes with oil is also a gift. They should give them to Aaron's sons."
    },
    {
      "verse": "11",
      "text": "These rules are for friendship offerings to the Lord."
    },
    {
      "verse": "12",
      "text": "If a man wants to thank God, he must give an animal and flat loaves of bread. He must mix the flour for the bread with oil. He must not mix the flour with yeast."
    },
    {
      "verse": "13",
      "text": "He must also give other loaves of bread to God. He must make these with flour, oil and yeast."
    },
    {
      "verse": "14",
      "text": "A man must offer one of each kind of loaf to the Lord. These belong to the priest who throws the blood on the altar."
    },
    {
      "verse": "15",
      "text": "The person must not keep the meat from the animal until the next day. He must eat it on the day that he offers it."
    },
    {
      "verse": "16",
      "text": "The gift to God may be for a promise. The gift may be because the person loves God. That person will not have to eat it all on the same day. He can eat some of it on the next day."
    },
    {
      "verse": "17",
      "text": "On the third day, there may still be some meat that he has not eaten. If there is, he must burn it."
    },
    {
      "verse": "18",
      "text": "If the person eats the meat on the third day, God will not accept the gift. The meat is not good. The person who eats it will not give God pleasure."
    },
    {
      "verse": "19",
      "text": "Some meat may touch something that is not clean. Nobody should eat that meat. People must burn it. Only a clean person can eat the meat that is a gift to God."
    },
    {
      "verse": "20",
      "text": "A person who is not clean might eat the friendship offering to the Lord. If he does, they must send him away from Israel's people."
    },
    {
      "verse": "21",
      "text": "A person might touch something that is not clean. He must not eat the meat of the offering to the Lord. That person must not eat it if he has touched an unclean animal or an unclean person. If he does eat it, they must send him away. They must send him away from Israel's people. ’"
    },
    {
      "verse": "22",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "23",
      "text": "‘Tell Israel's people this. They must not eat the fat from sheep, cows or goats."
    },
    {
      "verse": "24",
      "text": "A person can use the fat of a dead animal that he has found, but he must not eat it."
    },
    {
      "verse": "25",
      "text": "They must not eat the fat of an animal that they have burnt as a gift on the Lord's altar. They must send away from God's people anyone who does eat it."
    },
    {
      "verse": "26",
      "text": "You must not eat the blood of an animal or of a bird even if you are living in another country."
    },
    {
      "verse": "27",
      "text": "You must send away from Israel's people any person who eats blood. ’"
    },
    {
      "verse": "28",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "29",
      "text": "‘Say to Israel's people, “When a person gives an animal as a friendship offering, he must bring part of it to the Lord."
    },
    {
      "verse": "30",
      "text": "He must carry the offering in his own hands to the fire. He must bring the fat and the meat of the ribs and he must lift the meat to the Lord."
    },
    {
      "verse": "31",
      "text": "The priest will burn the fat at the altar. He will lift the meat of the ribs to God. Then Aaron's sons can eat it."
    },
    {
      "verse": "32",
      "text": "The top part of the back right leg of the animal is a gift."
    },
    {
      "verse": "33",
      "text": "It is for the priest who offers the blood and the fat."
    },
    {
      "verse": "34",
      "text": "The ribs and the top part of the right leg are gifts. They are from the friendship offering. God wants Aaron and his sons to have them. People must give these parts of their gift to the priests."
    },
    {
      "verse": "35",
      "text": "The Lord gave this part of the Israelites' offerings to Aaron's sons. He gave it to them on the day when they became the Lord's priests."
    },
    {
      "verse": "36",
      "text": "The Lord told the Israelites that they must do this. He told them that on the day that Aaron's sons became priests. All their sons and grandsons must always give these offerings to the priests. ” ’"
    },
    {
      "verse": "37",
      "text": "These are all the rules that a person must use. They are for when he gives a gift to God. They are the rules for offerings of grain and the friendship offering. And they are rules for the offerings that people give to take away their sin. The rules tell them how to make Aaron's sons priests. And they tell people who have done bad things what to do. They must show God that they are sorry."
    },
    {
      "verse": "38",
      "text": "Israel's people were in the Sinai desert. The Lord gave the rules to Moses on Sinai mountain. That was on the day that the Lord spoke to the people. He told them that they should bring their offerings to him there."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Fetch Aaron and his sons. Bring their special clothes. Bring the oil. Bring the basket of bread that they made without yeast. Also bring the bull for the sin offering and the two male sheep."
    },
    {
      "verse": "3",
      "text": "Cause all the people to come to the door of the Tent of Meeting. ’"
    },
    {
      "verse": "4",
      "text": "Moses did what the Lord said. Moses and the priests and all the people came to the door of the Tent of Meeting."
    },
    {
      "verse": "5",
      "text": "Moses said to the people, ‘The Lord said that I must do this. ’"
    },
    {
      "verse": "6",
      "text": "Moses washed Aaron and his sons with water."
    },
    {
      "verse": "7",
      "text": "Moses put a shirt on Aaron and he tied a belt round Aaron. He put a robe and an ephod on him. He tied the ephod with its special belt."
    },
    {
      "verse": "8",
      "text": "Moses put the breastpiece on Aaron, and he put the Urim and Thummim in its pocket."
    },
    {
      "verse": "9",
      "text": "Moses tied a piece of linen as a hat round Aaron's head. On the front of this linen he put a plate of gold with valuable stones on it. The Lord had said that Moses must do this."
    },
    {
      "verse": "10",
      "text": "Moses put some of the special olive oil on the tabernacle and on everything in it. He did this to make those things holy."
    },
    {
      "verse": "11",
      "text": "Moses shook oil on the altar seven times. He put oil on the altar table and on all the tools to use with it. He put oil on the washing dish and on the table on which it stood."
    },
    {
      "verse": "12",
      "text": "Moses anointed Aaron's head with oil to make him holy."
    },
    {
      "verse": "13",
      "text": "He put a robe on each of Aaron's sons. He tied cloth belts around them and cloth hats on their heads. The Lord had commanded Moses to do this."
    },
    {
      "verse": "14",
      "text": "Moses brought the bull as a gift to God. Aaron and his sons put their hands on the bull's head."
    },
    {
      "verse": "15",
      "text": "Moses killed the bull. He put his finger in the blood. He put the blood on the horns of the altar. That made it holy. Moses poured out the blood that he had not used. He poured it onto the floor in front of the altar. This is how he made the altar ready to make sacrifices."
    },
    {
      "verse": "16",
      "text": "He burnt the fat and the kidneys and the best piece of the liver on the altar."
    },
    {
      "verse": "17",
      "text": "Moses burnt the meat with the inside parts and the skin of the bull outside the camp. The Lord had said that Moses must do this."
    },
    {
      "verse": "18",
      "text": "Moses brought a male sheep to burn as a gift to God. Aaron and his sons put their hands on the sheep's head."
    },
    {
      "verse": "19",
      "text": "Moses killed the sheep. He threw the blood onto the sides of the altar."
    },
    {
      "verse": "20",
      "text": "Moses cut the sheep into small pieces. He burnt the fat and the head and the pieces on the altar."
    },
    {
      "verse": "21",
      "text": "He washed the legs and the inside parts. He burnt them on the altar as an offering to the Lord. The smell of them while they were burning gave the Lord pleasure. The Lord had said that Moses must do this."
    },
    {
      "verse": "22",
      "text": "Moses brought the other male sheep. It was a gift. It showed that God had chosen Aaron's family to become his priests. Aaron and his sons put their hands on the sheep's head."
    },
    {
      "verse": "23",
      "text": "Moses killed the sheep. He put some of its blood on Aaron's right ear. He also put blood on the thumb of Aaron's right hand. And he put some on the big toe of his right foot."
    },
    {
      "verse": "24",
      "text": "Moses did the same to Aaron's sons. Then he threw blood on all the sides of the altar."
    },
    {
      "verse": "25",
      "text": "Moses took the fat tail and the fat and the kidneys from inside the animal. He took the best piece of the liver from inside the animal. He took the top part of the right back leg."
    },
    {
      "verse": "26",
      "text": "Moses took two flat loaves of bread that they had made without yeast and a biscuit. He took them from the basket that was in front of the Lord. One of the loaves had oil in it. He put them on top of the fat and the leg."
    },
    {
      "verse": "27",
      "text": "Moses gave them to Aaron and to his sons. They lifted them up as a special gift to the Lord."
    },
    {
      "verse": "28",
      "text": "Moses took the special gift from them and he burnt it on the altar. The smell of it while it was burning gave the Lord pleasure."
    },
    {
      "verse": "29",
      "text": "Moses took his part of the animal, the meat of the ribs, and he lifted it up to the Lord. The Lord had said that Moses must do this."
    },
    {
      "verse": "30",
      "text": "Moses took some of the oil and some of the blood from the altar. He shook them on Aaron and his sons. He also shook some of the blood and some of the oil on their clothes. He did that to make them holy."
    },
    {
      "verse": "31",
      "text": "Moses said to Aaron and to his sons, ‘Cook the meat at the door of the Tent of Meeting. Eat the meat with the bread in the basket by the door of the Tent of Meeting."
    },
    {
      "verse": "32",
      "text": "Burn the meat and bread that you do not eat."
    },
    {
      "verse": "33",
      "text": "You must stay at the door of the Tent of Meeting for seven days. This will make you holy. You must stay for seven days to become holy."
    },
    {
      "verse": "34",
      "text": "The Lord said that you must do this to atone for your sin."
    },
    {
      "verse": "35",
      "text": "Remember that you must stay at the door of the Tent of Meeting. You must stay there for seven days and seven nights. The Lord told me that you must do this. If you do not obey him, you will die. ’"
    },
    {
      "verse": "36",
      "text": "So Aaron and his sons did everything that the Lord had told Moses."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "On the eighth day, Moses told Aaron and his sons and the leaders of Israel that they must come."
    },
    {
      "verse": "2",
      "text": "He said to Aaron, ‘Bring a young bull for your sin offering. And bring a male sheep for your burnt offering. They must be perfect to give to the Lord. ’"
    },
    {
      "verse": "3",
      "text": "Moses said to Aaron, ‘Tell Israel's people that they must bring a male goat for a sin offering. And they must bring a young cow and a young sheep. The young cow and the young sheep must be one year old. They must be perfect to burn as an offering."
    },
    {
      "verse": "4",
      "text": "Tell Israel's people that they must bring a bull and a male sheep. They must bring them to sacrifice as a friendship offering to the Lord. They will sacrifice them. They must mix grain and oil to offer with them. They must do that because the Lord will appear to them today. ’"
    },
    {
      "verse": "5",
      "text": "The people brought all the animals and the grain to the door of the Tent of Meeting. Moses and all the people came. And they stood at the door of the Tent of Meeting to worship the Lord."
    },
    {
      "verse": "6",
      "text": "Moses said to the people, ‘The Lord has told you that you must do this. Do it. And then the Lord will show you how great he is. ’"
    },
    {
      "verse": "7",
      "text": "Moses said to Aaron, ‘Go to the altar. Sacrifice your sin offering and your burnt offering to the Lord. You must do that to pay for your sins and those of the people. Then sacrifice the people's gift. Their offerings are an atonement for the bad things that they have done. The Lord said that you should do this. ’"
    },
    {
      "verse": "8",
      "text": "Aaron brought the young bull to the altar. He killed it. This was his offering to the Lord to atone for his sin."
    },
    {
      "verse": "9",
      "text": "His sons brought the blood to Aaron. He put his finger in the blood and he put it on the horns of the altar. He poured the blood that he did not use onto the floor in front of the altar."
    },
    {
      "verse": "10",
      "text": "Aaron burnt the fat, the kidneys and the best piece of the liver on the altar as a sin offering. He did it as the Lord had told Moses."
    },
    {
      "verse": "11",
      "text": "He took the meat and the skin from the young bull outside the camp and he burnt it."
    },
    {
      "verse": "12",
      "text": "Aaron brought the male sheep for the burnt offering to the altar. He killed it. His sons brought the blood to him. He threw the blood onto the sides of the altar."
    },
    {
      "verse": "13",
      "text": "The priests gave the pieces of the animal, including the head, to Aaron. Aaron burnt them on the altar."
    },
    {
      "verse": "14",
      "text": "He washed the inside parts and the legs. He burnt them on the altar on top of the burnt offering."
    },
    {
      "verse": "15",
      "text": "Aaron brought the goat. This was the people's sacrifice to God. Aaron killed it and he burnt it on the altar. It was an offering to atone for the people's sin. He offered this sacrifice in the same way as the first sacrifice for sin."
    },
    {
      "verse": "16",
      "text": "Aaron brought the other young cow. He killed it and he burnt it on the altar. He did it as Moses had told him."
    },
    {
      "verse": "17",
      "text": "He also brought the grain offering. He took some of it and he burnt it on the altar. He burnt it with the morning sacrifice."
    },
    {
      "verse": "18",
      "text": "Aaron killed the bull and the male sheep. These were friendship offerings from the people. The priests brought the blood to him. He threw it onto the sides of the altar."
    },
    {
      "verse": "19",
      "text": "Aaron took the fat tail, the fat and the kidneys and the best piece of the liver."
    },
    {
      "verse": "20",
      "text": "He put them on the meat of the animal's ribs. Then he burnt the fat on the altar."
    },
    {
      "verse": "21",
      "text": "Aaron lifted up the meat as an offering to the Lord. Moses had told him that he must do this."
    },
    {
      "verse": "22",
      "text": "When Aaron had finished burning the gifts, he lifted up his hands over the people. He had sacrificed the sin offering, the burnt offering and the friendship offering. Then he asked God to do good things for the people. And Aaron came down from the altar."
    },
    {
      "verse": "23",
      "text": "Moses and Aaron went into the Tent of Meeting. When they came out, they asked God to do good things for the people. The bright light from the Lord appeared to the people to show how great he is."
    },
    {
      "verse": "24",
      "text": "Then the Lord sent a fire to show that he accepted the gifts. It completely burnt all the fat and the offerings that were on the altar. The people were very happy when they saw this. They shouted and they fell down with their faces to the ground."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "Nadab and Abihu were sons of Aaron. They put hot material in the pots that they used to burn incense. They threw incense over the hot material. They offered the incense to the Lord. This was a wrong thing to do. The Lord had not told them that they should do it. So it was wrong. “People may come near to me. But those people must see that I am holy. All the people must give honour to me. ” ’ Aaron did not reply."
    },
    {
      "verse": "2",
      "text": "The Lord was angry and he sent fire to burn them. They died there in front of the Lord's altar."
    },
    {
      "verse": "3",
      "text": "Then Moses said to Aaron, ‘This is what the Lord said, “People may come near to me. But those people must see that I am holy. All the people must give honour to me. ” ’Aaron did not reply."
    },
    {
      "verse": "4",
      "text": "Mishael and Elzaphan were sons of Aaron's father's brother, Uzziel. Moses said to them, ‘Carry Nadab and Abihu away from the altar. Take your cousins outside the camp. ’"
    },
    {
      "verse": "5",
      "text": "Nadab and Abihu were still wearing their robes. Mishael and Elzaphan carried Nadab and Abihu outside the camp. Moses had told them that they must do that."
    },
    {
      "verse": "6",
      "text": "Moses said to Aaron and to his sons, ‘Comb your hair. Do not tear your clothes. If you do that, you will die. And the Lord will be angry with all the people. But Israel's people can show that they are sad. They are sad because the Lord has killed Nadab and Abihu with fire."
    },
    {
      "verse": "7",
      "text": "If you go away from the door of the Tent of Meeting you will die. You will die because the Lord's holy oil is on you. ’ So Aaron and his sons did as Moses had said."
    },
    {
      "verse": "8",
      "text": "The Lord then said to Aaron,"
    },
    {
      "verse": "9",
      "text": "‘Do not drink wine before you go into the Tent of Meeting. And do not drink anything that contains alcohol. If you do, you will die. This rule is for you and for all your sons and grandsons."
    },
    {
      "verse": "10",
      "text": "You must know what is holy. And you must know what is not holy. You must know what you can use. And you must know what you must not use to worship me."
    },
    {
      "verse": "11",
      "text": "You must teach Israel's people all the rules that I, the Lord, gave to them by Moses. ’"
    },
    {
      "verse": "12",
      "text": "Moses said to Aaron and to his two other sons Eleazar and Ithamar, ‘The grain offering is most holy. Take the part that you did not burn in front of the Lord. And make it into bread. Do not use yeast. Take it to the side of the altar and eat it."
    },
    {
      "verse": "13",
      "text": "Eat it in a holy place. The Lord has said that it is your part of the grain offering. It is for you and for your sons."
    },
    {
      "verse": "14",
      "text": "You and your sons and daughters can eat the meat of the ribs that you held up to God. And all your family can eat the top part of the leg. Eat the meat in a place that is clean and ready for God's use. It is your part of the people's friendship offering."
    },
    {
      "verse": "15",
      "text": "Bring the top of the leg and the meat of the ribs. Lift them up to the Lord. The Lord has given them to you and to your children. Lift them up with the fat parts of the burnt offering. He told you that you should do this. ’"
    },
    {
      "verse": "16",
      "text": "Moses looked for the goat that was to atone for the people's sin. Moses was angry with Eleazar and Ithamar, sons of Aaron. He was angry because they had burnt the goat."
    },
    {
      "verse": "17",
      "text": "Moses said to them, ‘This gift was for the Lord. It was a very holy gift. It was to atone for the people's sins. Why did you not take it to the holy place and eat it?"
    },
    {
      "verse": "18",
      "text": "You did not bring the blood into the holy place. I told you that you must eat its meat in the Tent of Meeting. ’"
    },
    {
      "verse": "19",
      "text": "Aaron said to Moses, ‘My sons sacrificed their gifts to the Lord today. But very bad things have happened to me today. I would not have given the Lord any pleasure if I had eaten the sin offering today. ’"
    },
    {
      "verse": "20",
      "text": "When Moses heard this, he was not angry any longer."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "The Lord said to Moses and Aaron,"
    },
    {
      "verse": "2",
      "text": "‘Some animals walk on the land. Tell Israel's people which of these animals they can eat."
    },
    {
      "verse": "3",
      "text": "Each foot on the animal must have two separate parts. The animal must eat its food and then it must bring the food back into its mouth. And then it must eat the food again. Some animals eat their food twice and they have feet with two parts. You can eat those animals."
    },
    {
      "verse": "4",
      "text": "Some animals have feet that have two separate parts. But they do not eat their food twice. Other animals eat their food twice. But their feet do not have two separate parts. You must not eat those animals. The camel eats its food twice. But its feet are not in two separate parts. The people must not eat the camel."
    },
    {
      "verse": "5",
      "text": "The rock badger eats its food twice. But its feet are not in two separate parts. They must not eat the rock badger."
    },
    {
      "verse": "6",
      "text": "The rabbit eats its food twice. But its feet are not in two separate parts. They must not eat the rabbit."
    },
    {
      "verse": "7",
      "text": "The pig's feet are in two parts. But when the pig eats its food, it does not bring the food back into its mouth. It does not eat it twice. The people must not eat the pig."
    },
    {
      "verse": "8",
      "text": "They must not touch the dead bodies of those animals. They must not eat their meat. They are not clean for you to eat."
    },
    {
      "verse": "9",
      "text": "They can eat some animals that live in the sea or in the river. Those animals must have fins and scales on their bodies."
    },
    {
      "verse": "10",
      "text": "They must not eat any other animals from the sea or the river. They must keep away from them."
    },
    {
      "verse": "11",
      "text": "They must not touch the dead bodies of the animals from the sea or the river. They must not eat the meat from those other animals."
    },
    {
      "verse": "12",
      "text": "Animals from the sea and the river may have fins and scales on their bodies. Those are the only ones that you can eat. Those without fins or scales are unclean."
    },
    {
      "verse": "13",
      "text": "They must not eat some birds because they are not clean. They must not eat either the eagle or the vulture."
    },
    {
      "verse": "14",
      "text": "They must not eat the buzzard or the kite."
    },
    {
      "verse": "15",
      "text": "They must not eat the raven."
    },
    {
      "verse": "16",
      "text": "They must not eat any owl, seagull or hawk."
    },
    {
      "verse": "17",
      "text": "They must not eat the cormorant."
    },
    {
      "verse": "18",
      "text": "They must not eat the osprey."
    },
    {
      "verse": "19",
      "text": "They must not eat the heron, the hoopoe or the bat. The people must not eat them nor touch their dead bodies. They are not clean."
    },
    {
      "verse": "20",
      "text": "Some insects fly in the air and walk on the ground. The people must not eat them."
    },
    {
      "verse": "21",
      "text": "Some insects can fly. And they have legs that can jump. They can eat those insects."
    },
    {
      "verse": "22",
      "text": "They can eat any of these. They include the locust, the cricket and the grasshopper."
    },
    {
      "verse": "23",
      "text": "They must not eat any other flying insect that has legs."
    },
    {
      "verse": "24",
      "text": "A person may touch the dead body of an animal that is not clean. If he does, that person is not clean either. They must keep him separate from the other people until the evening."
    },
    {
      "verse": "25",
      "text": "He must wash his clothes immediately."
    },
    {
      "verse": "26",
      "text": "An animal might not have feet that are in two separate parts. It is wrong to touch the dead body of this animal. Some animals do not bring food back into their mouths and eat it again. It is wrong to touch the dead bodies of these animals."
    },
    {
      "verse": "27",
      "text": "Some animals walk on four feet. It is wrong to touch the dead body of an animal that has paws."
    },
    {
      "verse": "28",
      "text": "A person who picks up the dead body of these animals must wash his clothes immediately. They must keep him separate from the people until the evening."
    },
    {
      "verse": "29",
      "text": "Some animals that walk on the ground are not clean. You must not touch a weasel, a rat or a mouse."
    },
    {
      "verse": "30",
      "text": "You must not touch any kind of lizard."
    },
    {
      "verse": "31",
      "text": "A person might touch the dead body of one of those animals. If he does, he will not be clean. So they must keep him separate from the people until evening."
    },
    {
      "verse": "32",
      "text": "A dead animal may fall onto something that someone made from wood, cloth or skin. That thing becomes unclean. A person must put it into water until the evening. Then it will be clean."
    },
    {
      "verse": "33",
      "text": "A dead animal might fall into a pot. Then the pot and the things in it are not clean. The person must break the pot."
    },
    {
      "verse": "34",
      "text": "The food or water from the pot is not clean. A person must not drink it or eat any of that food. Water from the pot may have touched some food. If it did, that food is not clean. You must not eat it."
    },
    {
      "verse": "35",
      "text": "If a dead animal falls onto a cooking pot, then the pot is not clean. You must break the pot."
    },
    {
      "verse": "36",
      "text": "If a dead animal falls into a fresh water stream, the stream stays clean. The pot that a person uses to get fresh water from the stream is clean."
    },
    {
      "verse": "37",
      "text": "If a dead animal falls onto some seeds, they stay clean."
    },
    {
      "verse": "38",
      "text": "A person might pour water on the seeds. A dead animal might fall on the wet seeds. Then those seeds are not clean."
    },
    {
      "verse": "39",
      "text": "An animal that is good for food might die. A man might touch its dead body. If he does, they must keep him separate from the people until the evening."
    },
    {
      "verse": "40",
      "text": "If a person eats meat from the body of the dead animal, he must wash his clothes. He will not be clean until the evening. If a person picks up the body of the dead animal, he must wash his clothes. He will not be clean until the evening."
    },
    {
      "verse": "41",
      "text": "The people must not eat small animals that move across the ground."
    },
    {
      "verse": "42",
      "text": "This means animals that pass across the ground on their stomachs. It also means animals that walk on four legs or many legs."
    },
    {
      "verse": "43",
      "text": "The people must not touch them or eat them."
    },
    {
      "verse": "44",
      "text": "God says, “I am the Lord your God. I am holy. Make yourselves holy. Do not touch any small animal that moves across the ground. If you do, you will not be clean or holy"
    },
    {
      "verse": "45",
      "text": "I am the Lord who brought you away from Egypt. I became your God. So be holy because I am holy. ” ’"
    },
    {
      "verse": "46",
      "text": "These rules are about animals, birds and all animals that move in water or on the ground."
    },
    {
      "verse": "47",
      "text": "The people must learn to know which animals are clean. They must recognize which animals they can eat. And they must recognize which animals they must not eat."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Say this to Israel's people. When a boy is born, his mother is not clean for seven days. When she is bleeding each month, the rule is the same. She is not clean."
    },
    {
      "verse": "3",
      "text": "Eight days after he is born, they must circumcise the boy."
    },
    {
      "verse": "4",
      "text": "days after the boy is born. All this time she must not touch anything that is holy. She must not go into the Tent of Meeting. After this time, she will become clean."
    },
    {
      "verse": "5",
      "text": "After a girl is born, her mother will not be clean for two weeks. The rule is the same as for each month, when she is bleeding. She will not be clean then. She must wait 66 days after a girl is born. Then she will become clean."
    },
    {
      "verse": "6",
      "text": "When the days to wait are finished, the woman must come to the door of the Tent of Meeting. She must bring to the priest a sheep that is one year old for a burnt offering. And she must bring a bird for a sin offering. The bird must be a pigeon or a dove. These are gifts to God."
    },
    {
      "verse": "7",
      "text": "The priest will offer the gifts to the Lord. Then the woman will become clean. These are the rules at the birth of a boy or of a girl."
    },
    {
      "verse": "8",
      "text": "If the woman does not have money to buy a sheep she can give two doves or pigeons. The priest will use one bird for a sin offering and he will burn the other one. That is how he will make atonement for her. Then she will be clean. ’"
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "The Lord said to Moses and Aaron,"
    },
    {
      "verse": "2",
      "text": "‘A person may have a kind of mark on his skin that might be a disease. He might give the disease to other people. If he has a mark like that, you must bring him to the priest."
    },
    {
      "verse": "3",
      "text": "The priest must look at the mark. If the hair on the mark is white, it might be a disease. If the mark is under the skin and on the skin it might be a disease. The priest must say that the person is not clean."
    },
    {
      "verse": "4",
      "text": "If the mark on the skin is white but not under the skin it might not be a disease. If the hair on the skin is not white, it might not be a bad disease. The priest must keep him separate from the people for seven days."
    },
    {
      "verse": "5",
      "text": "On the seventh day, the priest must look at the person. The mark may not be any bigger. If it is not, he must keep the person separate from the people for seven more days."
    },
    {
      "verse": "6",
      "text": "On the seventh day, the priest must look at the person. The mark may not be so dark and it may not be any bigger. The priest can say that the disease has left that person. The person must wash his clothes."
    },
    {
      "verse": "7",
      "text": "A person might see that the mark on his skin had grown. This might happen after the priest had said that the disease had left him. Then the person must go again to the priest."
    },
    {
      "verse": "8",
      "text": "The priest must look at the person. The mark might be bigger. The priest must say that the person has a disease. It is a disease that he could give to other people."
    },
    {
      "verse": "9",
      "text": "If a person has a disease on his skin, you must bring him to the priest."
    },
    {
      "verse": "10",
      "text": "The priest must look at the person. If the skin has a white mark and white hair on it, the person has a disease. If the mark has no skin on part of it, the person has a disease. But it may not be a disease that he could give to other people."
    },
    {
      "verse": "11",
      "text": "The priest must say that the person is not clean. The priest need not keep him separate from the people. He already has a disease."
    },
    {
      "verse": "12",
      "text": "If the disease is all over the body of the person, the priest must look at the person."
    },
    {
      "verse": "13",
      "text": "If the skin is all white the priest must say that the person is clean."
    },
    {
      "verse": "14",
      "text": "If there is an open hole in the skin, the person is not clean."
    },
    {
      "verse": "15",
      "text": "The priest will see the hole in the skin. He must say that the person has a disease."
    },
    {
      "verse": "16",
      "text": "The hole might close up and the skin might go white. If it does, the person must go to the priest."
    },
    {
      "verse": "17",
      "text": "The priest must look at the skin. It may be white. The priest must say that the disease has left the person. Then he will be clean."
    },
    {
      "verse": "18",
      "text": "A person might have a boil on his skin. Then it might get better."
    },
    {
      "verse": "19",
      "text": "If there is still a red or white mark on the skin, the person must go to the priest."
    },
    {
      "verse": "20",
      "text": "The priest must look at the person's skin. The red mark might be under the skin and the hair on the skin might be white. Then the priest must say that the person has a disease. The person is not clean."
    },
    {
      "verse": "21",
      "text": "If the red mark is not under the skin, it might not be a bad disease. There may not be any white hair on the red mark and the mark may be less red. If that is true, it might not be a bad disease. The priest must keep the person separate from the people for seven days."
    },
    {
      "verse": "22",
      "text": "If the red mark becomes bigger, the priest must say that the person has a bad disease."
    },
    {
      "verse": "23",
      "text": "If the red mark is not becoming bigger, the disease is getting better. It is a mark that remains on the skin from the boil. The priest must say that the person is now clean again."
    },
    {
      "verse": "24",
      "text": "A person who has burnt his skin might have a red or white mark. It might be where he burnt himself."
    },
    {
      "verse": "25",
      "text": "The priest must look at him. If the hair on the mark is white, it is a disease. If the mark is under the skin and on the skin, it is a disease. The priest must say that the person is not clean. He might give the disease to other people."
    },
    {
      "verse": "26",
      "text": "There may not be any white hair and the mark may not be under the skin. The disease is leaving the person. Then the priest must keep him separate from the people for seven days."
    },
    {
      "verse": "27",
      "text": "On the seventh day, the priest must look at the person. If the mark is getting bigger, it is a disease. The priest must say that the person is not clean."
    },
    {
      "verse": "28",
      "text": "If the mark is getting smaller, it is not a disease. The mark is because the person burnt himself. The priest must say that the person is clean."
    },
    {
      "verse": "29",
      "text": "A person may have a mark that hurts on his head."
    },
    {
      "verse": "30",
      "text": "The priest must look at the mark. The mark may be under the skin and on the skin, and it may have thin yellow hair on it. That is a bad disease. He could give that disease to other people. The priest must say that the person is not clean."
    },
    {
      "verse": "31",
      "text": "If the mark is not under the skin, it might not be a bad disease. If there is not any black hair on the mark, it might not be a disease. The priest must keep that person separate from the people for seven days."
    },
    {
      "verse": "32",
      "text": "On the seventh day, the priest must look at the mark that is hurting. The mark might not be under the skin. There might not be any yellow hair on it."
    },
    {
      "verse": "33",
      "text": "The person must cut the hair off his head. He must not cut the hair off where the mark is. Then the priest must keep the person separate from everyone else for seven more days."
    },
    {
      "verse": "34",
      "text": "On the seventh day, the priest must look at the mark that is hurting. The mark may be no bigger and not under the skin. The priest can say that the person is clean. The person must wash his clothes."
    },
    {
      "verse": "35",
      "text": "The mark might get bigger after the priest has said that the disease has left the person."
    },
    {
      "verse": "36",
      "text": "The priest must look at the mark. If it is bigger, he need not look for yellow hair. The person is not clean."
    },
    {
      "verse": "37",
      "text": "The mark may be no bigger and black hair may have grown on it. If that is true, the disease has left the person."
    },
    {
      "verse": "38",
      "text": "If a person has white marks on his skin,"
    },
    {
      "verse": "39",
      "text": "the priest must look at the marks. If the colour of the marks is not bright, it is not a disease. The person is clean."
    },
    {
      "verse": "40",
      "text": "The hair may fall from the head of a man until he is bald. That man remains clean."
    },
    {
      "verse": "41",
      "text": "If the hair falls from the front of the man's head, it is bald. The man is clean."
    },
    {
      "verse": "42",
      "text": "If the man has a red and white mark on his bald head, it is a disease."
    },
    {
      "verse": "43",
      "text": "The priest must look at the red and white mark on the bald head."
    },
    {
      "verse": "44",
      "text": "The priest must say that the man has a disease. It is a disease that he might give to other people,"
    },
    {
      "verse": "45",
      "text": "A person with this disease must tear his clothes. He must not comb his hair. He must cover the lower part of his face. He must shout, “I am not clean. ”"
    },
    {
      "verse": "46",
      "text": "He must be alone all the time that he has a disease. He must live outside the camp."
    },
    {
      "verse": "47",
      "text": "Clothes might become bad because of mildew."
    },
    {
      "verse": "48",
      "text": "People might have made the clothes from wool, linen or leather."
    },
    {
      "verse": "49",
      "text": "If the mark in the clothes is green or red, the mildew is growing. People must show these clothes to the priest."
    },
    {
      "verse": "50",
      "text": "The priest must look at the mildew. And he must keep the clothes separate from other clothes for seven days."
    },
    {
      "verse": "51",
      "text": "On the seventh day, the priest must look at the clothes. If the disease is getting bigger, the person must not wear them."
    },
    {
      "verse": "52",
      "text": "The priest must burn the wool, leather or linen clothes. They have a disease that will destroy them."
    },
    {
      "verse": "53",
      "text": "When the priest looks at the clothes, the mildew might not be getting bigger."
    },
    {
      "verse": "54",
      "text": "He must tell the people that they must wash the clothes. The people must keep these clothes separate from their other clothes for seven more days."
    },
    {
      "verse": "55",
      "text": "The priest will look at the clothes after the people have washed them. If the mildew still seems the same, the people must not wear the clothes. The people must burn the clothes whether the mark is inside or outside them."
    },
    {
      "verse": "56",
      "text": "The colour of the mark might be less bright, after the people have washed the clothes. If it is, the priest must tear the marked part out of the clothes."
    },
    {
      "verse": "57",
      "text": "If the mildew comes back to the clothes, the people must burn them."
    },
    {
      "verse": "58",
      "text": "If there is no mildew in the washed clothes, the people must wash the clothes again. Then the clothes will be clean. ’"
    },
    {
      "verse": "59",
      "text": "These are the rules for mildew in linen cloth. They are rules for wool or leather clothes. They tell the priest how to know whether they are clean or not clean."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘These rules are for a person who has had a disease on his skin. They are rules about how to make him clean. When the disease leaves the person, you must bring him to the priest."
    },
    {
      "verse": "3",
      "text": "The priest must go outside the camp and he must look at the person. If the disease has gone away,"
    },
    {
      "verse": "4",
      "text": "he must speak to the person. He must tell the person that he must bring two birds. They must be birds that are good for food. The birds must be alive. They must also bring wood from the cedar tree, red wool and some hyssop."
    },
    {
      "verse": "5",
      "text": "The priest will bring a pot with water in it. He will hold one of the birds over the pot and he will kill it."
    },
    {
      "verse": "6",
      "text": "The priest will take the other bird and the wood from the cedar tree. He will take the red wool and the hyssop. He will put all of them into the blood of the dead bird."
    },
    {
      "verse": "7",
      "text": "The priest will shake the blood over the person who had the disease. He will do this seven times. The priest will then say that the person is clean. The priest will let the live bird go. It will fly away."
    },
    {
      "verse": "8",
      "text": "The person who had the disease must wash his clothes. He must wash his body with water and he must cut off all his hair. Then he will be clean. He can go into the camp. But he must stay outside the home that he has made from animal skins for seven days."
    },
    {
      "verse": "9",
      "text": "On day seven, he must cut all the hair off his head and his face. He must wash his clothes and his body with water."
    },
    {
      "verse": "10",
      "text": "On the eighth day, the person must bring two young male sheep and one female sheep. The female sheep must be one year old. Both the animals must be perfect. He must also bring three tenths (3/10) of an ephah of flour (about six litres) mixed with oil. And he must bring a cup of olive oil."
    },
    {
      "verse": "11",
      "text": "The priest who is making him clean must be there. He must bring the person to the door of the Tent of Meeting. The person must bring with him his offerings to the Lord."
    },
    {
      "verse": "12",
      "text": "The priest must take one of the male sheep and the oil. He must lift them up to the Lord as a gift."
    },
    {
      "verse": "13",
      "text": "He must kill the sheep at the north side of the altar. That is where they kill the sin offering and the burnt offering. The gift is holy. It is food for the priests."
    },
    {
      "verse": "14",
      "text": "The priest must put some of the blood on the lowest part of the person's right ear. He must put blood on the thumb of the person's right hand. And he must put blood on the big toe of the person's right foot."
    },
    {
      "verse": "15",
      "text": "The priest must pour some of the oil into his own left hand."
    },
    {
      "verse": "16",
      "text": "He must put a finger from his right hand into the oil. He must shake the oil seven times in front of the Lord's altar."
    },
    {
      "verse": "17",
      "text": "The priest must put oil on the lowest part of the person's right ear. He must put some of the oil on the thumb of the person's right hand. He must put some of the oil on the big toe of the person's right foot. He will put the oil on top of the offering's blood."
    },
    {
      "verse": "18",
      "text": "The priest must put the oil that he did not use on the person's head. This makes his atonement in front of the Lord."
    },
    {
      "verse": "19",
      "text": "Then the priest must offer the sin offering. That will make atonement for the man who will become clean. Then the priest must kill another sheep. It is a burnt offering."
    },
    {
      "verse": "20",
      "text": "The priest must sacrifice the dead animal. It is a burnt offering. The priest must offer it on the altar. He must burn the flour and the oil with it on the altar. All this will make atonement for the person. This makes the person who had the disease clean."
    },
    {
      "verse": "21",
      "text": "If the person is poor, he must bring one young male sheep. And he must bring a tenth of an ephah of flour (about 2 litres) mixed with oil. And he must give a cup of olive oil. The priest must lift them to the Lord."
    },
    {
      "verse": "22",
      "text": "The person must also bring two birds. They must be doves or pigeons. These will be his gift. One bird is for a sin offering and the other one is for a burnt offering."
    },
    {
      "verse": "23",
      "text": "On the eighth day, the person must bring his gifts to the Lord. He must bring them to the door of the Tent of Meeting."
    },
    {
      "verse": "24",
      "text": "The priest will take the young sheep and the oil and he will lift them up to the Lord."
    },
    {
      "verse": "25",
      "text": "He will kill the sheep. He will put some of its blood on the lowest part of the person's ear. He will put the blood on the thumb of the person's right hand. He will put the blood on the big toe of the person's right foot."
    },
    {
      "verse": "26",
      "text": "The priest will pour some of the oil into his own left hand."
    },
    {
      "verse": "27",
      "text": "He will put a finger from his right hand into the oil. He will shake it seven times in front of the Lord's altar."
    },
    {
      "verse": "28",
      "text": "He will put oil from his hand on the lowest part of the person's ear. He will also put oil on the thumb of the person's right hand. He will put oil on the big toe of the person's right foot."
    },
    {
      "verse": "29",
      "text": "The priest will put the oil that he did not use on the person's head. Then the Lord can see that he is clean."
    },
    {
      "verse": "30",
      "text": "The priest will kill the pigeons or doves."
    },
    {
      "verse": "31",
      "text": "One bird is for a sin offering. The priest will burn the other bird with the grain offering. This is how the priest will make atonement in front of the Lord. He will do it for the person who was not clean."
    },
    {
      "verse": "32",
      "text": "These are the rules for a person who had a disease in his skin. They are for a disease that he might give to other people. They are for people who are too poor to buy three sheep. ’"
    },
    {
      "verse": "33",
      "text": "The Lord said to Moses and Aaron,"
    },
    {
      "verse": "34",
      "text": "‘Canaan is my gift to you, to belong to you for ever. When you go into that land, I may put a disease called mildew in a house there."
    },
    {
      "verse": "35",
      "text": "If a person finds mildew in his house, he must tell the priest. He must say, “I have found something like mildew in my house. ”"
    },
    {
      "verse": "36",
      "text": "The priest will tell the person what he should do. The person must take everything out of the house. If he does, those things will still be clean. Then the priest will go into the house."
    },
    {
      "verse": "37",
      "text": "He will look at the walls of the house. He will look for a green or red mark. If the mark goes into the wall,"
    },
    {
      "verse": "38",
      "text": "the priest will leave the house. He will shut it up for seven days."
    },
    {
      "verse": "39",
      "text": "On the seventh day, the priest will return to the house. The mildew may be bigger."
    },
    {
      "verse": "40",
      "text": "The priest must say, “You must remove the stones that have mildew. ” The person must put the stones outside the town. He must put them in a special place."
    },
    {
      "verse": "41",
      "text": "The person must cut the clay from inside the walls of the house. The person must put the clay from the walls outside the town. The person must put it in a place for things that are not clean."
    },
    {
      "verse": "42",
      "text": "The person who lives in the house must get some more stones. He must get some more clay. Then he can mend the wall."
    },
    {
      "verse": "43",
      "text": "A person might find mildew on the wall that he has mended. He must tell the priest."
    },
    {
      "verse": "44",
      "text": "The priest will look at the house. If the mildew is on more of the mended wall, the house is not clean."
    },
    {
      "verse": "45",
      "text": "The person must break the house into pieces. The person who lives in the house must put the stones outside the town. He must put the wood and the clay outside the town. He must put them in the place for things that are not clean."
    },
    {
      "verse": "46",
      "text": "A person may go into the house while it is shut up. If he does, he will not become clean until evening."
    },
    {
      "verse": "47",
      "text": "Any person who sleeps in a house with mildew must wash his clothes. And any person who eats in a house with mildew must wash his clothes."
    },
    {
      "verse": "48",
      "text": "If a person mends his house, the priest must look at it. There may not be any mildew. The priest will then say that it is clean."
    },
    {
      "verse": "49",
      "text": "The person must take two birds and some wood from the cedar tree. He must take red wool and hyssop."
    },
    {
      "verse": "50",
      "text": "The priest will bring a pot with water in it. He will hold one of the birds over the pot and he will kill it."
    },
    {
      "verse": "51",
      "text": "The priest will take the other bird and the wood from the cedar tree. He will take the red wool and the hyssop. He will put all of them into the blood of the dead bird. He will shake the blood and water over the house seven times. This will make the house clean."
    },
    {
      "verse": "52",
      "text": "The priest will use the birds and the wood from the cedar tree. And he will use the wool and the hyssop to make the house clean."
    },
    {
      "verse": "53",
      "text": "Then the priest will take the living bird outside the town. He will let the bird fly away. That will make atonement for the house. The person may then live in the house again. ’"
    },
    {
      "verse": "54",
      "text": "These are the rules for a disease in a person's skin."
    },
    {
      "verse": "55",
      "text": "These are the rules for mildew in clothes or in a house."
    },
    {
      "verse": "56",
      "text": "These are the rules for a mark on or under the skin."
    },
    {
      "verse": "57",
      "text": "These rules decide when a person has a disease. And they decide when he is clean. They show when a house has a disease. They are the rules for diseases in the skin and for mildew."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "The Lord said to Moses and Aaron,"
    },
    {
      "verse": "2",
      "text": "‘Say to Israel's people, “If pus is coming out of a man's body, he is unclean. ”"
    },
    {
      "verse": "3",
      "text": "The man is unclean if the pus pours. And he is unclean even if it stops pouring."
    },
    {
      "verse": "4",
      "text": "If the man sits on a bed, it becomes unclean. If the man sits on anything, it becomes unclean."
    },
    {
      "verse": "5",
      "text": "A person who touches the bed must wash his clothes and his body. He will be unclean until evening."
    },
    {
      "verse": "6",
      "text": "If anyone sits on anything that he has sat on, they will also become unclean. So they must wash their clothes and their body. They will also be unclean until evening."
    },
    {
      "verse": "7",
      "text": "A person who touches the unclean man must wash his clothes. He must also wash his body. He will be unclean until evening."
    },
    {
      "verse": "8",
      "text": "A man who is unclean might spit on another person. Then the other person must wash his clothes. He must also wash his body. He will be unclean until evening."
    },
    {
      "verse": "9",
      "text": "An unclean man might ride on an animal. The cloth on the back of the animal will become unclean."
    },
    {
      "verse": "10",
      "text": "A person who touches that cloth will be unclean until evening. If a person picks up that cloth, he must wash his clothes. He must also wash his body. He will be unclean until evening."
    },
    {
      "verse": "11",
      "text": "The unclean man might not wash his hands but then he touches another person. The person that he touched becomes unclean. That person must wash his clothes and his body. He will be unclean until evening."
    },
    {
      "verse": "12",
      "text": "If the unclean man touches a clay pot, you must break it. Or he may touch a thing that someone has made from wood. If he touches it, you must wash that thing."
    },
    {
      "verse": "13",
      "text": "The pus may stop coming out of a person. When it does, he must count seven days. He must wash his clothes and his body with fresh water. Then the man will be clean."
    },
    {
      "verse": "14",
      "text": "On the eighth day, he must come in front of the Lord. He must take two birds to the door of the Tent of Meeting. They must be doves or pigeons. He must give them to the priest."
    },
    {
      "verse": "15",
      "text": "The priest will sacrifice them. One bird is for a sin offering and the other is for a burnt offering. They are an atonement to the Lord. Then the man will be clean."
    },
    {
      "verse": "16",
      "text": "When semen comes out of a man, he must wash his body. He will be unclean until evening."
    },
    {
      "verse": "17",
      "text": "You must wash any clothes that semen touches. They are unclean until evening."
    },
    {
      "verse": "18",
      "text": "A man might lie with a woman. If semen comes out of him, they are both unclean. They must wash their bodies. They will be unclean until evening."
    },
    {
      "verse": "19",
      "text": "A woman will bleed every month. She is unclean for seven days. A person might touch the woman when she is bleeding. That person will remain unclean until evening."
    },
    {
      "verse": "20",
      "text": "The woman who is bleeding might lie on a bed. The bed will become unclean. If the woman sits on something, it becomes unclean."
    },
    {
      "verse": "21",
      "text": "If another person touches the bed, he must wash his clothes and his body. He will be unclean until evening."
    },
    {
      "verse": "22",
      "text": "Another person might sit on the thing that she sat on. That person must wash his clothes and his body. He will be unclean until evening."
    },
    {
      "verse": "23",
      "text": "A person might touch anything that the woman sat on. If he does, he is unclean until evening."
    },
    {
      "verse": "24",
      "text": "A man might lie down with a woman. If her blood touches him, he is unclean for seven days. Any bed that the man lies on becomes unclean."
    },
    {
      "verse": "25",
      "text": "If a woman is bleeding for more than seven days, she is unclean. She is unclean all the time that she is bleeding."
    },
    {
      "verse": "26",
      "text": "The bed that the woman lies on becomes unclean. Anything that the woman sits on is unclean."
    },
    {
      "verse": "27",
      "text": "If another person touches the chair, he becomes unclean. He must wash his clothes and his body. He will be unclean until evening. If another person touches the bed, he will also become unclean. He must wash his clothes and his body. He will be unclean until evening."
    },
    {
      "verse": "28",
      "text": "When the woman stops bleeding, she must count seven days. Then she will be clean."
    },
    {
      "verse": "29",
      "text": "On the eighth day, she must take two birds to the door of the Tent of Meeting. They must be doves or pigeons. She must give them to the priest. He will sacrifice one bird for her sin and he will burn the other."
    },
    {
      "verse": "30",
      "text": "He will kill them as an atonement to the Lord. Then the woman will be clean."
    },
    {
      "verse": "31",
      "text": "The tabernacle is God's house. It is among Israel's people. The priests must keep the people away from anything that makes them unclean. If they are not clean, they will make the Tent of Meeting unclean. So they will die. ’"
    },
    {
      "verse": "32",
      "text": "These are the rules when pus or semen come from a man's body."
    },
    {
      "verse": "33",
      "text": "These are the rules for a woman when she bleeds each month. These are the rules for a man who has sex with an unclean woman."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "The Lord spoke to Moses after the two sons of Aaron died. The gift that they gave to the Lord was not holy. So they died."
    },
    {
      "verse": "2",
      "text": "The Most Holy Place in the Tent of Meeting is behind the curtain. The Lord said to Moses, ‘Your brother Aaron cannot go behind the curtain at any time that he wants to. Tell him that. The Lord appears in a cloud over the lid of the Covenant Box. So Aaron will die if he does not obey the Lord."
    },
    {
      "verse": "3",
      "text": "This is how Aaron must go into the Most Holy Place. He must bring a young bull for a sin offering. He must also bring a male sheep for a burnt offering."
    },
    {
      "verse": "4",
      "text": "He must wash his body before he puts on his special clothes. He must wear his linen robe and linen clothes next to his body. They are holy. He must tie a linen belt round his body. He must put the linen hat on his head. These clothes are holy."
    },
    {
      "verse": "5",
      "text": "He must take two male goats for a sin offering. And he must take a male sheep for a burnt offering. They are a gift from Israel's people."
    },
    {
      "verse": "6",
      "text": "Aaron must offer the bull as an atonement to the Lord for himself, his family and his servants."
    },
    {
      "verse": "7",
      "text": "He must take the two goats to the door of the Tent of Meeting. They are a gift to the Lord."
    },
    {
      "verse": "8",
      "text": "He must use the special stones. They will help him to decide what he should do. He must decide which goat is for the Lord. And he must decide which goat he must send away."
    },
    {
      "verse": "9",
      "text": "Aaron must take the goat that is for the Lord. And he must kill it. It is a sin offering."
    },
    {
      "verse": "10",
      "text": "He must not kill the other goat. It is an atonement to the Lord. It will pay for the bad things that the people have done. It is to take away the people's punishment. He must send it away into the desert. ’"
    },
    {
      "verse": "11",
      "text": "‘Aaron must bring the bull and he must kill it. It is his atonement for his family's sins."
    },
    {
      "verse": "12",
      "text": "He must take a pot of the hot material. It is burning on the altar in front of the Lord. He must fill his two hands with incense. He must take the hot material and the incense behind the curtain."
    },
    {
      "verse": "13",
      "text": "He must put the incense on the burning material. It is in front of the Lord. The smoke will cover the lid of the Covenant Box. So he will not die."
    },
    {
      "verse": "14",
      "text": "He must take with him blood from the bull. He must use his finger to shake the blood. He must shake it onto the lid of the Covenant Box. He must shake the blood in front of the lid of the Covenant Box. He must shake it seven times with his finger."
    },
    {
      "verse": "15",
      "text": "Aaron must kill the goat for the sin offering. It is a gift from the people. He must take the blood behind the curtain. He must shake the blood on the lid of the Covenant Box as he did with the bull's blood. And he must shake the blood in front of the lid of the Covenant Box."
    },
    {
      "verse": "16",
      "text": "This will make atonement for all the sins of Israel's people. This will make the Holy Place clean. Aaron must do the same for the Tent of Meeting. That is because the people have done bad things in the camp. The Tent of meeting is in the middle of the camp."
    },
    {
      "verse": "17",
      "text": "Aaron must give the offerings to God. He must give them for his family and he must give them for his servants. He must give them for all the people. Nobody can go into the Tent of Meeting while Aaron is in the Most Holy Place. He must be alone when he goes in. And he must be alone until he comes out. He must be alone when he gives the offerings to God. Those offerings make atonement for himself, for his family and for all Israel's people."
    },
    {
      "verse": "18",
      "text": "He must go to the altar that is in front of the Lord. He must make atonement for it. He must take blood from the bull and blood from the goat. He must put the blood on the horns of the altar."
    },
    {
      "verse": "19",
      "text": "He must shake blood on the altar seven times to make it clean."
    },
    {
      "verse": "20",
      "text": "Aaron must first atone for the Most Holy Place, the Tent of meeting and the altar. Then he must bring the goat that is alive."
    },
    {
      "verse": "21",
      "text": "He must put his hands on the goat's head. He must speak aloud all the bad things that Israel's people have done. Then all the bad things will be on the goat's head. Aaron must tell a man that he must send the goat away into the desert."
    },
    {
      "verse": "22",
      "text": "The goat will carry all the sins of the people into the desert. The man must send it away into the desert."
    },
    {
      "verse": "23",
      "text": "Aaron must go into the Tent of Meeting. He must take off his special linen clothes. The holy clothes must stay in the Tent of Meeting."
    },
    {
      "verse": "24",
      "text": "He must wash his body in a holy place. He must put on his own clothes. He must leave the holy place. Then he must sacrifice the burnt offerings. They will make atonement for himself and for the people."
    },
    {
      "verse": "25",
      "text": "And he must also burn the fat from the sin offering on the altar."
    },
    {
      "verse": "26",
      "text": "The person who sent the goat away must wash his clothes and his body. He can return to the camp."
    },
    {
      "verse": "27",
      "text": "Aaron had killed a bull and a goat. He took their blood into the Most Holy Place to make atonement. Someone must carry their dead bodies outside the camp. He must burn them. That man must burn the skin, the meat and the inside parts."
    },
    {
      "verse": "28",
      "text": "The man who burnt the animals must wash his clothes and his body. Then he can return to the camp."
    },
    {
      "verse": "29",
      "text": "On the tenth day of the seventh month, Israel's people must not eat any food. This is a rule that you must obey for all time. The people who are travelling with them must not eat any food. None of them must do any work."
    },
    {
      "verse": "30",
      "text": "This day will make them clean from all their sins. The Lord will see them as clean people. This will be the Day of Atonement."
    },
    {
      "verse": "31",
      "text": "It is a day when you do not eat any food. It is a day of rest. This is a rule from God and you must do this every year."
    },
    {
      "verse": "32",
      "text": "The leader of the priests is a chosen son of Aaron. And he must make atonement. He will put on the special linen clothes that are holy. He will bring the people's offerings."
    },
    {
      "verse": "33",
      "text": "He will make atonement for the Most Holy Place. He will make atonement for the Tent of Meeting. He will make atonement for the altar. He will make atonement for the priests and for all the people."
    },
    {
      "verse": "34",
      "text": "He will make atonement for all the Israelites' sins once every year. This rule is for now and for all time. ’The people did everything in the way that the Lord had commanded Moses."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Tell this to Aaron and his sons and all the people. The Lord has given all these rules."
    },
    {
      "verse": "3",
      "text": "If a person sacrifices a bull, a sheep or a goat in the fields, that is a sin. Or if a person sacrifices it in the camp, that is a sin."
    },
    {
      "verse": "4",
      "text": "The animal is an offering to the Lord. The person should bring it to the door of the tabernacle. He should offer it to the Lord there. The person who offers a sacrifice anywhere else has sinned. He has sacrificed an animal in the wrong way. He must leave the camp."
    },
    {
      "verse": "5",
      "text": "This rule will stop the people giving sacrifices to the Lord in the fields. They must bring their gifts to the priest. They will be friendship offerings to the Lord. The priest will be at the door of the Tent of Meeting."
    },
    {
      "verse": "6",
      "text": "He must shake the blood of the animal on the Lord's altar. That altar is at the door of the Tent of Meeting. The priest must burn the fat. The smell of it while it is burning will give the Lord pleasure."
    },
    {
      "verse": "7",
      "text": "The people give sacrifices in the fields to worship idols that seem like goats. They must never do this again. This rule is for now and for all time."
    },
    {
      "verse": "8",
      "text": "If an Israelite gives a sacrifice or a burnt offering he must offer it at the Tent of Meeting's door. A foreigner may live among you. If he gives a sacrifice he must offer it at the Tent of Meeting's door."
    },
    {
      "verse": "9",
      "text": "If they did not offer it to the Lord at the Tent of Meeting's door, they are sinning. You must send them away from the camp."
    },
    {
      "verse": "10",
      "text": "An Israelite or a foreigner who lives among you must not eat blood. And they must not drink it. If somebody does, God will turn away from him. He will take that person away from his people."
    },
    {
      "verse": "11",
      "text": "The blood of an animal gives it life. You must put the blood on the altar. God has given the blood to you to atone for your sins. It makes your life right again, because of the blood."
    },
    {
      "verse": "12",
      "text": "For this reason, Israel's people must not eat blood. And the people who are travelling with them must not eat blood."
    },
    {
      "verse": "13",
      "text": "A person may catch an animal or a bird that is clean to eat. If he does, he must pour its blood on the ground. He must cover the blood with some earth."
    },
    {
      "verse": "14",
      "text": "The animal's life is in its blood. That is why no Israelite should eat any animal's blood. You must send any person that eats blood away from your people."
    },
    {
      "verse": "15",
      "text": "An Israelite or a foreign person may find a dead animal. If he eats it, he must wash his clothes and his body. He will be unclean until evening. Then he will become clean. A person might find an animal or a bird that a wild animal has killed. He must wash his clothes and his body. He will be unclean until evening."
    },
    {
      "verse": "16",
      "text": "If that person does not wash his clothes and his body, it is his own mistake. ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Tell Israel's people that I am the Lord their God."
    },
    {
      "verse": "3",
      "text": "They were living in Egypt, but they must not do as the people in Egypt do. Now I am bringing them to live in Canaan. They must not live in the way that the people in Canaan live. They must not do the things that those people do."
    },
    {
      "verse": "4",
      "text": "They must obey my rules. I am the Lord their God."
    },
    {
      "verse": "5",
      "text": "If they obey my rules and my laws, they will continue to live safely. I am the Lord."
    },
    {
      "verse": "6",
      "text": "Tell them this: A person must not have sex with anyone who belongs to his own family. I am the Lord."
    },
    {
      "verse": "7",
      "text": "Do not have sex with your mother. That would cause your father to be ashamed."
    },
    {
      "verse": "8",
      "text": "Do not have sex with any wife of your father. Your father would be ashamed."
    },
    {
      "verse": "9",
      "text": "Do not have sex with your sister. Do not have sex with a sister who is your mother's daughter or your father's daughter. It does not matter if she was born in your house or in another house. Do not have sex with any sister."
    },
    {
      "verse": "10",
      "text": "Do not have sex with any granddaughter. That would make you ashamed."
    },
    {
      "verse": "11",
      "text": "Do not have sex with the daughter of your father and his wife. She is your sister."
    },
    {
      "verse": "12",
      "text": "Do not have sex with your father's sister. She is his near relative."
    },
    {
      "verse": "13",
      "text": "Do not have sex with your mother's sister. She is her near relative."
    },
    {
      "verse": "14",
      "text": "Do not have sex with the wife of your father's brother. That would make your uncle ashamed. His wife is your aunt."
    },
    {
      "verse": "15",
      "text": "Do not have sex with your son's wife."
    },
    {
      "verse": "16",
      "text": "Do not have sex with your brother's wife. That would make your brother ashamed."
    },
    {
      "verse": "17",
      "text": "Do not have sex with both a woman and her daughter. Do not have sex with her son's daughter or with her daughter's daughter. They are her near relatives. It would be an evil thing to do."
    },
    {
      "verse": "18",
      "text": "Do not marry your wife's sister as a second wife. If your wife is still alive, do not have sex with her sister."
    },
    {
      "verse": "19",
      "text": "Do not have sex with a woman at the time when she bleeds each month. She is unclean during that time."
    },
    {
      "verse": "20",
      "text": "Do not have sex with the wife of another man. You would become unclean."
    },
    {
      "verse": "21",
      "text": "Do not offer your child as a sacrifice to the false god, Molech. This would spoil God's honour. He is the Lord."
    },
    {
      "verse": "22",
      "text": "A man must not have sex with another man. That is an evil thing to do."
    },
    {
      "verse": "23",
      "text": "Do not have sex with an animal. That would make you unclean. A woman must not offer herself to an animal to have sex with it. She would be doing a disgusting thing."
    },
    {
      "verse": "24",
      "text": "Do not do any of these things. They would make you unclean. The people who live in Canaan do these things. It made them unclean. God will send those people out of their country."
    },
    {
      "verse": "25",
      "text": "Canaan is unclean because the people did these things. This is why God pushed the people out of that land."
    },
    {
      "verse": "26",
      "text": "But you and the foreigners with you must not do these wrong things."
    },
    {
      "verse": "27",
      "text": "The people in Canaan did these bad things and the land became unclean."
    },
    {
      "verse": "28",
      "text": "If you do these bad things, I will push you out of Canaan's land. I will send you away, like the people before you."
    },
    {
      "verse": "29",
      "text": "You must send away any person who does any of these bad things."
    },
    {
      "verse": "30",
      "text": "All the people must obey my rules. They must not do the bad things that the people in Canaan did. If they did them, my people would become unclean. I am the Lord your God. ’"
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Speak to Israel's people. They must be holy because I am holy. You must tell them that."
    },
    {
      "verse": "3",
      "text": "Each person must respect his mother and his father. All the people must keep the Sabbath as a day of rest. I am the Lord your God."
    },
    {
      "verse": "4",
      "text": "You must not worship idols. You must not use metal to make gods for yourselves. I am the Lord your God."
    },
    {
      "verse": "5",
      "text": "When a person sacrifices a friendship offering to the Lord, he must obey the rules. If he does, the Lord will accept the gift."
    },
    {
      "verse": "6",
      "text": "The people must eat the meat on the day that the person offers it. Or they must eat it on the next day. The person must burn any meat that he has not eaten after the second day."
    },
    {
      "verse": "7",
      "text": "On the third day, the meat is not clean."
    },
    {
      "verse": "8",
      "text": "If he eats the meat on the third day he makes unclean a gift that is holy to the Lord. You must send him away from the camp."
    },
    {
      "verse": "9",
      "text": "When a person cuts the plants in his field, he must not cut to the edge of the field. He must not pick up what he drops."
    },
    {
      "verse": "10",
      "text": "If a person grows fruit to make wine, he must not pick all the fruit. He must not pick up the fruit that drops. The fruit that drops is for the poor people. And it is for those who are foreign. I am the Lord your God."
    },
    {
      "verse": "11",
      "text": "You must not take something that belongs to another person. You must not say something that is not true. You must obey my rules."
    },
    {
      "verse": "12",
      "text": "You must not use the name of your God to say a promise. This will make my name unclean. I am the Lord."
    },
    {
      "verse": "13",
      "text": "You must not rob another person. You must not keep a slave's money until the morning."
    },
    {
      "verse": "14",
      "text": "You must not speak bad words against a person who is deaf. You must not put something in front of a blind person, to make them fall down. I am the Lord. Obey me."
    },
    {
      "verse": "15",
      "text": "You must be fair to other people when you judge them. You must not be more kind to a rich person than to a poor person. You must be fair to everyone."
    },
    {
      "verse": "16",
      "text": "You must not speak bad words about other people. If somebody is in danger of death, do not keep quiet if you know the truth. I am the Lord."
    },
    {
      "verse": "17",
      "text": "You must not think bad thoughts about another person. A person may do something that is wrong. You must tell him that he is doing a wrong thing. If you do, you will not be a part of the wrong thing."
    },
    {
      "verse": "18",
      "text": "You must not try to punish a person who has done something wrong against you. You must not continue to hate a person like that. Instead, you must love other people as much you love yourself. I am the Lord."
    },
    {
      "verse": "19",
      "text": "The people must obey God's rules. They must not let two different kinds of animals have sex together. They must not put two different kinds of seeds in one field. They must not make clothes from two different materials."
    },
    {
      "verse": "20",
      "text": "A slave girl belongs to a man. Another man must not have sex with her. If he does, he is doing a wrong thing. But the girl is not free. He has not bought her. You must punish them. But you must not kill them because the girl was not free."
    },
    {
      "verse": "21",
      "text": "The man must bring a male sheep to the door of the Tent of Meeting. It is an offering to the Lord."
    },
    {
      "verse": "22",
      "text": "The priest will sacrifice the gift to the Lord. The sacrifice will atone for the man's sin. Then the Lord will forgive the man."
    },
    {
      "verse": "23",
      "text": "When you go into Canaan, a person may plant a fruit tree there. But he must not eat the fruit for three years."
    },
    {
      "verse": "24",
      "text": "In the fourth year, the fruit is holy. It is an offering to praise the Lord."
    },
    {
      "verse": "25",
      "text": "In the fifth year, the people can eat the fruit. If they do this, the trees will give much fruit to the people. I am the Lord your God."
    },
    {
      "verse": "26",
      "text": "You must not eat any meat that has the blood in it. You must not do magic. You must not use magic to learn about future times."
    },
    {
      "verse": "27",
      "text": "A man must not cut the hair on the sides of his head. He must not cut the edges of his beard."
    },
    {
      "verse": "28",
      "text": "He must not cut his body to remember the dead people. He must not paint his body. I am the Lord your God."
    },
    {
      "verse": "29",
      "text": "He must not sell his daughter for sex. You would make her ashamed. If he does this, all the people might do the same. The whole land would become full of sin."
    },
    {
      "verse": "30",
      "text": "God has said what the people can do on the Sabbath day of rest. On the day of rest, the people must do only those things. They must respect the Lord's house. I am the Lord."
    },
    {
      "verse": "31",
      "text": "They must not ask people who do magic to help them. That would make Israel's people unclean. I am the Lord your God."
    },
    {
      "verse": "32",
      "text": "The people must stand up when they are with old people. They must respect the old people. They must give honour to their God. I am the Lord your God."
    },
    {
      "verse": "33",
      "text": "A foreign person may live in your land. You must be kind to him or to her."
    },
    {
      "verse": "34",
      "text": "People must love the person from a different country as they love themselves. They must remember the time when they lived in Egypt. Egypt was not their country. I am the Lord your God."
    },
    {
      "verse": "35",
      "text": "They must be fair when they measure length or weight or size."
    },
    {
      "verse": "36",
      "text": "They must use correct weights and measures. I am the Lord your God. I led you out of Egypt."
    },
    {
      "verse": "37",
      "text": "They must obey all my rules. I am the Lord. ’"
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Talk to Israel's people. Say, “If any Israelite or foreign person gives his children to the god called Molech, he must die. ” The people must throw stones at him to kill him."
    },
    {
      "verse": "3",
      "text": "I, the Lord, will turn away from that person. I will make him separate from his people. That person did not respect the Lord. He did not respect the Lord's holy name."
    },
    {
      "verse": "4",
      "text": "Israel's people may not think that his sin was important. So they might not kill him."
    },
    {
      "verse": "5",
      "text": "But the Lord himself will become an enemy of the man and of his family. The Lord will send him away with all the people who worship the god called Molech."
    },
    {
      "verse": "6",
      "text": "A person must not ask someone who does magic for help. They are turning away from the Lord. He will send them away from his people."
    },
    {
      "verse": "7",
      "text": "The people must be holy. I am the Lord your God."
    },
    {
      "verse": "8",
      "text": "They must always obey all my rules. I am the Lord who makes them holy."
    },
    {
      "verse": "9",
      "text": "If a person says bad things about his mother or his father, you must kill him. He has destroyed their honour. His sin will cause his death."
    },
    {
      "verse": "10",
      "text": "If a man has sex with another man's wife you must kill him and the woman."
    },
    {
      "verse": "11",
      "text": "A man is sinning if he has sex with his father's wife. You must kill the man and the woman. They have destroyed the father's honour. Their sin causes their death."
    },
    {
      "verse": "12",
      "text": "A man is sinning if he has sex with his son's wife. You must kill them both. They have done a strange thing. Their own sin causes their death."
    },
    {
      "verse": "13",
      "text": "A man is sinning if he has sex with another man. You must kill both of the men. They should be ashamed. Their sin causes their death."
    },
    {
      "verse": "14",
      "text": "A man is sinning if he marries a woman and her mother. You must burn the man and both the women in the fire. Then their sin will not make my people unclean."
    },
    {
      "verse": "15",
      "text": "A man is sinning if he has sex with an animal. You must kill the man and the animal."
    },
    {
      "verse": "16",
      "text": "A woman is sinning if she has sex with an animal. You must kill the woman and the animal. Their sin causes their death."
    },
    {
      "verse": "17",
      "text": "It is a sin if a man marries his sister. She may be the daughter of his father or of his mother. It is a sin if he has sex with her. The people must send them away. He has taken away his sister's honour. He must carry the punishment for his sin."
    },
    {
      "verse": "18",
      "text": "A man must not have sex with a woman when she is bleeding. If he does, it is a sin. They have not obeyed the rules of the Lord. The people must send them away."
    },
    {
      "verse": "19",
      "text": "A man must not have sex with his mother's sister or with his father's sister. They are both doing a wrong thing. They are taking away the family's honour. Their sin causes their punishment."
    },
    {
      "verse": "20",
      "text": "A man is sinning if he has sex with his aunt. He is taking away his father's brother's honour. They will have no children."
    },
    {
      "verse": "21",
      "text": "It makes the people unclean if a man marries his brother's wife. He has taken away his brother's honour. They will not have any children."
    },
    {
      "verse": "22",
      "text": "If the people want to remain in the land that I am giving to them, they must obey my laws and my rules."
    },
    {
      "verse": "23",
      "text": "The people who are living in Canaan now are doing bad things. I, the Lord, hate them because they do these things. I will send them out of Canaan."
    },
    {
      "verse": "24",
      "text": "I, the Lord, will give their land to Israel's people. I will give it to you and to your children to keep for all time. In that land, there is plenty of food and drink, enough for everyone. I am the Lord your God. I want you to be separate from other people."
    },
    {
      "verse": "25",
      "text": "The people must know which animals are clean. And they must know which animals are unclean. They must know which birds are clean. And they must know which birds are unclean. They must not eat any animal or bird that is unclean."
    },
    {
      "verse": "26",
      "text": "I am the Lord and I am holy. So my people must be holy for me. I have made them separate from other people. They belong to me."
    },
    {
      "verse": "27",
      "text": "A man or a woman who uses magic is doing a wrong thing. People must throw stones at that person until they die. Their sin will cause their death. ’"
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "The Lord said to Moses, ‘Say this to the priests. They must not touch a dead body. That would make them unclean."
    },
    {
      "verse": "2",
      "text": "It may be the body of a person from their own family. The priest can touch the dead person if it is his mother or father. He can touch the dead person if it is his son or his daughter or his brother."
    },
    {
      "verse": "3",
      "text": "He can touch the dead person if it is his sister. But he must not touch her if she has a husband."
    },
    {
      "verse": "4",
      "text": "The priest must not touch a dead person who is married to a person of his family. That would make him unclean."
    },
    {
      "verse": "5",
      "text": "A priest must not cut all the hair from his head. He must not cut the sides of his beard. He must not cut his body."
    },
    {
      "verse": "6",
      "text": "A priest must be holy. He must not speak bad words about the Lord. He is the person who sacrifices the people's burnt offerings."
    },
    {
      "verse": "7",
      "text": "A priest must not marry a woman who has left her husband. He must not marry a woman if men have paid her to have sex with her. He must not marry a woman whose husband has sent her away. A priest must be holy."
    },
    {
      "verse": "8",
      "text": "A priest is holy because he sacrifices the people's offerings to God. A priest is holy because I, the Lord, am holy."
    },
    {
      "verse": "9",
      "text": "A priest's daughter must not have sex with men who pay her. That would make her unclean. She would take away her father's honour. If she does not obey, you must burn her in a fire."
    },
    {
      "verse": "10",
      "text": "They have poured special oil on the leader of the priests' head to show that he is greater than his brothers. He must wear special clothes. He must comb his hair. He must not tear his clothes."
    },
    {
      "verse": "11",
      "text": "He must not go into a room where there is a dead body. Even if it is the body of his parent, he must not go in. It will make him unclean."
    },
    {
      "verse": "12",
      "text": "He must not leave the house of God. He has the holy oil on his head. He must be separate. I am the Lord."
    },
    {
      "verse": "13",
      "text": "The leader of the priests must marry a woman who has not had sex before."
    },
    {
      "verse": "14",
      "text": "The woman must not have had a husband who died. She must not have a husband that she has left. Men must not have paid to have sex with her. She must be a woman from Israel's people,"
    },
    {
      "verse": "15",
      "text": "so that their children will be holy. I am the Lord. I make priests holy. ’"
    },
    {
      "verse": "16",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "17",
      "text": "‘Talk to Aaron. Say, “A priest who does not have a perfect body must not sacrifice the burnt offerings to God. ” This rule is for now and for all time."
    },
    {
      "verse": "18",
      "text": "A priest who cannot see must not sacrifice the food to God. A priest who cannot walk must not sacrifice food to God. A priest with a body that is the wrong shape must not offer food to God."
    },
    {
      "verse": "19",
      "text": "A priest with a hand that is the wrong shape must not offer food to God. A priest with a foot that is the wrong shape must not offer food to God."
    },
    {
      "verse": "20",
      "text": "A priest with a back that is not straight must not offer food to God. Neither must a priest who is very small offer a food gift. A priest who has an eye disease or a skin disease must not offer food to God. Neither must a priest offer food if his testicles are spoiled."
    },
    {
      "verse": "21",
      "text": "If a priest's son has something wrong with his body, he must not come near to the altar. He must not give the food offering to the Lord."
    },
    {
      "verse": "22",
      "text": "He can eat God's holy food and God's most holy food."
    },
    {
      "verse": "23",
      "text": "But none of Aaron's family who is not perfect can go near the holy curtain or the altar. He would make the holy places unclean. I am the Lord. I make them holy. ’"
    },
    {
      "verse": "24",
      "text": "Moses told all these rules to Aaron, to his sons and to all Israel's people."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Israel's people give gifts to God. Those gifts are holy. Tell Aaron and his sons that those things are holy. Tell them that they must remember that. They must give honour to my name. I am the Lord."
    },
    {
      "verse": "3",
      "text": "One of your sons may not be clean. That son must not come near the Lord's holy offerings. But perhaps he may not obey my rule. He might go near to the holy gifts. The priests who are clean must punish him. They must send him away. He must go from God's house. I am the Lord. This rule is for now and for all time."
    },
    {
      "verse": "4",
      "text": "If a son of Aaron has a skin disease, he must not eat the holy gifts. If pus is coming from his body, he is not clean. He must not eat the holy offerings until he is clean. He might touch something that has touched a dead body. Or if he touches an unclean man, he will become unclean. The man may be unclean because semen is coming from his body."
    },
    {
      "verse": "5",
      "text": "Aaron's son might touch an animal that moves on its stomach. Or he might touch a person who is not clean. If he does, Aaron's son will be unclean."
    },
    {
      "verse": "6",
      "text": "The son of Aaron who touches any of these things will be unclean until evening. He must not eat any of the holy gifts until he washes his body."
    },
    {
      "verse": "7",
      "text": "When the sun goes down, he will be clean. He can eat the holy gifts. They are his food."
    },
    {
      "verse": "8",
      "text": "He might find something that is dead. He must not eat it. He must not eat anything that an animal has torn. It will make him unclean. I am the Lord."
    },
    {
      "verse": "9",
      "text": "Aaron's sons must obey God's rules. If they do not obey them, it is a sin. They will die. I am the Lord who makes people holy."
    },
    {
      "verse": "10",
      "text": "Only a person who is from the priest's family can eat the holy gifts. Another person who is living in the priest's house must not eat the holy gifts. If a person is being paid to work for the priest, he must not eat the holy gifts."
    },
    {
      "verse": "11",
      "text": "A slave can eat the holy gifts if he was born in the priest's house. Or he can eat the holy gifts if the priest bought him."
    },
    {
      "verse": "12",
      "text": "A priest's daughter might marry a man who is not a priest. If she has done that, she must not eat the holy food."
    },
    {
      "verse": "13",
      "text": "A priest's daughter's husband might send her away. Or her husband might die. She might not have any children. She may go back to live in her father's house. Then she can eat her father's food."
    },
    {
      "verse": "14",
      "text": "A person might make a mistake and eat a holy gift. He must give back to the priest the same food. He must also give one fifth more."
    },
    {
      "verse": "15",
      "text": "The priest must not give the Lord's holy gifts to people who are not from Aaron's family. The gifts would become unclean."
    },
    {
      "verse": "16",
      "text": "If the people eat them they are sinning. They will have to pay for their sin. I am the Lord and I make them holy. ’"
    },
    {
      "verse": "17",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "18",
      "text": "‘Say this to Aaron, to his sons and to all the people. If any person gives a gift to the Lord,"
    },
    {
      "verse": "19",
      "text": "he must give a bull, a sheep or a goat. The gift may be for a promise, or to thank God for something or for a friendship offering. The animal must be perfect."
    },
    {
      "verse": "20",
      "text": "They must not give any animal that is not perfect. The Lord will not accept that animal."
    },
    {
      "verse": "21",
      "text": "When a person brings an animal to the Lord as a special gift, it must be perfect. If it is, God will accept it."
    },
    {
      "verse": "22",
      "text": "A person must not give to the Lord an animal that cannot see. The animal must not have a skin disease. And pus must not be coming from its body. The person must not burn an animal to the Lord on the altar that is not perfect."
    },
    {
      "verse": "23",
      "text": "A person may give a bull or a sheep with a body that is the wrong shape. He can use it as an offering to eat with his friends (friendship offering). But God will not take this animal as a gift for a promise. That gift must be perfect. You must not put on the altar an animal that is not perfect."
    },
    {
      "verse": "24",
      "text": "A person must not give a gift to the Lord of an animal that has something wrong with its testicles."
    },
    {
      "verse": "25",
      "text": "This rule is for Israel's people. You must not take animals from foreigners and then offer them to God as sacrifices. God will not accept them on your behalf, because animals like that are not perfect. ’"
    },
    {
      "verse": "26",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "27",
      "text": "‘When a cow or a sheep or a goat is born, it must stay with its mother for seven days. From the eighth day the people can give it as a burnt offering to the Lord."
    },
    {
      "verse": "28",
      "text": "They must not kill a cow or a sheep and its baby on the same day."
    },
    {
      "verse": "29",
      "text": "When they sacrifice an animal to thank the Lord, they must sacrifice it in the proper way. This will give the Lord pleasure."
    },
    {
      "verse": "30",
      "text": "They must eat it on the day that they kill it. They must not keep any of it until the next day. I am the Lord."
    },
    {
      "verse": "31",
      "text": "The people must obey my rules. I am the Lord."
    },
    {
      "verse": "32",
      "text": "They must give honour to my holy name. My people must believe that I am holy. I am the Lord. I make people holy."
    },
    {
      "verse": "33",
      "text": "I brought you out of Egypt and I became your God. I am the Lord. ’"
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Tell Israel's people about the special days when they must worship the Lord. They are holy days. The Israelites must come together and have a feast on these days."
    },
    {
      "verse": "3",
      "text": "There are six days when a person can work. The seventh day is the Sabbath day. A person must not do any work on that day. It is a day when people meet together for worship. You must not work in any place where you live. It is the Sabbath to the Lord, a day of rest."
    },
    {
      "verse": "4",
      "text": "There are other special days. They are holy feasts. On these days you must tell the people how to obey the Lord's rules."
    },
    {
      "verse": "5",
      "text": "One special day is the 14th day of the first month. When the sun goes down, the Passover to the Lord begins."
    },
    {
      "verse": "6",
      "text": "The 15th day of the first month, the Feast of Flat Bread begins. It is a feast to the Lord. For seven days the people must eat bread that has no yeast in it."
    },
    {
      "verse": "7",
      "text": "On the first day the people must meet together and they must not work."
    },
    {
      "verse": "8",
      "text": "For seven days the people must give burnt offerings to the Lord. On the seventh day they must stop work and they must worship the Lord. ’"
    },
    {
      "verse": "9",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "10",
      "text": "‘Tell Israel's people this. They will go into the land that I will give to them. And then they will harvest the grain. They must take the first part of the harvest in their arms. They must give this to the priest."
    },
    {
      "verse": "11",
      "text": "The priest will lift it to the Lord. Then the Lord will accept their gift. The priest will do this on the day after the Sabbath day."
    },
    {
      "verse": "12",
      "text": "On the same day the priest will bring a young sheep that is perfect to the Lord. It must be one year old. It is a gift from the people."
    },
    {
      "verse": "13",
      "text": "He will also bring two tenths (2/10) of an ephah (about 4 litres) of the best flour mixed with oil. He will burn the gift as a sacrifice. The smell of it while it is burning will give the Lord pleasure. The people must also give a ¼ hin (about 1 litre) of wine as a gift to God."
    },
    {
      "verse": "14",
      "text": "The people must not eat any of the new grain until they have given their gift to God. They and their children must do this now and always. They must do it in any place that they live."
    },
    {
      "verse": "15",
      "text": "On the day after the Sabbath day the people will sacrifice their gifts to God. After this, they must count seven weeks."
    },
    {
      "verse": "16",
      "text": "days until the day after the seventh Sabbath. Then they must give another gift of new grain to the Lord."
    },
    {
      "verse": "17",
      "text": "Each family must bring two loaves of bread as a special gift to the Lord. They must make the bread with two tenths (2/10) of an ephah (about 4 litres) of good flour and yeast. This gift is from the first of their harvest fruits."
    },
    {
      "verse": "18",
      "text": "With the bread, all the people must bring seven perfect sheep. They must be males, each one year old. They must bring a bull. They must also bring two older male sheep. The priest will burn the grain and the animals as a gift to the Lord. The smell of them while they are burning will give the Lord pleasure."
    },
    {
      "verse": "19",
      "text": "The priest must sacrifice one male goat as a sin offering. The people must give two young sheep. They must be one year old. They are a gift to God."
    },
    {
      "verse": "20",
      "text": "The priest will lift the animals and the bread to the Lord. They are a holy offering to the Lord. They are for the priest."
    },
    {
      "verse": "21",
      "text": "On this day, the people must not do any work. They must not work anywhere that they live. It is a special day to God now and for all time to come."
    },
    {
      "verse": "22",
      "text": "When the people harvest the grain, they must not cut it to the edge of the field. They must not pick up any grain that falls. Some grain must remain in the field. It is for the poor people and for foreign people. I am the Lord your God. ’"
    },
    {
      "verse": "23",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "24",
      "text": "‘Tell Israel's people this. On the first day of the seventh month, they must rest. It is a special day. They must worship together with the sound of trumpets."
    },
    {
      "verse": "25",
      "text": "They must not work. They must burn an offering to the Lord. ’"
    },
    {
      "verse": "26",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "27",
      "text": "‘The tenth day of the seventh month is the Day of Atonement. On that day, the people must come together. They must not eat any food. They must make an offering of food to the Lord."
    },
    {
      "verse": "28",
      "text": "They must not do any work. It is a holy day. On this special day, the leader of the priests must come near to the Lord. He will make atonement for the sins of the people."
    },
    {
      "verse": "29",
      "text": "You must punish any person who eats any food on that day. Send them away from my people."
    },
    {
      "verse": "30",
      "text": "I will kill any person who works on that day."
    },
    {
      "verse": "31",
      "text": "Nobody must work on that day. This rule is for now and for all time to come. You must obey it in any place where you are living."
    },
    {
      "verse": "32",
      "text": "It is a Sabbath rest for all the people. They must not eat any food. They must rest from the evening of the ninth day until the evening of the tenth day. ’"
    },
    {
      "verse": "33",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "34",
      "text": "‘Tell Israel's people that the Feast of Huts will start on the 15th day of the seventh month. The feast will continue for seven days, as people worship the Lord."
    },
    {
      "verse": "35",
      "text": "The first day is a special day. The people must not do any work."
    },
    {
      "verse": "36",
      "text": "For seven days each person must give a gift to the Lord. The eighth day is holy. The people must come together and they must give a burnt offering to the Lord. This is the last day of the feast. The people must not do any work on that day."
    },
    {
      "verse": "37",
      "text": "These are the rules for the special days of the Lord. You must tell people that they must bring offerings to the Lord on these days. They will bring gifts for burnt offerings each day. They must bring offerings of grain, animals and wine."
    },
    {
      "verse": "38",
      "text": "These are not the usual Sabbath gifts to the Lord. They are not gifts to give thanks or for promises to the Lord. But they are extra gifts for special days."
    },
    {
      "verse": "39",
      "text": "When the people have picked the grain, they can enjoy seven feast days to the Lord. The special days will begin on the 15th day of the seventh month. On the first day and on the eighth day they can rest."
    },
    {
      "verse": "40",
      "text": "On the first day, they must take fruit and leaves from the trees. Then for seven days they must praise the Lord."
    },
    {
      "verse": "41",
      "text": "They must do this to worship the Lord for seven days of each year. They must obey this rule in the seventh month now, and for all the years to come."
    },
    {
      "verse": "42",
      "text": "All Israel's people must live in huts for seven days."
    },
    {
      "verse": "43",
      "text": "Your descendants in the future will know that God brought Israel's people out of Egypt. They will know that he caused them to live in huts as they travelled through the wilderness. I am the Lord, your God. ’"
    },
    {
      "verse": "44",
      "text": "Moses told the people all that the Lord had told him."
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Tell Israel's people that they must bring to you the best oil. This will cause the light to burn all the time."
    },
    {
      "verse": "3",
      "text": "Aaron must put more oil in the lamp from evening to morning in front of the Lord. The lamp is outside the curtain. That curtain is in the Holy Place. The light must never go out. This rule is for now and for all time to come."
    },
    {
      "verse": "4",
      "text": "The lamps on the gold lampstand must burn always in front of the Lord."
    },
    {
      "verse": "5",
      "text": "loaves of bread. They must use the best flour. They must weigh the flour for each loaf. They must use two tenths (2/10) of an ephah (4 litres)."
    },
    {
      "verse": "6",
      "text": "They must put the loaves on a table in two rows in front of the Lord. There must be six loaves in each row."
    },
    {
      "verse": "7",
      "text": "They must put incense near each row. They must burn the incense as a gift to the Lord instead of the bread."
    },
    {
      "verse": "8",
      "text": "They must put the bread on the table every Sabbath. It is a covenant between Israel's people and the Lord."
    },
    {
      "verse": "9",
      "text": "The bread is for Aaron and for his sons. They must eat it in a holy place. It is their holy part of the burnt offering to the Lord. ’"
    },
    {
      "verse": "10",
      "text": "There was a man. His mother was an Israelite and his father was a man from Egypt. The man had a quarrel with an Israelite man."
    },
    {
      "verse": "11",
      "text": "The Israelite woman's son said bad things about God. The people took him to Moses. (The name of the mother was Shelomith. She was the daughter of Dibri from the family of Dan. )"
    },
    {
      "verse": "12",
      "text": "They locked the man up. The Lord told them what to do with him."
    },
    {
      "verse": "13",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "14",
      "text": "‘Take the man outside the camp. All the people who heard him speak must put a hand on him. All the people must throw stones at him until he is dead."
    },
    {
      "verse": "15",
      "text": "Tell Israel's people, “It is a sin if any man says bad things about God's name."
    },
    {
      "verse": "16",
      "text": "He must die. All the people must throw stones at him until he is dead. ” You must kill anyone who says bad things about the Lord's name. They may be a foreigner or an Israelite. You must kill them."
    },
    {
      "verse": "17",
      "text": "If any man kills another man you must kill him."
    },
    {
      "verse": "18",
      "text": "A man might kill an animal that belongs to another man. Then he must give an animal that is alive to the man. You must give a living animal if you take a living animal's life."
    },
    {
      "verse": "19",
      "text": "If a man hurts another person, you must punish him as he deserves. Hurt him in the same way that he has hurt the other person."
    },
    {
      "verse": "20",
      "text": "If he has broken one of the person's bones, break one of his bones. If he hurt the person's eye, hurt his eye. If he has broken a person's tooth, break his tooth."
    },
    {
      "verse": "21",
      "text": "A man might hit an animal so that it dies. That man must give back an animal that is alive. But if he kills a man, you must punish him with death."
    },
    {
      "verse": "22",
      "text": "This rule is for all the people. It is the same rule for Israelites and foreigners. I am the Lord your God. ’"
    },
    {
      "verse": "23",
      "text": "Moses spoke to Israel's people. A man had said bad things about God. They took him outside the camp. They threw stones at him until he died. Israel's people did as the Lord had told Moses."
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "Moses was on Sinai's mountain. The Lord spoke to him there."
    },
    {
      "verse": "2",
      "text": "The Lord said, ‘Speak to Israel's people. They will go into the land that I will give to them. Then the land must have a Sabbath rest to the Lord."
    },
    {
      "verse": "3",
      "text": "They can plant seeds in the fields for six years. They can cut the leaves of the plants and they can harvest the fruit for six years."
    },
    {
      "verse": "4",
      "text": "In the seventh year, the land must have a rest. They must not plant seeds in the fields or cut the leaves."
    },
    {
      "verse": "5",
      "text": "They must not harvest fruit or grain. The land must have a year for rest."
    },
    {
      "verse": "6",
      "text": "All of the people can eat anything that grows by itself in the Sabbath year. That will be food for you and for your servants and for your animals. And other people who live among you can eat it."
    },
    {
      "verse": "7",
      "text": "The wild animals also can eat anything that grows by itself in the Sabbath year."
    },
    {
      "verse": "8",
      "text": "The people must count seven lots of Sabbath years. That is 49 years."
    },
    {
      "verse": "9",
      "text": "In the 50th year they must make loud music. They must blow trumpets on the tenth day of the seventh month. That is the Day of Atonement. They must blow the trumpet through all the country."
    },
    {
      "verse": "10",
      "text": "The year will be special. It is a Jubilee year. It is a time for every one of my people to become free. Everyone can return to his own land and to his family."
    },
    {
      "verse": "11",
      "text": "The 50th year is a Jubilee year. The people must not plant any seed in the fields. They must not harvest anything that grows by itself on the bushes."
    },
    {
      "verse": "12",
      "text": "It is a Jubilee year for the people. And they can eat only food that they take from the fields."
    },
    {
      "verse": "13",
      "text": "In the Jubilee year every person must return to the land of his family."
    },
    {
      "verse": "14",
      "text": "If the people buy and sell land from each other, they must be honest with each other."
    },
    {
      "verse": "15",
      "text": "The person who is selling the land will decide the price. He must count the number of years until the next Jubilee year."
    },
    {
      "verse": "16",
      "text": "When there are many years, the price must be big. When there are few years, the price must be small. The number of years that the land will give food to eat is what is important."
    },
    {
      "verse": "17",
      "text": "Be honest with each other and respect God. I am the Lord your God."
    },
    {
      "verse": "18",
      "text": "The people must obey God's rules. If they do, they will be safe."
    },
    {
      "verse": "19",
      "text": "You will be able to grow food on the land. And the people will have plenty to eat. They will be safe."
    },
    {
      "verse": "20",
      "text": "The people may ask what they will eat in the seventh year. They will not have planted any seeds."
    },
    {
      "verse": "21",
      "text": "God will cause a lot of food to grow in the sixth year. They will have food for three more years."
    },
    {
      "verse": "22",
      "text": "When a person plants seed in the eighth year he will still be eating the crops that he planted in the sixth year. The next time he will harvest the plants from the fields will be in the ninth year."
    },
    {
      "verse": "23",
      "text": "The people must never sell the land for all time. The land belongs to God. He has said that the people can live on it."
    },
    {
      "verse": "24",
      "text": "A person may buy land. But he must remember that he may have to sell it back to the seller."
    },
    {
      "verse": "25",
      "text": "If a man becomes poor, he can sell some of his land. A person from his family must buy the land back for the man."
    },
    {
      "verse": "26",
      "text": "But the man might not have any family. If he stops being poor, he can buy the land back."
    },
    {
      "verse": "27",
      "text": "He must count how many years until the next Jubilee year. He must pay the right amount of money for the land. Then he can live on the land again."
    },
    {
      "verse": "28",
      "text": "If the man is too poor to buy the land back, it will belong to the other person. It will belong to the other person until the next Jubilee year. He must return it to the poor man in the Jubilee year."
    },
    {
      "verse": "29",
      "text": "A man may sell a house in a city with walls. For one year after he sells it, he can buy it back."
    },
    {
      "verse": "30",
      "text": "If the man does not buy back the house, it will belong to the other person and his sons. It will belong to them for all time. They will not have to return it in the Jubilee year."
    },
    {
      "verse": "31",
      "text": "If the house is in a village, a person can buy it back. If he does not buy it back, they will return it to him in the Jubilee year."
    },
    {
      "verse": "32",
      "text": "The Levites (people from the family of Levi) can buy back the houses in their towns."
    },
    {
      "verse": "33",
      "text": "In the Jubilee year, the Levites must get back the houses that they sold. Their towns belong to the Levites."
    },
    {
      "verse": "34",
      "text": "The Levites must not sell the fields that belong to their towns. God gave to them their towns and cities to live in for all time."
    },
    {
      "verse": "35",
      "text": "An Israelite may become poor. He may not be able to feed his family. You must help him. You would help a visitor or a foreigner in the same way. You must help the man so that he can continue to live among you."
    },
    {
      "verse": "36",
      "text": "The man must not pay back more than you gave to him. You must obey your God."
    },
    {
      "verse": "37",
      "text": "The person who is feeding the man might give money or food to him. He must not ask for more back than he gave."
    },
    {
      "verse": "38",
      "text": "I am the Lord your God who brought you out of Egypt. I brought you into this land to be your God."
    },
    {
      "verse": "39",
      "text": "If an Israelite becomes poor, he might sell himself to you. But he must not work for you as a slave. You must pay him to work as your servant."
    },
    {
      "verse": "40",
      "text": "He must work for you until the next Jubilee year."
    },
    {
      "verse": "41",
      "text": "In the Jubilee year, you will make him free. He and his children can go back to his own home and family."
    },
    {
      "verse": "42",
      "text": "Israel's people belong to God. I took them out of Egypt. They must not be slaves."
    },
    {
      "verse": "43",
      "text": "You must be kind to all Israelites. Remember to obey your God."
    },
    {
      "verse": "44",
      "text": "Israel's people can buy male and female slaves. Those slaves must come from other countries."
    },
    {
      "verse": "45",
      "text": "And Israelites can buy people from other countries who live among them. They may have children who were born in your land. You can buy them. They will become slaves."
    },
    {
      "verse": "46",
      "text": "You can give the slaves to your children when you die. But you must rule Israel's people in a kind way."
    },
    {
      "verse": "47",
      "text": "A person from another country may become rich. Then he might buy an Israelite who became poor. But the poor man can buy himself back at any time."
    },
    {
      "verse": "48",
      "text": "A person from the family of the poor man can buy him back."
    },
    {
      "verse": "49",
      "text": "A brother or a cousin of the poor man can buy him back. If the poor man becomes rich, he can pay to make himself free."
    },
    {
      "verse": "50",
      "text": "The man and the person who bought him must count the time until the Jubilee year. The man must pay the right amount of money to be free."
    },
    {
      "verse": "51",
      "text": "The Jubilee year may be many years away. If it is, the man must pay a lot of money to be free."
    },
    {
      "verse": "52",
      "text": "There may be a few years until the Jubilee year. If there are, he has to pay only a small amount of money to be free."
    },
    {
      "verse": "53",
      "text": "The person who has bought the man must pay him each year. You must cause the rich man to be kind to the man."
    },
    {
      "verse": "54",
      "text": "Perhaps nobody will pay any money for the man. But the man who bought him must make him free in the Jubilee year."
    },
    {
      "verse": "55",
      "text": "Israel's people belong to me. I brought them out of Egypt. They are my servants. I am the Lord."
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "You must not make idols from stones and worship them. You must not draw things on stones and bend down in front of them. I am the Lord your God."
    },
    {
      "verse": "2",
      "text": "You must rest on Sabbath days and you must keep them holy. You must respect God's house. I am the Lord."
    },
    {
      "verse": "3",
      "text": "The people must carefully obey the rules."
    },
    {
      "verse": "4",
      "text": "If they do, I will send rain at the proper time. Plants for food will grow in the ground. Fruit will grow on your trees."
    },
    {
      "verse": "5",
      "text": "The people will harvest grain until the grapes are ready to eat. They will harvest the grapes until it is the time to plant seeds. They will have all the food to eat that they need. I will keep them safe in their land."
    },
    {
      "verse": "6",
      "text": "I will stop war in Israel. When the people sleep, they will not be afraid. I will take the wild animals away. Other people will not hurt my people."
    },
    {
      "verse": "7",
      "text": "Israel's enemies will run away from them. They will kill their enemies."
    },
    {
      "verse": "8",
      "text": "of them. And 100 of you will run after 1, 000 enemies. You will kill all your enemies."
    },
    {
      "verse": "9",
      "text": "I will do good things for your people and I will give many children to them. Their number will grow. I will do everything that I have promised to do for them."
    },
    {
      "verse": "10",
      "text": "They will have so much food that some will remain after the next harvest."
    },
    {
      "verse": "11",
      "text": "I will have my home among you, my people. I will never turn away from them."
    },
    {
      "verse": "12",
      "text": "I will walk among the people. They will belong to me."
    },
    {
      "verse": "13",
      "text": "I am the Lord your God. I brought you out of Egypt. You will not be the slaves of people in Egypt. I saved you so that you need not be ashamed."
    },
    {
      "verse": "14",
      "text": "God will be angry if the people do not listen to him. He will be angry if they do not obey his rules."
    },
    {
      "verse": "15",
      "text": "The people may not respect or obey God's rules. So they will not be doing what they promised to him."
    },
    {
      "verse": "16",
      "text": "So God will send diseases to the people. They will be afraid. The people will have diseases in their eyes. They will get thin and they will die. They will plant their seed and their enemies will eat the fruit."
    },
    {
      "verse": "17",
      "text": "God will fight against you. Your enemies will win the war. They will become your rulers. Your soldiers will run away even when nobody is running after them."
    },
    {
      "verse": "18",
      "text": "The people may not obey God even after this. If they do not, God will punish them seven times more strongly."
    },
    {
      "verse": "19",
      "text": "He will make them ashamed. He will not send any rain and the land will be hard and dry."
    },
    {
      "verse": "20",
      "text": "Even if they do a lot of work, no grain will grow. No fruit will grow on the trees."
    },
    {
      "verse": "21",
      "text": "The people may still not listen to God. If they do not, he will be seven times more angry. If they do not obey him, he will cause their lives to be seven times more difficult."
    },
    {
      "verse": "22",
      "text": "He will send wild animals to kill their children and their animals. The land will be almost empty."
    },
    {
      "verse": "23",
      "text": "The people may still not listen to God. If they do not, he will be angry."
    },
    {
      "verse": "24",
      "text": "He will become their enemy. If they do not obey him, he will punish them seven times more strongly."
    },
    {
      "verse": "25",
      "text": "He will send enemy soldiers to kill the people. They have not done what they promised to do. So he will punish them for that. If they go back to their cities, he will send them diseases. The enemy will win the war."
    },
    {
      "verse": "26",
      "text": "The people will not have any food. A woman will bake one loaf for ten families. They will weigh it to give one part to each family. When a person eats his piece of bread, he will still be hungry."
    },
    {
      "verse": "27",
      "text": "If the people still turn away from God, he will be even more angry. They will not turn away from their sin."
    },
    {
      "verse": "28",
      "text": "So he will turn away from them. He will punish them seven times more again."
    },
    {
      "verse": "29",
      "text": "They will be so hungry that they will eat their own children."
    },
    {
      "verse": "30",
      "text": "The Lord will destroy the places where they worship false gods. He will destroy their very bad incense altars. He will put their dead bodies round their idols. He will hate them."
    },
    {
      "verse": "31",
      "text": "He will destroy the cities. He will destroy the places for wrong worship. Nobody will burn incense to give the Lord pleasure."
    },
    {
      "verse": "32",
      "text": "God will destroy the land. He will cause the enemies who live in your land to hate it."
    },
    {
      "verse": "33",
      "text": "God will push you out. He will send your people away to other countries. He will destroy your cities. And he will make your land a desert."
    },
    {
      "verse": "34",
      "text": "The land will have a Sabbath rest while there are no people in it."
    },
    {
      "verse": "35",
      "text": "All the time that it is empty, the land will have rest. It will have the Sabbath rest that it did not have. It did not have it when you lived in it."
    },
    {
      "verse": "36",
      "text": "Some of Israel's people will remain in other countries. They will be frightened. A leaf that is blowing in the wind will cause them to run away. It will be like when an enemy is running after them. They will fall even if no enemy is running after them."
    },
    {
      "verse": "37",
      "text": "They will fall over each other when nobody is running after them. They will not be strong enough to fight their enemies."
    },
    {
      "verse": "38",
      "text": "They will die in the countries where they are living. Those countries will cause their deaths."
    },
    {
      "verse": "39",
      "text": "Those who remain here will die because of their sins. They will die because their ancestors did not obey God."
    },
    {
      "verse": "40",
      "text": "Your sons and your grandsons must tell me, the Lord, that they are sorry. They must be sorry because they did not obey my rules. They must be sorry that they turned away from me."
    },
    {
      "verse": "41",
      "text": "They must remember that they made me angry. They caused me to turn away from them. I am the Lord, and I sent them into their enemies' country. They will be sorry until I have punished them enough."
    },
    {
      "verse": "42",
      "text": "Then I will remember my covenant with Abraham, Isaac and Jacob. I will remember that I gave their land to them."
    },
    {
      "verse": "43",
      "text": "Before this, the land will be empty and it will have a rest. My people will pay for the bad things that they did."
    },
    {
      "verse": "44",
      "text": "But I, the Lord, will not kill all of them. The people will be living in their enemies' country. Then I will remember them. I will not leave them alone. I will remember my covenant with them. I am the Lord, their God."
    },
    {
      "verse": "45",
      "text": "I will remember my covenant with their ancestors that I brought out of Egypt. The people of other nations saw me do this. I am the Lord. ’"
    },
    {
      "verse": "46",
      "text": "These are the rules that the Lord gave to Moses on Sinai mountain. They are his covenant with Israel's people."
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Speak to Israel's people. Tell them this. A person might give another person to the Lord for a special promise."
    },
    {
      "verse": "3",
      "text": "They can make that person free. But they must give the right amount of money to God. For a man between 20 years and 60 years old, they must give 50 pieces of silver."
    },
    {
      "verse": "4",
      "text": "For a woman, they must give 30 pieces of silver."
    },
    {
      "verse": "5",
      "text": "years old, they must give to God 20 pieces of silver. For a female, they must give ten pieces of silver."
    },
    {
      "verse": "6",
      "text": "For a boy between one month and five years old, they must give five pieces of silver. For a girl of the same age, God must have three pieces of silver."
    },
    {
      "verse": "7",
      "text": "years, they must give 15 pieces of silver. For a woman, they must give ten pieces of silver."
    },
    {
      "verse": "8",
      "text": "A person might say this special promise to God. But he might be too poor to pay the money. He must bring the person to the priest. The priest will tell the person how much money to pay. The priest will know how much money the man can give."
    },
    {
      "verse": "9",
      "text": "If the promise is to give an animal to God the animal becomes holy to the Lord."
    },
    {
      "verse": "10",
      "text": "The person must not change a good animal for a bad animal. He must not change a bad animal for a good animal. If the person does change one animal for another, both the animals become holy."
    },
    {
      "verse": "11",
      "text": "The animal might be an animal that you must not eat. And you can not give it to the Lord. If it is, the person must bring it to the priest."
    },
    {
      "verse": "12",
      "text": "The priest will decide if the animal is good or bad."
    },
    {
      "verse": "13",
      "text": "The person might want to buy the animal back. He must pay the price of the animal and one fifth more."
    },
    {
      "verse": "14",
      "text": "A person might give his house to the Lord. The priest will decide if the house is good or bad. The priest will decide the price of the house."
    },
    {
      "verse": "15",
      "text": "The person might want to buy the house back. He must pay the price of the house and one fifth more. Then it will again belong to him."
    },
    {
      "verse": "16",
      "text": "A person might give part of his land to the Lord. The person will decide the price by how much seed the land needs. The price will be 50 pieces of silver for a homer (220 litres) of seed."
    },
    {
      "verse": "17",
      "text": "If a person gives his land in a Jubilee year, the price is the same."
    },
    {
      "verse": "18",
      "text": "A person might give his land after the Jubilee year. The priest will count the number of years before the next Jubilee. The price will be less."
    },
    {
      "verse": "19",
      "text": "A person might want to buy the land back. He must pay the price of the land and one fifth more."
    },
    {
      "verse": "20",
      "text": "He may not buy it back before the year of Jubilee. Then the field becomes holy. But the man may have sold the land to another person. If he has, he cannot get it back."
    },
    {
      "verse": "21",
      "text": "In the Jubilee year the land will become holy. Then it will belong to the priests."
    },
    {
      "verse": "22",
      "text": "A person might buy some land from another family. He might give that land to the Lord."
    },
    {
      "verse": "23",
      "text": "The priest will count how many years there are until the Jubilee year. The person must pay the money on that day. The money is holy to the Lord."
    },
    {
      "verse": "24",
      "text": "In the Jubilee year, the land returns to the family from whom he bought it."
    },
    {
      "verse": "25",
      "text": "The priest must decide the price of the land. He must use the correct measures."
    },
    {
      "verse": "26",
      "text": "The first baby that an animal has is holy. It belongs to the Lord. A person cannot give it as a special gift to the Lord."
    },
    {
      "verse": "27",
      "text": "The animal might be an unclean animal (an animal that they must not eat). The person can pay the price of the animal and one fifth more to get it back. If the person does not buy it back, the priest will sell it."
    },
    {
      "verse": "28",
      "text": "A man might give to the Lord something that the man has. Everything that a man gives like that is holy. It might be a person, an animal or land. The priest must not sell it. A man cannot take it back. Everything that someone gives to the Lord is most holy."
    },
    {
      "verse": "29",
      "text": "God might decide that a person must die. If he does, nobody can buy the person back. The person must die."
    },
    {
      "verse": "30",
      "text": "One tenth of everything that comes from the land is holy to the Lord. It may be grain or fruit. It belongs to the Lord."
    },
    {
      "verse": "31",
      "text": "If a person buys back any of his gift, he must pay the price and one fifth more."
    },
    {
      "verse": "32",
      "text": "Out of every ten animals, one animal is holy. It belongs to the Lord."
    },
    {
      "verse": "33",
      "text": "A person must not change a good animal for a bad animal. A person must not change a bad animal for a good animal. If he does that, both animals are holy. They belong to God. A person cannot buy them back. ’"
    },
    {
      "verse": "34",
      "text": "These are the rules that the Lord gave to Moses on Sinai mountain. They are the rules for Israel's people."
    }
  ]
};