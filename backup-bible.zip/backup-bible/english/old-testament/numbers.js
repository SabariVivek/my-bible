module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "The Israelites were in the Sinai desert. It was the first day of the second month of the second year after they left Egypt. Moses was in the Tent of Meeting. The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Put the people into clans and families and count them. Make a list. Write the name of each man on the list."
    },
    {
      "verse": "3",
      "text": "You and Aaron must record the names of all the men in each group who can fight in the army. Record the names of men who are 20 years old or older."
    },
    {
      "verse": "4",
      "text": "A man from each tribe must help you. Each of them will be the leader of his family."
    },
    {
      "verse": "5",
      "text": "These are the men from each tribe who must help you: Reuben: Elizur, the son of Shedeur."
    },
    {
      "verse": "6",
      "text": "Simeon: Shelumiel, the son of Zurishaddai."
    },
    {
      "verse": "7",
      "text": "Judah: Nahshon, the son of Amminadab."
    },
    {
      "verse": "8",
      "text": "Issachar: Nethanel, the son of Zuar."
    },
    {
      "verse": "9",
      "text": "Zebulun: Eliab, the son of Helon."
    },
    {
      "verse": "10",
      "text": "Ephraim (Joseph's son): Elishama, the son of Ammihud. Manasseh (Joseph's son): Gamaliel, the son of Pedahzur."
    },
    {
      "verse": "11",
      "text": "Benjamin: Abidan, the son of Gideoni."
    },
    {
      "verse": "12",
      "text": "Dan: Ahiezer, the son of Ammishaddai."
    },
    {
      "verse": "13",
      "text": "Asher: Pagiel, the son of Ocran."
    },
    {
      "verse": "14",
      "text": "Gad: Eliasaph, the son of Deuel."
    },
    {
      "verse": "15",
      "text": "Naphtali: Ahira, the son of Enan. ’"
    },
    {
      "verse": "16",
      "text": "These were the men that they chose from among the people. They were leaders of their clans. Each of them worked on behalf of the tribe of their ancestor."
    },
    {
      "verse": "17",
      "text": "Moses and Aaron told these leaders to come."
    },
    {
      "verse": "18",
      "text": "On the first day of the second month, they said that all the Israelite people must come together. The people were in clans and in families. They made a list of all the men who were 20 years old or older."
    },
    {
      "verse": "19",
      "text": "They did the things that the Lord had told Moses to do. So Moses recorded the names there in the Sinai desert."
    },
    {
      "verse": "44",
      "text": "Moses and Aaron counted the numbers of the men in each tribe. The 12 leaders of the Israelites helped them to do it. That was one man from each tribe."
    },
    {
      "verse": "45",
      "text": "They recorded the names of all the men in each family. All the men who were 20 years old or older were on the list. Those men could fight in the army."
    },
    {
      "verse": "46",
      "text": "The number of all the men was 603, 550."
    },
    {
      "verse": "47",
      "text": "But Moses and Aaron did not count the descendants of Levi among the other tribes."
    },
    {
      "verse": "48",
      "text": "The Lord had said to Moses,"
    },
    {
      "verse": "49",
      "text": "‘You must not count the tribe of Levi. You must not put the Levites on the list with the other Israelites."
    },
    {
      "verse": "50",
      "text": "The Levites' work will be in the special Tent of Meeting. They must take care of the Tent and everything that is in it. They must carry it everywhere. Their work is with all those things. They must put their own tents round the special Tent."
    },
    {
      "verse": "51",
      "text": "When the people move to another place, the Levites must pack the Tent. When the people arrive at a new place, the Levites must put the Tent up again. If any other person, not a Levite, comes near to the special Tent, they must die."
    },
    {
      "verse": "52",
      "text": "All the other Israelites must put up their tents in groups. Each man must live among his own group. Each group must put up its own flag."
    },
    {
      "verse": "53",
      "text": "But the Levites must put up their tents around the Tent of Meeting. They must take care of it. Then I, the Lord, will not be angry with the people. ’"
    },
    {
      "verse": "54",
      "text": "The Israelites did everything that the Lord had told Moses to do."
    },
    {
      "verse": "20",
      "text": "years old or older. T"
    },
    {
      "verse": "21",
      "text": "hose men could fight"
    },
    {
      "verse": "22",
      "text": "in the army. They rec"
    },
    {
      "verse": "23",
      "text": "orded the names of th"
    },
    {
      "verse": "24",
      "text": "e men in each clan an"
    },
    {
      "verse": "25",
      "text": "d family. Reuben was"
    },
    {
      "verse": "26",
      "text": "the firstborn son of"
    },
    {
      "verse": "27",
      "text": "Israel, so they recor"
    },
    {
      "verse": "28",
      "text": "ded his tribe first."
    },
    {
      "verse": "29",
      "text": "These were the number"
    },
    {
      "verse": "30",
      "text": "s of the men from eac"
    },
    {
      "verse": "31",
      "text": "h tribe: Reuben: 46, 50"
    },
    {
      "verse": "32",
      "text": "0 men. Simeon: 59, 300"
    },
    {
      "verse": "33",
      "text": "men. Gad: 45, 650 men. J"
    },
    {
      "verse": "34",
      "text": "udah: 74, 600 men. Issa"
    },
    {
      "verse": "35",
      "text": "char: 54, 400 men. Zebu"
    },
    {
      "verse": "36",
      "text": "lun: 57, 400 men. Ephra"
    },
    {
      "verse": "37",
      "text": "im (Joseph's son): 40"
    },
    {
      "verse": "38",
      "text": ", 500 men. Manasseh (Jo"
    },
    {
      "verse": "39",
      "text": "seph's son): 32, 200 m"
    },
    {
      "verse": "40",
      "text": "en. Benjamin: 35, 400 m"
    },
    {
      "verse": "41",
      "text": "en. Dan: 62, 700 men. As"
    },
    {
      "verse": "42",
      "text": "her: 41, 500 men. Napht"
    },
    {
      "verse": "43",
      "text": "ali: 53, 400 men."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "The Lord said to Moses and Aaron,"
    },
    {
      "verse": "2",
      "text": "‘The Israelites must put up their tents on each side of the Tent of Meeting. They must not be very near to it but they must be all around it. They must live together in their tribes. Each person must be with his own tribe. Each tribe must have its own flag."
    },
    {
      "verse": "3",
      "text": "The people in Judah's tribe must be on the east side of the Tent. They must have their flag with them, and they must put up their tents in groups. The leader of the tribe of Judah is Nahshon, the son of Amminadab."
    },
    {
      "verse": "4",
      "text": "There will be 74, 600 soldiers in his army."
    },
    {
      "verse": "5",
      "text": "The tribe of Issachar will put up their tents on one side of Judah's camp. The leader of the tribe of Issachar is Nethanel, the son of Zuar."
    },
    {
      "verse": "6",
      "text": "There will be 54, 400 soldiers in his army."
    },
    {
      "verse": "7",
      "text": "The tribe of Zebulun will be on the other side of Judah's camp. The leader of the tribe of Zebulun is Eliab, the son of Helon."
    },
    {
      "verse": "8",
      "text": "There will be 57, 400 soldiers in his army."
    },
    {
      "verse": "9",
      "text": "So there will be 186, 400 soldiers in the three groups on Judah's side of the camp. When the people travel, these tribes will march first."
    },
    {
      "verse": "10",
      "text": "The tribe of Reuben must be on the south side of the Tent. They must have their flag with them, and they must put up their tents in groups. The leader of the tribe of Reuben is Elizur, the son of Shedeur."
    },
    {
      "verse": "11",
      "text": "There will be 46, 500 soldiers in his army."
    },
    {
      "verse": "12",
      "text": "The tribe of Simeon will put up their tents on one side of Reuben's camp. The leader of the tribe of Simeon is Shelumiel, the son of Zurishaddai."
    },
    {
      "verse": "13",
      "text": "There will be 59, 300 soldiers in his army."
    },
    {
      "verse": "14",
      "text": "The tribe of Gad will be on the other side of Reuben's camp. The leader of the tribe of Gad is Eliasaph, the son of Deuel."
    },
    {
      "verse": "15",
      "text": "There will be 45, 650 soldiers in his army."
    },
    {
      "verse": "16",
      "text": "So there will be 151, 450 soldiers in the three groups on Reuben's side of the camp. When the people travel, they will march second."
    },
    {
      "verse": "17",
      "text": "The Levites must march next. The Levites must carry the Tent of Meeting. They must march between the first two groups of tribes and the last two groups of tribes. Each man must be in his own place. They must march with their flag."
    },
    {
      "verse": "18",
      "text": "The tribe of Ephraim must be on the west side of the Tent. They must have their flag with them and they must live in groups. The leader of the tribe of Ephraim is Elishama, the son of Ammihud."
    },
    {
      "verse": "19",
      "text": "There will be 40, 500 soldiers in his army."
    },
    {
      "verse": "20",
      "text": "The tribe of Manasseh will be on one side of Ephraim's camp. The leader of the tribe of Manasseh is Gamaliel, the son of Pedahzur."
    },
    {
      "verse": "21",
      "text": "There will be 32, 200 soldiers in his army."
    },
    {
      "verse": "22",
      "text": "The tribe of Benjamin will be on the other side of Ephraim's camp. The leader of the tribe of Benjamin is Abidan, the son of Gideoni."
    },
    {
      "verse": "23",
      "text": "There will be 35, 400 soldiers in his army."
    },
    {
      "verse": "24",
      "text": "So there will be 108, 100 soldiers in the three groups on Ephraim's side of the camp. When the people travel, they will march third."
    },
    {
      "verse": "25",
      "text": "The tribe of Dan must be on the north side of the Tent. They must have their flag with them and they must live in groups. The leader of the tribe of Dan is Ahiezer, the son of Ammishaddai."
    },
    {
      "verse": "26",
      "text": "There will be 62, 700 soldiers in his army."
    },
    {
      "verse": "27",
      "text": "The tribe of Asher will put up their tents on one side of Dan's camp. The leader of the tribe of Asher is Pagiel, the son of Ocran."
    },
    {
      "verse": "28",
      "text": "There will be 41, 500 soldiers in his army."
    },
    {
      "verse": "29",
      "text": "The tribe of Naphtali will be on the other side of Dan's camp. The leader of the tribe of Naphtali is Ahira, the son of Enan."
    },
    {
      "verse": "30",
      "text": "There will be 53, 400 soldiers in his army."
    },
    {
      "verse": "31",
      "text": "So there will be 157, 600 soldiers in the three groups on Dan's side of the camp. They will march last with their flag. ’"
    },
    {
      "verse": "32",
      "text": "In that way, Moses and his helpers counted all the Israelite men who were able to fight. They counted them in groups, clan by clan. There were 603, 550 soldiers."
    },
    {
      "verse": "33",
      "text": "They did not count the Levites among the other Israelites. That was what the Lord had told Moses."
    },
    {
      "verse": "34",
      "text": "The Israelites did everything that the Lord had told Moses. They put up their tents in groups, as the Lord wanted. Each tribe put up its tents under its own flag. When they started to travel, each man walked with his own clan and his own family."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "This is the list of the family of Aaron and Moses. This was at the time when the Lord spoke to Moses on Sinai mountain."
    },
    {
      "verse": "2",
      "text": "The names of the sons of Aaron were Nadab, Abihu, Eleazar and Ithamar. Nadab was the firstborn son."
    },
    {
      "verse": "3",
      "text": "Aaron anointed them, and he gave authority to them to work as priests."
    },
    {
      "verse": "4",
      "text": "But Nadab and Abihu fell down and died in front of the Lord. That happened when they offered strange fire to the Lord in the Sinai desert. They had no children. So only Eleazar and Ithamar worked as priests while their father Aaron was alive."
    },
    {
      "verse": "5",
      "text": "Then the Lord said to Moses,"
    },
    {
      "verse": "6",
      "text": "‘Bring the tribe of Levi to Aaron the priest. They must help him."
    },
    {
      "verse": "7",
      "text": "They must serve him and all the Israelites. They must work at the Tent of Meeting and take care of it."
    },
    {
      "verse": "8",
      "text": "They must work on behalf of the Israelites. They must take care of the things that are in the Tent of Meeting. That is how they will serve God."
    },
    {
      "verse": "9",
      "text": "Give the Levites to Aaron and to his descendants. They will be the Israelites who help him. They do not have to do anything else."
    },
    {
      "verse": "10",
      "text": "But you must make a list of Aaron and his descendants. They will be the priests. If any other person comes near to the special Tent, they must die. ’"
    },
    {
      "verse": "11",
      "text": "The Lord also said to Moses,"
    },
    {
      "verse": "12",
      "text": "‘I will not take the firstborn son of every woman in Israel to belong to me. I will take the Levites instead of them."
    },
    {
      "verse": "13",
      "text": "I killed all the firstborn sons of the Egyptians. But I kept the firstborn sons of every person and animal among the Israelites for myself. They belong to me. I am the Lord! ’"
    },
    {
      "verse": "14",
      "text": "The Lord said to Moses in the Sinai desert,"
    },
    {
      "verse": "15",
      "text": "‘Put the Levites into clans and families and count them. Make a list of every male who is a month old or older. ’"
    },
    {
      "verse": "16",
      "text": "Moses obeyed the Lord. So Moses recorded them as the Lord said."
    },
    {
      "verse": "17",
      "text": "The names of the sons of Levi were Gershon, Kohath and Merari."
    },
    {
      "verse": "18",
      "text": "Gershon had two sons. Their names were Libni and Shimei."
    },
    {
      "verse": "19",
      "text": "Kohath's sons were called Amram, Izhar, Hebron and Uzziel."
    },
    {
      "verse": "20",
      "text": "Merari's sons were called Mahli and Mushi. Those were the sons and grandsons of Levi. They became the leaders of the clans of Levi's tribe. Those were the sons and grandsons of Levi. They became the leaders of the clans of Levi's tribe."
    },
    {
      "verse": "21",
      "text": "There were two families in Gershon's clan. They were the families of Libni and Shimei."
    },
    {
      "verse": "22",
      "text": "There were 7, 500 males who were one month or older in their list."
    },
    {
      "verse": "23",
      "text": "Gershon's clan had to put up their tents on the west side of the special Tent."
    },
    {
      "verse": "24",
      "text": "The leader of the clan of Gershon was Eliasaph the son of Lael."
    },
    {
      "verse": "25",
      "text": "Gershon's clan had to take care of the Tent of Meeting, with the cloth that covered it, and the curtain at its door."
    },
    {
      "verse": "26",
      "text": "There was a yard round the outside of the tabernacle and the altar. Gershon's family took care of the curtains that hung round the yard, with their ropes. They also took care of the curtain at the entrance to the yard. They took care of all those kinds of things."
    },
    {
      "verse": "27",
      "text": "There were four families in Kohath's clan. They were the families of Amram, Izhar, Hebron and Uzziel."
    },
    {
      "verse": "28",
      "text": "There were 8, 600 males who were one month old or older in this clan. They had to take care of the things inside the special Tent."
    },
    {
      "verse": "29",
      "text": "Kohath's clan had to put up their tents on the south side of the tabernacle."
    },
    {
      "verse": "30",
      "text": "The leader of Kohath's descendants was Elizaphan the son of Uzziel."
    },
    {
      "verse": "31",
      "text": "Kohath's family had to take care of the Covenant Box, the table and the lampstands. They had to take care of the altars and the tools that the priests used in the special Tent. They also took care of the curtain in front of the Most Holy Place in the Tent. They did all the work with those things."
    },
    {
      "verse": "32",
      "text": "Eleazar, the son of Aaron the priest, was the most important leader of the Levites. He ruled over those people who took care of God's special Tent."
    },
    {
      "verse": "33",
      "text": "There were two families in Merari's clan. They were the families of Mahli and Mushi."
    },
    {
      "verse": "34",
      "text": "There were 6, 200 males in that list. They were one month old or older when Moses counted them."
    },
    {
      "verse": "35",
      "text": "The leader of Merari's clan was Zuriel, the son of Abihail. They had to put up their tents on the north side of the special tabernacle."
    },
    {
      "verse": "36",
      "text": "Merari's family had to take care of all the wood parts of the tabernacle. They took care of the heavy things that stood on the ground to hold the poles."
    },
    {
      "verse": "37",
      "text": "They also took care of the poles that held the cloth round the yard, their ropes and other things that held the Tent in its place."
    },
    {
      "verse": "38",
      "text": "Moses, Aaron and Aaron's sons had to put up their tents in front of the tabernacle, on the east side. They were the only people who could go into the Holy Place in the Tent. Any other person who went near it had to die."
    },
    {
      "verse": "39",
      "text": "So Moses and Aaron obeyed the Lord. They counted the Levites by their clans. There were 22, 000 males who were one month old or older."
    },
    {
      "verse": "40",
      "text": "The Lord said to Moses, ‘Record all the firstborn sons of the Israelites. Record every male who is one month old or older. Make a list of their names."
    },
    {
      "verse": "41",
      "text": "The Israelites' firstborn sons belong to me. I am the Lord. But I will accept all the males among the Levites instead. The Israelites' firstborn animals also belong to me. But I will accept the animals of the Levites instead. ’"
    },
    {
      "verse": "42",
      "text": "So Moses counted all the firstborn males among the Israelites as the Lord had said."
    },
    {
      "verse": "43",
      "text": "He counted 22, 273 firstborn males who were one month old or older. He made a list of their names."
    },
    {
      "verse": "44",
      "text": "Then the Lord said to Moses,"
    },
    {
      "verse": "45",
      "text": "‘Do not take the firstborn males among the people to belong to me. Accept the Levites instead. Do not use the firstborn animals of the people. Accept the animals of the Levites instead. The Levites will belong to me. I am the Lord."
    },
    {
      "verse": "46",
      "text": "more firstborn males of the people than there are Levites. So the people must pay for the extra firstborn sons."
    },
    {
      "verse": "47",
      "text": "You must accept five shekels for each extra firstborn male. The shekel must have the same weight as the shekel that the Levites use in God's tabernacle. There are 20 gerahs in one shekel."
    },
    {
      "verse": "48",
      "text": "Give that money to Aaron and his sons. ’"
    },
    {
      "verse": "49",
      "text": "firstborn sons. That was because the number of firstborn sons was more than the number of Levites."
    },
    {
      "verse": "50",
      "text": "He took 1, 365 shekels from them. The shekels had the same weight as the shekel that the Levites used in God's tabernacle."
    },
    {
      "verse": "51",
      "text": "Moses did what the Lord had told him to do. He gave the money to Aaron and his sons."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "The Lord said to Moses and Aaron,"
    },
    {
      "verse": "2",
      "text": "‘Write a list of the people in Kohath's clan in their families. That list must be separate from the list of the other Levites."
    },
    {
      "verse": "3",
      "text": "Record the men who can work in the Tent of Meeting. Record them if they are between 30 and 50 years old."
    },
    {
      "verse": "4",
      "text": "These men must take care of everything that is most holy in the Tent of Meeting."
    },
    {
      "verse": "5",
      "text": "When the people are ready to move, Aaron and his sons must go into the Tent of Meeting. They must take down the curtain that is in front of the Covenant Box. They must cover the Covenant Box with the curtain."
    },
    {
      "verse": "6",
      "text": "Then they must cover the curtain with good leather. On the top of that, they must put a blue cloth. Then, they must put the poles through the rings, so that they can carry the Covenant Box."
    },
    {
      "verse": "7",
      "text": "They must put a blue cloth over the table for the special bread. The bread must remain on the table. They must put on the cloth the plates, bowls and dishes. They must also put on it the jars for the wine that they offer to me."
    },
    {
      "verse": "8",
      "text": "Then they must cover all those things with a red cloth. On the top of the red cloth, they must put good leather. Then they must fix the poles to the table, so that they can carry it."
    },
    {
      "verse": "9",
      "text": "They must cover the lampstand and its tools with a blue cloth. They must also cover the jars for the oil with the blue cloth."
    },
    {
      "verse": "10",
      "text": "Then they must cover all this with good leather. They must carry it on a board."
    },
    {
      "verse": "11",
      "text": "They must cover the gold altar with a blue cloth. They must cover the blue cloth with good leather. Then they must fix the poles to the altar, so that they can carry it."
    },
    {
      "verse": "12",
      "text": "They must cover all the tools from God's Holy Tent with a blue cloth. They must cover the blue cloth with good leather. They must carry all this on a board."
    },
    {
      "verse": "13",
      "text": "They must remove the ashes from the bronze altar. They must cover the bronze altar with a purple cloth."
    },
    {
      "verse": "14",
      "text": "They must put all the tools on top of it. That includes the plates for the fire, the forks for the meat, the spades and the bowls. They must cover all that with good leather. Then they must put the poles through the rings on the altar, so that they can carry it."
    },
    {
      "verse": "15",
      "text": "When the camp is ready to move, the men from Kohath's clan must be ready to carry all those things. But they must wait until Aaron and his sons have covered God's Holy Tent and all its holy things. The men from Kohath's clan must not touch the holy things. They will die if they touch the holy things. These are the jobs of Kohath's clan. They must carry the things from the Tent of Meeting when the Israelites travel."
    },
    {
      "verse": "16",
      "text": "Eleazar, who is the son of Aaron the priest, must keep the oil for the light. He must keep the incense and the grain offering. He must keep the special oil. The special oil is a mark on everything that God chooses. Eleazar must take care of the whole Tent of Meeting. He must work with God's Holy Tent and with everything in it. ’"
    },
    {
      "verse": "17",
      "text": "Then the Lord said to Moses and Aaron,"
    },
    {
      "verse": "18",
      "text": "‘You must not cause the end of Kohath's clan from among the Levites."
    },
    {
      "verse": "19",
      "text": "Do not let the men in that clan die. That will happen if they come near to the most holy things. You must do this: Aaron and his sons must go into the Tent of Meeting. They will tell each man the work that he must do. And they must tell each man the things that he must carry."
    },
    {
      "verse": "20",
      "text": "But the men from Kohath's clan must not look at anything that is holy, even for a moment. If they do look at those things, they will die. ’"
    },
    {
      "verse": "21",
      "text": "Then the Lord said to Moses,"
    },
    {
      "verse": "22",
      "text": "‘Also write a list of the people in Gershon's clan in their families."
    },
    {
      "verse": "23",
      "text": "Record the men who can work in the Tent of Meeting. Record them if they are between 30 and 50 years old."
    },
    {
      "verse": "24",
      "text": "The work of the men in Gershon's clan is to carry everything."
    },
    {
      "verse": "25",
      "text": "The men from that clan must carry the curtains of God's Tent. And they must carry the Tent of Meeting with the thing that covers it. And they must carry the good leather that covers all that. And they must carry the curtain for the place where people go into the Tent of Meeting."
    },
    {
      "verse": "26",
      "text": "They must carry the curtains of the yard that is round God's Tent. Also, they must carry the curtain and ropes for the place where people go into the yard. That is the yard that is round God's Tent and the altar. The men from Gershon's clan must carry all the tools that belong with those curtains. They must do everything that all those things need."
    },
    {
      "verse": "27",
      "text": "The men in Gershon's clan must do everything that Aaron and his sons ask them to do. Aaron and his sons must tell them the things that they should carry. And they must tell them everything that they should do."
    },
    {
      "verse": "28",
      "text": "That is the work for the Tent of Meeting that the descendants of Gershon must do. Ithamar, the son of Aaron the priest, will tell them the things that they must do. ’"
    },
    {
      "verse": "29",
      "text": "Also God said to Moses, ‘Write a list of the people in Merari's clan in their families."
    },
    {
      "verse": "30",
      "text": "Record the men who can work in the Tent of Meeting. Record them if they are between 30 and 50 years old."
    },
    {
      "verse": "31",
      "text": "This is the work of the men in Merari's clan. They must carry the wood parts that hold the Tent of Meeting, and its poles. They must carry its pillars and its bases."
    },
    {
      "verse": "32",
      "text": "And they must carry the pillars, bases, pegs and ropes for the yard that is round God's Tent. And the men in Merari's clan must keep all the tools that belong with those things safe. Each man in Merari's clan must take care of something. Tell each man which things he must carry."
    },
    {
      "verse": "33",
      "text": "That is the work of the descendants of Merari in the Tent of Meeting. Ithamar, the son of Aaron the priest, will tell them the things that they must do. ’"
    },
    {
      "verse": "34",
      "text": "So Moses, Aaron and the people's leaders recorded the names of Kohath's descendants in their clans and in their families."
    },
    {
      "verse": "35",
      "text": "They recorded the men who could work in the Tent of Meeting. They recorded them if they were between 30 and 50 years old."
    },
    {
      "verse": "36",
      "text": "They recorded them in clans. There were 2, 750 men."
    },
    {
      "verse": "37",
      "text": "Moses and Aaron recorded the descendants of Kohath who worked at the Tent of Meeting. The Lord had told Moses that they must do that."
    },
    {
      "verse": "38",
      "text": "Moses and Aaron also recorded the names of Gershon's descendants in their clans and in their families."
    },
    {
      "verse": "39",
      "text": "They recorded the men who could work in the Tent of Meeting. They recorded them if they were between 30 and 50 years old."
    },
    {
      "verse": "40",
      "text": "They recorded them in clans and families. There were 2, 630 men."
    },
    {
      "verse": "41",
      "text": "Moses and Aaron recorded the descendants of Gershon who worked at the Tent of Meeting. The Lord had told Moses that they must do that."
    },
    {
      "verse": "42",
      "text": "Moses and Aaron also recorded the names of Merari's descendants in their clans and in their families."
    },
    {
      "verse": "43",
      "text": "They counted all the men who worked in the Tent of Meeting. They counted them if they were between 30 and 50 years old."
    },
    {
      "verse": "44",
      "text": "They recorded them in clans. There were 3, 200 men."
    },
    {
      "verse": "45",
      "text": "Moses and Aaron recorded the descendants of Merari who worked at the Tent of Meeting. The Lord had told Moses that they must do that."
    },
    {
      "verse": "46",
      "text": "Moses, Aaron and the people's leaders recorded the names of the Levites in their clans and in their families."
    },
    {
      "verse": "47",
      "text": "They counted all the men who worked in the Tent of Meeting. And they counted all the men who carried any of its things. They counted them if they were between 30 and 50 years old."
    },
    {
      "verse": "48",
      "text": "There were 8, 580 Levites in the list."
    },
    {
      "verse": "49",
      "text": "They told each man the things that he must do. Or they told him what he must carry. Moses recorded all their names. The Lord had told him that he must do that."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Speak to the Israelites. They must send any person with a disease of the skin away from the camp. Or somebody may have a disease that causes pus to come out of his body. Any person like that is not clean. Anyone who has touched a dead person is also not clean. Send those people out of the camp too."
    },
    {
      "verse": "3",
      "text": "Do this with both men and women. Send them out of the camp. They must not make the camp unclean, because that is where I live among the people. ’"
    },
    {
      "verse": "4",
      "text": "The Israelites did what the Lord had said to Moses. They sent those people outside the camp."
    },
    {
      "verse": "5",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "6",
      "text": "‘Tell these rules to the Israelites: A person might do a wrong thing against another person. If they do, then they have turned against the Lord."
    },
    {
      "verse": "7",
      "text": "That person must agree that they have sinned. They must pay the right amount to the other person. They must also pay them one fifth extra."
    },
    {
      "verse": "8",
      "text": "But the other person may have died. If they have no relative who can accept the money, the money must go to the Lord. The person who did a wrong thing must give the money and a male sheep to the priest. The sheep is a special gift to the Lord to make everything right. Then I will forgive that person."
    },
    {
      "verse": "9",
      "text": "All the special gifts from the Israelites to God are for the priest."
    },
    {
      "verse": "10",
      "text": "The priest will keep all the special gifts. ’"
    },
    {
      "verse": "11",
      "text": "The Lord said to Moses:"
    },
    {
      "verse": "12",
      "text": "‘Speak to the Israelites. Tell them to follow these rules. A woman may do wrong things against her husband."
    },
    {
      "verse": "13",
      "text": "She might have had sex with another man. The husband might not know about this. His wife might have kept it secret. Nobody came in while it was happening. So there is nobody to say that it happened."
    },
    {
      "verse": "14",
      "text": "But the man may think that it happened. He will be angry. But she may not have made herself unclean in that way."
    },
    {
      "verse": "15",
      "text": "The man must take his wife to the priest. He must bring one kilogram of barley flour with him. This is a grain offering to discover if his wife really did do those things. So he must not put oil or incense on the grain offering. That is an offering because the man does not trust his wife."
    },
    {
      "verse": "16",
      "text": "Then the priest will bring the woman to stand in front of the Lord."
    },
    {
      "verse": "17",
      "text": "He must pour some holy water into a bowl that someone has made from clay. He must take some dust from the floor of God's Tent. And he must put the dust into the water."
    },
    {
      "verse": "18",
      "text": "Then the priest must bring the woman in front of the Lord. The priest must make the woman's hair free. He must put into her hands the grain offering. That is the offering because the man does not trust his wife. The priest must hold the bowl that contains the bitter water. The bitter water brings a curse."
    },
    {
      "verse": "19",
      "text": "Then the woman must agree to the strong promise that the priest tells her to say. The priest must say to her, “This water brings a curse. If no other man has had sex with you, it will not hurt you."
    },
    {
      "verse": "20",
      "text": "But if another man has had sex with you, The woman must say, “That should happen. I agree! ”"
    },
    {
      "verse": "21",
      "text": "may the Lord bring the curse on you. The bitter water will cause your female parts to become smaller. Your stomach will become very big."
    },
    {
      "verse": "22",
      "text": "That will happen when you drink the bitter water. ”The woman must say, “That should happen. I agree! ”"
    },
    {
      "verse": "23",
      "text": "The priest must write the curses on special paper. Then he must wash the words off the paper into the bitter water."
    },
    {
      "verse": "24",
      "text": "He must tell the woman that she must drink the bitter water. This water that brings a curse will go into her body. It may cause her to be very ill."
    },
    {
      "verse": "25",
      "text": "But first, the priest must take the grain offering from her hands. That is the offering because the man does not trust his wife. The priest must lift it up in front of the Lord. Then he must bring it to the altar."
    },
    {
      "verse": "26",
      "text": "He must burn a small part of it as a sacrifice. After that, the woman must drink the bitter water."
    },
    {
      "verse": "27",
      "text": "If the woman has had sex with another man, the water will cause her to have very bad pain. Her female parts will become smaller. Her stomach will become very big. And people will curse her."
    },
    {
      "verse": "28",
      "text": "But, if she did not do those wrong things, the water will not hurt her. She will be able to have babies."
    },
    {
      "verse": "31",
      "text": "If the woman did not do those wrong things, you must not punish her husband. But if the woman did do those wrong things, you must punish her. ’"
    },
    {
      "verse": "29",
      "text": "Perhaps a man is jealous because his wife has had sex with another man. Or he may only think that his wife has had sex with another man."
    },
    {
      "verse": "30",
      "text": "This is what the law says that the priest must do: The man must bring her in front of the Lord."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Tell the Israelites this: “A man or a woman may want to make a special promise to the Lord. That will make him or her separate from other people, as a Nazirite."
    },
    {
      "verse": "3",
      "text": "They must not drink wine. They must not drink any alcohol or vinegar. They must not drink the juice of grapes, or eat grapes or raisins."
    },
    {
      "verse": "4",
      "text": "They must not eat the seeds of grapes for all the time that they are Nazirites. They must not even eat the skins of grapes."
    },
    {
      "verse": "5",
      "text": "A person must not cut his hair during the time that he is a Nazirite. He must be different all the time that he is separate for the Lord. He must let the hair on his head grow long."
    },
    {
      "verse": "6",
      "text": "He must not go near a dead body while he is separate for the Lord."
    },
    {
      "verse": "7",
      "text": "His hair shows that he is separate for God. So he must not go near a dead body. He must not go near it even if the dead person is his father, mother, brother or sister."
    },
    {
      "verse": "8",
      "text": "During the time that the person is a Nazirite, they are holy because they belong to the Lord."
    },
    {
      "verse": "9",
      "text": "The Nazirite may be near to a person when that person dies suddenly. Then his head becomes unclean. He must remove all the hair from his head seven days after the person dies. Then he will be clean."
    },
    {
      "verse": "10",
      "text": "On day 8, he must bring two doves or two young pigeons to the door of the Tent of Meeting. He must give them to the priest."
    },
    {
      "verse": "11",
      "text": "The priest must sacrifice one bird as a sin offering and the other bird as a burnt offering. The priest must do that because the Nazirite sinned. He went too near to a dead body. That will make the Nazirite's head clean again on that same day."
    },
    {
      "verse": "12",
      "text": "He must begin his time as a Nazirite again, with a new promise to the Lord. He cannot include the days before he became unclean. He must bring a male lamb that is one year old. That is a guilt offering."
    },
    {
      "verse": "13",
      "text": "He is a Nazirite for a certain time. When that time finishes, the people must bring him to the door of the Tent of Meeting."
    },
    {
      "verse": "14",
      "text": "He must offer to the Lord three animals that have nothing wrong with them. He must offer a young male sheep that is one year old. That is a burnt offering. He must offer a young female sheep that is one year old. That is a sin offering. He must offer a male sheep. That is a friendship offering."
    },
    {
      "verse": "15",
      "text": "And he must bring a basket of bread that people have made without yeast. He must bring cakes that people have made with the best flour and oil. Also, he must bring thin biscuits with oil on them. But they must not have yeast in them either. He must bring the proper grain offerings and drink offerings with them."
    },
    {
      "verse": "16",
      "text": "The priest must offer those things to the Lord. And he must sacrifice the sin offering and the burnt offering."
    },
    {
      "verse": "17",
      "text": "Then the priest must sacrifice the male sheep as a friendship offering to the Lord. He must offer the basket of bread. He must give the grain offering and the drink offering with it."
    },
    {
      "verse": "18",
      "text": "Then the Nazirite must stand at the place where people go into the Tent of Meeting. He must remove all the hair from his head. He must put his hair into the same fire where the priest has cooked the friendship offering."
    },
    {
      "verse": "19",
      "text": "When the male sheep is cooked, the priest must take its shoulder. Also, he must take one cake and one thin biscuit from the basket. The cake and the biscuit must not have yeast in them. The priest must put these things into the hands of the Nazirite who has removed the hair from his head."
    },
    {
      "verse": "20",
      "text": "The Nazirite must give those things back to the priest. The priest must lift them up to the Lord as a special gift. They are a special gift for the priest. Also, the priest can eat the front part of the sheep and its back leg. After that, the Nazirite can drink wine. ”"
    },
    {
      "verse": "21",
      "text": "Those are the rules about Nazirites. Also, the Nazirite may give anything else that he can give. And he must bring any other gift that he promised to the Lord. ’"
    },
    {
      "verse": "22",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "23",
      "text": "‘Tell Aaron and his sons to use these words when they ask me to bless the Israelites."
    },
    {
      "verse": "24",
      "text": "They must say:“I pray that the Lord will bless you. I pray that he will keep you safe. “I pray that the Lord will bless you. I pray that he will keep you safe."
    },
    {
      "verse": "25",
      "text": "I pray that the Lord will smile at you. And I pray that he will be very kind to you. And I pray that he will be very kind to you."
    },
    {
      "verse": "26",
      "text": "I pray that the Lord will be pleased with you. And I pray that he will give you peace in your minds. ” And I pray that he will give you peace in your minds. ”"
    },
    {
      "verse": "27",
      "text": "Aaron and his sons must use my name to bless the Israelites. If they do that, I will certainly bless them. ’"
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "When Moses had put up God's Tent, he poured special oil on it. He also poured it on the things in the tent, the altar and all the tools. This showed that all these things were special for God to use."
    },
    {
      "verse": "2",
      "text": "leaders of Israel's tribes came to God's Tent. They brought gifts. These men were the leaders who had helped to count the people."
    },
    {
      "verse": "3",
      "text": "They brought their gifts to the Lord. They brought six carts, one cart for every two leaders. They brought 12 oxen. That was one ox for each leader. They brought it all to God's Tent."
    },
    {
      "verse": "4",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "5",
      "text": "‘Accept these gifts from the leaders. Give them to the Levites. All the Levites can use them for their work at the Tent of Meeting. ’"
    },
    {
      "verse": "6",
      "text": "So Moses took the carts and the oxen and he gave them to the Levites."
    },
    {
      "verse": "7",
      "text": "He gave two carts and four oxen to the descendants of Gershon."
    },
    {
      "verse": "8",
      "text": "He gave four carts and eight oxen to the descendants of Merari for their work. Ithamar was the son of Aaron. He had to tell the descendants of Merari the work that they should do."
    },
    {
      "verse": "9",
      "text": "But the descendants of Kohath had to carry everything that was special on their shoulders. So Moses did not give any carts or oxen to the descendants of Kohath."
    },
    {
      "verse": "10",
      "text": "When Moses poured special oil on the altar, the leaders also brought gifts. They offered their gifts to God in front of the altar."
    },
    {
      "verse": "11",
      "text": "The Lord said to Moses: ‘One leader must bring a gift to the altar every day. That is how they will make the altar special for me. ’"
    },
    {
      "verse": "12",
      "text": "On the first day, Nahshon, the son of Amminadab from the tribe of Judah brought his gift."
    },
    {
      "verse": "13",
      "text": "He brought a plate and a bowl that someone had made from silver. The plate weighed 130 shekels. The bowl weighed 70 shekels. They had weighed the silver by the shekel of God's Holy Tent. Both of those were full of good flour that he had mixed with oil. They were for a grain offering."
    },
    {
      "verse": "14",
      "text": "He brought one small dish that someone had made from gold. It weighed ten shekels and it was full of incense."
    },
    {
      "verse": "15",
      "text": "He brought one young bull, one male sheep and one male lamb that was less than one year old. Those animals were for a burnt offering."
    },
    {
      "verse": "16",
      "text": "He brought one male goat for a sin offering."
    },
    {
      "verse": "17",
      "text": "He also brought two oxen, five male sheep, five male goats, and five male lambs that were less than one year old. Those animals were for the friendship offerings. That was the gift of Nahshon, the son of Amminadab."
    },
    {
      "verse": "18",
      "text": "On day 2, Nethanel, the son of Zuar, from the tribe of Issachar brought his gift."
    },
    {
      "verse": "19",
      "text": "He brought a plate and a bowl that someone had made from silver. The plate weighed 130 shekels. The bowl weighed 70 shekels. They had weighed the silver by the shekel of God's Holy Tent. Both of those were full of good flour that he had mixed with oil. They were for a grain offering."
    },
    {
      "verse": "20",
      "text": "He brought one small dish that someone had made from gold. It weighed ten shekels and it was full of incense."
    },
    {
      "verse": "21",
      "text": "He brought one young bull, one male sheep and one male lamb that was less than one year old. Those animals were for a burnt offering."
    },
    {
      "verse": "22",
      "text": "He brought one male goat for a sin offering."
    },
    {
      "verse": "23",
      "text": "He also brought two oxen, five male sheep, five male goats, and five male lambs that were less than one year old. Those animals were for the friendship offerings. That was the gift of Nethanel, the son of Zuar."
    },
    {
      "verse": "24",
      "text": "On day 3, Eliab, the son of Helon, from the tribe of Zebulun brought his gift."
    },
    {
      "verse": "25",
      "text": "He brought a plate and a bowl that someone had made from silver. The plate weighed 130 shekels. The bowl weighed 70 shekels. They had weighed the silver by the shekel of God's Holy Tent. Both of those were full of good flour that he had mixed with oil. They were for a grain offering."
    },
    {
      "verse": "26",
      "text": "He brought one small dish that someone had made from gold. It weighed ten shekels and it was full of incense."
    },
    {
      "verse": "27",
      "text": "He brought one young bull, one male sheep and one male lamb that was less than one year old. Those animals were for a burnt offering."
    },
    {
      "verse": "28",
      "text": "He brought one male goat for a sin offering."
    },
    {
      "verse": "29",
      "text": "He also brought two oxen, five male sheep, five male goats, and five male lambs that were less than one year old. Those animals were for the friendship offerings. That was the gift of Eliab, the son of Helon."
    },
    {
      "verse": "30",
      "text": "On day 4, Elizur, the son of Shedeur, from the tribe of Reuben brought his gift."
    },
    {
      "verse": "31",
      "text": "He brought a plate and a bowl that someone had made from silver. The plate weighed 130 shekels. The bowl weighed 70 shekels. They had weighed the silver by the shekel of God's Holy Tent. Both of those were full of good flour that he had mixed with oil. They were for a grain offering."
    },
    {
      "verse": "32",
      "text": "He brought one small dish that someone had made from gold. It weighed ten shekels and it was full of incense."
    },
    {
      "verse": "33",
      "text": "He brought one young bull, one male sheep and one male lamb that was less than one year old. Those animals were for a burnt offering."
    },
    {
      "verse": "34",
      "text": "He brought one male goat for a sin offering."
    },
    {
      "verse": "35",
      "text": "He also brought two oxen, five male sheep, five male goats, and five male lambs that were less than one year old. Those animals were for the friendship offerings. That was the gift of Elizur, the son of Shedeur."
    },
    {
      "verse": "36",
      "text": "On day 5, Shelumiel, the son of Zurishaddai, from the tribe of Simeon brought his gift."
    },
    {
      "verse": "37",
      "text": "He brought a plate and a bowl that someone had made from silver. The plate weighed 130 shekels. The bowl weighed 70 shekels. They had weighed the silver by the shekel of God's Holy Tent. Both of those were full of good flour that he had mixed with oil. They were for a grain offering."
    },
    {
      "verse": "38",
      "text": "He brought one small dish that someone had made from gold. It weighed ten shekels and it was full of incense."
    },
    {
      "verse": "39",
      "text": "He brought one young bull, one male sheep and one male lamb that was less than one year old. Those animals were for a burnt offering."
    },
    {
      "verse": "40",
      "text": "He brought one male goat for a sin offering."
    },
    {
      "verse": "41",
      "text": "He also brought two oxen, five male sheep, five male goats, and five male lambs that were less than one year old. Those animals were for the friendship offerings. That was the gift of Shelumiel, the son of Zurishaddai."
    },
    {
      "verse": "42",
      "text": "On day 6, Eliasaph, the son of Deuel, from the tribe of Gad brought his gift."
    },
    {
      "verse": "43",
      "text": "He brought a plate and a bowl that someone had made from silver. The plate weighed 130 shekels. The bowl weighed 70 shekels. They had weighed the silver by the shekel of God's Holy Tent. Both of those were full of good flour that he had mixed with oil. They were for a grain offering."
    },
    {
      "verse": "44",
      "text": "He brought one small dish that someone had made from gold. It weighed ten shekels and it was full of incense."
    },
    {
      "verse": "45",
      "text": "He brought one young bull, one male sheep and one male lamb that was less than one year old. Those animals were for a burnt offering."
    },
    {
      "verse": "46",
      "text": "He brought one male goat for a sin offering."
    },
    {
      "verse": "47",
      "text": "He also brought two oxen, five male sheep, five male goats, and five male lambs that were less than one year old. Those animals were for the friendship offerings. That was the gift of Eliasaph, the son of Deuel."
    },
    {
      "verse": "48",
      "text": "On day 7, Elishama, the son of Ammihud, from the tribe of Ephraim brought his gift."
    },
    {
      "verse": "49",
      "text": "He brought a plate and a bowl that someone had made from silver. The plate weighed 130 shekels. The bowl weighed 70 shekels. They had weighed the silver by the shekel of God's Holy Tent. Both of those were full of good flour that he had mixed with oil. They were for a grain offering."
    },
    {
      "verse": "50",
      "text": "He brought one small dish that someone had made from gold. It weighed ten shekels and it was full of incense."
    },
    {
      "verse": "51",
      "text": "He brought one young bull, one male sheep and one male lamb that was less than one year old. Those animals were for a burnt offering."
    },
    {
      "verse": "52",
      "text": "He brought one male goat for a sin offering."
    },
    {
      "verse": "53",
      "text": "He also brought two oxen, five male sheep, five male goats, and five male lambs that were less than one year old. Those animals were for the friendship offerings. That was the gift of Elishama, the son of Ammihud."
    },
    {
      "verse": "54",
      "text": "On day 8, Gamaliel, the son of Pedahzur, from the tribe of Manasseh brought his gift."
    },
    {
      "verse": "55",
      "text": "He brought a plate and a bowl that someone had made from silver. The plate weighed 130 shekels. The bowl weighed 70 shekels. They had weighed the silver by the shekel of God's Holy Tent. Both of those were full of good flour that he had mixed with oil. They were for a grain offering."
    },
    {
      "verse": "56",
      "text": "He brought one small dish that someone had made from gold. It weighed ten shekels and it was full of incense."
    },
    {
      "verse": "57",
      "text": "He brought one young bull, one male sheep and one male lamb that was less than one year old. Those animals were for a burnt offering."
    },
    {
      "verse": "58",
      "text": "He brought one male goat for a sin offering."
    },
    {
      "verse": "59",
      "text": "He also brought two oxen, five male sheep, five male goats, and five male lambs that were less than one year old. Those animals were for the friendship offerings. That was the gift of Gamaliel, the son of Pedahzur."
    },
    {
      "verse": "60",
      "text": "On day 9, Abidan, the son of Gideoni, from the tribe of Benjamin brought his gift."
    },
    {
      "verse": "61",
      "text": "He brought a plate and a bowl that someone had made from silver. The plate weighed 130 shekels. The bowl weighed 70 shekels. They had weighed the silver by the shekel of God's Holy Tent. Both of those were full of good flour that he had mixed with oil. They were for a grain offering."
    },
    {
      "verse": "62",
      "text": "He brought one small dish that someone had made from gold. It weighed ten shekels and it was full of incense."
    },
    {
      "verse": "63",
      "text": "He brought one young bull, one male sheep and one male lamb that was less than one year old. Those animals were for a burnt offering."
    },
    {
      "verse": "64",
      "text": "He brought one male goat for a sin offering."
    },
    {
      "verse": "65",
      "text": "He also brought two oxen, five male sheep, five male goats, and five male lambs that were less than one year old. Those animals were for the friendship offerings. That was the gift of Abidan, the son of Gideoni."
    },
    {
      "verse": "66",
      "text": "On day 10, Ahiezer, the son of Ammishaddai, from the tribe of Dan brought his gift."
    },
    {
      "verse": "67",
      "text": "He brought a plate and a bowl that someone had made from silver. The plate weighed 130 shekels. The bowl weighed 70 shekels. They had weighed the silver by the shekel of God's Holy Tent. Both of those were full of good flour that he had mixed with oil. They were for a grain offering."
    },
    {
      "verse": "68",
      "text": "He brought one small dish that someone had made from gold. It weighed ten shekels and it was full of incense."
    },
    {
      "verse": "69",
      "text": "He brought one young bull, one male sheep and one male lamb that was less than one year old. Those animals were for a burnt offering."
    },
    {
      "verse": "70",
      "text": "He brought one male goat for a sin offering."
    },
    {
      "verse": "71",
      "text": "He also brought two oxen, five male sheep, five male goats, and five male lambs that were less than one year old. Those animals were for the friendship offerings. That was the gift of Ahiezer, the son of Ammishaddai."
    },
    {
      "verse": "72",
      "text": "On day 11, Pagiel, the son of Ocran, from the tribe of Asher brought his gift."
    },
    {
      "verse": "73",
      "text": "He brought a plate and a bowl that someone had made from silver. The plate weighed 130 shekels. The bowl weighed 70 shekels. They had weighed the silver by the shekel of God's Holy Tent. Both of those were full of good flour that he had mixed with oil. They were for a grain offering."
    },
    {
      "verse": "74",
      "text": "He brought one small dish that someone had made from gold. It weighed ten shekels and it was full of incense."
    },
    {
      "verse": "75",
      "text": "He brought one young bull, one male sheep and one male lamb that was less than one year old. Those animals were for a burnt offering."
    },
    {
      "verse": "76",
      "text": "He brought one male goat for a sin offering."
    },
    {
      "verse": "77",
      "text": "He also brought two oxen, five male sheep, five male goats, and five male lambs that were less than one year old. Those animals were for the friendship offerings. That was the gift of Pagiel, the son of Ocran."
    },
    {
      "verse": "78",
      "text": "On day 12, Ahira, the son of Enan, from the tribe of Naphtali brought his gift."
    },
    {
      "verse": "79",
      "text": "He brought a plate and a bowl that someone had made from silver. The plate weighed 130 shekels. The bowl weighed 70 shekels. They had weighed the silver by the shekel of God's Holy Tent. Both of those were full of good flour that he had mixed with oil. They were for a grain offering."
    },
    {
      "verse": "80",
      "text": "He brought one small dish that someone had made from gold. It weighed ten shekels and it was full of incense."
    },
    {
      "verse": "81",
      "text": "He brought one young bull, one male sheep and one male lamb that was less than one year old. Those animals were for a burnt offering."
    },
    {
      "verse": "82",
      "text": "He brought one male goat for a sin offering."
    },
    {
      "verse": "83",
      "text": "He also brought two oxen, five male sheep, five male goats, and five male lambs that were less than one year old. Those animals were for the friendship offerings. That was the gift of Ahira, the son of Enan."
    },
    {
      "verse": "84",
      "text": "The leaders of Israel brought these gifts to the altar when Moses poured special oil on it. They brought all the gifts in the list below. They brought 12 plates and 12 bowls that people had made from silver."
    },
    {
      "verse": "85",
      "text": "shekels and each bowl weighed 70 shekels. All the silver weighed 2, 400 shekels. That was the shekel of God's Holy Tent."
    },
    {
      "verse": "86",
      "text": "small dishes that people had made from gold. Each small dish weighed ten shekels. They were each full of incense. All the gold weighed 120 shekels."
    },
    {
      "verse": "87",
      "text": "young bulls, 12 male sheep and 12 male lambs that were one year old. They also brought the proper grain offerings with those animals. And they brought 12 male goats for a sin offering."
    },
    {
      "verse": "88",
      "text": "oxen, 60 male sheep, 60 male goats and 60 male lambs. The male lambs were one year old. Those animals were for the friendship offering. That was the offering when they made the altar special for God. That was after Moses had poured special oil on it."
    },
    {
      "verse": "89",
      "text": "When Moses went into the Tent of Meeting, to speak with the Lord, the Lord did speak to him. And Moses heard the Lord. The sound came from above the lid which was on the top of the Covenant Box. On the lid, there were images of two cherubs. The sound came from between the cherubs. That was how the Lord spoke to Moses."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Then the Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Speak to Aaron and say to him, “When you put the lamps on the lampstand, the seven lamps must give light in front of the lampstand. ” ’"
    },
    {
      "verse": "3",
      "text": "So Aaron did that. He put its lamps at the front of the lampstand, as the Lord had said to Moses."
    },
    {
      "verse": "4",
      "text": "A worker had made the lampstand from one piece of gold that he had made flat with a hammer. From its base to the flowers at the top, he had made it in that way. It was completely like the lampstand that the Lord had shown to Moses."
    },
    {
      "verse": "5",
      "text": "Again the Lord spoke to Moses and he said,"
    },
    {
      "verse": "6",
      "text": "‘Take the Levites from among the Israelites and make them clean."
    },
    {
      "verse": "7",
      "text": "You will make them clean like this: Put on them the special water that makes people clean. They must remove all the hair from their whole body, and they must wash their clothes. Then they will be clean."
    },
    {
      "verse": "8",
      "text": "Then they must take a bull with the proper grain offering and oil. And you must take another bull for a sin offering."
    },
    {
      "verse": "9",
      "text": "Then you must bring the Levites in front of the Tent of Meeting. You must also bring all the Israelites there."
    },
    {
      "verse": "10",
      "text": "You must bring the Levites in front of the Lord. Then the Israelites must put their hands on the Levites' heads."
    },
    {
      "verse": "11",
      "text": "Aaron must give the Levites to the Lord as a special offering from the Israelites. Then they will be ready to do the Lord's work."
    },
    {
      "verse": "12",
      "text": "Then the Levites must put their hands on the heads of the bulls. Then offer one bull for a sin offering and the other one for a burnt offering to the Lord. That will make peace with the Lord for the Levites sin."
    },
    {
      "verse": "13",
      "text": "And you must cause the Levites to stand in front of Aaron and his sons. So they will be a special gift to the Lord."
    },
    {
      "verse": "14",
      "text": "That is how you will make the Levites separate from the other Israelites. And then the Levites will be mine."
    },
    {
      "verse": "15",
      "text": "Then after that the Levites can go in to work in the Tent of Meeting. But you must make them clean and you must bring them to me as a special gift."
    },
    {
      "verse": "16",
      "text": "That is because all the Levites among the Israelites are mine. All the Israelites' firstborn sons are mine. But I have taken the Levites for myself instead."
    },
    {
      "verse": "17",
      "text": "Every firstborn son among the Israelites is mine. And all the firstborn male animals are mine too. On the day that I killed all the firstborn sons in Egypt I made them special for myself."
    },
    {
      "verse": "18",
      "text": "But now I have not taken all the firstborn sons among the Israelites. I have taken the Levites instead."
    },
    {
      "verse": "19",
      "text": "And I have given the Levites as a gift to Aaron and to his sons from among the Israelites. They will work at the Tent of Meeting on behalf of the Israelites. And they will make peace with me on behalf of the Israelites. So there will not be a bad disease among the Israelites when they go near to God's Holy Tent. ’"
    },
    {
      "verse": "20",
      "text": "So Moses and Aaron and all the Israelites did those things to the Levites. The Israelites did everything that the Lord had said to Moses about the Levites."
    },
    {
      "verse": "21",
      "text": "The Levites, too, made themselves clean and they washed their clothes. And Aaron brought them in front of Lord as a special gift. Aaron also burnt sacrifices to make them clean."
    },
    {
      "verse": "22",
      "text": "After that, the Levites went in to do their work in the Tent of Meeting. They helped Aaron and his sons. The Israelites did everything with the Levites that the Lord had said to Moses about them."
    },
    {
      "verse": "23",
      "text": "Then the Lord spoke to Moses again and he said,"
    },
    {
      "verse": "24",
      "text": "‘These are the rules about the Levites: The men who are 25 years old or older must go in to work in the Tent of Meeting."
    },
    {
      "verse": "25",
      "text": "years old. And they must not do that work after that."
    },
    {
      "verse": "26",
      "text": "But they can help the other Levites in the Tent of Meeting. They can help them to do their jobs. But they themselves must not have any jobs. Those are the rules about the Levites and about their jobs. ’"
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "The Lord spoke to Moses in the Sinai desert. The Israelites had left Egypt. It was the second year after the Israelites had left that country. It was the first month during that year. The Lord said,"
    },
    {
      "verse": "2",
      "text": "‘The Israelites must eat the Passover meal at the proper time. They must eat it as the rules about it say."
    },
    {
      "verse": "3",
      "text": "The proper time is during the evening of the 14th day of this month. It is when it starts to become dark. That is when you must eat it. You must obey all its rules and its laws. ’"
    },
    {
      "verse": "4",
      "text": "So Moses told the Israelites that they should eat the Passover."
    },
    {
      "verse": "5",
      "text": "So they ate the Passover in the first month, on the 14th day when it started to become dark. That was in the Sinai desert. The Israelites did everything that the Lord had said to Moses about it."
    },
    {
      "verse": "6",
      "text": "But there were some people who were not clean. That was because they had touched a dead body. So they could not eat the Passover on that day. So they came to Moses and Aaron on that day."
    },
    {
      "verse": "7",
      "text": "And those people said to Moses, ‘We are not clean because of the dead body that we touched. But we would like to bring our gift to the Lord at the proper time with the other Israelites. ’"
    },
    {
      "verse": "8",
      "text": "So Moses said to them, ‘Wait here. Then I will ask the Lord about this. ’"
    },
    {
      "verse": "9",
      "text": "Then the Lord said to Moses,"
    },
    {
      "verse": "10",
      "text": "‘Say to the Israelites, “Anyone among you or your descendants may become not clean because of a dead body. Or they may be away because they are travelling. They can still eat the Passover meal to thank the Lord."
    },
    {
      "verse": "11",
      "text": "They must eat it during the evening of the 14th day of the second month. They must eat it when it starts to become dark. They must eat it with bread and with bitter herbs. The bread must not have yeast in it."
    },
    {
      "verse": "12",
      "text": "They must not keep any of the food until the next morning. And they must not break any of the bones of the lamb. And they must obey all the rules about the Passover."
    },
    {
      "verse": "13",
      "text": "But perhaps a clean person who is at home chooses not to eat the Passover meal. You must make that person separate from his people. That is because he did not offer the proper sacrifices to the Lord at the proper time. So that person must receive the punishment for his sin."
    },
    {
      "verse": "14",
      "text": "People from foreign countries may also eat the Lord's Passover meal, if they are living among you. But they must obey all the rules about the Passover festival. The rules are the same for a foreign person and for an Israelite. ” ’"
    },
    {
      "verse": "15",
      "text": "On the day that Moses put up the Tent of Meeting, a cloud covered it. In the evening it became something like a fire over the Tent, until morning."
    },
    {
      "verse": "16",
      "text": "It was like that all the time. The cloud covered it during the day. But at night, the cloud seemed to have fire in it."
    },
    {
      "verse": "17",
      "text": "When the cloud went up from God's Tent, the Israelites started to travel. And when the cloud came down, the Israelites made their camp in that place."
    },
    {
      "verse": "18",
      "text": "The Lord decided when the Israelites should start to travel. And the Lord decided where they should stop and make their camp. During all the time that the cloud was over the tabernacle, they stayed in their camp."
    },
    {
      "verse": "19",
      "text": "Even when the cloud stayed over the tabernacle for many days, the Israelites obeyed the Lord. They did not start to travel."
    },
    {
      "verse": "20",
      "text": "Sometimes the cloud stayed over God's Tent for a few days. Then they remained in their camp. When the Lord showed them that they should travel, they started to travel."
    },
    {
      "verse": "21",
      "text": "Sometimes the cloud stayed there from evening until morning. But, when the cloud went up in the morning, they started to travel. But sometimes it stayed for one day and one night. Then when the cloud went up, they started to travel again."
    },
    {
      "verse": "22",
      "text": "Sometimes the cloud continued to be over God's Tent for two days or for a month or for a year. It stayed above it. Then, the Israelites stayed in their camp. They did not start to travel. But when it went up, they did start to travel."
    },
    {
      "verse": "23",
      "text": "The Lord decided when they should make their camp. And the Lord decided when they should start to travel. So they obeyed the Lord about everything that the Lord said to Moses."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Make two trumpets from one piece of silver. Use a hammer to make them in the right shape. Make a noise with them to tell the people that they must come together. Also, use the trumpets to tell the people that they must move the camp."
    },
    {
      "verse": "3",
      "text": "When the people hear the sound from both trumpets, all the people must meet you. They must meet you at the door of the Tent of Meeting."
    },
    {
      "verse": "4",
      "text": "But you may want only the leaders of Israel's tribes to meet you. If you want that, a priest should make the sound from only one trumpet."
    },
    {
      "verse": "5",
      "text": "But when the sound is one short sound, the tribes on the east side of the camp must start to travel."
    },
    {
      "verse": "6",
      "text": "When they hear the next short sound, the tribes on the south side of the camp must start to travel. Short sounds from the trumpet will tell the people that they must start to travel."
    },
    {
      "verse": "7",
      "text": "But when you want everyone to meet together, make a different sound with the trumpet."
    },
    {
      "verse": "8",
      "text": "The priests, the sons of Aaron, must use the trumpets to make a noise. This is a rule for you and for all your descendants."
    },
    {
      "verse": "9",
      "text": "Use the trumpets to tell everyone when an enemy is attacking you in your own land. Make a sound with the trumpets to tell the people that they must fight the enemy. Then the Lord your God will hear and he will save you from your enemies."
    },
    {
      "verse": "10",
      "text": "You must make sounds with the trumpets on your happy days, too. And you must make sounds with the trumpets at your regular festivals and on the first days of your months. And you must make sounds with the trumpets over your burnt offerings, and over your friendship offerings. God will hear and he will remember you. I am the Lord your God. ’"
    },
    {
      "verse": "11",
      "text": "In the second year, in the second month, on the 20th day of the month, the cloud went up. It went away from God's Tent of Meeting."
    },
    {
      "verse": "12",
      "text": "So the Israelites started to travel on their journey away from the Sinai desert. Then the cloud stopped in the desert called Paran."
    },
    {
      "verse": "13",
      "text": "They started to travel for the first time, in the way that the Lord had told them to do, through Moses."
    },
    {
      "verse": "14",
      "text": "The flag of the camp of Judah's tribe, started to travel first, with all their armies. And Nahshon the son of Amminadab was over all their armies."
    },
    {
      "verse": "15",
      "text": "Nethanel, the son of Zuar, was over the army of the tribe of Issachar."
    },
    {
      "verse": "16",
      "text": "Eliab, the son of Helon, was over the army of the tribe of Zebulun."
    },
    {
      "verse": "17",
      "text": "Then the Levites packed God's Tent. Then Gershon's clan and Merari's clan, who were carrying God's Tent, started to travel."
    },
    {
      "verse": "18",
      "text": "Next the flag of the camp of Reuben started to travel, with all their armies. Elizur, the son of Shedeur, was over all their armies."
    },
    {
      "verse": "19",
      "text": "Shelumiel, the son of Zurishaddai, was over the army of the tribe of Simeon."
    },
    {
      "verse": "20",
      "text": "Eliasaph, the son of Deuel, was over the army of the tribe of Gad."
    },
    {
      "verse": "21",
      "text": "Then Kohath's clan started to travel. They were carrying the holy things. Before they arrived at the new camp, the other Levites would put up God's Tent."
    },
    {
      "verse": "22",
      "text": "Next the flag of the camp of the tribe of Ephraim started to travel, with all their armies. Elishama the son of Ammihud was over all their armies."
    },
    {
      "verse": "23",
      "text": "And Gamaliel the son of Pedahzur was over the army of the tribe of Manasseh."
    },
    {
      "verse": "24",
      "text": "And Abidan the son of Gideoni was over the army of the tribe of Benjamin."
    },
    {
      "verse": "25",
      "text": "Then the flag of the camp of the tribe of Dan started to travel last, with all their armies. They could keep the Israelites safe if an enemy attacked them from behind them. Ahiezer the son of Ammishaddai was over all their armies."
    },
    {
      "verse": "26",
      "text": "And Pagiel the son of Ocran was over the army of the tribe of Asher."
    },
    {
      "verse": "27",
      "text": "And Ahira the son of Enan was over the army of the tribe of Naphtali."
    },
    {
      "verse": "28",
      "text": "The Israelites marched out like that every time that they started to travel."
    },
    {
      "verse": "29",
      "text": "Moses spoke to Reuel's son, Hobab. He was the brother of Moses' wife. He was a Midianite. Moses said to Hobab, ‘We are leaving here now to go to another place. The Lord has said to us, “I will give that place to you. ” The Lord has promised to help Israel's people with good things. So come with us and we will take care of you. ’"
    },
    {
      "verse": "30",
      "text": "But Hobab said to him, ‘I will not come. Instead, I will return to my own country and to my family there. ’"
    },
    {
      "verse": "31",
      "text": "Moses said, ‘Please do not leave us. You know good places for us to put up our tents in the desert. So you can be our guide."
    },
    {
      "verse": "32",
      "text": "And if you come with us, we will share with you the good things that the Lord gives to us. ’"
    },
    {
      "verse": "33",
      "text": "So the Israelites left the Lord's mountain. They travelled for three days. During that time, the Levites carried the Lord's Covenant Box in front of them. That was so that the Lord could show them where to make their camp."
    },
    {
      "verse": "34",
      "text": "And the Lord's cloud was over them during the day, whenever they started to travel from the camp."
    },
    {
      "verse": "35",
      "text": "Each time that the Covenant Box started to travel Moses said, ‘Be ready, Lord! Cause your enemies to run away in every direction! ’"
    },
    {
      "verse": "36",
      "text": "When they stopped travelling, Moses said, ‘Return, Lord, to be near to the thousands of Israel's people. ’"
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "But the people started to complain about their problems. The Lord heard them and he became very angry. He sent fire. The Lord sent his fire to burn among them. It destroyed some parts of the camp at the edge."
    },
    {
      "verse": "2",
      "text": "So the people asked Moses to help them. And Moses prayed to the Lord, and the fire stopped."
    },
    {
      "verse": "3",
      "text": "So that place was called Taberah, because the Lord's fire burned among them there."
    },
    {
      "verse": "4",
      "text": "Some foreign people were travelling with the Israelites. Those people wanted very much to eat better food. So the Israelites wept again. They said, ‘We want meat to eat!"
    },
    {
      "verse": "5",
      "text": "We remember the fish that we ate in Egypt. We had as much as we wanted. And we remember all the nice vegetables, cucumbers, leeks, onions and garlic. And we remember the melons."
    },
    {
      "verse": "6",
      "text": "But now our mouths are dry and we do not want to eat this food. There is not even anything to look at, except this manna. ’"
    },
    {
      "verse": "7",
      "text": "The manna was like small seeds called coriander. Its colour was yellow and white."
    },
    {
      "verse": "8",
      "text": "The people walked about and they picked it up from the ground. They used stones to make it into flour. Or they beat it with a stick. They boiled it in pots, and they made cakes with it. The taste of the cakes was like olive oil."
    },
    {
      "verse": "9",
      "text": "At night, dew fell on the ground in the camp. The manna fell with the dew."
    },
    {
      "verse": "10",
      "text": "People in every family were crying at the doors of their tents. And Moses heard them. The Lord became very angry with the people. Moses too was not happy."
    },
    {
      "verse": "11",
      "text": "So Moses said to the Lord, ‘I am your servant. But you have given this problem to me! It seems that you are not pleased with me. You have given to me the hard job to be leader of all these people."
    },
    {
      "verse": "12",
      "text": "They are not my children! But you have said to me, “Take care of them like parents take care of their babies. Carry them to the land that I have promised to their ancestors. ”"
    },
    {
      "verse": "13",
      "text": "They are complaining to me. They are saying, “Give us meat that we can eat! ” But I cannot get meat to feed all these people!"
    },
    {
      "verse": "14",
      "text": "I cannot be the leader of all these people unless I receive help. This job is too difficult for me."
    },
    {
      "verse": "15",
      "text": "So if you do not want to help me, please kill me now. I do not want to continue to be so upset. So please be kind to me. ’"
    },
    {
      "verse": "16",
      "text": "So the Lord said to Moses, ‘Choose 70 leaders of the Israelites and bring them to the Tent of Meeting. You must know that they are leaders and officers that the people respect. Bring them to stand there with you."
    },
    {
      "verse": "17",
      "text": "Then I will come down and I will speak with you there. I will take some of the authority of my Spirit that I gave to you. I will share it with them. Then they will help you to lead the people. So you will not be the only man who is doing that job."
    },
    {
      "verse": "18",
      "text": "Then say to the people, “The Lord heard you when you were weeping. You said, ‘We want someone to give us meat to eat! Life was better when we were in Egypt. ’ So the Lord will give you meat and you will eat it. So make yourselves clean for tomorrow, and then you will eat meat."
    },
    {
      "verse": "19",
      "text": "You will not eat it only for one day, or two days, or five days, or ten days, or 20 days."
    },
    {
      "verse": "20",
      "text": "You will eat it every day for a whole month! You will hate the smell of it and it will seem disgusting to you. This is because you have turned against the Lord. He is near to you and you have wept in front of him. You have said, ‘We should never have left Egypt. ’ ” ’"
    },
    {
      "verse": "21",
      "text": "Moses said to the Lord, ‘There are 600, 000 men here. But you have said, “I will give to them meat to eat for a whole month. ”"
    },
    {
      "verse": "22",
      "text": "Even if we killed all our sheep and cows, we would not have enough meat for them. If we caught every fish in the sea, we still would not have enough! ’"
    },
    {
      "verse": "23",
      "text": "Then the Lord said to Moses, ‘Do you think that I, the Lord, do not have enough power to do this? I have promised you to do it. So now you will see me do it! ’"
    },
    {
      "verse": "24",
      "text": "So Moses went out from God's Tent and he told the people the Lord's message. He chose 70 leaders of the Israelites and he put them round the Tent."
    },
    {
      "verse": "25",
      "text": "Then the Lord came down in the cloud to speak to them. He took some of the authority of his Spirit that he had given to Moses. And he shared it with the 70 leaders. While God's Spirit stayed on them, they prophesied. But they did not do it again after that."
    },
    {
      "verse": "26",
      "text": "But two men had stayed in the camp. Their names were Eldad and Medad. They were among the men that Moses had chosen. But they had not gone to meet with God in the special Tent. God's Spirit also came on them. So they prophesied in the camp."
    },
    {
      "verse": "27",
      "text": "A young man ran to Moses and he said, ‘Eldad and Medad are prophesying in the camp. ’"
    },
    {
      "verse": "28",
      "text": "Nun's son Joshua was there. Since he was a boy, he had been Moses' servant. Joshua said to Moses, ‘Moses, my master, stop them. ’"
    },
    {
      "verse": "29",
      "text": "But Moses said to him, ‘Perhaps you think that I might be jealous of them. But I would be happy if the Lord would give his Spirit to all his people. I would like them all to be prophets! ’"
    },
    {
      "verse": "30",
      "text": "Then Moses and the leaders returned to the camp."
    },
    {
      "verse": "31",
      "text": "Then the Lord sent a wind. It blew in birds called quails from the sea. They fell to the ground everywhere round the camp. There were birds everywhere as far as a person could walk in one day in any direction. They were about 1 metre deep all over the ground."
    },
    {
      "verse": "32",
      "text": "The people were picking up the birds all day and all night and all the next day. Each person got at least 220 litres of birds. They put their dead bodies on the ground everywhere round the camp."
    },
    {
      "verse": "33",
      "text": "But the Lord became very angry with the people. They had not even started to eat the meat when the Lord sent a very bad disease among them."
    },
    {
      "verse": "34",
      "text": "They buried there the bodies of people who had wanted better food. So the people called that place Kibroth-Hattaavah."
    },
    {
      "verse": "35",
      "text": "From Kibroth-Hattaavah the people travelled to Hazeroth, and they stayed at Hazeroth."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "Moses had married a woman who was a descendant of Cush. Miriam and Aaron spoke against Moses because he had married that woman."
    },
    {
      "verse": "2",
      "text": "They said, ‘We do not believe that the Lord has really spoken only by Moses. We believe that he has spoken by us too. ’ The Lord heard what they said."
    },
    {
      "verse": "3",
      "text": "Moses was a very humble man. He was the most humble person in the whole world."
    },
    {
      "verse": "4",
      "text": "Immediately, the Lord said to Moses, Aaron and Miriam, ‘You three people come out to the Tent of Meeting. ’ So the three people went there."
    },
    {
      "verse": "5",
      "text": "Then the Lord came down in a pillar of cloud. He stood at the door of the tent. He said that Aaron and Miriam should come nearer. They both came nearer."
    },
    {
      "verse": "6",
      "text": "Then he said, ‘Listen to my words! If there is a prophet among you, I, the Lord, will show myself to him in a vision. Or I will speak to him in a dream."
    },
    {
      "verse": "7",
      "text": "But it is different when I speak to Moses. He is the one that I trust to lead all my people."
    },
    {
      "verse": "8",
      "text": "I speak clearly to him, as I come near to him. I do not say things to him that are hard to understand. He even sees the shape of the Lord. So you should have been afraid to speak against my servant Moses! ’"
    },
    {
      "verse": "9",
      "text": "So the Lord was very angry with Aaron and Miriam and he left them."
    },
    {
      "verse": "10",
      "text": "But when the cloud had gone away from over the tent, Miriam's skin became white, like snow. She now had the bad disease called leprosy in her skin. Aaron looked at her and he saw that she had leprosy."
    },
    {
      "verse": "11",
      "text": "Then Aaron said to Moses, ‘My master, please do not punish us because we have done this very silly thing. We have done a bad thing."
    },
    {
      "verse": "12",
      "text": "But do not let Miriam be like a baby that is born dead, with a body that is only half there. ’"
    },
    {
      "verse": "13",
      "text": "So Moses called loudly to the Lord, ‘Please God, make her well again! ’"
    },
    {
      "verse": "14",
      "text": "But the Lord said to Moses, ‘Even if her father had spat on her face, she would have to be ashamed for seven days. So you must keep her outside the camp for seven days. After that you can let her come back inside the camp. ’"
    },
    {
      "verse": "15",
      "text": "So Moses kept Miriam outside the camp for seven days. The people did not start to travel again until they had brought Miriam back into the camp again."
    },
    {
      "verse": "16",
      "text": "After that, the people left Hazeroth. They went to the Paran desert and they put up their tents there."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "Then the Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘I will give the land of Canaan to the Israelites. Now you must send men to explore that land. Choose one man from each tribe of your ancestors. Each man must be a leader among his tribe. ’"
    },
    {
      "verse": "3",
      "text": "So Moses obeyed the Lord's command. He sent the men from the Paran desert into Canaan. Each man was a leader among the Israelites."
    },
    {
      "verse": "4",
      "text": "This is a list of their names: From Reuben's tribe: Shammua, the son of Zaccur."
    },
    {
      "verse": "5",
      "text": "From Simeon's tribe: Shaphat, the son of Hori."
    },
    {
      "verse": "6",
      "text": "From Judah's tribe: Caleb, the son of Jephunneh."
    },
    {
      "verse": "7",
      "text": "From Issachar's tribe: Igal, the son of Joseph."
    },
    {
      "verse": "8",
      "text": "From Ephraim's tribe: Hoshea, the son of Nun."
    },
    {
      "verse": "9",
      "text": "From Benjamin's tribe: Palti, the son of Raphu."
    },
    {
      "verse": "10",
      "text": "From Zebulun's tribe: Gaddiel, the son of Sodi."
    },
    {
      "verse": "11",
      "text": "From Manasseh's tribe: Gaddi, the son of Susi."
    },
    {
      "verse": "12",
      "text": "From Dan's tribe: Ammiel, the son of Gemalli."
    },
    {
      "verse": "13",
      "text": "From Asher's tribe: Sethur, the son of Michael."
    },
    {
      "verse": "14",
      "text": "From Naphtali's tribe: Nahbi, the son of Vophsi."
    },
    {
      "verse": "15",
      "text": "From Gad's tribe: Geuel, the son of Maki."
    },
    {
      "verse": "16",
      "text": "Those are the names of the men that Moses sent to explore the land. Moses changed the name of Hoshea, the son of Nun, to Joshua."
    },
    {
      "verse": "17",
      "text": "Moses sent them to explore the land of Canaan. He said to them, ‘Go north from here, through the Negev desert. Then continue to go north, into the place where there are hills."
    },
    {
      "verse": "18",
      "text": "Look at the land to see what it is like. See whether the people who live there are strong or weak. See whether few people or many people live there."
    },
    {
      "verse": "19",
      "text": "See whether their land is good or bad. Look at the towns where the people live. See if they have strong walls or they are in the open."
    },
    {
      "verse": "20",
      "text": "See whether the land is able to make good food grow there, or not. See whether there are forests that grow there. Then try to get some fruit from the land and bring it back here. ’ (It was the time of year for the first grapes to be ready to eat. )"
    },
    {
      "verse": "21",
      "text": "So the men went and they explored the land of Canaan. They started in the desert called Zin, and they continued to Rehob, near Lebo-Hamath."
    },
    {
      "verse": "22",
      "text": "When they had gone up through the Negev desert in the south of the land, they arrived at Hebron. That was where Ahiman, Sheshai and Talmai, the descendants of Anak, were living. They had built Hebron seven years before the Egyptians built Zoan."
    },
    {
      "verse": "23",
      "text": "Then the men came to the valley called Eshcol. They cut a branch which had one group of grapes on it. It was so large that two men carried it between them on a pole. They also brought some other fruits called pomegranates and figs."
    },
    {
      "verse": "24",
      "text": "They called that valley ‘Eshcol’ because of the large group of grapes that the Israelites cut down there."
    },
    {
      "verse": "25",
      "text": "The men returned after they had explored the land for 40 days."
    },
    {
      "verse": "26",
      "text": "The men came back to Kadesh in the Paran desert. They brought their message to Moses and Aaron and to all the Israelites there. They told them all about the land of Canaan and they showed its fruit to them."
    },
    {
      "verse": "27",
      "text": "They said to Moses, ‘We went to look at the land where you sent us. It is certainly a land where there is plenty of food and drink, enough for everyone. This is some of its fruit."
    },
    {
      "verse": "28",
      "text": "But the people who live in the land are strong. Their towns are very big, and strong walls keep them safe. Also, we saw some descendants of Anak there."
    },
    {
      "verse": "29",
      "text": "The Amalekites are living in Negev, the land in the south of the country. The Hittites, Jebusites and Amorites live in the hills. And the Canaanites live by the sea and by the edge of Jordan River. ’"
    },
    {
      "verse": "30",
      "text": "Then Caleb stood in front of Moses and he told the Israelites to be quiet. He said, ‘We should go into the land and get power over it. We will certainly be able to do it! ’"
    },
    {
      "verse": "31",
      "text": "But the men who had gone into Canaan with him said, ‘These people are stronger than we are. So we cannot go and fight against them. ’"
    },
    {
      "verse": "32",
      "text": "Those men gave to the Israelites a bad report about the land that they had explored. They said, ‘We went through that whole land and we explored it. The land seems to eat the people who live there! All the people that we saw there were very big and strong."
    },
    {
      "verse": "33",
      "text": "We also saw descendants of the Nephilites there. And we felt like very small insects when we looked at them. And we seemed like very small insects to them too. ’ (The descendants of Anak are also descendants of the Nephilites. )"
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "Then all the people started to weep loudly. And they cried all night."
    },
    {
      "verse": "2",
      "text": "All the Israelites spoke bad words against Moses and Aaron. All the people said to them, ‘We would rather have died in Egypt, or even in this desert!"
    },
    {
      "verse": "3",
      "text": "Why has the Lord brought us into this land? Its people will kill us all with swords. They will take our wives and our children for themselves. We think that it would be better for us to return to Egypt. ’"
    },
    {
      "verse": "4",
      "text": "So they said to each other, ‘We should choose a new leader instead of Moses. Then we should return to Egypt. ’"
    },
    {
      "verse": "5",
      "text": "Then Moses and Aaron threw themselves on the ground in front of the whole group of the Israelites."
    },
    {
      "verse": "6",
      "text": "Joshua, the son of Nun, and Caleb, the son of Jephunneh, were two of the men who had explored the land. They were very upset and they tore their clothes."
    },
    {
      "verse": "7",
      "text": "Joshua and Caleb said to all the Israelites, ‘The land that we travelled through to explore is a very good land."
    },
    {
      "verse": "8",
      "text": "If the Lord is happy with us, he will bring us into this land. And he will give it to us. In that land there is plenty of food and drink, enough for everyone."
    },
    {
      "verse": "9",
      "text": "But do not refuse to obey the Lord. Do not be afraid of the people in that land. They are ready for us to fight against them and win! They have no place to hide! The Lord is with us to help us. So do not be afraid of them. ’"
    },
    {
      "verse": "10",
      "text": "Then all the people wanted to throw stones at Joshua and Caleb to kill them. But the glory of the Lord appeared over the Tent of Meeting. All the Israelites could see that."
    },
    {
      "verse": "11",
      "text": "The Lord said to Moses, ‘These people continue to turn away from me. I did great miracles to show them my power. But still they will not trust me."
    },
    {
      "verse": "12",
      "text": "I will send a disease to kill them. They will not get any of the good things that I wanted to give to them. Then I will make you, Moses, the ancestor of a nation greater and more powerful than they are. ’"
    },
    {
      "verse": "13",
      "text": "Moses said to the Lord, ‘Please do not do that! You used your great power to bring these people out of Egypt. If you destroy them, the Egyptians will hear about it."
    },
    {
      "verse": "14",
      "text": "Then they will tell the people who live in this land about it. They know that you, Lord, are among your people. They know that you meet with your people. They know that your cloud stays over them. They know that you lead them as a pillar of cloud during the day and as a pillar of fire during the night."
    },
    {
      "verse": "15",
      "text": "The people in other nations have heard of your power. So now, if you kill all your people together, the people in those nations will say,"
    },
    {
      "verse": "16",
      "text": "“The Lord could not bring those people into the land that he had seriously promised to give to them. So he killed all of them in the desert. ”"
    },
    {
      "verse": "17",
      "text": "But now, I pray that you will show how powerful you are. You yourself have said,"
    },
    {
      "verse": "18",
      "text": "“The Lord does not quickly become angry. His faithful love for his people continues for ever. He forgives people when they turn against him and they do bad things. But if someone is guilty, he surely punishes them. And he punishes their children, their grandchildren and their grandchildren's children. ”"
    },
    {
      "verse": "19",
      "text": "So please forgive the very bad thing that these people have done. Do that because your faithful love is so great. You have forgiven these people since they left Egypt until now. So please be kind and forgive them again now. ’"
    },
    {
      "verse": "20",
      "text": "Then the Lord said, ‘I have forgiven them as you asked me to do."
    },
    {
      "verse": "21",
      "text": "As surely as I live, and all the earth will be full of my glory, I tell you this."
    },
    {
      "verse": "22",
      "text": "All these people have seen my glory. They have seen the miracles that I did in Egypt and in the desert. But they have tested me many times now to see if I would punish them. They still do not obey me."
    },
    {
      "verse": "23",
      "text": "So I tell you, none of them will ever see the land that I promised to give to their ancestors. None of those men who did not trust me will see that place."
    },
    {
      "verse": "24",
      "text": "But my servant Caleb has thought differently, and he has obeyed me completely. So I will bring him into the land that he explored. It will belong to his descendants."
    },
    {
      "verse": "25",
      "text": "The Amalekites and the Canaanites live in the valleys now. So tomorrow you must turn back. You must travel through the desert towards the Red Sea. ’"
    },
    {
      "verse": "26",
      "text": "The Lord said to Moses and Aaron,"
    },
    {
      "verse": "27",
      "text": "‘These evil people have complained against me too many times! I have heard the bad things that the Israelites have said against me."
    },
    {
      "verse": "28",
      "text": "Tell them this: “I, the Lord, have heard your words. I promise you, as surely as I live, I will certainly do to you as you have said."
    },
    {
      "verse": "29",
      "text": "Your dead bodies will fall to the ground in this desert. All the men that Moses counted will die. Those were the men who were 20 years old or older when he counted them. They complained against me and now they will die in this desert."
    },
    {
      "verse": "30",
      "text": "None of them will go into the land that I promised to give to you to live in. The only men who will go in are Caleb, the son of Jephunneh, and Joshua, the son of Nun."
    },
    {
      "verse": "31",
      "text": "You said that the people in Canaan would take your children to be their slaves. But I will bring those children into the land. You did not want that land for yourselves, but now it will belong to your children."
    },
    {
      "verse": "32",
      "text": "But as for you, your dead bodies will fall to the ground in this desert."
    },
    {
      "verse": "33",
      "text": "years. Because you did not trust me, your children will have trouble. That will continue until all your dead bodies are lying in the desert."
    },
    {
      "verse": "34",
      "text": "days. Now you will have trouble for 40 years, because of your sins. Each day becomes one year! You will know that I am not with you, but I am against you."
    },
    {
      "verse": "35",
      "text": "I, the Lord, have spoken! I will certainly do all these things to punish these evil people. That is because they have all joined together to speak against me. In this desert they will die. Yes, that will be the end of them! ” ’"
    },
    {
      "verse": "38",
      "text": "Only two men who had gone to explore the land did not die. They were Joshua, the son of Nun, and Caleb, the son of Jephunneh."
    },
    {
      "verse": "39",
      "text": "When Moses gave God's message to all the Israelites, the people were very sad."
    },
    {
      "verse": "40",
      "text": "But the next morning, they got up early. They went up to the top of the hills near there. They said, ‘We have certainly done a bad thing. But now we are ready! We will go to the place that the Lord has promised to give to us. ’"
    },
    {
      "verse": "41",
      "text": "But Moses said, ‘You are still not obeying the Lord's command. Why is that? It will not happen as you want."
    },
    {
      "verse": "42",
      "text": "Do not go into that land. The Lord is not with you. So your enemies will win against you."
    },
    {
      "verse": "43",
      "text": "The Amalekites and the Canaanites will be there in front of you. They will kill you with their swords. That will happen because you have refused to obey the Lord. So the Lord will not be with you to help you. ’"
    },
    {
      "verse": "44",
      "text": "But the people did not listen to Moses. Moses and the Lord's Covenant Box stayed in the camp. But still the men went up to the top of the hills."
    },
    {
      "verse": "45",
      "text": "Then the Amalekites and the Canaanites who lived in those hills ran down. They attacked the Israelite men and they chased them to Hormah."
    },
    {
      "verse": "36",
      "text": "The men who had given a bad report to the people about the land of Canaan died immediately. Moses had sent them to explore the land, but they had caused all the people to turn against the Lord."
    },
    {
      "verse": "37",
      "text": "So the Lord sent a bad disease to kill those men."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Say to the Israelites, “You will go into the land that I am giving to you."
    },
    {
      "verse": "3",
      "text": "When you are living there, you can sacrifice bulls, male sheep or goats to the Lord. You will burn them on the altar as a burnt offering. You may offer special sacrifices to the Lord when you have promised to do it. Or you may offer sacrifices because you choose to do it. Also, you will give sacrifices during your regular festivals. The smell of these sacrifices as they burn will please the Lord."
    },
    {
      "verse": "4",
      "text": "The person who gives the gift to the Lord must also give a gift of flour. He must mix the flour with oil. It should be 1 kilogram of your best flour. Mix this flour with 1 litre of olive oil."
    },
    {
      "verse": "5",
      "text": "litre of wine for each lamb. You must give that as a drink offering with each burnt offering or sacrifice."
    },
    {
      "verse": "6",
      "text": "If the animal is a male sheep, you must also offer 2 kilograms of flour. Mix this flour with 1. 5 litres of olive oil."
    },
    {
      "verse": "7",
      "text": "Also, you must pour 1. 5 litres of wine on the altar as a drink offering. The smell of the smoke from this sacrifice will please the Lord."
    },
    {
      "verse": "8",
      "text": "A person can give a young bull as a burnt offering. This may be a special sacrifice that he has promised to give to God. Or it may be a friendship offering to the Lord."
    },
    {
      "verse": "9",
      "text": "Also, you must offer 3 kilograms of flour. Mix this flour with 2 litres of olive oil. Do that if the bull is a burnt offering, or a friendship offering. Do the same if you offer this sacrifice because of a promise."
    },
    {
      "verse": "10",
      "text": "Also, you must pour 2 litres of wine on the altar as a drink offering. The smell of this smoke will please the Lord."
    },
    {
      "verse": "11",
      "text": "You must do the same thing for each bull or for each male sheep. And you must do the same thing for each male lamb or for each young goat."
    },
    {
      "verse": "12",
      "text": "You must do that for every animal that you offer as a gift to God."
    },
    {
      "verse": "13",
      "text": "All the Israelites must do that when they burn sacrifices. The smell of them as they burn will please the Lord."
    },
    {
      "verse": "14",
      "text": "A stranger who is living in your land may want to give a gift by fire to the Lord. He must do the same as you do now, and for all future time."
    },
    {
      "verse": "15",
      "text": "These rules will be the same for the Israelites and for all foreign people who live with them. These rules are for now and for all future time. Both you and the foreign person must obey the Lord's rules."
    },
    {
      "verse": "16",
      "text": "There is the same law for you and for the foreign person who is living among you. There is only one set of rules. ” ’"
    },
    {
      "verse": "17",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "18",
      "text": "‘Tell the Israelites this. I am bringing them into the land of Canaan. After they have gone into it, they must obey my rules."
    },
    {
      "verse": "19",
      "text": "When they first eat the food from that land, they must give a special offering to the Lord."
    },
    {
      "verse": "20",
      "text": "You must give a cake as a special offering from the first of your flour. You must do it as you give your special gift from your threshing floor."
    },
    {
      "verse": "21",
      "text": "From the first of your flour, you must give to the Lord a special offering. And your descendants must continue to do that."
    },
    {
      "verse": "22",
      "text": "The people might not obey a rule that the Lord told Moses about. But they might not know that they are not obeying a rule."
    },
    {
      "verse": "23",
      "text": "It might be any rule that the Lord gave to you by Moses."
    },
    {
      "verse": "24",
      "text": "Perhaps somebody does not know that they are not obeying one of my rules. When that happens, they must sacrifice a young bull as a burnt offering. The smell of the smoke from this sacrifice will please the Lord. Also, they must give a grain offering, a drink offering and a male goat as a sin offering."
    },
    {
      "verse": "25",
      "text": "Then the priest will make things right with God for all the Israelites. The Lord will forgive them. That is because their sin was a mistake. They have brought their offering, an offering by fire to the Lord. And they have brought their sin offering to the Lord, for their mistake."
    },
    {
      "verse": "26",
      "text": "God will forgive all the Israelites and the foreign people who live among you. That is because your sin was a mistake. And also you offered the proper sacrifices to me."
    },
    {
      "verse": "27",
      "text": "Also, a person may not know that something is a sin. If he does that thing, he must sacrifice a female goat. The goat must be one year old. It will be a sin offering."
    },
    {
      "verse": "28",
      "text": "The priest will bring the gift to the Lord. That is to make things right. Then the Lord will forgive that person who did the sin. The person did not know that he had done a wrong thing."
    },
    {
      "verse": "29",
      "text": "The same rule is for the Israelites and for all the foreign people who live among them. That is when it was a mistake."
    },
    {
      "verse": "30",
      "text": "But a person might do something that he knows to be wrong. He does it because he wants to do it. That person is as bad as someone who insults the Lord. It does not matter whether he is an Israelite or a foreign person. You must make that person separate from all the people."
    },
    {
      "verse": "31",
      "text": "That person thought that the Lord's command was not important. He has not obeyed God's rules. So you must make that person completely separate from the people. He is a guilty person. ’"
    },
    {
      "verse": "32",
      "text": "When the Israelites were in the desert, a man was picking up sticks on the day of rest."
    },
    {
      "verse": "33",
      "text": "Some people found him while he was picking up the sticks. They took him to Moses and Aaron and to all the people."
    },
    {
      "verse": "34",
      "text": "They were not sure what to do with the man. So they put him by himself in a tent. Men stood at the door of the tent so that he could not leave it."
    },
    {
      "verse": "35",
      "text": "The Lord said to Moses, ‘This man must die. All the people must take him outside the camp. They must throw stones at him to kill him. ’"
    },
    {
      "verse": "36",
      "text": "So the people took the man outside the camp. They threw stones at him until he died. That was what the Lord had told Moses to do."
    },
    {
      "verse": "37",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "38",
      "text": "‘Tell the Israelites that they must put tassels on the corners of their clothes. They must fix the tassels on blue strings. They must do this now and for all future time."
    },
    {
      "verse": "39",
      "text": "You will be able to look at the tassels. They will help you to remember all the Lord's rules. Then you can obey them. Then you will not only do what you yourself want to do. You will not turn away from me."
    },
    {
      "verse": "40",
      "text": "When you see the tassels, you will remember to obey all my rules. You will be holy for your God."
    },
    {
      "verse": "41",
      "text": "I am the Lord your God. I brought you out from Egypt to be your God. I am the Lord your God. ’"
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "Then Korah the son of Izhar, the son of Kohath, the son of Levi, decided to speak against Moses. Eliab's sons, Dathan and Abiram, and Peleth's son, On, who were descendants of Reuben, were with him."
    },
    {
      "verse": "2",
      "text": "leaders of the Israelites, they all turned against Moses. Those were famous men that the people had chosen as their leaders."
    },
    {
      "verse": "3",
      "text": "They all came to Moses and Aaron and they said, ‘All the Israelites are special. The Lord has chosen all of us and he is with us all. So you should not say that you are better than the rest of the Lord's people. ’"
    },
    {
      "verse": "4",
      "text": "When Moses heard that, he threw himself onto the ground."
    },
    {
      "verse": "5",
      "text": "Moses said to Korah and to all the other men, ‘Tomorrow the Lord will show us who is truly special to him. He will show us who really belongs to him. He will make the person that he chooses come near to him."
    },
    {
      "verse": "6",
      "text": "Now do this: Get some pots for yourselves, Korah and your group of friends."
    },
    {
      "verse": "7",
      "text": "Put fire and incense in them, to burn in front of the Lord tomorrow. Then the Lord will choose the man who is holy. You make yourselves too important, you descendants of Levi! ’"
    },
    {
      "verse": "8",
      "text": "Then Moses said to Korah, ‘Listen, you descendants of Levi."
    },
    {
      "verse": "9",
      "text": "The God of Israel has caused you Levites to be separate from all the other Israelites. He has brought you near to himself, to work in the Lord's Tent. He has chosen you to stand in front of all the people to serve them. But it seems that this is not enough for you."
    },
    {
      "verse": "10",
      "text": "He has brought you, Korah, and all the other descendants of Levi near to himself. But it seems that you want to be priests as well."
    },
    {
      "verse": "11",
      "text": "You are not only speaking bad words against Aaron. You and all your group are complaining against the Lord! ’"
    },
    {
      "verse": "12",
      "text": "Then Moses called Dathan and Abiram, the sons of Eliab, to come to him. But they said, ‘No, we will not come."
    },
    {
      "verse": "13",
      "text": "You have brought us out of a country where there is plenty of food and drink, enough for everyone. You have brought us here, where we will die in the desert. But it seems that that is not enough for you. It seems that you want to be our master as well!"
    },
    {
      "verse": "14",
      "text": "You have certainly not brought us into a land where there is plenty of food and drink. You have not given to us fields and vineyards, for us and for our descendants. You cannot deceive all these men. We will not come up to meet with you! ’"
    },
    {
      "verse": "15",
      "text": "Moses was angry. He said to the Lord, ‘Do not accept what these men offer to you. I did not take anything from them, not even one donkey! I did not do a wrong thing to any of them. ’"
    },
    {
      "verse": "16",
      "text": "Moses said to Korah, ‘Tomorrow, you and your men must come to the Tent of Meeting. You must come to stand in front of the Lord. Aaron will be there too."
    },
    {
      "verse": "17",
      "text": "Each of you must take a pot and you must put incense in it. You must put the pots on the altar in front of the Lord. That will be 250 pots. You yourself must do the same thing, as well as Aaron. ’"
    },
    {
      "verse": "18",
      "text": "So each man took a pot. He put incense in it, and fire to burn it. They stood with Moses and Aaron at the door of the Tent of Meeting."
    },
    {
      "verse": "19",
      "text": "Korah brought all his group of people to stand against Moses and Aaron at the door of the Tent of Meeting. Then the glory of the Lord appeared to all the people."
    },
    {
      "verse": "20",
      "text": "The Lord said to Moses and Aaron,"
    },
    {
      "verse": "21",
      "text": "‘Stand away from these men so that I can kill them. ’"
    },
    {
      "verse": "22",
      "text": "But Moses and Aaron threw themselves on the ground. Their faces were touching the ground. They said, ‘You, our God, are the God who gives life to all people. When one man does a bad thing, will you be angry with all the people? Is that right? ’"
    },
    {
      "verse": "23",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "24",
      "text": "‘Tell the people to move away from the tents of Korah, Dathan and Abiram. ’"
    },
    {
      "verse": "25",
      "text": "Moses got up from the ground. He went to Dathan and Abiram. The leaders of the Israelites went with him."
    },
    {
      "verse": "26",
      "text": "Moses said to all the people, ‘Move away from the tents of these wicked men. Do not touch anything that belongs to them. If you do not move away, God may destroy you together with them, because of all their sins. ’"
    },
    {
      "verse": "27",
      "text": "So the people moved away from the tents of Korah, Dathan and Abiram. Dathan and Abiram were standing with their wives, babies and children at the doors of their tents."
    },
    {
      "verse": "28",
      "text": "Then Moses said to the people, ‘Now you will know that the Lord has chosen me to lead you. He has told me to do this. It was not my own idea. This is how you will know."
    },
    {
      "verse": "29",
      "text": "If these men die in a usual way, as all men will die one day, then the Lord did not choose me."
    },
    {
      "verse": "30",
      "text": "But if the Lord causes something new to happen to these men, you will know that they have turned against him. For example, a hole might appear in the ground so that these men fall into it. They might fall down into their own graves while they are still alive. If that happens to them and to all that belongs to them, then you will know that the Lord has punished them. ’"
    },
    {
      "verse": "31",
      "text": "When Moses finished speaking, a hole opened in the ground."
    },
    {
      "verse": "32",
      "text": "Like a big mouth, it ate those men, their families and everything that belonged to them. The earth covered Korah, all his group and everything that belonged to them."
    },
    {
      "verse": "33",
      "text": "They all went down into the deep grave while they were still alive. The ground closed over them and they died, no longer part of God's people."
    },
    {
      "verse": "34",
      "text": "When the other Israelites heard those men shout, they ran away quickly. They were saying, ‘Help! The ground might eat us too! ’"
    },
    {
      "verse": "35",
      "text": "Then the Lord sent fire down. It killed the 250 men who were offering the incense to God."
    },
    {
      "verse": "36",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "37",
      "text": "‘Tell Eleazar, the son of Aaron the priest, that he must take the pots with incense out of the burning fire. That is because those pots are holy. Then you must throw away the coal over all the ground round that place."
    },
    {
      "verse": "38",
      "text": "Those men died because they did a bad thing. But the pots that they were holding are holy, because they were offering the incense to the Lord. So workers must use hammers to make the pots into thin metal. Then cover the altar with the metal. That will be like a sign to warn the Israelites. ’"
    },
    {
      "verse": "39",
      "text": "pots and he used the bronze metal to cover the altar."
    },
    {
      "verse": "40",
      "text": "Then the Israelites would remember not to do what Korah and his group did. Only people from the family of Aaron could burn incense on the Lord's altar. God would punish anyone else, like he punished Korah and his men. The Lord had given this command through Moses."
    },
    {
      "verse": "41",
      "text": "But on the next day, all the Israelites together complained against Moses and Aaron. They said, ‘You have killed the Lord's people! ’"
    },
    {
      "verse": "42",
      "text": "When the people came together to stand against Moses and Aaron, they turned to look at the Tent of Meeting. The Lord's cloud covered the Tent and his glory appeared."
    },
    {
      "verse": "43",
      "text": "Moses and Aaron went to stand at the front of the Tent of Meeting."
    },
    {
      "verse": "44",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "45",
      "text": "‘Get away from the people so that I can destroy them immediately! ’ Moses and Aaron threw themselves down so that their faces touched the ground."
    },
    {
      "verse": "46",
      "text": "Moses said to Aaron, ‘Pick up your pot. Take coals with fire from the altar and put incense with them in the pot. Then take it quickly among all the people. Remove their sin so that God will forgive them. Be quick! The Lord is so angry with the people that he is already punishing them with a bad disease! ’"
    },
    {
      "verse": "47",
      "text": "The bad disease was already killing some of the people. But Aaron did what Moses had told him to do. He took the pot of incense among the people to remove their sin."
    },
    {
      "verse": "48",
      "text": "In that way, he stood between the people who had died and those who were still living. The bad disease stopped killing people."
    },
    {
      "verse": "49",
      "text": "But 14, 700 people died because of the disease, as well as the people who had died with Korah."
    },
    {
      "verse": "50",
      "text": "After the disease stopped, Aaron went back to Moses at the door of the Tent of Meeting."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Tell the Israelites that they must give to you 12 sticks, one for each tribe. Write the name of the leader of each tribe on each stick."
    },
    {
      "verse": "3",
      "text": "Write Aaron's name on the stick from the tribe of Levi."
    },
    {
      "verse": "4",
      "text": "Take the sticks to the Tent of Meeting and put them in front of the Covenant Box."
    },
    {
      "verse": "5",
      "text": "Leaves will start to grow on the stick of the man that I have chosen as priest. In that way I will stop the bad words that the Israelites are always saying against you. ’"
    },
    {
      "verse": "6",
      "text": "sticks."
    },
    {
      "verse": "7",
      "text": "Moses put the sticks in front of the Covenant Box of the Lord in the Tent of Meeting."
    },
    {
      "verse": "8",
      "text": "The next day, Moses went to the Tent of Meeting. He saw that the stick of the tribe of Levi had started to make leaves. That stick had the name of Aaron on it. Flowers and almonds were growing on it!"
    },
    {
      "verse": "9",
      "text": "Moses brought all the sticks out of the Tent of Meeting. He showed them to the leaders and they saw what had happened. Each leader took his own stick."
    },
    {
      "verse": "10",
      "text": "The Lord said to Moses, ‘Put Aaron's stick in front of the Covenant Box again. The people will see it there like a sign. Then they will remember that they must not turn against me. If they continue to complain, they will die. ’"
    },
    {
      "verse": "11",
      "text": "Moses did what the Lord told him."
    },
    {
      "verse": "12",
      "text": "The Israelites said to Moses, ‘We will all die!"
    },
    {
      "verse": "13",
      "text": "Any person who comes near the Lord's special Tent will die. So we will all die! ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "The Lord said to Aaron, ‘You and your sons and your family will be guilty for any wrong thing that happens in my Holy Tent. You and your sons will be guilty for any wrong thing that a priest does."
    },
    {
      "verse": "2",
      "text": "Bring the people of your tribe, the Levites, to the Tent of Meeting."
    },
    {
      "verse": "3",
      "text": "They must take care of the Tent of Meeting on your behalf. You must tell them what they should do. They must not go near anything that is inside God's Holy Place or the altar. If they do, they will die, and you will die too."
    },
    {
      "verse": "4",
      "text": "The Levites must work with you as they take care of the Tent of Meeting. No other people have authority to come near you as you work there."
    },
    {
      "verse": "5",
      "text": "You must take care of God's Holy Place and the altar. Then I will not be angry with the Israelites again."
    },
    {
      "verse": "6",
      "text": "I have chosen your family, the Levites, from among the other Israelite tribes. They are the Lord's gift to you, to help you take care of the Tent of Meeting."
    },
    {
      "verse": "7",
      "text": "But only you, Aaron, and your sons will serve me as priests. You will work at the altar and in the Holy Place behind the curtain. I have chosen you to serve me as my priests. That is my gift to you. Any other person who comes near the Holy Place must die. ’"
    },
    {
      "verse": "8",
      "text": "The Lord said to Aaron, ‘I give you authority over the things that people offer to me. As priests, part of the gifts that people bring will belong to you and your sons. This rule will always be true for you and your descendants."
    },
    {
      "verse": "9",
      "text": "I am giving to you the parts that do not burn on the altar. A part of all these gifts will belong to you: grain offerings, sin offerings and guilt offerings. These are holy gifts and they belong to you and to your sons."
    },
    {
      "verse": "10",
      "text": "All the men in your family may eat these gifts. Remember that they are holy gifts."
    },
    {
      "verse": "11",
      "text": "Also, you will receive part of the special gifts that the Israelites lift up in front of me. I have given it to you and to your sons and daughters, for all time. Every person who lives in your house may eat it. But they must be clean at the time."
    },
    {
      "verse": "12",
      "text": "I will give to you the best olive oil, the best wine and the best grain. The people give to the Lord the first part of these that they get."
    },
    {
      "verse": "13",
      "text": "I also give to you the best parts of the food that people bring to the Lord. Any clean person who lives in your house may eat them."
    },
    {
      "verse": "14",
      "text": "Everything in Israel that should belong to me is now yours."
    },
    {
      "verse": "15",
      "text": "I give to you every firstborn animal and male child that people offer to the Lord. But you must pay the price for every firstborn son and for every firstborn male animal that is not clean."
    },
    {
      "verse": "16",
      "text": "When they are one month old, you must buy them from me for five shekels of silver each. The shekel must have the same weight as the shekel that the Levites use in God's Holy Tent. There are 20 gerahs in one shekel."
    },
    {
      "verse": "17",
      "text": "You must not pay for the firstborn of a cow, a sheep or a goat. Those animals are holy. Splash the blood from those animals on the altar and burn the fat from them. The smell will make the Lord happy."
    },
    {
      "verse": "18",
      "text": "And the meat of those animals belongs to you. In the same way, the meat of the ribs and the right back leg of the special gifts that you lift up to me also belong to you."
    },
    {
      "verse": "19",
      "text": "I have given all the gifts that the Israelites offer to the Lord to you, your sons and your daughters. That is a rule for all time. That is the Lord's special promise to you and to your descendants for all time. ’"
    },
    {
      "verse": "20",
      "text": "Then the Lord said to Aaron, ‘You priests and your descendants will have no land, like the other tribes do. You will not share in the things that they receive. I myself am the gift that you receive."
    },
    {
      "verse": "21",
      "text": "The Israelites give to me one tenth of everything that they receive. I will give it to the Levites because they serve me in the Tent of Meeting."
    },
    {
      "verse": "22",
      "text": "The other Israelites must not come near the Tent of Meeting again. If they do come near it, they will be guilty and then they will die."
    },
    {
      "verse": "23",
      "text": "Only the Levites must do the work in the Tent of Meeting. And if they do anything wrong there, they will be guilty. That will be a rule for you and for all your descendants. The Levites will not receive any land like the other Israelites do."
    },
    {
      "verse": "24",
      "text": "That is because I have given to the Levites the tithes that the Israelites offer to the Lord. I have told them, “You will not receive any land, like the other Israelites do. ” I have given the tithes to them instead. ’"
    },
    {
      "verse": "25",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "26",
      "text": "‘You must say to the Levites, “You will receive from the Israelites the tithe that I have given to you from them. I have not given any land to you. I have given the tithes to you instead. When you receive those tithes, you must offer one tenth of it to the Lord. That will be a tithe of the tithe."
    },
    {
      "verse": "27",
      "text": "This gift will be the same as when a farmer is giving grain or wine to me. It will be special."
    },
    {
      "verse": "28",
      "text": "So you will give something to the Lord from the tithes that you receive from the Israelites. You must give that part to Aaron the priest."
    },
    {
      "verse": "29",
      "text": "From all the gifts that the people give to you, you must make separate every offering that the Lord should have. The best part of each gift is the part that you must make separate for the Lord. ”"
    },
    {
      "verse": "30",
      "text": "You must say to the Levites, “After you have made the best part of the gift separate for the priests, the other part will belong to the Levites. That will be the grain and the wine that you receive for your food."
    },
    {
      "verse": "31",
      "text": "That is what you receive because you take care of the Tent of Meeting. You and your family may eat it anywhere that you choose."
    },
    {
      "verse": "32",
      "text": "You will not be guilty when you eat it. That is because you have offered the best part of it to God. But you must do that in the right way. The gifts that you receive from the Israelites are holy. If you do not do the right things with them, you will die. ” ’"
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "The Lord said to Moses and Aaron,"
    },
    {
      "verse": "2",
      "text": "‘This is another rule in the Lord's law that I am telling to you: Tell the Israelites that they must bring to you a young red cow. It must not have anything wrong with it. And nobody must have put a yoke on it."
    },
    {
      "verse": "3",
      "text": "They must take the cow outside the camp. They must kill it and then give it to Eleazar the priest."
    },
    {
      "verse": "4",
      "text": "Eleazar must take some of the blood from the cow. He must splash it seven times in front of the Tent of Meeting."
    },
    {
      "verse": "5",
      "text": "Then they must burn the whole cow while Eleazar is watching. They must burn its body with the skin, meat, blood and everything that is inside its body."
    },
    {
      "verse": "6",
      "text": "The priest must take some wood, some plants and some red wool. He must throw them on the fire."
    },
    {
      "verse": "7",
      "text": "Then he must wash his clothes and he must wash his body with water. After that, he can come into the camp, but he will not be clean until the evening."
    },
    {
      "verse": "8",
      "text": "And the man who burns the animal must also wash his clothes in water. And he must wash his body in water. He will not be clean until the evening."
    },
    {
      "verse": "9",
      "text": "Then a man who is clean must pick up all the ashes of the cow. And he must put them outside the camp in a clean place. Keep them safe there for all the Israelites. You must mix them with water to make special water. It will be water for someone who is not clean to make them holy again. It is water to remove sin."
    },
    {
      "verse": "10",
      "text": "The man who picks up the ashes must also wash his clothes. He will not be clean until evening. This rule is for the Israelites and for all the people who are living with them."
    },
    {
      "verse": "11",
      "text": "Any person who touches a dead body will not be clean for seven days."
    },
    {
      "verse": "12",
      "text": "He must use the water to wash himself on the third day and on the seventh day. Then he will be clean. If he does not wash himself on the third day and on the seventh day, he will not be clean."
    },
    {
      "verse": "13",
      "text": "A person might touch the body of a dead person. If he does not make himself clean, he has made the Lord's Tent of Meeting unclean. You must make that person separate from the Israelites. Because they did not splash the special water on him, he will not be clean. He will continue to be unclean."
    },
    {
      "verse": "14",
      "text": "This is the rule when a person dies in a tent. Any person who is in the tent will not be clean for seven days."
    },
    {
      "verse": "15",
      "text": "Any pot in the tent that does not have a lid will not be clean."
    },
    {
      "verse": "16",
      "text": "Also, a person might have killed someone with a sword out in the country. Or someone may have died because he was old or ill. Anyone who touches a dead body in the country will become unclean for seven days. Also if they touch a human bone, or a grave, that person will be unclean for seven days."
    },
    {
      "verse": "17",
      "text": "Then for the person who is not clean, you must take some of the ashes of the young red cow. That is the cow to make people clean. You must put these ashes into a pot and you must mix them with water from a river."
    },
    {
      "verse": "18",
      "text": "Then a person who is clean must take hyssop. He must put it into the water. Then he must use it to splash the water on the tent and on everything that is in it. He must also splash the water on all the people who have been there. And he must splash it on the person who touched the bone or the dead body or the grave."
    },
    {
      "verse": "19",
      "text": "And the clean person must splash the water on the unclean person on the third day too. And he must do it on the seventh day. On the seventh day he will make the person clean again. Then the person who had not been clean must wash his clothes. And he must wash himself in water. In the evening, that person will become clean."
    },
    {
      "verse": "20",
      "text": "The person who is not clean might not wash himself and his clothes. If he does not do it, you must make that person separate from the people. That is because he has made the Lord's Holy Place become unclean. Because the priest did not splash special water on him he will not be clean."
    },
    {
      "verse": "21",
      "text": "This rule is for now and for ever. The man who splashes the special water must also wash his clothes. Any person who touches the special water will not be clean until evening."
    },
    {
      "verse": "22",
      "text": "If an unclean person touches anything, that thing also becomes unclean. If anyone touches the unclean person, he also becomes unclean until evening. ’"
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "In the first month, the Israelites came to the Zin desert. They put up their tents at Kadesh. Miriam died there and the people buried her."
    },
    {
      "verse": "2",
      "text": "The people did not have any water to drink. They complained to Moses and Aaron."
    },
    {
      "verse": "3",
      "text": "They said to Moses, ‘We would rather be dead! When the Lord killed our brothers, he should have killed us too."
    },
    {
      "verse": "4",
      "text": "We are the Lord's people. Have you brought us and our animals here to die?"
    },
    {
      "verse": "5",
      "text": "You should not have brought us to this very bad place. When we were in Egypt, we had grain, figs, grapes and pomegranates. There is no food like that here! And there is no water to drink! ’"
    },
    {
      "verse": "6",
      "text": "Moses and Aaron went away from the people to the door of the Tent of Meeting. They threw themselves down with their faces towards the ground. The glory of the Lord appeared to them."
    },
    {
      "verse": "7",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "8",
      "text": "‘Get the stick. Take your brother Aaron with you and go to the whole group of the Israelites. Then speak to that rock that you can all see. Water will pour out from it. Then the people and their animals can drink it. ’"
    },
    {
      "verse": "9",
      "text": "So Moses did what the Lord had told him. He took the stick from its place in the Lord's Tent of Meeting."
    },
    {
      "verse": "10",
      "text": "Then Moses and Aaron brought all the people to meet in front of the rock. Moses said to them, ‘Listen now, you people who refuse to obey God. It seems that we must bring water out of this rock for you! ’"
    },
    {
      "verse": "11",
      "text": "Moses lifted up his arm. He hit the rock twice with his stick. Water poured out from the rock. The people and their animals drank the water."
    },
    {
      "verse": "12",
      "text": "The Lord said to Moses and Aaron, ‘You did not trust me enough to show the Israelites that I am holy. So you will not lead them into the land that I have promised to give to them. ’"
    },
    {
      "verse": "13",
      "text": "The place where this happened was called ‘Meribah’, because the Israelites quarrelled with the Lord there. But he showed them there that he was their holy God."
    },
    {
      "verse": "14",
      "text": "From Kadesh, Moses sent men to the king of Edom with this message: ‘We are Israelites, your relatives. We should be friendly to each other. You know about all the troubles that have happened to us."
    },
    {
      "verse": "15",
      "text": "Our ancestors went to Egypt. We lived there for many years. The people in Egypt were cruel to us."
    },
    {
      "verse": "16",
      "text": "But when we asked the Lord to help us, he heard us. He sent an angel and he brought us out from Egypt. Now we are here at Kadesh, which is a town at the border of your land."
    },
    {
      "verse": "17",
      "text": "Please let us travel through your land. We will not go through any fields or through any vineyards. We will not even drink water from your wells. We will go along the main road. We will not leave that road on either side until we have gone through all your land. ’"
    },
    {
      "verse": "18",
      "text": "The king of Edom said, ‘You must not travel through my country. If you do, we will bring our army to attack you. ’"
    },
    {
      "verse": "19",
      "text": "The Israelites replied, ‘We will stay on the main road. If our animals drink your water, we will pay for it. We only want to travel through your country. We do not want anything else. ’"
    },
    {
      "verse": "20",
      "text": "The king of Edom said, ‘No, you must not travel through our country. ’ He sent many strong soldiers to attack the Israelites."
    },
    {
      "verse": "21",
      "text": "In that way, the Edomites stopped the Israelites from travelling through Edom. So the Israelites turned away from there."
    },
    {
      "verse": "22",
      "text": "All the Israelites went from Kadesh to Hor mountain."
    },
    {
      "verse": "23",
      "text": "When they were there, at the border of Edom's land, the Lord spoke to Moses and Aaron."
    },
    {
      "verse": "24",
      "text": "He said, ‘Aaron will soon die. He will not go in to the land that I am giving to the Israelites. That is because you both refused to obey me at Meribah."
    },
    {
      "verse": "25",
      "text": "Moses, you must take Aaron and his son Eleazar to climb up Hor mountain."
    },
    {
      "verse": "26",
      "text": "Take the priest's clothes from Aaron and put them on Eleazar. Aaron will die there. ’"
    },
    {
      "verse": "27",
      "text": "Moses did what the Lord told him to do. Moses, Aaron and Eleazar climbed up Hor mountain, while the Israelites watched."
    },
    {
      "verse": "28",
      "text": "Moses took the priest's clothes from Aaron and he put them on Eleazar. Then Aaron died there, at the top of the mountain. Moses and Eleazar walked back down the mountain."
    },
    {
      "verse": "29",
      "text": "days because Aaron died."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "The king of Arad city lived in the Negev desert. That was in the south part of Canaan. People told him that the Israelites were coming on the road to Atharim. So he attacked the Israelites and he caught some of them."
    },
    {
      "verse": "2",
      "text": "The Israelites made this promise to the Lord: ‘If you put these people under our power, we will destroy their towns for you. ’"
    },
    {
      "verse": "3",
      "text": "The Lord accepted the Israelites' promise. He put the Canaanites under their power. The Israelites destroyed them and all their towns. After that, the place was called Hormah."
    },
    {
      "verse": "4",
      "text": "The Israelites left Hor mountain. They travelled round the edge of Edom to the Red Sea. As they travelled, the people were upset."
    },
    {
      "verse": "5",
      "text": "They complained to God and to Moses, ‘You should not have brought us from Egypt to die here in the desert. There is nothing to eat. There is no water to drink. We do not like this bad food, manna. ’"
    },
    {
      "verse": "6",
      "text": "Then the Lord sent snakes among the people. They bit the people and many of the Israelites died."
    },
    {
      "verse": "7",
      "text": "So the people came to Moses and they said, ‘We did a bad thing when we spoke against the Lord and against you. Please pray to the Lord on our behalf. Ask him to remove the snakes from us. ’ So Moses prayed for the people."
    },
    {
      "verse": "8",
      "text": "The Lord said to Moses, ‘Make a model of a snake and put it up high on a pole. When a snake bites anyone, they must look at the bronze snake. Then they will not die. ’"
    },
    {
      "verse": "9",
      "text": "Moses made a bronze snake and he put it on a pole. When a snake bit anyone and they looked at the bronze snake, they did not die."
    },
    {
      "verse": "10",
      "text": "The Israelites put up their tents at Oboth."
    },
    {
      "verse": "11",
      "text": "Then they travelled from Oboth, and they put up their tents at Iye-Abarim, in the desert. That place is on the east border of the country called Moab."
    },
    {
      "verse": "12",
      "text": "Then they put up their tents in Zered valley."
    },
    {
      "verse": "13",
      "text": "Then they left there and they put up their tents on the north side of the River Arnon. The River Arnon is the border between the Moabites and the Amorites."
    },
    {
      "verse": "14",
      "text": "You can read about this in the Book of the Lord's Wars. It talks about Waheb in Suphah and about the valleys of the River Arnon."
    },
    {
      "verse": "15",
      "text": "It also speaks about the sides of the valleys on the border of Moab that lead to the town of Ar."
    },
    {
      "verse": "16",
      "text": "From there, the Israelites continued to travel until they arrived at Beer. That is the well where the Lord had said to Moses, ‘Bring the people together. Then I will give water to them. ’ ‘Sing to this well. Ask it to give water to us."
    },
    {
      "verse": "17",
      "text": "The Israelites sang this song at that well:‘Sing to this well. Ask it to give water to us."
    },
    {
      "verse": "18",
      "text": "This was the well that our rulers dug. Our leaders dug it with their sceptres and their ruler's sticks. ’After that, the Israelites went from the desert to Mattanah. Our leaders dug it with their sceptres and their ruler's sticks. ’"
    },
    {
      "verse": "19",
      "text": "Then they went from Mattanah to Nahaliel. They went from Nahaliel to Bamoth."
    },
    {
      "verse": "20",
      "text": "They went from Bamoth to the valley in the region of Moab. They put up their tents near the top of Pisgah mountain that is high above the desert."
    },
    {
      "verse": "21",
      "text": "The Israelites sent men with a message to Sihon, the king of the Amorites."
    },
    {
      "verse": "22",
      "text": "They said, ‘Please let us travel through your country. We will not go through any fields or through any vineyards. We will not even drink water from your wells. We will go along the main road. We will not leave that road on either side until we have gone through all your land. ’"
    },
    {
      "verse": "23",
      "text": "But Sihon would not let the Israelites travel through his land. Sihon and his army marched to Jahaz, in the desert. They attacked the Israelites there. ‘Come to Heshbon and build it up again. Build the city of Sihon again."
    },
    {
      "verse": "24",
      "text": "The Israelites fought against the army of Sihon and they won. They got power over the land from the River Arnon to the River Jabbok. But the border of the Ammonites' land had strong towns, so they could not go beyond them."
    },
    {
      "verse": "25",
      "text": "They got power over all the cities of the Amorites. Those cities included Heshbon and the towns round it."
    },
    {
      "verse": "26",
      "text": "Heshbon was the city of Sihon, the king of the Amorites. He had fought against the king of Moab. He took from the king of Moab the land as far as the River Arnon."
    },
    {
      "verse": "27",
      "text": "So the people who write songs wrote this:‘Come to Heshbon and build it up again. Build the city of Sihon again."
    },
    {
      "verse": "28",
      "text": "An army that was like a fire went out from Heshbon. It was like a flame that went out from Sihon's city. It destroyed Ar in Moab, and everything on the hills near the River Arnon. It was like a flame that went out from Sihon's city. It destroyed Ar in Moab, and everything on the hills near the River Arnon."
    },
    {
      "verse": "29",
      "text": "It will be very bad for you, people of Moab. Sihon has killed you people who worship the god Chemosh. Your god has let the king of the Amorites put you in prison. Sihon has killed you people who worship the god Chemosh. Your god has let the king of the Amorites put you in prison."
    },
    {
      "verse": "30",
      "text": "But now, we have won against them! We have destroyed Heshbon, and as far as Dibon. We have killed them from Nophah to Medeba. ’ We have destroyed Heshbon, and as far as Dibon. We have killed them from Nophah to Medeba. ’"
    },
    {
      "verse": "31",
      "text": "So the Israelites stayed in the land of the Amorites."
    },
    {
      "verse": "32",
      "text": "Moses sent men to find the best way to attack Jazer. Then the Israelites attacked Jazer and the towns round it. They caused the Amorites who lived there to run away."
    },
    {
      "verse": "33",
      "text": "After that, the Israelites travelled towards Bashan. Og, the king of Bashan, marched out with his army to fight against them at Edrei."
    },
    {
      "verse": "34",
      "text": "The Lord said to Moses, ‘Do not be afraid of Og. I will put him under your power, as well as his army and his land. Attack him in the same way that you attacked Sihon, the king of the Amorites who ruled in Heshbon. ’"
    },
    {
      "verse": "35",
      "text": "So they killed Og and his sons and all his army. Nobody was left alive. Their land became the Israelites' land."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "The Israelites travelled to Moab. They lived in tents at the side of the Jordan River. Jericho city was on the other side of the river."
    },
    {
      "verse": "2",
      "text": "The king of Moab at that time was Balak, the son of Zippor. He had seen what the Israelites did to the Amorites."
    },
    {
      "verse": "3",
      "text": "The people in Moab were afraid because there were so many Israelites. All the people in Moab became very afraid of the Israelites."
    },
    {
      "verse": "4",
      "text": "So the Moabites said to the leaders of the Midianites, ‘This large group of people will destroy everything round us. They will be like a bull that eats all the grass in a field! ’So Balak, the king of Moab,"
    },
    {
      "verse": "5",
      "text": "sent men to get Balaam, the son of Beor. Balaam was living near the Euphrates river at Pethor. Balak told the men to say to Balaam, ‘A large group of people has come here from Egypt. They cover all the ground, everywhere. They have put up their tents near our land."
    },
    {
      "verse": "6",
      "text": "They are more powerful than I am. Come here and put a curse on them. If you do that, maybe I will win against them. Then I can chase them away from our land. I know that you have the authority to bless people or to curse them. ’"
    },
    {
      "verse": "7",
      "text": "The leaders of Moab and Midian went to find Balaam. They took the money to pay for Balaam's work. When they found him, they told him what Balak had said."
    },
    {
      "verse": "8",
      "text": "Balaam said to them, ‘Stay here tonight. I will talk to the Lord. Tomorrow, I will tell you his answer. ’ So the Moabite officers stayed with Balaam."
    },
    {
      "verse": "9",
      "text": "Then God came to Balaam and he asked, ‘Who are these men who are staying with you? ’"
    },
    {
      "verse": "10",
      "text": "Balaam said to God, ‘Zippor's son Balak, the king of Moab, has sent a message to me."
    },
    {
      "verse": "11",
      "text": "He said, “A big group of people has come from Egypt and they cover all the ground. So please come and curse them for me. Then perhaps I will be able to fight them and send them away. ” ’"
    },
    {
      "verse": "12",
      "text": "God said to Balaam, ‘Do not agree to go with them. You must not curse those people. They are special people. I have blessed them. ’"
    },
    {
      "verse": "13",
      "text": "The next day, Balaam said to the officers from Moab, ‘Go back to Moab. The Lord told me that I should not go with you. ’"
    },
    {
      "verse": "14",
      "text": "So the officers went back to Moab. They told King Balak that Balaam would not come with them."
    },
    {
      "verse": "15",
      "text": "Then Balak sent other officers to speak to Balaam. These officers were even more important than the first group, and there were more of them."
    },
    {
      "verse": "16",
      "text": "They said to Balaam, ‘King Balak says, “Do not let anything stop you from coming to me."
    },
    {
      "verse": "17",
      "text": "I will certainly make you rich and famous. I will do for you anything that you want. So please come and curse these people for me. ” ’"
    },
    {
      "verse": "18",
      "text": "Balaam said to them, ‘No, I will only do what the Lord tells me. I can do no more than that, and no less. Even if Balak gives me his house, all his gold and all his silver, I will only do what the Lord says."
    },
    {
      "verse": "19",
      "text": "Stay here tonight, as the other men did. I will talk to the Lord and see if he has anything more to tell me. ’"
    },
    {
      "verse": "20",
      "text": "That night, God said to Balaam, ‘These men have asked you to go with them, so go with them. But only do what I tell you. ’"
    },
    {
      "verse": "21",
      "text": "In the morning, Balaam prepared his donkey to travel. He went with the officers to Moab."
    },
    {
      "verse": "22",
      "text": "God was angry because Balaam went with the men. The angel of the Lord stood on the road to stop Balaam. Balaam was riding on his donkey and his two servants were with him."
    },
    {
      "verse": "23",
      "text": "The angel of the Lord was holding a sword. When the donkey saw the angel, it tried to leave the road and go into a field. Balaam hit the donkey to make it go back to the road."
    },
    {
      "verse": "24",
      "text": "Then the angel of the Lord stood on the road between two vineyards. The path was narrow there, with a wall on each side."
    },
    {
      "verse": "25",
      "text": "When the donkey saw the angel of the Lord, it pushed against the wall. Balaam's foot became fixed between the donkey and the wall. So Balaam hit the donkey again."
    },
    {
      "verse": "26",
      "text": "Then the angel of the Lord moved on. He stood in a very narrow place where there was no space to turn round."
    },
    {
      "verse": "27",
      "text": "When the donkey saw the angel of the Lord it lay down on the ground. Balaam was still sitting on the donkey and he became very angry. He hit the donkey with his stick."
    },
    {
      "verse": "28",
      "text": "Then the Lord caused the donkey to speak. It said, ‘What have I done to hurt you? Why have you hit me three times like that? ’"
    },
    {
      "verse": "29",
      "text": "Balaam said to the donkey, ‘You have made me look silly. If I had a sword in my hand now, I would kill you. ’"
    },
    {
      "verse": "30",
      "text": "The donkey said to Balaam, ‘I am your own donkey that you ride every day. Do I usually do things like this to you? ’ Balaam said, ‘No. ’"
    },
    {
      "verse": "31",
      "text": "Then the Lord let Balaam see the angel of the Lord. He could see that the angel stood there with a sword in his hand. Balaam lay down with his face down towards the ground."
    },
    {
      "verse": "32",
      "text": "The angel of the Lord said to him, ‘You should not have hit your donkey like that! I have come here to stop you because you refuse to obey me."
    },
    {
      "verse": "33",
      "text": "Three times the donkey saw me and turned back. If it had not done that, I would have killed you. But I would not have killed your donkey. ’"
    },
    {
      "verse": "34",
      "text": "Then Balaam said to the angel of the Lord, ‘I have done a wrong thing. I did not realize that you were standing in the road to stop me. If you do not want me to continue, I will return to my home. ’"
    },
    {
      "verse": "35",
      "text": "But the angel of the Lord said to Balaam, ‘Go with the men. But you must say only the words that I will tell you. ’ So Balaam went with Balak's officers."
    },
    {
      "verse": "36",
      "text": "Balak heard the news that Balaam was coming. He went out to meet Balaam at the border of Moab's land. The town was beside the river Arnon."
    },
    {
      "verse": "37",
      "text": "Balak said to Balaam, ‘You should have come the first time that I sent men to get you. Why did you not come? Did you think that I could not pay you with enough good things? ’"
    },
    {
      "verse": "38",
      "text": "Balaam said to Balak, ‘Anyway, I have come to you now! But I cannot choose to say anything. I can only say the words that God tells me to speak. ’"
    },
    {
      "verse": "39",
      "text": "Balaam went with Balak to Kiriath-Huzoth."
    },
    {
      "verse": "40",
      "text": "When they arrived there, Balak killed bulls and sheep as a sacrifice. He sent some of the meat to Balaam and the officers who were with him."
    },
    {
      "verse": "41",
      "text": "The next day, Balak took Balaam to Bamoth-Baal. From there, Balaam could see some of the big group of the Israelites."
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "Balaam said to King Balak, ‘Build seven altars here for me. Prepare seven bulls and seven male sheep. ’"
    },
    {
      "verse": "2",
      "text": "Balak did this. Balaam and Balak then offered a bull and a male sheep on each altar as a sacrifice."
    },
    {
      "verse": "3",
      "text": "Then Balaam said to Balak, ‘Stand next to your burnt offering. I will go to see if the Lord will come to meet me. If he shows something to me, I will tell you about it. ’ Then Balaam went to the top of a hill where there were no trees."
    },
    {
      "verse": "4",
      "text": "Balaam said to the Lord, ‘I made seven altars. On each altar, I have offered a bull and a male sheep. ’"
    },
    {
      "verse": "5",
      "text": "God told Balaam the message that he should speak to Balak."
    },
    {
      "verse": "6",
      "text": "So Balaam returned to Balak. Balak was still standing by his burnt offering with all the Moabite officers."
    },
    {
      "verse": "7",
      "text": "Then Balaam started to speak his message from God. He said, ‘Balak, the king of Moab, has brought me from Syria. He brought me from the mountains in the east. He said “Come and curse Jacob's descendants for me. Say bad things against the Israelites! ”"
    },
    {
      "verse": "8",
      "text": "But I cannot curse these people, because God has not cursed them. I cannot speak against people that the Lord does not speak against."
    },
    {
      "verse": "9",
      "text": "When I stand on the rocks, I can see the Israelites. I can watch them from the hills. They are people who are separate from other nations."
    },
    {
      "verse": "10",
      "text": "Nobody can count Jacob's descendants. They are as many as the dust on the ground! It would be too difficult to count even a quarter of the Israelites. I would like to die in peace like those righteous people! ’"
    },
    {
      "verse": "11",
      "text": "Balak said to Balaam, ‘You have not done what I wanted you to do! I brought you here to curse my enemies. But you have blessed them! ’"
    },
    {
      "verse": "12",
      "text": "Balaam answered, ‘I can only speak the message that the Lord has told me. ’"
    },
    {
      "verse": "13",
      "text": "Then Balak said to Balaam, ‘Please come with me to another place where you can see the Israelites. You will not see all of them from there. Then curse those people for me. ’"
    },
    {
      "verse": "14",
      "text": "Balak took Balaam to the field of Zophim. It was at the top of Pisgah mountain. Balak built seven altars there. He offered a bull and a male sheep on each altar as sacrifices."
    },
    {
      "verse": "15",
      "text": "Balaam said to Balak, ‘Stay here beside your burnt offering. I will go to meet with the Lord. ’"
    },
    {
      "verse": "16",
      "text": "The Lord met Balaam and told him the message that he should speak to Balak. He told Balaam to go and tell it to Balak."
    },
    {
      "verse": "17",
      "text": "So Balaam went back to Balak. Balak and the Moabite officers were standing beside the burnt offerings. Balak asked Balaam, ‘What did the Lord say? ’"
    },
    {
      "verse": "18",
      "text": "Balaam spoke his message from God. He said, ‘Balak, son of Zippor, be ready! Listen carefully to me."
    },
    {
      "verse": "19",
      "text": "God is not human. He does not tell lies. He does not change his thoughts. If he promises to do something, it happens."
    },
    {
      "verse": "20",
      "text": "He told me that I must bless the Israelites. He has blessed them, so I must do it too."
    },
    {
      "verse": "21",
      "text": "I do not see that any trouble will come to the Israelites. The Lord their God is with them, to help them. They call him their king."
    },
    {
      "verse": "22",
      "text": "He brought them out of Egypt. He fights on their behalf, as strong as a wild bull."
    },
    {
      "verse": "23",
      "text": "Nobody can curse the Israelites. No magic has any power to hurt them. Now people will say about them, “See the great things that God has done for them! ”"
    },
    {
      "verse": "24",
      "text": "The Israelites are like a strong lion. It eats the animals that it has killed. It does not rest until it has eaten as much as it wants. It also drinks their blood. ’"
    },
    {
      "verse": "25",
      "text": "Balak said to Balaam, ‘You do not have to curse the Israelites, but please do not bless them! ’"
    },
    {
      "verse": "26",
      "text": "Balaam replied, ‘I already told you, “I must do everything that the Lord tells me. ” ’"
    },
    {
      "verse": "27",
      "text": "Balak said to Balaam, ‘Let me take you to a different place. Perhaps God will let you curse the Israelites from that place. ’"
    },
    {
      "verse": "28",
      "text": "Balak took Balaam to the top of Peor mountain. From there they could look over the desert."
    },
    {
      "verse": "29",
      "text": "Balaam said, ‘Build seven altars here. Prepare seven bulls and seven male sheep as sacrifices. ’"
    },
    {
      "verse": "30",
      "text": "Balak did that. He offered a bull and a male sheep on each altar as sacrifices."
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "Balaam realized that the Lord wanted to bless the Israelites. So he did not use magic again to find out what the Lord wanted him to do. Instead, he looked towards the desert."
    },
    {
      "verse": "2",
      "text": "When he looked, he saw the Israelite people. They had put up their tents in groups for each tribe. Then the Spirit of God came on him."
    },
    {
      "verse": "3",
      "text": "As a result, Balaam said, ‘This is God's message that he has given to Balaam, the son of Beor. It is the words of a man who understands what God is saying."
    },
    {
      "verse": "4",
      "text": "It is the message of a man who hears God's words. I am a man who sees a vision that God Almighty has shown to him. I lie down on the ground, but my eyes are open! I see this:"
    },
    {
      "verse": "5",
      "text": "The tents where the Israelites live are beautiful!"
    },
    {
      "verse": "6",
      "text": "They are like green gardens in a valley beside a river. They are like tall trees that the Lord has put there. They are like cedar trees that grow beside water."
    },
    {
      "verse": "7",
      "text": "God will give them plenty of rain. Their descendants will always have plenty of water. Their king will be more powerful than Agag. Their kingdom will be great."
    },
    {
      "verse": "8",
      "text": "God brought them out of Egypt. God fights for them like a wild bull. He will destroy the nations who are their enemies. He will break their enemies' bones into pieces. He will shoot his arrows at them."
    },
    {
      "verse": "9",
      "text": "The Israelites are like a lion. When it is asleep, nobody is brave enough to wake it. God blesses those who bless you, Israel. And those who curse you are truly cursed. ’"
    },
    {
      "verse": "10",
      "text": "When Balaam said that, Balak became very angry with him. He hit his hands together and he said to Balaam, ‘I asked you to come here and to curse my enemies, the Israelites. But you have blessed them three times!"
    },
    {
      "verse": "11",
      "text": "So go home now. I said that I would pay you very well. But the Lord has stopped me from giving you anything. ’"
    },
    {
      "verse": "12",
      "text": "Balaam said to Balak, ‘I already said this to the men that you sent to bring me."
    },
    {
      "verse": "13",
      "text": "I told them, “I can only speak the message that the Lord tells me. I cannot do good things or bad things just because I want to do them. Even if Balak gives his palace full of silver and gold to me, I cannot do anything different. I have to obey the Lord's command. ”"
    },
    {
      "verse": "14",
      "text": "So I will now return to my own people. But listen! Before I go, I will tell you what these Israelites will do to your people in the future. ’"
    },
    {
      "verse": "15",
      "text": "Then Balaam spoke this message from God. He said, ‘This is the message of Balaam, the son of Beor. It is the message of a man who sees clearly."
    },
    {
      "verse": "16",
      "text": "It is the message of a man who hears God's words. The Most High God has shown me things that only he knows. I am a man who sees a vision that God Almighty has shown to him. I lie down on the ground, but my eyes are open! I see this:"
    },
    {
      "verse": "17",
      "text": "I see a king who will come from among the Israelites. He will not come now, but at a future time. He will appear as king, like a bright star. He will knock down the leaders of Moab. He will destroy the descendants of Sheth."
    },
    {
      "verse": "18",
      "text": "He will win against his enemies in Edom and Seir. The Israelites will become stronger."
    },
    {
      "verse": "19",
      "text": "A descendant of Jacob will become their ruler. He will destroy all the people who are still alive in the city. ’"
    },
    {
      "verse": "20",
      "text": "Then, in his vision, Balaam saw the Amalekites. He said, ‘Amalek was the most powerful of all the nations. God will destroy it now and for ever. ’"
    },
    {
      "verse": "21",
      "text": "Then Balaam saw the Kenites. He spoke this message: ‘The place where you live seems strong and safe, high up among the rocks."
    },
    {
      "verse": "22",
      "text": "But Assyria's army will attack you. They will take you away as prisoners. ’"
    },
    {
      "verse": "23",
      "text": "Then Balaam spoke this message: ‘It is very bad for you! Nobody can live when God does these things!"
    },
    {
      "verse": "24",
      "text": "Ships will come from the coast of Cyprus island. Their soldiers will attack Assyria and Eber. Then God will destroy them too. ’"
    },
    {
      "verse": "25",
      "text": "After he spoke those messages, Balaam returned to his home. King Balak also left that place."
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "The Israelites were staying in Shittim. The men began to have sex with the women from Moab."
    },
    {
      "verse": "2",
      "text": "The women from Moab took Israelite men to watch them as they offered sacrifices to the gods of Moab. The Israelite men joined with the Moabite women to eat at their feasts. They also worshipped the gods of Moab."
    },
    {
      "verse": "3",
      "text": "The Israelites joined the Moabite women to worship their god, Baal of Peor. So the Lord became very angry with them."
    },
    {
      "verse": "4",
      "text": "The Lord said to Moses, ‘Take hold of all the leaders of these people. Hang them up during the day so that they die and people see them. Do what I tell you, so that I will no longer be angry against the Israelites. ’"
    },
    {
      "verse": "5",
      "text": "Moses told the officers of the Israelites, ‘Each of you, kill the men who have worshipped the god, Baal of Peor. ’"
    },
    {
      "verse": "6",
      "text": "Moses and all the people were at the door of the Tent of Meeting. They were weeping. While they were there, an Israelite man brought a Midianite woman into his tent. Moses and all the people could see them."
    },
    {
      "verse": "7",
      "text": "Phinehas, the son of Eleazar and grandson of Aaron the priest, saw what happened. So he stood up among all the people and he took a spear in his hand."
    },
    {
      "verse": "8",
      "text": "He went into the man's tent. He pushed the spear through the body of the man and the Midianite woman. When he did that, the bad disease that was killing the Israelites stopped."
    },
    {
      "verse": "9",
      "text": "But 24, 000 people had already died as a result of the disease."
    },
    {
      "verse": "10",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "11",
      "text": "‘I am no longer angry with the Israelites. That is because of what Phinehas, the son of Eleazar and grandson of Aaron the priest, did. He did not want the people to worship any god except me. Because of him, I did not kill all the Israelites."
    },
    {
      "verse": "12",
      "text": "So you must tell him that I have promised that my peace will be with him."
    },
    {
      "verse": "13",
      "text": "That promise will be for him and for his descendants after him. They will always be priests. That is because he did not want the people to worship any god except me. He has removed the sin of the Israelites so that I could forgive them. ’"
    },
    {
      "verse": "14",
      "text": "The name of the man that Phinehas killed with the Midianite woman was Zimri. He was the son of Salu. Salu was the leader of a clan from the tribe of Simeon."
    },
    {
      "verse": "15",
      "text": "The name of the Midianite woman was Cozbi. She was the daughter of Zur. Zur was a leader of a Midianite clan."
    },
    {
      "verse": "16",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "17",
      "text": "‘Attack the Midianites and destroy them."
    },
    {
      "verse": "18",
      "text": "They have deceived you and they have become your enemies. They took some of you to worship their god Peor. They used Cozbi to make you do a wrong thing, and she was the daughter of a Midianite leader. Phinehas killed her on the day when the bad disease killed many Israelites at Peor mountain. ’"
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "When the bad disease stopped killing people, the Lord spoke to Moses and to Eleazar, the son of Aaron. These are the names of the Israelites who came out of Egypt:"
    },
    {
      "verse": "2",
      "text": "He said, ‘Count all the Israelites, clan by clan. Count all the men who are 20 years old or older. Count only those men who can fight in the army. ’"
    },
    {
      "verse": "3",
      "text": "So Moses and Eleazar the priest spoke to the Israelites. Their camp was on the flat ground of Moab, beside the Jordan River. Jericho was on the other side of the river. They said,"
    },
    {
      "verse": "4",
      "text": "‘Count all the men who are 20 years old or older. The Lord has told Moses that we must do that. ’These are the names of the Israelites who came out of Egypt:"
    },
    {
      "verse": "5",
      "text": "The tribe of Reuben, Jacob's firstborn son had these clans: Hanoch's family, Pallu's family,"
    },
    {
      "verse": "6",
      "text": "Hezron's family and Carmi's family."
    },
    {
      "verse": "7",
      "text": "There were 43, 730 men in the clans of the tribe of Reuben."
    },
    {
      "verse": "8",
      "text": "Pallu's descendant was Eliab."
    },
    {
      "verse": "9",
      "text": "Eliab's descendants were Nemuel, Dathan and Abiram. Dathan and Abiram were the men who turned against Moses and Aaron. Korah was their leader and they all turned against the Lord."
    },
    {
      "verse": "10",
      "text": "A hole opened in the ground. Korah, Dathan, Abiram and their families fell into the hole and they died. And fire killed 250 other men. So they became a sign to warn the other Israelites."
    },
    {
      "verse": "11",
      "text": "But Korah's clan did not all die at that time."
    },
    {
      "verse": "12",
      "text": "The tribe of Simeon had these clans: Nemuel's family, Jamin's family, Jakin's family,"
    },
    {
      "verse": "13",
      "text": "Zerah's family and Shaul's family."
    },
    {
      "verse": "14",
      "text": "There were 22, 200 men in the clans of the tribe of Simeon."
    },
    {
      "verse": "15",
      "text": "The tribe of Gad had these clans: Zephon's family, Haggi's family, Shuni's family,"
    },
    {
      "verse": "16",
      "text": "Ozni's family, Eri's family,"
    },
    {
      "verse": "17",
      "text": "Arod's family and Areli's family."
    },
    {
      "verse": "18",
      "text": "There were 40, 500 men in the clans of the tribe of Gad."
    },
    {
      "verse": "19",
      "text": "The sons of Judah were Er and Onan, but Er and Onan died in Canaan."
    },
    {
      "verse": "20",
      "text": "The tribe of Judah had these clans: Shelah's family, Perez's family, Zerah's family,"
    },
    {
      "verse": "21",
      "text": "Hezron's family and Hamul's family."
    },
    {
      "verse": "22",
      "text": "There were 76, 500 men in the clans of the tribe of Judah."
    },
    {
      "verse": "23",
      "text": "The tribe of Issachar had these clans: Tola's family, Puah's family,"
    },
    {
      "verse": "24",
      "text": "Jashub's family and Shimron's family."
    },
    {
      "verse": "25",
      "text": "There were 64, 300 men in the clans of the tribe of Issachar."
    },
    {
      "verse": "26",
      "text": "The tribe of Zebulun had these clans: Sered's family, Elon's family and Jahleel's family."
    },
    {
      "verse": "27",
      "text": "There were 60, 500 men in the clans of the tribe of Zebulun."
    },
    {
      "verse": "28",
      "text": "The descendants of Joseph became two tribes, Manasseh and Ephraim."
    },
    {
      "verse": "29",
      "text": "The tribe of Manasseh had these clans: Makir's family and Gilead's family. Makir was Gilead's father."
    },
    {
      "verse": "30",
      "text": "These clans came from Gilead's descendants: Iezer's family, Helek's family,"
    },
    {
      "verse": "31",
      "text": "Asriel's family, Shechem's family,"
    },
    {
      "verse": "32",
      "text": "Shemida's family and Hepher's family."
    },
    {
      "verse": "33",
      "text": "Zelophehad, the son of Hepher, had no sons, but only daughters. The names of Zelophehad's daughters were Mahlah, Noah, Hoglah, Milcah and Tirzah."
    },
    {
      "verse": "34",
      "text": "There were 52, 700 men in the clans of the tribe of Manasseh."
    },
    {
      "verse": "35",
      "text": "The tribe of Ephraim had these clans: Shuthelah's family, Becher's family, and Tahan's family."
    },
    {
      "verse": "36",
      "text": "Eran's family was a clan from the descendants of Shuthelah."
    },
    {
      "verse": "37",
      "text": "There were 32, 500 men in the clans of the tribe of Ephraim. The clans of the tribes of Manasseh and Ephraim were all descendants of Joseph."
    },
    {
      "verse": "38",
      "text": "The tribe of Benjamin had these clans: Bela's family, Ashbel's family, Ahiram's family,"
    },
    {
      "verse": "39",
      "text": "Shupham's family and Hupham's family."
    },
    {
      "verse": "40",
      "text": "Ard's family and Naaman's family were clans from Bela's descendants."
    },
    {
      "verse": "41",
      "text": "There were 45, 600 men in the clans of the tribe of Benjamin."
    },
    {
      "verse": "42",
      "text": "The tribe of Dan had this clan: Shuham's family."
    },
    {
      "verse": "43",
      "text": "There were 64, 400 men in Shuham's clan."
    },
    {
      "verse": "44",
      "text": "The tribe of Asher had these clans: Imnah's family, Ishvi's family and Beriah's family."
    },
    {
      "verse": "45",
      "text": "Heber's family and Malkiel's family were clans from Beriah's descendants."
    },
    {
      "verse": "46",
      "text": "There was also a daughter of Asher who was called Serah."
    },
    {
      "verse": "47",
      "text": "There were 53, 400 men in the clans of the tribe of Asher."
    },
    {
      "verse": "48",
      "text": "The tribe of Naphtali had these clans: Jahzeel's family, Guni's family,"
    },
    {
      "verse": "49",
      "text": "Jezer's family and Shillem's family."
    },
    {
      "verse": "50",
      "text": "There were 45, 400 men in the clans of the tribe of Naphtali."
    },
    {
      "verse": "51",
      "text": "There were 601, 730 men on the list of all the Israelites."
    },
    {
      "verse": "52",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "53",
      "text": "‘I will give part of the land to each tribe. You need to know the number of names that you have on your list for each tribe."
    },
    {
      "verse": "54",
      "text": "The big tribes will receive a big piece of land. The small tribes will receive a smaller piece of land."
    },
    {
      "verse": "55",
      "text": "You must use lots to decide the land that each tribe receive."
    },
    {
      "verse": "56",
      "text": "The larger clans must have more land than the smaller clans. ’"
    },
    {
      "verse": "57",
      "text": "The Levites included these clans: Gershon's family, Kohath's family and Merari's family."
    },
    {
      "verse": "58",
      "text": "It also included these clans: Libni's family, Hebron's family, Mahli's family, Mushi's family and Korah's family. Kohath was the father of Amram."
    },
    {
      "verse": "59",
      "text": "The name of Amram's wife was Jochebed. She was a descendant of Levi, and she was born in Egypt. Amram and Jochebed were the parents of Moses and Aaron, and their sister Miriam."
    },
    {
      "verse": "60",
      "text": "Aaron was the father of Nadab, Abihu, Eleazar and Ithamar."
    },
    {
      "verse": "61",
      "text": "Nadab and Abihu died when they offered strange fire to the Lord."
    },
    {
      "verse": "62",
      "text": "There were 23, 000 male Levites who were more than one month old. Moses did not include them on the list of the other Israelite tribes. They did not receive any land as the other tribes did."
    },
    {
      "verse": "63",
      "text": "Those are the men that Moses and Eleazar the priest counted. They counted them on the flat ground in Moab beside the Jordan River. Jericho was on the other side of the river."
    },
    {
      "verse": "64",
      "text": "None of the men that Moses and Aaron had counted in the Sinai desert were still alive."
    },
    {
      "verse": "65",
      "text": "The Lord had said about those men, ‘They will certainly die in the desert. ’ Among all those men, only Caleb the son of Jephunneh and Joshua the son of Nun were still alive."
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "Then the daughters of Zelophehad, the son of Hepher, came to speak to Moses. Hepher was the son of Gilead, the son of Makir, the son of Manasseh, the son of Joseph. So Zelophehad belonged to the tribe of Manasseh. His daughters were called Mahlah, Noah, Hoglah, Milcah and Tirzah."
    },
    {
      "verse": "2",
      "text": "Moses, Eleazar the priest and all the leaders of the people were standing at the front of the Tent of Meeting. Zelophehad's daughters said to them,"
    },
    {
      "verse": "3",
      "text": "‘Our father died in the desert. But he was not in Korah's group of men who came together to speak against the Lord. He died in the desert because of his own sin, and he did not have any sons."
    },
    {
      "verse": "4",
      "text": "We are his daughters, so please give us some land along with our father's male relatives. Then people will not forget our father's family name. ’"
    },
    {
      "verse": "5",
      "text": "Moses asked the Lord about this."
    },
    {
      "verse": "6",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "7",
      "text": "‘What the daughters of Zelophehad said is right. You must give to them some of the land that their father's family will receive. Give to them the land that their father would have received."
    },
    {
      "verse": "8",
      "text": "Tell the Israelites this: “Sometimes a man only has daughters. When he dies, his daughters must receive what belongs to their family."
    },
    {
      "verse": "9",
      "text": "If he does not have any sons or daughters, you must give his family's land to his brothers."
    },
    {
      "verse": "10",
      "text": "If he does not have any brothers, you must give his land to his father's brothers."
    },
    {
      "verse": "11",
      "text": "Sometimes the man's father may have no brothers. If that happens, you must give his land to another person in his family. This is a rule for all the people. The Lord gave this command to Moses. ” ’"
    },
    {
      "verse": "12",
      "text": "The Lord said to Moses, ‘Go up to the top of the Abiram mountains. From there, look at the land that I am giving to the Israelites."
    },
    {
      "verse": "13",
      "text": "After that, you will die, just as your brother Aaron also died."
    },
    {
      "verse": "14",
      "text": "In the Zin desert, when the people turned against me, you did not obey my command. That happened when you hit the rock to get water at Meribah Kadesh. You did not show the people that I was holy, so now you will not go into the land of Canaan. ’"
    },
    {
      "verse": "15",
      "text": "Moses said to the Lord,"
    },
    {
      "verse": "16",
      "text": "‘You are the Lord, the God of the spirits of all people. Please choose another man to be leader over all the people."
    },
    {
      "verse": "17",
      "text": "He will lead them when they go out to fight, and he will bring them back safely. Then the Lord's people will not be like sheep who have no shepherd. ’"
    },
    {
      "verse": "18",
      "text": "The Lord replied to Moses, ‘Choose Joshua, the son of Nun. My Spirit is in him to help him lead well. Put your hand on him to take your place as leader."
    },
    {
      "verse": "19",
      "text": "He must stand in front of Eleazar the priest and in front of all the Israelites. Let all the people see that he is the new leader that I have chosen."
    },
    {
      "verse": "20",
      "text": "Tell the people that they must obey him, because he now has your authority."
    },
    {
      "verse": "21",
      "text": "Eleazar the priest will use the Urim to find out from me what Joshua should do. Then Joshua can tell the people when to go out to fight, and he can lead them safely back again. He will tell all the Israelite people what they must do. ’"
    },
    {
      "verse": "22",
      "text": "Moses did as the Lord told him. He brought Joshua to stand in front of Eleazar the priest and all the people."
    },
    {
      "verse": "23",
      "text": "He put his hands on Joshua to show that he would be the new leader. Moses gave his authority to Joshua, as the Lord had told him to do."
    }
  ],
  "28": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Tell the Israelites that they must give their gifts to God at the proper time. The smell of the gifts when they burn will make him happy."
    },
    {
      "verse": "3",
      "text": "You must say to them, “This is the offering by fire that you must offer to the Lord: It must be two male lambs that are one year old. They must not have anything wrong with them. That is the burnt offering for every day."
    },
    {
      "verse": "4",
      "text": "You must give one lamb in the morning and one lamb in the evening."
    },
    {
      "verse": "5",
      "text": "With the lambs, you must also offer to God one kilogram of flour that you have mixed with one litre of good olive oil."
    },
    {
      "verse": "6",
      "text": "It is a regular burnt offering that God told you about. He told you about it on Sinai mountain. It is an offering by fire to the Lord. The smell as it burns makes the Lord happy."
    },
    {
      "verse": "7",
      "text": "Then the drink offering with it will be one litre of wine for each lamb. In God's Holy Tent, you must pour out a drink offering of the best wine to the Lord."
    },
    {
      "verse": "8",
      "text": "You must offer the other lamb when it begins to get dark. Offer it with a grain offering and a drink offering like the offerings in the morning. You must give it as an offering by fire. The smell of the smoke from these sacrifices will make the Lord happy."
    },
    {
      "verse": "9",
      "text": "Then on the Sabbath day, you must offer two male lambs that are one year old. They must not have anything wrong with them. And you must offer 2 kilograms of good flour. Mix that with oil as a grain offering. And you must give the proper drink offering with it."
    },
    {
      "verse": "10",
      "text": "This is the burnt offering for every Sabbath. But you must also give the regular burnt offering with its proper drink offering."
    },
    {
      "verse": "11",
      "text": "Also, on the first day of every month, you must give a burnt offering to the Lord. It must be two young bulls, one male sheep and seven male lambs. The lambs must be one year old and they must not have anything wrong with them."
    },
    {
      "verse": "12",
      "text": "With each bull and with the male sheep, you must give a grain offering. Mix together 3 kilograms of the best flour with olive oil. Offer it to me with each bull. Mix together 2 kilograms of the best flour with olive oil. Offer it to me with the male sheep."
    },
    {
      "verse": "13",
      "text": "And with each lamb you must give a grain offering. Mix together 1 kilogram of the best flour with olive oil. Offer it to me with each male lamb as a burnt offering to the Lord. The smell of the smoke from these sacrifices will make the Lord happy."
    },
    {
      "verse": "14",
      "text": "And there must be drink offerings with these sacrifices. The offering must be 2 litres of wine for a bull. It must be 1. 5 litres for the male sheep and 1 litre for a lamb. That is the burnt offering of each month for every month of the year."
    },
    {
      "verse": "15",
      "text": "Also, you must offer one male goat as a sin offering to the Lord. You must offer it with the proper drink offering. But you must still offer the regular burnt offering."
    },
    {
      "verse": "16",
      "text": "On the 14th day of the first month, you must eat the Lord's Passover meal."
    },
    {
      "verse": "17",
      "text": "is the start of a week when you must eat the flat bread. You must not put any yeast in the bread. You must do that for seven days."
    },
    {
      "verse": "18",
      "text": "The first day will be a holy day and all the people must meet together. You must not work at your jobs on that day."
    },
    {
      "verse": "19",
      "text": "And you must give an offering by fire, a burnt offering to the Lord. The offering must be two young bulls, one male sheep and seven male lambs that are one year old. But these animals must not have anything wrong with them."
    },
    {
      "verse": "20",
      "text": "Offer the proper grain offering with each animal. Mix together 3 kilograms of the best flour and olive oil. Offer it to me with each bull. With the male sheep, offer 2 kilograms of the best flour with oil."
    },
    {
      "verse": "21",
      "text": "With each of the seven lambs, you must offer one kilogram of flour that you have mixed with oil."
    },
    {
      "verse": "22",
      "text": "You must also give one male goat as a sin offering. That is to make things right with God for you."
    },
    {
      "verse": "23",
      "text": "But you must still give the regular burnt offering in the morning."
    },
    {
      "verse": "24",
      "text": "You must offer those gifts every day for seven days. They are the food of an offering by fire. The smell of them as they burn will make the Lord happy. But you must still give the regular burnt offering with the proper drink offering."
    },
    {
      "verse": "25",
      "text": "And the seventh day must be a holy day and all the people must meet together. You must not work at your jobs on that day."
    },
    {
      "verse": "26",
      "text": "The day when you offer to the Lord the first part of the harvest must also be a holy day. That is also the day when you give to the Lord an offering of new grain. That is the Festival of Weeks. All the people must meet together. You must not work at your jobs on that day."
    },
    {
      "verse": "27",
      "text": "And you must give a burnt offering to the Lord. The offering must be two young bulls, one male sheep and seven male lambs that are one year old. The smell of the smoke from these sacrifices will make the Lord happy."
    },
    {
      "verse": "28",
      "text": "kilograms of the best flour and olive oil. Offer that with each bull. With the male sheep, offer 2 kilograms of flour with oil."
    },
    {
      "verse": "29",
      "text": "With each of the seven lambs, you must offer one kilogram of flour that you have mixed with oil."
    },
    {
      "verse": "30",
      "text": "You must also offer one male goat to remove your sins."
    },
    {
      "verse": "31",
      "text": "You must still give the regular burnt offering with the proper grain offering. You must give them with the proper drink offerings. The animals must not have anything wrong with them."
    }
  ],
  "29": [
    {
      "verse": "1",
      "text": "On the first day of the seventh month, all the people must come together for a holy meeting. You must not work at your jobs. It is a day for you to make music with your trumpets."
    },
    {
      "verse": "2",
      "text": "And you must offer a burnt offering to the Lord. You must give one young bull and one male sheep. Also offer seven lambs that are one year old. The animals must not have anything wrong with them. The smell of the smoke from these sacrifices will cause the Lord to be happy."
    },
    {
      "verse": "3",
      "text": "Offer to me the proper grain offering with each animal. Mix together 3 kilograms of the best flour with olive oil. Offer it to me with the young bull. Offer 2 kilograms of flour with oil with the male sheep."
    },
    {
      "verse": "4",
      "text": "kilogram of flour with each lamb."
    },
    {
      "verse": "5",
      "text": "Also offer one male goat as a sin offering, so that I will forgive the people's sins."
    },
    {
      "verse": "6",
      "text": "Offer these sacrifices as well as the burnt offering, grain offerings and drink offerings that you give each month and each day. The smell of the smoke from these sacrifices will cause the Lord to be happy."
    },
    {
      "verse": "7",
      "text": "On the tenth day of the seventh month, you must come together for a holy meeting. During that day, you must make yourselves humble. And you must not do any work."
    },
    {
      "verse": "8",
      "text": "You must offer a burnt offering to the Lord. The smell of the smoke will make the Lord happy. Offer one young bull, one male sheep and seven male lambs that are one year old. The animals must not have anything wrong with them."
    },
    {
      "verse": "9",
      "text": "Offer to me the proper grain offering with each animal. Mix together 3 kilograms of the best flour with olive oil. Offer it to me with the young bull. Offer 2 kilograms of flour with oil with the male sheep."
    },
    {
      "verse": "10",
      "text": "kilogram of flour with oil with each lamb."
    },
    {
      "verse": "11",
      "text": "Also offer one male goat as a sin offering. Give these gifts as well as the burnt offering, the grain offerings and the drink offerings that you give each day and each month."
    },
    {
      "verse": "12",
      "text": "On the 15th day of the seventh month, you must come together for a holy meeting. You must not work at your jobs. You must have a feast to the Lord for seven days."
    },
    {
      "verse": "13",
      "text": "Give an offering by fire as a smell to make the Lord happy. Give a burnt offering of 13 young bulls, two male sheep and 14 lambs that are one year old. The animals must not have anything wrong with them."
    },
    {
      "verse": "14",
      "text": "bulls give a grain offering. Mix together 3 kilograms of the best flour with olive oil. Offer it to me with each bull. With each male sheep, offer 2 kilograms of flour with oil."
    },
    {
      "verse": "15",
      "text": "Offer one kilogram of flour that you have mixed with oil with each male lamb."
    },
    {
      "verse": "16",
      "text": "Include one male goat as a sin offering. Sacrifice it with the regular burnt offering with the proper grain offering and the drink offering."
    },
    {
      "verse": "17",
      "text": "On the second day, give 12 young bulls, two male sheep and 14 lambs that are one year old. The animals must not have anything wrong with them."
    },
    {
      "verse": "18",
      "text": "With the bulls, male sheep and lambs, give the proper grain offerings and drink offerings for each animal."
    },
    {
      "verse": "19",
      "text": "Include one male goat as a sin offering. Sacrifice it with the regular burnt offering with the proper grain offering and their drink offerings."
    },
    {
      "verse": "20",
      "text": "On the third day, give 11 bulls, two male sheep and 14 male lambs that are a year old. The animals must not have anything wrong with them."
    },
    {
      "verse": "21",
      "text": "With the bulls, male sheep and lambs, give the proper grain offerings and drink offerings for each animal."
    },
    {
      "verse": "22",
      "text": "Include one male goat as a sin offering. Sacrifice it with the regular burnt offering with the proper grain offering and the drink offering."
    },
    {
      "verse": "23",
      "text": "On the fourth day give ten bulls, two male sheep and 14 male lambs that are a year old. The animals must not have anything wrong with them."
    },
    {
      "verse": "24",
      "text": "With the bulls, male sheep and lambs, give the proper grain offerings and drink offerings for each animal."
    },
    {
      "verse": "25",
      "text": "Include one male goat as a sin offering. Sacrifice it with the regular burnt offering with the proper grain offering and the drink offering."
    },
    {
      "verse": "26",
      "text": "On the fifth day give nine bulls, two male sheep and 14 male lambs that are a year old. The animals must not have anything wrong with them."
    },
    {
      "verse": "27",
      "text": "With the bulls, male sheep and lambs, give the proper grain offerings and drink offerings for each animal."
    },
    {
      "verse": "28",
      "text": "Include one male goat as a sin offering. Sacrifice it with the regular burnt offering with the proper grain offering and the drink offering."
    },
    {
      "verse": "29",
      "text": "On the sixth day give eight bulls, two male sheep and 14 male lambs that are a year old. The animals must not have anything wrong with them."
    },
    {
      "verse": "30",
      "text": "With the bulls, male sheep and lambs, give the proper grain offerings and drink offerings for each animal."
    },
    {
      "verse": "31",
      "text": "Include one male goat as a sin offering. Sacrifice it with the regular burnt offering with the proper grain offering and the drink offering."
    },
    {
      "verse": "32",
      "text": "On the seventh day give seven bulls, two male sheep and 14 male lambs that are a year old. The animals must not have anything wrong with them."
    },
    {
      "verse": "33",
      "text": "With the bulls, male sheep and lambs, give the proper grain offerings and drink offerings for each animal."
    },
    {
      "verse": "34",
      "text": "Include one male goat as a sin offering. Sacrifice it with the regular burnt offering with the proper grain offering and the drink offering."
    },
    {
      "verse": "35",
      "text": "On the eighth day, all the people must come together for a holy meeting. You must not work at your jobs."
    },
    {
      "verse": "36",
      "text": "Give an offering by fire as a smell to make the Lord happy. Give a burnt offering of one bull, one male sheep and seven male lambs that are a year old. The animals must not have anything wrong with them."
    },
    {
      "verse": "37",
      "text": "With the bull, the male sheep and the lambs, give the proper grain offerings and drink offerings for each animal."
    },
    {
      "verse": "38",
      "text": "Include one male goat as a sin offering. Sacrifice it with the regular burnt offering with the proper grain offering and the drink offering."
    },
    {
      "verse": "39",
      "text": "You must offer those gifts to the Lord at the times of the feasts. You must do that even if you have given your usual burnt offering, grain offerings, drink offerings or friendship offerings. And you must do it even if you have given other offerings. You might have given those other offerings because you wanted to give them. Or you might have given them because you had promised to give them. ” ’"
    },
    {
      "verse": "40",
      "text": "Moses told the Israelites everything that the Lord had said to him."
    }
  ],
  "30": [
    {
      "verse": "1",
      "text": "Moses said to the leaders of the Israelite tribes: ‘The Lord commands this:"
    },
    {
      "verse": "2",
      "text": "If a man promises to the Lord that he will do something, he must do everything that he has promised."
    },
    {
      "verse": "3",
      "text": "A young woman who still lives in her father's house might make a promise to the Lord."
    },
    {
      "verse": "4",
      "text": "If her father hears about her promise and he does not say anything, she must do everything that she has promised."
    },
    {
      "verse": "5",
      "text": "But her father may refuse to let her do it. Then she does not have to do what she promised to do. The Lord will understand why she does not do it."
    },
    {
      "verse": "6",
      "text": "But a young woman like that might make a promise to God and then marry a husband. She might have promised something when she had not thought carefully about it."
    },
    {
      "verse": "7",
      "text": "After she marries, if her husband hears about it but he does not stop her, she must do what she promised."
    },
    {
      "verse": "8",
      "text": "But her husband may say that he refuses to let her do it. He must say that on the day when he first hears about it. Then the woman does not have to do what she promised to do. The Lord will forgive her."
    },
    {
      "verse": "9",
      "text": "If a woman no longer has a husband, she must do whatever she has promised to the Lord. Maybe she is a widow, or she has become separate from her husband."
    },
    {
      "verse": "10",
      "text": "A woman who is living with her husband may make a promise to the Lord."
    },
    {
      "verse": "11",
      "text": "If her husband hears about it but he does not say anything, she must do everything that she has promised."
    },
    {
      "verse": "12",
      "text": "But her husband may say clearly that she must not do it. Then she must obey him. The Lord will understand why she does not do it."
    },
    {
      "verse": "13",
      "text": "The husband may let his wife do what she promised to do, or he may refuse."
    },
    {
      "verse": "14",
      "text": "If the husband does not say anything for many days about the promise, the woman must do what she promised."
    },
    {
      "verse": "15",
      "text": "The husband may wait for many days after he hears about his wife's promise. If he then refuses to let her do what she promised, he will be guilty. God will punish him instead of his wife. ’"
    },
    {
      "verse": "16",
      "text": "Those are the rules that the Lord gave to Moses. They say what must happen when husbands, wives or young women who still live at home make a promise to the Lord."
    }
  ],
  "31": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘You must punish the Midianites because they caused the Israelites to worship idols. After you have done that, you will die. ’"
    },
    {
      "verse": "3",
      "text": "Moses said to the people, ‘Choose some men to go and fight against the Midianites. Give them weapons to punish the Midianites as the Lord wants."
    },
    {
      "verse": "4",
      "text": "Choose 1, 000 men from each Israelite tribe to go and fight. ’"
    },
    {
      "verse": "5",
      "text": "They did that. There were 12, 000 men ready with weapons to fight the battle."
    },
    {
      "verse": "6",
      "text": "Moses sent those men out to fight. There were 1, 000 men from each tribe. Phinehas, the son of Eleazar the priest, went with them. Phinehas took with him the special things from God's Holy Tent. He also took the trumpets to make sounds for the battle."
    },
    {
      "verse": "7",
      "text": "They attacked the Midianites as the Lord had told them. They killed all the men."
    },
    {
      "verse": "8",
      "text": "That included the five kings of Midian: Evi, Rekem, Zur, Hur and Reba. They also killed Balaam, the son of Beor, with a sword."
    },
    {
      "verse": "9",
      "text": "Israel's men took hold of the women and children of Midian. They took their animals and everything that was valuable."
    },
    {
      "verse": "10",
      "text": "They burned all their towns and their camps."
    },
    {
      "verse": "11",
      "text": "They took for themselves the people, the animals and everything that was valuable."
    },
    {
      "verse": "12",
      "text": "They took all the prisoners and the things that they had taken to Moses, and to Eleazar the priest. They brought them to the camp of the Israelites. That was on the flat ground in Moab beside the Jordan River. Jericho was on the other side of the river."
    },
    {
      "verse": "13",
      "text": "Moses, Eleazar and the leaders of the Israelites went to meet them outside the camp."
    },
    {
      "verse": "14",
      "text": "Moses was angry with the leaders and the officers of the army who had come back from the battle against the Midianites."
    },
    {
      "verse": "15",
      "text": "Moses said to them, ‘Why have you let all the women live?"
    },
    {
      "verse": "16",
      "text": "You should not have done that. These women caused the Israelites to turn against the Lord. They did what Balaam said to them at Peor. As a result, a bad disease killed many of the Lord's people."
    },
    {
      "verse": "17",
      "text": "Because of that, kill all the boys, and kill every woman who has had sex with a man."
    },
    {
      "verse": "18",
      "text": "But as for the girls who have not had sex with a man, you may keep them for yourselves. ’"
    },
    {
      "verse": "19",
      "text": "Moses said, ‘Any soldier who has killed someone, or who has touched a dead body is unclean. He must stay outside the camp for seven days. On the third day and on the seventh day, you must wash yourselves to become clean. You must do the same thing to your Midianite prisoners."
    },
    {
      "verse": "20",
      "text": "You must also make these things clean: any clothes or anything made from leather, wool or wood. ’"
    },
    {
      "verse": "21",
      "text": "Eleazar the priest said to the soldiers, ‘This is the rule that the Lord told Moses:"
    },
    {
      "verse": "22",
      "text": "You must put all the gold, the silver, the bronze, the iron, and other metals in a fire."
    },
    {
      "verse": "23",
      "text": "Put in the fire anything that the fire will not destroy. The fire will make those things clean. But you must also wash them with water. As for anything that the fire would destroy, wash them with water to make them clean."
    },
    {
      "verse": "24",
      "text": "On the seventh day, you must wash your clothes. After that you will be clean again. Then you can come into the camp. ’"
    },
    {
      "verse": "25",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "26",
      "text": "‘You and Eleazar the priest, and the leaders of the family clans must count all the people and animals that you took in the battle."
    },
    {
      "verse": "27",
      "text": "Give one half of all those things to the soldiers who went to fight the war against the Midianites. Give the other half to the rest of the people."
    },
    {
      "verse": "28",
      "text": "From the half which belongs to the soldiers, keep one part out of every 500. Do that with the Midianite prisoners, the cows, the donkeys and the sheep. Those parts will be for the Lord."
    },
    {
      "verse": "29",
      "text": "Give those to Eleazar the priest. He will offer them to the Lord."
    },
    {
      "verse": "30",
      "text": "From the half that belongs to the people, keep one part out of every 50. Do that with the Midianite prisoners, the cows, the donkeys and the sheep. Those parts will be for the Levites who take care of the Lord's special tent. ’"
    },
    {
      "verse": "31",
      "text": "Moses and Eleazar did as the Lord said."
    },
    {
      "verse": "32",
      "text": "The soldiers had brought from the battle: 675, 000 sheep,"
    },
    {
      "verse": "33",
      "text": "72, 000 cows,"
    },
    {
      "verse": "34",
      "text": "61, 000 donkeys"
    },
    {
      "verse": "35",
      "text": "and 32, 000 young women who had not had sex with a man."
    },
    {
      "verse": "36",
      "text": "The soldiers' half included 337, 500 sheep."
    },
    {
      "verse": "37",
      "text": "sheep for the Lord."
    },
    {
      "verse": "38",
      "text": "The soldiers' half also included 36, 000 cows. So there were 72 cows for the Lord."
    },
    {
      "verse": "39",
      "text": "The soldiers' half also included 30, 500 donkeys. So there were 61 donkeys for the Lord."
    },
    {
      "verse": "40",
      "text": "The soldiers' half also included 16, 000 people. So there were 32 people for the Lord."
    },
    {
      "verse": "41",
      "text": "Moses gave the part that was for the Lord to Eleazar, the priest. He would offer these to the Lord, as the Lord had commanded Moses."
    },
    {
      "verse": "42",
      "text": "Moses made the half for the Israelite people separate from the half that was for the soldiers."
    },
    {
      "verse": "43",
      "text": "The people's half included 337, 500 sheep,"
    },
    {
      "verse": "44",
      "text": "36, 000 cows,"
    },
    {
      "verse": "45",
      "text": "30, 500 donkeys"
    },
    {
      "verse": "46",
      "text": "and 16, 000 people."
    },
    {
      "verse": "47",
      "text": "From the Israelites' half, Moses took one part out of every 50. He gave those to the Levites who took care of the Lord's special tent. That was what the Lord had commanded Moses to do."
    },
    {
      "verse": "48",
      "text": "Then the leaders and the officers of the army went to Moses."
    },
    {
      "verse": "49",
      "text": "They said to him: ‘We have counted the soldiers who went to fight against the Midianites. They have all come back safely."
    },
    {
      "verse": "50",
      "text": "So we have brought a gift to offer to the Lord. We have brought gold rings, ear-rings, necklaces and other gold things that people wear. They are gifts to remove our sins so that the Lord will forgive us. ’"
    },
    {
      "verse": "51",
      "text": "Moses and Eleazar took all the gold things that the soldiers' officers and leaders brought to them."
    },
    {
      "verse": "52",
      "text": "They weighed all the gold that was offered to the Lord. The weight was 16, 750 shekels."
    },
    {
      "verse": "53",
      "text": "The soldiers had also taken gold things from the enemy for themselves."
    },
    {
      "verse": "54",
      "text": "Moses and Eleazar took the gold gifts from the soldiers' officers and leaders into the Tent of Meeting. It would help the Israelites to remember how the Lord had helped them."
    }
  ],
  "32": [
    {
      "verse": "1",
      "text": "The people in the tribes of Reuben and Gad had very many animals. They saw that the land in Jazer and Gilead was good for their animals."
    },
    {
      "verse": "2",
      "text": "They went to speak to Moses, Eleazar and the other leaders of the Israelites."
    },
    {
      "verse": "3",
      "text": "They said, ‘The land at Ataroth, Dibon, Jazer, Nimrah, Heshbon, Elealeh, Sebam, Nebo and Beon"
    },
    {
      "verse": "4",
      "text": "is good for animals. The Lord has given all this land to us Israelites. We have very many animals,"
    },
    {
      "verse": "5",
      "text": "so please let us have this land for our animals. Let us have this land to live on, instead of land on the other side of the Jordan River. ’"
    },
    {
      "verse": "6",
      "text": "Moses said to the men of Reuben and Gad, ‘The other Israelite tribes will go across the river to fight against the people who live there. It is not fair that you should stay here!"
    },
    {
      "verse": "7",
      "text": "If you stay here, the rest of the Israelites may not want to cross the river. Do not stop them going into the land that the Lord has given to them!"
    },
    {
      "verse": "8",
      "text": "Your fathers did the same thing when I sent them from Kadesh-Barnea to look at the land of Canaan."
    },
    {
      "verse": "9",
      "text": "They went to Eshcol valley and they saw the land. But they told the Israelites that it was not a good idea to go into Canaan. So the people did not go into the land that the Lord had given to them."
    },
    {
      "verse": "10",
      "text": "As a result, the Lord was very angry with them."
    },
    {
      "verse": "11",
      "text": "He promised, “None of the men that I brought out from Egypt will go into the land. It is the land that I promised to give to Abraham, Isaac and Jacob. But they have not trusted me completely. So any man who is 20 years old or older will not go into this land."
    },
    {
      "verse": "12",
      "text": "Caleb, the son of Jephunneh, and Joshua the son of Nun are the only men who will go into the land. They are the only men who trusted me completely. ”"
    },
    {
      "verse": "13",
      "text": "At that time, the Lord was angry with all the Israelites. He caused them to travel in the desert for 40 years. After that, all the men who had turned against him were dead. ’"
    },
    {
      "verse": "14",
      "text": "Moses continued to say, ‘Now you are turning against God, as your fathers did. You are as bad as them! You will cause the Lord to be even more angry with the Israelites."
    },
    {
      "verse": "15",
      "text": "If you turn against him, he will leave them here in the desert. If all the Israelite people die, it will be because of you! ’"
    },
    {
      "verse": "16",
      "text": "The men of Reuben and Gad said to Moses, ‘Let us build strong houses here for our women and our children. We will also build places to keep our animals safe."
    },
    {
      "verse": "17",
      "text": "Then we will be ready to join the other tribes and we will lead them to the battle. While we are fighting, our families will be safe here. The people who live in this land will not be able to hurt them."
    },
    {
      "verse": "18",
      "text": "We will not return to our homes here until all the Israelite tribes receive their own part of the land."
    },
    {
      "verse": "19",
      "text": "We will not receive any of the land on the other side of the Jordan River. Our part of the land will be here, on the east side of the river. ’"
    },
    {
      "verse": "20",
      "text": "Moses said to the men, ‘You must really do as you have said. You must take your weapons and go to fight for the Lord."
    },
    {
      "verse": "21",
      "text": "Your men must cross over the Jordan River with the other tribes. You must continue to fight until we have won against all our enemies."
    },
    {
      "verse": "22",
      "text": "When the Lord has power over the whole land, then you can return here. You will have done everything that the Lord wants you to do. You will have helped the whole Israelite nation in the way that you should. The Lord will give to you this land on the east side of the Jordan River."
    },
    {
      "verse": "23",
      "text": "But if you do not do what you have promised, that will be a sin against the Lord. And be sure that God will punish you for your sin."
    },
    {
      "verse": "24",
      "text": "So build towns for your families, and build safe places for your animals. But then do everything that you have promised to do. ’"
    },
    {
      "verse": "25",
      "text": "The men in the tribes of Gad and Reuben said to Moses, ‘Yes sir, we will do what you have said."
    },
    {
      "verse": "26",
      "text": "Our women, children and our animals will stay here in Gilead's towns."
    },
    {
      "verse": "27",
      "text": "But all our men who are able to fight will cross over the river. We will fight on behalf of the Lord, as you have said that we should do. ’"
    },
    {
      "verse": "28",
      "text": "Moses gave this message to Eleazar the priest, to Joshua the son of Nun and to the leaders of the family clans."
    },
    {
      "verse": "29",
      "text": "He said to them, ‘The men in Reuben's tribe and in Gad's tribe must cross over the Jordan River to fight with you on behalf of the Lord. If they do that, you must give to them the land here in Gilead. When you have won power over the whole land, then this land will belong to them."
    },
    {
      "verse": "30",
      "text": "If they refuse to fight together with the other tribes, they will have no land here. They must have part of the land in Canaan, like the other tribes. ’"
    },
    {
      "verse": "31",
      "text": "The men in the tribes of Reuben and Gad said, ‘We will do what the Lord has told us to do."
    },
    {
      "verse": "32",
      "text": "We will take our weapons and we will cross over the Jordan River to fight on behalf of the Lord in Canaan. But then we will live in our land here on this side of the river. ’"
    },
    {
      "verse": "33",
      "text": "So Moses gave to them all the kingdom of Sihon, king of the Amorites and Og, the king of Bashan. He gave to them the land with its towns and all the land round the towns. He gave it to the descendants of Gad and of Reuben and half of the tribe of Joseph's son Manasseh."
    },
    {
      "verse": "34",
      "text": "The men in the tribe of Gad built up again Dibon, Ataroth and Aroer."
    },
    {
      "verse": "35",
      "text": "They also built up again Atroth-Shophan, Jazer, Jogbehah,"
    },
    {
      "verse": "36",
      "text": "Beth-Nimrah and Beth-Haran. They built houses for their families and their animals."
    },
    {
      "verse": "37",
      "text": "The men in the tribe of Reuben built up again Heshbon, Elealeh, Kiriathaim."
    },
    {
      "verse": "38",
      "text": "Nebo, Baal-Meon and Sibmah. They gave new names to the cities that they built up again."
    },
    {
      "verse": "39",
      "text": "The descendants of Makir, the son of Manasseh, attacked Gilead. They sent away the people who lived there."
    },
    {
      "verse": "40",
      "text": "So Moses gave Gilead to the descendants of Makir who was the son of Manasseh. And they lived there."
    },
    {
      "verse": "41",
      "text": "Jair, who was a descendant of Manasseh, attacked some villages. He got power over them and he called them Havvoth-Jair."
    },
    {
      "verse": "42",
      "text": "Nobah attacked Kenath and the villages round it. He called it Nobah, like his own name."
    }
  ],
  "33": [
    {
      "verse": "1",
      "text": "This is the way that the Israelites travelled, after Moses and Aaron led them out of Egypt. They travelled in their family groups."
    },
    {
      "verse": "2",
      "text": "The Lord told Moses that he should write about the journey. These are the places where they made their camps on the way:"
    },
    {
      "verse": "3",
      "text": "They left Rameses in Egypt on the 15th day of the first month. That was the day after the Passover meal. The Israelites marched out bravely, while all the Egyptian people watched them."
    },
    {
      "verse": "4",
      "text": "As they left, the Egyptians were burying all their firstborn sons, because the Lord had killed them. The Lord had shown his power over the Egyptians' gods."
    },
    {
      "verse": "5",
      "text": "They left Rameses and they travelled to Succoth. They made their camp there."
    },
    {
      "verse": "6",
      "text": "They travelled from Succoth to Etham. They made their camp there, on the edge of the desert."
    },
    {
      "verse": "7",
      "text": "They travelled from Etham and they turned round to go to Pi-Hahiroth, which is east of Baal-Zephon. They made their camp near Migdol."
    },
    {
      "verse": "8",
      "text": "They travelled from Pi-Hahiroth. They went through the middle of the sea and then went into the desert. They travelled for three days and then they made their camp at Marah, in Etham desert."
    },
    {
      "verse": "9",
      "text": "They travelled from Marah to Elim. At Elim, there were 12 wells of water and 70 palm trees. They made their camp there."
    },
    {
      "verse": "10",
      "text": "They travelled from Elim and they made their camp by the side of the Red Sea."
    },
    {
      "verse": "11",
      "text": "They travelled from the Red Sea. And they made their camp in the Sin desert."
    },
    {
      "verse": "12",
      "text": "They travelled from the Sin desert and they made their camp at Dophkah."
    },
    {
      "verse": "13",
      "text": "They travelled from Dophkah and they made their camp at Alush."
    },
    {
      "verse": "14",
      "text": "They travelled from Alush and they made their camp at Rephidim. There was no water there for the people to drink."
    },
    {
      "verse": "15",
      "text": "They travelled from Rephidim and they made their camp in the Sinai desert."
    },
    {
      "verse": "16",
      "text": "They travelled from the Sinai desert and they made their camp at Kibroth-Hattaavah."
    },
    {
      "verse": "17",
      "text": "They travelled from Kibroth-Hattaavah and they made their camp at Hazeroth."
    },
    {
      "verse": "18",
      "text": "They travelled from Hazeroth and they made their camp at Rithmah."
    },
    {
      "verse": "19",
      "text": "They travelled from Rithmah and they made their camp at Rimmon-Perez."
    },
    {
      "verse": "20",
      "text": "They travelled from Rimmon-Perez and they made their camp at Libnah."
    },
    {
      "verse": "21",
      "text": "They travelled from Libnah and they made their camp at Rissah."
    },
    {
      "verse": "22",
      "text": "They travelled from Rissah and they made their camp at Kehelathah."
    },
    {
      "verse": "23",
      "text": "They travelled from Kehelathah and they made their camp at Shepher mountain."
    },
    {
      "verse": "24",
      "text": "They travelled from Shepher mountain and they made their camp at Haradah."
    },
    {
      "verse": "25",
      "text": "They travelled from Haradah and they made their camp at Makheloth."
    },
    {
      "verse": "26",
      "text": "They travelled from Makheloth and they made their camp at Tahath."
    },
    {
      "verse": "27",
      "text": "They travelled from Tahath and they made their camp at Terah."
    },
    {
      "verse": "28",
      "text": "They travelled from Terah and they made their camp at Mithcah."
    },
    {
      "verse": "29",
      "text": "They travelled from Mithcah and they made their camp at Hashmonah."
    },
    {
      "verse": "30",
      "text": "They travelled from Hashmonah and they made their camp at Moseroth."
    },
    {
      "verse": "31",
      "text": "They travelled from Moseroth and they made their camp at Bene-Jaakan."
    },
    {
      "verse": "32",
      "text": "They travelled from Bene-Jaakan and they made their camp at Hor-Haggidgad."
    },
    {
      "verse": "33",
      "text": "They travelled from Hor-Haggidgad and they made their camp at Jotbathah."
    },
    {
      "verse": "34",
      "text": "They travelled from Jotbathah and they made their camp at Abronah."
    },
    {
      "verse": "35",
      "text": "They travelled from Abronah and they made their camp at Ezion-Geber."
    },
    {
      "verse": "36",
      "text": "They travelled from Ezion-Geber and they made their camp at Kadesh in the Zin desert."
    },
    {
      "verse": "37",
      "text": "They travelled from Kadesh and they made their camp at Hor mountain. It is on the border of Edom land."
    },
    {
      "verse": "38",
      "text": "The Lord told Aaron that he must go up Hor mountain. Aaron went up and he died there. That was in the 40th year after the Israelites had left Egypt. He died on the first day of the fifth month."
    },
    {
      "verse": "39",
      "text": "years old when he died on Hor mountain."
    },
    {
      "verse": "40",
      "text": "The king of Arad lived in the south part of the land of Canaan. People told him that the Israelites were coming."
    },
    {
      "verse": "41",
      "text": "The Israelites travelled from Hor mountain and they made their camp at Zalmonah."
    },
    {
      "verse": "42",
      "text": "They travelled from Zalmonah and they made their camp at Punon."
    },
    {
      "verse": "43",
      "text": "They travelled from Punon and they made their camp at Oboth."
    },
    {
      "verse": "44",
      "text": "They travelled from Oboth and they made their camp at Iye-Abarim, on the border of Moab land."
    },
    {
      "verse": "45",
      "text": "They travelled from Iye-Abarim and they made their camp at Dibon-Gad."
    },
    {
      "verse": "46",
      "text": "They travelled from Dibon-Gad and they made their camp at Almon-Diblathaim."
    },
    {
      "verse": "47",
      "text": "They travelled from Almon-Diblathaim and they made their camp in the mountains of Abarim, near Nebo."
    },
    {
      "verse": "48",
      "text": "They travelled from the mountains of Abarim and they made their camp in Moab beside the Jordan River. They were on the other side of the river from Jericho city."
    },
    {
      "verse": "49",
      "text": "They made their camp on the flat ground beside the river. Their tents covered the ground from Beth-Jeshimoth to Abel-Shittim."
    },
    {
      "verse": "50",
      "text": "Then the Lord spoke to Moses there in Moab beside the Jordan River. Jericho was on the other side of the river. The Lord said,"
    },
    {
      "verse": "51",
      "text": "‘Say to the Israelites, “You will cross over the Jordan River and you will go into the land of Canaan."
    },
    {
      "verse": "52",
      "text": "Then you must chase out all the people who live in that land. You must destroy all their idols that are made from wood or stone. Also destroy the altars where they worship their false gods."
    },
    {
      "verse": "53",
      "text": "I have given this land to you to live in. So you must win power over the people who live there now."
    },
    {
      "verse": "54",
      "text": "You must use lots to choose how to give part of the land to each family. You must give more land to the larger clans and you must give less land to the smaller clans. The lots will decide which piece of land belongs to each family. Each of your ancestors' tribes will get its own part of the land."
    },
    {
      "verse": "55",
      "text": "If any Canaanites remain in the land, they will bring trouble and pain to the Israelites. So you must chase them all away."
    },
    {
      "verse": "56",
      "text": "If you do not do that, I will punish you in the way that I wanted to punish them. ” ’"
    }
  ],
  "34": [
    {
      "verse": "1",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "2",
      "text": "‘Tell the Israelites this: These are the borders of Canaan, the land that will be yours to live in."
    },
    {
      "verse": "3",
      "text": "The south edge will start at the Zin desert and it will go along the border of Edom land. It will continue to the east, and it will reach the south end of the Salt Sea."
    },
    {
      "verse": "4",
      "text": "It will go south of the place called Scorpion Hill, and it will continue to Zin. Then it will go south of Kadesh-Barnea. It will go to Hazar-Addar and then across to Azmon."
    },
    {
      "verse": "5",
      "text": "There the border will turn and it will go along the Stream of Egypt. It will continue as far as the Mediterranean Sea."
    },
    {
      "verse": "6",
      "text": "The west border of your land will be the coast of the Mediterranean Sea."
    },
    {
      "verse": "7",
      "text": "This will be the north border: From the Mediterranean Sea draw a line to Hor mountain."
    },
    {
      "verse": "8",
      "text": "From Hor mountain the border will go to Lebo-Hamath. Then it will go to Zedad."
    },
    {
      "verse": "9",
      "text": "It will continue to Ziphron and it will finish at Hazar-Enan."
    },
    {
      "verse": "10",
      "text": "This will be the east border: Draw a line from Hazar-Enan to Shepham. That will be your land, with its borders. ’"
    },
    {
      "verse": "11",
      "text": "Then the border will go from Shepham to Riblah, on the east side of Ain. It will go along the east shore of Lake Galilee."
    },
    {
      "verse": "12",
      "text": "Then it will go along the Jordan River and it will finish at the Salt Sea. That will be your land, with its borders. ’"
    },
    {
      "verse": "13",
      "text": "Moses said to the Israelites, ‘That is the land for the Israelites to live in. You must use lots to give part of the land to each tribe. The Lord has told you to give it to the nine and a half tribes."
    },
    {
      "verse": "14",
      "text": "That is because the tribes of Reuben and Gad, and half of Manasseh's tribe have their land already."
    },
    {
      "verse": "15",
      "text": "Their land is on the east side of the Jordan River. It is on the other side of the river from Jericho city. ’"
    },
    {
      "verse": "16",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "17",
      "text": "‘Joshua, the son of Nun, and Eleazar the priest will decide which parts of the land will belong to each family."
    },
    {
      "verse": "18",
      "text": "One leader from each tribe must help them."
    },
    {
      "verse": "19",
      "text": "These are the names of those leaders: Caleb the son of Jephunneh from the tribe of Judah."
    },
    {
      "verse": "20",
      "text": "Shemuel the son of Ammihud from the tribe of Simeon."
    },
    {
      "verse": "21",
      "text": "Elidad the son of Kislon from the tribe of Benjamin."
    },
    {
      "verse": "22",
      "text": "Bukki the son of Jogli from the tribe of Dan."
    },
    {
      "verse": "23",
      "text": "These will be the two leaders from the descendants of Joseph: Hanniel the son of Ephod from the tribe of Manasseh."
    },
    {
      "verse": "24",
      "text": "Kemuel the son of Shiphtan from the tribe of Ephraim."
    },
    {
      "verse": "25",
      "text": "Then there will be Elizaphan the son of Parnach from the tribe of Zebulun."
    },
    {
      "verse": "26",
      "text": "Paltiel the son of Azzan from the tribe of Issachar."
    },
    {
      "verse": "27",
      "text": "Ahihud the son of Shelomi from the tribe of Asher."
    },
    {
      "verse": "28",
      "text": "Pedahel the son of Ammihud from the tribe of Naphtali. ’"
    },
    {
      "verse": "29",
      "text": "Those were the men that the Lord chose to decide about the land for the Israelite families."
    }
  ],
  "35": [
    {
      "verse": "1",
      "text": "The Lord spoke to Moses in Moab, beside the Jordan River. Jericho was on the other side of the river."
    },
    {
      "verse": "2",
      "text": "The Lord said, ‘Tell the people this. They must give some of their land to the Levites. Then the Levites can build towns to live in. They will also have the land round the towns for their animals."
    },
    {
      "verse": "3",
      "text": "The Levites must have towns to live in and land for their cows and all their animals."
    },
    {
      "verse": "4",
      "text": "metres from the walls of each town."
    },
    {
      "verse": "5",
      "text": "You must also measure 1, 000 metres outside the town on each side, the east side, the south side, the west side and the north side. So the town will be in the centre. Those fields of grass will belong to them for each of their towns."
    },
    {
      "verse": "6",
      "text": "Six of the Levites' towns must be safe places. If anyone kills another person, he can run there to be safe. The Levites must also have another 42 towns."
    },
    {
      "verse": "7",
      "text": "In that way, the Levites will have 48 towns and land for their animals."
    },
    {
      "verse": "8",
      "text": "Each of the Israelite tribes must give to the Levites towns from their own land. The larger tribes will give more towns. The smaller tribes will give fewer towns. That is because the larger tribes have received more land than the smaller tribes. ’"
    },
    {
      "verse": "9",
      "text": "The Lord said to Moses,"
    },
    {
      "verse": "10",
      "text": "‘Tell the Israelites to do this when they cross the Jordan River and they go into Canaan."
    },
    {
      "verse": "11",
      "text": "They must choose some towns to be safe places. If anyone kills another person but he did not mean to, he can run there to be safe."
    },
    {
      "verse": "12",
      "text": "Those towns will be places where the killer can be safe from the dead person's relative. The killer will not die before the people in the town have judged him."
    },
    {
      "verse": "13",
      "text": "You must choose six towns to be safe places."
    },
    {
      "verse": "14",
      "text": "Three towns must be in Canaan and three towns must be on the other side of the Jordan River."
    },
    {
      "verse": "15",
      "text": "Those six towns will be safe places for Israelites and for foreign people who live among them. Anyone who has killed another person may run to one of these towns and be safe there. But they will only be safe if they did not mean to kill the other person."
    },
    {
      "verse": "16",
      "text": "Murderers are different. You must kill a murderer. Maybe someone hits another person with a heavy iron tool. If the person dies, the murderer must also die."
    },
    {
      "verse": "17",
      "text": "Someone might hit another person with a big stone. If the person dies, the man is a murderer. He must die."
    },
    {
      "verse": "18",
      "text": "A man might hit a person with a dangerous weapon made from wood. If the person dies, the man is a murderer. He must die."
    },
    {
      "verse": "19",
      "text": "The dead person's relative himself must kill the murderer when he meets him."
    },
    {
      "verse": "20",
      "text": "These are other examples of murder: A man might push another person hard because he hates him. A man might throw something at another person to hurt him."
    },
    {
      "verse": "21",
      "text": "Or a man might hit someone with his hand because he hates him. If the person dies as a result, you must kill the murderer. The dead person's relative must kill the murderer when he meets him."
    },
    {
      "verse": "22",
      "text": "But when a man kills another person, it might be a mistake. For example, he might push someone very hard, or he might throw something at another person. If he did not hate the other person, then it might be a mistake."
    },
    {
      "verse": "23",
      "text": "Or he might drop a heavy stone on someone when he had not seen them. If he did not hate the other person, perhaps he did not mean to hurt him."
    },
    {
      "verse": "24",
      "text": "If that happens, the people must judge who is right. They must choose between the killer and the dead person's relative. They must use those rules to decide if the man is a murderer."
    },
    {
      "verse": "25",
      "text": "If the man is a killer but not a murderer, the people must keep him safe from the dead person's relative. They must send him back to the safe city that he ran to. He will live there safely until the death of the leader of God's priests."
    },
    {
      "verse": "26",
      "text": "But one day, the killer might go outside the border of the safe city that he ran to."
    },
    {
      "verse": "27",
      "text": "If he does that, the dead person's relative might find him outside the safe city. Then, if the dead person's relative kills him, the relative will not be guilty of murder."
    },
    {
      "verse": "28",
      "text": "That is because the killer should have stayed in his safe city until the death of the leader of the priests. But after the leader of the priests dies, the killer may return to his own home."
    },
    {
      "verse": "29",
      "text": "Wherever you and your descendants live, these are the rules that you must obey for all future time."
    },
    {
      "verse": "30",
      "text": "Before you kill a murderer, people must agree that they saw him kill someone. But if only one person saw what happened, that is not enough for you to kill him."
    },
    {
      "verse": "31",
      "text": "You must not accept money to pay for the life of a murderer. If he is guilty of murder, you must kill him."
    },
    {
      "verse": "32",
      "text": "Also, you must not accept money from a killer who has run to a safe city. You must not let him return to his own home until the leader of the priests has died."
    },
    {
      "verse": "33",
      "text": "Murder causes the land where you live to become unclean. You have to make it clean again. You must kill anyone who murders another person. That is the only way to make the land clean again."
    },
    {
      "verse": "34",
      "text": "You must not make the land where you live become unclean. It is the land where I also live. That is because I, the Lord, live among the Israelites. ’"
    }
  ],
  "36": [
    {
      "verse": "1",
      "text": "The leaders of the families in Gilead's clan went to Moses and to the other leaders of the Israelites' clans. (Gilead was the descendant of Makir, who was the descendant of Manasseh. Manasseh was Joseph's son. )"
    },
    {
      "verse": "2",
      "text": "They said, ‘The Lord told you, sir, that you should decide which parts of the land to give to each Israelite family. You used special stones to do that. The Lord told you to give Zelophehad's land to his daughters. Zelophehad was in our clan."
    },
    {
      "verse": "3",
      "text": "But if his daughters marry, the land will then belong to their husbands. If they marry men from other tribes, the land will no longer belong to us, the tribe of Manasseh."
    },
    {
      "verse": "4",
      "text": "Even when the Jubilee year comes, the land will not return to our tribe. It will belong to the tribes of the men that Zelophehad's daughters have married. ’"
    },
    {
      "verse": "5",
      "text": "The Lord gave Moses his answer. So Moses gave this command to the Israelites: ‘What Joseph's descendants are saying is right."
    },
    {
      "verse": "6",
      "text": "This is what the Lord has commanded about the daughters of Zelophehad: Let them marry men that they want to marry. But they must marry men from the clans of their father's tribe."
    },
    {
      "verse": "7",
      "text": "If they do that, each tribe will keep the land that has been given to their ancestors. None of their land will go to another tribe."
    },
    {
      "verse": "8",
      "text": "Any young woman who receives land when her father dies must marry a man from her father's tribe. All the Israelite tribes must obey that rule. Then every Israelite person will keep the land that belonged to his ancestors."
    },
    {
      "verse": "9",
      "text": "No land that belongs to any tribe will become the land of another tribe. So each tribe will keep the land that their ancestors had. ’"
    },
    {
      "verse": "10",
      "text": "The daughters of Zelophehad did what the Lord had commanded Moses."
    },
    {
      "verse": "11",
      "text": "Mahlah, Tirzah, Hoglah, Milcah and Noah, the daughters of Zelophehad, married sons of their father's brothers."
    },
    {
      "verse": "12",
      "text": "They married men from the clans of the descendants of Joseph's son, Manasseh. Because of that, their land remained with the tribe of their father's clan."
    },
    {
      "verse": "13",
      "text": "Those are the rules that the Lord gave to the Israelites at that time. The Lord told Moses what he should say to the people. That happened when they were beside the Jordan River in Moab, on the flat ground on the other side of the river from Jericho city."
    }
  ]
};