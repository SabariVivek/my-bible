module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This book tells about Hilkiah's son, Jeremiah, and the words that he spoke. Jeremiah was a priest. He lived at Anathoth, a town in the land that belonged to the tribe of Benjamin."
    },
    {
      "verse": "2",
      "text": "The Lord first spoke to him when Amon's son Josiah had been king of Judah for 13 years."
    },
    {
      "verse": "3",
      "text": "The Lord also spoke to him while Josiah's son, Jehoiakim, ruled Judah as king. He continued to speak to Jeremiah until Josiah's son Zedekiah had ruled Judah for 11 years. In the fifth month of that year, Judah's enemies took the people of Jerusalem away as their prisoners."
    },
    {
      "verse": "4",
      "text": "The Lord gave me this message:"
    },
    {
      "verse": "5",
      "text": "‘I already knew you before I made you inside your mother's body. I chose you to be special before you were born. I chose you to be my prophet, to speak my message to other nations. ’"
    },
    {
      "verse": "6",
      "text": "I answered, ‘Lord God, I do not know how to speak. I am only a child. ’"
    },
    {
      "verse": "7",
      "text": "The Lord said to me, ‘Do not say, “I am only a child. ” You must go to everyone that I send you to. You must say whatever I tell you to say."
    },
    {
      "verse": "8",
      "text": "Do not be afraid of them. Remember that I will be with you. I will keep you safe. ’"
    },
    {
      "verse": "9",
      "text": "Then the Lord touched my mouth with his hand. He said to me, ‘I am giving you the words that you must speak."
    },
    {
      "verse": "10",
      "text": "Look! I give you authority to tell nations and kingdoms what will happen to them. You will pull some of them out of the ground, like a plant and its roots. You will knock down and destroy some of them. You will bring an end to their power. But you will build up other nations and make them strong. ’"
    },
    {
      "verse": "11",
      "text": "The Lord asked me, ‘What do you see, Jeremiah? ’I replied, ‘I see the branch of an almond tree. ’ I replied, ‘I see the branch of an almond tree. ’"
    },
    {
      "verse": "12",
      "text": "The Lord said, ‘Yes, that is correct. I am watching carefully to make sure that what I say will happen really happens. ’"
    },
    {
      "verse": "13",
      "text": "The Lord asked me again. ‘What do you see? ’I replied, ‘I see in the north a pot with boiling water in it. It will pour its water in this direction. ’The Lord said, I replied, ‘I see in the north a pot with boiling water in it. It will pour its water in this direction. ’"
    },
    {
      "verse": "14",
      "text": "‘Yes, trouble like boiling water will come from the north. It will destroy all the people who live in this land."
    },
    {
      "verse": "15",
      "text": "I will call all the nations that are in the north to come here. Their kings will come and they will sit on their thrones at the city gates of Jerusalem. Their armies will be all around the walls of Jerusalem and the other cities of Judah."
    },
    {
      "verse": "16",
      "text": "I will punish my people for the wicked things that they have done. They have turned away from me. They have offered sacrifices to false gods. They have worshipped idols that they have made with their own hands."
    },
    {
      "verse": "17",
      "text": "You must be ready to move, Jeremiah! Go and say to the people whatever I tell you. Do not be afraid of them. If you are afraid of them now, when you are among them, I will cause you to be very frightened! That is what the Lord says. ’"
    },
    {
      "verse": "18",
      "text": "I, the Lord, promise that I will make you as strong as a city with strong walls around it. You will be as strong as an iron pillar, or a wall that is made of bronze. You will speak a message against the whole nation of Judah. You will speak against its kings, its officers, its priests and all its people."
    },
    {
      "verse": "19",
      "text": "They will attack you. But they will not win against you, because I will be with you. I will keep you safe. That is what the Lord says. ’"
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "The Lord spoke to me again. “This is what the Lord says: I remember how you used to love me when you were young. You loved me as a young wife loves her husband. You followed me through the wilderness, where no crops were growing."
    },
    {
      "verse": "2",
      "text": "He said, ‘Go and tell this to the people in Jerusalem:“This is what the Lord says: I remember how you used to love me when you were young. You loved me as a young wife loves her husband. You followed me through the wilderness, where no crops were growing."
    },
    {
      "verse": "3",
      "text": "At that time, Israel belonged to me as my special people. They were like the first crops that grew on my land. I promised to punish anyone who tried to hurt them. I sent great trouble to those who attacked you. That is what I, the Lord, have said. ” ’ They were like the first crops that grew on my land. I promised to punish anyone who tried to hurt them. I sent great trouble to those who attacked you. That is what I, the Lord, have said. ” ’"
    },
    {
      "verse": "4",
      "text": "Listen to what the Lord says, you descendants of Jacob, all you families in Israel. ‘I had done nothing wrong against your ancestors, but they turned away from me. Instead, they worshipped useless idols. So they themselves became useless."
    },
    {
      "verse": "5",
      "text": "This is the Lord's message to you:‘I had done nothing wrong against your ancestors, but they turned away from me. Instead, they worshipped useless idols. So they themselves became useless."
    },
    {
      "verse": "6",
      "text": "They did not think to themselves, “Where is the Lord? We should ask him to help us. He brought us safely out of Egypt. He led us through the wilderness. It was a place with dry sand and deep holes. There was no water there and it was dangerous. Nobody lives in that desert, and nobody even travels through it. ” “Where is the Lord? We should ask him to help us. He brought us safely out of Egypt. He led us through the wilderness. It was a place with dry sand and deep holes. There was no water there and it was dangerous. Nobody lives in that desert, and nobody even travels through it. ”"
    },
    {
      "verse": "7",
      "text": "But I, the Lord, brought you to a good land. It was a place where fruit grew on trees. You could eat all those good things, as well as the crops that you grew there. You came into the land that I had promised to give to you. But you spoiled it with your sins. You made it a disgusting place. It was a place where fruit grew on trees. You could eat all those good things, as well as the crops that you grew there. You came into the land that I had promised to give to you. But you spoiled it with your sins. You made it a disgusting place."
    },
    {
      "verse": "8",
      "text": "Your priests did not ask, “Where is the Lord? ”The people who taught my laws did not know me. Your leaders turned against me. Your prophets spoke messages from Baal. They worshipped useless idols. ’ The people who taught my laws did not know me. Your leaders turned against me. Your prophets spoke messages from Baal. They worshipped useless idols. ’"
    },
    {
      "verse": "9",
      "text": "So the Lord says this:‘Because of your sins, I will speak against you in court. I will show that you are guilty, as well as your children and your grandchildren. ‘Because of your sins, I will speak against you in court. I will show that you are guilty, as well as your children and your grandchildren."
    },
    {
      "verse": "10",
      "text": "No other nation has done what you have done! Send people across the sea to islands in the west. Or send them to the deserts in the east. Let them find out if any other people have done this terrible thing. Send people across the sea to islands in the west. Or send them to the deserts in the east. Let them find out if any other people have done this terrible thing."
    },
    {
      "verse": "11",
      "text": "Have any other nations turned against their gods? No! They have not done that, even to their false gods! But my people have turned against me, the true God who makes them great. ’ No! They have not done that, even to their false gods! But my people have turned against me, the true God who makes them great. ’"
    },
    {
      "verse": "12",
      "text": "The Lord says, ‘The whole universe should see how terrible this is. Yes, everything should shake with fear! ‘The whole universe should see how terrible this is. Yes, everything should shake with fear!"
    },
    {
      "verse": "13",
      "text": "My people have done two evil things: I give them life, like a spring of fresh water, but they have turned away from me. Instead, they have tried to get water for themselves. They have dug holes in the ground to store it. But those holes cannot hold the water. It quickly runs away. I give them life, like a spring of fresh water, but they have turned away from me. Instead, they have tried to get water for themselves. They have dug holes in the ground to store it. But those holes cannot hold the water. It quickly runs away."
    },
    {
      "verse": "14",
      "text": "Israel's people are surely not slaves. They were not born as slaves. But their enemies have taken them away as prisoners. They were not born as slaves. But their enemies have taken them away as prisoners."
    },
    {
      "verse": "15",
      "text": "Their enemies have attacked them like lions. They have destroyed my people's land. They have destroyed your cities with fire. Nobody lives in them any more. They have destroyed my people's land. They have destroyed your cities with fire. Nobody lives in them any more."
    },
    {
      "verse": "16",
      "text": "Soldiers from Memphis and Tahpanhes have broken your skulls!"
    },
    {
      "verse": "17",
      "text": "You Israelites have caused this to happen. The Lord your God was leading you on the right way. But you decided not to follow him any longer. The Lord your God was leading you on the right way. But you decided not to follow him any longer."
    },
    {
      "verse": "18",
      "text": "So what help will you get from Egypt? If you drink water from the Nile river, will that make you strong? No! And what help will you get from Assyria? If you drink water from the Euphrates river, will that make you strong? No! If you drink water from the Nile river, will that make you strong? No! And what help will you get from Assyria? If you drink water from the Euphrates river, will that make you strong? No!"
    },
    {
      "verse": "19",
      "text": "The wicked things that you have done will punish you. You are guilty because you have turned away from me. You have brought terrible trouble on yourselves, because you have turned against me, the Lord your God. Because you no longer respect me, you will realize that you are in great trouble. ’That is what the Lord God Almighty says. You are guilty because you have turned away from me. You have brought terrible trouble on yourselves, because you have turned against me, the Lord your God. Because you no longer respect me, you will realize that you are in great trouble. ’ That is what the Lord God Almighty says."
    },
    {
      "verse": "20",
      "text": "‘A long time ago, you stopped obeying me. You refused to accept my authority. You said, “I will not serve you! ”Instead, you go up on the hills to worship other gods. You lie down under the green trees, and you live like prostitutes. You refused to accept my authority. You said, “I will not serve you! ” Instead, you go up on the hills to worship other gods. You lie down under the green trees, and you live like prostitutes."
    },
    {
      "verse": "21",
      "text": "I planted you in my land, like the very good seed of a vine. But see how you have changed! You have become like a wild vine. Your grapes are bad and useless. like the very good seed of a vine. But see how you have changed! You have become like a wild vine. Your grapes are bad and useless."
    },
    {
      "verse": "22",
      "text": "You may use strong soap to make yourselves clean. But I still see the dirt of your sins. ’That is what the Almighty Lord says. But I still see the dirt of your sins. ’ That is what the Almighty Lord says."
    },
    {
      "verse": "23",
      "text": "‘You say, “We have not made ourselves unclean. We do not worship the idols of Baal. ”But remember what you have done in the valleys. You hurry to find another idol that you can worship. Like a female camel, you cannot control yourselves. We do not worship the idols of Baal. ” But remember what you have done in the valleys. You hurry to find another idol that you can worship. Like a female camel, you cannot control yourselves."
    },
    {
      "verse": "24",
      "text": "You are like a wild female donkey that lives in the wilderness. She lifts her nose to smell the air. She wants to find a male donkey. Nobody can control her. Male donkeys do not have to chase her. She will come to them to have sex with them. You are like that as you chase after false gods. She lifts her nose to smell the air. She wants to find a male donkey. Nobody can control her. Male donkeys do not have to chase her. She will come to them to have sex with them. You are like that as you chase after false gods."
    },
    {
      "verse": "25",
      "text": "Stop running after them! Your feet will hurt and you will become very thirsty. You say, “Do not try to stop us! We cannot turn back. We love foreign gods and we must serve them! ” Your feet will hurt and you will become very thirsty. You say, “Do not try to stop us! We cannot turn back. We love foreign gods and we must serve them! ”"
    },
    {
      "verse": "26",
      "text": "A robber is ashamed when people catch him. The people of Israel will become ashamed like that. They will all be ashamed of their sins. Their kings, their officers, their priests and their prophets are all guilty. The people of Israel will become ashamed like that. They will all be ashamed of their sins. Their kings, their officers, their priests and their prophets are all guilty."
    },
    {
      "verse": "27",
      "text": "They worship a piece of wood, and they say, “You are my father. ”They say to a stone, “You gave birth to me. ”They have not turned to come to me. Instead, they have turned away from me. But when trouble comes to them, they call out to me to rescue them. and they say, “You are my father. ” They say to a stone, “You gave birth to me. ” They have not turned to come to me. Instead, they have turned away from me. But when trouble comes to them, they call out to me to rescue them."
    },
    {
      "verse": "28",
      "text": "But where are the gods that you made for yourselves? Ask them to save you when trouble comes! You have enough gods to give you help. Yes, people of Judah, your gods are as many as your towns! Ask them to save you when trouble comes! You have enough gods to give you help. Yes, people of Judah, your gods are as many as your towns!"
    },
    {
      "verse": "29",
      "text": "You cannot argue against me. You have all turned against me. ’That is what the Lord says. You have all turned against me. ’ That is what the Lord says."
    },
    {
      "verse": "30",
      "text": "‘When I punished your people, they did not change how they lived. When I sent my prophets to you, you killed them as if you were a hungry lion. ’ they did not change how they lived. When I sent my prophets to you, you killed them as if you were a hungry lion. ’"
    },
    {
      "verse": "31",
      "text": "Listen to the Lord's message, you people who are alive today:‘People of Israel, why do you not trust me? Have I become like a desert for you? Have I become a dark and dangerous land for you to live in? No! But you say, “We are free to go where we like. We do not need to serve you any more. ” ‘People of Israel, why do you not trust me? Have I become like a desert for you? Have I become a dark and dangerous land for you to live in? No! But you say, “We are free to go where we like. We do not need to serve you any more. ”"
    },
    {
      "verse": "32",
      "text": "A young woman does not forget to wear her jewels. When a woman marries, she does not forget to wear her special dress. But for many years, my people have forgotten me. When a woman marries, she does not forget to wear her special dress. But for many years, my people have forgotten me."
    },
    {
      "verse": "33",
      "text": "You are very clever. You can always find someone to love. Even prostitutes could learn something from you! Even prostitutes could learn something from you!"
    },
    {
      "verse": "34",
      "text": "You have been cruel to poor people for no reason. Your clothes have their blood on them! They had not robbed you, but you still killed them. You have done all these bad things, but still you say, Your clothes have their blood on them! They had not robbed you, but you still killed them. You have done all these bad things, but still you say,"
    },
    {
      "verse": "35",
      "text": "“We have not done anything that is wrong. God cannot be angry with us! ”Be careful! I will surely punish you, because you say, “I am not guilty of any sin. ” God cannot be angry with us! ” Be careful! I will surely punish you, because you say, “I am not guilty of any sin. ”"
    },
    {
      "verse": "36",
      "text": "You try to get help from other nations. You run here and there to make new friends. You hoped for help from Assyria, but no help came. And you will get no help from Egypt either. You run here and there to make new friends. You hoped for help from Assyria, but no help came. And you will get no help from Egypt either."
    },
    {
      "verse": "37",
      "text": "You will come away from Egypt with your hands on your heads. You will be ashamed and upset. The Lord has turned away from those nations. You have trusted them to help you, But you will not receive any help from them. ’"
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "The Lord says this:‘If a man sends his wife away, she may leave him and marry another man. Then her first husband may not take her as his wife again. That would be a sin against the land where you live. But you have left me to live with other gods. You have lived like a prostitute, but you still think that you can return to me. ‘If a man sends his wife away, she may leave him and marry another man. Then her first husband may not take her as his wife again. That would be a sin against the land where you live. But you have left me to live with other gods. You have lived like a prostitute, but you still think that you can return to me."
    },
    {
      "verse": "2",
      "text": "Look up at the tops of the hills. You have loved other gods on all of them! You sat by the side of the road, and you waited for a lover to come. Like a robber, you waited to catch menso that you could sleep with them. You have not been faithful to me, but you have looked for other gods, like a prostitute. The wicked things that you have donehave made the land unclean. You have loved other gods on all of them! You sat by the side of the road, and you waited for a lover to come. Like a robber, you waited to catch men so that you could sleep with them. You have not been faithful to me, but you have looked for other gods, like a prostitute. The wicked things that you have done have made the land unclean."
    },
    {
      "verse": "3",
      "text": "That is why I have not sent any rain on your land. Even the spring rains have not come. But you still live like a proud prostitute. You refuse to be ashamed of what you have done. Even the spring rains have not come. But you still live like a proud prostitute. You refuse to be ashamed of what you have done."
    },
    {
      "verse": "4",
      "text": "You still call me your Father. You say, “You have always been my friend. You have loved me all my life. You say, “You have always been my friend. You have loved me all my life."
    },
    {
      "verse": "5",
      "text": "Surely you will not always be angry with me! You cannot continue to be angry for ever. ”Those are the things that you say. But you continue to do as many evil things as you can. ’ You cannot continue to be angry for ever. ” Those are the things that you say. But you continue to do as many evil things as you can. ’"
    },
    {
      "verse": "6",
      "text": "The Lord spoke to me while Josiah was king of Judah. He said, ‘Look at what the Israelites have done. They have not been faithful to me. They have worshipped other gods under every big tree and on every high hill. Israel has been like a wife who is not faithful to her husband."
    },
    {
      "verse": "7",
      "text": "I thought that one day she would come back to me. But she did not return. Israel's sister, Judah, saw what Israel did."
    },
    {
      "verse": "8",
      "text": "Israel was not faithful to me and she served other gods. So I sent her away, like a husband may send his wife away if she is not faithful to him. Judah saw what happened to Israel, but she was not afraid. Like a prostitute, she also went to find other gods that she could serve."
    },
    {
      "verse": "9",
      "text": "She was not ashamed of what she was doing. She worshipped idols made of wood and stone. She made the land unclean because she was not faithful to me."
    },
    {
      "verse": "10",
      "text": "Still Judah has not turned back to me. She wants me to think that she has, but she has not. Like her sister, Israel, she has not been faithful. ’ That is what the Lord says."
    },
    {
      "verse": "11",
      "text": "The Lord said to me, ‘It is true that Israel's people have not been faithful to me. But Judah's people are even more guilty than them."
    },
    {
      "verse": "12",
      "text": "Go now. Shout this message to my people in the north:“You people of Israel have not been faithful to me. But now return to me, ” says the Lord. “I will not always turn away from you. I am kind and I forgive people. I will not be angry with you for ever, ” says the Lord. “You people of Israel have not been faithful to me. But now return to me, ” says the Lord. “I will not always turn away from you. I am kind and I forgive people. I will not be angry with you for ever, ” says the Lord."
    },
    {
      "verse": "13",
      "text": "“But you must agree that you are guilty of sin. You have turned against me, the Lord your God. You have loved to serve many foreign gods. You have worshipped them under every big tree. You have not obeyed my commands. ” ’That is what the Lord says. You have turned against me, the Lord your God. You have loved to serve many foreign gods. You have worshipped them under every big tree. You have not obeyed my commands. ” ’ That is what the Lord says."
    },
    {
      "verse": "14",
      "text": "The Lord says, ‘Return to me, you people who have turned away. Remember that you belong to me. If you turn back to me, I will choose one of you from each town and two from each family. I will bring you safely back to Zion."
    },
    {
      "verse": "15",
      "text": "I will give you leaders who will serve me faithfully. They will take care of you like shepherds. They will be wise and they will lead you well."
    },
    {
      "verse": "16",
      "text": "Then the number of your people who live in your land will increase. You will no longer need to talk about the Lord's Covenant Box. You will not think that it is important any more. You will forget all about it. You will not want to make another one."
    },
    {
      "verse": "17",
      "text": "Instead, you will call the city of Jerusalem “The Lord's throne”. At that time, people from all nations will come to Jerusalem. They will meet there to give honour to the Lord's name. They will no longer do the wicked things that they enjoy."
    },
    {
      "verse": "18",
      "text": "At that time, the nations of Judah and Israel will join together as one kingdom. They will leave their exile in a country in the north. They will come back to this land that I gave to your ancestors to be their home for ever."
    },
    {
      "verse": "19",
      "text": "I thought this:“I want you people of Israel to be my children. That would make me very happy. I want to give you a good land as your home. It is a more beautiful land than any other nation enjoys. ”I thought that you would call me “Father”. I thought that you would always be faithful to me. “I want you people of Israel to be my children. That would make me very happy. I want to give you a good land as your home. It is a more beautiful land than any other nation enjoys. ” I thought that you would call me “Father”. I thought that you would always be faithful to me."
    },
    {
      "verse": "20",
      "text": "But you, Israel, have gone away from me, like a woman who leaves her husband. You have not been faithful to me. ’That is what the Lord says. like a woman who leaves her husband. You have not been faithful to me. ’ That is what the Lord says."
    },
    {
      "verse": "21",
      "text": "‘I can hear a noise on the tops of the hills. Israel's people are weeping. They are calling out for help. Yes, they have turned to bad ways. They have forgotten to serve the Lord their God. Israel's people are weeping. They are calling out for help. Yes, they have turned to bad ways. They have forgotten to serve the Lord their God."
    },
    {
      "verse": "22",
      "text": "Return to me, all of you have turned away. I will help you to be faithful to me. Now you should say, “Yes, we will return to you, because you are the Lord our God. I will help you to be faithful to me. Now you should say, “Yes, we will return to you, because you are the Lord our God."
    },
    {
      "verse": "23",
      "text": "The false gods that we worship on the hills have deceived us. Our wild parties on the mountains have not helped us. Only the Lord our God can really save Israel. Our wild parties on the mountains have not helped us. Only the Lord our God can really save Israel."
    },
    {
      "verse": "24",
      "text": "Since we were a young nation, we have seen all our good things disappear. The useless gods that we worshipped have taken them. They took away the things that our ancestors worked to get. They took away our sheep and our cows. They even took away our sons and our daughters. we have seen all our good things disappear. The useless gods that we worshipped have taken them. They took away the things that our ancestors worked to get. They took away our sheep and our cows. They even took away our sons and our daughters."
    },
    {
      "verse": "25",
      "text": "We are ashamed to agree that this is true. We must accept the shame that we deserve. We and our ancestors have done bad thingsagainst the Lord our God. Since long ago, we have not obeyed him, and even today, we still do not listen to him. ” ’"
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "The Lord says this:‘People of Israel, you should return to me. If you want to do that, you must throw away your idols. Remove those disgusting thingsand do not turn away from me again. ‘People of Israel, you should return to me. If you want to do that, you must throw away your idols. Remove those disgusting things and do not turn away from me again."
    },
    {
      "verse": "2",
      "text": "You must be honest and do what is right. You must do what you promise to do. You can show that your promise is truewhen you add, “As surely as the Lord is alive. ”Then other nations will see that I have blessed you. They will pray that I will bless them too. and they will praise me. ’ You must do what you promise to do. You can show that your promise is true when you add, “As surely as the Lord is alive. ” Then other nations will see that I have blessed you. They will pray that I will bless them too. and they will praise me. ’"
    },
    {
      "verse": "3",
      "text": "The Lord says this to the people of Jerusalem and all Judah:‘Prepare yourselves, like a farmer who ploughs his fields. Do not plant your seeds where weeds are growing. ‘Prepare yourselves, like a farmer who ploughs his fields. Do not plant your seeds where weeds are growing."
    },
    {
      "verse": "4",
      "text": "Give yourselves to me, the Lord, and agree to serve me faithfully. Remove from your lives everything that is not right, so that you obey my covenant. If you do not do that, I will be very angry with you. I will punish you like a hot fire that destroys things. Nobody will be able to stop my anger. People of Judah and Jerusalem, if you continue to do wicked things, I will certainly punish you. ’ and agree to serve me faithfully. Remove from your lives everything that is not right, so that you obey my covenant. If you do not do that, I will be very angry with you. I will punish you like a hot fire that destroys things. Nobody will be able to stop my anger. People of Judah and Jerusalem, if you continue to do wicked things, I will certainly punish you. ’"
    },
    {
      "verse": "5",
      "text": "The Lord said:‘Shout this message to the people in Jerusalem and in all Judah:“Make a loud noise with trumpets in all the land! ”Shout loudly, “Come together! We must all run to the cities with strong walls! ” ‘Shout this message to the people in Jerusalem and in all Judah: “Make a loud noise with trumpets in all the land! ” Shout loudly, “Come together! We must all run to the cities with strong walls! ”"
    },
    {
      "verse": "6",
      "text": "Lift up a flag that shows the way to Zion! Run quickly to a safe place! Do not wait! I will soon bring great trouble from the north. An enemy will destroy your country. Run quickly to a safe place! Do not wait! I will soon bring great trouble from the north. An enemy will destroy your country."
    },
    {
      "verse": "7",
      "text": "Yes, a strong army is coming, like a lion that has left its cave. It has come out to destroy many nations. It will attack your whole land. Your cities will become heaps of stones, and nobody will live in them. like a lion that has left its cave. It has come out to destroy many nations. It will attack your whole land. Your cities will become heaps of stones, and nobody will live in them."
    },
    {
      "verse": "8",
      "text": "So wear rough sackcloth! Weep and cry aloud. Say, “The Lord is still very angry with us. ” ’ Weep and cry aloud. Say, “The Lord is still very angry with us. ” ’"
    },
    {
      "verse": "9",
      "text": "The Lord says:‘When this happens, the king and his officers will be afraid. The priests will shake with fear. The prophets will be unable to speak. ’ ‘When this happens, the king and his officers will be afraid. The priests will shake with fear. The prophets will be unable to speak. ’"
    },
    {
      "verse": "10",
      "text": "Then I said, ‘Lord God, that is terrible! You have deceived the people of Judah and Jerusalem. You told them, “You will live in peace. ” But now an enemy is ready to attack us! ’"
    },
    {
      "verse": "11",
      "text": "The Lord will tell the people at that time, ‘A hot wind will blow from the hills in the desert. It will not be a little wind that blows chaff from wheat. It will be a strong storm that blows away the people that I love."
    },
    {
      "verse": "12",
      "text": "I will send a strong wind of punishment on my people. ’"
    },
    {
      "verse": "13",
      "text": "Look! The enemy army is coming like dark clouds! Their chariots make the noise of a storm. Their horses move faster than eagles in the sky. Terrible trouble has come. We will all die! Their chariots make the noise of a storm. Their horses move faster than eagles in the sky. Terrible trouble has come. We will all die!"
    },
    {
      "verse": "14",
      "text": "People of Jerusalem, remove the evil things from your lives. Then the Lord may save you. Do not continue to have wicked ideas. Then the Lord may save you. Do not continue to have wicked ideas."
    },
    {
      "verse": "15",
      "text": "People are bringing a message from Danand from the hill country of Ephraim. The message says that great trouble is coming. and from the hill country of Ephraim. The message says that great trouble is coming."
    },
    {
      "verse": "16",
      "text": "They say, ‘Warn all the nations that the enemy is coming! ’Shout this message in Jerusalem:‘An army is coming from a country that is far away. They will attack the towns in Judah. Shout this message in Jerusalem: ‘An army is coming from a country that is far away. They will attack the towns in Judah."
    },
    {
      "verse": "17",
      "text": "Their soldiers are all around Jerusalem's walls, like guards around a farmer's field. ’The Lord says, ‘This will happen because the people of Judah have turned against me. like guards around a farmer's field. ’"
    },
    {
      "verse": "18",
      "text": "I will punish you very much, because that is what you deserve. You have lived in a wicked way and you have done evil things. My punishment will give you pain that goes all through you. ’"
    },
    {
      "verse": "19",
      "text": "I am so upset! My body is shaking with pain. My heart beats hard inside me. I cannot keep still. I cannot keep quiet. I have heard the noise of the enemy's trumpetsand the shouts of their soldiers. My body is shaking with pain. My heart beats hard inside me. I cannot keep still. I cannot keep quiet. I have heard the noise of the enemy's trumpets and the shouts of their soldiers."
    },
    {
      "verse": "20",
      "text": "They are winning one battle after another! They are destroying the whole land. Our homes are becoming heaps of stones. They quickly knock down our tents. They are destroying the whole land. Our homes are becoming heaps of stones. They quickly knock down our tents."
    },
    {
      "verse": "21",
      "text": "How long will our enemy continue to attack us? How long will I see their flags and hear their trumpets? How long will I see their flags and hear their trumpets?"
    },
    {
      "verse": "22",
      "text": "The Lord says, ‘My people are fools. They do not know me. They are like children who do not know anything. They understand nothing. They are very clever at doing evil things. But they do not know how to do what is good. ’ ‘My people are fools. They do not know me. They are like children who do not know anything. They understand nothing. They are very clever at doing evil things. But they do not know how to do what is good. ’"
    },
    {
      "verse": "23",
      "text": "I looked at the earth. It had no shape and it was empty. I looked at the sky. Its light had disappeared. It had no shape and it was empty. I looked at the sky. Its light had disappeared."
    },
    {
      "verse": "24",
      "text": "I looked at the mountains. They were shaking. All the hills were moving around. They were shaking. All the hills were moving around."
    },
    {
      "verse": "25",
      "text": "When I looked, I saw no people. All the birds had flown away. All the birds had flown away."
    },
    {
      "verse": "26",
      "text": "The land where crops had grown was now a desert. All the cities had become heaps of stones. The Lord had caused this to happenbecause he was very angry. All the cities had become heaps of stones. The Lord had caused this to happen because he was very angry."
    },
    {
      "verse": "27",
      "text": "The Lord had said, ‘The whole land will become like a desert, but I will not completely destroy it. ‘The whole land will become like a desert, but I will not completely destroy it."
    },
    {
      "verse": "28",
      "text": "So the earth will be sad and weep. The sky will become dark. I have said what I will do. And I will not change my thoughts. I will do as I have decided. ’ The sky will become dark. I have said what I will do. And I will not change my thoughts. I will do as I have decided. ’"
    },
    {
      "verse": "29",
      "text": "When the enemy attacks a town, the people will run away to escape. The enemy soldiers will ride on horses, and they will shoot arrows. When the people hear them, some of them will hide among trees. Some of them will climb up among the rocks. All the towns will become empty. Nobody will live in them. the people will run away to escape. The enemy soldiers will ride on horses, and they will shoot arrows. When the people hear them, some of them will hide among trees. Some of them will climb up among the rocks. All the towns will become empty. Nobody will live in them."
    },
    {
      "verse": "30",
      "text": "Yes, Jerusalem, an enemy has destroyed you! You tried to make friends, like a woman who wears a beautiful dress. You wore your gold and your jewels. You painted around your eyes. But all that has not helped you. The nations that you wanted to be your lovers have turned against you. Now they want to kill you. You tried to make friends, like a woman who wears a beautiful dress. You wore your gold and your jewels. You painted around your eyes. But all that has not helped you. The nations that you wanted to be your lovers have turned against you. Now they want to kill you."
    },
    {
      "verse": "31",
      "text": "I can hear people who are calling out. It sounds like a woman who is giving birth to her first baby. She is calling out with great pain. It is Jerusalem who is crying! She is calling out for help. She says, ‘Help me! I am very weak. These murderers have come to kill me! ’"
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "The Lord said, ‘Run along all the streets of Jerusalem. Look carefully all around you. Look in all the public places of the city. Try to find one person who is honest. Try to find one person who wants to know the truth. If you find one person like that, I will forgive all the people in the city. ‘Run along all the streets of Jerusalem. Look carefully all around you. Look in all the public places of the city. Try to find one person who is honest. Try to find one person who wants to know the truth. If you find one person like that, I will forgive all the people in the city."
    },
    {
      "verse": "2",
      "text": "They make promises and they say, “I will do it, as surely as the Lord lives. ”But what they say is all lies. ’ “I will do it, as surely as the Lord lives. ” But what they say is all lies. ’"
    },
    {
      "verse": "3",
      "text": "Lord, you want people to be honest and true. You have punished your people, but they did not feel any pain. You nearly destroyed them, but they still refuse to change. Their minds have become as hard as rock. They refuse to turn back to you. You have punished your people, but they did not feel any pain. You nearly destroyed them, but they still refuse to change. Their minds have become as hard as rock. They refuse to turn back to you."
    },
    {
      "verse": "4",
      "text": "I thought, ‘These are poor, foolish people. They do not understand what the Lord wants them to do. They do not know his commands. They do not understand what the Lord wants them to do. They do not know his commands."
    },
    {
      "verse": "5",
      "text": "So I will go to speak to the leaders. They will surely understand what the Lord wants. They will know his commands. ’But all of them have turned against the Lord too. They refuse to obey his authority. They will surely understand what the Lord wants. They will know his commands. ’ But all of them have turned against the Lord too. They refuse to obey his authority."
    },
    {
      "verse": "6",
      "text": "So lions will come out of the forest to attack them. Wolves will come from the desert to destroy them. Leopards will wait outside their cities. They will kill anyone who goes outside. That will happen because the people have turned against the Lord. They have done many bad things. Wolves will come from the desert to destroy them. Leopards will wait outside their cities. They will kill anyone who goes outside. That will happen because the people have turned against the Lord. They have done many bad things."
    },
    {
      "verse": "7",
      "text": "The Lord said, ‘Jerusalem, I have to punish you. Your people have turned away from me. They have served gods that are not true gods. I gave them everything that they needed. But they left me, like a wife who leaves her husband. The men hurry to the houses of prostitutes. ‘Jerusalem, I have to punish you. Your people have turned away from me. They have served gods that are not true gods. I gave them everything that they needed. But they left me, like a wife who leaves her husband. The men hurry to the houses of prostitutes."
    },
    {
      "verse": "8",
      "text": "They are like strong male horses. They cannot wait to have sex with another man's wife. ’ They cannot wait to have sex with another man's wife. ’"
    },
    {
      "verse": "9",
      "text": "The Lord says this:‘I must punish them for what they have done. I will pay back this wicked nation for their sins. ’ ‘I must punish them for what they have done. I will pay back this wicked nation for their sins. ’"
    },
    {
      "verse": "10",
      "text": "The Lord says this to Judah's enemies:‘March through the vineyards of Israel and Judah, and destroy the vines. But do not destroy them completely. Pull the branches from the trees. Do this, because these people do not belong to the Lord. ‘March through the vineyards of Israel and Judah, and destroy the vines. But do not destroy them completely. Pull the branches from the trees. Do this, because these people do not belong to the Lord."
    },
    {
      "verse": "11",
      "text": "The people of Israel and Judah have turned against me."
    },
    {
      "verse": "12",
      "text": "They have told lies about the Lord. They have said, “He will not punish us! No trouble will come to us. There will be no war. There will be no famine. They have said, “He will not punish us! No trouble will come to us. There will be no war. There will be no famine."
    },
    {
      "verse": "13",
      "text": "The prophets speak empty words. They do not speak the Lord's messages. The troubles that they talk about should happen to them, not us! ” ’ They do not speak the Lord's messages. The troubles that they talk about should happen to them, not us! ” ’"
    },
    {
      "verse": "14",
      "text": "Because of that, the Lord God Almighty said to me, ‘That is what the people are saying. So I will give you a strong message to speak to them. It will be like fire that comes out of your mouth. And the people will burn like wood in that fire. ’ ‘That is what the people are saying. So I will give you a strong message to speak to them. It will be like fire that comes out of your mouth. And the people will burn like wood in that fire. ’"
    },
    {
      "verse": "15",
      "text": "The Lord says this:‘Listen to me, you people of Israel. I will bring an army to attack you. They will come from a nation that is far away. It is a strong nation that started long ago. You do not know their language. You cannot understand what they say. ‘Listen to me, you people of Israel. I will bring an army to attack you. They will come from a nation that is far away. It is a strong nation that started long ago. You do not know their language. You cannot understand what they say."
    },
    {
      "verse": "16",
      "text": "They are all brave soldiers. They shoot arrows that will kill you. They shoot arrows that will kill you."
    },
    {
      "verse": "17",
      "text": "They will eat all the crops in your fieldsand the food that you have stored. They will take your sons and your daughters for themselves. They will kill your sheep and your cows for food. They will eat all your grapes and your figs. They will attack your strong citieswhere you thought you would be safe. Their soldiers will knock down the walls. ’ and the food that you have stored. They will take your sons and your daughters for themselves. They will kill your sheep and your cows for food. They will eat all your grapes and your figs. They will attack your strong cities where you thought you would be safe. Their soldiers will knock down the walls. ’"
    },
    {
      "verse": "18",
      "text": "But the Lord says this: ‘Even at that time, I will not destroy you completely."
    },
    {
      "verse": "19",
      "text": "So, Jeremiah, the people may ask you, “Why has the Lord our God done this to us? ” Then tell them, “It is because you have turned away from me. You have chosen to serve foreign gods in your own land. So now you will have to serve foreign people and their gods in a land that is not your own land. ”"
    },
    {
      "verse": "20",
      "text": "Tell this message to the descendants of Jacob. Shout it everywhere in Judah. Shout it everywhere in Judah."
    },
    {
      "verse": "21",
      "text": "Tell them, “Hear this message, you foolish and stupid people. You have eyes, but you do not see properly. You have ears, but you do not hear properly. ” ’ you foolish and stupid people. You have eyes, but you do not see properly. You have ears, but you do not hear properly. ” ’"
    },
    {
      "verse": "22",
      "text": "The Lord says, ‘You should respect me and obey me. You should shake with fear when you come to me. I made the sand as an edge for the sea. It is like a wall that the sea cannot cross. The sea's waves may attack the shore, but it cannot go further than that edge. You should shake with fear when you come to me. I made the sand as an edge for the sea. It is like a wall that the sea cannot cross. The sea's waves may attack the shore, but it cannot go further than that edge."
    },
    {
      "verse": "23",
      "text": "But these people do not obey me, as the waves do. They have turned away from me. They have chosen to go their own way. They have turned away from me. They have chosen to go their own way."
    },
    {
      "verse": "24",
      "text": "They do not say to themselves, “We should respect the Lord our God. He sends rain for us in the autumn and in the spring. He makes sure that we have a harvest from our crops. ” “We should respect the Lord our God. He sends rain for us in the autumn and in the spring. He makes sure that we have a harvest from our crops. ”"
    },
    {
      "verse": "25",
      "text": "But instead, your sins have stopped these good things. You have not received God's blessing. You have not received God's blessing."
    },
    {
      "verse": "26",
      "text": "There are wicked men among my people. They like to catch people and rob them. They hide like someone who wants to catch a bird. They put out their traps to kill what they want. They like to catch people and rob them. They hide like someone who wants to catch a bird. They put out their traps to kill what they want."
    },
    {
      "verse": "27",
      "text": "Their houses are full of valuable things, like a trap that is full of beautiful birds. They have cheated peopleand they have robbed them. That is how they have become rich and powerful. like a trap that is full of beautiful birds. They have cheated people and they have robbed them. That is how they have become rich and powerful."
    },
    {
      "verse": "28",
      "text": "They are very fat and healthy. They will never stop doing evil things. They do not help poor people or children who have no family. They do not try to get justice for them. ’ They will never stop doing evil things. They do not help poor people or children who have no family. They do not try to get justice for them. ’"
    },
    {
      "verse": "29",
      "text": "The Lord says, ‘I will certainly punish them for what they have done. I will pay back this wicked nation for their sins. ‘I will certainly punish them for what they have done. I will pay back this wicked nation for their sins."
    },
    {
      "verse": "30",
      "text": "A terrible thing is happening in the land of Judah."
    },
    {
      "verse": "31",
      "text": "The prophets speak messages that are not true. The priests make their own rules for people to obey. And my people love to live like this! But when all this comes to an end, my people will be helpless! ’"
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "You descendants of Benjamin, you must run away to be safe! Escape from Jerusalem! Make a noise with a trumpet in Tekoa! Light a fire to warn people in Beth-Hakkerem! A great army is coming from the north. It will come to destroy everything! you must run away to be safe! Escape from Jerusalem! Make a noise with a trumpet in Tekoa! Light a fire to warn people in Beth-Hakkerem! A great army is coming from the north. It will come to destroy everything!"
    },
    {
      "verse": "2",
      "text": "Jerusalem is a beautiful city, like a daughter that I love. She cannot protect herself, and I will destroy her. like a daughter that I love. She cannot protect herself, and I will destroy her."
    },
    {
      "verse": "3",
      "text": "Kings will come to attack the city. They will bring their armies, like shepherds with their sheep. They will make their camps all around the city. Each of them will take their own piece of land. They will bring their armies, like shepherds with their sheep. They will make their camps all around the city. Each of them will take their own piece of land."
    },
    {
      "verse": "4",
      "text": "They will say to their soldiers, ‘Get ready to attack the city! We will attack at noon! ’But if the day is almost finished, they will say, ‘It is already evening and it will soon be dark. ‘Get ready to attack the city! We will attack at noon! ’ But if the day is almost finished, they will say, ‘It is already evening and it will soon be dark."
    },
    {
      "verse": "5",
      "text": "So we should attack them in the night. We will destroy all their strong buildings! ’ We will destroy all their strong buildings! ’"
    },
    {
      "verse": "6",
      "text": "This will happen because Lord Almighty has said, ‘Cut down the trees around Jerusalem. Use them to build towers to the top of the city's walls. I must punish Jerusalem. It is full of cruel people. ‘Cut down the trees around Jerusalem. Use them to build towers to the top of the city's walls. I must punish Jerusalem. It is full of cruel people."
    },
    {
      "verse": "7",
      "text": "They never stop doing wicked things, like water that pours out from a spring. It is full of the noise of violence and fights. Everywhere I see people who have disease and wounds. like water that pours out from a spring. It is full of the noise of violence and fights. Everywhere I see people who have disease and wounds."
    },
    {
      "verse": "8",
      "text": "Listen to me as I warn you, Jerusalem. If not, I will turn away from you. I will destroy you completely. Nobody will live on your land any more. ’ If not, I will turn away from you. I will destroy you completely. Nobody will live on your land any more. ’"
    },
    {
      "verse": "9",
      "text": "The Lord Almighty said this:‘I will let the enemy take all the people from Israel, like a farmer who picks all the grapes from his vine. So check the vines carefully, to see if there are some grapes that you can save. ’ ‘I will let the enemy take all the people from Israel, like a farmer who picks all the grapes from his vine. So check the vines carefully, to see if there are some grapes that you can save. ’"
    },
    {
      "verse": "10",
      "text": "I replied, ‘If I speak to people and I warn them, nobody will listen to me. They have shut their ears so that they cannot hear. They hate the Lord's message. They do not want to hear it. ‘If I speak to people and I warn them, nobody will listen to me. They have shut their ears so that they cannot hear. They hate the Lord's message. They do not want to hear it."
    },
    {
      "verse": "11",
      "text": "I am as angry with them as you are, Lord. I can no longer control my anger. ’The Lord replied, ‘Tell everyone how angry you are! Tell the children who play in the streets, Tell the young men who meet together. Include all the men and their wives, as well as the old people, and those who are near to death. I can no longer control my anger. ’ The Lord replied, ‘Tell everyone how angry you are! Tell the children who play in the streets, Tell the young men who meet together. Include all the men and their wives, as well as the old people, and those who are near to death."
    },
    {
      "verse": "12",
      "text": "I will give their houses to other people to live in. Other people will take their fields and their wives. Yes, I will punish the people who live in this land. ’That is what the Lord says. Other people will take their fields and their wives. Yes, I will punish the people who live in this land. ’ That is what the Lord says."
    },
    {
      "verse": "13",
      "text": "‘They all cheat other people to get what they want. Important people and ordinary people do that. Prophets and priests do that. They love to deceive people. Important people and ordinary people do that. Prophets and priests do that. They love to deceive people."
    },
    {
      "verse": "14",
      "text": "They tell my people that their wounds are not bad. They say to them, “No problem! You will have peace! ”But there will be no peace for my people. They say to them, “No problem! You will have peace! ” But there will be no peace for my people."
    },
    {
      "verse": "15",
      "text": "They are not ashamed of the disgusting things that they do. They do not even know what shame is. They have forgotten how to be ashamed. So they will fall to the ground, as other people have fallen. When I decide to punish them, that will be the end of them. ’That is what the Lord says. They do not even know what shame is. They have forgotten how to be ashamed. So they will fall to the ground, as other people have fallen. When I decide to punish them, that will be the end of them. ’ That is what the Lord says."
    },
    {
      "verse": "16",
      "text": "The Lord said to his people, ‘Stand at the place where the roads cross, and look carefully. Ask where the ways of your ancestors are. Find the good way, and go along that way. Then you will live in peace. ’But the people said, ‘No, we will not go that way. ’ ‘Stand at the place where the roads cross, and look carefully. Ask where the ways of your ancestors are. Find the good way, and go along that way. Then you will live in peace. ’ But the people said, ‘No, we will not go that way. ’"
    },
    {
      "verse": "17",
      "text": "The Lord said, ‘I sent my prophets to warn you of danger. They said, “Listen for the noise of the trumpet! That will tell you when danger is near. ”But you said, “We do not want to listen. ” ‘I sent my prophets to warn you of danger. They said, “Listen for the noise of the trumpet! That will tell you when danger is near. ” But you said, “We do not want to listen. ”"
    },
    {
      "verse": "18",
      "text": "So listen to me, all you nations. Look carefully! See what will happen to my people. Look carefully! See what will happen to my people."
    },
    {
      "verse": "19",
      "text": "Hear me, all people on the earth. I will cause great trouble for my people. I will punish them as a result of their wrong thoughts. They have not listened to my messages. They have turned against my law. I will cause great trouble for my people. I will punish them as a result of their wrong thoughts. They have not listened to my messages. They have turned against my law."
    },
    {
      "verse": "20",
      "text": "They may offer to me sweet incense that comes from Sheba. But that does not please me. The spices that they bring from lands far awaydo not please me either. I will not accept the burnt offerings or other sacrificesthat they offer to me. ’ But that does not please me. The spices that they bring from lands far away do not please me either. I will not accept the burnt offerings or other sacrifices that they offer to me. ’"
    },
    {
      "verse": "21",
      "text": "So this is what the Lord says:‘I will send troubles to make these people fall down. Fathers and their children will all fall to the ground. Their friends and their neighbours will die. ’ ‘I will send troubles to make these people fall down. Fathers and their children will all fall to the ground. Their friends and their neighbours will die. ’"
    },
    {
      "verse": "22",
      "text": "This is what the Lord says:‘Look! An army is coming from the north. A great nation is preparing to attack youfrom a place that is far away. ‘Look! An army is coming from the north. A great nation is preparing to attack you from a place that is far away."
    },
    {
      "verse": "23",
      "text": "Its soldiers carry bows and spears as their weapons. They are always cruel and they are never kind. They ride into the battle on their horses, and it sounds like the noise of the sea. They are ready to attack you, people of Jerusalem. ’ They are always cruel and they are never kind. They ride into the battle on their horses, and it sounds like the noise of the sea. They are ready to attack you, people of Jerusalem. ’"
    },
    {
      "verse": "24",
      "text": "The people say, ‘We have heard news about them, and we are very frightened. We feel too weak to fight. We are afraid and in pain, like a woman who is giving birth. ‘We have heard news about them, and we are very frightened. We feel too weak to fight. We are afraid and in pain, like a woman who is giving birth."
    },
    {
      "verse": "25",
      "text": "Do not go out into the fields. Do not travel on the roads. Our enemies are everywhere. They have their swords ready to attack us. Danger is all around us. ’ Do not travel on the roads. Our enemies are everywhere. They have their swords ready to attack us. Danger is all around us. ’"
    },
    {
      "verse": "26",
      "text": "So I say, ‘My dear people, show that you are sorry. Wear sackcloth and sit in ashes. Weep and cry aloud, as if your only child had died. Realize that the enemy's army will soon be hereand they are ready to destroy us. ’ Wear sackcloth and sit in ashes. Weep and cry aloud, as if your only child had died. Realize that the enemy's army will soon be here and they are ready to destroy us. ’"
    },
    {
      "verse": "27",
      "text": "The Lord said to me, ‘I have sent you to test my people. Test them like someone tests metal. Watch them carefully, to see how they live. ‘I have sent you to test my people. Test them like someone tests metal. Watch them carefully, to see how they live."
    },
    {
      "verse": "28",
      "text": "They have completely turned against God. They refuse to change their minds. They tell lies against people, and they cheat them. They refuse to change their minds. They tell lies against people, and they cheat them."
    },
    {
      "verse": "29",
      "text": "A very hot fire can remove the dirt from silverand make it pure. I punish my people to make them pure, but it is useless. There are too many wicked people, so I cannot make them pure. and make it pure. I punish my people to make them pure, but it is useless. There are too many wicked people, so I cannot make them pure."
    },
    {
      "verse": "30",
      "text": "I, the Lord, cannot accept them, so they are like useless silver. ’"
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "The Lord gave this message to Jeremiah:"
    },
    {
      "verse": "2",
      "text": "‘Stand at the gate of the Lord's temple and speak this message. Say, “Listen to the Lord's message, all you people of Judah. You come through this gate to worship the Lord."
    },
    {
      "verse": "3",
      "text": "This is what the Lord Almighty, Israel's God, says: Change the way that you live. Do things that are right. If you change, I will let you continue to live here."
    },
    {
      "verse": "4",
      "text": "People may say, ‘We are safe here! This is the temple of the Lord. It is the temple of the Lord! ’ But the people who say that are deceiving you. Do not trust them."
    },
    {
      "verse": "5",
      "text": "You must change the way that you have been living. You must do what is right. Be fair to each other."
    },
    {
      "verse": "6",
      "text": "Do not be cruel to foreigners who are living among you. Do not be cruel to widows, or to children who have no family. You must stop murdering people. You must stop worshipping other gods. If you live like that, it will destroy you."
    },
    {
      "verse": "7",
      "text": "If you change how you live, I will let you live in this place. It is the land that I gave to your ancestors, to be their home for ever."
    },
    {
      "verse": "8",
      "text": "But look at how you live now! You believe in lies that cannot save you."
    },
    {
      "verse": "9",
      "text": "You rob people. You murder people. You have sex with someone else's wife or husband. You tell lies in court when you have promised to tell the truth. You offer sacrifices to the false god, Baal. You serve other gods that you never knew before."
    },
    {
      "verse": "10",
      "text": "You do that and then you come to meet me here, in my own house! You say, ‘We are safe! ’"
    },
    {
      "verse": "11",
      "text": "This is my temple! It is not a place where robbers can hide and be safe. Listen to me! I have seen the things that you have done. ” That is what the Lord says."
    },
    {
      "verse": "12",
      "text": "“Go to Shiloh, and see what I did there. It was the first place that I chose where people would worship me. But I destroyed it because of the wicked things that my people, the Israelites, did."
    },
    {
      "verse": "13",
      "text": "You have done the same wicked things. I have warned you many times, but you have not listened to me. I called out to you, but you refused to answer. ” That is what the Lord says."
    },
    {
      "verse": "14",
      "text": "“So now I will destroy this temple that I chose to be my home. I gave this temple to you and to your ancestors. You think that it will keep you safe. But I will destroy it, as I destroyed Shiloh."
    },
    {
      "verse": "15",
      "text": "I will send you far away from me. I already did that to the other Israelites, the people of Ephraim's tribe. ”"
    },
    {
      "verse": "16",
      "text": "Jeremiah, you must not pray for this people. Do not ask me to help them. If you ask me to save them, I will not listen to you."
    },
    {
      "verse": "17",
      "text": "You can see what they are doing in Jerusalem and in all the towns of Judah."
    },
    {
      "verse": "18",
      "text": "The children fetch wood and their fathers use it to light a fire. The women prepare flour to cook cakes. Then they offer them to the “Queen of Heaven”. And they offer gifts of drink to other false gods. They do that to make me angry."
    },
    {
      "verse": "19",
      "text": "But they are not hurting me. They are hurting themselves, and they will be ashamed. ’ That is what the Lord says."
    },
    {
      "verse": "20",
      "text": "The Lord God says, ‘Because I am so angry, I will punish this land very much. It will be like a fire that nobody can stop. My punishment will destroy people, animals, trees and crops. ’"
    },
    {
      "verse": "21",
      "text": "The Lord Almighty, Israel's God, says this to Judah's people: ‘You should eat the meat from your burnt offerings, as well as your other sacrifices. You are not offering them to me!"
    },
    {
      "verse": "22",
      "text": "Remember this: I brought your ancestors safely out of Egypt. Then I gave them my commands. Those commands were not only about burnt offerings and sacrifices."
    },
    {
      "verse": "23",
      "text": "I also told them, “Obey me. Then I will be your God, and you will be my people. You must live in the way that I have commanded you. If you do that, you will enjoy your lives. ”"
    },
    {
      "verse": "24",
      "text": "But your ancestors refused to obey me. They did anything that their wicked thoughts made them want to do. They refused to return to me. Instead, they went further away."
    },
    {
      "verse": "25",
      "text": "Since the time that your ancestors left Egypt, I have sent my servants, the prophets to speak to you. I have continued to do that many times, even until now."
    },
    {
      "verse": "26",
      "text": "But my people did not listen to me. They have refused to obey me. They have continued to do evil things, even worse than their ancestors did. ’"
    },
    {
      "verse": "27",
      "text": "The Lord said to me, ‘Jeremiah, you must speak my message to them. But they will not listen to you. When you call out to them, they will not answer."
    },
    {
      "verse": "28",
      "text": "So you must tell them, “The people of this nation have not obeyed the Lord their God. When I warned them, they have not agreed to change. Nobody does what is right. Nobody even speaks about what is true."
    },
    {
      "verse": "29",
      "text": "Now show that you are upset. Cut off your hair and throw it away. Go to the tops of the hills and sing sad songs about death. Realize that today's people have made the Lord very angry. So he has decided to turn away from them and leave them. ” ’"
    },
    {
      "verse": "30",
      "text": "The Lord says, ‘The people of Judah have done things that I see are evil. They have put their disgusting idols in my temple. That is the place that I chose to be my special home, and they have made it unclean."
    },
    {
      "verse": "31",
      "text": "They have built altars in Topheth, in Ben-Hinnom Valley. On those altars, they light fires to burn their sons and daughters as sacrifices. I never commanded them to do that. I never even thought about it."
    },
    {
      "verse": "32",
      "text": "So listen to me! The time will soon come when people no longer call those places Topheth or Ben-Hinnom Valley. Instead, they will call it Death Valley. They will bury lots of dead people there. There will be no space left to bury any more people!"
    },
    {
      "verse": "33",
      "text": "Then the bodies of dead people will lie on the ground. Birds and animals will come and eat them. There will be nobody to chase them away."
    },
    {
      "verse": "34",
      "text": "Jerusalem and all of Judah will become like a desert where nobody lives. There will be no noise of happy people. There will be no happy songs or marriage parties. The whole land will be quiet. ’"
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "The Lord says, ‘At that time, your enemies will open the graves of your leaders and they will remove their bones. They will remove the bones of Judah's kings and their officers, as well as the priests and prophets. They will also remove the bones of the ordinary people of Jerusalem."
    },
    {
      "verse": "2",
      "text": "They will leave the bones all over the ground, under the sun, the moon and the stars. Those were the gods that my people loved. They served them and they worshipped them. Nobody will take their bones and bury them again. They will lie on the ground, like dung."
    },
    {
      "verse": "3",
      "text": "The people of this wicked nation who are still alive will want to die. I will send them away as prisoners to other countries. They will not want to live in those places. They will all want to die. ’ That is what the Lord Almighty says."
    },
    {
      "verse": "4",
      "text": "‘Jeremiah, tell the people that this is what I, the Lord, say to them: When people fall down, they get up again. When people realize that they are on the wrong road, they turn around. When people fall down, they get up again. When people realize that they are on the wrong road, they turn around."
    },
    {
      "verse": "5",
      "text": "So why have the people of Jerusalem not turned back to me? They turn away from me all the time. They believe the lies of false gods, and they refuse to return to me. They turn away from me all the time. They believe the lies of false gods, and they refuse to return to me."
    },
    {
      "verse": "6",
      "text": "I have listened carefully to them, but they do not say what is right. They are not sorry for the wicked things that they have done. None of them say, “I have done something wrong. ”They all continue to do what they want to do. They are like horses that are running into a battle. but they do not say what is right. They are not sorry for the wicked things that they have done. None of them say, “I have done something wrong. ” They all continue to do what they want to do. They are like horses that are running into a battle."
    },
    {
      "verse": "7",
      "text": "Even birds know when it is time for them to move to a different place. That is true for storks, doves, swallows and cranes. Birds know when it is time to return, but my people do not know my laws. That is true for storks, doves, swallows and cranes. Birds know when it is time to return, but my people do not know my laws."
    },
    {
      "verse": "8",
      "text": "You say, “We are wisebecause we have the law of the Lord. ”But I tell you, your teachers have changed my laws. They teach you lies instead. because we have the law of the Lord. ” But I tell you, your teachers have changed my laws. They teach you lies instead."
    },
    {
      "verse": "9",
      "text": "Those wise teachers will be ashamed and upset. Enemies will catch them as their prisoners. They have refused to accept the Lord's message. So they are not really wise. Enemies will catch them as their prisoners. They have refused to accept the Lord's message. So they are not really wise."
    },
    {
      "verse": "10",
      "text": "I will give their wives to other men. Their fields will belong to other men. They all cheat other people to get what they want. Important people and ordinary people do that. Prophets and priests do that. They love to deceive people. Their fields will belong to other men. They all cheat other people to get what they want. Important people and ordinary people do that. Prophets and priests do that. They love to deceive people."
    },
    {
      "verse": "11",
      "text": "They tell my dear people that their wounds are not bad. They say to them, “No problem! You will have peace. ”But there will be no peace for my people. They say to them, “No problem! You will have peace. ” But there will be no peace for my people."
    },
    {
      "verse": "12",
      "text": "They are not ashamed of the disgusting things that they do. They do not even know what shame is. They have forgotten how to be ashamed. So they will fall to the ground, as other people have fallen. When I punish them, that will be the end of them. ’That is what the Lord says. They do not even know what shame is. They have forgotten how to be ashamed. So they will fall to the ground, as other people have fallen. When I punish them, that will be the end of them. ’ That is what the Lord says."
    },
    {
      "verse": "13",
      "text": "The Lord says, ‘I will take away the crops from their fields. ’‘No figs or grapes will grow on their trees. The leaves on their trees will dry up and die. All the good things that I gave to them will disappear. ’ ‘I will take away the crops from their fields. ’ ‘No figs or grapes will grow on their trees. The leaves on their trees will dry up and die. All the good things that I gave to them will disappear. ’"
    },
    {
      "verse": "14",
      "text": "The people say:‘We should not sit here and do nothing. We must all go together into our strong cities. If we have to die, we will die there! The Lord our God has said that we must die. We have done bad things against him. He has decided to punish us with death. He has given us water to drink that has poison in it. ‘We should not sit here and do nothing. We must all go together into our strong cities. If we have to die, we will die there! The Lord our God has said that we must die. We have done bad things against him. He has decided to punish us with death. He has given us water to drink that has poison in it."
    },
    {
      "verse": "15",
      "text": "We wanted to have peace, but nothing good has happened to us. We wanted to rest without trouble, but instead we are afraid. but nothing good has happened to us. We wanted to rest without trouble, but instead we are afraid."
    },
    {
      "verse": "16",
      "text": "In the city of Dan, people can already hearthe noise of the enemy's horses. They are coming to attack our land, so everyone shakes with fear. They will destroy the whole landand everything in it. They will destroy the citiesand all the people who live in them. ’ the noise of the enemy's horses. They are coming to attack our land, so everyone shakes with fear. They will destroy the whole land and everything in it. They will destroy the cities and all the people who live in them. ’"
    },
    {
      "verse": "17",
      "text": "The Lord says, ‘Yes! I am sending an enemy's army to attack you. They will be like dangerous snakes that have poison. Nobody can stop them! They will bite you and kill you. ’ ‘Yes! I am sending an enemy's army to attack you. They will be like dangerous snakes that have poison. Nobody can stop them! They will bite you and kill you. ’"
    },
    {
      "verse": "18",
      "text": "I said, ‘I am very sad and upset. I will never get better again. ‘I am very sad and upset. I will never get better again."
    },
    {
      "verse": "19",
      "text": "Listen to my dear people! They are calling out for help everywhere in the land. They are saying, “Is the Lord still with us in Zion? Is he still there to rule us as our King? ” ’The Lord replies, ‘They worship images of false gods. and useless foreign idols. That has made me very angry. ’ They are calling out for help everywhere in the land. They are saying, “Is the Lord still with us in Zion? Is he still there to rule us as our King? ” ’ The Lord replies, ‘They worship images of false gods. and useless foreign idols. That has made me very angry. ’"
    },
    {
      "verse": "20",
      "text": "The people say, ‘We have taken in all our crops from the fields. The summer has finished. And still nobody has rescued us. ’ ‘We have taken in all our crops from the fields. The summer has finished. And still nobody has rescued us. ’"
    },
    {
      "verse": "21",
      "text": "I am very upsetbecause my dear people have so much pain. I weep and I cry, as if a friend had died. because my dear people have so much pain. I weep and I cry, as if a friend had died."
    },
    {
      "verse": "22",
      "text": "Surely there is a medicine in Gilead. There is a doctor there who can make my dear people better. But my people are still ill. Why are they not better?"
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "‘My head should be like a pool of water. My eyes should be like a river of tears. Then I would never stop cryingfor my dear people who have died in war. My eyes should be like a river of tears. Then I would never stop crying for my dear people who have died in war."
    },
    {
      "verse": "2",
      "text": "I would like to live in a hut in the desert. Then I could leave my people. I could forget about them. They have all turned away from God. They have not been faithful to him. They are a crowd of people that nobody can trust. ’ Then I could leave my people. I could forget about them. They have all turned away from God. They have not been faithful to him. They are a crowd of people that nobody can trust. ’"
    },
    {
      "verse": "3",
      "text": "The Lord says, ‘The tongues of these people speak lies, like the bows of soldiers shoot arrows. They have become powerful in the land, but they have used lies to do that. They do more and more evil things, and they do not respect me. ‘The tongues of these people speak lies, like the bows of soldiers shoot arrows. They have become powerful in the land, but they have used lies to do that. They do more and more evil things, and they do not respect me."
    },
    {
      "verse": "4",
      "text": "Be careful of your friends. Do not even trust your brothers! They will always try to cheat you. All your friends will speak lies about you. Do not even trust your brothers! They will always try to cheat you. All your friends will speak lies about you."
    },
    {
      "verse": "5",
      "text": "They deceive each other, and they never tell the truth. They have taught their tongues to speak lies. They love to do bad thingsand they cannot stop themselves. and they never tell the truth. They have taught their tongues to speak lies. They love to do bad things and they cannot stop themselves."
    },
    {
      "verse": "6",
      "text": "They hurt and they deceive each other. They do that more and more. They refuse to respect me. ’That is what the Lord says. They do that more and more. They refuse to respect me. ’ That is what the Lord says."
    },
    {
      "verse": "7",
      "text": "So the Lord Almighty says this:‘Listen! I will test my people, like a man uses fire to make metal become pure. I must punish them like this because they are so wicked. There is nothing else that I can do! ‘Listen! I will test my people, like a man uses fire to make metal become pure. I must punish them like this because they are so wicked. There is nothing else that I can do!"
    },
    {
      "verse": "8",
      "text": "Their tongues are like arrows that have poison. They hurt people with their lies. They speak kind words to their neighbours, but they are looking for a way to cheat them. They hurt people with their lies. They speak kind words to their neighbours, but they are looking for a way to cheat them."
    },
    {
      "verse": "9",
      "text": "I must certainly punish them for what they have done. I will pay back this wicked nation for their sins. ’That is what the Lord says. I will pay back this wicked nation for their sins. ’ That is what the Lord says."
    },
    {
      "verse": "10",
      "text": "‘I will weep for the mountains. I will cry for the fields in the wilderness. There is no grass for the animals to eat. Nobody travels through those places. There is no sound of cows and sheep. The birds and the wild animals have all disappeared. ’ I will cry for the fields in the wilderness. There is no grass for the animals to eat. Nobody travels through those places. There is no sound of cows and sheep. The birds and the wild animals have all disappeared. ’"
    },
    {
      "verse": "11",
      "text": "The Lord replied, ‘I will make Jerusalem a heap of stones. Only wild animals will live there. I will destroy the towns of Judahso that nobody can live in them. ’ ‘I will make Jerusalem a heap of stones. Only wild animals will live there. I will destroy the towns of Judah so that nobody can live in them. ’"
    },
    {
      "verse": "12",
      "text": "I said, ‘Nobody is wise enough to understand this. The Lord has not told anyone, so that he can explain it to others. Why has our land become like a desert so that nobody travels through it? Does anyone know the answer? ’ ‘Nobody is wise enough to understand this. The Lord has not told anyone, so that he can explain it to others. Why has our land become like a desert so that nobody travels through it? Does anyone know the answer? ’"
    },
    {
      "verse": "13",
      "text": "The Lord answered, ‘It is because my people have not accepted the laws that I gave to them. They have not obeyed me. They have not lived in the way that I told them to live."
    },
    {
      "verse": "14",
      "text": "Instead, they have done whatever they wanted to do. They have served the gods of Baal, as their ancestors taught them to do. ’"
    },
    {
      "verse": "15",
      "text": "So the Lord Almighty, Israel's God, says this: ‘I will punish my people with trouble and pain. I will give them food that is bitter. They will drink water that is poison."
    },
    {
      "verse": "16",
      "text": "I will send them away as prisoners. They will live among foreign nations that they had never heard about. Their ancestors had not heard about them either. I will send enemies to chase after them until I have destroyed them. ’"
    },
    {
      "verse": "17",
      "text": "The Lord Almighty said this:‘Think about what is happening! Call the women who weep at funerals. Bring those women who know what to do. ’ ‘Think about what is happening! Call the women who weep at funerals. Bring those women who know what to do. ’"
    },
    {
      "verse": "18",
      "text": "‘Yes, tell them to come quicklyto sing funeral songs for us. Then tears will pour from our eyes, and we will not stop weeping. to sing funeral songs for us. Then tears will pour from our eyes, and we will not stop weeping."
    },
    {
      "verse": "19",
      "text": "Listen to the people who are crying in Jerusalem! They say, “A terrible thing has happened to us! We are very ashamed! Our enemies have destroyed our houses. Now we have to leave our land. ” ’ They say, “A terrible thing has happened to us! We are very ashamed! Our enemies have destroyed our houses. Now we have to leave our land. ” ’"
    },
    {
      "verse": "20",
      "text": "‘Now hear the Lord's message, you women. Listen to what he says to you. Teach your daughters how to weep. Teach each other this funeral song: Listen to what he says to you. Teach your daughters how to weep. Teach each other this funeral song:"
    },
    {
      "verse": "21",
      "text": "“Death has come to visit us! It has come into our strong houses. Death has taken away our childrenwho play in the streets. It has taken away our young menwho meet together in the streets. ” It has come into our strong houses. Death has taken away our children who play in the streets. It has taken away our young men who meet together in the streets. ”"
    },
    {
      "verse": "22",
      "text": "The Lord says this: Dead bodies of people will lie everywhere on the ground. They will lie there like dungthat a farmer puts on his fields. They will lie there like crops at harvest timethat nobody has picked up. ’ Dead bodies of people will lie everywhere on the ground. They will lie there like dung that a farmer puts on his fields. They will lie there like crops at harvest time that nobody has picked up. ’"
    },
    {
      "verse": "23",
      "text": "The Lord says, ‘Wise people should not be proud of their wisdom. Powerful people should not be proud of their power. And rich people should not be proud that they are rich. ‘Wise people should not be proud of their wisdom. Powerful people should not be proud of their power. And rich people should not be proud that they are rich."
    },
    {
      "verse": "24",
      "text": "If they want to be proud about something, they should be proud that they know me. They should boast that they understand who I am. I am the Lord. I am faithful in my love for my people. I always do what is right and fair. It makes me happy when people live in that way too. ’ they should be proud that they know me. They should boast that they understand who I am. I am the Lord. I am faithful in my love for my people. I always do what is right and fair. It makes me happy when people live in that way too. ’"
    },
    {
      "verse": "25",
      "text": "The Lord says, ‘Be careful! Very soon I will punish all people who do not respect me. Those people may be circumcised, but if they do not respect me, I will punish them."
    },
    {
      "verse": "26",
      "text": "Those people include the Egyptians, the Edomites, the Ammonites, the Moabites and the people of Judah. I will also punish the people who live in the desert and who cut their hair short. Those people are not circumcised to give honour to me. The Israelites are the same. Their bodies are circumcised, but they do not want to obey my covenant with them. ’"
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "People of Israel, listen to what the Lord says to you."
    },
    {
      "verse": "2",
      "text": "The Lord says, ‘Do not copy the way that people of other nations live. They are afraid of strange things that they see in the sky. But you must not be afraid of those things. ‘Do not copy the way that people of other nations live. They are afraid of strange things that they see in the sky. But you must not be afraid of those things."
    },
    {
      "verse": "3",
      "text": "The customs of those people are useless. They cut down a tree in the forest. A worker uses his tools to make it into an idol. They cut down a tree in the forest. A worker uses his tools to make it into an idol."
    },
    {
      "verse": "4",
      "text": "He covers it with silver and goldto make it look beautiful. He uses nails to fix it togetherso that it will not fall down. to make it look beautiful. He uses nails to fix it together so that it will not fall down."
    },
    {
      "verse": "5",
      "text": "Those idols cannot speak. They are like scarecrows that a farmer puts in his field of vegetables. The idols cannot walk, so people have to carry them. So do not be afraid of them. They cannot hurt you. And they do not have any power to help you. ’ They are like scarecrows that a farmer puts in his field of vegetables. The idols cannot walk, so people have to carry them. So do not be afraid of them. They cannot hurt you. And they do not have any power to help you. ’"
    },
    {
      "verse": "6",
      "text": "There is nobody like you, Lord. You are great and your name shows your power. You are great and your name shows your power."
    },
    {
      "verse": "7",
      "text": "Everyone should respect you, the King who rules all the nations. You deserve that people give you honour. There is nobody like you anywhere in the world. Among all the wise people of the nationsand among all their kings, there is no one like you. the King who rules all the nations. You deserve that people give you honour. There is nobody like you anywhere in the world. Among all the wise people of the nations and among all their kings, there is no one like you."
    },
    {
      "verse": "8",
      "text": "The people of those nations are stupid and foolish. They think that wooden idols can teach them something! They think that wooden idols can teach them something!"
    },
    {
      "verse": "9",
      "text": "They bring thin silver from Spain. They bring gold from Uphaz. Workers who know how to use wood and metalmake the idols look beautiful. They put valuable blue and purple clothes on the idols. Workers who have special skills do this. They bring gold from Uphaz. Workers who know how to use wood and metal make the idols look beautiful. They put valuable blue and purple clothes on the idols. Workers who have special skills do this."
    },
    {
      "verse": "10",
      "text": "But the Lord is the only true God. He is the God who is alive. He is the King who rules for ever. When he is angry, the earth shakes. None of the nations can stop his anger. He is the God who is alive. He is the King who rules for ever. When he is angry, the earth shakes. None of the nations can stop his anger."
    },
    {
      "verse": "11",
      "text": "Tell the nations this:‘Your gods did not make the earth or the sky. They will disappear completely from everywhere on earthand everywhere in the sky. ’ ‘Your gods did not make the earth or the sky. They will disappear completely from everywhere on earth and everywhere in the sky. ’"
    },
    {
      "verse": "12",
      "text": "But the Lord used his power to make the earth. He used his wisdom to make it strong. He knew how to put the sky to cover the earth. He used his wisdom to make it strong. He knew how to put the sky to cover the earth."
    },
    {
      "verse": "13",
      "text": "When he shouts like thunder, the water in the sky roars. He causes clouds to rise from the far places of the earth. He causes bright lightning to show in the storms. He opens his rooms so that the wind comes outand it blows everywhere. the water in the sky roars. He causes clouds to rise from the far places of the earth. He causes bright lightning to show in the storms. He opens his rooms so that the wind comes out and it blows everywhere."
    },
    {
      "verse": "14",
      "text": "People who worship idols are stupid. They do not understand what they are doing. The men who make idols will be ashamed. They make images of gods that are false. None of their idols have the breath of life in them. They do not understand what they are doing. The men who make idols will be ashamed. They make images of gods that are false. None of their idols have the breath of life in them."
    },
    {
      "verse": "15",
      "text": "They are useless things that people should laugh at. When the time for their punishment arrives, God will destroy them. When the time for their punishment arrives, God will destroy them."
    },
    {
      "verse": "16",
      "text": "The God that Jacob's descendants worshipis not like those idols. He created everything. He chose the Israelites as the people who would belong to him. His name is the Lord Almighty. is not like those idols. He created everything. He chose the Israelites as the people who would belong to him. His name is the Lord Almighty."
    },
    {
      "verse": "17",
      "text": "Your enemies are all aroundand they are ready to attack you. So get all your things together. Prepare to leave your country. and they are ready to attack you. So get all your things together. Prepare to leave your country."
    },
    {
      "verse": "18",
      "text": "This is what the Lord says:‘I will now throw out the people who live in this land. I will bring much trouble to them, and they will be in pain. ’ ‘I will now throw out the people who live in this land. I will bring much trouble to them, and they will be in pain. ’"
    },
    {
      "verse": "19",
      "text": "‘A terrible thing has happened to us! We have received a very bad wound. We thought, “We are very ill, but one day we will get better. ” We have received a very bad wound. We thought, “We are very ill, but one day we will get better. ”"
    },
    {
      "verse": "20",
      "text": "But now they have destroyed our tent. They have broken the ropes that held it. Our children have gone, and none of them remain. There is nobody still alivewho can help us build our homes again. They have broken the ropes that held it. Our children have gone, and none of them remain. There is nobody still alive who can help us build our homes again."
    },
    {
      "verse": "21",
      "text": "Our leaders are fools. They do not ask the Lord for his advice. So they have failed to take care of us, and all their people have disappeared. They do not ask the Lord for his advice. So they have failed to take care of us, and all their people have disappeared."
    },
    {
      "verse": "22",
      "text": "Listen! We have heard the news! There is the noise of a great army in the north. It is marching towards us! It is coming to attack the towns of Judah. It will make them heaps of stones. Only wild animals will live in them. There is the noise of a great army in the north. It is marching towards us! It is coming to attack the towns of Judah. It will make them heaps of stones. Only wild animals will live in them."
    },
    {
      "verse": "23",
      "text": "Lord, I know that nobody controls their own life. Nobody can decide what will happen to them. Nobody can decide what will happen to them."
    },
    {
      "verse": "24",
      "text": "Lord, teach us what is right, but do it carefully. Please do not punish us in your anger. That would be the end of us. but do it carefully. Please do not punish us in your anger. That would be the end of us."
    },
    {
      "verse": "25",
      "text": "Instead, be angry with the nations that do not respect you. Be angry with the people who do not worship you. Those are the people who have destroyed Jacob's descendants. They have killed our people. They have destroyed our land and our homes. ’"
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "The Lord gave this message to Jeremiah: I answered, ‘Amen, Lord, I would like that to happen. ’"
    },
    {
      "verse": "2",
      "text": "‘Listen to the rules of the covenant that I made with my people. Tell them to the people who live in Jerusalem and the other towns in Judah."
    },
    {
      "verse": "3",
      "text": "Tell them that the Lord, Israel's God, says, “I will curse anyone who does not obey the rules of this covenant."
    },
    {
      "verse": "4",
      "text": "I gave those rules to your ancestors when I brought them safely out of Egypt. That place was like a hot oven where they were in great pain. At that time, I said to them, ‘Obey me and do everything that I command you to do. If you obey my covenant with you, you will be my people and I will be your God."
    },
    {
      "verse": "5",
      "text": "I will do what I promised to your ancestors. I promised to give to them a land where there was plenty of food and drink, enough for everyone. ’ That is the land that you still live in today. ” ’I answered, ‘Amen, Lord, I would like that to happen. ’"
    },
    {
      "verse": "6",
      "text": "The Lord said to me, ‘Speak all these words in the towns of Judah and in the streets of Jerusalem: “Listen to the rules of my covenant with you. Obey them!"
    },
    {
      "verse": "7",
      "text": "I clearly warned your ancestors that they must obey me. I warned them many times since I brought them safely out of Egypt. I have continued to do that, even until today."
    },
    {
      "verse": "8",
      "text": "But they did not listen to me. They did not agree to obey my covenant. Instead, they continued to do all the wicked things that they wanted to do. They would not change how they lived. So I punished them in the way that the covenant said they deserved. I had commanded them to obey the rules of the covenant, and they did not do that. ” ’"
    },
    {
      "verse": "9",
      "text": "The Lord said to me, ‘The people of Judah and those who live in Jerusalem have decided to turn against me."
    },
    {
      "verse": "10",
      "text": "They are doing the same evil things that their ancestors did. Their ancestors refused to obey my commands. These people do that, and they also serve and worship other gods. I made a covenant with their ancestors. But the nations of Judah and Israel have refused to obey that covenant."
    },
    {
      "verse": "11",
      "text": "So now, I, the Lord, say this: “I will bring great trouble to these people. They will not be able to escape. When they call out to me for help, I will not listen to them."
    },
    {
      "verse": "12",
      "text": "The people who live in Jerusalem and in the other towns of Judah will ask their false gods to help them. Those are the gods that they offer sacrifices to. But when this terrible trouble comes, those gods will never be able to rescue them."
    },
    {
      "verse": "13",
      "text": "You people of Judah have as many gods as you have towns! You have built many altars to offer sacrifices to that disgusting god, Baal. You have built as many of those altars as there are streets in Jerusalem! ”"
    },
    {
      "verse": "14",
      "text": "So, Jeremiah, do not pray for these people. Do not ask me to do anything to help them. Do not ask me to save them. When trouble comes and they ask me for help, I will not listen to them."
    },
    {
      "verse": "15",
      "text": "The people that I love are doing wicked things. They should not be in my temple. They think that they will be safeif they offer animal sacrifices to me. They enjoy the evil things that they do, and their punishment will certainly happen. They should not be in my temple. They think that they will be safe if they offer animal sacrifices to me. They enjoy the evil things that they do, and their punishment will certainly happen."
    },
    {
      "verse": "16",
      "text": "I, the Lord, called you a beautiful olive tree. It was a tree that gave lots of good fruit. But now I will destroy you with fire. The flames will make a loud noise. All your branches will be useless. It was a tree that gave lots of good fruit. But now I will destroy you with fire. The flames will make a loud noise. All your branches will be useless."
    },
    {
      "verse": "17",
      "text": "I, the Lord Almighty, planted you in the land, like a tree. But now you have caused me to be angry. You nations of Israel and Judah have done evil things. And you have offered sacrifices to Baal. So now I have decided to punish you with great trouble. ’ But now you have caused me to be angry. You nations of Israel and Judah have done evil things. And you have offered sacrifices to Baal. So now I have decided to punish you with great trouble. ’"
    },
    {
      "verse": "18",
      "text": "The Lord showed me what the people were doing. He helped me to understood what was really happening."
    },
    {
      "verse": "19",
      "text": "Before that, I did not know about their plans to kill me. I was like a lamb that men were taking away to kill it. I did not know that they were saying, ‘We should cut down this tree and destroy its fruit! Jeremiah must not continue to live in this world. Then people will forget all about him. ’"
    },
    {
      "verse": "20",
      "text": "So I said, ‘Lord Almighty, you judge people in a fair way. You know what people are thinking. You understand how they feel. I trust you to show that I have not done anything that is wrong. So please punish these people. Pay them back for their sins. ’"
    },
    {
      "verse": "21",
      "text": "The Lord told me that some men in Anathoth wanted to kill me. They said to me, ‘Stop telling us messages from the Lord! If you do not stop, we will kill you. ’"
    },
    {
      "verse": "22",
      "text": "So the Lord Almighty said, ‘Yes, I will certainly punish them! Their young men will die as they fight in war. Their children will be so hungry that they die."
    },
    {
      "verse": "23",
      "text": "All those men in Anathoth who wanted to kill you will die. At the right time, I will punish them with great trouble. ’"
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "Lord, when I complain to you, you always do what is right. But I must ask you about your justice. Why do wicked people have success in life? Why do people who cheat their friendslive in comfort? you always do what is right. But I must ask you about your justice. Why do wicked people have success in life? Why do people who cheat their friends live in comfort?"
    },
    {
      "verse": "2",
      "text": "They are like trees that you have planted. They have strong roots. They produce good fruits. Those people like to talk about you a lot, but they do not really love you. They have strong roots. They produce good fruits. Those people like to talk about you a lot, but they do not really love you."
    },
    {
      "verse": "3",
      "text": "But you know everything about me, Lord. You watch me carefully to test me. You know what I am thinking. You should kill those wicked men, as they deserve! Take them away like sheep, to kill them when the time is right. You watch me carefully to test me. You know what I am thinking. You should kill those wicked men, as they deserve! Take them away like sheep, to kill them when the time is right."
    },
    {
      "verse": "4",
      "text": "Our land has been dry for a long time. The grass everywhere is dying. How long will this continue? The animals and the birds are dying. This has happened because the people who live in this land do wicked things. They like to boast, ‘God will not see what happens to us. ’ The grass everywhere is dying. How long will this continue? The animals and the birds are dying. This has happened because the people who live in this land do wicked things. They like to boast, ‘God will not see what happens to us. ’"
    },
    {
      "verse": "5",
      "text": "‘Jeremiah, you are running a race against people, and you are already tired! So you will never be able to run a race against horses. You are walking in flat fields, and you still fall over! So it will be much worse when you try to runthrough the trees and bushes near the Jordan River. and you are already tired! So you will never be able to run a race against horses. You are walking in flat fields, and you still fall over! So it will be much worse when you try to run through the trees and bushes near the Jordan River."
    },
    {
      "verse": "6",
      "text": "Even your own brothers and family have turned against you. They join with other people to attack you. So do not trust them, even when they say kind words to you. They join with other people to attack you. So do not trust them, even when they say kind words to you."
    },
    {
      "verse": "7",
      "text": "I have decided to turn away from my nation. I will leave the people that I chose to belong to me. I will put the people that I loveunder the power of their enemies. I will leave the people that I chose to belong to me. I will put the people that I love under the power of their enemies."
    },
    {
      "verse": "8",
      "text": "The people that belong to mehave turned against me. They are like a lion that hides in the forest. It roars and is ready to attack me. Because of that, I have turned against my people. have turned against me. They are like a lion that hides in the forest. It roars and is ready to attack me. Because of that, I have turned against my people."
    },
    {
      "verse": "9",
      "text": "They attack me like hyenas, but vultures are ready to attack them. Tell all the wild animals to come, so that they can eat their dead bodies! but vultures are ready to attack them. Tell all the wild animals to come, so that they can eat their dead bodies!"
    },
    {
      "verse": "10",
      "text": "Many foreign leaders will come. They will destroy the land where my people live. It was a beautiful garden where I planted my people. But enemies will make it become like a desert. They will destroy the land where my people live. It was a beautiful garden where I planted my people. But enemies will make it become like a desert."
    },
    {
      "verse": "11",
      "text": "They will make it a dry and empty place, where nobody lives and nothing grows. The whole land will be like a desert. There will be nobody to take care of it. where nobody lives and nothing grows. The whole land will be like a desert. There will be nobody to take care of it."
    },
    {
      "verse": "12",
      "text": "Soldiers will march over the hills in the wilderness. They will come to destroy the whole land. I, the Lord, will use them as my weapon. I will punish everyone. Nobody will be safe. They will come to destroy the whole land. I, the Lord, will use them as my weapon. I will punish everyone. Nobody will be safe."
    },
    {
      "verse": "13",
      "text": "My people will plant seeds of wheat, but they will only have weeds at harvest time. They will work very hard, but they will get nothing. At harvest time, they will have no crops to be proud of. Because I am very angry, they will not have any food. ’ but they will only have weeds at harvest time. They will work very hard, but they will get nothing. At harvest time, they will have no crops to be proud of. Because I am very angry, they will not have any food. ’"
    },
    {
      "verse": "14",
      "text": "This is what the Lord says: ‘I will punish the wicked nations that came to attack the land of my people. It was the land that I gave to Israel's people to be their home. But those enemies destroyed it. So I will remove them from their own lands. I will rescue the people of Judah from among them."
    },
    {
      "verse": "15",
      "text": "But after I have removed those nations, I will return to help them. I will be kind to them. I will bring them back to the countries where they belong. Each nation will return to live in its own land."
    },
    {
      "verse": "16",
      "text": "But they must learn to live in the way that my people live. At one time they taught my people to use Baal's name when they made promises. But now they must give honour to me as the true God. When they make a promise, they must say, “I promise to do this, as surely as the Lord lives. ” If they do these things, they will belong among my people."
    },
    {
      "verse": "17",
      "text": "But if any nation refuses to obey me, I will destroy it completely. ’ That is what the Lord says."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "The Lord said to me, ‘Go and buy a linen belt. Tie it around your body. But do not put it into water. ’"
    },
    {
      "verse": "2",
      "text": "So I bought a belt, as the Lord had told me to do. I tied it around me."
    },
    {
      "verse": "3",
      "text": "The Lord spoke to me again."
    },
    {
      "verse": "4",
      "text": "He said, ‘Take the belt that you bought and you are now wearing. Take it now to Perath. Hide it there in a hole in the rocks. ’"
    },
    {
      "verse": "5",
      "text": "So I went to Perath. I hid it there, as the Lord had commanded me to do."
    },
    {
      "verse": "6",
      "text": "Many days after that, the Lord said to me, ‘Now go to Perath again. Get the belt that I told you to hide there. ’"
    },
    {
      "verse": "7",
      "text": "So I went back to Perath. I dug out the belt from the place where I had hidden it. But it had become spoiled. I could not use it any more."
    },
    {
      "verse": "8",
      "text": "Then the Lord said to me,"
    },
    {
      "verse": "9",
      "text": "‘I, the Lord, tell you this: See what happened to your belt. Now I will destroy everything that the people of Judah and Jerusalem are proud of."
    },
    {
      "verse": "10",
      "text": "Those wicked people refuse to listen to my words. They do whatever they want to do. They are too proud to change. They serve other gods and they worship them. Now they will become as useless as this linen belt."
    },
    {
      "verse": "11",
      "text": "I tell you this: My people should have been like a belt for me. I held all the people of Israel and all the people of Judah very near to me. I chose them to be my special people. They should have respected me and given me honour so that people would praise me. But they refused to obey me."
    },
    {
      "verse": "12",
      "text": "You must tell them, “The Lord, Israel's God, says this: People make wine bottles so that they can fill them with wine. ” They may answer, “We know that is why people make wine bottles. Everyone knows that! ”"
    },
    {
      "verse": "13",
      "text": "Then tell them, “Now I will fill all the people who live in this land. I will fill the kings from David's family, the prophets, the priests and the people who live in Jerusalem. Yes, I will fill them all with so much wine that they become drunk!"
    },
    {
      "verse": "14",
      "text": "I will knock them against each other, so that they break like bottles. I will punish everyone, parents and their children. I will not be sorry for them and I will not be kind to them. I will destroy them, and nothing can stop me. ” That is what the Lord says. ’"
    },
    {
      "verse": "15",
      "text": "‘Listen carefully to me. Do not be too proud to listen! The Lord has spoken to you. Do not be too proud to listen! The Lord has spoken to you."
    },
    {
      "verse": "16",
      "text": "Give honour to the Lord your God, before it is too late. Do it before he makes everywhere become dark. Then you will fall down, like someone who walks on the mountains at night. You may hope for light to come, but God will make it completely dark. before it is too late. Do it before he makes everywhere become dark. Then you will fall down, like someone who walks on the mountains at night. You may hope for light to come, but God will make it completely dark."
    },
    {
      "verse": "17",
      "text": "If you refuse to listen to God's message, I will hide myself and I will weep. Because you are so proud, tears will pour from my eyes. I will cry because the Lord has sent his own people awayas prisoners to a foreign land. I will hide myself and I will weep. Because you are so proud, tears will pour from my eyes. I will cry because the Lord has sent his own people away as prisoners to a foreign land."
    },
    {
      "verse": "18",
      "text": "Tell the king and his mother, “Come down from your thrones. Your beautiful crowns will soon fall from your heads. ” “Come down from your thrones. Your beautiful crowns will soon fall from your heads. ”"
    },
    {
      "verse": "19",
      "text": "The cities in the south of Judah will keep their gates shut. Nobody will go in or out of the cities. Enemies will take the people of Judah away as prisoners. They will take them all into exile. Nobody will go in or out of the cities. Enemies will take the people of Judah away as prisoners. They will take them all into exile."
    },
    {
      "verse": "20",
      "text": "Leaders of Jerusalem, look up! See the enemy that is coming from the north. What has happened to your people? You were proud of themand you should have taken care of them. You are like shepherds who have lost their sheep. See the enemy that is coming from the north. What has happened to your people? You were proud of them and you should have taken care of them. You are like shepherds who have lost their sheep."
    },
    {
      "verse": "21",
      "text": "The Lord will choose other people to rule over you. They are people that you wanted to be your friends, but now they will have power over you. So what will you say about that? You will be afraid and in much pain, like a woman who is giving birth to a baby. They are people that you wanted to be your friends, but now they will have power over you. So what will you say about that? You will be afraid and in much pain, like a woman who is giving birth to a baby."
    },
    {
      "verse": "22",
      "text": "You may ask, “Why are these things happening to me? ”It is because of your many terrible sins. Like an adulteress, they have torn off your dressto make you ashamed. “Why are these things happening to me? ” It is because of your many terrible sins. Like an adulteress, they have torn off your dress to make you ashamed."
    },
    {
      "verse": "23",
      "text": "You have done evil things for a long time. So you cannot now start to do good things. Can anyone change the colour of his skin? Can a leopard remove the marks on its body? No! And you cannot change yourselves either. ’ So you cannot now start to do good things. Can anyone change the colour of his skin? Can a leopard remove the marks on its body? No! And you cannot change yourselves either. ’"
    },
    {
      "verse": "24",
      "text": "The Lord says, ‘I will blow you away, as a hot desert wind blows away straw. ‘I will blow you away, as a hot desert wind blows away straw."
    },
    {
      "verse": "25",
      "text": "That is how I have decided to punish you. It is what you deservebecause you have forgotten me. You have trusted in false gods. It is what you deserve because you have forgotten me. You have trusted in false gods."
    },
    {
      "verse": "26",
      "text": "So I will cause you to be very ashamed, like a woman whose dress they have removed. like a woman whose dress they have removed."
    },
    {
      "verse": "27",
      "text": "People of Jerusalem, you are in terrible trouble! I have seen the disgusting things that you do. You are like a woman who has not been faithful to her husband. Like a prostitute, you look for other gods to serve. You cannot control yourselves, as you do disgusting things on the hills and in the fields. Will you never be clean and pure again? ’"
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "This is the Lord's message that he gave to Jeremiah about the famine:"
    },
    {
      "verse": "2",
      "text": "‘Judah's people are very sad and upset. The people in Judah's cities are becoming weak. They are sitting on the ground and they are weeping. Jerusalem's people call to me for help. The people in Judah's cities are becoming weak. They are sitting on the ground and they are weeping. Jerusalem's people call to me for help."
    },
    {
      "verse": "3",
      "text": "Rich people send their servants to get water. They go to the wells, but they do not find any water. They return home with empty water jars. They are ashamed and upset. They hide their faces in their hands. They go to the wells, but they do not find any water. They return home with empty water jars. They are ashamed and upset. They hide their faces in their hands."
    },
    {
      "verse": "4",
      "text": "There has been no rain anywhere. The ground is breaking apart. The farmers too are very upset. They hide their faces in their hands. The ground is breaking apart. The farmers too are very upset. They hide their faces in their hands."
    },
    {
      "verse": "5",
      "text": "There is no grass in the fields for the deer to eat. So the mother deer runs away from her new baby. So the mother deer runs away from her new baby."
    },
    {
      "verse": "6",
      "text": "Wild donkeys stand on the empty hills. They breathe very fast, like thirsty jackals. Their eyes hurt as they look for grass, but there is no food for them to eat. ’ They breathe very fast, like thirsty jackals. Their eyes hurt as they look for grass, but there is no food for them to eat. ’"
    },
    {
      "verse": "7",
      "text": "‘Lord, our many sins show that we are guilty. But please help us, to show that you are our God. We have turned away from you many times. We have done bad things against you. But please help us, to show that you are our God. We have turned away from you many times. We have done bad things against you."
    },
    {
      "verse": "8",
      "text": "You are the one that we Israelites hope to give us help. You are the one who saves us when we are in trouble. But now you live among us like a foreigner. You are like a visitor who stays for only one night. You are the one who saves us when we are in trouble. But now you live among us like a foreigner. You are like a visitor who stays for only one night."
    },
    {
      "verse": "9",
      "text": "You seem to be like a helpless person. You are like a brave fighter who has lost his strength to save anyone. But surely you are among us, Lord. We belong to you as your own people. Do not leave us alone! ’ You are like a brave fighter who has lost his strength to save anyone. But surely you are among us, Lord. We belong to you as your own people. Do not leave us alone! ’"
    },
    {
      "verse": "10",
      "text": "The Lord says this about his people:‘These people love to go wherever they want. They do not try to stay near to me. So they do not please me. Now I will remember the wrong things that they have done. I will punish them for their sins. ’ ‘These people love to go wherever they want. They do not try to stay near to me. So they do not please me. Now I will remember the wrong things that they have done. I will punish them for their sins. ’"
    },
    {
      "verse": "11",
      "text": "The Lord said to me, ‘Do not pray that I will do any more good things for these people."
    },
    {
      "verse": "12",
      "text": "Even if they fast, I will not listen when they ask me for help. I will not accept the burnt offerings or grain offerings that they offer to me. Instead, I will use war, famine and disease to destroy them. ’"
    },
    {
      "verse": "13",
      "text": "I said, ‘Lord God, the prophets are deceiving the people. They say that there will not be any war or famine or disease that will hurt the people. Instead, they say that you have promised peace in our land. ’"
    },
    {
      "verse": "14",
      "text": "The Lord said to me, ‘Those prophets say that they speak my messages, but they are telling lies. I did not send them. I did not give them my authority. I did not give them any messages. They are deceiving people with the visions that they talk about. When they prophesy about things, it means nothing. They only speak about their own foolish ideas."
    },
    {
      "verse": "15",
      "text": "They claim to speak with my authority, but I did not send them. They say that there will be no war or famine. So I tell you, this is what will happen to those prophets: War and famine will kill them."
    },
    {
      "verse": "16",
      "text": "And the people that they are speaking their messages to will also die because of war and famine. Their bodies will lie in Jerusalem's streets. Nobody will be there to bury them. This will happen to the men, their wives, their sons and their daughters. I will punish them as they deserve, because they are so wicked."
    },
    {
      "verse": "17",
      "text": "Say this to the people, Jeremiah:“Tears pour from my eyes all the time. I weep through each day and each night. I am sad about my own dear people. A great trouble has knocked them to the ground. They have received a very bad wound. “Tears pour from my eyes all the time. I weep through each day and each night. I am sad about my own dear people. A great trouble has knocked them to the ground. They have received a very bad wound."
    },
    {
      "verse": "18",
      "text": "When I go out into the fields, I see the bodies of people who have died in war. When I look in the city, I see people who are dying from famine. The prophets and the priests are busy with their work. But they do not understand what is happening. ” ’ I see the bodies of people who have died in war. When I look in the city, I see people who are dying from famine. The prophets and the priests are busy with their work. But they do not understand what is happening. ” ’"
    },
    {
      "verse": "19",
      "text": "‘Lord, have you completely turned away from the people of Judah? Do you really hate the people of Zion? You have knocked us downso that we will never get better. We hoped to live in peace, but nothing good happened to us. We hoped to have rest from our troubles, but instead we live in fear. Do you really hate the people of Zion? You have knocked us down so that we will never get better. We hoped to live in peace, but nothing good happened to us. We hoped to have rest from our troubles, but instead we live in fear."
    },
    {
      "verse": "20",
      "text": "Lord, we agree that we are wicked people. Our ancestors also did bad things. We have turned against you. Our ancestors also did bad things. We have turned against you."
    },
    {
      "verse": "21",
      "text": "But please do not refuse to help us. Show that you are a faithful God. Jerusalem is the place where you have your beautiful throne. So do not go away and leave us. Remember the covenant that you made with us. Please do what you promised to do for us. Show that you are a faithful God. Jerusalem is the place where you have your beautiful throne. So do not go away and leave us. Remember the covenant that you made with us. Please do what you promised to do for us."
    },
    {
      "verse": "22",
      "text": "The idols of other nations are useless. None of them can cause rain to fall. And the sky itself does not make rain. No, it is you, Lord, our God, who sends rain. You alone do all these things, so we trust you to help us. ’"
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "The Lord said to me, ‘Even if Moses and Samuel asked me not to punish these people, I would not agree. I still would not help them. Send them away! I do not want to see them again! Those who should become ill and die will die. Those who should die in war will die in war. Those who should die from famine will die from famine. Those who should go away as prisoners will go away as prisoners. ”"
    },
    {
      "verse": "2",
      "text": "They may ask you, “Where should we go? ” Then tell them, “This is what the Lord says: Those who should become ill and die will die. Those who should die in war will die in war. Those who should die from famine will die from famine. Those who should go away as prisoners will go away as prisoners. ”"
    },
    {
      "verse": "3",
      "text": "I will send four kinds of punishments to hurt them. Soldiers will kill them in war. Dogs will carry away their dead bodies. Birds and wild animals will eat them and destroy them."
    },
    {
      "verse": "4",
      "text": "I will cause the people of all nations to think that the people of Judah are disgusting. That will be because of the evil things that the king of Judah, Hezekiah's son, Manasseh, did in Jerusalem. ’"
    },
    {
      "verse": "5",
      "text": "The Lord said, ‘People of Jerusalem, nobody will feel sorry for you. Nobody will weep for you. Nobody will stop to ask how you are. ‘People of Jerusalem, nobody will feel sorry for you. Nobody will weep for you. Nobody will stop to ask how you are."
    },
    {
      "verse": "6",
      "text": "I tell you this: You have turned away from me. You continue to go further away from me. So I will prepare to use my power to destroy you. I can no longer be kind to you. You have turned away from me. You continue to go further away from me. So I will prepare to use my power to destroy you. I can no longer be kind to you."
    },
    {
      "verse": "7",
      "text": "I will punish the people of every town in the land. I will blow them away, like wind blows away straw. My people have refused to change the way that they live. So I will destroy them and their children too. I will blow them away, like wind blows away straw. My people have refused to change the way that they live. So I will destroy them and their children too."
    },
    {
      "verse": "8",
      "text": "There will be more widows in Judah, than there is sand on the shore of the sea. At midday I will send an enemy to destroy the young men. Their mothers will weep for them. It will happen very suddenly. Fear and terror will come! than there is sand on the shore of the sea. At midday I will send an enemy to destroy the young men. Their mothers will weep for them. It will happen very suddenly. Fear and terror will come!"
    },
    {
      "verse": "9",
      "text": "A mother will feel very weak, because all her seven children have died. It is difficult for her even to breathe. She has lost the children that made her happy, while they were still young. She will be ashamed and without honour. I will send your enemies to killany of your people who are still alive. ’That is what the Lord says. because all her seven children have died. It is difficult for her even to breathe. She has lost the children that made her happy, while they were still young. She will be ashamed and without honour. I will send your enemies to kill any of your people who are still alive. ’ That is what the Lord says."
    },
    {
      "verse": "10",
      "text": "‘This is terrible for me! I am sorry, mother, that you gave birth to me. I cause trouble and argumentswherever I go in the land. I never lend money to people, and I do not ask them to lend money to me. But everyone curses me anyway. ’ I am sorry, mother, that you gave birth to me. I cause trouble and arguments wherever I go in the land. I never lend money to people, and I do not ask them to lend money to me. But everyone curses me anyway. ’"
    },
    {
      "verse": "11",
      "text": "The Lord said, ‘I will take care of youso that it brings something good for you. I will cause your enemies to ask you for help. They will come to you when they are in trouble. ‘I will take care of you so that it brings something good for you. I will cause your enemies to ask you for help. They will come to you when they are in trouble."
    },
    {
      "verse": "12",
      "text": "Your enemy that comes from the northis like a weapon made from iron and bronze. You will never break it. is like a weapon made from iron and bronze. You will never break it."
    },
    {
      "verse": "13",
      "text": "I will give all your valuable things to your enemies. They will take them all away. You will receive nothing in return. That will pay for the sins that you have doneeverywhere in your land. They will take them all away. You will receive nothing in return. That will pay for the sins that you have done everywhere in your land."
    },
    {
      "verse": "14",
      "text": "Your enemies will make you their slavesin a land that you do not know. I will punish you as if in a hot fire, because I am very angry with you. ’ in a land that you do not know. I will punish you as if in a hot fire, because I am very angry with you. ’"
    },
    {
      "verse": "15",
      "text": "‘Lord, you understand my problems. Remember me and take care of me. Please punish those people who hate me. Do not be so patient with them that they kill me. Remember that they have insulted mebecause I am serving you. Remember me and take care of me. Please punish those people who hate me. Do not be so patient with them that they kill me. Remember that they have insulted me because I am serving you."
    },
    {
      "verse": "16",
      "text": "As your words came to me, I took them into me like sweet food. I belong to you, Lord, God Almighty, so your words made me very happy. I took them into me like sweet food. I belong to you, Lord, God Almighty, so your words made me very happy."
    },
    {
      "verse": "17",
      "text": "When people were enjoying wild parties, I did not join with them. I sat alone, because you held me. You caused me to be angry with those people. I did not join with them. I sat alone, because you held me. You caused me to be angry with those people."
    },
    {
      "verse": "18",
      "text": "I am in pain which never ends. People have hurt me and nothing makes it better. Why are you not there to help me? You are like a stream that becomes dryand it has no water. ’ People have hurt me and nothing makes it better. Why are you not there to help me? You are like a stream that becomes dry and it has no water. ’"
    },
    {
      "verse": "19",
      "text": "So the Lord said this to me:‘If you turn back to me, I will help you to be strong. Then you can continue to serve me. Speak valuable words instead of useless words. Then you can speak on my behalf. These people must change to be like you have been. You must not change to become like them. ‘If you turn back to me, I will help you to be strong. Then you can continue to serve me. Speak valuable words instead of useless words. Then you can speak on my behalf. These people must change to be like you have been. You must not change to become like them."
    },
    {
      "verse": "20",
      "text": "When these people attack you, I will make you like a strong wall. You will be like a wall that is made of bronze. The people will not be able to knock you down. I will be with you to protect you. I will keep you safe. ’That is what the Lord says. I will make you like a strong wall. You will be like a wall that is made of bronze. The people will not be able to knock you down. I will be with you to protect you. I will keep you safe. ’ That is what the Lord says."
    },
    {
      "verse": "21",
      "text": "‘I will rescue you from the power of those wicked people. I will keep you safe from those cruel people. ’"
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "The Lord said to me,"
    },
    {
      "verse": "2",
      "text": "‘You must not marry in this place. You must not have sons or daughters here."
    },
    {
      "verse": "3",
      "text": "I will tell you what will happen to children who are born here and what will happen to their parents."
    },
    {
      "verse": "4",
      "text": "Terrible disease will kill them. Nobody will weep for them. Nobody will bury them. Their bodies will lie on the ground like dung. Either war or famine will kill them. Birds and wild animals will come to eat their dead bodies. ’"
    },
    {
      "verse": "5",
      "text": "The Lord also said to me, ‘Do not go into a house where they are eating a funeral meal. Do not join with them to weep because someone in the family has died. I have removed my blessing and my faithful love from these people. I will no longer be kind to them. That is what I say."
    },
    {
      "verse": "6",
      "text": "When people die, nobody will bury them, whether they are rich people or poor people. Nobody will weep for them. People will not cut their bodies because they are upset. They will not cut the hair from their heads."
    },
    {
      "verse": "7",
      "text": "Nobody will take food to comfort families when someone has died. Even if their mother or their father has died, nobody will bring any wine to comfort them."
    },
    {
      "verse": "8",
      "text": "Do not join with people who are eating a feast because they are happy. Do not go into their house to eat and drink with them."
    },
    {
      "verse": "9",
      "text": "I, the Lord Almighty, Israel's God, tell you what I will do. I will stop their happy songs and their marriage parties in this place. You will see this happen while you are still alive."
    },
    {
      "verse": "10",
      "text": "Tell the people everything that I have said. Then they will ask you, “Why has the Lord told us that he will punish us so much? What wrong things have we done? What sin have we done against the Lord, our God? ”"
    },
    {
      "verse": "11",
      "text": "Then you must tell them what I say: “It is because your ancestors turned against me. They went to other gods. They worshipped and they served those gods. They turned against me and they did not obey my law."
    },
    {
      "verse": "12",
      "text": "And you have done even more wicked things than your ancestors! You do any wicked thing that you want to do. You refuse to change. You do not obey me."
    },
    {
      "verse": "13",
      "text": "So I will throw you out of this land. I will send you away to a land that you and your ancestors never knew. There you will worship other gods, as much as you like. I will no longer help you. ” ’"
    },
    {
      "verse": "14",
      "text": "The Lord also said, ‘Listen! A better time will come. When people make a promise, they will not say, “I promise to do this as surely as the Lord lives, who brought the Israelites safely out of Egypt. ”"
    },
    {
      "verse": "15",
      "text": "Instead they will say, “I promise to do this as surely as the Lord lives, who brought the Israelites safely back from the land in the north. He brought them back from all the places that he had sent them to as prisoners. ” Yes, at that time I will bring them back to this land that I gave to their ancestors."
    },
    {
      "verse": "16",
      "text": "But now I will send enemies to catch these people. They will catch them like fishermen catch fish. They will chase after them like hunters who catch wild animals. They will find them everywhere in the mountains, in the hills and in holes in the rocks."
    },
    {
      "verse": "17",
      "text": "I am watching them carefully all the time. They cannot hide from me. I can see all their sins."
    },
    {
      "verse": "18",
      "text": "I will punish them for their sins. I will make them pay twice for the wrong things that they have done. That is because they have spoiled my land. They have made it unclean with their disgusting idols that have no life. They have filled my special land with the evil things that they have done. ’"
    },
    {
      "verse": "19",
      "text": "Lord, you give me strength. You are the safe place where I can hide. When I am in trouble, I can run to you and be safe. People will come from nations all over the earth, to give you honour. They will say, ‘Our ancestors worshipped false gods. Those gods were useless and they could not help us. You are the safe place where I can hide. When I am in trouble, I can run to you and be safe. People will come from nations all over the earth, to give you honour. They will say, ‘Our ancestors worshipped false gods. Those gods were useless and they could not help us."
    },
    {
      "verse": "20",
      "text": "Can people make gods for themselves? If they make them, they are not really gods. ’ If they make them, they are not really gods. ’"
    },
    {
      "verse": "21",
      "text": "‘So I, the Lord, will teach these people about my great power. Then they will understand that I am the Lord, the true God. ’"
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "‘The people of Judah love to do bad things. Their sins are deep inside them. It is like they are written on their heartsand on the horns of their altars. They are written with an iron pen. Nobody can remove the list of their sins. Their sins are deep inside them. It is like they are written on their hearts and on the horns of their altars. They are written with an iron pen. Nobody can remove the list of their sins."
    },
    {
      "verse": "2",
      "text": "Even their children always think about their altarswhere they worship false gods. They have put up their Asherah polesunder the big trees and on the high hills. where they worship false gods. They have put up their Asherah poles under the big trees and on the high hills."
    },
    {
      "verse": "3",
      "text": "They also worship their false godson the mountains and in the fields. So I will cause enemies to take all your valuable things. They will take your riches for themselves. That will be the price that you pay for your sins. You have done evil things everywhere in the land. on the mountains and in the fields. So I will cause enemies to take all your valuable things. They will take your riches for themselves. That will be the price that you pay for your sins. You have done evil things everywhere in the land."
    },
    {
      "verse": "4",
      "text": "I gave you this land to be your home for ever. But it will no longer belong to you. Your enemies will take you to a land that you do not know. You will be their slaves. You have made me very angry, like a fire that nobody can stop. ’ But it will no longer belong to you. Your enemies will take you to a land that you do not know. You will be their slaves. You have made me very angry, like a fire that nobody can stop. ’"
    },
    {
      "verse": "5",
      "text": "The Lord says, ‘I will curse those who only trust people to help them. They think that human strength will save them, and they turn away from me, the Lord. ‘I will curse those who only trust people to help them. They think that human strength will save them, and they turn away from me, the Lord."
    },
    {
      "verse": "6",
      "text": "They will be like a bush that grows in the desert. It grows in a place where nobody can live. The ground is very dry and is spoiled by salt. Even when good times come, those people will not receive any good thing. It grows in a place where nobody can live. The ground is very dry and is spoiled by salt. Even when good times come, those people will not receive any good thing."
    },
    {
      "verse": "7",
      "text": "The Lord blesses people who trust in him. They know that the Lord will help them. They know that the Lord will help them."
    },
    {
      "verse": "8",
      "text": "They will be like trees that grow beside a river. Their roots reach into the water. When the sun is hot, they are not afraid. Their leaves continue to be green. They give fruit each year, even when there is no rain. Their roots reach into the water. When the sun is hot, they are not afraid. Their leaves continue to be green. They give fruit each year, even when there is no rain."
    },
    {
      "verse": "9",
      "text": "A person's own mind deceives him, more than anything else does. Nobody can change it to be better. Nobody completely understands it. more than anything else does. Nobody can change it to be better. Nobody completely understands it."
    },
    {
      "verse": "10",
      "text": "But I, the Lord, look inside a person's mind. I see what he thinks and what he feels. I see how everyone lives, and I see the things that they do. I give to each one what he deserves. I see what he thinks and what he feels. I see how everyone lives, and I see the things that they do. I give to each one what he deserves."
    },
    {
      "verse": "11",
      "text": "Someone may get rich because he cheats other people. He is like a bird that sits on eggsthat it has taken from another nest. He will lose his riches before he is old. At the end of his life, he will die as a fool. ’ He is like a bird that sits on eggs that it has taken from another nest. He will lose his riches before he is old. At the end of his life, he will die as a fool. ’"
    },
    {
      "verse": "12",
      "text": "Lord, your beautiful throne is high above. You have ruled there from the beginning. That is where we worship you. You have ruled there from the beginning. That is where we worship you."
    },
    {
      "verse": "13",
      "text": "You are the one that the Israelites hope in. Everyone who turns away from you will be ashamed. They will disappear, as if their names are written in the dust. Lord, you give life to your people, like a spring of fresh water. But they have turned against you. Everyone who turns away from you will be ashamed. They will disappear, as if their names are written in the dust. Lord, you give life to your people, like a spring of fresh water. But they have turned against you."
    },
    {
      "verse": "14",
      "text": "Lord, please make me well again. Then I will be completely well. Rescue me so that I am completely safe. You are the one that I praise! Then I will be completely well. Rescue me so that I am completely safe. You are the one that I praise!"
    },
    {
      "verse": "15",
      "text": "People are asking me questions. They say, ‘Nothing has happened to us yet! When will the Lord's message become true? ’ They say, ‘Nothing has happened to us yet! When will the Lord's message become true? ’"
    },
    {
      "verse": "16",
      "text": "Lord, I have not stopped taking care of your people. I have never asked you to destroy them on one final day. You know that, and you know everything that I have said. I have never asked you to destroy them on one final day. You know that, and you know everything that I have said."
    },
    {
      "verse": "17",
      "text": "Please do not make me afraid! When I am in trouble, I run to you to be safe. When I am in trouble, I run to you to be safe."
    },
    {
      "verse": "18",
      "text": "Please bring shame on those who want to hurt me. Do not make me ashamed. Make those people afraid, but do not make me afraid. Destroy them with a time of great trouble. Punish them completely! Do not make me ashamed. Make those people afraid, but do not make me afraid. Destroy them with a time of great trouble. Punish them completely!"
    },
    {
      "verse": "19",
      "text": "The Lord said to me, ‘Go and stand at the gate of the city that is called “The People's Gate”. That is the gate that the kings of Judah use to go in and out of the city. Then go and stand at the other gates of Jerusalem."
    },
    {
      "verse": "20",
      "text": "Stand in those places and say, “Listen, you kings of Judah, everyone who lives in Jerusalem and all the people of Judah. Hear this message from the Lord."
    },
    {
      "verse": "21",
      "text": "This is what the Lord says: Be careful to obey these rules if you want to continue to live! On a Sabbath day, do not carry any loads in through the gates of Jerusalem."
    },
    {
      "verse": "22",
      "text": "Do not carry any loads out of your houses. Do not do any work on a Sabbath day. You must keep the Sabbath day as a special day for me. That is what I commanded your ancestors to do."
    },
    {
      "verse": "23",
      "text": "But they did not listen to me and they did not obey me. They refused to accept the rules that I gave to them. When I warned them, they would not change. ”"
    },
    {
      "verse": "24",
      "text": "The Lord says, “But you must be careful to obey me. Do not carry any loads through the gates of this city on a Sabbath day. You must keep the Sabbath day as a special day for me. Do not do any work on a Sabbath day."
    },
    {
      "verse": "25",
      "text": "If you obey me, kings from David's family will continue to rule. Kings and their officers will pass through these gates, together with the people of Jerusalem and all Judah. They will ride on horses and in chariots. Many people will always live in this city."
    },
    {
      "verse": "26",
      "text": "People will come here from everywhere in Judah. They will bring offerings to the Lord's temple. They will come from Judah's towns and from the villages around Jerusalem. They will come from the land that belongs to Benjamin's tribe. They will come from the low hills in the west and from the hill country and the wilderness in the south. They will bring burnt offerings, grain offerings, other sacrifices and incense. They will offer sacrifices to the Lord to thank him."
    },
    {
      "verse": "27",
      "text": "But you must remember to obey me. You must keep the Sabbath day as a special day for me. You must not carry any loads in through Jerusalem's gates on a Sabbath day. If you do not obey this rule, I will burn Jerusalem's gates with fire. The fire will destroy all the strong buildings in Jerusalem. Nobody will be able to stop that fire. ” ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "The Lord gave this message to Jeremiah:"
    },
    {
      "verse": "2",
      "text": "‘Go down to the potter's house. I will tell you my message there. ’"
    },
    {
      "verse": "3",
      "text": "So I went down to the potter's house. He was working at his wheel."
    },
    {
      "verse": "4",
      "text": "He was using clay to make pots with his hands. But, as he worked, sometimes a pot had the wrong shape. So he used the clay to make it into another pot. He made it in the shape that he wanted."
    },
    {
      "verse": "5",
      "text": "Then the Lord told me his message."
    },
    {
      "verse": "6",
      "text": "He said, ‘I tell you this: I can do to you, nation of Israel, the same thing that this potter does with his clay. I hold you in my hands, as the potter holds the clay in his hands."
    },
    {
      "verse": "7",
      "text": "Sometimes I may warn a nation or a kingdom that I will knock it down and destroy it."
    },
    {
      "verse": "8",
      "text": "But when I warn them, those people might stop doing wicked things. Then I would not punish them as I had promised to do."
    },
    {
      "verse": "9",
      "text": "Sometimes I may promise to build up a nation or a kingdom and make it strong."
    },
    {
      "verse": "10",
      "text": "But those people might start to do evil things. They might stop obeying me. Then I would not help them as I had promised to do."
    },
    {
      "verse": "11",
      "text": "So now you must speak to the people who live in Jerusalem and in all of Judah. Tell them that the Lord says this: “Listen to me! I will cause great trouble for you. I have decided to punish you. So you must all stop doing the evil things that you have been doing. Change the way that you live and do things that are right. ”"
    },
    {
      "verse": "12",
      "text": "But they will say, “Do not try to stop us! We will do whatever we want to do. We will continue to do wicked things. ” ’"
    },
    {
      "verse": "13",
      "text": "So the Lord says this:‘Go and ask the people of other nations! Have they ever heard about anything as terrible as this? My people, Israel, should have been pure. But they have done a disgusting thing! ‘Go and ask the people of other nations! Have they ever heard about anything as terrible as this? My people, Israel, should have been pure. But they have done a disgusting thing!"
    },
    {
      "verse": "14",
      "text": "There is always snow on Lebanon's mountains. Cold streams of water always pour down from those high rocks. Cold streams of water always pour down from those high rocks."
    },
    {
      "verse": "15",
      "text": "Those things never change, but my people have forgotten me. They offer sacrifices to useless idols. Because of that, they live in a wrong way. They have left the good paths that their ancestors knew. Instead, they walk along narrow pathsthat nobody takes care of. but my people have forgotten me. They offer sacrifices to useless idols. Because of that, they live in a wrong way. They have left the good paths that their ancestors knew. Instead, they walk along narrow paths that nobody takes care of."
    },
    {
      "verse": "16",
      "text": "So I will cause their land to become a terrible place. People will always see how disgusting my people are. Everybody who goes near therewill be very surprised. They will shake their heads and they will insult my people. People will always see how disgusting my people are. Everybody who goes near there will be very surprised. They will shake their heads and they will insult my people."
    },
    {
      "verse": "17",
      "text": "I will send enemies to attack them. They will chase my people away, like an east wind that blows away dust. I will turn away from themwhen that day of great trouble arrives. I will refuse to help them. ’ They will chase my people away, like an east wind that blows away dust. I will turn away from them when that day of great trouble arrives. I will refuse to help them. ’"
    },
    {
      "verse": "18",
      "text": "Then some people said, ‘We must find a way to stop Jeremiah. We do not need him. The priests will still be here to teach us. Wise men will still be here to give us advice. The prophets will still be here to give us God's messages. We should speak bad things against Jeremiah. Then we will not have to listen to him any more. ’"
    },
    {
      "verse": "19",
      "text": "‘Please listen to me, Lord! Hear what my enemies are saying against me. Hear what my enemies are saying against me."
    },
    {
      "verse": "20",
      "text": "I have done good things for them, but they are paying me back with evil things. They have already dug a grave for me! Remember that I stood in front of youand I asked you to forgive them. I asked you not to be angry with them. but they are paying me back with evil things. They have already dug a grave for me! Remember that I stood in front of you and I asked you to forgive them. I asked you not to be angry with them."
    },
    {
      "verse": "21",
      "text": "So now I ask you to punish them! Yes, may famine kill their children. May they die in war. May wives no longer have husbands or children. May disease kill the old men. May the young men die in battle. Yes, may famine kill their children. May they die in war. May wives no longer have husbands or children. May disease kill the old men. May the young men die in battle."
    },
    {
      "verse": "22",
      "text": "Send people to attack them suddenlyand rob them in their homes. Then they will shout aloud in great fear. They have dug a hole for me to fall into. They have prepared traps to catch me. and rob them in their homes. Then they will shout aloud in great fear. They have dug a hole for me to fall into. They have prepared traps to catch me."
    },
    {
      "verse": "23",
      "text": "But Lord, you know how they want to kill me. They are guilty, so do not forgive them. Do not forget to punish them for their sins. Put them under your power! Punish them while you are still angry! ’"
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "The Lord said to me, ‘Go to a potter. Buy from him a pot that he has made from clay. Take with you some leaders of the people and some leaders of the priests."
    },
    {
      "verse": "2",
      "text": "Go out into Ben-Hinnom Valley, which is near to the “Broken Pots” gate. There you must speak the words that I will tell you."
    },
    {
      "verse": "3",
      "text": "Say, “Hear the Lord's message, you kings of Judah and people who live in Jerusalem. The Lord Almighty, Israel's God says this: Listen to me! I will bring very great trouble to this place. It will be very bad. Everyone who hears about it will be very surprised."
    },
    {
      "verse": "4",
      "text": "That will happen because Judah's people have turned away from me. They worship foreign gods in this place. They have offered sacrifices to those gods. They are gods that their ancestors did not know about. The kings of Judah never knew about them either. In this place, Judah's people have killed people who did not deserve to die."
    },
    {
      "verse": "5",
      "text": "They have built altars here to give honour to Baal. They light fires to give their children to Baal as burnt offerings. I never even thought about it. I never commanded my people to offer those kinds of sacrifices. I never even thought about it."
    },
    {
      "verse": "6",
      "text": "So I tell you this: A time will soon come when people do not call this place Topheth or Ben-Hinnom Valley. Instead, they will call it Death Valley."
    },
    {
      "verse": "7",
      "text": "I will spoil all the ideas that the people of Judah and Jerusalem have. In this place I will put them under the power of their enemies. Their enemies will kill them in war. I will give their dead bodies as food to the birds and the wild animals."
    },
    {
      "verse": "8",
      "text": "I will make this city a heap of stones. People will see how disgusting my people are. Everybody who goes near there will be very surprised. They will see all the terrible trouble that has happened to the city and they will insult it."
    },
    {
      "verse": "9",
      "text": "Enemies will make their camp all around the city, so that they can kill the people who live there. The people will not have any food to eat. They will be so hungry that they will eat their own children and they will eat each other. ”"
    },
    {
      "verse": "10",
      "text": "Then, Jeremiah, take the pot that you bought. Break it in front of all those people who are there with you."
    },
    {
      "verse": "11",
      "text": "Tell them that the Lord Almighty says, “I will destroy this nation and this city. They will be like this broken pot that nobody is able to mend. They will bury lots of dead people here in Topheth. There will be no space left to bury any more people."
    },
    {
      "verse": "12",
      "text": "I tell you this: I will cause this city and its people to become like Topheth."
    },
    {
      "verse": "13",
      "text": "The houses in Jerusalem will be full of dead bodies like Topheth. The palaces of the kings of Judah will be the same. I will do that because people went up on the roofs of their houses to offer sacrifices to the stars. They poured out drink offerings to other gods. ” ’"
    },
    {
      "verse": "14",
      "text": "Then Jeremiah left Topheth, where the Lord had sent him to speak his message. He went to the Lord's temple in the city. He stood in the yard of the temple. He spoke aloud to the people."
    },
    {
      "verse": "15",
      "text": "He said, ‘The Lord Almighty, Israel's God, says this: “Listen to me! I will soon punish this city and all the towns around it, as I have promised that I will do. I will do it because the people have refused to listen to my message. ” ’"
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "Immer's son Pashhur was the priest who had authority in the Lord's temple. He heard Jeremiah's message about Jerusalem."
    },
    {
      "verse": "2",
      "text": "So he told his men to beat Jeremiah. Then they tied Jeremiah up with heavy pieces of wood on his legs. That was at the Benjamin Gate of the Lord's temple."
    },
    {
      "verse": "3",
      "text": "The next day, Pashhur let Jeremiah go free. Jeremiah said to him, ‘The Lord's name for you is not “Pashhur”. It is “Terror is all around”."
    },
    {
      "verse": "4",
      "text": "The Lord says, “I will send enemies to make you and your friends very afraid. You yourself will see enemies kill all your friends in war. I will put Judah's people under the power of Babylon's king. He will take some of them away as prisoners. His soldiers will kill others of them."
    },
    {
      "verse": "5",
      "text": "I will give all the riches in this city to Judah's enemies. I will give them all the things that the people have worked hard to get. They will take all the valuable things that belonged to the people, and to the kings of Judah. They will take everything away to Babylon."
    },
    {
      "verse": "6",
      "text": "They will also take you, Pashhur, and everybody who lives in your house. They will take you as prisoners to Babylon. You will die there and people will bury you there. The same thing will happen to all your friends. You spoke false messages to these people, as if they were messages from me. ” ’"
    },
    {
      "verse": "7",
      "text": "Lord, you forced me to become a prophet, and I let you do that. You used your power to make me agree, and you won. Now everybody laughs at me and they insult me. and I let you do that. You used your power to make me agree, and you won. Now everybody laughs at me and they insult me."
    },
    {
      "verse": "8",
      "text": "When I speak your message, I have to say, ‘Terrible trouble is coming! ’When I shout that message from the Lord, people laugh at me. They insult me. ‘Terrible trouble is coming! ’ When I shout that message from the Lord, people laugh at me. They insult me."
    },
    {
      "verse": "9",
      "text": "Sometimes I think, ‘I will say nothing about the Lord or his message. ’But then his message burns like a fire inside me. It gives me pain in my mind and my body. I cannot keep his message to myself. I have to speak it. ‘I will say nothing about the Lord or his message. ’ But then his message burns like a fire inside me. It gives me pain in my mind and my body. I cannot keep his message to myself. I have to speak it."
    },
    {
      "verse": "10",
      "text": "I hear what people are saying against me. They say, ‘Terror is all around him! We should tell the officers what he is saying. ’All my friends want me to make a mistakeso that they can accuse me. They say, ‘Perhaps we can cause him to say something wrong. Then we will have power over him. We will pay him back for the trouble he has given us. ’ They say, ‘Terror is all around him! We should tell the officers what he is saying. ’ All my friends want me to make a mistake so that they can accuse me. They say, ‘Perhaps we can cause him to say something wrong. Then we will have power over him. We will pay him back for the trouble he has given us. ’"
    },
    {
      "verse": "11",
      "text": "But the Lord is with me, like a brave soldier who will fight for me. So people who want to hurt me will fail. They will not get power over me. They will be very ashamed because they have failed. Nobody will ever forget their shame. like a brave soldier who will fight for me. So people who want to hurt me will fail. They will not get power over me. They will be very ashamed because they have failed. Nobody will ever forget their shame."
    },
    {
      "verse": "12",
      "text": "Lord Almighty, you test righteous people, to see if they are faithful. You know what people think. You know their feelings. I trust you to show that I am not guilty. So punish those people who want to hurt me. to see if they are faithful. You know what people think. You know their feelings. I trust you to show that I am not guilty. So punish those people who want to hurt me."
    },
    {
      "verse": "13",
      "text": "Sing to the Lord! Praise the Lord! He rescues poor peoplefrom the power of wicked people. Praise the Lord! He rescues poor people from the power of wicked people."
    },
    {
      "verse": "14",
      "text": "I would like to curse the day that I was born. That day was not a happy day, the day that my mother gave birth to me. That day was not a happy day, the day that my mother gave birth to me."
    },
    {
      "verse": "15",
      "text": "That day, a man told my father, ‘Good news! You have a son! ’I would like to curse that man too. ‘Good news! You have a son! ’ I would like to curse that man too."
    },
    {
      "verse": "16",
      "text": "May the Lord destroy that man, as he completely destroyed those cities long ago. I want that man to hear people who are weeping in the morning. I want him to hear the noise of battles at noon. as he completely destroyed those cities long ago. I want that man to hear people who are weeping in the morning. I want him to hear the noise of battles at noon."
    },
    {
      "verse": "17",
      "text": "He should have killed me before I was born. I should have died inside my mother. She would have held me inside her. That would have been my grave for ever. I should have died inside my mother. She would have held me inside her. That would have been my grave for ever."
    },
    {
      "verse": "18",
      "text": "I should have stayed in that safe place. In my life, I only receive trouble and pain. When I die, all I will have is shame."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "The Lord gave another message to Jeremiah. King Zedekiah sent Malkijah's son Pashhur, to speak to Jeremiah. He also sent the priest Zephaniah, Maaseiah's son. They went to say to Jeremiah,"
    },
    {
      "verse": "2",
      "text": "‘Nebuchadnezzar, King of Babylon, is attacking us. Please ask the Lord to help us. Perhaps he will do a powerful miracle as he has done for us in the past. Perhaps he will cause Nebuchadnezzar to go away and leave us alone. ’"
    },
    {
      "verse": "3",
      "text": "Jeremiah answered them, ‘Tell Zedekiah that the Lord, Israel's God, says this:"
    },
    {
      "verse": "4",
      "text": "“Your soldiers have gone outside the city to fight against the king of Babylon and his soldiers. But I will make the weapons of your soldiers useless. You will have to bring them all back into the city."
    },
    {
      "verse": "5",
      "text": "I myself will use my great power and strength to fight against you. I will do that because I am very angry with you."
    },
    {
      "verse": "6",
      "text": "I will attack everything that lives in this city, both people and animals. A very bad disease will kill them. ”"
    },
    {
      "verse": "7",
      "text": "The Lord also says this: “Then I will put King Zedekiah of Judah under the power of Nebuchadnezzar, king of Babylon. I will do the same thing to any of his officers or people who are still alive. Those are the people that war, famine or disease has not already killed. I will give them to King Nebuchadnezzar and to their enemies who want to kill them. He will tell his soldiers to kill them. He will not be kind to them and he will kill them all. ”"
    },
    {
      "verse": "8",
      "text": "But also tell the people that the Lord says this: “I will let you choose between two things. One is a way that will give you life. The other is a way that will give you death."
    },
    {
      "verse": "9",
      "text": "Anyone who stays in the city will die. War or famine or disease will kill them. But you may choose to leave the city. You may put yourselves under the power of Babylon's army that is attacking the city. Anyone who does that will continue to live."
    },
    {
      "verse": "10",
      "text": "I, the Lord, tell you this: I have decided not to rescue this city. Instead I will destroy it. I will give it to the king of Babylon. He will destroy it with fire. ” ’"
    },
    {
      "verse": "11",
      "text": "This is the Lord's message to the king of Judah, to his family and his officers:"
    },
    {
      "verse": "12",
      "text": "‘Descendants of King David, the Lord says this to you: Every day you must be fair as you judge people. Punish those who rob other people. Punish those who are cruel to other people. Help the people that they have hurt. If you do not do judge in a fair way, I will be very angry. My anger will burn like a hot firethat nobody can stop. It will destroy youbecause of the evil things that you have done. ’The Lord says: Every day you must be fair as you judge people. Punish those who rob other people. Punish those who are cruel to other people. Help the people that they have hurt. If you do not do judge in a fair way, I will be very angry. My anger will burn like a hot fire that nobody can stop. It will destroy you because of the evil things that you have done. ’ The Lord says:"
    },
    {
      "verse": "13",
      "text": "‘I have turned against you, Jerusalem's palace. Kings sit there on their thrones, on a high rock above the valley. You say, “We are safe here in our strong building. No enemy can get in here to attack us. ” Kings sit there on their thrones, on a high rock above the valley. You say, “We are safe here in our strong building. No enemy can get in here to attack us. ”"
    },
    {
      "verse": "14",
      "text": "But I will punish you for everything that you have done. I will destroy your palace with fire. That fire will destroy everything that is around you. ’That is what the Lord says."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "The Lord said to me, ‘Go down to the palace of the king of Judah. You must say to him,"
    },
    {
      "verse": "2",
      "text": "“King of Judah, descendant of King David, listen to this message from the Lord. Your officers and the people of your palace must listen too."
    },
    {
      "verse": "3",
      "text": "The Lord says: You must do things that are right and fair. Punish those who rob other people. Help the people that they have hurt. Do not be cruel to foreigners who are living among you. Do not cheat them. Do not hurt or cheat widows, or children who have no family. Stop killing people who have not done anything wrong."
    },
    {
      "verse": "4",
      "text": "If you are careful to obey these commands, David's descendants will continue to rule as kings in this city. They will ride on horses and on chariots to come in through the city's gates. Their officers and their people will come with them."
    },
    {
      "verse": "5",
      "text": "But if you do not obey these commands, I will destroy this palace. I promise you that it will become a heap of stones! That is what I, the Lord, tell you. ” ’"
    },
    {
      "verse": "6",
      "text": "The Lord says this about the palace of the king of Judah:‘This place is as beautiful as Gilead! It is as beautiful as Lebanon's mountains. But I will cause it to become a wilderness, a place where nobody lives any more. ‘This place is as beautiful as Gilead! It is as beautiful as Lebanon's mountains. But I will cause it to become a wilderness, a place where nobody lives any more."
    },
    {
      "verse": "7",
      "text": "I will send enemies to destroy this place. They will use their weapons to knock it all down. They will cut down the strong beams of cedar wood. They will throw them into the fire. They will use their weapons to knock it all down. They will cut down the strong beams of cedar wood. They will throw them into the fire."
    },
    {
      "verse": "8",
      "text": "People from many nations will see what has happened here. They will ask each other, “Why has the Lord destroyed this great city? ”"
    },
    {
      "verse": "9",
      "text": "Other people will answer, “He did it because they refused to obey their covenant with the Lord their God. They worshipped other gods instead of him. ” ’"
    },
    {
      "verse": "10",
      "text": "Do not weep because the king is dead. Do not be sad that he no longer lives. Instead, weep for the king that has gone away. He will never return to see his own land again. Do not be sad that he no longer lives. Instead, weep for the king that has gone away. He will never return to see his own land again."
    },
    {
      "verse": "11",
      "text": "Josiah's son, Shallum, became king of Judah after his father died. But enemies took him away as a prisoner to a foreign land. The Lord says this about him: ‘He will never return to this land."
    },
    {
      "verse": "12",
      "text": "He will die in the foreign land where they took him as prisoner. He will not see this land again. ’"
    },
    {
      "verse": "13",
      "text": "The Lord says, ‘Terrible trouble will happen to this man! He cheats peopleso that he can build a beautiful palace for himself. He does not do what is right and fair. He does not pay the people who work for him. His own men have to work for nothing. ‘Terrible trouble will happen to this man! He cheats people so that he can build a beautiful palace for himself. He does not do what is right and fair. He does not pay the people who work for him. His own men have to work for nothing."
    },
    {
      "verse": "14",
      "text": "He says, “I will build a great palace for myself. It will have large rooms upstairs. ”He puts windows in its walls. He covers the walls with cedar wood. He uses red paint to make it beautiful. It will have large rooms upstairs. ” He puts windows in its walls. He covers the walls with cedar wood. He uses red paint to make it beautiful."
    },
    {
      "verse": "15",
      "text": "Are you better than other kingsbecause you use more cedar wood to build your palace? Think about how your father lived. He did what was right and fair. He had enough to eat and to drink. So he was happy with a good life. because you use more cedar wood to build your palace? Think about how your father lived. He did what was right and fair. He had enough to eat and to drink. So he was happy with a good life."
    },
    {
      "verse": "16",
      "text": "He did what was rightfor people who were poor and helpless. So people were happy. That is how people who know me should live. ’That is what the Lord says. for people who were poor and helpless. So people were happy. That is how people who know me should live. ’ That is what the Lord says."
    },
    {
      "verse": "17",
      "text": "‘But you always want to cheat people, so that you can get more riches for yourself. You make plans to kill people who have not done anything wrong. You hurt people in cruel ways. ’ so that you can get more riches for yourself. You make plans to kill people who have not done anything wrong. You hurt people in cruel ways. ’"
    },
    {
      "verse": "18",
      "text": "So the Lord says this about Josiah's son, King Jehoiakim of Judah:‘People will not weep when he dies. They will not say, “I am very sad, my brother. I am very sad, my sister. ”They will not weep and say, “What a terrible thing has happened! Our great king has died! ” ‘People will not weep when he dies. They will not say, “I am very sad, my brother. I am very sad, my sister. ” They will not weep and say, “What a terrible thing has happened! Our great king has died! ”"
    },
    {
      "verse": "19",
      "text": "Instead, they will bury him like a dead donkey. They will pull his dead body to the city's gate. They will throw it on the ground outside Jerusalem. ’ They will pull his dead body to the city's gate. They will throw it on the ground outside Jerusalem. ’"
    },
    {
      "verse": "20",
      "text": "‘Go up to Lebanon and cry aloud. Shout loudly in Bashan. Cry aloud from the mountains of Moab. The nations that were your lovershave lost their power. Shout loudly in Bashan. Cry aloud from the mountains of Moab. The nations that were your lovers have lost their power."
    },
    {
      "verse": "21",
      "text": "When you were feeling strong and safe, I warned you that this would happen. But you said, “I refuse to listen to you. ”You have been like that since you were young. You have never obeyed me. I warned you that this would happen. But you said, “I refuse to listen to you. ” You have been like that since you were young. You have never obeyed me."
    },
    {
      "verse": "22",
      "text": "Your leaders will all disappear, as if a strong wind had blown them away. Enemies will take your friends away as prisoners. Then you will feel very ashamed, because of all the wicked things that you have done. as if a strong wind had blown them away. Enemies will take your friends away as prisoners. Then you will feel very ashamed, because of all the wicked things that you have done."
    },
    {
      "verse": "23",
      "text": "You live safely in beautiful housesthat are made from Lebanon's cedar wood. But when I punish you, you will cry out with pain. You will feel pain like a woman who is having a baby. ’ that are made from Lebanon's cedar wood. But when I punish you, you will cry out with pain. You will feel pain like a woman who is having a baby. ’"
    },
    {
      "verse": "24",
      "text": "This is what the Lord says: ‘Jeconiah, king of Judah, son of Jehoiakim, I promise you this, as surely as I live. I will remove your power as king. If you were the special ring of authority on my right hand, I would pull you off!"
    },
    {
      "verse": "25",
      "text": "You are afraid of your enemies who want to kill you, King Nebuchadnezzar of Babylon and his army. Now I will let them catch you."
    },
    {
      "verse": "26",
      "text": "I will throw you and your mother out of Judah. I will send you both to a foreign land. You were not born in that land, but you will both die there."
    },
    {
      "verse": "27",
      "text": "You will want to return to this land of Judah, but you will never come back here. ’"
    },
    {
      "verse": "28",
      "text": "This man Jeconiah will be like a broken pot. It is a clay pot that nobody wants any more. He and his children will go as prisoners to a foreign country. They will live in a country that they do not know. Why will that happen to them? It is a clay pot that nobody wants any more. He and his children will go as prisoners to a foreign country. They will live in a country that they do not know. Why will that happen to them?"
    },
    {
      "verse": "29",
      "text": "Listen, people of this land! Listen, people of Judah! Listen to the Lord's message! Listen to the Lord's message!"
    },
    {
      "verse": "30",
      "text": "The Lord says, ‘Write this man's name on the list. Write it as the name of a man who has no children. He will not have success in his life. None of his sons will rule as a descendant of King David. None of them will be king of Judah. ’"
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "The Lord says, ‘Terrible trouble will come to the rulers of my people. They should have taken care of my people, as shepherds take care of their sheep. Instead, they have caused them to run away. ’"
    },
    {
      "verse": "2",
      "text": "So the Lord, Israel's God, says to the leaders who rule over his people, ‘You have not taken care of my people. You have chased them away to other places. So now I will come and punish you, because of the evil things that you have done. I, the Lord, tell you that!"
    },
    {
      "verse": "3",
      "text": "I myself will bring back together all my people who are still alive. I will fetch them from the countries where I have sent them. I will bring them back to the land that is their home. They will give birth to many children and they will grow in number."
    },
    {
      "verse": "4",
      "text": "I will choose rulers for them who will truly take care of them. My people will no longer be afraid. They will all be safe. ’ That is what the Lord says."
    },
    {
      "verse": "5",
      "text": "The Lord says, ‘The time will come when I do this: I will cause a descendant of David to be born. He will be righteous. He will grow like a branch on the tree of David's family. He will rule as king in a wise way. He will do what is right and fair in the land. I will cause a descendant of David to be born. He will be righteous. He will grow like a branch on the tree of David's family. He will rule as king in a wise way. He will do what is right and fair in the land."
    },
    {
      "verse": "6",
      "text": "While he rules, the people of Judah will be safe. And Israel's people will live in peace. People will give this name to him:“The Lord is our righteous Saviour. ” ’ And Israel's people will live in peace. People will give this name to him: “The Lord is our righteous Saviour. ” ’"
    },
    {
      "verse": "7",
      "text": "The Lord says, ‘Yes, a new time will come. When people make a promise, they will not say, “I promise to do this as surely as the Lord lives, who brought the Israelites safely out of Egypt. ”"
    },
    {
      "verse": "8",
      "text": "Instead they will say, “I promise to do this as surely as the Lord lives, who brought the descendants of Israel safely back from the land in the north. He brought them back from all the places where he had sent them as prisoners. ” At that time they will live in their own land. ’"
    },
    {
      "verse": "9",
      "text": "I am very upset about what the prophets are doing. My body is shaking. I move like a man who has become drunk, someone who has drunk too much wine. I am afraid because of the Lordand the holy message that he has spoken. My body is shaking. I move like a man who has become drunk, someone who has drunk too much wine. I am afraid because of the Lord and the holy message that he has spoken."
    },
    {
      "verse": "10",
      "text": "The land is full of people who are not faithful to God. The prophets live wicked lives. They use their power in a bad way. Because of that, God has cursed the land. The land is as dry as a desert, and the fields have no grass. The prophets live wicked lives. They use their power in a bad way. Because of that, God has cursed the land. The land is as dry as a desert, and the fields have no grass."
    },
    {
      "verse": "11",
      "text": "The Lord says, ‘The prophets and the priests are all wicked. I see the evil things that they do, even in my temple. ‘The prophets and the priests are all wicked. I see the evil things that they do, even in my temple."
    },
    {
      "verse": "12",
      "text": "Because of that, the paths that they travel on will be dark. They will easily slip and fall to the ground. I will cause terrible trouble to happen to them. I will decide the time when I will punish them. ’That is what the Lord says. They will easily slip and fall to the ground. I will cause terrible trouble to happen to them. I will decide the time when I will punish them. ’ That is what the Lord says."
    },
    {
      "verse": "13",
      "text": "‘I saw the disgusting thing that the prophets in Samaria did. They used the name of Baal to prophesy. Their messages deceived my people, Israel. They used the name of Baal to prophesy. Their messages deceived my people, Israel."
    },
    {
      "verse": "14",
      "text": "But now some prophets in Jerusalem do even worse things! They are not faithful to their wives. They always deceive people. They encourage people to do evil things. They do not try to stop them. They are as bad as the people of Sodom long ago. The people of Jerusalem are as bad as the people of Gomorrah. They are not faithful to their wives. They always deceive people. They encourage people to do evil things. They do not try to stop them. They are as bad as the people of Sodom long ago. The people of Jerusalem are as bad as the people of Gomorrah."
    },
    {
      "verse": "15",
      "text": "So I, the Lord Almighty, say this about these prophets: I will cause them to have much pain and trouble. They will eat bitter food. They will drink water that is poison. It is because of Jerusalem's prophetsthat people do wicked things everywhere in the land. ’ say this about these prophets: I will cause them to have much pain and trouble. They will eat bitter food. They will drink water that is poison. It is because of Jerusalem's prophets that people do wicked things everywhere in the land. ’"
    },
    {
      "verse": "16",
      "text": "The Lord Almighty says to the people, ‘Do not listen to the messages that the prophets are telling you. They are only deceiving you. They speak about visions that are their own ideas. They do not speak a message that comes from the Lord himself. ‘Do not listen to the messages that the prophets are telling you. They are only deceiving you. They speak about visions that are their own ideas. They do not speak a message that comes from the Lord himself."
    },
    {
      "verse": "17",
      "text": "When people refuse to listen to me, the prophets still encourage them. They say to them, “The Lord will give you peace. ”When people refuse to change their wicked way of life, the prophets tell them, “Nothing bad will happen to you. ” the prophets still encourage them. They say to them, “The Lord will give you peace. ” When people refuse to change their wicked way of life, the prophets tell them, “Nothing bad will happen to you. ”"
    },
    {
      "verse": "18",
      "text": "But none of those prophets has met with the Lord. They have not seen himand they have not heard his voice. So none of them has ever listened to himto know what he is saying. They have not seen him and they have not heard his voice. So none of them has ever listened to him to know what he is saying."
    },
    {
      "verse": "19",
      "text": "But look! The Lord's anger will comelike a strong storm. It will blow away the heads of those wicked people. like a strong storm. It will blow away the heads of those wicked people."
    },
    {
      "verse": "20",
      "text": "The Lord will not stop being angry, until he has finished what he has decided to do. When the time comes, you will understand this clearly. until he has finished what he has decided to do. When the time comes, you will understand this clearly."
    },
    {
      "verse": "21",
      "text": "I did not send those prophets. But they have still run to speak to you. I did not tell them what to say, but they have continued to prophesy. But they have still run to speak to you. I did not tell them what to say, but they have continued to prophesy."
    },
    {
      "verse": "22",
      "text": "If they had really met with me, they would have spoken my message to my people. They would have caused my people to turn away from their wicked way of life. They would have stopped my people doing evil things. ’ they would have spoken my message to my people. They would have caused my people to turn away from their wicked way of life. They would have stopped my people doing evil things. ’"
    },
    {
      "verse": "23",
      "text": "The Lord says, ‘Am I a God in only one place? No! I see everything everywhere! No! I see everything everywhere!"
    },
    {
      "verse": "24",
      "text": "Do you think you can hidein a place where I cannot see you? You should know that I am everywhere, in the heavens above and on the earth. ’That is what the Lord says. in a place where I cannot see you? You should know that I am everywhere, in the heavens above and on the earth. ’ That is what the Lord says."
    },
    {
      "verse": "25",
      "text": "‘I have heard the lies that these prophets are saying. They say that they have messages from me. They say, “God has spoken to me in a dream! ”"
    },
    {
      "verse": "26",
      "text": "But all their words are lies. Their messages are their own ideas. When will they stop deceiving people?"
    },
    {
      "verse": "27",
      "text": "They want to make my people forget who I am. They use their dreams to do this. They tell them to each other. They are as bad as their ancestors. They also forgot who I am when they worshipped the false god, Baal."
    },
    {
      "verse": "28",
      "text": "If a prophet has a dream, he should say what it is. If a prophet receives a message from me, he should speak that message faithfully. But dreams are very different from my messages. Straw is not the same as wheat!"
    },
    {
      "verse": "29",
      "text": "A message from me is like a fire that burns things. It is like a hammer that breaks a rock into pieces. ’ That is what the Lord says."
    },
    {
      "verse": "30",
      "text": "‘I tell you that I am against those prophets! They say that they speak messages from me. But they are using each other's ideas."
    },
    {
      "verse": "31",
      "text": "They say, “This message is from the Lord, ” but it is their own words that they speak."
    },
    {
      "verse": "32",
      "text": "Yes, I am against those who have dreams and use them to deceive people. They are using cruel lies to lead the people away from me. I did not send those prophets to speak on my behalf. They do nothing to help my people. ’ That is what the Lord says."
    },
    {
      "verse": "33",
      "text": "The Lord said, ‘Jeremiah, someone may ask you a question. He may be one of these people or a prophet or a priest. He may ask you, “What message of trouble is the Lord telling us now? ” Then you must say to him, “You are the trouble! The Lord says that he will go away from you. ”"
    },
    {
      "verse": "34",
      "text": "If a prophet, a priest, or anyone else says, “I have a message of trouble from the Lord, ” I will punish that person. I will punish his whole family too."
    },
    {
      "verse": "35",
      "text": "Instead, each of you should ask your friends, “What is the Lord's answer? ” or “What has the Lord said? ”"
    },
    {
      "verse": "36",
      "text": "But you must not speak any more about “a message of trouble from the Lord”. It is the person's own message that brings the trouble. In that way, you change the true message of our God, the living God who is the Lord Almighty."
    },
    {
      "verse": "37",
      "text": "You should ask the prophet, “What answer did the Lord give to you? ” or “What did the Lord say? ”"
    },
    {
      "verse": "38",
      "text": "You must no longer say, “What is the message of trouble from the Lord? ” If you continue to say that when I have told you not to say it, this is what will happen:"
    },
    {
      "verse": "39",
      "text": "I will pick you up and I will throw you away! I will send you all a long way away from me. I will chase out all the people of this city that I gave to you and to your ancestors."
    },
    {
      "verse": "40",
      "text": "I will make you very ashamed. People will never forget your great shame. ’"
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "King Nebuchadnezzar of Babylon took Jeconiah away as his prisoner. Jeconiah was the son of Jehoiakim, king of Judah. Nebuchadnezzar also took all Jeconiah's officers and the workers in Judah who had special skills. He took them all away from Jerusalem to Babylon as his prisoners. After that happened, the Lord showed me a vision. I saw two baskets of figs. Somebody had put them in front of the Lord's temple."
    },
    {
      "verse": "2",
      "text": "One basket had very good figs, like those that are ready to eat early in the year. The other basket had very bad figs. They were too bad to eat."
    },
    {
      "verse": "3",
      "text": "Then the Lord asked me, ‘What do you see, Jeremiah? ’I answered, ‘Figs. The good figs are very good. But the bad figs are so bad that nobody can eat them. ’ I answered, ‘Figs. The good figs are very good. But the bad figs are so bad that nobody can eat them. ’"
    },
    {
      "verse": "4",
      "text": "Then the Lord gave me this message:"
    },
    {
      "verse": "5",
      "text": "‘The Lord, Israel's God, says, “The people that I sent away from Judah to Babylon as prisoners are like the good figs. I see them as good."
    },
    {
      "verse": "6",
      "text": "I will watch them carefully and I will take care of them. I will bring them back to this land. I will build them up and make them strong. I will not knock them down. I will help them to grow in the land, like plants with good roots. I will not pull them up."
    },
    {
      "verse": "7",
      "text": "I will cause them to want to know me. They will know that I am the Lord. They will be my people and I will be their God, because they will choose to return to me. ”"
    },
    {
      "verse": "8",
      "text": "But I, the Lord, also tell you this: “King Zedekiah of Judah and his officers are like the bad figs. That is true of the people who still live in Jerusalem, and those who have run away to Egypt to live there. They are all like the figs that are too bad to eat."
    },
    {
      "verse": "9",
      "text": "I will send great trouble to punish them. It will make everyone afraid. The people of all the kingdoms on the earth will think that they are disgusting. People will insult them. They will use them as an example in proverbs. They will use their name as a curse. That will happen in all the places where I send my people."
    },
    {
      "verse": "10",
      "text": "I will send war, famine and disease to kill them. I will destroy them all. They will disappear from the land that I gave to them and to their ancestors. ” ’"
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "The Lord spoke to Jeremiah in the fourth year that Jehoiakim ruled Judah as king. Jehoiakim was the son of King Josiah. It was also the first year that Nebuchadnezzar was king of Babylon. The Lord's message was about the people of Judah."
    },
    {
      "verse": "2",
      "text": "So the prophet Jeremiah spoke to all the people of Judah and to all the people who were living in Jerusalem."
    },
    {
      "verse": "3",
      "text": "He said, ‘For 23 years the Lord has been giving me his messages. I started to tell you his messages when Amon's son Josiah had been ruling Judah for 13 years. I have continued to tell you many times what the Lord has said, even until today. But you have refused to listen."
    },
    {
      "verse": "4",
      "text": "The Lord has also sent his servants, the prophets, to speak to you many times. You have refused to listen to them too."
    },
    {
      "verse": "5",
      "text": "The Lord's message to you was, “Turn away from your wicked way of life. Stop doing the evil things that you are doing. If you do that, you may continue to live in this land. It is the land that the Lord gave to you and to your ancestors to be their home for ever."
    },
    {
      "verse": "6",
      "text": "Do not look for other gods that you can serve and worship. Do not continue to do things that make me angry. Then I will not hurt you. ”"
    },
    {
      "verse": "7",
      "text": "So now the Lord says, “You have refused to listen to my messages. You have continued to do things that make me angry. So you have brought trouble on yourselves. ”"
    },
    {
      "verse": "8",
      "text": "The Lord Almighty says, “You have not listened to my messages."
    },
    {
      "verse": "9",
      "text": "So I, the Lord, tell you that I will call the nations in the north to come. I will call my servant, King Nebuchadnezzar of Babylon, to come. I will bring them to attack this land and the people who live here. They will also attack all the nations that are around you. I will completely destroy this land, its people and all the nations around it. Their houses will become heaps of stones for ever. The land will become a terrible place. People will always see how foolish my people are."
    },
    {
      "verse": "10",
      "text": "Everywhere, I will stop people's happy songs and their marriage parties. Nobody will make flour any more. Nobody will light lamps in their homes."
    },
    {
      "verse": "11",
      "text": "This whole place will be as empty as a desert. Nobody will live here. The people of Judah and these other nations will serve the king of Babylon for 70 years. ”"
    },
    {
      "verse": "12",
      "text": "The Lord also says, “But after the 70 years have finished, I will punish the king of Babylon and his nation. I will punish them for their sins. I will destroy the land of the Babylonians. It will be a heap of stones for ever."
    },
    {
      "verse": "13",
      "text": "I will certainly do to them all the terrible things that I have spoken about. I will do to them everything that is written in this book. I will cause them to have all the trouble that Jeremiah prophesies against all the nations."
    },
    {
      "verse": "14",
      "text": "Many nations and great kings will have power over the king of Babylon and his people. The Babylonians will become their slaves. In that way, I will punish the Babylonians for all the bad things that they did to my people. ” ’"
    },
    {
      "verse": "15",
      "text": "The Lord, Israel's God, said to me, ‘Take this cup from me. It is full of wine that shows my great anger. Take it to the nations where I send you. Make them drink this wine of punishment."
    },
    {
      "verse": "16",
      "text": "When they drink it, they will walk like people who are drunk. They will seem to be crazy, because they know that I will send armies to attack them. ’"
    },
    {
      "verse": "17",
      "text": "So I took the cup from the Lord's hand. In my vision, I took it to the nations where the Lord sent me. I made them drink the wine of his punishment."
    },
    {
      "verse": "18",
      "text": "I went to Jerusalem and the other cities of Judah. I made the people of Judah, its kings and its officers drink from the cup. It was to destroy them all. Judah would become a terrible place. People would see that its people are very foolish. They would use their name as a curse. That is already happening today."
    },
    {
      "verse": "19",
      "text": "I also took the cup of punishment to these people: Pharaoh, king of Egypt, and his officers, his servants and his people; Finally, the king of Babylon will have to drink the wine of the Lord's great anger."
    },
    {
      "verse": "20",
      "text": "the foreign people who lived in Egypt; all the kings of Uz; all the kings of the Philistines (They were the kings of Ashkelon, Gaza, Ekron and the people who were still living in Ashdod);"
    },
    {
      "verse": "21",
      "text": "the people of Edom, Moab and Ammon;"
    },
    {
      "verse": "22",
      "text": "all the kings of Tyre and all the kings of Sidon; the kings of the nations around the Mediterranean Sea;"
    },
    {
      "verse": "23",
      "text": "the people of Dedan, Tema, and Buz; the people who live in the desert and who cut their hair short;"
    },
    {
      "verse": "24",
      "text": "all the kings of Arabia and the kings of the tribes who live in the desert;"
    },
    {
      "verse": "25",
      "text": "all the kings of Zimri, Elam and Media;"
    },
    {
      "verse": "26",
      "text": "all the kings of the nations in the north, those who live near together and those who live far apart; the people of all the other kingdoms everywhere on the earth. Finally, the king of Babylon will have to drink the wine of the Lord's great anger."
    },
    {
      "verse": "27",
      "text": "Then the Lord said to me, ‘Tell them that the Lord Almighty, Israel's God, says, “Drink the wine from this cup until you become drunk. Drink so much that you are sick. Drink it until you fall down and cannot get up again, because you know that I will send armies to attack you. ”"
    },
    {
      "verse": "28",
      "text": "But people may refuse to take the cup from you. They may refuse to drink from it. Then you must tell them that the Lord Almighty says this: “You must drink this wine of my punishment!"
    },
    {
      "verse": "29",
      "text": "I have already begun to punish Jerusalem, the city that is my special home. So do not think that I will leave you other nations alone! I will certainly punish you too. I will send war against everyone who lives on the earth. That is what the Lord Almighty says will happen! ”"
    },
    {
      "verse": "30",
      "text": "Now Jeremiah, prophesy this message against them:“The Lord will shout from his high place above. He will roar like a lion that is ready to attack his land. He will make a noise like thunder from his holy home. He will shout aloud like people who are stamping on grapesto make wine. He will shout against everyone who lives on the earth. “The Lord will shout from his high place above. He will roar like a lion that is ready to attack his land. He will make a noise like thunder from his holy home. He will shout aloud like people who are stamping on grapes to make wine. He will shout against everyone who lives on the earth."
    },
    {
      "verse": "31",
      "text": "People everywhere will hear his message. The Lord will accuse the nations of their sins, and he will judge all the people on the earth. He will send war to kill all the wicked people. ”That is what the Lord says. The Lord will accuse the nations of their sins, and he will judge all the people on the earth. He will send war to kill all the wicked people. ” That is what the Lord says."
    },
    {
      "verse": "32",
      "text": "The Lord Almighty also says this:“Listen to me! Great trouble will come to every single nation. War will come like a great stormfrom the ends of the earth. ” “Listen to me! Great trouble will come to every single nation. War will come like a great storm from the ends of the earth. ”"
    },
    {
      "verse": "33",
      "text": "At that time, dead bodies will lie everywhere, all over the earth. Those will be people that the Lord has killed. Nobody will weep for them. Nobody will take their bodiesto bury them in the ground. Their dead bodies will lie on the ground like dung. all over the earth. Those will be people that the Lord has killed. Nobody will weep for them. Nobody will take their bodies to bury them in the ground. Their dead bodies will lie on the ground like dung."
    },
    {
      "verse": "34",
      "text": "You leaders should have been like shepherdsto take care of my people. But now it is time for you to weep! Roll on the ground in the dust! The time of your death has arrived. You will lie on the ground, like pieces of a broken pot. to take care of my people. But now it is time for you to weep! Roll on the ground in the dust! The time of your death has arrived. You will lie on the ground, like pieces of a broken pot."
    },
    {
      "verse": "35",
      "text": "The leaders will not be able to run away and hide. The shepherds of my people will not escape. The shepherds of my people will not escape."
    },
    {
      "verse": "36",
      "text": "Listen to the leaders as they weep! The Lord's people were like their sheep. Now the shepherds are weeping loudly, because the Lord is destroying their fields. The Lord's people were like their sheep. Now the shepherds are weeping loudly, because the Lord is destroying their fields."
    },
    {
      "verse": "37",
      "text": "The Lord will completely destroy the fieldswhere the sheep quietly ate the grass. He will do that because he is very angry. where the sheep quietly ate the grass. He will do that because he is very angry."
    },
    {
      "verse": "38",
      "text": "The Lord will come out, like a lion that comes out of its cave. He will make their land a terrible place. Cruel armies will destroy the land, because of the Lord's great anger. ’"
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "The Lord spoke to Jeremiah at the time when Josiah's son Jehoiakim became king of Judah."
    },
    {
      "verse": "2",
      "text": "The Lord said, ‘Go and stand in the yard of the Lord's temple. People come from all the towns in Judah to worship the Lord in his temple. Speak to them. Tell them everything that I command you to say. Do not leave out even one word."
    },
    {
      "verse": "3",
      "text": "Perhaps they will listen to what you say. Then they may stop living in the evil way that they do now. If they change how they live, I will not punish them for their sins, as I had promised to do."
    },
    {
      "verse": "4",
      "text": "Tell them that the Lord says this: “You must obey me. I have given you my laws that tell you how you should live."
    },
    {
      "verse": "5",
      "text": "You must listen to the messages that my servants the prophets tell you. I have sent them to speak to you many times, but you have not listened to them."
    },
    {
      "verse": "6",
      "text": "So if you do not obey me, I will destroy this temple, as I destroyed Shiloh. People of all the other nations on earth will use the name of this city as a curse. ” ’"
    },
    {
      "verse": "7",
      "text": "The priests, the prophets, and all the people heard Jeremiah's message in the Lord's temple. The whole crowd of people pushed together around Jeremiah in the yard of the temple."
    },
    {
      "verse": "8",
      "text": "Jeremiah said everything that the Lord had commanded him to say to all the people. Just as he finished, some of the priests, the prophets, and the people took hold of him. They shouted, ‘You deserve to die!"
    },
    {
      "verse": "9",
      "text": "You should not say that you have the Lord's authority to prophesy such terrible things! You cannot say that this temple will become like Shiloh. You cannot say that this city will become a heap of stones where nobody lives! ’The whole crowd of people pushed together around Jeremiah in the yard of the temple."
    },
    {
      "verse": "10",
      "text": "Some of Judah's officers heard about what was happening. So they left the king's palace and they went up to the Lord's temple. They went to the gate of the temple that is called ‘The New Gate’. They sat in their places as judges near the gate."
    },
    {
      "verse": "11",
      "text": "Then the priests and the prophets told the officers and all the people why they accused Jeremiah. They said, ‘This man deserves to die because he has prophesied trouble against this city. You yourselves have heard what he said! ’"
    },
    {
      "verse": "12",
      "text": "Then Jeremiah said to all the officers and to all the people, ‘The Lord sent me to say all the things that you have heard me speak. He told me to prophesy against this temple and against this city."
    },
    {
      "verse": "13",
      "text": "Now you must change the way that you have been living. You must do what is good and right. Obey the Lord your God. Then the Lord will not punish you as he said that he would do."
    },
    {
      "verse": "14",
      "text": "As for me, I am under your authority. Do with me whatever you think is good and right."
    },
    {
      "verse": "15",
      "text": "But you should know this: If you punish me with death, you will bring great trouble on yourselves, this city, and everyone who lives here. You will be guilty of murder, because I have not done anything wrong. The Lord has sent me to speak all these words for you to hear. That is the truth! ’"
    },
    {
      "verse": "16",
      "text": "Then the officers and all the people gave their answer to the priests and the prophets. They said, ‘This man does not deserve to die. The Lord our God has given him authority to say these things to us. ’"
    },
    {
      "verse": "17",
      "text": "Then some of Judah's leaders stood up to speak to all the people who were there. “The Lord Almighty says this: Zion will be like a field that a farmer has dug. Jerusalem will become a heap of stones. Trees will cover the hill where the temple is now. ”"
    },
    {
      "verse": "18",
      "text": "They said, ‘Micah from Moresheth prophesied when Hezekiah was king of Judah. He gave this message to all the people of Judah:“The Lord Almighty says this: Zion will be like a field that a farmer has dug. Jerusalem will become a heap of stones. Trees will cover the hill where the temple is now. ”"
    },
    {
      "verse": "19",
      "text": "When Micah said that, King Hezekiah and all Judah's people did not punish him with death. Instead, Hezekiah gave honour to the Lord. He wanted to please the Lord. So the Lord did not destroy them as he had said he would do. If we are not careful, we will bring great trouble on ourselves! ’"
    },
    {
      "verse": "20",
      "text": "There was another prophet who was called Uriah. He was the son of Shemaiah, from Kiriath-Jearim. Uriah prophesied against this city and this nation, with the Lord's authority, as Jeremiah did."
    },
    {
      "verse": "21",
      "text": "When King Jehoiakim, his personal guards and all his officers heard what Uriah was saying, the king wanted to kill him. But Uriah heard about it and he was afraid. So he ran away to Egypt."
    },
    {
      "verse": "22",
      "text": "But King Jehoiakim sent Akbor's son Elnathan and some other men to Egypt."
    },
    {
      "verse": "23",
      "text": "They brought Uriah back from there to King Jehoiakim. The king punished Uriah with death. They threw his dead body in the place where they buried poor people."
    },
    {
      "verse": "24",
      "text": "But Shaphan's son Ahikam, spoke on Jeremiah's behalf. He stopped the people from taking hold of Jeremiah and killing him."
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "The Lord spoke to Jeremiah when Josiah's son Zedekiah became king of Judah."
    },
    {
      "verse": "2",
      "text": "The Lord said to me, ‘Use wood and leather to make a yoke. Tie the yoke around your neck."
    },
    {
      "verse": "3",
      "text": "Then send a message to the kings of Edom, Moab, Ammon, Tyre and Sidon. Those kings have officers who have come to see King Zedekiah of Judah here in Jerusalem."
    },
    {
      "verse": "4",
      "text": "Give them this message to tell their masters:“The Lord Almighty, Israel's God, says, ‘Tell this to your masters:"
    },
    {
      "verse": "5",
      "text": "I used my great power and strength to make this earth, as well as the people and the animals who live on it. I give these things that I have made to anyone that I choose."
    },
    {
      "verse": "6",
      "text": "Now I choose to give all your countries to my servant Nebuchadnezzar, king of Babylon. He will rule over you and even over the wild animals."
    },
    {
      "verse": "7",
      "text": "People from all nations will serve him. They will also serve his son and his grandson until the time of their kingdom has finished. Then great kings and people from many other nations will take away his power."
    },
    {
      "verse": "8",
      "text": "But if the people of any nation or kingdom refuse to serve King Nebuchadnezzar of Babylon, I will punish those people. They must agree to work for him, like oxen that have a yoke around their necks. If they refuse, I will cause the king of Babylon to punish that nation. I will destroy them with war, famine or disease."
    },
    {
      "verse": "9",
      "text": "So do not listen to your prophets, or to your diviners. Do not listen to people who use dreams or magic or the spirits of dead people to tell you what will happen. Those people tell you that you will not have to serve the king of Babylon."
    },
    {
      "verse": "10",
      "text": "But the things that they say are lies, so do not agree with them. It will cause me to take you away from your own land. I will remove you to a country that is far away and you will die there."
    },
    {
      "verse": "11",
      "text": "But if the people of any nation agree to serve the king of Babylon, I will let them stay in their own land. If they work for him, with his yoke around their necks, they can continue to grow crops and live in their own land. ’ That is what the Lord says. ” ’"
    },
    {
      "verse": "12",
      "text": "I gave the same message to King Zedekiah of Judah. I told him, ‘Put the yoke of the king of Babylon around your neck. Agree to work for him and for his people. Then you will continue to live."
    },
    {
      "verse": "13",
      "text": "You and your people do not need to die. But war, famine or disease will destroy any nation that refuses to serve the king of Babylon. The Lord has said that this will happen."
    },
    {
      "verse": "14",
      "text": "So do not listen to the words of the prophets who say, “You will not have to serve the king of Babylon. ” The things that they prophesy are lies."
    },
    {
      "verse": "15",
      "text": "The Lord says, “I have not sent those prophets. They are using my name to tell you lies. If you agree with them, I will chase you all out of the land, including those false prophets. You will die in a foreign land. ” ’"
    },
    {
      "verse": "16",
      "text": "I also spoke to the priests and to all the people. I told them, ‘The Lord says, “Do not listen to the words of your prophets. They say that the people of Babylon will soon bring back the valuable things that they took from the Lord's temple. But the things that they tell you are lies."
    },
    {
      "verse": "17",
      "text": "Do not listen to them. Agree to serve the king of Babylon. Then you will continue to live. This city does not need to become a heap of stones! ”"
    },
    {
      "verse": "18",
      "text": "Perhaps you think that they are true prophets who speak the Lord's messages. Then tell them to pray to the Lord Almighty for help. They should ask him to keep safe the valuable things that remain in Jerusalem. They should pray that the things in the Lord's temple and in the king's palace would not be taken away to Babylon."
    },
    {
      "verse": "19",
      "text": "The Lord Almighty has already spoken about the valuable things that remain in this city. He has spoken about the two bronze pillars, the big bronze bath which is called “the Sea”, and the bronze carts to carry water."
    },
    {
      "verse": "20",
      "text": "King Nebuchadnezzar did not take these things away with him when he took the king of Judah away as prisoner. He took away Jehoiakim's son, King Jeconiah of Judah, as well as the important people of Judah and Jerusalem."
    },
    {
      "verse": "21",
      "text": "Yes, Israel's God, the Lord Almighty has spoken about the things that still remain in Jerusalem, in the Lord's temple and in the king's palace."
    },
    {
      "verse": "22",
      "text": "He has said, “King Nebuchadnezzar's men will take them away to Babylon. They will remain there until I decide to do something with them. Then I will bring them back here to Jerusalem again. ” That is what the Lord says. ’"
    }
  ],
  "28": [
    {
      "verse": "1",
      "text": "In the same year, the prophet Hananiah spoke to me. It happened in the fifth month of the fourth year that King Zedekiah ruled Judah. Hananiah was the son of Azzur, who came from Gibeon. He spoke to me in the Lord's temple, where the priests and all the people could hear him."
    },
    {
      "verse": "2",
      "text": "He said, ‘Israel's God, the Lord Almighty, says this: “I will break the yoke that the king of Babylon has put around your necks."
    },
    {
      "verse": "3",
      "text": "King Nebuchadnezzar took with him to Babylon many valuable things from this temple. In less than two years, I will bring all those things back here."
    },
    {
      "verse": "4",
      "text": "I will also bring back Jehoiakim's son, King Jeconiah of Judah. And I will bring back all the people of Judah that King Nebuchadnezzar took as prisoners to Babylon. ” The Lord says, “I will break the king of Babylon's yoke. ” ’"
    },
    {
      "verse": "5",
      "text": "Jeremiah replied to Hananiah, the prophet, in the Lord's temple. The priests and all the people who were standing there could hear him."
    },
    {
      "verse": "6",
      "text": "The prophet Jeremiah said, ‘Amen! I agree! I pray that the Lord would do that! I pray that what you have prophesied really happens. May the Lord bring back from Babylon all the valuable things that belong in his temple. May he bring back all the people that King Nebuchadnezzar took to Babylon as prisoners."
    },
    {
      "verse": "7",
      "text": "But listen to what I say to you, and to all the people here."
    },
    {
      "verse": "8",
      "text": "From long ago, there have been prophets, before you and I became prophets. They often prophesied that war, famine and disease would bring great trouble to many countries and kingdoms."
    },
    {
      "verse": "9",
      "text": "But it is different if a prophet says that people will live safely in peace. We would only agree that the Lord has really sent him if his message becomes true. ’"
    },
    {
      "verse": "10",
      "text": "Then the prophet Hananiah removed the yoke from the neck of the prophet Jeremiah. He broke it into pieces. After Hananiah said that, the prophet Jeremiah went away from the temple."
    },
    {
      "verse": "11",
      "text": "He said in front of all the people, ‘The Lord says, “That shows how I will break the yoke of King Nebuchadnezzar of Babylon. He has put his yoke around the necks of all the nations. In less than two years I will break his yoke and I will remove it from their necks. ” ’After Hananiah said that, the prophet Jeremiah went away from the temple."
    },
    {
      "verse": "12",
      "text": "Soon after Hananiah had broken the yoke that was on Jeremiah's neck, the Lord spoke again to Jeremiah."
    },
    {
      "verse": "13",
      "text": "He said, ‘Go to Hananiah and tell him that the Lord says, “It is true that you have broken a wooden yoke. But instead of that you will get a yoke that is made from iron!"
    },
    {
      "verse": "14",
      "text": "Yes, the Lord Almighty, Israel's God, says this: I have put an iron yoke around the necks of all those nations. They will have to serve King Nebuchadnezzar of Babylon as his slaves. Everything will be under his power, even the wild animals. ” ’"
    },
    {
      "verse": "15",
      "text": "Then Jeremiah said to Hananiah, ‘Listen to me, Hananiah! The Lord has not sent you as his prophet. You have spoken lies to these people and they have believed you."
    },
    {
      "verse": "16",
      "text": "So the Lord says to you, “I will remove you from this earth. You have taught people to turn against me, the Lord. You will certainly die this year. ” ’"
    },
    {
      "verse": "17",
      "text": "In the seventh month of that same year, the prophet Hananiah died."
    }
  ],
  "29": [
    {
      "verse": "1",
      "text": "Jeremiah sent a letter from Jerusalem to the people of Judah who were in Babylon. He sent it to the Israelite leaders and to the priests, the prophets and all the other people who were there. Nebuchadnezzar had taken them there as prisoners from Jerusalem."
    },
    {
      "verse": "2",
      "text": "He sent the letter after King Nebuchadnezzar had taken King Jeconiah and his mother away from Jerusalem. He had taken them to Babylon with Jeconiah's officers, and the leaders of Judah and Jerusalem. He had also taken away to Babylon the men who had special skills to work with wood or metal."
    },
    {
      "verse": "3",
      "text": "King Zedekiah of Judah was sending some men to King Nebuchadnezzar in Babylon. They were Shaphan's son Elasah, and Hilkiah's son Gemariah. Jeremiah gave his letter to them to take to Babylon. This is what the letter said:"
    },
    {
      "verse": "4",
      "text": "The Lord Almighty, Israel's God, sends this message to all the people of Judah who are in Babylon. He sent them there from Jerusalem as prisoners."
    },
    {
      "verse": "5",
      "text": "He says, ‘Build houses for yourselves. Make Babylon your home. Plant gardens. Eat the food that grows in them."
    },
    {
      "verse": "6",
      "text": "Marry, so that you have sons and daughters. Find wives for your sons to marry. Let your daughters marry too. Then they also can give birth to sons and daughters. Your descendants should become more and more, not fewer."
    },
    {
      "verse": "7",
      "text": "Work well to help the foreign place where I have sent you to live. Try to make it a successful place. Pray to the Lord that it will do well. If it does well, you will also do well. ’"
    },
    {
      "verse": "8",
      "text": "Yes, the Lord Almighty, Israel's God, says, ‘Some of the prophets and the other people use magic to tell you what will happen in the future. Do not let them deceive you with their lies. Do not listen to the dreams that they tell you about."
    },
    {
      "verse": "9",
      "text": "They say that they are speaking with my authority. But the things that they prophesy are lies. I have not sent them to speak to you. ’ That is what the Lord says."
    },
    {
      "verse": "10",
      "text": "The Lord says, ‘You will live in Babylon for 70 years. Then I will choose to help you. I will be kind to you, as I promised. I will bring you back here to your home."
    },
    {
      "verse": "11",
      "text": "I, the Lord, tell you this: I have decided what I will do for you. I have plans to help you to do well. I do not want to hurt you. I want to give you hope for a good life in the future."
    },
    {
      "verse": "12",
      "text": "At that time, when you call out to me for help, I will hear your prayers."
    },
    {
      "verse": "13",
      "text": "You will want to find me, and I will be ready to meet with you. If you really want to find me,"
    },
    {
      "verse": "14",
      "text": "I will be there for you. ’ That is what the Lord says. ‘I will bring you back from the nations and all the places where I sent you as prisoners. You will no longer have to live in those foreign places. ’"
    },
    {
      "verse": "15",
      "text": "You may say, ‘The Lord has chosen prophets to bring his message to us here in Babylon. ’"
    },
    {
      "verse": "16",
      "text": "But listen to what the Lord says about the people who are still here in Jerusalem. The enemy did not take them with you as prisoners to Babylon. That includes the king who now rules David's kingdom."
    },
    {
      "verse": "17",
      "text": "The Lord Almighty says, ‘I will send war, famine and disease to hurt them. They will be like bad figs that nobody can eat."
    },
    {
      "verse": "18",
      "text": "I will use war, famine and disease to chase them away from their homes. I will send them to live among other nations. The people of all the nations in the world will see how disgusting they are. People will use their names as a curse. They will see how foolish they are and they will laugh at them."
    },
    {
      "verse": "19",
      "text": "I will do that because they have not listened to my message. I sent my servants, the prophets, to speak to them many times, but the people in Jerusalem refused to listen. ’ That is what the Lord says. The Lord also says, ‘You people of Judah who are now in Babylon have not listened to my message either."
    },
    {
      "verse": "20",
      "text": "I sent you away from Jerusalem as prisoners to Babylon. All of you must also listen carefully to my message. ’"
    },
    {
      "verse": "21",
      "text": "The Lord Almighty, Israel's God, says this about Kolaiah's son Ahab and Maaseiah's son Zedekiah: ‘They are speaking to you in my name, but they are prophesying lies. So I will put them under the power of King Nebuchadnezzar of Babylon. He will kill them while you watch."
    },
    {
      "verse": "22",
      "text": "They will be an example to the people of Judah who are now living in Babylon. When they want to curse someone, they will say, “May the Lord punish you in the same way that the king of Babylon killed Zedekiah and Ahab. He burned them to death in a fire! ”"
    },
    {
      "verse": "23",
      "text": "That will happen to them because of the terrible sins that they have done in Israel. They have sex with the wives of their neighbours. They have used my name to tell lies. They have spoken messages that I did not command them to speak. I know what they have done because I have seen it all. ’ That is what the Lord says."
    },
    {
      "verse": "24",
      "text": "The Lord told Jeremiah to send this message to Shemaiah, who came from Nehelam:"
    },
    {
      "verse": "25",
      "text": "‘The Lord Almighty, Israel's God says, “You sent a letter on your own authority to all the people in Jerusalem. Those people included the priest Zephaniah, Maaseiah's son, and all the other priests. In your letter, you said to Zephaniah:"
    },
    {
      "verse": "26",
      "text": "The Lord chose you to be priest instead of Jehoiada. You are the officer who has authority over the Lord's temple. If there is any crazy man who says that he is a prophet, you must take hold of him. It is your duty to tie him up. Put heavy pieces of wood on his legs and iron chains around his neck."
    },
    {
      "verse": "27",
      "text": "That is your job, so I do not know why you have not punished Jeremiah, the man from Anathoth. He is there and he is prophesying to you."
    },
    {
      "verse": "28",
      "text": "He has even sent a message to us here in Babylon. He told us that we will be here for a long time. He told us to build houses and make our homes here. He says that we should plant gardens to grow food for ourselves. ” ’"
    },
    {
      "verse": "29",
      "text": "When Zephaniah the priest received Shemaiah's letter, he read it to the prophet Jeremiah."
    },
    {
      "verse": "30",
      "text": "Then the Lord said to Jeremiah,"
    },
    {
      "verse": "31",
      "text": "‘Send a message to all the people of Judah who are now in Babylon. Tell them that the Lord says this about Shemaiah, the man from Nehelam: “Shemaiah has prophesied to you. But I did not send him to you. He has caused you to believe a lie. ”"
    },
    {
      "verse": "32",
      "text": "So the Lord says, “I will certainly punish Shemaiah and his family. He will not have any descendants who remain among my people. None of them will receive any of the good things that I will do for my people. I will punish him because he has taught my people to turn against me. ” That is what the Lord has said. ’"
    }
  ],
  "30": [
    {
      "verse": "1",
      "text": "The Lord gave this message to Jeremiah:"
    },
    {
      "verse": "2",
      "text": "‘The Lord, Israel's God, says, “Write all the words that I have spoken in a book. ”"
    },
    {
      "verse": "3",
      "text": "I, the Lord, tell you this: “The time will come when I will bring back my people from foreign lands. I will bring the people of Israel and Judah back to the land that I gave to their ancestors. It will belong to them. ” That is what the Lord says. ’"
    },
    {
      "verse": "4",
      "text": "The Lord spoke this message about Israel and Judah:"
    },
    {
      "verse": "5",
      "text": "The Lord said, ‘People are shouting because they are afraid! Listen to them! There is no peace anywhere. ‘People are shouting because they are afraid! Listen to them! There is no peace anywhere."
    },
    {
      "verse": "6",
      "text": "Think carefully about this. Do men ever give birth to babies? So why are these strong men weak with pain? They seem like a woman who is giving birth. All their faces have become white with fear. Do men ever give birth to babies? So why are these strong men weak with pain? They seem like a woman who is giving birth. All their faces have become white with fear."
    },
    {
      "verse": "7",
      "text": "It will be a time of terrible trouble, worse than anything that has happened before. It will be a time of great trouble for Jacob's descendants. But I will rescue them from their trouble. ’ worse than anything that has happened before. It will be a time of great trouble for Jacob's descendants. But I will rescue them from their trouble. ’"
    },
    {
      "verse": "8",
      "text": "The Lord Almighty says this:‘When that day comes, I will break the yoke that is around your necks. I will remove the ropes that tie your legs. My people will no longer be slavesunder the power of foreign people. ‘When that day comes, I will break the yoke that is around your necks. I will remove the ropes that tie your legs. My people will no longer be slaves under the power of foreign people."
    },
    {
      "verse": "9",
      "text": "Instead, they will serve the Lord their God. They will serve David's descendant. I will raise that man up to be their king. ’ They will serve David's descendant. I will raise that man up to be their king. ’"
    },
    {
      "verse": "10",
      "text": "The Lord says, ‘Do not be afraid, descendants of Jacob, my servants. People of Israel, do not be upset. I will rescue you and your descendants from your enemies. I will bring you back from the land far away, where you are prisoners. Jacob's descendants will return to their own land. They will live there safely in peace. There will be no enemies to make them afraid. ’ ‘Do not be afraid, descendants of Jacob, my servants. People of Israel, do not be upset. I will rescue you and your descendants from your enemies. I will bring you back from the land far away, where you are prisoners. Jacob's descendants will return to their own land. They will live there safely in peace. There will be no enemies to make them afraid. ’"
    },
    {
      "verse": "11",
      "text": "The Lord says, ‘I am with you and I will save you. I have sent you away to live in foreign lands. That was the punishment that you deserved. I will completely destroy the nations where I sent you to live. But I will not completely destroy you. I will certainly punish you, but only as much as you deserve. ’ ‘I am with you and I will save you. I have sent you away to live in foreign lands. That was the punishment that you deserved. I will completely destroy the nations where I sent you to live. But I will not completely destroy you. I will certainly punish you, but only as much as you deserve. ’"
    },
    {
      "verse": "12",
      "text": "The Lord says this to Zion's people:‘You have received very bad wounds. Nobody can make you well again. ‘You have received very bad wounds. Nobody can make you well again."
    },
    {
      "verse": "13",
      "text": "There is no one who will speak on your behalf. There is no medicine that can make you well. There is no medicine that can make you well."
    },
    {
      "verse": "14",
      "text": "All your friends have turned away from you. They do not want to help you in your troubles. I have hurt you, in the way that an enemy might attack you. You have lived in a very wicked way, and you are guilty of many sins. So I had to punish you, to teach you what is right. They do not want to help you in your troubles. I have hurt you, in the way that an enemy might attack you. You have lived in a very wicked way, and you are guilty of many sins. So I had to punish you, to teach you what is right."
    },
    {
      "verse": "15",
      "text": "You complain about your wounds. You say that your pain will never get better. But I had to punish you, because you are very wicked, and you are guilty of many sins. You say that your pain will never get better. But I had to punish you, because you are very wicked, and you are guilty of many sins."
    },
    {
      "verse": "16",
      "text": "But I will destroy your enemies who destroyed you. All of them will go as prisoners to foreign lands. They took your valuable things for themselves. Now I will take away their valuable things. All of them will go as prisoners to foreign lands. They took your valuable things for themselves. Now I will take away their valuable things."
    },
    {
      "verse": "17",
      "text": "People say that nobody takes care of you, people of Zion. They say that I have chased you out of your land. But I will give you back your health. I will make your wounds better. ’That is what the Lord says. people of Zion. They say that I have chased you out of your land. But I will give you back your health. I will make your wounds better. ’ That is what the Lord says."
    },
    {
      "verse": "18",
      "text": "The Lord says, ‘I will bring back Jacob's descendants to their own land. Enemies have knocked down their houses, but I will repair the homes where they lived. I will be kind to them, so that each family can live safely. The city will stand again in its right place. The palace will also stand where it was before. ‘I will bring back Jacob's descendants to their own land. Enemies have knocked down their houses, but I will repair the homes where they lived. I will be kind to them, so that each family can live safely. The city will stand again in its right place. The palace will also stand where it was before."
    },
    {
      "verse": "19",
      "text": "In those places you will hear happy songs, as people thank God. People will laugh aloud because they are so happy. I will make them grow in number. Their descendants will be many. I will cause other nations to give them honour. They will no longer insult my people. as people thank God. People will laugh aloud because they are so happy. I will make them grow in number. Their descendants will be many. I will cause other nations to give them honour. They will no longer insult my people."
    },
    {
      "verse": "20",
      "text": "Jacob's descendants will be strong again, as they were long ago. They will serve me together as one group of people. I will punish anyone who wants to hurt them. as they were long ago. They will serve me together as one group of people. I will punish anyone who wants to hurt them."
    },
    {
      "verse": "21",
      "text": "One of their own people will rule them as king. I will ask him to come near to me, and he will come near. Nobody would be brave enough to come near to me, unless I asked him to come. ’That is what the Lord says. I will ask him to come near to me, and he will come near. Nobody would be brave enough to come near to me, unless I asked him to come. ’ That is what the Lord says."
    },
    {
      "verse": "22",
      "text": "‘At that time, you will again be my people, and I will be your God. ’ and I will be your God. ’"
    },
    {
      "verse": "23",
      "text": "Look! The Lord's anger will comelike a strong storm. Like a strong wind, it will blow away the heads of wicked people. like a strong storm. Like a strong wind, it will blow away the heads of wicked people."
    },
    {
      "verse": "24",
      "text": "The Lord will not stop being angry, until he has finished what he has decided to do. When the time comes, you will understand this clearly."
    }
  ],
  "31": [
    {
      "verse": "1",
      "text": "The Lord says this:‘When that time comes, I will be the God of every family in Israel. And they will be my people. ’ ‘When that time comes, I will be the God of every family in Israel. And they will be my people. ’"
    },
    {
      "verse": "2",
      "text": "The Lord says, ‘I was kind to the Israeliteswhen they travelled in the desert. I helped those that the enemy had not killed, as they looked for a place where they could rest. ’ ‘I was kind to the Israelites when they travelled in the desert. I helped those that the enemy had not killed, as they looked for a place where they could rest. ’"
    },
    {
      "verse": "3",
      "text": "At that time long ago, the Lord showed himself to his people. He said, ‘I have always loved youand I always will love you. My faithful love for you continues for ever. the Lord showed himself to his people. He said, ‘I have always loved you and I always will love you. My faithful love for you continues for ever."
    },
    {
      "verse": "4",
      "text": "My special people of Israel, I will make you strong again. You will be so happy that you dance, as people make music with tambourines. I will make you strong again. You will be so happy that you dance, as people make music with tambourines."
    },
    {
      "verse": "5",
      "text": "You will again plant vineson the hills in Samaria. Yes, farmers will plant vinesand they will eat their fruit. on the hills in Samaria. Yes, farmers will plant vines and they will eat their fruit."
    },
    {
      "verse": "6",
      "text": "There will be a time when guards will call out, as they watch for danger in the hills of Ephraim. They will shout, “Let us go up to Zion, to worship the Lord our God. ” ’ as they watch for danger in the hills of Ephraim. They will shout, “Let us go up to Zion, to worship the Lord our God. ” ’"
    },
    {
      "verse": "7",
      "text": "The Lord says this:‘Sing with joy for Jacob's descendants! They are the greatest of all the nations! Praise the Lord with loud voices! Say, “Lord, please save your people. Save those Israelites who are still alive. ” ‘Sing with joy for Jacob's descendants! They are the greatest of all the nations! Praise the Lord with loud voices! Say, “Lord, please save your people. Save those Israelites who are still alive. ”"
    },
    {
      "verse": "8",
      "text": "See what I will do! I will bring them back from the land in the north. Wherever they are, I will bring them back. A great crowd of my people will return. Blind people will be among them, and people who cannot walk well. There will be pregnant womenand some who will very soon give birth. I will bring them back from the land in the north. Wherever they are, I will bring them back. A great crowd of my people will return. Blind people will be among them, and people who cannot walk well. There will be pregnant women and some who will very soon give birth."
    },
    {
      "verse": "9",
      "text": "They will be weeping as they come. They will pray for my help as I lead them. I will lead them beside streams of fresh water, and on flat paths where they will not fall down. I will help them because I am a father for Israel's people. Ephraim is like my firstborn son. ’ They will pray for my help as I lead them. I will lead them beside streams of fresh water, and on flat paths where they will not fall down. I will help them because I am a father for Israel's people. Ephraim is like my firstborn son. ’"
    },
    {
      "verse": "10",
      "text": "People of all nations, listen to the Lord's message. Shout it aloud for everyone to hear, even those who live on the coasts far away. Say, ‘The Lord chased Israel's people away, but now he will bring them back. He will take care of them, like a shepherd who takes care of his sheep. ’ listen to the Lord's message. Shout it aloud for everyone to hear, even those who live on the coasts far away. Say, ‘The Lord chased Israel's people away, but now he will bring them back. He will take care of them, like a shepherd who takes care of his sheep. ’"
    },
    {
      "verse": "11",
      "text": "Yes, the Lord will rescue Jacob's descendants. He will pay the cost to let them be free. They will no longer be under the power of people who were stronger than them. He will pay the cost to let them be free. They will no longer be under the power of people who were stronger than them."
    },
    {
      "verse": "12",
      "text": "His people will come back to Mount Zion, and they will shout with joy. They will be very happybecause of all the good things that the Lord gives to them. There will be grain to make bread, new wine and olive oil. There will be lambs and young cows. They will grow and be strong, like a garden that has plenty of water. They will not be weak or sad any more. and they will shout with joy. They will be very happy because of all the good things that the Lord gives to them. There will be grain to make bread, new wine and olive oil. There will be lambs and young cows. They will grow and be strong, like a garden that has plenty of water. They will not be weak or sad any more."
    },
    {
      "verse": "13",
      "text": "The Lord says this:‘Young women will dance because they are happy. The young men and the old men will also be happy. I will cause them to laugh instead of weep. I will comfort them, so that they are happy instead of sad. ‘Young women will dance because they are happy. The young men and the old men will also be happy. I will cause them to laugh instead of weep. I will comfort them, so that they are happy instead of sad."
    },
    {
      "verse": "14",
      "text": "I will give the priests plenty of good things. My people will have everything that they need, because of all the good things that I give to them. ’ My people will have everything that they need, because of all the good things that I give to them. ’"
    },
    {
      "verse": "15",
      "text": "The Lord says, ‘You can hear a sad noise in Ramah. Someone is weeping with a loud voice. It is Rachel, and she is weeping for her children. Nobody can help her to stop weeping, because her children are dead. ’ ‘You can hear a sad noise in Ramah. Someone is weeping with a loud voice. It is Rachel, and she is weeping for her children. Nobody can help her to stop weeping, because her children are dead. ’"
    },
    {
      "verse": "16",
      "text": "The Lord says, ‘Stop crying! Do not weep any more! I will help you because of what you have done. Your children will return from the land of their enemies. ’That is what the Lord says. ‘Stop crying! Do not weep any more! I will help you because of what you have done. Your children will return from the land of their enemies. ’ That is what the Lord says."
    },
    {
      "verse": "17",
      "text": "‘Yes, you will have descendants in the future. Your children will return to their own land. ’That is what the Lord says. Your children will return to their own land. ’ That is what the Lord says."
    },
    {
      "verse": "18",
      "text": "‘I have heard Israel's people when they are sad. They say to me, “You punished us, and we accepted it. You taught us to obey you, like a farmer teaches an ox to work for him. So let us come back to serve you. We are ready to return to you, because you are the Lord, our God. They say to me, “You punished us, and we accepted it. You taught us to obey you, like a farmer teaches an ox to work for him. So let us come back to serve you. We are ready to return to you, because you are the Lord, our God."
    },
    {
      "verse": "19",
      "text": "After we turned away from you, we were sorry that we had done that. We understood what we had done, and we showed that we were sad. We were ashamed and upset, because of the disgusting things that we did when we were young. ” we were sorry that we had done that. We understood what we had done, and we showed that we were sad. We were ashamed and upset, because of the disgusting things that we did when we were young. ”"
    },
    {
      "verse": "20",
      "text": "But Israel's people are my own dear children. I still love them, even when I have to speak against them. I can never forget them. I only want to help them. I will certainly be kind to them. ’That is what the Lord says. I still love them, even when I have to speak against them. I can never forget them. I only want to help them. I will certainly be kind to them. ’ That is what the Lord says."
    },
    {
      "verse": "21",
      "text": "‘People of Israel, put up signs along the roads, so that you know the way to go. Remember the road that you travelled onwhen you went away from your land. Now return, my special people, Israel. Return to your cities that you had to leave. so that you know the way to go. Remember the road that you travelled on when you went away from your land. Now return, my special people, Israel. Return to your cities that you had to leave."
    },
    {
      "verse": "22",
      "text": "You went away from me, like a daughter who refuses to obey her father. Do not continue to turn away from me. I, the Lord, promise to do a new thing. Women will take care of men! ’ like a daughter who refuses to obey her father. Do not continue to turn away from me. I, the Lord, promise to do a new thing. Women will take care of men! ’"
    },
    {
      "verse": "23",
      "text": "The Lord Almighty, Israel's God, says this:‘I will bring my people back from the land where they have been prisoners. Then the people in the towns of Judah will again say, “We pray that the Lord will bless you, Jerusalem. You are the special place where he lives on his holy mountain! ” ‘I will bring my people back from the land where they have been prisoners. Then the people in the towns of Judah will again say, “We pray that the Lord will bless you, Jerusalem. You are the special place where he lives on his holy mountain! ”"
    },
    {
      "verse": "24",
      "text": "People will live together in the towns of Judah. Farmers and shepherds will work in the fields."
    },
    {
      "verse": "25",
      "text": "I will help those who feel tired. I will make those who feel weak strong again."
    },
    {
      "verse": "26",
      "text": "Then they will say, “When I woke from my sleep and I looked around, I was happy. ” ’"
    },
    {
      "verse": "27",
      "text": "The Lord says this:‘The time will come when I fill the lands of Israel and Judah with people and animals."
    },
    {
      "verse": "28",
      "text": "In past time, I chose to pull them out of their land, like a plant with its roots. I knocked them down and I destroyed them. But now I will put them in their land again, like strong plants. ’ That is what the Lord says."
    },
    {
      "verse": "29",
      "text": "‘When that happens, people will not say, “The fathers have eaten bitter fruit, but it causes their children's teeth to hurt. ”"
    },
    {
      "verse": "30",
      "text": "Instead, I will punish everyone for their own sins. It will be the teeth of the person who eats bitter fruit that will hurt. ’"
    },
    {
      "verse": "31",
      "text": "The Lord says, ‘A time will soon come when I make a new covenant with Israel's people and with Judah's people."
    },
    {
      "verse": "32",
      "text": "It will not be like the old covenant that I made with their ancestors. At that time, I brought them safely out of Egypt. I took care of them, like a faithful husband who takes care of his wife. But they did not obey my covenant. ’ That is what the Lord says."
    },
    {
      "verse": "33",
      "text": "‘Yes, I will make a new covenant with Israel's people at that time. It will be like this: I will put my law deep inside them, in their hearts and minds. I will be their God, and they will be my people. ’ That is what the Lord says."
    },
    {
      "verse": "34",
      "text": "‘Then people will not have to teach their friends or their family about me. They will all know me already. The important people and the ordinary people will all know me. I will forgive the wicked things that they have done. I will no longer think about their sins. ’ That is what the Lord says."
    },
    {
      "verse": "35",
      "text": "The Lord is the one who causes the sun to shine during the day. He causes the moon and the stars to shine at night. He causes the waves of the sea to move aroundand they make a loud noise. He is the Lord Almighty, and he makes this promise: He causes the moon and the stars to shine at night. He causes the waves of the sea to move around and they make a loud noise. He is the Lord Almighty, and he makes this promise:"
    },
    {
      "verse": "36",
      "text": "‘I will always take care of Israel's people as my special nation. I will always cause the laws that rule everything to continue. I could never forget those laws, and I could never forget my people. ’ I will always cause the laws that rule everything to continue. I could never forget those laws, and I could never forget my people. ’"
    },
    {
      "verse": "37",
      "text": "The Lord says, ‘Nobody can measure the size of the sky. Nobody can dig down to the bottom of the earth's foundations. In the same way, I can never turn away from all Israel's people. I will not leave them, even though they have done wicked things. ’That is what the Lord says. ‘Nobody can measure the size of the sky. Nobody can dig down to the bottom of the earth's foundations. In the same way, I can never turn away from all Israel's people. I will not leave them, even though they have done wicked things. ’ That is what the Lord says."
    },
    {
      "verse": "38",
      "text": "The Lord says this:‘The time will soon come when this city of Jerusalem belongs to me again. You will build it all again, from the tower of Hananel to the Corner gate."
    },
    {
      "verse": "39",
      "text": "The edge of the city will go straight from there to Gareb hill. Then it will turn south and go to Goah."
    },
    {
      "verse": "40",
      "text": "The whole area will belong to the Lord as a holy place. It will include the valley where they throw dead bodies and the ashes from sacrifices. It will include all the fields of the Kidron valley in the east, as far north as the corner of the Horse Gate. All of that will be my holy place. Nobody will ever again take the city or destroy it. ’"
    }
  ],
  "32": [
    {
      "verse": "1",
      "text": "The Lord spoke to Jeremiah when King Zedekiah had ruled Judah for ten years. At that time, King Nebuchadnezzar had ruled in Babylon for 18 years."
    },
    {
      "verse": "2",
      "text": "Nebuchadnezzar's army had made their camp all around Jerusalem. Jeremiah was a prisoner in the city. Guards kept him in a yard of the palace of the king of Judah."
    },
    {
      "verse": "3",
      "text": "King Zedekiah had put Jeremiah in prison there. He did not like the messages from God that Jeremiah was speaking. He said to Jeremiah, ‘You should stop saying these things! Do not continue to say, “The Lord will put this city under the power of the king of Babylon. The king of Babylon will take the city for himself."
    },
    {
      "verse": "4",
      "text": "Zedekiah, king of Judah, will not escape from Babylon's army. They will take him to the king of Babylon. Zedekiah will have to stand in front of the king of Babylon and answer his questions."
    },
    {
      "verse": "5",
      "text": "They will take Zedekiah away to Babylon as their prisoner. He will stay there until the Lord has punished him completely. If you continue to fight against Babylon's army, you will never win. ” ’ That was the Lord's message that Jeremiah had told Zedekiah."
    },
    {
      "verse": "6",
      "text": "While Jeremiah was in prison, the Lord said to him,"
    },
    {
      "verse": "7",
      "text": "‘Hanamel, the son of your uncle Shallum, will come to visit you. He will say to you, “I want you to buy my field in Anathoth. The law says that I should offer it to you first, because you are my relative. ” ’"
    },
    {
      "verse": "8",
      "text": "This happened as the Lord had said it would happen. My cousin Hanamel came to visit me in the prison. He said, ‘Buy my field at Anathoth, in the land of Benjamin's tribe. I offer it to you first, as my relative. So you can buy it for yourself. ’When this happened, I realized I had really heard the Lord's message."
    },
    {
      "verse": "9",
      "text": "So I bought the field at Anathoth from my cousin Hanamel. I weighed 17 shekels of silver to pay him for it."
    },
    {
      "verse": "10",
      "text": "I wrote my name on a piece of paper to show that I had bought the land. Some men watched as I did this, to agree to the sale. I closed the paper with a seal. Then I gave Hanamel the silver that I had weighed."
    },
    {
      "verse": "11",
      "text": "I took the paper with the seal, and also a copy of it that had no seal. The agreement about the sale of land was written on those pieces of paper."
    },
    {
      "verse": "12",
      "text": "I gave both pieces of paper to Baruch, the son of Neriah and grandson of Mahseiah. Hanamel watched me as I did this, as well as the men who had written their names on the paper. The people of Judah who were there in the guards' yard also watched me."
    },
    {
      "verse": "13",
      "text": "While all those people listened, I said to Baruch,"
    },
    {
      "verse": "14",
      "text": "‘The Lord Almighty, Israel's God says, “Take these two pieces of paper that have the agreement about the sale of land. Take the piece that has a seal on it and the piece without a seal. Put them both in a clay jar to keep them safe for a long time. ”"
    },
    {
      "verse": "15",
      "text": "The Lord Almighty, Israel's God, says, “A time will come when people in this land again buy houses, fields and vineyards. ” ’"
    },
    {
      "verse": "16",
      "text": "After I had given Baruch the pieces of paper about the sale of land, I prayed to the Lord."
    },
    {
      "verse": "17",
      "text": "I said, ‘Lord God, you used your great power and strength to make the earth and the sky. Nothing is too difficult for you to do."
    },
    {
      "verse": "18",
      "text": "You show your faithful love to thousands of people. But you also punish people for the sins that their ancestors did in past times. You are the great and powerful God, the Lord Almighty."
    },
    {
      "verse": "19",
      "text": "You have wise thoughts and you do great things. You see everything that people do. You see how they live. You give everyone what they deserve."
    },
    {
      "verse": "20",
      "text": "You did powerful miracles in Egypt, and we still remember them today. In this way you continue to be famous in Israel and everywhere in the world."
    },
    {
      "verse": "21",
      "text": "You used your great power and strength to bring your people out of Egypt. You did miracles that showed your power. It caused the Egyptians to be very afraid."
    },
    {
      "verse": "22",
      "text": "You gave this land to the Israelites, as you had promised to their ancestors. It was a land where there was plenty of food and drink, enough for everyone."
    },
    {
      "verse": "23",
      "text": "Your people moved in to the land and they made it their home. But they did not obey you. They did not live in the way that your law taught them. They did not do the things that you commanded them to do. Because of that, you caused them to have all this terrible trouble."
    },
    {
      "verse": "24",
      "text": "Babylon's army have already put heaps of earth around the city's walls. They are ready to attack us. War, famine and disease will soon kill us. Babylon's soldiers will come into the city and take it for themselves. Lord, you warned us that this would happen. Now you can see that it is already happening."
    },
    {
      "verse": "25",
      "text": "I know that Babylon's army will soon get power over the city. But you still told me to use my silver to buy that field. And people watched me write my name on the paper. ’"
    },
    {
      "verse": "26",
      "text": "Then the Lord said to Jeremiah,"
    },
    {
      "verse": "27",
      "text": "‘I am the Lord, the God who rules all people. Nothing is too difficult for me to do."
    },
    {
      "verse": "28",
      "text": "So I, the Lord, tell you this: I will certainly give this city to King Nebuchadnezzar of Babylon and his army. They will get power over it."
    },
    {
      "verse": "29",
      "text": "The soldiers from Babylon who are attacking the city will come in. They will destroy it with fire. They will burn down the houses of the people. These people have made me angry. They went up on the roofs of their houses and they burned incense to worship Baal. They also poured out drink offerings to other false gods."
    },
    {
      "verse": "30",
      "text": "The people of Israel and Judah have continued to do things that I see are evil. They have done those things since they were a young nation. They have always done things that make me angry. That is what the Lord says."
    },
    {
      "verse": "31",
      "text": "The people of this city have made me very angry from the time when they built it, even until now. Because of that, I have decided to destroy it completely."
    },
    {
      "verse": "32",
      "text": "The people of Israel and Judah have made me angry because of all the wicked things that they have done. Their kings, officers, priests and prophets have all done wicked things. I will destroy this city because of the wicked things that the people of Jerusalem and all of Judah have done."
    },
    {
      "verse": "33",
      "text": "They should have come to me for help, but instead they turned away from me. Many times I taught them what was right. But they would not listen to me when I warned them."
    },
    {
      "verse": "34",
      "text": "They put their disgusting idols in the temple. I chose that place to be my special home, but they have made it unclean."
    },
    {
      "verse": "35",
      "text": "They have built altars in Ben-Hinnom valley to worship Baal. On those altars, they light fires to burn their sons and daughters as sacrifices to Molech. I never commanded them to do that. I never even thought about it. It has caused Judah's people to be guilty of sin."
    },
    {
      "verse": "36",
      "text": "You are right to say, “War, famine and disease will cause the king of Babylon to get power over this city. ” But I, the Lord, Israel's God, tell you this:"
    },
    {
      "verse": "37",
      "text": "I will certainly bring my people back from the foreign countries where I will send them. I will send them away as prisoners because they have made me very angry. But I will bring them back to this place so that they can live here safely."
    },
    {
      "verse": "38",
      "text": "They will be my people and I will be their God."
    },
    {
      "verse": "39",
      "text": "I will make them all want to do one thing. They will want to live in a way that always pleases me. They will do that so that they enjoy good lives and their children also enjoy good lives after them."
    },
    {
      "verse": "40",
      "text": "I will make a covenant with them that will continue for ever. I will promise always to do good things for them. They will want to respect me and obey me so that they never turn away from me again. That is what I will do for them."
    },
    {
      "verse": "41",
      "text": "I will be happy to help them with good things. I promise them faithfully that I will put them in this land again. They will grow like strong plants. ’"
    },
    {
      "verse": "42",
      "text": "The Lord says this: ‘It is true that I have brought terrible trouble to this people. But in the same way, I will give them all the good things that I have promised."
    },
    {
      "verse": "43",
      "text": "At this time, you are saying, “Babylon's army will take power over our land. It will become like a desert. No people or animals will live in it. ” But I tell you that one day people will again buy and sell fields in this land."
    },
    {
      "verse": "44",
      "text": "They will pay silver to buy fields. There will be pieces of paper that show the agreement for the sale. There will be seals on those papers. People will watch and agree that the sale has happened. People will buy fields in the land that belongs to Benjamin's tribe and in the villages round Jerusalem. They will buy land in the towns of Judah, in the hill country, in the low hills in the west and in the Negev region in the south. At that time, I will bring my people back to live safely in their land. I, the Lord, promise that this will happen! ’"
    }
  ],
  "33": [
    {
      "verse": "1",
      "text": "The Lord spoke to Jeremiah a second time while he was in prison in the yard of the palace."
    },
    {
      "verse": "2",
      "text": "He said, ‘I am the Lord who made the earth. I gave a shape to it and I put it in its place. The Lord is my name. I say this to you:"
    },
    {
      "verse": "3",
      "text": "“Call out to me and I will answer you. I will tell you about great things. They are secret things that you do not yet know. ”"
    },
    {
      "verse": "4",
      "text": "The Lord, Israel's God, has a message about the houses in this city and about the royal palaces of Judah's kings. The people have knocked down the city's buildings. They have used the stones to make the city's walls stronger,"
    },
    {
      "verse": "5",
      "text": "to fight against Babylon's army. The Lord says, “The city's houses will be full of dead bodies. I am very angry with the people in the city and I will kill them. I will refuse to help this city because of the wicked things that its people have done."
    },
    {
      "verse": "6",
      "text": "But listen to me! I will bring health again to the people of this city. I will make my people well again. They will live safely in peace."
    },
    {
      "verse": "7",
      "text": "I will bring back the people of Judah and Israel from foreign lands. I will make them a strong nation, as they were before."
    },
    {
      "verse": "8",
      "text": "They have done bad things and they have turned against me. But I will forgive all their sins that they have done against me."
    },
    {
      "verse": "9",
      "text": "Then this city will cause the people of all the nations on the earth to give me honour. They will praise me and make me happy. They will hear about all the good things that I am doing for Jerusalem. They will see that I have caused its people to have health and peace. Because of that, they will respect me and they will shake with fear. ”"
    },
    {
      "verse": "10",
      "text": "The Lord says, “You say that this place is like a desert, and no people or animals live here. But I tell you that people will return to live here. You will hear the voices of people in the streets of Jerusalem and in the towns of Judah that are now empty. ‘We thank the Lord Almighty, because he is good. His faithful love continues for ever. ’ Yes, I will make the land successful again, as it was before. ” That is what the Lord says."
    },
    {
      "verse": "11",
      "text": "You will hear the sounds of happy people. You will hear the songs of men and women at their weddings. You will hear the voices of people as they bring gifts to the Lord's temple to thank him. They will say, ‘We thank the Lord Almighty, because he is good. His faithful love continues for ever. ’Yes, I will make the land successful again, as it was before. ” That is what the Lord says."
    },
    {
      "verse": "12",
      "text": "The Lord Almighty says, “This place will become a heap of stones. No people or animals will live here. But I will put fields of grass around the towns again. There will be places for shepherds to rest with their sheep."
    },
    {
      "verse": "13",
      "text": "Shepherds will count their sheep again, one by one. They will do that in the towns of the hill country, in the low hills in the west and in the Negev region in the south. They will do it in the land that belongs to Benjamin's tribe, in the villages around Jerusalem and in all the towns of Judah. ” That is what the Lord says."
    },
    {
      "verse": "14",
      "text": "The Lord also says, “A time will soon come when I do good things for the nations of Israel and Judah. I will do what I have promised to do for them."
    },
    {
      "verse": "15",
      "text": "At that time, I will cause a descendant of David to be born. He will be righteous. He will grow like a branch on the tree of David's family. He will do what is right and fair in the land."
    },
    {
      "verse": "16",
      "text": "When he rules, the people of Judah will be safe. Jerusalem's people will live in peace. People will give this name to the city: ‘The Lord is our righteous Saviour. ’ ”"
    },
    {
      "verse": "17",
      "text": "The Lord says, “One of David's descendants will always rule as king over the nation of Israel."
    },
    {
      "verse": "18",
      "text": "There will always be priests who are descendants of Levi. They will serve me in my temple. They will always be there to offer burnt offerings, grain offerings and other sacrifices to me. ” ’"
    },
    {
      "verse": "19",
      "text": "The Lord also said this to Jeremiah:"
    },
    {
      "verse": "20",
      "text": "‘I, the Lord, say to you, “The day and the night will always come at their proper times. I have made that agreement with them, and nobody can stop it."
    },
    {
      "verse": "21",
      "text": "In the same way, nobody can stop the covenant that I have made with my servant David, and with the Levites. I promise you that there will always be a descendant of King David who rules as king. I also promise that there will always be descendants of Levi to serve me as priests."
    },
    {
      "verse": "22",
      "text": "I promise that my servant David will always have many descendants. There will also be very many Levites to serve me as priests. You will not be able to count them. They will be more than the stars in the sky and more than the sand on the shore of the sea. ” ’"
    },
    {
      "verse": "23",
      "text": "The Lord also said to Jeremiah,"
    },
    {
      "verse": "24",
      "text": "‘Some people are saying, “The Lord chose the two nations of Israel and Judah to be his special people. But now he has turned away from them. ” You have heard people say those things. They do not think that my people will ever be a nation again."
    },
    {
      "verse": "25",
      "text": "But I promise you this: Nobody can stop the agreement that I have made with the day and the night. I have also commanded the earth and the sky to obey certain laws."
    },
    {
      "verse": "26",
      "text": "In the same way, I will never change my promise to the descendants of Jacob and to my servant David. I will always choose one of David's descendants to rule over the descendants of Abraham, Isaac and Jacob. I will bring them back to their own land. I will be kind to them and forgive them. ’"
    }
  ],
  "34": [
    {
      "verse": "1",
      "text": "The Lord spoke to Jeremiah again, while King Nebuchadnezzar of Babylon and his army were attacking Jerusalem. Soldiers from all the kingdoms that King Nebuchadnezzar ruled joined with Babylon's own soldiers to make a large army. They were attacking Jerusalem and the towns around it."
    },
    {
      "verse": "2",
      "text": "The Lord, Israel's God, said to Jeremiah, ‘Go to Zedekiah, king of Judah, and give him this message: The Lord says, “I will put this city under the power of the king of Babylon. He will burn it down."
    },
    {
      "verse": "3",
      "text": "You will not be able to escape. Babylon's soldiers will certainly take hold of you. They will take you to the king of Babylon. You will have to stand in front of the king of Babylon and answer his questions. Then you will go to Babylon as his prisoner."
    },
    {
      "verse": "4",
      "text": "But listen to the promise that the Lord makes to you, Zedekiah, king of Judah. I, the Lord, promise you that you will not die in a battle."
    },
    {
      "verse": "5",
      "text": "Instead, you will die with peace in your mind. People will burn incense to give you honour when they bury you. They did that for your ancestors who ruled as kings before you. They will do it for you too. When you die, people will weep because they are sad. They will say, ‘This is terrible! Our king has died! ’ That is my promise to you, says the Lord. ” ’"
    },
    {
      "verse": "6",
      "text": "The prophet Jeremiah told all this to King Zedekiah of Judah, in Jerusalem."
    },
    {
      "verse": "7",
      "text": "This happened when the king of Babylon's army were attacking Jerusalem and the cities of Lachish and Azekah. Those were the only strong cities in Judah that were not yet under his power."
    },
    {
      "verse": "8",
      "text": "At another time, the Lord gave Jeremiah another message for King Zedekiah. Zedekiah had made an agreement with the people of Jerusalem. They all agreed to let their slaves go free."
    },
    {
      "verse": "9",
      "text": "Everyone in Judah who had a Hebrew slave must let their slave go free, both male and female slaves. Nobody should keep another Israelite person as their slave."
    },
    {
      "verse": "10",
      "text": "All the officers and the people agreed with the king that they would do this. They would not continue to have male or female slaves. They let them go free, as they had promised."
    },
    {
      "verse": "11",
      "text": "But later, they decided that they would not do that. They took the men and women back to work for them as slaves again. They forced them to do that."
    },
    {
      "verse": "12",
      "text": "Then the Lord said to Jeremiah,"
    },
    {
      "verse": "13",
      "text": "‘The Lord, Israel's God, says this to the people: I made a covenant with your ancestors when I brought them out of Egypt. They had been slaves when they were there."
    },
    {
      "verse": "14",
      "text": "I told them, “When any Hebrew slave has worked for you for six years, you must let them go free. In the seventh year after they sold themselves to you, you must set them free. ” But your ancestors did not listen to me. They did not obey me."
    },
    {
      "verse": "15",
      "text": "But now, you yourselves agreed to do what pleases me. You decided to obey me. You made a serious agreement with me in the temple which is my home. You let your slaves go free."
    },
    {
      "verse": "16",
      "text": "But now you have turned back to your old ways. You have refused to give me honour. You had let your slaves go free, as they wanted to do. But now you have forced them to work for you as your slaves again."
    },
    {
      "verse": "17",
      "text": "So I, the Lord, tell you this: You have not obeyed me. You have not let your Israelite slaves become free men and women. So now I will make you free! Yes, you will be free to let war, famine or disease kill you. People of all the kingdoms in the world will see how disgusting you are."
    },
    {
      "verse": "18",
      "text": "I will punish the people who did not obey the agreement that they made with me. When they made that agreement, they cut a young cow into two pieces and they walked between the pieces. Because they have not obeyed their agreement, I will now cut them into pieces, like the young cow."
    },
    {
      "verse": "19",
      "text": "I will punish the leaders of Judah and Jerusalem, the king's officers and the priests. I will punish all the people of Judah who refused to obey the agreement that they made with me."
    },
    {
      "verse": "20",
      "text": "I will put them under the power of their enemies. Their enemies will kill them. Birds and wild animals will eat their dead bodies as food."
    },
    {
      "verse": "21",
      "text": "I will also put King Zedekiah of Judah and his officers under the power of their enemies. Their enemies will want to kill them. The king of Babylon's army has stopped attacking Jerusalem for a time. But I will put King Zedekiah and his officers under their power."
    },
    {
      "verse": "22",
      "text": "I will command Babylon's army to return to this city. They will fight against it and they will take it. They will burn the city down. I will also cause the other towns of Judah to become heaps of stones. Nobody will live in them any more. ’"
    }
  ],
  "35": [
    {
      "verse": "1",
      "text": "The Lord spoke to Jeremiah when Josiah's son Jehoiakim ruled Judah as king."
    },
    {
      "verse": "2",
      "text": "He said, ‘Go to the place where Rekab's descendants live. Ask them to come to the Lord's temple. Take them into one of the temple's small rooms. Give to them some wine to drink. ’"
    },
    {
      "verse": "3",
      "text": "So I went to meet with Rekab's descendants. They were Jaazaniah, son of Jeremiah and grandson of Habazziniah. I also met with Jaazaniah's brothers and all his sons. Those were all the descendants of Rekab."
    },
    {
      "verse": "4",
      "text": "I took them to the Lord's temple. I took them into the room where the disciples of the prophet Hanan lived. He was the son of Igdaliah. That room was next to the room where the temple officers lived. It was also above the room where Shallum's son Maaseiah lived. He was one of the guards for the doors of the temple."
    },
    {
      "verse": "5",
      "text": "I put some jars of wine and some cups in front of Rekab's descendants. I said to them, ‘Drink some wine. ’"
    },
    {
      "verse": "6",
      "text": "They replied, ‘We do not drink wine. Our ancestor Jonadab, son of Rekab, said to us, “You and your descendants must never drink wine."
    },
    {
      "verse": "7",
      "text": "You must not build houses. You must not plant seed in fields to grow crops. You must not plant vines or have a vineyard. Instead, you must always live in tents. If you live in that way, you will live for a long time as you travel around in the land. ”"
    },
    {
      "verse": "8",
      "text": "We have obeyed all the rules that our ancestor Jonadab gave to us. Our wives and our children have also obeyed them. We have never drunk wine."
    },
    {
      "verse": "9",
      "text": "We have never built houses to be our homes. We have no fields or vineyards and we grow no crops."
    },
    {
      "verse": "10",
      "text": "We have always lived in tents. So we have completely obeyed our ancestor Jonadab. We have done everything that he commanded us to do."
    },
    {
      "verse": "11",
      "text": "But when King Nebuchadnezzar of Babylon attacked our land, we decided to come to Jerusalem. We said, “We must leave here and go to Jerusalem. We must escape from the armies of Babylon and Syria. ” That is why we are now living in Jerusalem. ’"
    },
    {
      "verse": "12",
      "text": "Then the Lord gave this message to Jeremiah."
    },
    {
      "verse": "13",
      "text": "The Lord Almighty, Israel's God, said to him, ‘Go and speak to the people of Judah, including those who live in Jerusalem. Tell them that I, the Lord, say this: “Learn a lesson about how you should obey me!"
    },
    {
      "verse": "14",
      "text": "Rekab's son Jonadab commanded his descendants that they must not drink wine. They have obeyed his command. Even now, they have never drunk wine because their ancestor told them not to do that. But as for you, I have spoken to you very many times and you have not obeyed me!"
    },
    {
      "verse": "15",
      "text": "I have sent my servants the prophets to warn you many times. They told you, ‘You must all stop doing wicked things. Instead, start doing the things that are right. Do not serve other gods and worship them. Then you will continue to live in this land that I gave to you and to your ancestors. ’ But you did not listen to my message. You did not obey me."
    },
    {
      "verse": "16",
      "text": "The descendants of Rekab's son Jonadab obeyed the commands that their ancestor gave to them. But as for you, my people, you have not obeyed me. ”"
    },
    {
      "verse": "17",
      "text": "So the Lord Almighty, Israel's God, says, “Listen to me! I will soon punish the people of Judah and Jerusalem with all the things that I warned them about. I spoke to them, but they did not listen. I called out to them, but they did not answer. So now I will punish them. ” ’"
    },
    {
      "verse": "18",
      "text": "Then Jeremiah said to Rekab's descendants, ‘The Lord Almighty, Israel's God, says, “You have completely obeyed the commands of your ancestor Jonadab. You have done everything that he told you to do. ”"
    },
    {
      "verse": "19",
      "text": "So the Lord Almighty, Israel's God, also says, “There will always be a male descendant of Rekab's son Jonadab who will live to serve me. ” ’"
    }
  ],
  "36": [
    {
      "verse": "1",
      "text": "The Lord spoke to Jeremiah in the fourth year that Josiah's son Jehoiakim ruled Judah as king. He said,"
    },
    {
      "verse": "2",
      "text": "‘Write down on a scroll all the messages that I have spoken to you. Since Josiah was king until now, I have given you messages about Israel, Judah and the other nations. Write them all on a scroll."
    },
    {
      "verse": "3",
      "text": "That will warn the people of Judah about the very bad things that I have decided to do to them. When they hear about it, perhaps they will stop doing the evil things that they have been doing. Then I will forgive their sins and everything wrong that they have done. ’"
    },
    {
      "verse": "4",
      "text": "So Jeremiah told Neriah's son Baruch to come to him. Jeremiah spoke all the words that the Lord had told him to say. Baruch wrote them down on a scroll."
    },
    {
      "verse": "5",
      "text": "Then Jeremiah said to Baruch, ‘The officers will not let me go to the Lord's temple."
    },
    {
      "verse": "6",
      "text": "So you must go to the temple yourself. Go on a special day when people are fasting and they have come from their towns. Read the words that you wrote on the scroll to the people, so that they can all hear them."
    },
    {
      "verse": "7",
      "text": "Perhaps they will ask the Lord to forgive them. Perhaps they will stop doing all the evil things that they have been doing. The Lord is very angry with them and he has warned them that he will punish them. ’"
    },
    {
      "verse": "8",
      "text": "Neriah's son Baruch did everything that the prophet Jeremiah had told him. He went to the Lord's temple. He read the Lord's message that was written on the scroll."
    },
    {
      "verse": "9",
      "text": "That happened in the ninth month of the fifth year that Jehoiakim ruled Judah as king. People from all Judah's towns had come to Jerusalem. They joined with the people of Jerusalem to fast and pray in the Lord's temple."
    },
    {
      "verse": "10",
      "text": "Baruch stood in the temple, at the entrance of the room of Gemariah, the son of Shaphan. Shaphan had been the king's secretary. Gemariah's room was in the higher yard of the temple, near the New Gate. Baruch stood there. He read the Lord's message that Jeremiah had told him to write on the scroll."
    },
    {
      "verse": "11",
      "text": "Micaiah, son of Gemariah and grandson of Shaphan, heard the Lord's message as Baruch read it aloud."
    },
    {
      "verse": "12",
      "text": "Then Micaiah went to the secretary's room in the king's palace. All the king's officers were meeting there. They included: the king's secretary Elishama, Shemaiah's son Delaiah, Akbor's son Elnathan, Shaphan's son Gemariah, and Hananiah's son Zedekiah. All the officers were sitting there."
    },
    {
      "verse": "13",
      "text": "Micaiah told them everything that he had heard when Baruch read the scroll aloud to the people."
    },
    {
      "verse": "14",
      "text": "The officers sent somebody to go and speak to Baruch. They sent Jehudi, son of Nethaniah, and the grandson of Cushi's son, Shelemiah. They told him to say to Baruch, ‘Bring here to us the scroll with the words that you read aloud to the people. ’So Neriah's son Baruch went to them. He took the scroll with him in his hand."
    },
    {
      "verse": "15",
      "text": "The officers said to him, ‘Please sit down and read it to us. ’ So Baruch read it to them."
    },
    {
      "verse": "16",
      "text": "They listened to the words that Baruch had written on the scroll. They looked at each other in fear. They said to Baruch, ‘We must certainly report this to the king. We must tell him about everything that you have read to us. ’"
    },
    {
      "verse": "17",
      "text": "They also asked Baruch, ‘Please tell us how you wrote all these words. Did Jeremiah himself tell you what to write? ’"
    },
    {
      "verse": "18",
      "text": "Baruch said, ‘Yes, he told me what I should write. Then I used ink to write the words on this scroll. ’"
    },
    {
      "verse": "19",
      "text": "The officers said to Baruch, ‘You and Jeremiah must go and hide yourselves. Do not tell anyone where you are. ’"
    },
    {
      "verse": "20",
      "text": "The officers put the scroll into the room of Elishama, the king's secretary, to keep it safe. Then they went to see the king. He was in the palace yard. They reported to him everything that they had heard."
    },
    {
      "verse": "21",
      "text": "Then the king sent Jehudi to fetch the scroll. Jehudi brought the scroll from Elishama's room in the temple. Then he read the message that was written on the scroll. He read it aloud to the king and to all the officers who were standing around him."
    },
    {
      "verse": "22",
      "text": "It was autumn, so the king was sitting in the rooms that he used when it was cold. A fire was burning beside him."
    },
    {
      "verse": "23",
      "text": "Jehudi read a small section of the words that were written on the scroll. As soon as he finished each section, the king cut off that part of the scroll with a knife. He threw each piece of the scroll on the fire. The king continued to do that until fire had burned up the whole scroll."
    },
    {
      "verse": "24",
      "text": "As the king and his officers heard Jehudi read each section of the scroll, it did not make them afraid. None of them tore their clothes because they were upset."
    },
    {
      "verse": "25",
      "text": "Elnathan, Delaiah and Gemariah asked the king very strongly not to burn the scroll. But the king refused to listen to them."
    },
    {
      "verse": "26",
      "text": "Instead, the king told Prince Jerahmeel to go and find the secretary Baruch and the prophet Jeremiah. Jerahmeel went with Azriel's son Seraiah and Abdeel's son Shelemiah to take hold of them. But the Lord had hidden Baruch and Jeremiah."
    },
    {
      "verse": "27",
      "text": "After the king had destroyed the scroll on which Baruch had written Jeremiah's words, the Lord spoke to Jeremiah again."
    },
    {
      "verse": "28",
      "text": "He said, ‘Take another scroll. Write on it everything that was written on the first scroll that King Jehoiakim of Judah burned in the fire."
    },
    {
      "verse": "29",
      "text": "Then tell the king that the Lord says this: “You burned the scroll because you did not like the message that was written on it. It said that the king of Babylon would come to destroy this land, with all its people and animals. You warned Jeremiah that he should not write things like that. ”"
    },
    {
      "verse": "30",
      "text": "So now the Lord says this to you, Jehoiakim, king of Judah: “None of your descendants will rule David's kingdom of Judah. When you die, people will not bury your body. They will throw your dead body on the ground. As it lies there, the sun will burn it in the daytime. At night it will be cold with frost."
    },
    {
      "verse": "31",
      "text": "I will punish you, your descendants and your officers because you have all done wicked things. I will also bring terrible trouble on the people of Jerusalem and all of Judah. I will punish everyone in the way that I promised I would do. I warned them, but they did not listen to me. ” ’"
    },
    {
      "verse": "32",
      "text": "Then Jeremiah took another scroll. He gave it to Neriah's son, Baruch, the secretary. Jeremiah spoke the same message that Baruch had written on the first scroll. That was the scroll that King Jehoiakim of Judah had burned in the fire. They also added more messages that were like the first one."
    }
  ],
  "37": [
    {
      "verse": "1",
      "text": "Josiah's son Zedekiah became king of Judah. King Nebuchadnezzar of Babylon chose Zedekiah to be king instead of Jehoiakim's son, Jeconiah."
    },
    {
      "verse": "2",
      "text": "Zedekiah did not obey the Lord's messages that Jeremiah spoke. The king's officers and the people of Judah did not obey those messages either."
    },
    {
      "verse": "3",
      "text": "King Zedekiah sent a message to the prophet Jeremiah. He sent Shelemiah's son Jehucal, and Maaseiah's son Zephaniah, the priest, to deliver this message: ‘Please pray to the Lord our God for us. ’"
    },
    {
      "verse": "4",
      "text": "Jeremiah was a free man at this time. They had not yet put him in prison. He could go where he wanted among the people."
    },
    {
      "verse": "5",
      "text": "The army of Pharaoh, king of Egypt, had marched out of Egypt. Babylon's soldiers who were attacking Jerusalem heard news about that. So they went away from Jerusalem."
    },
    {
      "verse": "6",
      "text": "Then the Lord gave this message to the prophet Jeremiah:"
    },
    {
      "verse": "7",
      "text": "‘The Lord, Israel's God, says: Go to the king of Judah, who sent you to ask for my help. Tell him, “Pharaoh's army marched out of Egypt to bring you help. But they will turn back and return to their own land, Egypt."
    },
    {
      "verse": "8",
      "text": "Then Babylon's army will return here. They will attack this city. They will take it for themselves. They will burn it completely. ”"
    },
    {
      "verse": "9",
      "text": "The Lord also says, “Do not deceive yourselves. Do not think that Babylon's soldiers will go away and leave you alone. They will not go away!"
    },
    {
      "verse": "10",
      "text": "You might even win the fight against the whole army that is attacking you. There might be only a few of Babylon's soldiers who remain. You might have hurt them so much that they are lying down in their tents. But those weak men would still get up and attack this city. They would completely burn down this city. ” ’"
    },
    {
      "verse": "11",
      "text": "At that time, Babylon's army had gone away from Jerusalem because Pharaoh's army was coming."
    },
    {
      "verse": "12",
      "text": "So Jeremiah started to leave Jerusalem. He wanted to go to the land that belonged to Benjamin's tribe. He wanted to receive his part of the land that belonged to his family."
    },
    {
      "verse": "13",
      "text": "He was going out through the Benjamin gate of the city. Irijah, the son of Shelemiah and grandson of Hananiah, stopped him. Irijah was the captain of the guards at the gate. He took hold of Jeremiah. He said, ‘You are going out of the city to join Babylon's army! ’"
    },
    {
      "verse": "14",
      "text": "Jeremiah said, ‘That is not true! I would never help the soldiers from Babylon. ’ But Irijah would not listen to him. So he took Jeremiah to the king's officers as his prisoner."
    },
    {
      "verse": "15",
      "text": "The officers were very angry with Jeremiah. They beat him with a stick. They put him in a strong room of Jonathan's house. Jonathan was the king's secretary. They had made his house into a place to keep hold of prisoners."
    },
    {
      "verse": "16",
      "text": "They put Jeremiah in a small room in the ground under the house. He stayed there for a long time."
    },
    {
      "verse": "17",
      "text": "Then King Zedekiah told his officers to bring Jeremiah to the palace. When they were alone, the king asked him, ‘Do you have any message for me from the Lord? ’Jeremiah replied, ‘Yes, there is a message. Soldiers will put you under the power of the king of Babylon. ’"
    },
    {
      "verse": "18",
      "text": "Then Jeremiah asked King Zedekiah, ‘Why have your officers put me in prison? Do I deserve that? Have I done something bad against you, your officers or the people of Judah?"
    },
    {
      "verse": "19",
      "text": "Your own prophets said that the king of Babylon would not attack you or the land of Judah. That was a lie, so what have you done to them?"
    },
    {
      "verse": "20",
      "text": "Please help me now, my master, the king. Do not send me back to the house of your secretary Jonathan. If you do that, I will die there. ’"
    },
    {
      "verse": "21",
      "text": "Then King Zedekiah told his officers to put Jeremiah in the palace yard where the guards would watch him. He told them to get bread every day from the bakers in the city and give it to Jeremiah. They should do that until there was no more bread in the city. So they kept Jeremiah as prisoner in the palace yard with the royal guards."
    }
  ],
  "38": [
    {
      "verse": "1",
      "text": "Some of Jerusalem's officers heard the things that Jeremiah had been telling the people. They were Mattan's son Shephatiah, Pashhur's son Gedaliah, Shelemiah's son Jehucal and Malkijah's son Pashhur."
    },
    {
      "verse": "2",
      "text": "They had heard him say this: ‘The Lord says, “Any people who stay in this city will die. War or famine or disease will kill them. But those people who leave the city will not die. If they put themselves under the power of Babylon's soldiers, they will live. ”"
    },
    {
      "verse": "3",
      "text": "The Lord also says, “I will put this city under the power of the King of Babylon's army. They will take it for themselves. ” ’"
    },
    {
      "verse": "4",
      "text": "When the officers heard that, they said to the king, ‘You must punish this man with death. He is making our soldiers who remain in the city afraid. The things that he says are making all the people in the city very afraid. He does not want to help our people. He wants to destroy them. ’"
    },
    {
      "verse": "5",
      "text": "King Zedekiah said to them, ‘You can do to Jeremiah whatever you want to do. I cannot stop you. ’"
    },
    {
      "verse": "6",
      "text": "So the officers took hold of Jeremiah. They put him in a deep hole in the palace yard where the guards were. Prince Malkijah had made the hole to store water. There was no water in the hole, but only mud. They tied ropes around Jeremiah and they slowly dropped him into the hole. Jeremiah fell deep into the mud."
    },
    {
      "verse": "7",
      "text": "There was an officer who served the king in his palace. His name was Ebed-Melech. He came from the country of Ethiopia. He heard the news that some officers had put Jeremiah into the deep hole in the palace yard. At that time the king was sitting as judge at the Benjamin Gate of the city."
    },
    {
      "verse": "8",
      "text": "So Ebed-Melech quickly left the palace. He went to speak to the king. He said to him,"
    },
    {
      "verse": "9",
      "text": "‘My master, the king, those men have done very wicked things to the prophet Jeremiah. They have put him in a deep hole. He will soon die there because there is no food in the city. ’"
    },
    {
      "verse": "10",
      "text": "Then the king gave this command to Ebed-Melech. He said, ‘Take 30 men with you from here. Go and lift Jeremiah out of the deep hole before he dies. ’"
    },
    {
      "verse": "11",
      "text": "So Ebed-Melech took the men with him. He went to a room in the palace where they stored valuable things. He took some old clothes and pieces of cloth from there. He tied them to the end of some ropes. Then he let them drop down into the deep hole where Jeremiah was."
    },
    {
      "verse": "12",
      "text": "He said to Jeremiah, ‘Put these old cloths and clothes under your arms. Then tie the ropes over them so that they do not hurt you. ’ Jeremiah did as Ebed-Melech told him."
    },
    {
      "verse": "13",
      "text": "Then they pulled Jeremiah up out of the deep hole. But Jeremiah still had to stay in the palace yard with the guards."
    },
    {
      "verse": "14",
      "text": "One day, King Zedekiah sent some men to bring Jeremiah to meet with him. They met at the third gate of the Lord's temple. The king said to Jeremiah, ‘I would like to ask you a question. Do not hide anything from me. ’"
    },
    {
      "verse": "15",
      "text": "Jeremiah said to the king, ‘If I give you a true answer, you will surely kill me. If I give you advice, you will not agree. ’"
    },
    {
      "verse": "16",
      "text": "But King Zedekiah made a serious promise to Jeremiah. Nobody else knew about it. He said, ‘I promise you that this is true, as surely as the Lord lives. I promise that I will not kill you. And I will not give you to the men who want to kill you. ’"
    },
    {
      "verse": "17",
      "text": "Then Jeremiah said to Zedekiah, ‘The Lord Almighty, Israel's God, says, “You must put yourself under the power of the king of Babylon's officers. If you do that, you will not die. Your enemies will not burn down this city. You and your family will continue to live."
    },
    {
      "verse": "18",
      "text": "But if you do not agree to be under their power, they will take this city for themselves. They will burn it down. You yourself will become their prisoner. ” ’"
    },
    {
      "verse": "19",
      "text": "King Zedekiah said to Jeremiah, ‘I am afraid to do that. Some of Judah's people have gone out of the city to help Babylon's army. Babylon's officers might give me to them and they will be very cruel to me. ’"
    },
    {
      "verse": "20",
      "text": "Jeremiah answered the king, ‘They will not give you to those people of Judah. Obey the Lord and do as I tell you. Then you will continue to enjoy your life. “Your friends that you trusted to help you have deceived you. They have won against you. Your feet are now deep in the mud and you cannot move. So your friends have gone away and left you. ”"
    },
    {
      "verse": "21",
      "text": "But if you refuse to put yourself under the power of the enemy, a terrible thing will happen to you. The Lord has shown me this in a vision."
    },
    {
      "verse": "22",
      "text": "The enemy's soldiers will bring out all the women in the palace of Judah's king. They will give those women to the king of Babylon's officers. The women will say to you, “Your friends that you trusted to help you have deceived you. They have won against you. Your feet are now deep in the mud and you cannot move. So your friends have gone away and left you. ”"
    },
    {
      "verse": "23",
      "text": "Babylon's soldiers will take all your wives and your children for themselves. You yourself will not escape from them. The king of Babylon will take hold of you as his prisoner. His soldiers will burn down this city. ’"
    },
    {
      "verse": "24",
      "text": "Then Zedekiah said to Jeremiah, ‘Do not tell anyone what we have talked about. If you do tell anyone, you will surely die."
    },
    {
      "verse": "25",
      "text": "My officers may know that we have talked together. They may come to you and ask you, “Tell us what you talked about with the king. Tell us everything that you said. If not, we will kill you. ”"
    },
    {
      "verse": "26",
      "text": "If that happens, tell them, “I was asking the king to help me. I did not want him to send me back to be a prisoner in Jonathan's house. I did not want to die there. ” ’"
    },
    {
      "verse": "27",
      "text": "All the officers did come to Jeremiah to ask him about his meeting with the king. Jeremiah said to them everything that the king had told him to say. Nobody had heard what Jeremiah and the king had really talked about. So the officers stopped asking Jeremiah any more questions."
    },
    {
      "verse": "28",
      "text": "After that, Jeremiah stayed in the palace yard as a prisoner. He stayed there until the day when Babylon's army took Jerusalem for themselves."
    }
  ],
  "39": [
    {
      "verse": "1",
      "text": "This is how the army of King Nebuchadnezzar of Babylon got power over Jerusalem. In the tenth month of the ninth year that Zedekiah had ruled Judah as king, Nebuchadnezzar's army marched to attack Jerusalem. The whole army made their camp around the city."
    },
    {
      "verse": "2",
      "text": "They stayed there until the ninth day of the fourth month of the 11th year that Zedekiah had been king. On that day, Babylon's soldiers broke through the walls of the city."
    },
    {
      "verse": "3",
      "text": "The king of Babylon's officers came into Jerusalem. They sat at the Middle Gate of the city. The officers were Nergal-Sharezer from Samgar, an important officer called Nebo-Sarsekim, and another important officer, also called Nergal-Sharezer. All the other officers of the king of Babylon met with them there."
    },
    {
      "verse": "4",
      "text": "King Zedekiah of Judah and all his soldiers tried to escape when they saw them. They left the city at night. They took a path through the king's garden and went through the gate between the two walls of the city. Then they ran towards the Jordan Valley."
    },
    {
      "verse": "5",
      "text": "But the soldiers of Babylon's army chased after them. They caught Zedekiah on the flat land near Jericho. They took him to King Nebuchadnezzar of Babylon at Riblah, in the region called Hamath. King Nebuchadnezzar decided that Zedekiah was guilty."
    },
    {
      "verse": "6",
      "text": "He decided how he would punish Zedekiah. He told his soldiers to kill all Zedekiah's sons, while Zedekiah watched. Nebuchadnezzar also punished all the important men of Judah with death."
    },
    {
      "verse": "7",
      "text": "Then they cut out Zedekiah's eyes to make him blind. They tied him with chains to take him to Babylon as their prisoner."
    },
    {
      "verse": "8",
      "text": "Babylon's soldiers destroyed the king's palace with fire. They also destroyed the temple and the people's houses in Jerusalem. They knocked down the walls around the city."
    },
    {
      "verse": "9",
      "text": "Nebuzaradan, the captain of King Nebuchadnezzar's guards, took hold of all the people who remained in Jerusalem. He sent them away as prisoners to Babylon. He also sent away the people of Judah who had joined Babylon's army."
    },
    {
      "verse": "10",
      "text": "But Captain Nebuzaradan let some of the very poor people remain in Judah. He gave them some fields and vineyards to take care of."
    },
    {
      "verse": "11",
      "text": "King Nebuchadnezzar of Babylon had commanded Captain Nebuzaradan what to do with Jeremiah."
    },
    {
      "verse": "12",
      "text": "He said, ‘Find Jeremiah and take care of him. Do not hurt him. Help him in any way that he asks you. ’"
    },
    {
      "verse": "13",
      "text": "So Captain Nebuzaradan, an important officer called Nebushazban, Nergal-Sharezer, the king's advisor, and all King Nebuchadnezzar's other officers did that."
    },
    {
      "verse": "14",
      "text": "They sent some men to bring Jeremiah from the palace yard. They told Gedaliah to take care of Jeremiah. Gedaliah was Ahikam's son and Shaphan's grandson. He took Jeremiah to his home. So Jeremiah continued to live among his own people."
    },
    {
      "verse": "15",
      "text": "The Lord had spoken to Jeremiah while he was still a prisoner in the palace yard."
    },
    {
      "verse": "16",
      "text": "The Lord said, ‘Tell the Ethiopian man, Ebed-Melech, this: The Lord Almighty, Israel's God, says, “I will punish this city as I promised to do. I will send terrible trouble instead of help. You will see this when it happens."
    },
    {
      "verse": "17",
      "text": "But I will rescue you at that time. I promise you that. The people that you are afraid of will not take hold of you."
    },
    {
      "verse": "18",
      "text": "I will certainly save you. You will not die in battle. You trusted me, so I will keep your life safe. I, the Lord, say that to you. ” ’"
    }
  ],
  "40": [
    {
      "verse": "1",
      "text": "The Lord spoke to Jeremiah again after Captain Nebuzaradan let him go free at Ramah. Jeremiah was with all the other people of Jerusalem and Judah that Captain Nebuzaradan was taking to Babylon. He was taking them in chains, as his prisoners. But he removed the chains from Jeremiah in Ramah."
    },
    {
      "verse": "2",
      "text": "He said this to Jeremiah when they were alone: ‘The Lord your God warned your people that he would bring trouble to this place."
    },
    {
      "verse": "3",
      "text": "Now he has done that. The Lord has done what he promised to do. He sent this trouble because your people did not obey the Lord. They turned against him."
    },
    {
      "verse": "4",
      "text": "But today I am taking the chains off your hands so that you can go free. You can come with me to Babylon, if you choose to do that. If you come, I will take care of you. But if you do not choose to come with me, you do not have to do that. You are a free man. You may go to any part of the land that you choose. ’"
    },
    {
      "verse": "5",
      "text": "But before Jeremiah turned away from him, Captain Nebuzaradan said, ‘Return to Ahikam's son Gedaliah. The king of Babylon chose him to rule over the towns of Judah. Go and live with Gedaliah, among the people of Judah. Or you may go to any other place that you choose. ’Captain Nebuzaradan gave Jeremiah some food and a gift. Then he let him go."
    },
    {
      "verse": "6",
      "text": "So Jeremiah went to live with Gedaliah in Mizpah. He stayed among the few people who continued to live in Judah."
    },
    {
      "verse": "7",
      "text": "Some officers of Judah's army were living in fields in the country, with their soldiers. They heard news that the king of Babylon had chosen Ahikam's son Gedaliah to have authority over Judah. He ruled over the very poor people of Judah who continued to live there. They were the men, women and children that Babylon's soldiers had not taken away as prisoners."
    },
    {
      "verse": "8",
      "text": "These army officers and their soldiers came to meet with Gedaliah at Mizpah. The officers were: Nethaniah's son Ishmael, Kareah's sons, Johanan and Jonathan, Tanhumeth's son, Seraiah, the sons of Ephai, who came from Netophah, and Jaazaniah, whose father came from Maakah."
    },
    {
      "verse": "9",
      "text": "Gedaliah made a serious promise to them that he would not hurt them. He said, ‘Do not be afraid to serve the soldiers from Babylon. Make your homes here in our land, but agree to serve the king of Babylon. If you do that, you will be successful."
    },
    {
      "verse": "10",
      "text": "I myself will stay here in Mizpah. If Babylon's officers come to visit me, I will speak on your behalf. But you should go and live in the towns that you have taken for yourselves. Then you can eat the things that you grow in your fields. You can pick grapes to make wine and olives to make oil. You can pick dates and figs. You can store these things in jars. ’"
    },
    {
      "verse": "11",
      "text": "There were people of Judah who had run away to live in Moab, Ammon, Edom and other countries. They heard the news that the king of Babylon had let some people continue to live in Judah. They also heard that he had chosen Ahikam's son Gedaliah to be their ruler."
    },
    {
      "verse": "12",
      "text": "As a result, all those people returned to their homes in Judah. On their way, they stopped in Mizpah to meet Gedaliah. When they arrived, they picked a big harvest of dates, figs and grapes to make wine."
    },
    {
      "verse": "13",
      "text": "Kareah's son Johanan came to Mizpah to see Gedaliah. He came with the other army officers who had been hiding in the country."
    },
    {
      "verse": "14",
      "text": "They said to Gedaliah, ‘You should know that King Baalis of Ammon has sent Nethaniah's son Ishmael to kill you. ’ But Gedaliah did not believe them."
    },
    {
      "verse": "15",
      "text": "So while Johanan was in Mizpah, he went to speak to Gedaliah alone. He said, ‘Let me go and kill Nethaniah's son Ishmael. Nobody will know who did it. If I do not kill him, he will surely kill you. Then the people of Judah who are here with you will run away. The few people who still remain in Judah will all disappear. ’"
    },
    {
      "verse": "16",
      "text": "But Ahikam's son Gedaliah, said to Kareah's son Johanan, ‘Do not do that! I do not believe the things that you tell me about Ishmael. ’"
    }
  ],
  "41": [
    {
      "verse": "1",
      "text": "But in the seventh month of the year, Nethaniah's son Ishmael went to Mizpah to visit Ahikam's son Gedaliah. Ishmael was the grandson of Elishama who belonged to the royal family. He had been an officer who served King Zedekiah. Ishmael brought ten of his men with him. They were all eating a meal with Gedaliah in Mizpah."
    },
    {
      "verse": "2",
      "text": "During the meal, Ishmael and his ten men stood up. They took hold of their swords and they killed Gedaliah, Ahikam's son and grandson of Shaphan. Ishmael and his men killed the man that the king of Babylon had chosen to rule Judah."
    },
    {
      "verse": "3",
      "text": "Ishmael also killed the men of Judah and the soldiers of Babylon who were there with Gedaliah."
    },
    {
      "verse": "4",
      "text": "The next day, before anyone knew about Gedaliah's murder,"
    },
    {
      "verse": "5",
      "text": "men arrived in Mizpah. They had come from their homes in Shechem, Shiloh and Samaria. They brought grain offerings and incense to offer to the Lord in his temple. They had cut off their beards, torn their clothes and cut their skin to show that they were very upset."
    },
    {
      "verse": "6",
      "text": "Nethaniah's son Ishmael went out of the city to meet them. He was weeping as he went. When he met the men, he said to them, ‘Come with me to meet Ahikam's son Gedaliah. ’"
    },
    {
      "verse": "7",
      "text": "So they all went into the city. Then Ishmael and his men killed them. They threw the dead bodies into a deep hole which stored water."
    },
    {
      "verse": "8",
      "text": "But ten of the men said, ‘Please do not kill us! We have hidden lots of wheat, barley, olive oil and honey in a field. We will give it to you. ’ So Ishmael let them stay alive. He did not kill them with the other men."
    },
    {
      "verse": "9",
      "text": "Ishmael filled the deep hole with all the dead bodies of the men he had murdered. The hole had been built by King Asa to store water. Asa had dug holes like that to keep the city safe from King Baasha of Israel."
    },
    {
      "verse": "10",
      "text": "Then Ishmael took hold of all the other people in Mizpah who were still alive. He made them his prisoners. These people included the king's daughters, as well as all the other people who remained in Mizpah. Captain Nebuzaradan had said that Ahikam's son Gedaliah would have authority over those people. But Ishmael took them away as his prisoners. He started to take them towards the land of Ammon."
    },
    {
      "verse": "11",
      "text": "Kareah's son Johanan and the army officers who were with him heard news about what had happened. They heard about the wicked things that Nethaniah's son Ishmael had done."
    },
    {
      "verse": "12",
      "text": "So they took all their soldiers to go and fight against Ishmael. They chased after him. They caught him near the large pool at Gibeon."
    },
    {
      "verse": "13",
      "text": "All the people that Ishmael had taken as his prisoners saw Johanan and the officers who were with him. They were very happy to see them."
    },
    {
      "verse": "14",
      "text": "All the people that Ishmael had taken away from Mizpah ran away from him. They went to join Kareah's son Johanan."
    },
    {
      "verse": "15",
      "text": "But Ishmael and eight of his men escaped from Johanan. They went to live among the Ammonite people."
    },
    {
      "verse": "16",
      "text": "Johanan and the army officers who were with him led the people away from Gibeon. Those were the people who were still alive in Mizpah after Ishmael had murdered Gedaliah. Now Johanan and his men had rescued them from Ishmael. Johanan brought those men, women, children, soldiers and palace officers away from Gibeon."
    },
    {
      "verse": "17",
      "text": "They started on the way towards Egypt. They stopped at Geruth Kimham, a town that is near Bethlehem."
    },
    {
      "verse": "18",
      "text": "They were afraid that the soldiers of Babylon would want to kill them. They would be angry because Nethaniah's son Ishmael had killed Ahikam's son Gedaliah. The king of Babylon had chosen Gedaliah to rule Judah."
    }
  ],
  "42": [
    {
      "verse": "1",
      "text": "All the army officers went to speak to the prophet Jeremiah. They included Kareah's son Johanan and Hoshaiah's son Jezaniah. All the people went with them, important people and ordinary people."
    },
    {
      "verse": "2",
      "text": "They said to Jeremiah, ‘Please listen to us. Pray to the Lord your God for those of us who remain alive. You can see that only a few of us remain from the many people that we were before."
    },
    {
      "verse": "3",
      "text": "Please ask the Lord to tell us where we should go. Ask him what we should do. ’"
    },
    {
      "verse": "4",
      "text": "The prophet Jeremiah replied, ‘I agree to do that. I will pray to the Lord your God, as you have asked me to do. I will tell you everything that the Lord says to answer you. I will not hide anything from you. ’"
    },
    {
      "verse": "5",
      "text": "They said to Jeremiah, ‘We promise to do everything that the Lord sends you to say to us. We ask the Lord to listen to our promise. May he punish us if we do not do what we have promised to do."
    },
    {
      "verse": "6",
      "text": "We have asked you to pray to the Lord our God for us. We will obey what he tells us to do. We will obey him whether we like what he tells us, or whether we do not like it. We will obey him because we want to enjoy a good life. ’"
    },
    {
      "verse": "7",
      "text": "Ten days after that, the Lord spoke to Jeremiah."
    },
    {
      "verse": "8",
      "text": "So Jeremiah told Kareah's son Johanan, the other army officers and all the people to come to him. That included everyone, important people and ordinary people."
    },
    {
      "verse": "9",
      "text": "Jeremiah said to them, ‘You sent me to ask the Lord, Israel's God, what you should do. He says this to you:"
    },
    {
      "verse": "10",
      "text": "“You should stay here in the land of Judah. If you do that, I will build you up and make you strong again. I will not knock you down. I will help you to grow in the land, like plants with good roots. I will not pull you up. I have punished you with terrible trouble, and that makes me very sad. So now I will help you."
    },
    {
      "verse": "11",
      "text": "You are afraid of the king of Babylon now, but do not be afraid of him any more. I am with you to help you. I will save you and I will rescue you from his power. I, the Lord, promise you this."
    },
    {
      "verse": "12",
      "text": "I will be kind and I will help you. I will cause the king of Babylon to be kind to you. He will let you return to your own land as your home. ”"
    },
    {
      "verse": "13",
      "text": "You must not refuse to obey this message from the Lord your God. Do not say, “We will not stay here in this land. ”"
    },
    {
      "verse": "14",
      "text": "Do not say, “We refuse to stay here. Instead, we will go to live in Egypt. There, we will not have trouble from wars. We will not hear the noise of trumpets as people fight battles. We will not be hungry because there is no food. ”"
    },
    {
      "verse": "15",
      "text": "If you say those things, then the Lord has a message for you, you people who remain in Judah. The Lord Almighty, Israel's God, says, “If you decide to go and live in Egypt, I will cause you to have the same troubles there."
    },
    {
      "verse": "16",
      "text": "You are afraid of wars here, but I will cause wars to hurt you in Egypt. You worry that you might be hungry here, but I will make you hungry in Egypt. Finally, you will die in Egypt."
    },
    {
      "verse": "17",
      "text": "All the people who decide to go and live in Egypt will die there. War, famine or disease will kill everyone. Nobody will escape from the terrible trouble that I will send. Nobody will remain alive. ”"
    },
    {
      "verse": "18",
      "text": "The Lord Almighty, Israel's God, says, “If you go to Egypt, I will be very angry with you. I punished the people of Jerusalem because I was very angry with them. I will be as angry as that with you, if you go to Egypt. Other people will think that you are disgusting. They will insult you. They will use your name as a curse, because God has cursed you. You will never see this land of Judah again. ”"
    },
    {
      "verse": "19",
      "text": "Listen to me, you people who still remain in Judah. The Lord has said to you, “Do not go to Egypt. ” You must understand that I am now warning you."
    },
    {
      "verse": "20",
      "text": "You made a terrible mistake when you asked me to pray to the Lord your God for you. You told me, “Tell us everything that the Lord our God says, and we will do it. ”"
    },
    {
      "verse": "21",
      "text": "Today I have told you what he said. But you still do not want to obey the Lord. You will not do what he sent me to tell you."
    },
    {
      "verse": "22",
      "text": "So now I tell you this: When you go to the place where you want to live, war, famine or disease will kill you. ’"
    }
  ],
  "43": [
    {
      "verse": "1",
      "text": "Jeremiah finished telling the people the Lord's message to them. He told them everything that the Lord their God had sent him to tell them."
    },
    {
      "verse": "2",
      "text": "Then Hoshaiah's son Azariah and Kareah's son Johanan and some other proud men said to Jeremiah, ‘You are speaking lies! The Lord our God has not sent you to say to us, “You must not go to Egypt to live there. ”"
    },
    {
      "verse": "3",
      "text": "You are telling us what Neriah's son Baruch wants you to say. He wants to hurt us. He wants the soldiers from Babylon to kill us, or to take us as prisoners to Babylon. ’"
    },
    {
      "verse": "4",
      "text": "So Kareah's son Johanan, all the other army officers and all the other people did not obey the Lord's command. They refused to stay in Judah."
    },
    {
      "verse": "5",
      "text": "Instead, Johanan and all the officers led the people away. Those were the people who had returned from all the nations where their enemies had taken them as prisoners. They had returned to their homes in Judah."
    },
    {
      "verse": "6",
      "text": "Now the army officers led them away. They also took the men, women and children that Captain Nebuzaradan had allowed to remain with Gedaliah. They included the king's daughters. (Gedaliah was Ahikam's son and Shaphan's grandson. ) They took the prophet Jeremiah and Neriah's son Baruch with them."
    },
    {
      "verse": "7",
      "text": "The people went to Egypt because they did not obey the Lord. They went as far as the city of Tahpanhes."
    },
    {
      "verse": "8",
      "text": "When they arrived in Tahpanhes, the Lord spoke to Jeremiah. Those who should become ill and die will die. Those who should go away as prisoners will go away as prisoners. Those who should die in war will die in war."
    },
    {
      "verse": "9",
      "text": "He said, ‘Choose some large stones and take them to Pharaoh's palace that is here in Tahpanhes. Bury the stones under the path at the entrance of the palace. Do it while the people of Judah are watching you."
    },
    {
      "verse": "10",
      "text": "Then say to the people, “The Lord Almighty, Israel's God, says this: I will call for my servant, King Nebuchadnezzar of Babylon, to come here. He will put his throne on the path over these stones that I have hidden. They will put up a royal tent for him to sit under."
    },
    {
      "verse": "11",
      "text": "He will come here and he will attack Egypt. Those who should become ill and die will die. Those who should go away as prisonerswill go away as prisoners. Those who should die in war will die in war."
    },
    {
      "verse": "12",
      "text": "He will burn the temples of Egypt's gods with fire. He will burn their gods or he will carry them away. He will take everything that he wants from Egypt. He will return home in good health."
    },
    {
      "verse": "13",
      "text": "He will knock down the pillars of the temple where people worship their sun god. He will destroy all the temples of Egypt's gods. ” ’"
    }
  ],
  "44": [
    {
      "verse": "1",
      "text": "The Lord spoke to Jeremiah about the people of Judah who were now living in Egypt. They were living in Migdol, Tahpanhes, Memphis and places in the south part of Egypt."
    },
    {
      "verse": "2",
      "text": "This was the Lord's message to them:‘The Lord Almighty, Israel's God, says, “You saw the great trouble that I sent to the people of Jerusalem and all the towns of Judah. Their towns have become heaps of stones and nobody lives in them."
    },
    {
      "verse": "3",
      "text": "That happened because of the wicked things that the people did in those places. They offered sacrifices to other gods. They worshipped gods that they never knew before. You and your ancestors did not know those gods either. That made me very angry."
    },
    {
      "verse": "4",
      "text": "Many times I sent my servants the prophets to speak to them. They warned them, ‘Do not do this disgusting thing that the Lord hates! ’"
    },
    {
      "verse": "5",
      "text": "But the people there did not listen to my message. They refused to obey me. They did not stop doing wicked things. They did not stop offering sacrifices to other gods."
    },
    {
      "verse": "6",
      "text": "So I became very angry with the people of Judah and Jerusalem. I sent them terrible trouble, like a fire that burned their towns and their streets. That is why their towns have become heaps of stones, as they still are today. ”"
    },
    {
      "verse": "7",
      "text": "Now the Lord God Almighty, Israel's God, says, “You are causing more trouble for yourselves. Why are you doing that? All the men, women, children and babies will disappear from Judah. None of your people will remain alive."
    },
    {
      "verse": "8",
      "text": "You continue to make me angry because of the things that you are doing. You are offering sacrifices to the gods of Egypt, where you now live. As a result, you will destroy yourselves. The people of all the other nations will use your name as a curse. They will all laugh at you."
    },
    {
      "verse": "9",
      "text": "Do not forget about all the wicked things that your ancestors did in the towns of Judah and in the streets of Jerusalem. I punished them, as well as their kings and their kings' wives. And I punished you and your wives too."
    },
    {
      "verse": "10",
      "text": "Even now your people are still proud. They have not respected my authority. They have not obeyed the laws and commands that I gave to you and to your ancestors. ”"
    },
    {
      "verse": "11",
      "text": "So the Lord Almighty, Israel's God, says, “Listen to me! I will certainly cause you to have great trouble. I will destroy all Judah's people."
    },
    {
      "verse": "12",
      "text": "I will remove the people who remained in Judah and who decided to come here to live in Egypt. They will all die here. War or famine will kill them. All of them will die here in Egypt, important people and ordinary people. Other people will think that they are disgusting. They will insult them. They will use their name as a curse, because God has cursed them."
    },
    {
      "verse": "13",
      "text": "I will punish the people who have come to live in Egypt. War, famine or disease will kill them, in the way that I punished the people of Jerusalem."
    },
    {
      "verse": "14",
      "text": "None of the people who remained in Judah and who came to live here in Egypt will escape. They will not remain alive to return to Judah. They may want very much to return, but only a few will be able to run away and go home. ” ’"
    },
    {
      "verse": "15",
      "text": "A large crowd of Judah's people listened to Jeremiah. They came from the places where they now lived in the north and the south of Egypt. Some men were there who knew that their wives were offering sacrifices to other gods. Those men and their wives said to Jeremiah,"
    },
    {
      "verse": "16",
      "text": "‘We do not believe that your message really comes from the Lord."
    },
    {
      "verse": "17",
      "text": "So we will continue to do what we have promised to do. We will make sacrifices to the Queen of Heaven. We will pour out drink offerings to her. That is what our ancestors, our kings and our leaders did when we lived in Jerusalem and in the other towns of Judah. When we did that, we had plenty of food to eat. We enjoyed a good life and we had no troubles."
    },
    {
      "verse": "18",
      "text": "But since we stopped offering sacrifices to the Queen of Heaven, we have not had those good things. War and famine have been killing our people. ’"
    },
    {
      "verse": "19",
      "text": "The women said, ‘It is true that we offered sacrifices and drink offerings to the Queen of Heaven. We also made cakes that were like her image. But our husbands knew what we were doing and they helped us. ’"
    },
    {
      "verse": "20",
      "text": "Then Jeremiah said this to all those men and women who had answered him:"
    },
    {
      "verse": "21",
      "text": "‘The Lord saw everything that you were doing. You must surely realize that! He knew about the things that you, your ancestors, your kings, your leaders and all the people were doing. He remembered all the sacrifices that you offered to other gods in the towns of Judah and in the streets of Jerusalem."
    },
    {
      "verse": "22",
      "text": "Finally, he had to punish you for the wicked and disgusting things that you were doing. Because of that, your land has become an empty place, like a desert. Its towns are heaps of stones where nobody lives. People use its name as a curse."
    },
    {
      "verse": "23",
      "text": "That happened because you have offered sacrifices to other gods. You have done many sins against the Lord. You have refused to obey him. You have not obeyed his laws, his teaching or his commands. That is why all this trouble has happened to you now. ’"
    },
    {
      "verse": "24",
      "text": "Then Jeremiah said this to all the people, including the women:‘Listen to the Lord's message, all you people of Judah who are now living in Egypt."
    },
    {
      "verse": "25",
      "text": "The Lord God Almighty, Israel's God, says, “You and your wives have certainly done the things that you said you would do. You said, ‘We will continue to do what we have promised to do. We will make sacrifices to the Queen of Heaven. We will pour out drink offerings to her. ’ So do all those things that you promised to do! ”"
    },
    {
      "verse": "26",
      "text": "But listen to the Lord's message to all you people of Judah who are living in Egypt. The Lord says, “I now promise this to you, with the authority of my own name. None of you who live in Egypt will ever use my name again when you make a promise. You will not say, ‘I promise you I will do this, as surely as the Lord God lives. ’"
    },
    {
      "verse": "27",
      "text": "Listen to me! I will choose to hurt you and not to help you. War or famine will kill all the people of Judah who are living in Egypt. None of them will remain alive."
    },
    {
      "verse": "28",
      "text": "But a few of them will escape death and return to Judah from Egypt. They will be very few people. Then all the people of Judah who came to live in Egypt will know who speaks the truth. Do I speak the truth, or do they speak the truth? I do! ”"
    },
    {
      "verse": "29",
      "text": "The Lord also says, “I will show you that I will surely punish you in this place. I will tell you something that will soon happen. Then you will know that my promise to punish you will certainly become true."
    },
    {
      "verse": "30",
      "text": "I tell you now that I will put Hophra, king of Egypt, under the power of his enemies, who want to kill him. That is the same thing that I did to King Zedekiah of Judah. I put him under the power of King Nebuchadnezzar of Babylon, who wanted to kill him. ” ’"
    }
  ],
  "45": [
    {
      "verse": "1",
      "text": "Baruch wrote down on a scroll the words that Jeremiah told him to write. That happened in the fourth year that Josiah's son, Jehoiakim, ruled Judah as king. At that time, Jeremiah said to Baruch,"
    },
    {
      "verse": "2",
      "text": "‘The Lord, Israel's God, says this to you, Baruch:"
    },
    {
      "verse": "3",
      "text": "You said, “I have terrible trouble! I have a lot of pain, and the Lord has also made me very sad. I am so upset that I have become very weak. I cannot rest at all. ”"
    },
    {
      "verse": "4",
      "text": "But the Lord says this to you, Baruch: “I will soon knock down the things that I have built. I will pull out of the ground the things that I have planted. I will do that everywhere in the land."
    },
    {
      "verse": "5",
      "text": "If you want to become famous and important, do not hope for that to happen. I will send great trouble to all the people on the earth. But I promise that I will keep your life safe, wherever you go. ” That is what the Lord says. ’"
    }
  ],
  "46": [
    {
      "verse": "1",
      "text": "The Lord gave the prophet Jeremiah messages about the nations."
    },
    {
      "verse": "2",
      "text": "This is the message about Egypt. Nebuchadnezzar, king of Babylon, and his army fought against the army of Pharaoh Necho, king of Egypt. Babylon's army won the battle against Egypt's army at Carchemish on the Euphrates river. That happened in the fourth year that Josiah's son Jehoiakim ruled Judah as king. Nebuchadnezzar, king of Babylon, and his army fought against the army of Pharaoh Necho, king of Egypt. Babylon's army won the battle against Egypt's army at Carchemish on the Euphrates river. That happened in the fourth year that Josiah's son Jehoiakim ruled Judah as king."
    },
    {
      "verse": "3",
      "text": "‘Get ready to march to the battle! Pick up your shields and your weapons. Pick up your shields and your weapons."
    },
    {
      "verse": "4",
      "text": "Prepare your horses and sit on them. Put on your helmets and be ready to fight. Make your spears sharp. Put on your armour! ’ Put on your helmets and be ready to fight. Make your spears sharp. Put on your armour! ’"
    },
    {
      "verse": "5",
      "text": "The Lord says, ‘But I see this: The soldiers are afraid and they are running away! They cannot win the fight. Terror is everywhere around them. They do not turn to look behind them. They run away as fast as they can. ‘But I see this: The soldiers are afraid and they are running away! They cannot win the fight. Terror is everywhere around them. They do not turn to look behind them. They run away as fast as they can."
    },
    {
      "verse": "6",
      "text": "But none of them can run fast enough. Even the strongest soldiers cannot escape. In the north, beside the River Euphrates, they fall down to the ground. Even the strongest soldiers cannot escape. In the north, beside the River Euphrates, they fall down to the ground."
    },
    {
      "verse": "7",
      "text": "A nation is rising up, like the great waters of the Nile river. Who is this nation? Who is this nation?"
    },
    {
      "verse": "8",
      "text": "Egypt is rising like the waters of the Nile. Its streams of water quickly pour out over the earth. Egypt says, “I will rise up and I will cover the earth. I will destroy cities. I will kill the people who live in them. ” Its streams of water quickly pour out over the earth. Egypt says, “I will rise up and I will cover the earth. I will destroy cities. I will kill the people who live in them. ”"
    },
    {
      "verse": "9",
      "text": "So ride your horses quickly into the battle! Drive your chariots as fast as they will go! Tell your soldiers to march forward into the battle. Send your soldiers of Ethiopia and Libya who carry shields. Send your soldiers of Lydia who have bows and arrows. Drive your chariots as fast as they will go! Tell your soldiers to march forward into the battle. Send your soldiers of Ethiopia and Libya who carry shields. Send your soldiers of Lydia who have bows and arrows."
    },
    {
      "verse": "10",
      "text": "But it is the Lord God Almighty who will win! It is the day when he will punish his enemies. His sword will completely destroy them, like a hungry person who cannot stop eating! His sword will cause a lot of blood to pour out. The Lord God Almighty will accept his enemies as a sacrifice. That is what will happen in the northern land beside the Euphrates river. It is the day when he will punish his enemies. His sword will completely destroy them, like a hungry person who cannot stop eating! His sword will cause a lot of blood to pour out. The Lord God Almighty will accept his enemies as a sacrifice. That is what will happen in the northern land beside the Euphrates river."
    },
    {
      "verse": "11",
      "text": "Dear people of Egypt, go to Gilead and find medicine to make you well. But that will not help you. There is no medicine that will make you better. go to Gilead and find medicine to make you well. But that will not help you. There is no medicine that will make you better."
    },
    {
      "verse": "12",
      "text": "The other nations will see that you are ashamed. All over the earth, people will hear you as you weep. As your soldiers run from the battle, they will fall over each other. They will fall to the ground together. ’ All over the earth, people will hear you as you weep. As your soldiers run from the battle, they will fall over each other. They will fall to the ground together. ’"
    },
    {
      "verse": "13",
      "text": "The Lord gave this message to the prophet Jeremiah about King Nebuchadnezzar of Babylon. He said that Nebuchadnezzar would come to attack Egypt."
    },
    {
      "verse": "14",
      "text": "‘Shout this message everywhere in Egypt. Let people hear it in Migdol, Memphis and in Tahpanhes. “Get ready to fight against your enemies! They are already killing the people all around you. ” Let people hear it in Migdol, Memphis and in Tahpanhes. “Get ready to fight against your enemies! They are already killing the people all around you. ”"
    },
    {
      "verse": "15",
      "text": "Your brave soldiers will fall. They will lie flat on the ground. They cannot stand and fight because the Lord will knock them down. They will lie flat on the ground. They cannot stand and fight because the Lord will knock them down."
    },
    {
      "verse": "16",
      "text": "They will continue to fall over each other. They will say to each other, “Get up! We must return to our homes where our own people live. We must escape from our enemies, who want to kill us. ” They will say to each other, “Get up! We must return to our homes where our own people live. We must escape from our enemies, who want to kill us. ”"
    },
    {
      "verse": "17",
      "text": "When they get back home, they will say, “The king of Egypt is only a loud noise. He could not win when he had the chance. ” ’ “The king of Egypt is only a loud noise. He could not win when he had the chance. ” ’"
    },
    {
      "verse": "18",
      "text": "The Lord Almighty is the great King. He says, ‘I promise you, as surely as I live, that a powerful army will come to fight against you! They will look as great as Tabor looks among the other mountains. They will seem like Carmel mountain that stands beside the sea. ‘I promise you, as surely as I live, that a powerful army will come to fight against you! They will look as great as Tabor looks among the other mountains. They will seem like Carmel mountain that stands beside the sea."
    },
    {
      "verse": "19",
      "text": "You dear people of Egypt, be ready to travel as prisoners to a foreign land! Your enemy will destroy Memphis city. It will become a heap of stones where nobody lives. Your enemy will destroy Memphis city. It will become a heap of stones where nobody lives."
    },
    {
      "verse": "20",
      "text": "Egypt is like a beautiful young cow. But an army from the north will attack her, like a crowd of flies that bite. But an army from the north will attack her, like a crowd of flies that bite."
    },
    {
      "verse": "21",
      "text": "Egypt has paid soldiers from other countries to help her. But they are like fat calves that are too weak to fight. They will not stand and fight, but they will turn and run away. Yes, the day of Egypt's punishment has arrived! Their enemy has come to destroy them. But they are like fat calves that are too weak to fight. They will not stand and fight, but they will turn and run away. Yes, the day of Egypt's punishment has arrived! Their enemy has come to destroy them."
    },
    {
      "verse": "22",
      "text": "Egypt's people will run away, like a snake along the ground. The enemy's strong army will march forward. They will attack Egypt with axes, like men who cut down trees. The enemy's strong army will march forward. They will attack Egypt with axes, like men who cut down trees."
    },
    {
      "verse": "23",
      "text": "Egypt's soldiers are as many as the trees in a great forest. But the enemy's soldiers will cut them down. Their army is like a hungry crowd of locusts. They are too many to count. But the enemy's soldiers will cut them down. Their army is like a hungry crowd of locusts. They are too many to count."
    },
    {
      "verse": "24",
      "text": "The people of Egypt will be ashamed. They will be under the power of the people from the north. ’That is what the Lord says. They will be under the power of the people from the north. ’ That is what the Lord says."
    },
    {
      "verse": "25",
      "text": "The Lord Almighty, Israel's God, also says, ‘Now I will punish Amon, the god of Thebes city, and the other gods of Egypt. I will also punish Pharaoh, the king of Egypt, and Egypt's other rulers. I will punish Egypt's people and everyone who trusts in Pharoah's power."
    },
    {
      "verse": "26",
      "text": "I will put them under the power of King Nebuchadnezzar and his army, who want to kill them. But in later years, people will again live in Egypt, as they did before. ’ That is what the Lord says."
    },
    {
      "verse": "27",
      "text": "‘My servants, descendants of Jacob, do not be afraid. People of Israel, do not be upset. You have been prisoners in countries far away. But I will rescue you and your descendants. You will return to your own land and you will live in peace. Jacob's descendants will be safe and nobody will make them afraid. People of Israel, do not be upset. You have been prisoners in countries far away. But I will rescue you and your descendants. You will return to your own land and you will live in peace. Jacob's descendants will be safe and nobody will make them afraid."
    },
    {
      "verse": "28",
      "text": "So do not be afraid, descendants of my servant Jacob. I am with you to help you. I may completely destroy all the nations where I send you to live. But I will never completely destroy you. I will certainly punish you, to teach you what is right. But I will do that in a fair way. ’That is what the Lord says."
    }
  ],
  "47": [
    {
      "verse": "1",
      "text": "The Lord gave this message to the prophet Jeremiah before Pharaoh and the army of Egypt attacked Gaza. The Lord said this about the Philistines:"
    },
    {
      "verse": "2",
      "text": "‘Look at what is happening! Armies in the north are rising like a flood of water. They will pour out from there like a great river. They will cover the whole land and everything in it. They will destroy the cities and the people who live in them. People will shout for help. Everyone who lives there will cry with pain. Armies in the north are rising like a flood of water. They will pour out from there like a great river. They will cover the whole land and everything in it. They will destroy the cities and the people who live in them. People will shout for help. Everyone who lives there will cry with pain."
    },
    {
      "verse": "3",
      "text": "They will hear the sound of their enemies' horsesand the loud noises of their chariots. Fathers will not turn back to save their children, because fear has made them weak. and the loud noises of their chariots. Fathers will not turn back to save their children, because fear has made them weak."
    },
    {
      "verse": "4",
      "text": "The time has come when the Lord will destroy all the Philistines. None of them will remain to give help to Tyre and Sidon. The Lord is ready to destroy the Philistines who remain. Those are the people who came from the island of Crete. None of them will remain to give help to Tyre and Sidon. The Lord is ready to destroy the Philistines who remain. Those are the people who came from the island of Crete."
    },
    {
      "verse": "5",
      "text": "The people of Gaza will cut the hair off their headsbecause they are so upset. In Ashkelon, nobody will say a word. You Philistines who live near the sea and are still alive, will you continue to cut your bodies? because they are so upset. In Ashkelon, nobody will say a word. You Philistines who live near the sea and are still alive, will you continue to cut your bodies?"
    },
    {
      "verse": "6",
      "text": "You shout to the Lord, “How long will you attack us with your sword? Please stop killing us! Put your sword away! ” Please stop killing us! Put your sword away! ”"
    },
    {
      "verse": "7",
      "text": "But the Lord has commanded his sword to kill. So it cannot rest! The Lord has commanded his sword to attack Ashkelonand the people who live on the coast of the sea. ’"
    }
  ],
  "48": [
    {
      "verse": "1",
      "text": "The Lord Almighty, Israel's God, spoke this message about Moab:‘Nebo city is in terrible trouble! It will soon become a heap of stones. The people of Kiriathaim city will be ashamed. Its enemies will take it for themselves. They will knock down its strong buildings, and its people will be ashamed. ‘Nebo city is in terrible trouble! It will soon become a heap of stones. The people of Kiriathaim city will be ashamed. Its enemies will take it for themselves. They will knock down its strong buildings, and its people will be ashamed."
    },
    {
      "verse": "2",
      "text": "People will no longer praise Moab. In Heshbon, Moab's enemies will decide how to destroy the nation. They will say, “We must completely destroy Moab! ”The town of Madmen will become silent, as a great army chases out the people. In Heshbon, Moab's enemies will decide how to destroy the nation. They will say, “We must completely destroy Moab! ” The town of Madmen will become silent, as a great army chases out the people."
    },
    {
      "verse": "3",
      "text": "The people of Horonaim will shout for help, because a strong army is destroying them. because a strong army is destroying them."
    },
    {
      "verse": "4",
      "text": "Moab will come to an end! Its children will cry loudly. Its children will cry loudly."
    },
    {
      "verse": "5",
      "text": "They will go up the hill to Luhith. They will weep as they go. As they go down the road towards Horonaim, they will cry about their town that the enemy is destroying. They will weep as they go. As they go down the road towards Horonaim, they will cry about their town that the enemy is destroying."
    },
    {
      "verse": "6",
      "text": "People say, “Run away to save your lives! Go and live in the desert. ” Go and live in the desert. ”"
    },
    {
      "verse": "7",
      "text": "People of Moab, you trusted your riches and your skills to save you. Because of that, your enemies will catch you. They will even take your god Chemosh away as prisoner, together with his priests and officers. Because of that, your enemies will catch you. They will even take your god Chemosh away as prisoner, together with his priests and officers."
    },
    {
      "verse": "8",
      "text": "Your cruel enemy will attack every town. No town or city will escape. The enemy will destroy every place in the valley, and every place on the high ground. They will become heaps of stones. I, the Lord, tell you this! No town or city will escape. The enemy will destroy every place in the valley, and every place on the high ground. They will become heaps of stones. I, the Lord, tell you this!"
    },
    {
      "verse": "9",
      "text": "Dig a grave to bury Moab! Its land will become like a desert. Its cities will become heaps of stones. Nobody will live in them. ’ Its land will become like a desert. Its cities will become heaps of stones. Nobody will live in them. ’"
    },
    {
      "verse": "10",
      "text": "The Lord will curse anyone who refuses to do his work! He will punish anyone who does not use his sword to kill his enemies!"
    },
    {
      "verse": "11",
      "text": "The Lord said, ‘Moab's people have lived in peace since they first became a nation. No enemy has taken them away to a foreign land as their prisoners. They have been like the wine in a bottle that nobody has moved. Nobody has poured it into another bottle, so its taste and smell have never changed. Moab has always been the same."
    },
    {
      "verse": "12",
      "text": "But the time will soon come when I will send people to attack Moab. They will pour out Moab's people like somebody pours wine out of a bottle. They will pour out all the wine so that the bottles are empty. And they will break the bottles into pieces!"
    },
    {
      "verse": "13",
      "text": "Then Moab's people will be ashamed because their god Chemosh has not saved them. They will be like the Israelites who trusted in their idol at Bethel and they became ashamed."
    },
    {
      "verse": "14",
      "text": "Men of Moab, you should no longer say, “We are brave soldiers who know how to fight. ” “We are brave soldiers who know how to fight. ”"
    },
    {
      "verse": "15",
      "text": "I am the King, the Lord Almighty, and I tell you this: The enemy will soon destroy Moab and its cities. They will kill its strongest young men. The enemy will soon destroy Moab and its cities. They will kill its strongest young men."
    },
    {
      "verse": "16",
      "text": "Moab will soon come to an end. Terrible trouble will quickly destroy it. Terrible trouble will quickly destroy it."
    },
    {
      "verse": "17",
      "text": "You nations that live around Moab, you know how famous it has been. But now you must weep for it. Say, “Moab's royal power is finished! They no longer have great power to rule! ” you know how famous it has been. But now you must weep for it. Say, “Moab's royal power is finished! They no longer have great power to rule! ”"
    },
    {
      "verse": "18",
      "text": "You people who live in Dibon must stop being proud. Come down from the places where people give you honour. Sit on the ground in the dirt. Moab's cruel enemy has arrived. They will cause your strong buildings to become heaps of stones. Come down from the places where people give you honour. Sit on the ground in the dirt. Moab's cruel enemy has arrived. They will cause your strong buildings to become heaps of stones."
    },
    {
      "verse": "19",
      "text": "You people who live in Aroer, stand beside the road and watch. Ask the people who are running away what has happened. stand beside the road and watch. Ask the people who are running away what has happened."
    },
    {
      "verse": "20",
      "text": "They will reply, “The enemy has won against Moaband its people are ashamed. So weep and cry out! Stand beside the Arnon river and tell the news. Tell people that the enemy has destroyed Moab. ” and its people are ashamed. So weep and cry out! Stand beside the Arnon river and tell the news. Tell people that the enemy has destroyed Moab. ”"
    },
    {
      "verse": "21",
      "text": "The Lord has judged the cities on the high ground and he will soon punish them: Holon, Jahzah and Mephaath,"
    },
    {
      "verse": "22",
      "text": "Dibon, Nebo and Beth-Diblathaim,"
    },
    {
      "verse": "23",
      "text": "Kiriathaim, Beth-Gamul and Beth-Meon,"
    },
    {
      "verse": "24",
      "text": "Kerioth and Bozrah. He will punish all the towns of Moab, near or far away."
    },
    {
      "verse": "25",
      "text": "Moab has lost its power. Its strength has finished. ’That is what the Lord says. That is what the Lord says."
    },
    {
      "verse": "26",
      "text": "‘Moab has turned against me. So my anger will make him like a person who is drunk. He will lie down in the place where he has been sick. People will laugh at him. So my anger will make him like a person who is drunk. He will lie down in the place where he has been sick. People will laugh at him."
    },
    {
      "verse": "27",
      "text": "You people of Moab laughed at my people, the Israelites. Why did you insult them? You said that they were no better than a group of robbers. Why did you insult them? You said that they were no better than a group of robbers."
    },
    {
      "verse": "28",
      "text": "Now you must all leave your towns. Go and live among the rocks. Live like doves that make their nests high up among the rocks. Go and live among the rocks. Live like doves that make their nests high up among the rocks."
    },
    {
      "verse": "29",
      "text": "We have heard that Moab's people are very proud. They think that they are better than everyone else. We know how much they boast. ’ They think that they are better than everyone else. We know how much they boast. ’"
    },
    {
      "verse": "30",
      "text": "The Lord says, ‘I know about Moab's proud thoughts. But their pride is false. Whatever they do, it will be useless. ‘I know about Moab's proud thoughts. But their pride is false. Whatever they do, it will be useless."
    },
    {
      "verse": "31",
      "text": "So I am sad for Moab. I am crying for all their people. I weep for the people of Kir-Heres. I weep for the people of Kir-Heres."
    },
    {
      "verse": "32",
      "text": "I weep for the vines of Sibmah, more than Jazer weeps. The branches of those vines reached across the sea as far as Jazer. But the cruel enemy will destroy all the fruit that grows on your vines and trees. The branches of those vines reached across the sea as far as Jazer. But the cruel enemy will destroy all the fruit that grows on your vines and trees."
    },
    {
      "verse": "33",
      "text": "People will no longer be happy in the land where this fruit grows. I will stop them making wine from their grapes. They will not stamp on their grapes and shout with joy. Instead, the shouts will be shouts about trouble. I will stop them making wine from their grapes. They will not stamp on their grapes and shout with joy. Instead, the shouts will be shouts about trouble."
    },
    {
      "verse": "34",
      "text": "In Heshbon and Elealeh people cry out because of their pain. The noise reaches as far as Jahaz. It reaches from Zoar to Horonaim and Eglath-Shelishiyah. Even the Nimrim river has become dry. ’ The noise reaches as far as Jahaz. It reaches from Zoar to Horonaim and Eglath-Shelishiyah. Even the Nimrim river has become dry. ’"
    },
    {
      "verse": "35",
      "text": "The Lord says this:‘I will remove the people of Moab who worship other gods. They offer sacrifices to themand they burn incense at their altars. ‘I will remove the people of Moab who worship other gods. They offer sacrifices to them and they burn incense at their altars."
    },
    {
      "verse": "36",
      "text": "So I am very sad for the people of Moab. I weep like a flute that plays a funeral song. I am sad for the people of Kir-Heres, because all their riches will disappear. I weep like a flute that plays a funeral song. I am sad for the people of Kir-Heres, because all their riches will disappear."
    },
    {
      "verse": "37",
      "text": "All the men will be very upset. They will cut the hair off their heads and their faces. They will use knives to cut their hands. They will wear sackcloth as their clothes. They will cut the hair off their heads and their faces. They will use knives to cut their hands. They will wear sackcloth as their clothes."
    },
    {
      "verse": "38",
      "text": "People are standing on the roofs of their houses. They are standing in the streets. They are all crying and weeping. They are sad because I have destroyed Moab. I have broken it in pieces, like a jar that I no longer want. ’That is what the Lord says. They are standing in the streets. They are all crying and weeping. They are sad because I have destroyed Moab. I have broken it in pieces, like a jar that I no longer want. ’ That is what the Lord says."
    },
    {
      "verse": "39",
      "text": "‘Yes, Moab will be like a broken jar. Its people will weep with loud voices. They will turn away because they are ashamed. All the nations around there will laugh at Moab. They will see the terrible trouble that it has received. ’ Its people will weep with loud voices. They will turn away because they are ashamed. All the nations around there will laugh at Moab. They will see the terrible trouble that it has received. ’"
    },
    {
      "verse": "40",
      "text": "The Lord says, ‘Look at the enemy that suddenly arrives! It comes like an eagle that flies down to catch its food. ‘Look at the enemy that suddenly arrives! It comes like an eagle that flies down to catch its food."
    },
    {
      "verse": "41",
      "text": "The enemy will take Moab's towns and its strong buildings. Moab's soldiers will be afraid, like a woman who will soon give birth. Moab's soldiers will be afraid, like a woman who will soon give birth."
    },
    {
      "verse": "42",
      "text": "Moab has been proud and it has turned against the Lord. So they will no longer be a nation. ’ So they will no longer be a nation. ’"
    },
    {
      "verse": "43",
      "text": "The Lord says this:‘People of Moab, there will be danger, deep holes and traps that are ready to catch you! ‘People of Moab, there will be danger, deep holes and traps that are ready to catch you!"
    },
    {
      "verse": "44",
      "text": "Anyone who runs away from danger, will fall into a deep hole. And a trap will catch anyone who climbs out of the deep hole. Yes, the time will soon come when I will punish Moab's people. And a trap will catch anyone who climbs out of the deep hole. Yes, the time will soon come when I will punish Moab's people."
    },
    {
      "verse": "45",
      "text": "People will run away to Heshbon to be safe. They will be helpless as they stand outside its walls. Flames of fire will come out from Heshbon, the city where King Sihon once ruled. It will burn as far as Moab's borders. It will destroy those proud people who love to fight. They will be helpless as they stand outside its walls. Flames of fire will come out from Heshbon, the city where King Sihon once ruled. It will burn as far as Moab's borders. It will destroy those proud people who love to fight."
    },
    {
      "verse": "46",
      "text": "It will be very bad for you, you people of Moab! The enemy will destroy you people who worship Chemosh. They will take away your sons and your daughters. They will take them as prisoners to a foreign land. The enemy will destroy you people who worship Chemosh. They will take away your sons and your daughters. They will take them as prisoners to a foreign land."
    },
    {
      "verse": "47",
      "text": "But one day I will cause Moab to be strong again. ’That is what the Lord says. That is the end of the Lord's message against Moab."
    }
  ],
  "49": [
    {
      "verse": "1",
      "text": "The Lord gave this message about the people of Ammon:‘There are plenty of Israel's descendants who are still alive. They are strong enough to live in the land that is their home. So why have people who worship the god Molech moved in to the land of Gad's tribe? They should not be living in towns that belong to Gad's people. ’ ‘There are plenty of Israel's descendants who are still alive. They are strong enough to live in the land that is their home. So why have people who worship the god Molech moved in to the land of Gad's tribe? They should not be living in towns that belong to Gad's people. ’"
    },
    {
      "verse": "2",
      "text": "The Lord says, ‘A time will come when an army attacks Rabbah, Ammon's capital city. Its people will hear the noise of a battle. The city will become a big heap of stones. Fire will destroy the villages around it. Then the Israelites will chase out the people who had taken their land from them. ’That is what the Lord says. ‘A time will come when an army attacks Rabbah, Ammon's capital city. Its people will hear the noise of a battle. The city will become a big heap of stones. Fire will destroy the villages around it. Then the Israelites will chase out the people who had taken their land from them. ’ That is what the Lord says."
    },
    {
      "verse": "3",
      "text": "‘You people in Heshbon, cry aloud, because the enemy has destroyed Ai. Weep, you people who live in Rabbah. Dress yourselves in sackcloth, because you are so sad. Run around inside the city. The enemy will take away your idol of Molech. They will take Molech's priests and their officers to a foreign land. because the enemy has destroyed Ai. Weep, you people who live in Rabbah. Dress yourselves in sackcloth, because you are so sad. Run around inside the city. The enemy will take away your idol of Molech. They will take Molech's priests and their officers to a foreign land."
    },
    {
      "verse": "4",
      "text": "You people of Ammon boast about your power. But that will soon come to an end! You have not been faithful. You have trusted in your riches and you say, “Nobody will be able to attack us! ” ’ But that will soon come to an end! You have not been faithful. You have trusted in your riches and you say, “Nobody will be able to attack us! ” ’"
    },
    {
      "verse": "5",
      "text": "But the Lord God Almighty says, ‘I will bring terror all around you. Your enemy will chase you away in all directions. Nobody will be able to bring you together again. ‘I will bring terror all around you. Your enemy will chase you away in all directions. Nobody will be able to bring you together again."
    },
    {
      "verse": "6",
      "text": "But in future days, I will make Ammon's people strong again. ’That is what the Lord says. That is what the Lord says."
    },
    {
      "verse": "7",
      "text": "The Lord Almighty gave this message about Edom:‘It seems that wisdom has disappeared from Teman. Edom's clever men have no good advice. Their great ideas have gone away. ‘It seems that wisdom has disappeared from Teman. Edom's clever men have no good advice. Their great ideas have gone away."
    },
    {
      "verse": "8",
      "text": "You people who live in Dedan, run away and escape! Go and find somewhere safe to hide! The time has come for me to punish Esau's descendants. I will cause them to have terrible trouble. Go and find somewhere safe to hide! The time has come for me to punish Esau's descendants. I will cause them to have terrible trouble."
    },
    {
      "verse": "9",
      "text": "If people came to pick your grapes, they would leave a few grapes on the vines. If robbers came at night to take your things, they would only take the things that they needed. they would leave a few grapes on the vines. If robbers came at night to take your things, they would only take the things that they needed."
    },
    {
      "verse": "10",
      "text": "But I will take everything from Esau's descendants, so that they have nothing. I will open their secret places, so that they have nowhere to hide. The enemy will destroy them and their children, family and friends. None of them will remain alive. so that they have nothing. I will open their secret places, so that they have nowhere to hide. The enemy will destroy them and their children, family and friends. None of them will remain alive."
    },
    {
      "verse": "11",
      "text": "But I will take care of your widows and the children who have no family. You can trust me to keep them safe. ’ You can trust me to keep them safe. ’"
    },
    {
      "verse": "12",
      "text": "The Lord says, ‘I had to punish even those people who did not deserve my great punishment. So you will certainly not escape my punishment! You will have to drink my anger from the cup that I give to you."
    },
    {
      "verse": "13",
      "text": "I, the Lord, promise you this, with the authority of my own name: Bozrah city will become a heap of stones. The people of other nations will think that it is disgusting. They will laugh at it. They will use its name as a curse. All the towns and villages around it will be heaps of stones for ever. ’"
    },
    {
      "verse": "14",
      "text": "I have heard a message from the Lord. He has sent someone with this message to the nations:‘Prepare your armies to attack Edom. Prepare to fight a battle against Edom! ’ ‘Prepare your armies to attack Edom. Prepare to fight a battle against Edom! ’"
    },
    {
      "verse": "15",
      "text": "The Lord says to Edom's people, ‘I will make you a weak nation that nobody respects. ‘I will make you a weak nation that nobody respects."
    },
    {
      "verse": "16",
      "text": "You are proud people. You boast that you cause other people to be afraid of you. But your thoughts have deceived you. You live high up among the rocks, and on the tops of mountains. But I will bring you down from there, even if you are as high as an eagle's nest. ’That is what the Lord says. You boast that you cause other people to be afraid of you. But your thoughts have deceived you. You live high up among the rocks, and on the tops of mountains. But I will bring you down from there, even if you are as high as an eagle's nest. ’ That is what the Lord says."
    },
    {
      "verse": "17",
      "text": "‘People will see how disgusting Edom is. Everybody who goes there will be very surprised. They will see all the terrible trouble that has happened to the nation, and they will insult it."
    },
    {
      "verse": "18",
      "text": "Edom will become a heap of stones where nobody lives. The same thing happened to Sodom and Gomorrah, and the towns that were near them. Edom will be as empty as a desert. ’That is what the Lord says. The same thing happened to Sodom and Gomorrah, and the towns that were near them. Edom will be as empty as a desert. ’ That is what the Lord says."
    },
    {
      "verse": "19",
      "text": "‘I will attack the people of Edomand I will chase them out of their land. I will be like a lion that has been hiding in the forest. It attacks the sheep in the fields beside the Jordan River. Like that lion, I will suddenly chase Edom's people out of their country. Then I will choose a leader to rule that nation. There is nobody who is like me. Nobody can accuse me of anything. No ruler can stand against me. and I will chase them out of their land. I will be like a lion that has been hiding in the forest. It attacks the sheep in the fields beside the Jordan River. Like that lion, I will suddenly chase Edom's people out of their country. Then I will choose a leader to rule that nation. There is nobody who is like me. Nobody can accuse me of anything. No ruler can stand against me."
    },
    {
      "verse": "20",
      "text": "So listen to me, the Lord! This is what I have decided to do to Edom. Yes, this is the trouble that I will bring to the people who live in Teman. Soldiers will catch their children and take them away, like little lambs that they take from their mothers. I will completely destroy their homes. This is what I have decided to do to Edom. Yes, this is the trouble that I will bring to the people who live in Teman. Soldiers will catch their children and take them away, like little lambs that they take from their mothers. I will completely destroy their homes."
    },
    {
      "verse": "21",
      "text": "When Edom's people fall, the noise will cause the whole earth to shake. The sound of their sad voices will reach as far as the Red Sea. the noise will cause the whole earth to shake. The sound of their sad voices will reach as far as the Red Sea."
    },
    {
      "verse": "22",
      "text": "A nation will rise up high, like an eagle in the sky. It will fly down to catch its food in Bozrah! When the brave soldiers of Edom see that, they will become very afraid. They will be afraid, like a woman who will soon give birth. ’ It will fly down to catch its food in Bozrah! When the brave soldiers of Edom see that, they will become very afraid. They will be afraid, like a woman who will soon give birth. ’"
    },
    {
      "verse": "23",
      "text": "The Lord gave this message about Damascus:‘The people of Hamath and Arpad will hear bad news. It will cause them to be upset. They will no longer feel brave. They will not be able to rest because they are afraid. ‘The people of Hamath and Arpad will hear bad news. It will cause them to be upset. They will no longer feel brave. They will not be able to rest because they are afraid."
    },
    {
      "verse": "24",
      "text": "The people of Damascus will become weak. They will try to run away. They will become confused because of their fear. They will feel pain like a woman who is giving birth. They will try to run away. They will become confused because of their fear. They will feel pain like a woman who is giving birth."
    },
    {
      "verse": "25",
      "text": "Damascus was a famous city. The people who lived in it were very happy. But now it will become empty. The people who lived in it were very happy. But now it will become empty."
    },
    {
      "verse": "26",
      "text": "Its young men will die in its streets. All its soldiers will be dead. All its soldiers will be dead."
    },
    {
      "verse": "27",
      "text": "I will burn down the city walls of Damascus. Fire will destroy the palaces of King Ben-Hadad. ’That is what the Lord Almighty says. Fire will destroy the palaces of King Ben-Hadad. ’ That is what the Lord Almighty says."
    },
    {
      "verse": "28",
      "text": "The Lord gave this message about Kedar and the kingdoms of Hazor that King Nebuchadnezzar of Babylon attacked:‘March to Kedar and attack the city! Destroy those people who live east of Judah. ‘March to Kedar and attack the city! Destroy those people who live east of Judah."
    },
    {
      "verse": "29",
      "text": "Take away their tents and their sheep. Take their curtains and the other things in their tents. Carry those things away with their camels. Cause the people to shout, “Terror is everywhere around us! ” ’ Take their curtains and the other things in their tents. Carry those things away with their camels. Cause the people to shout, “Terror is everywhere around us! ” ’"
    },
    {
      "verse": "30",
      "text": "The Lord says, ‘You people who live in Hazor, run away quickly! Go and find somewhere safe to hide! King Nebuchadnezzar of Babylon has decided to attack you. He knows how he will destroy you. ’ ‘You people who live in Hazor, run away quickly! Go and find somewhere safe to hide! King Nebuchadnezzar of Babylon has decided to attack you. He knows how he will destroy you. ’"
    },
    {
      "verse": "31",
      "text": "The Lord says to King Nebuchadnezzar, ‘Go and attack that nation. They think that they are strong and safe. But their city has no gates or walls to protect them. They live far away from other people. ‘Go and attack that nation. They think that they are strong and safe. But their city has no gates or walls to protect them. They live far away from other people."
    },
    {
      "verse": "32",
      "text": "Take their camels and their farm animals for yourselves. I will chase away those people who live in the desert and who cut their hair short. I will send them away in every direction. And I will bring terrible trouble from every direction to hurt them. I will chase away those people who live in the desert and who cut their hair short. I will send them away in every direction. And I will bring terrible trouble from every direction to hurt them."
    },
    {
      "verse": "33",
      "text": "Hazor will become as empty as a desert. Only wild animals will live there. It will always be a place where no people live. ’ Only wild animals will live there. It will always be a place where no people live. ’"
    },
    {
      "verse": "34",
      "text": "Soon after Zedekiah became king of Judah, the Lord gave this message about Elam to the prophet Jeremiah. ‘Listen to me! Elam's army makes them a strong nation. They have soldiers who can shoot arrows well. But I will destroy those soldiers."
    },
    {
      "verse": "35",
      "text": "The Lord Almighty said, ‘Listen to me! Elam's army makes them a strong nation. They have soldiers who can shoot arrows well. But I will destroy those soldiers."
    },
    {
      "verse": "36",
      "text": "I will cause enemies to attack Elam, like winds that blow from every direction. I will chase Elam's people away in every direction. They will run away to live in every other nation of the world. like winds that blow from every direction. I will chase Elam's people away in every direction. They will run away to live in every other nation of the world."
    },
    {
      "verse": "37",
      "text": "I will make them very afraid of their enemies who want to kill them. I will cause them to have terrible trouble, because I am very angry with them. ’That is what the Lord says. ‘I will send soldiers to attack them, until I have completely destroyed them. I will cause them to have terrible trouble, because I am very angry with them. ’ That is what the Lord says. ‘I will send soldiers to attack them, until I have completely destroyed them."
    },
    {
      "verse": "38",
      "text": "I will destroy their kings and their leaders. I will be the king who rules over Elam. ’That is what the Lord says. I will be the king who rules over Elam. ’ That is what the Lord says."
    },
    {
      "verse": "39",
      "text": "‘But at a future time, I will make Elam strong again. ’That is what the Lord says."
    }
  ],
  "50": [
    {
      "verse": "1",
      "text": "The Lord gave this message to the prophet Jeremiah about Babylon city and the people of Babylonia:"
    },
    {
      "verse": "2",
      "text": "‘Tell this news to the nations! Wave a flag to make sure that people listen! Do not try to hide anything. Say this:“Enemies will take Babylon. Bel will become ashamed. Yes, Marduk will be afraid. All Babylon's disgusting idols will be ashamed. ” Wave a flag to make sure that people listen! Do not try to hide anything. Say this: “Enemies will take Babylon. Bel will become ashamed. Yes, Marduk will be afraid. All Babylon's disgusting idols will be ashamed. ”"
    },
    {
      "verse": "3",
      "text": "A nation from the north will attack Babylon. They will destroy the whole land. People and animals will all run away, so that nobody lives there. ’ They will destroy the whole land. People and animals will all run away, so that nobody lives there. ’"
    },
    {
      "verse": "4",
      "text": "The Lord says, ‘When that happens, the people of Israel and Judah will return to their land. They will weep because of their sins. They will want to worship the Lord their God. the people of Israel and Judah will return to their land. They will weep because of their sins. They will want to worship the Lord their God."
    },
    {
      "verse": "5",
      "text": "They will ask people to show them the way to Zion. They will travel in that direction. They will promise to serve the Lord. They will make a covenant with him that will continue for ever. Nobody will ever forget that covenant. They will travel in that direction. They will promise to serve the Lord. They will make a covenant with him that will continue for ever. Nobody will ever forget that covenant."
    },
    {
      "verse": "6",
      "text": "My people have been like sheep that are lost. Their leaders should have taken care of them like shepherds. Instead, they have let my people become lost, like sheep that have gone into the mountains. They go from one hill to another hill, and they have forgotten where their home is. Their leaders should have taken care of them like shepherds. Instead, they have let my people become lost, like sheep that have gone into the mountains. They go from one hill to another hill, and they have forgotten where their home is."
    },
    {
      "verse": "7",
      "text": "Anyone who found them killed them. Their enemies said, “We are not guilty for their death. They deserved to die because they turned against the Lord. He is their true home where they are safe. But they turned against the Lord, the God that their ancestors trusted. ” ’ Their enemies said, “We are not guilty for their death. They deserved to die because they turned against the Lord. He is their true home where they are safe. But they turned against the Lord, the God that their ancestors trusted. ” ’"
    },
    {
      "verse": "8",
      "text": "‘People of Judah, escape quickly from Babylon! Leave the land of Babylonia! Be the first people to leave. Lead the other people away, like a male goat that leads the other goats. Leave the land of Babylonia! Be the first people to leave. Lead the other people away, like a male goat that leads the other goats."
    },
    {
      "verse": "9",
      "text": "I will call a group of strong nations from the north. They will join together to fight against Babylon. They will get ready to attack. They will come from the northand they will take power over Babylon. Their arrows will be like brave soldiers. They will kill everyone that they want to kill. They will join together to fight against Babylon. They will get ready to attack. They will come from the north and they will take power over Babylon. Their arrows will be like brave soldiers. They will kill everyone that they want to kill."
    },
    {
      "verse": "10",
      "text": "The people of Babylonia will lose all their things. Enemy soldiers will take everything that they want for themselves. ’That is what the Lord says. Enemy soldiers will take everything that they want for themselves. ’ That is what the Lord says."
    },
    {
      "verse": "11",
      "text": "‘You people of Babylon are very happy, because you have robbed my people. You dance like young cows that have fresh grass to eat. You make a happy noise, like a strong male horse. because you have robbed my people. You dance like young cows that have fresh grass to eat. You make a happy noise, like a strong male horse."
    },
    {
      "verse": "12",
      "text": "Babylon is like your mother who gave you life, but she will become ashamed. Yes, she will become the least important of all nations. The country will be dry and empty, like a desert. but she will become ashamed. Yes, she will become the least important of all nations. The country will be dry and empty, like a desert."
    },
    {
      "verse": "13",
      "text": "Nobody will live in Babylon, because I, the Lord, am very angry with it. It will be only a heap of stones. Everyone who goes that way will see that it is a disgusting place. They will insult Babylon, because of the terrible troubles that have happened to it. ’ because I, the Lord, am very angry with it. It will be only a heap of stones. Everyone who goes that way will see that it is a disgusting place. They will insult Babylon, because of the terrible troubles that have happened to it. ’"
    },
    {
      "verse": "14",
      "text": "‘Get ready to fight, all you soldiers who have bows and arrows. Stand in your places around Babylon. Shoot your arrows into the city! Shoot all of them! Punish Babylon, because its people have turned against the Lord. Stand in your places around Babylon. Shoot your arrows into the city! Shoot all of them! Punish Babylon, because its people have turned against the Lord."
    },
    {
      "verse": "15",
      "text": "Shout as you attack the city from all sides. Its people are ready to stop fighting. Its strong towers will fall down. You will knock down its walls. The Lord is punishing Babylon, so punish the people for their sins! Do the same thing to them that they have done to other people. Its people are ready to stop fighting. Its strong towers will fall down. You will knock down its walls. The Lord is punishing Babylon, so punish the people for their sins! Do the same thing to them that they have done to other people."
    },
    {
      "verse": "16",
      "text": "Remove from Babylon all the farmers who plant crops. Remove all the people who cut the crops at harvest time. The foreigners must return to their own homes. They must run away to escape from the enemy army. ’ Remove all the people who cut the crops at harvest time. The foreigners must return to their own homes. They must run away to escape from the enemy army. ’"
    },
    {
      "verse": "17",
      "text": "‘Israel's enemies have chased them away to many different places. They are like sheep that hungry lions have chased away. The first to catch them was the king of Assyria. Then King Nebuchadnezzar of Babylon destroyed them, like a lion that broke their bones. ’ They are like sheep that hungry lions have chased away. The first to catch them was the king of Assyria. Then King Nebuchadnezzar of Babylon destroyed them, like a lion that broke their bones. ’"
    },
    {
      "verse": "18",
      "text": "So the Lord Almighty, Israel's God, says this:‘I will punish the king of Babylon and his country, as I punished the king of Assyria. ‘I will punish the king of Babylon and his country, as I punished the king of Assyria."
    },
    {
      "verse": "19",
      "text": "But I will bring Israel's people back to their own land. They will grow their crops on Carmel and in Bashan. They will have plenty of food to eaton the hills of Ephraim and in Gilead. They will grow their crops on Carmel and in Bashan. They will have plenty of food to eat on the hills of Ephraim and in Gilead."
    },
    {
      "verse": "20",
      "text": "At that time, I will forgive the sins of my people. I have let a few people of Israel and Judah remain. And they will no longer be guilty of any sins. ’That is what the Lord says. I have let a few people of Israel and Judah remain. And they will no longer be guilty of any sins. ’ That is what the Lord says."
    },
    {
      "verse": "21",
      "text": "The Lord says, ‘Attack the land of Merathaim. Attack the people who live in Pekod. Run after them! Kill them! Completely destroy them! Do everything that I have commanded you to do. ‘Attack the land of Merathaim. Attack the people who live in Pekod. Run after them! Kill them! Completely destroy them! Do everything that I have commanded you to do."
    },
    {
      "verse": "22",
      "text": "There is a noise of war in the land of Babylonia. The enemy is destroying everything! The enemy is destroying everything!"
    },
    {
      "verse": "23",
      "text": "Babylon attacked other nations of the world, like a hammer that breaks things into pieces. But now that hammer has broken into pieces. Now the other nations see that Babylon is a disgusting place. like a hammer that breaks things into pieces. But now that hammer has broken into pieces. Now the other nations see that Babylon is a disgusting place."
    },
    {
      "verse": "24",
      "text": "Babylon, I put a trap to catch you, and you did not know about it. Now I have caught you in my trap, because you fought against me. and you did not know about it. Now I have caught you in my trap, because you fought against me."
    },
    {
      "verse": "25",
      "text": "I have taken out my weapons from the place where I had stored them. I will use those weapons to punish the people of Babylonia, because I am very angry with them. I am the Lord God Almighty. I have work to do in the land of Babylonia. I will use those weapons to punish the people of Babylonia, because I am very angry with them. I am the Lord God Almighty. I have work to do in the land of Babylonia."
    },
    {
      "verse": "26",
      "text": "Now come from far away to attack Babylonia! Break open the store rooms and take out the grain. Knock down their buildings and break them into pieces. Completely destroy everything. Do not let anything remain! Break open the store rooms and take out the grain. Knock down their buildings and break them into pieces. Completely destroy everything. Do not let anything remain!"
    },
    {
      "verse": "27",
      "text": "Kill all their strong soldiers. Let them go to their place of death! Terrible trouble has come to the people of Babylon. The time of their punishment has arrived! ’ Let them go to their place of death! Terrible trouble has come to the people of Babylon. The time of their punishment has arrived! ’"
    },
    {
      "verse": "28",
      "text": "Listen! People have run away from the war in Babylon. Now they are arriving in Jerusalem. They will tell the news in Zion about how the Lord is punishing Babylon. He is punishing the people of Babylon because they destroyed his temple."
    },
    {
      "verse": "29",
      "text": "‘Bring all the soldiers with bows and arrows to attack Babylon. They must make their camp all around the city. Do not let anyone escape. Punish the people for the things that they have done. Do the same thing to them that they have done to others. Those people have insulted me, Israel's holy God. They must make their camp all around the city. Do not let anyone escape. Punish the people for the things that they have done. Do the same thing to them that they have done to others. Those people have insulted me, Israel's holy God."
    },
    {
      "verse": "30",
      "text": "So Babylon's young men will die in its streets. All its soldiers will die in battle on that day. ’That is what the Lord says. All its soldiers will die in battle on that day. ’ That is what the Lord says."
    },
    {
      "verse": "31",
      "text": "The Lord God Almighty says this:‘You people of Babylon are very proud, so I will fight against you. Now the day has comewhen I will punish you for your sins. ‘You people of Babylon are very proud, so I will fight against you. Now the day has come when I will punish you for your sins."
    },
    {
      "verse": "32",
      "text": "You are proud but you will fall to the ground. Nobody will help you to get up. I will burn Babylonia's towns with fire, and it will destroy everything that is around them. ’ Nobody will help you to get up. I will burn Babylonia's towns with fire, and it will destroy everything that is around them. ’"
    },
    {
      "verse": "33",
      "text": "The Lord Almighty says, ‘People have been cruel to the people of Israel and Judah. Enemies have taken them away as prisoners. They have refused to let my people go free. ‘People have been cruel to the people of Israel and Judah. Enemies have taken them away as prisoners. They have refused to let my people go free."
    },
    {
      "verse": "34",
      "text": "But my name is the Lord Almighty. I am strong and I will rescue my people. I will fight hard to save them. I will bring peace to their land. But the people of Babylonia will only have trouble. ’ I am strong and I will rescue my people. I will fight hard to save them. I will bring peace to their land. But the people of Babylonia will only have trouble. ’"
    },
    {
      "verse": "35",
      "text": "The Lord says, ‘I am sending an army to fight against Babylon. They will attack the people of Babylonia, its leaders and its wise men. ‘I am sending an army to fight against Babylon. They will attack the people of Babylonia, its leaders and its wise men."
    },
    {
      "verse": "36",
      "text": "They will attack its false prophets, and people will see that the prophets are fools. They will attack the soldiers of Babylonia, and those soldiers will be very afraid. and people will see that the prophets are fools. They will attack the soldiers of Babylonia, and those soldiers will be very afraid."
    },
    {
      "verse": "37",
      "text": "They will attack Babylonia's horses and chariots, and the foreign soldiers who belong to its army. They will become as weak as women. The enemy soldiers will take Babylon's valuable things. They will take them away for themselves. and the foreign soldiers who belong to its army. They will become as weak as women. The enemy soldiers will take Babylon's valuable things. They will take them away for themselves."
    },
    {
      "verse": "38",
      "text": "There will be no rain on the landso that the rivers and streams become dry. I will send all this trouble becausetheir whole land is full of idols. The people become crazybecause they are afraid of their idols. so that the rivers and streams become dry. I will send all this trouble because their whole land is full of idols. The people become crazy because they are afraid of their idols."
    },
    {
      "verse": "39",
      "text": "Hyenas and other wild animals will live there. Ostriches will live there, too. But people will never live there again. It will remain as empty as a desert. Ostriches will live there, too. But people will never live there again. It will remain as empty as a desert."
    },
    {
      "verse": "40",
      "text": "Babylonia will become a heap of stones where nobody lives. The same thing happened to Sodom and Gomorrahand the towns near to them. Nobody will live there any more. ’That is what the Lord says. The same thing happened to Sodom and Gomorrah and the towns near to them. Nobody will live there any more. ’ That is what the Lord says."
    },
    {
      "verse": "41",
      "text": "‘Look! An army is coming from the north. A great nation and many kings are preparing to attack. They are coming from a place that is far away. A great nation and many kings are preparing to attack. They are coming from a place that is far away."
    },
    {
      "verse": "42",
      "text": "Its soldiers carry bows and spears as their weapons. They are always cruel and they are never kind. They ride into the battle on their horses, and it sounds like the noise of the sea. They are ready to attack you, people of Babylon! They are always cruel and they are never kind. They ride into the battle on their horses, and it sounds like the noise of the sea. They are ready to attack you, people of Babylon!"
    },
    {
      "verse": "43",
      "text": "The king of Babylon has heard news about them, and he is very afraid. He feels too weak to fight. He feels pain like a woman who is giving birth. and he is very afraid. He feels too weak to fight. He feels pain like a woman who is giving birth."
    },
    {
      "verse": "44",
      "text": "I will attack the people of Babylonia, and I will chase them out of their land. I will do that like a lion that has been hiding in the forest. It attacks the sheep in the fields beside the Jordan River. Like that lion, I will suddenly chase Babylonia's people out of their country. Then I will choose a leader to rule that nation. There is nobody who is like me. Nobody can accuse me of anything. No ruler can stand against me. and I will chase them out of their land. I will do that like a lion that has been hiding in the forest. It attacks the sheep in the fields beside the Jordan River. Like that lion, I will suddenly chase Babylonia's people out of their country. Then I will choose a leader to rule that nation. There is nobody who is like me. Nobody can accuse me of anything. No ruler can stand against me."
    },
    {
      "verse": "45",
      "text": "So listen to me, the Lord! This is what I have decided to do to Babylon. Yes, this is the trouble that I will bring to the people of Babylonia. Soldiers will catch their children and take them away, like little lambs that they take from their mothers. I will completely destroy their homes. This is what I have decided to do to Babylon. Yes, this is the trouble that I will bring to the people of Babylonia. Soldiers will catch their children and take them away, like little lambs that they take from their mothers. I will completely destroy their homes."
    },
    {
      "verse": "46",
      "text": "When the enemy takes power over Babylon, the noise will cause the whole earth to shake. The other nations will hear Babylon's people shout with pain. ’"
    }
  ],
  "51": [
    {
      "verse": "1",
      "text": "The Lord says this:‘I will send an enemy to destroy Babylon and the people of Babylonia. It will come like a strong wind that blows them away. ‘I will send an enemy to destroy Babylon and the people of Babylonia. It will come like a strong wind that blows them away."
    },
    {
      "verse": "2",
      "text": "I will send foreign soldiers to remove them from their land, like a wind that blows chaff away. They will make the land become empty. On the day of that great trouble, they will attack Babylonia from all directions. like a wind that blows chaff away. They will make the land become empty. On the day of that great trouble, they will attack Babylonia from all directions."
    },
    {
      "verse": "3",
      "text": "Do not give Babylon's soldiers time to pick up their weapons! Do not give them time to put on their armour! Kill all their young men. Completely destroy their whole army. Do not give them time to put on their armour! Kill all their young men. Completely destroy their whole army."
    },
    {
      "verse": "4",
      "text": "Their dead bodies will lie on the groundall over Babylonia and in the streets of the city. all over Babylonia and in the streets of the city."
    },
    {
      "verse": "5",
      "text": "The Lord Almighty, Israel's God, will not leave Israel and Judah on their own. Those people are guilty of many bad thingsthat they have done against Israel's holy God. will not leave Israel and Judah on their own. Those people are guilty of many bad things that they have done against Israel's holy God."
    },
    {
      "verse": "6",
      "text": "Run away from Babylonia! Run quickly to escape from there! Do not stay there to die along with Babylonia's people. The time has come for the Lord to pay them back for their sins. He will punish them as they deserve. Run quickly to escape from there! Do not stay there to die along with Babylonia's people. The time has come for the Lord to pay them back for their sins. He will punish them as they deserve."
    },
    {
      "verse": "7",
      "text": "Babylon has been like a gold cup of wine in the Lord's hand. The nations of the world had to drink that wine. It made everyone become drunk, and so they all became crazy. The nations of the world had to drink that wine. It made everyone become drunk, and so they all became crazy."
    },
    {
      "verse": "8",
      "text": "But now Babylon will quickly fall. An enemy will destroy it, so weep for it! Find some medicine that will make its wounds better. Perhaps it will become well again. An enemy will destroy it, so weep for it! Find some medicine that will make its wounds better. Perhaps it will become well again."
    },
    {
      "verse": "9",
      "text": "The foreign people in Babylon say, “We tried to make its wounds better, but it was not possible to do it. Now we must leave it. We must each go back to our own country. Its punishment will have no end. It will reach as high as the sky! ” “We tried to make its wounds better, but it was not possible to do it. Now we must leave it. We must each go back to our own country. Its punishment will have no end. It will reach as high as the sky! ”"
    },
    {
      "verse": "10",
      "text": "The people from Judah who are in Babylon say, “The Lord has shown that we are his people. Now we must go to Jerusalem. We must tell people in Zionabout how the Lord our God has helped us. ” ’ “The Lord has shown that we are his people. Now we must go to Jerusalem. We must tell people in Zion about how the Lord our God has helped us. ” ’"
    },
    {
      "verse": "11",
      "text": "‘Make your arrows sharp! Prepare your weapons! The Lord has caused Media's kings to prepare for war. He will use them to destroy Babylon. The Lord will punish the people of Babyloniabecause they destroyed his temple. Prepare your weapons! The Lord has caused Media's kings to prepare for war. He will use them to destroy Babylon. The Lord will punish the people of Babylonia because they destroyed his temple."
    },
    {
      "verse": "12",
      "text": "Wave a flag and prepare to attack Babylon's city walls! Bring plenty of guards to watch all around the city. Put soldiers to catch anyone who tries to escape. Yes, the Lord will now do everything that he has decided. He will punish Babylon's people, as he said he would do. Bring plenty of guards to watch all around the city. Put soldiers to catch anyone who tries to escape. Yes, the Lord will now do everything that he has decided. He will punish Babylon's people, as he said he would do."
    },
    {
      "verse": "13",
      "text": "You people of Babylon, who live beside many rivers, it is now time for you to die. You have become rich with many valuable things, but now your lives will finish. ’ it is now time for you to die. You have become rich with many valuable things, but now your lives will finish. ’"
    },
    {
      "verse": "14",
      "text": "The Lord Almighty has made this strong promisewith the authority of his own name:‘I will cause the enemy's soldiers to fill your cities. They will come like a big crowd of locusts. They will shout loudly when they take your city for themselves. ’ with the authority of his own name: ‘I will cause the enemy's soldiers to fill your cities. They will come like a big crowd of locusts. They will shout loudly when they take your city for themselves. ’"
    },
    {
      "verse": "15",
      "text": "The Lord used his power to make the earth. He used his wisdom to make it strong. He knew how to put the sky to cover the earth. He used his wisdom to make it strong. He knew how to put the sky to cover the earth."
    },
    {
      "verse": "16",
      "text": "When he shouts like thunder, the water in the sky roars. He brings the clouds from the far places of the earth. He causes bright lightning to show in the storms. He opens his rooms so that the wind comes outand it blows everywhere. the water in the sky roars. He brings the clouds from the far places of the earth. He causes bright lightning to show in the storms. He opens his rooms so that the wind comes out and it blows everywhere."
    },
    {
      "verse": "17",
      "text": "People who worship idols are stupid. They do not understand what they are doing. The men who make idols will be ashamed. They make images of gods that are false. None of their idols have the breath of life in them. They do not understand what they are doing. The men who make idols will be ashamed. They make images of gods that are false. None of their idols have the breath of life in them."
    },
    {
      "verse": "18",
      "text": "They are useless things that people should laugh at. When the time for their punishment arrives, God will destroy them. When the time for their punishment arrives, God will destroy them."
    },
    {
      "verse": "19",
      "text": "The God that Jacob's descendants worshipis not like those idols. He created everything. He chose Israel's people to belong to him. His name is the Lord Almighty. is not like those idols. He created everything. He chose Israel's people to belong to him. His name is the Lord Almighty."
    },
    {
      "verse": "20",
      "text": "‘You are the weapon that I use to fight my battles. I have used you to punish nations. I have used you to destroy kingdoms. I have used you to punish nations. I have used you to destroy kingdoms."
    },
    {
      "verse": "21",
      "text": "I have used you to destroy whole armies, with their horses, chariots and riders. with their horses, chariots and riders."
    },
    {
      "verse": "22",
      "text": "I have used you to destroy men and women, old men, young men, boys and girls. old men, young men, boys and girls."
    },
    {
      "verse": "23",
      "text": "I have used you to destroy shepherds and their sheep, as well as farmers and their oxen. I have used you to destroy rulers and their officers. as well as farmers and their oxen. I have used you to destroy rulers and their officers."
    },
    {
      "verse": "24",
      "text": "But now I will punish Babylonand all the people who live in Babylonia. I will pay them back for all the evil things that they did in Jerusalem. And you will see me do that. ’That is what the Lord says. and all the people who live in Babylonia. I will pay them back for all the evil things that they did in Jerusalem. And you will see me do that. ’ That is what the Lord says."
    },
    {
      "verse": "25",
      "text": "The Lord says, ‘Listen to me, Babylon! I am your enemy! You are like a strong mountain that destroys the whole earth. I will punish you with all my strength. I will push you down from your high place. I will make you a heap of ashes. ‘Listen to me, Babylon! I am your enemy! You are like a strong mountain that destroys the whole earth. I will punish you with all my strength. I will push you down from your high place. I will make you a heap of ashes."
    },
    {
      "verse": "26",
      "text": "Nobody will be able to use any of your stonesas a foundation for a new building. You will remain as empty as a desert for ever. ’That is what the Lord says. as a foundation for a new building. You will remain as empty as a desert for ever. ’ That is what the Lord says."
    },
    {
      "verse": "27",
      "text": "‘Call the nations to come and fight a battle against Babylonia. Wave a flag and make a noise with trumpets, so that these kingdoms prepare their armies to attack: Ararat, Minni and Ashkenaz. Choose a captain to lead them into battle. Send an army of soldiers on horses to attack, like a large crowd of locusts. Wave a flag and make a noise with trumpets, so that these kingdoms prepare their armies to attack: Ararat, Minni and Ashkenaz. Choose a captain to lead them into battle. Send an army of soldiers on horses to attack, like a large crowd of locusts."
    },
    {
      "verse": "28",
      "text": "Tell the nations to prepare their armies for war against Babylonia. Tell the kings of Media to get ready, as well as their leaders and officers. The armies of the countries that they rule must also be ready to fight. Tell the kings of Media to get ready, as well as their leaders and officers. The armies of the countries that they rule must also be ready to fight."
    },
    {
      "verse": "29",
      "text": "The whole earth will shake with painas the Lord punishes Babylonia. He will certainly do what he has decided to do. He will make the land of Babylonia as empty as a desert. Nobody will live there. as the Lord punishes Babylonia. He will certainly do what he has decided to do. He will make the land of Babylonia as empty as a desert. Nobody will live there."
    },
    {
      "verse": "30",
      "text": "The brave soldiers of Babylonia are no longer fighting! They remain inside their strong buildings. Their strength has gone! They are as weak as women. In their cities, enemy soldiers are burning their houses. They have broken down the city gates. They remain inside their strong buildings. Their strength has gone! They are as weak as women. In their cities, enemy soldiers are burning their houses. They have broken down the city gates."
    },
    {
      "verse": "31",
      "text": "Now people run to send the news to the king of Babylon. They pass this message along the line:“The enemy has taken power over the whole city! They pass this message along the line: “The enemy has taken power over the whole city!"
    },
    {
      "verse": "32",
      "text": "They have guards to stop people escaping across the rivers. They have burned the reeds in the wet fields. All our soldiers are afraid. ” They have burned the reeds in the wet fields. All our soldiers are afraid. ”"
    },
    {
      "verse": "33",
      "text": "The Lord Almighty, Israel's God, says this: Babylon is like a threshing floorthat is ready for people to stamp on wheat. The harvest time will soon come! Then the enemy will cut down Babylon, and they will stamp all over it! ’ Babylon is like a threshing floor that is ready for people to stamp on wheat. The harvest time will soon come! Then the enemy will cut down Babylon, and they will stamp all over it! ’"
    },
    {
      "verse": "34",
      "text": "‘King Nebuchadnezzar of Babylon has destroyed us with his army. He has made us weak and confused. He has eaten us like a hungry monster. He has filled himself with all our good things. Then he spat us out of his mouth. ’ He has made us weak and confused. He has eaten us like a hungry monster. He has filled himself with all our good things. Then he spat us out of his mouth. ’"
    },
    {
      "verse": "35",
      "text": "Zion's people then say to the Lord, ‘Please punish the people of Babylonia, because they did cruel things to us. ’Jerusalem's people say, ‘Pay back the people of Babylonia, because they killed our relatives. ’ ‘Please punish the people of Babylonia, because they did cruel things to us. ’ Jerusalem's people say, ‘Pay back the people of Babylonia, because they killed our relatives. ’"
    },
    {
      "verse": "36",
      "text": "So the Lord says, ‘I will help you to win. I will punish the people of Babylonia for what they have done to you. I will cause all their rivers and their springs to become dry. ‘I will help you to win. I will punish the people of Babylonia for what they have done to you. I will cause all their rivers and their springs to become dry."
    },
    {
      "verse": "37",
      "text": "Babylon will become a heap of stones. Wild animals will live there. People will see that it is a disgusting place, and they will laugh at it. Nobody will live there. Wild animals will live there. People will see that it is a disgusting place, and they will laugh at it. Nobody will live there."
    },
    {
      "verse": "38",
      "text": "Its people shout loudly, like lions that roar. They make a noise like baby lions that are hungry. They make a noise like baby lions that are hungry."
    },
    {
      "verse": "39",
      "text": "While they are feeling so hungry, I will prepare a feast for them. I will cause them to become drunk, and they will become helpless. They will sleep for everand they will never wake up again. ’That is what the Lord says. I will prepare a feast for them. I will cause them to become drunk, and they will become helpless. They will sleep for ever and they will never wake up again. ’ That is what the Lord says."
    },
    {
      "verse": "40",
      "text": "‘I will take them down to the place of death. People will kill them as if they are lambs, sheep and goats. ’ People will kill them as if they are lambs, sheep and goats. ’"
    },
    {
      "verse": "41",
      "text": "‘Now an enemy will take power over Babylon! Everyone in the world praised it as a great nation. But now all the nations will see that it is a disgusting place. Everyone in the world praised it as a great nation. But now all the nations will see that it is a disgusting place."
    },
    {
      "verse": "42",
      "text": "The sea will pour over it. Many waves of water will cover it. Many waves of water will cover it."
    },
    {
      "verse": "43",
      "text": "Babylonia's towns will become heaps of stones. The land will be dry and empty, like a desert. Nobody will live there any more. Nobody will even travel through the land. The land will be dry and empty, like a desert. Nobody will live there any more. Nobody will even travel through the land."
    },
    {
      "verse": "44",
      "text": "I will punish Bel, the god of Babylon. I will cause him to give back everything that he has taken. Nations will never go to worship him again. Yes, the walls of Babylon will fall down! ’ I will cause him to give back everything that he has taken. Nations will never go to worship him again. Yes, the walls of Babylon will fall down! ’"
    },
    {
      "verse": "45",
      "text": "‘Escape from Babylon, my people! Run away to save your lives! The Lord is very angry with that place, so run away from there! Run away to save your lives! The Lord is very angry with that place, so run away from there!"
    },
    {
      "verse": "46",
      "text": "You must be brave! When you hear news in Babylon of what is happening, do not be afraid. People will report one thing this year, and next year they will report a different thing. They will speak about violence in the land, and about rulers who are fighting against each other. When you hear news in Babylon of what is happening, do not be afraid. People will report one thing this year, and next year they will report a different thing. They will speak about violence in the land, and about rulers who are fighting against each other."
    },
    {
      "verse": "47",
      "text": "So the time will soon come when I will punish Babylon's idols. The whole country will become ashamed. Its people will die and their dead bodies will lie everywhere. The whole country will become ashamed. Its people will die and their dead bodies will lie everywhere."
    },
    {
      "verse": "48",
      "text": "Then everyone in heaven and everyone on the earthwill shout with joy because of what happens to Babylon. They will be happy because an army will come from the north to destroy it. ’That is what the Lord says. will shout with joy because of what happens to Babylon. They will be happy because an army will come from the north to destroy it. ’ That is what the Lord says."
    },
    {
      "verse": "49",
      "text": "‘Babylon's people have caused the death of people everywhere. They have killed many Israelites. So now Babylon must lose its power. They have killed many Israelites. So now Babylon must lose its power."
    },
    {
      "verse": "50",
      "text": "You Israelites who are still alive, leave Babylon now! Do not wait! You are far away from your homes. But remember that the Lord is with you. Think about Jerusalem. leave Babylon now! Do not wait! You are far away from your homes. But remember that the Lord is with you. Think about Jerusalem."
    },
    {
      "verse": "51",
      "text": "You say, “We are ashamed. People have insulted us. We hide our faces in shamebecause foreigners have gone into the holy places of the Lord's temple. ” ’ We hide our faces in shame because foreigners have gone into the holy places of the Lord's temple. ” ’"
    },
    {
      "verse": "52",
      "text": "But the Lord says this:‘The time will soon come when I will punish Babylon's idols. People everywhere in that land will cry with pain, because their wounds are causing them to die. ‘The time will soon come when I will punish Babylon's idols. People everywhere in that land will cry with pain, because their wounds are causing them to die."
    },
    {
      "verse": "53",
      "text": "Babylon's people may build their city very high. They may make its walls very strong. But I will send an army to destroy it. ’That is what the Lord says. They may make its walls very strong. But I will send an army to destroy it. ’ That is what the Lord says."
    },
    {
      "verse": "54",
      "text": "‘Listen to the noise that comes from Babylon! People are crying in pain. Listen to the noise of the enemy armyas it destroys Babylonia. People are crying in pain. Listen to the noise of the enemy army as it destroys Babylonia."
    },
    {
      "verse": "55",
      "text": "The Lord is preparing to destroy Babylon. No noise will come from there any more. The enemy soldiers will attack like great waves of water. There will be a loud noise of battle. No noise will come from there any more. The enemy soldiers will attack like great waves of water. There will be a loud noise of battle."
    },
    {
      "verse": "56",
      "text": "An army is coming to destroy Babylon. They will take hold of its brave soldiers. They will break their weapons. The Lord is a God who punishes people as they deserve. He always pays them back for their sins. They will take hold of its brave soldiers. They will break their weapons. The Lord is a God who punishes people as they deserve. He always pays them back for their sins."
    },
    {
      "verse": "57",
      "text": "I will make Babylon's officers and its wise men drunk, as well as its rulers, its leaders and its soldiers. They will sleep for everand they will never wake up again. ’That is what the King says. His name is the Lord Almighty. as well as its rulers, its leaders and its soldiers. They will sleep for ever and they will never wake up again. ’ That is what the King says. His name is the Lord Almighty."
    },
    {
      "verse": "58",
      "text": "The Lord Almighty says this:‘The enemy will completely knock down the strong walls of Babylon. They will burn its high gates with fire. The nations work very hard, but their work is useless. They make themselves tired, but fire destroys all their work. ’ ‘The enemy will completely knock down the strong walls of Babylon. They will burn its high gates with fire. The nations work very hard, but their work is useless. They make themselves tired, but fire destroys all their work. ’"
    },
    {
      "verse": "59",
      "text": "This is the command that the prophet Jeremiah gave to the king's officer Seraiah. Seraiah was the son of Neriah and the grandson of Mahseiah. He took the message when he went to Babylon with King Zedekiah of Judah. That happened in the fourth year that Zedekiah had ruled Judah as king. That is the end of Jeremiah's messages."
    },
    {
      "verse": "60",
      "text": "Jeremiah had written on a scroll a list of all the terrible troubles that would happen to Babylon. Those were all the messages that he had written about Babylon."
    },
    {
      "verse": "61",
      "text": "Jeremiah said to Seraiah, ‘When you arrive in Babylon, you must read aloud all these messages."
    },
    {
      "verse": "62",
      "text": "Then say, “Lord, you have said that you will destroy this place. Then no people or animals will live in it any longer. It will be empty for ever. ”"
    },
    {
      "verse": "63",
      "text": "When you have finished reading aloud all the words on the scroll, tie a big stone to it. Throw it all into the middle of the Euphrates river."
    },
    {
      "verse": "64",
      "text": "Then say, “That is how Babylon will sink! It will go down and it will never rise up again. The Lord is ready to cause all these terrible troubles to happen to Babylon. Its people will be too weak to stop it. ” ’That is the end of Jeremiah's messages."
    }
  ],
  "52": [
    {
      "verse": "1",
      "text": "years old when he became king. He ruled in Jerusalem for 11 years. His mother's name was Hamutal. She was the daughter of Jeremiah, who came from Libnah."
    },
    {
      "verse": "2",
      "text": "Zedekiah did things that the Lord said were evil, as Jehoiakim had done."
    },
    {
      "verse": "3",
      "text": "All this trouble happened to Jerusalem and to Judah because the Lord was very angry with them. In the end, the Lord sent them away from himself. This is what happened when King Zedekiah turned against the king of Babylon."
    },
    {
      "verse": "4",
      "text": "Nebuchadnezzar, the king of Babylon, marched with his army to attack Jerusalem. He arrived on the tenth day of the tenth month, in the ninth year when Zedekiah had ruled Judah. His soldiers made their camp all around the city. They built heaps of earth all around Jerusalem's walls."
    },
    {
      "verse": "5",
      "text": "Babylon's army stayed around the city until the 11th year that Zedekiah had been king."
    },
    {
      "verse": "6",
      "text": "By the ninth day of the fourth month there was a very bad famine in the city. There was no food for the people to eat."
    },
    {
      "verse": "7",
      "text": "Then Babylon's army broke down Jerusalem's wall so that they could go into the city. Their soldiers were all around the city. So the king of Judah and all his army tried to escape in the night. They went through the gate that was near the king's garden. The path went between the two walls of the city. They ran towards the Jordan Valley."
    },
    {
      "verse": "8",
      "text": "But the soldiers of Babylon's army chased after King Zedekiah. They caught him on the flat land near Jericho. All King Zedekiah's soldiers ran away from him in many directions."
    },
    {
      "verse": "9",
      "text": "Babylon's soldiers took hold of Zedekiah. They took him to King Nebuchadnezzar at Riblah, in Hamath region. Nebuchadnezzar decided how to punish Zedekiah."
    },
    {
      "verse": "10",
      "text": "He told his soldiers to kill all Zedekiah's sons, while Zedekiah watched. He also punished all the officers of Judah with death there at Riblah."
    },
    {
      "verse": "11",
      "text": "Then they cut out Zedekiah's eyes to make him blind. They tied him with chains and they took him to Babylon as their prisoner. They kept him in prison until the day that he died."
    },
    {
      "verse": "12",
      "text": "King Nebuchadnezzar had an officer whose name was Nebuzaradan. He was the captain of the king's royal guards. Nebuzaradan came to Jerusalem when Nebuchadnezzar had ruled Babylon for 19 years. It was on the tenth day of the fifth month."
    },
    {
      "verse": "13",
      "text": "Nebuzaradan destroyed the Lord's temple, the king's palace and all the other houses in Jerusalem. He burned them all with fire, so that he destroyed every important building in the city."
    },
    {
      "verse": "14",
      "text": "Then Nebuzaradan commanded his whole army to knock down the walls around Jerusalem."
    },
    {
      "verse": "15",
      "text": "Captain Nebuzaradan sent away as prisoners some of the poor people and the rest of the people who remained in Jerusalem. He also sent away those people who had agreed to serve the king of Babylon, and the workers who had special skills."
    },
    {
      "verse": "16",
      "text": "But he let some of the poorest people stay there. He gave them vineyards and fields to work in."
    },
    {
      "verse": "17",
      "text": "The soldiers from Babylon broke the two bronze pillars that were in the Lord's temple. They also broke the carts which carried the buckets for water and the large bath called ‘the Sea’. They carried all the bronze pieces away to Babylon."
    },
    {
      "verse": "18",
      "text": "They also took away the pots, the bowls, the spades, the small tools for the lamps, and the dishes. They took all the bronze tools that the priests used in the temple."
    },
    {
      "verse": "19",
      "text": "Captain Nebuzaradan also took away everything that was made from gold or silver. He took the dishes, the baskets that carried hot coals, the bowls for water, the pots, the lampstands and other bowls."
    },
    {
      "verse": "20",
      "text": "The bronze from the things that King Solomon had made for the Lord's temple was very heavy. They included the two bronze pillars, the large bath called ‘the Sea’, the 12 bronze bulls under the bath and the carts which carried the buckets for water. The bronze from all these things was more than they could weigh."
    },
    {
      "verse": "21",
      "text": "metres high and 5 metres around. The bronze was 8 centimetres thick and each pillar was empty inside."
    },
    {
      "verse": "22",
      "text": "The bronze piece on the top of one pillar was more than a metre high. It had rows of chains with images of pomegranates made from bronze all around it. The other pillar, with its rows of chains and pomegranates, was the same."
    },
    {
      "verse": "23",
      "text": "images of pomegranates around the sides of the pillars. There were 100 images of pomegranates on the chains at the top."
    },
    {
      "verse": "24",
      "text": "Captain Nebuzaradan took hold of these people: Seraiah, the leader of the priests. Zephaniah, the next most important priest. The three temple guards."
    },
    {
      "verse": "25",
      "text": "He also took hold of these people who remained in Jerusalem: The palace officer with authority over the soldiers. Seven of the king's advisors. The army secretary who took men to join the army. 60 other people of Judah who were inside the city."
    },
    {
      "verse": "26",
      "text": "Captain Nebuzaradan took hold of all those people. He brought them to the king of Babylon at Riblah. That was how Judah's people went into exile, away from their own land."
    },
    {
      "verse": "27",
      "text": "There, at Riblah in the Hamath region, the king of Babylon commanded his soldiers to punish them all with death. That was how Judah's people went into exile, away from their own land."
    },
    {
      "verse": "28",
      "text": "This is a list of the number of people that Nebuchadnezzar took away as prisoners to Babylon: He took 3, 023 people from Judah in his seventh year as king."
    },
    {
      "verse": "29",
      "text": "people from Jerusalem in his 18th year."
    },
    {
      "verse": "30",
      "text": "people from Judah in Nebuchadnezzar's 23rd year as king. So Nebuchadnezzar took 4, 600 people away as his prisoners."
    },
    {
      "verse": "31",
      "text": "years after King Jehoiachin of Judah had gone as a prisoner to Babylon, Evil-Merodach became the king of Babylon. On the 25th day of the 12th month, he took Jehoiachin out from his prison so that he became free."
    },
    {
      "verse": "32",
      "text": "King Evil-Merodach spoke in a kind way to Jehoiachin. He gave him more honour than the other kings who were with him in Babylon."
    },
    {
      "verse": "33",
      "text": "Jehoiachin no longer had to wear the clothes of a prisoner. Every day for the rest of his life, he ate a meal at the king's table in Babylon."
    },
    {
      "verse": "34",
      "text": "The king of Babylon gave Jehoiachin everything that he needed each day of his life until he died."
    }
  ]
};