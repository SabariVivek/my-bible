module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "Amos was one of the shepherds who lived in the town of Tekoa. God spoke to him. He showed Amos the things that would happen to the people of Israel. God did that two years before the earthquake came. It was during the time that Uzziah was the king of Judah, and Joash's son, Jeroboam, was the king of Israel. This book tells about the message that Amos received from God."
    },
    {
      "verse": "2",
      "text": "Amos said, ‘The Lord speaks loudly from Zion. Yes, he shouts from Jerusalem. As a result, the green fields will become dry and the grass will die. There will be nothing for the sheep to eat. Even the grass on Mount Carmel mountain will die. ’"
    },
    {
      "verse": "3",
      "text": "The Lord says, ‘The people in Damascus have done more and more wrong things. So I will certainly punish them! They have been cruel to the people in Gilead. They used their iron weapons to tear them into pieces."
    },
    {
      "verse": "4",
      "text": "I will send a fire to destroy the palace that King Hazael built. It will destroy the strong buildings of King Ben-Hadad."
    },
    {
      "verse": "5",
      "text": "I will also break the strong gates of the city of Damascus. I will remove all the people who live in the Aven valley. I will remove the king of Beth-Eden. Their enemies will take the people of Syria far away to Kir as prisoners. ’ That is what the Lord says."
    },
    {
      "verse": "6",
      "text": "The Lord says, ‘The people in Gaza have done more and more wrong things. So I will certainly punish them. They caught my people and they took them away from their homes. They sold them to the people in Edom."
    },
    {
      "verse": "7",
      "text": "So I will send a fire to burn the walls of Gaza. It will destroy the strong buildings in Gaza."
    },
    {
      "verse": "8",
      "text": "I will remove the king of Ashdod city. And I will remove the king who rules in Ashkelon city. I will punish the people who live in Ekron city. All the Philistines who remain will die. ’ That is what the Lord God says."
    },
    {
      "verse": "9",
      "text": "The Lord says, ‘The people in Tyre have done more and more wrong things. So I will certainly punish them. Before, they had been friends with the people in Israel. They had promised to those people, “We will be like brothers. ” But the people from Tyre did not do what they had promised. They took my people away. They sold my people to the people in Edom and my people became slaves."
    },
    {
      "verse": "10",
      "text": "So I will start a fire on the walls of Tyre city. And the fire will burn all the strong buildings. It will destroy them completely. ’"
    },
    {
      "verse": "11",
      "text": "The Lord says, ‘The people in Edom have done more and more wrong things. So I will certainly punish them. They took their swords and they chased after their cousins, the Israelites. They were not kind. Instead, they continued to be angry all the time. They did not stop attacking them."
    },
    {
      "verse": "12",
      "text": "So I will start a fire. And the fire will destroy the big city of Teman. The fire will also burn the strong buildings of Bozrah city. ’"
    },
    {
      "verse": "13",
      "text": "The Lord says, ‘The people in Ammon have done more and more wrong things. So I will certainly punish them. People from Ammon fought against the people in Gilead. Ammon's people wanted to get more land for themselves. While they were killing people there, they also cut pregnant women open."
    },
    {
      "verse": "14",
      "text": "So I will send fire. And the fire will destroy the walls of Rabbah city. It will destroy the strong buildings too. People will fight and they will shout. They will shout loudly, like the noise that a strong wind makes in a storm."
    },
    {
      "verse": "15",
      "text": "The enemies will take away their king and their leaders. They will take them to another country. The king and the leaders will not be free to return. ’ That is what the Lord says."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "The Lord says, ‘The people in Moab have done more and more wrong things. So I will certainly punish them. They dug up the bones of Edom's king. They burned his bones until they became ashes."
    },
    {
      "verse": "2",
      "text": "So I will send fire to the country called Moab. The fire will destroy the strong buildings in Kerioth town. The people will hear their enemies shout. And they will hear the sounds that their enemies' trumpets make. And the people will die."
    },
    {
      "verse": "3",
      "text": "I will let the enemies kill the ruler of Moab. And I will let them kill all its leaders too. ’ That is what the Lord says."
    },
    {
      "verse": "4",
      "text": "The Lord says, ‘The people in Judah have done more and more wrong things. So I will certainly punish them. They refused to obey my laws and my commands. They have listened to their false gods, Those are the same false gods that their ancestors served."
    },
    {
      "verse": "5",
      "text": "So I will send fire to Judah. The fire will completely burn the strong buildings that are in Jerusalem. ’"
    },
    {
      "verse": "6",
      "text": "The Lord says, ‘The people in Israel have done more and more wrong things. So I will certainly punish them. They sold people that did not do wrong things. They sold them for silver. And they sold poor people for only the price of shoes."
    },
    {
      "verse": "7",
      "text": "They are not kind to poor people and they do not help them. A father and his son have sex with the same woman. They do not respect the holy way that I want them to live."
    },
    {
      "verse": "8",
      "text": "When they lend money to poor people, they take the poor people's clothes. They do not return the clothes each night, as they should do. Instead they sleep on the clothes themselves. They do that at the places where they worship their gods. The rich people take money from poor people. They use that money to buy wine for themselves. Then they drink the wine in the temples of their gods."
    },
    {
      "verse": "9",
      "text": "Remember the Amorites. They were big and strong. They were like the tallest cedar trees and the strongest oak trees. But I destroyed all of them."
    },
    {
      "verse": "10",
      "text": "I brought you out of Egypt. After that, I led you through the wilderness for 40 years. Then I took you to the land where the Amorites lived, so that it would belong to you."
    },
    {
      "verse": "11",
      "text": "I chose some men among you to be prophets, and some to be Nazirites. You Israelites know that it is true. ’ That is what the Lord says."
    },
    {
      "verse": "12",
      "text": "‘But you told the Nazirites to drink wine, like everyone else. And you said to the prophets, “Do not speak messages from God. ”"
    },
    {
      "verse": "13",
      "text": "So I will punish you. A cart that has a heavy load pushes down on the ground. That is how I will push down on you."
    },
    {
      "verse": "14",
      "text": "You might try to run away. But nobody will get free. Even the fastest runner will not get free. The strong people will not be strong enough to stop me. The soldiers will not be able to save their lives."
    },
    {
      "verse": "15",
      "text": "Soldiers who shoot arrows will have to turn back. Fast runners will not save their lives. Soldiers who ride on horses will also die."
    },
    {
      "verse": "16",
      "text": "At that time, strong, brave soldiers will run away without their clothes. ’ That is what the Lord says."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "You Israelites, listen to this message that the Lord speaks against you. This message is to all you people that he saved from Egypt."
    },
    {
      "verse": "2",
      "text": "He says, ‘There are many nations of people on the earth. But I chose you alone to belong to me. So I will punish you when you do wrong things. ’"
    },
    {
      "verse": "3",
      "text": "If two people travel together, they have first agreed to meet together."
    },
    {
      "verse": "4",
      "text": "If a lion roars in the forest, it means that he has killed an animal to eat. A young lion does not shout unless he has caught something."
    },
    {
      "verse": "5",
      "text": "If there is no food in a trap, a bird will not fly into it. If the door of the trap closes, it means that it has caught something."
    },
    {
      "verse": "6",
      "text": "Also, if the people in a city hear a trumpet's sound, they become very afraid. If bad trouble comes to a city, it means that the Lord has sent it."
    },
    {
      "verse": "7",
      "text": "Before the Lord God decides to send trouble, he first tells his prophets about it."
    },
    {
      "verse": "8",
      "text": "So now the lion has roared! Everyone should be afraid! The Lord God has spoken, so his prophets must tell his message."
    },
    {
      "verse": "9",
      "text": "Tell this message now in Ashdod city. Go to the strong cities in Egypt and speak the message there. Say this: ‘Come to the mountains in Samaria. Look at the cruel things that people are doing in Samaria. Many people are afraid. ’"
    },
    {
      "verse": "10",
      "text": "The Lord says, ‘People have forgotten how to be honest. They rob people and they store valuable things in their big houses. They become rich because they are so cruel. ’"
    },
    {
      "verse": "11",
      "text": "So the Lord God says, ‘Enemies will come to attack your land. They will destroy your strong buildings. They will take all your good things from you. ’"
    },
    {
      "verse": "12",
      "text": "The Lord says, ‘When a lion catches a young sheep, the shepherd will try to save as much as he can. He might save only two legs, or a small part of an ear. It will be the same for the Israelites who live in Samaria. They will escape with only a piece of a bed, or a bit of cloth. ’"
    },
    {
      "verse": "13",
      "text": "The Lord God Almighty said to me, ‘Listen! Go and warn the Israelites that they have done wrong things."
    },
    {
      "verse": "14",
      "text": "I will punish them because they have not obeyed my Law. I will destroy the altars at Bethel. The horns of the altar will break off and they will fall to the ground."
    },
    {
      "verse": "15",
      "text": "I will destroy all their houses, the homes that they live in during the winter, and the ones that they live in during the summer. I will completely destroy all their big, beautiful houses, with their valuable things made from ivory. ’ That is what the Lord says."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Listen to this message, you women who live on the hill in Samaria. You are like fat cows that do not work hard for food. You are like the cows in Bashan. They eat on very good land by the Jordan river. You do not give to weak people what they need. You are not fair to poor people. Then you sit down and you say to your husbands, ‘Bring us more to drink. ’"
    },
    {
      "verse": "2",
      "text": "The Lord God has made this promise and he speaks only true words. He says, ‘The time will come, when your enemies will take you away with meat hooks and fish hooks."
    },
    {
      "verse": "3",
      "text": "There are places in your city's walls where people have broken the walls. Your enemies will pull you through those places and they will throw you out. They will take you to that bad place called Harmon. None of you will stay here. ’"
    },
    {
      "verse": "4",
      "text": "The Lord also says, ‘You like to go to Bethel. You say that it is your holy place. And when you go there, you do wrong things. So go there, if you must, and do your bad things. Go to Gilgal, if you must, and do more bad things there. You bring your sacrifices there every morning as a gift. But that does not make me happy. Every three days, you bring your gifts. But that also does not make me happy."
    },
    {
      "verse": "5",
      "text": "You bring bread to say “thank you”. You even bring lots of it and you tell everyone, “Look at how much I have brought. ” You really like to do that. So continue to do it, but it does not make me happy. ’ The Lord God says this!"
    },
    {
      "verse": "6",
      "text": "‘Earlier I made you hungry in all your cities. There was no food anywhere. But you did not start to pray to me again. ’ The Lord says this!"
    },
    {
      "verse": "7",
      "text": "‘Three months before your food was ready to pick, I did not send rain. So all the food became too dry. Sometimes I sent rain to one city, but I did not send it to other cities. I sent rain to one person's land, but I did not send it to another person's land. So that other person's land became too dry."
    },
    {
      "verse": "8",
      "text": "People became weak. They went from city to city to look for water. They were almost too weak to walk. There was not enough water. But still you did not start to pray to me again. ’ The Lord says this!"
    },
    {
      "verse": "9",
      "text": "‘I sent hot winds from the east. They burned the small plants, so those plants died. Worms made the other plants sick. So the other plants died. Locusts ate your trees that give fruit. But still you did not start to pray to me again. ’ The Lord says this! ."
    },
    {
      "verse": "10",
      "text": "‘I caused many people among you to become very sick. It was like what happened many years ago in Egypt. At that time, very many people got sick. Then I sent soldiers to you. And they killed your young men and they took away your horses. The smell from dead bodies was very bad. But you still did not start to pray to me again. ’ The Lord says this!"
    },
    {
      "verse": "11",
      "text": "‘I killed many people among you, as I destroyed the cities called Sodom and Gomorrah. Some of you did not die. You were like a stick that is already burning. And someone saves it from the fire. But still you did not start to pray to me again. ’ The Lord says this!"
    },
    {
      "verse": "12",
      "text": "‘So I will send trouble to you Israelites again. Get ready! You will see it. Then you will know that I have come to judge you."
    },
    {
      "verse": "13",
      "text": "I made the mountains and I made the wind. I tell people what I have decided to do. I change dawn into night. I walk on the high places of the earth. My name is the Lord God Almighty. ’"
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "You people of Israel's family, listen to the sad song that I will sing about you:"
    },
    {
      "verse": "2",
      "text": "‘You are like a young woman that died young, without children. Now you have fallen down and you will not rise up again. You lie there on the ground. There is nobody there to help you to get up. ’"
    },
    {
      "verse": "3",
      "text": "This is what the Lord God says to you: ‘1, 000 soldiers will go out from a city to fight, but only 100 soldiers will come back. From another city, 100 soldiers will go out to fight, but only ten will come back. ’"
    },
    {
      "verse": "4",
      "text": "To the people of Israel's family, the Lord says, ‘Come back to me and you will live."
    },
    {
      "verse": "5",
      "text": "Do not go to Bethel, Gilgal, or Beersheba. Do not try to find me there, because I am not there. I will send enemies to destroy those places. They will take the people away as slaves. ’"
    },
    {
      "verse": "6",
      "text": "Return to the Lord and you will live. If you do not do that, he will come like fire to punish you. He will completely destroy Joseph's descendants. Bethel and all its people will burn. Nobody will be able to stop the fire."
    },
    {
      "verse": "7",
      "text": "You people change what is right and true to make lies. You are not fair or honest."
    },
    {
      "verse": "8",
      "text": "The Lord made the groups of stars called Pleiades and Orion. The Lord changes the night into dawn, and he changes the day back to night again. He takes the water in the sea, and he pours it out as rain on the earth. The Lord is his name!"
    },
    {
      "verse": "9",
      "text": "He quickly destroys strong people. He knocks down their strong buildings and their walls."
    },
    {
      "verse": "10",
      "text": "‘You Israelites hate honest judges. You laugh at anyone who speaks the truth."
    },
    {
      "verse": "11",
      "text": "You cheat poor people so that they pay too much tax. You take away their food for yourselves. Because of that, you will not live in the beautiful houses that you have built for yourselves. You will not drink wine from the vines that you have planted."
    },
    {
      "verse": "12",
      "text": "I, the Lord, know all the wrong things that you have done. They are very many and they are very bad. You are cruel to good people. You take bribes to tell lies. Sometimes a person gives money to you to make you tell lies. As a result, poor people do not receive justice."
    },
    {
      "verse": "13",
      "text": "This is such an evil time that clever people say nothing. That is how they keep themselves safe. ’"
    },
    {
      "verse": "14",
      "text": "You say that the Lord God Almighty is with you. Stop doing evil things. Do good things, so that you will live. Then the Lord God Almighty will really be with you, as you say."
    },
    {
      "verse": "15",
      "text": "Hate evil things and love good things. When you judge people, be fair and honest. Then maybe the Lord God Almighty will be kind to those of his people who still remain, Joseph's descendants."
    },
    {
      "verse": "16",
      "text": "The Lord, the Lord God Almighty says, ‘All the people will be sad. They will weep and cry loudly in all the streets. They will tell the farmers to weep with them. They will tell the singers to sing sad songs for them."
    },
    {
      "verse": "17",
      "text": "In every field and garden, people will be weeping, because I will come to punish them all. ’ That is what the Lord says."
    },
    {
      "verse": "18",
      "text": "You want the special day of the Lord to come. But it will be very bad for you! You think that God will punish your enemies on that day. But that day will not bring light to you, it will bring darkness."
    },
    {
      "verse": "19",
      "text": "Nobody will escape! It will be like a man who runs away from a lion, but then he meets a bear! When he goes into his house to be safe, he puts his hand on a wall and a snake bites him!"
    },
    {
      "verse": "20",
      "text": "Know this: The day of the Lord will be dark, not light. It will bring trouble, not joy."
    },
    {
      "verse": "21",
      "text": "The Lord says, ‘When you have your festivals, I hate them! When you meet to worship me, it does not make me happy!"
    },
    {
      "verse": "22",
      "text": "When you bring burnt offerings and grain offerings to me, they do not please me. I will not accept your friendship offerings of fat animals."
    },
    {
      "verse": "23",
      "text": "When you sing songs to worship me, I will not listen. They are just noise! I do not want to hear the music of your harps."
    },
    {
      "verse": "24",
      "text": "What I do want to see is justice! I want to see that you always do what is right. Those good things should never stop, like a river that always runs with water."
    },
    {
      "verse": "25",
      "text": "You people of Israel's family, listen to me! I led you through the wilderness for 40 years. During that time, did you worship me with sacrifices and offerings? No!"
    },
    {
      "verse": "26",
      "text": "Instead, you have idols that you have made for yourselves. You have the idol of Sakkuth, your king. You have the idol of Kaiwan, your star god. Now you will have to carry them with you. That is what the Lord says, and he is God Almighty."
    },
    {
      "verse": "27",
      "text": "I will send you away as prisoners. Your enemies will take you beyond Damascus. ’That is what the Lord says, and he is God Almighty."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "Trouble is coming to you people who live in Zion and on Samaria's hill. You think that you are safe. You think that you are important people who live in the best nation on earth. Israelite people respect you as their leaders."
    },
    {
      "verse": "2",
      "text": "Go and look at Calneh city. And go and look at Hamath city. Then go and look at Gath city, where the Philistines live. Are your cities stronger than their cities? Do you have more land than they do?"
    },
    {
      "verse": "3",
      "text": "You refuse to think that trouble might come to you. But the cruel things that you do are causing trouble to come very soon."
    },
    {
      "verse": "4",
      "text": "You lie on beautiful, expensive beds. You do not work, but you rest all the time. You eat fat young sheep and cows."
    },
    {
      "verse": "5",
      "text": "Like King David, you play music on your harps and you sing new songs."
    },
    {
      "verse": "6",
      "text": "You drink lots of wine. You put beautiful oils on your bodies. But you are not sad that Joseph's descendants are destroying themselves as a nation."
    },
    {
      "verse": "7",
      "text": "You will be the first people that your enemies will take away as prisoners. You will no longer enjoy your feasts and wild parties."
    },
    {
      "verse": "8",
      "text": "The Lord God Almighty has promised that this will surely happen. He has spoken this strong message: ‘The Israelites think that they are very strong. But I have turned against them. I hate their strong buildings. So I will give their great city and everything in it to their enemies. ’"
    },
    {
      "verse": "9",
      "text": "At that time, if ten people are safe together in one house, they will still all die."
    },
    {
      "verse": "10",
      "text": "When a man comes to carry a dead body outside to burn it, he will ask his relative, ‘Is there anyone with you in the house? ’ The relative will answer, ‘No. ’ Then the man will say, ‘Be quiet! . Do not speak the name of the Lord! ’"
    },
    {
      "verse": "11",
      "text": "When the Lord gives his command, enemies will destroy all the houses, great and small. They will break them all into pieces."
    },
    {
      "verse": "12",
      "text": "Horses cannot run on rocks. People do not try to plough the sea. But you Israelites have changed what is fair and honest into something bad. You have made justice seem like poison."
    },
    {
      "verse": "13",
      "text": "You are proud because you won against Lo-Debar and Karnaim. You think that your own strength did that."
    },
    {
      "verse": "14",
      "text": "But the Lord God Almighty says to you Israelites, ‘I am sending an enemy nation to attack you. They will bring trouble to you everywhere, all the way from Lebo-Hamath in the north, to the Arabah valley in the south. ’"
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "The Lord God showed a vision to me. I saw a crowd of locusts. The Lord was ready to send them to destroy the crops in the fields. They would come after we had taken the early crops to give to the king. Then the later crops were beginning to make grain."
    },
    {
      "verse": "2",
      "text": "I saw that the locusts came and they ate everything. I asked the Lord, ‘Lord God, please forgive your people. We cannot continue to live if those locusts destroy our food. We are too weak! ’"
    },
    {
      "verse": "3",
      "text": "Then the Lord decided not to do it. He said to me, ‘That will not happen. ’"
    },
    {
      "verse": "4",
      "text": "After that, the Lord God showed to me a vision of a fire. He was ready to send it to punish us. I saw that it caused the deep sea to become dry. It also burnt all the land."
    },
    {
      "verse": "5",
      "text": "I said, ‘Lord God, please do not do that! Your people cannot continue to live. We are too weak! ’"
    },
    {
      "verse": "6",
      "text": "Then the Lord decided not to do it. He said to me, ‘That too will not happen. ’"
    },
    {
      "verse": "7",
      "text": "Then the Lord showed this vision to me. The Lord God was standing next to a wall. In his hand was a string with a heavy weight on its end. The Lord was hanging the string down the wall. He was looking to see whether the wall was straight. The Lord said, ‘Understand this. I am ready to measure my people with this string. I will test them and I will punish them for their sins. I will not forgive them any more."
    },
    {
      "verse": "8",
      "text": "He asked me, ‘Amos, what do you see? ’ I said, ‘You are measuring the wall to see if it is straight. ’The Lord said, ‘Understand this. I am ready to measure my people with this string. I will test them and I will punish them for their sins. I will not forgive them any more."
    },
    {
      "verse": "9",
      "text": "I will send enemies to destroy the holy places of Isaac's descendants. All Israel's holy places will fall down. Enemies will use swords to kill King Jeroboam and his family. ’"
    },
    {
      "verse": "10",
      "text": "Amaziah, was a priest at the holy place called Bethel. He sent a message to Jeroboam, the king of Israel. He said, ‘Amos is speaking against you among all Israel's people. What he is saying will deceive the people of our nation."
    },
    {
      "verse": "11",
      "text": "Amos is saying, “Our enemies will kill King Jeroboam. They will take all the people to a foreign country as prisoners. ” ’"
    },
    {
      "verse": "12",
      "text": "Then Amaziah said to Amos, ‘Go away, you prophet! Go back to your own country, Judah. Speak your messages from God to get your food there!"
    },
    {
      "verse": "13",
      "text": "Do not speak God's message here in Bethel any longer. It is where our king and our nation come to worship. ’"
    },
    {
      "verse": "14",
      "text": "Then Amos answered Amaziah, ‘My job was not as a prophet. My father never did that work. My job was to work as a shepherd. I also took care of fig trees."
    },
    {
      "verse": "15",
      "text": "But the Lord told me to leave my work as a shepherd. He told me to go and to speak his message to his people, the Israelites."
    },
    {
      "verse": "16",
      "text": "So listen to the Lord's message to you! You are telling me, “Do not speak God's message against Israel. Do not say that trouble is coming to Isaac's descendants. ”"
    },
    {
      "verse": "17",
      "text": "The Lord says this to you, Amaziah: “Your wife will work as a prostitute in the streets. Your sons and daughters will die in war. Enemies will measure your land into separate pieces and they will give it to others. They will take your people away from here as prisoners to a foreign country. And that is where they will die. ” ’"
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Then the Lord God showed another vision to me. I saw a basket with summer fruit in it."
    },
    {
      "verse": "2",
      "text": "He asked me, ‘Amos, what do you see? ’ I answered him, ‘I see a basket of summer fruit. ’ Then the Lord said to me, ‘The time has now come to punish my people. I will not forgive them any longer."
    },
    {
      "verse": "3",
      "text": "On the day that I come to punish them, people will not sing in the temple. Instead they will weep loudly. There will be dead bodies everywhere. Be quiet now! ’ That is what the Lord God says."
    },
    {
      "verse": "4",
      "text": "So listen to me, you who are cruel to helpless people. You try to destroy people who are poor and weak."
    },
    {
      "verse": "5",
      "text": "You say to yourselves, ‘We want the new moon festival to finish so that we can sell food again. We want our Sabbath day of rest to finish so that we can sell grain. ’ But when you sell things, you cheat the people who buy from you. You deceive them with false weights, and you make the price too high."
    },
    {
      "verse": "6",
      "text": "When poor people cannot pay their debts, you buy them as your slaves. You pay a silver coin to buy them, which would not even buy a pair of shoes. You also mix dust with the grain that you sell."
    },
    {
      "verse": "7",
      "text": "The Lord has promised this: ‘You proud descendants of Jacob, I will never forget the wrong things that you have done."
    },
    {
      "verse": "8",
      "text": "The whole country will shake because of your sins. Everyone who lives there will weep. The ground will rise up, like the floods of the Nile river in Egypt. Then it will go down again, like the water of the Nile. ’"
    },
    {
      "verse": "9",
      "text": "The Lord God says, ‘At that time, I will make the sun go down at noon. I will make the earth become dark in the daytime."
    },
    {
      "verse": "10",
      "text": "Your parties will become funerals. You will not sing happy songs but you will weep. You will wear rough clothes and you will cut off all your hair. You will be as sad as if your only son had died. That will be a very bad day for you. ’"
    },
    {
      "verse": "11",
      "text": "The Lord God says, ‘Listen to me! At that time, I will cause you to be very hungry. It will not be because you need food and water. Instead, everyone in the land will want to hear a message from me."
    },
    {
      "verse": "12",
      "text": "People will travel everywhere in the country, north and south, east and west. They will want to hear a message from the Lord, but there will be nothing for them to hear."
    },
    {
      "verse": "13",
      "text": "At that time, your beautiful young women and your young men will become very thirsty. They will be weak and tired."
    },
    {
      "verse": "14",
      "text": "They worship Samaria's idols. They use the names of those false gods to make promises. They say, “In the name of the god of Dan, ” or “In the name of the god of Beersheba. ” Those people will fall down and they will never get up again. ’"
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "Then I saw a vision of the Lord. He was standing beside the altar in the temple. The Lord said, ‘Hit the tops of the pillars so that the whole foundation shakes! Cause the building to fall on the heads of all the people. If anyone is still alive after that, I will cause them to die in battle. Nobody will escape!"
    },
    {
      "verse": "2",
      "text": "They might try to dig deep into the earth to save themselves. But my strong hand will pull them out of there. They might climb up into the sky. But I will pull them down from there."
    },
    {
      "verse": "3",
      "text": "They might try to hide on the top of Mount Carmel. But I will find them and I will take them from there. They might try to hide from me deep down in the sea. But I will command the great sea snake to bite them."
    },
    {
      "verse": "4",
      "text": "Even when their enemies take them away as prisoners, I will cause them to die in battle. I have decided to destroy them. I will not help them. ’"
    },
    {
      "verse": "5",
      "text": "The Lord God Almighty will do this! When he touches the earth, it shakes. Everyone who lives there weeps. The ground rises up, like the water of the Nile river in Egypt. Then it goes down again, like the river."
    },
    {
      "verse": "6",
      "text": "The Lord builds his palace up into heaven, with its foundation on the earth. He takes up the water from the sea, and he pours it out on the earth as rain. The Lord is his name."
    },
    {
      "verse": "7",
      "text": "The Lord says, ‘You Israelite people, do not think that you are more important to me than the people of Ethiopia. It is true that I led you safely out of Egypt. But I also brought the Philistines from Crete. And I brought the Aramean people from Kir."
    },
    {
      "verse": "8",
      "text": "I, the Lord God, am carefully watching you Israelites. I see that you are a wicked nation, so I will remove you from the earth. But I will not completely destroy all the descendants of Jacob. ’ That is what the Lord says."
    },
    {
      "verse": "9",
      "text": "‘Listen to me! I will cause trouble to come to Israel's family, as they live among other nations. It will be like a person who shakes a sieve to remove dirt from grain."
    },
    {
      "verse": "10",
      "text": "Those among my people who do bad things will die. They say, “God will not send trouble to us. Nothing bad will happen to us. ” But their enemies will kill those bad people in war. ’"
    },
    {
      "verse": "11",
      "text": "The Lord says, ‘When that time comes, I will make David's kingdom strong again. It has become like a broken hut, but I will repair it. I will cause it to become as good and strong as it was when king David ruled. That is what the Lord says, and he will do it."
    },
    {
      "verse": "12",
      "text": "You Israelites will fight the Edomites who still remain. You will win against them and the other nations that once belonged to me. ’That is what the Lord says, and he will do it."
    },
    {
      "verse": "13",
      "text": "The Lord says, ‘The time will come when food will grow very well in your fields. People will need to work quickly to cut down all their crops before they plough the ground to plant again. Lots of grapes will grow on your vines. People will work quickly to make wine from the grapes before they plant new vines. So much juice will pour out of the grapes that it will run down the hills!"
    },
    {
      "verse": "14",
      "text": "I will bring the people of Israel, my people, back to their own land. Enemies destroyed their cities, but now my people will build them again. They will live safely in them. My people will plant vines. They will drink wine from their grapes. They will eat the fruit from trees that they have planted in their gardens. That is what the Lord your God says."
    },
    {
      "verse": "15",
      "text": "And I will plant my people in their own land. That is the land that I have given to them, and nobody will ever pull them out of that land. ’That is what the Lord your God says."
    }
  ]
};