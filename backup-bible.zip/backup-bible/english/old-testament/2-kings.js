module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "After King Ahab's death, the country of Moab turned against Israel."
    },
    {
      "verse": "2",
      "text": "At this time, Ahaziah was king of Israel. He lived in the city of Samaria. One day he fell from the window of an upstairs room in his palace. He became very ill. So he sent men to the temple of Baal-Zebub, the god of Ekron. He told them, ‘Ask their god if I will become well again after my disease. ’"
    },
    {
      "verse": "3",
      "text": "Then the angel of the Lord spoke to Elijah. He was a prophet who came from Tishbe. The angel said, ‘Go and meet the men that the king of Samaria has sent. Say to them, “Do you think that there is no God in Israel? Is that why you are going to Ekron's god, Baal-Zebub, to ask if the king will be well again? ”"
    },
    {
      "verse": "4",
      "text": "Because you are doing this, the Lord says to you, Ahaziah, “You will never leave the bed that you are lying on. You will certainly die. ” ’"
    },
    {
      "verse": "5",
      "text": "Elijah went to tell the men the Lord's message. So the men returned to the king. He asked them, ‘Why have you returned already? ’"
    },
    {
      "verse": "6",
      "text": "They replied, ‘A man came to meet us. He told us to go back to the king who had sent us. He says to you, “This is what the Lord says: Why have you sent men to speak to Ekron's god, Baal-Zebub? You seem to think that there is no God in Israel. Because of that, you will not leave the bed that you are lying on. You will certainly die. ” ’"
    },
    {
      "verse": "7",
      "text": "The king asked them, ‘Describe the man who came to meet you. What did he look like? ’"
    },
    {
      "verse": "8",
      "text": "They replied, ‘He was wearing rough clothes. He had tied a leather belt around him. ’ Then the king said, ‘That was Elijah, the prophet from Tishbe. ’"
    },
    {
      "verse": "9",
      "text": "soldiers with their captain to fetch Elijah. Elijah was sitting on the top of a hill. The captain went up and he said to Elijah, ‘Man of God, the king says, “Come down with us. ” ’"
    },
    {
      "verse": "10",
      "text": "Elijah replied to the captain, ‘If I am really a man of God, fire will come down from the sky. It will destroy you and your 50 soldiers. ’ Then fire did come down from the sky. It destroyed the captain and his 50 soldiers."
    },
    {
      "verse": "11",
      "text": "more soldiers to fetch Elijah. The captain went up and he said to Elijah, ‘Man of God, the king says, “Come down immediately! ” ’"
    },
    {
      "verse": "12",
      "text": "Elijah answered, ‘If I am really a man of God, fire will come down from the sky. It will destroy you and your 50 soldiers. ’ Then fire from God did come down from the sky. It destroyed the captain and his 50 soldiers."
    },
    {
      "verse": "13",
      "text": "So the king sent a third captain, with 50 more soldiers. This captain went up to Elijah. He bent down on his knees in front of Elijah to ask him to be kind to them. He said, ‘Man of God, we are your servants. Please do not kill me and my 50 soldiers."
    },
    {
      "verse": "14",
      "text": "We know that fire came down from the sky. It destroyed the two captains who came before me and all their soldiers. But now, please be kind and do not kill me. ’"
    },
    {
      "verse": "15",
      "text": "The angel of the Lord said to Elijah, ‘Go down with him. Do not be afraid of him. ’ So Elijah went down with the captain to meet the king."
    },
    {
      "verse": "16",
      "text": "Elijah said to the king, ‘This is what the Lord says: You sent men to speak to Ekron's god, Baal-Zebub, to find out what would happen to you. Did you think that there is no God in Israel? You did not ask him what would happen. Because of that, you will not leave the bed that you are lying on. You will certainly die. ’"
    },
    {
      "verse": "17",
      "text": "So Ahaziah died. The Lord had told Elijah that this would happen. Ahaziah had no son, so his brother, Joram, became king after him. This happened in the second year that Jehoshaphat's son, Jehoram, ruled Judah as king."
    },
    {
      "verse": "18",
      "text": "The other things that happened while Ahaziah was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about the things that King Ahaziah did."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "The Lord was now ready to take Elijah up to heaven in a storm of wind. At this time, Elijah and Elisha were travelling from Gilgal."
    },
    {
      "verse": "2",
      "text": "Elijah said to Elisha, ‘Stay here, because the Lord has sent me to Bethel. ’ But Elisha replied, ‘I will not leave you. I promise that, as surely as the Lord lives and as surely as you also live. ’So they went down to Bethel together."
    },
    {
      "verse": "3",
      "text": "A group of prophets lived in Bethel. They came out to Elisha and they asked him, ‘Do you know that the Lord will take your master away from you today? ’ Elisha replied, ‘Yes, I do know that, but do not talk about it now. ’"
    },
    {
      "verse": "4",
      "text": "Then Elijah said to Elisha, ‘Stay here, because the Lord has sent me to Jericho. ’ But Elisha replied, ‘I will not leave you. I promise that, as surely as the Lord lives and as surely as you live. ’So they went to Jericho together."
    },
    {
      "verse": "5",
      "text": "A group of prophets lived in Jericho. They went out to Elisha and they asked him, ‘Do you know that the Lord will take your master away from you today? ’ Elisha replied, ‘Yes, I do know that, but do not talk about it now. ’"
    },
    {
      "verse": "6",
      "text": "Then Elijah said to Elisha, ‘Stay here, because the Lord has sent me to the Jordan River. ’ But Elisha replied, ‘I will not leave you. I promise that, as surely as the Lord lives and as surely as you live. ’So they continued to travel together."
    },
    {
      "verse": "7",
      "text": "men who belonged to the group of prophets went and they stood near the Jordan River. They were standing not far away from Elijah and Elisha. They watched what happened."
    },
    {
      "verse": "8",
      "text": "Elijah took off his coat. He rolled it up and he hit the water with it. The water became separate to the left side and to the right side. Elijah and Elisha went across the river on dry ground."
    },
    {
      "verse": "9",
      "text": "After they had crossed the river, Elijah said to Elisha, ‘The Lord will soon take me away from you. What do you want me to do for you before that happens? ’ Elisha replied, ‘Please let me have twice as much of your spirit. ’"
    },
    {
      "verse": "10",
      "text": "Elijah said, ‘You have asked a difficult thing. But watch carefully when God takes me from you. If you see it happen, you will receive that spirit. If you do not see me, you will not receive it. ’"
    },
    {
      "verse": "11",
      "text": "So they walked along and they talked together. Suddenly a chariot that was burning with fire appeared. The horses that pulled it were also burning with fire. The chariot went between Elijah and Elisha. Elijah went up to heaven in a storm of wind."
    },
    {
      "verse": "12",
      "text": "When Elisha saw this, he shouted, ‘My father! My father! You are riding in Israel's chariot! Israel's men are riding on the horses! ’After that, Elisha could not see Elijah again. He took hold of his own clothes and he tore them into pieces because he was very upset."
    },
    {
      "verse": "13",
      "text": "He picked up Elijah's coat that had fallen off. He went and he stood on the shore of the Jordan River."
    },
    {
      "verse": "14",
      "text": "He took Elijah's coat and he hit the water with it. He said, ‘Now is the Lord, Elijah's God, with me? ’ When he hit the water with Elijah's coat, the water became separate, to the left side and to the right side. Elisha went across the river."
    },
    {
      "verse": "15",
      "text": "The group of prophets from Jericho were standing not far away. They saw what happened. They said, ‘The spirit that gave power to Elijah is now with Elisha. ’ They went to meet Elisha. They bent down low to the ground to respect him."
    },
    {
      "verse": "16",
      "text": "They said to him, ‘Please, sir! We are your servants. We have 50 strong men with us. Let them go and look for your master. Perhaps the Spirit of the Lord has carried him away. Maybe it has dropped him somewhere on a mountain or in a valley. ’ But Elisha replied, ‘No. Do not send them to look for him. ’"
    },
    {
      "verse": "17",
      "text": "But the prophets asked him many times to do this. Elisha was too ashamed to refuse. So he said, ‘Send them to look. ’ They sent 50 men who looked for Elijah for three days. But they did not find him."
    },
    {
      "verse": "18",
      "text": "When they returned, Elisha was waiting for them in Jericho. He said to them, ‘I told you not to go and look for Elijah. ’"
    },
    {
      "verse": "19",
      "text": "One day, the leaders in Jericho said to Elisha, ‘Please listen to us, sir. You can see that our city is in a good place. But the water here is bad. The land does not give us good crops. ’"
    },
    {
      "verse": "20",
      "text": "Elisha said, ‘Bring a new bowl to me with some salt in it. ’ So they brought it to him."
    },
    {
      "verse": "21",
      "text": "Then Elisha went out to the city's spring of water. He threw the salt into it. He said, ‘This is what the Lord says: “I have made this water clean again. It will no longer cause people to die. The land will no longer be useless for crops. ” ’"
    },
    {
      "verse": "22",
      "text": "Since that time, the water has always been pure. This is what Elisha had said would happen."
    },
    {
      "verse": "23",
      "text": "Elisha went from Jericho to Bethel. While he travelled along the road, some boys came out of the town. They laughed at Elisha. They shouted at him, ‘Bald man, move on! Go away, you bald man! ’"
    },
    {
      "verse": "24",
      "text": "Elisha turned around and he looked at them. He asked the Lord to punish them. Two bears came out from the forest. They tore 42 of the boys in pieces."
    },
    {
      "verse": "25",
      "text": "Then Elisha travelled to Mount Carmel. From there, he returned to Samaria."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "Ahab's son Jehoram became the king of Israel in Samaria. This happened when Jehoshaphat had been the king of Judah for 18 years. Jehoram ruled Israel as king for 12 years."
    },
    {
      "verse": "2",
      "text": "He did things that the Lord said were evil. But he was not as bad as his father and his mother had been. Jehoram did throw away the stone pillar where people worshipped Baal. His father Ahab had made that pillar."
    },
    {
      "verse": "3",
      "text": "But Jehoram continued to do the same bad things that Nebat's son Jeroboam had done. Jeroboam had caused many people in Israel to do those sins, and Jehoram did not stop doing them himself."
    },
    {
      "verse": "4",
      "text": "Mesha, the king of Moab, was a sheep farmer. Every year he had to pay the king of Israel 100, 000 male lambs and the wool from 100, 000 male sheep. Jehoshaphat replied, ‘Yes, I will go with you. We will have one army. My soldiers will join with your soldiers. My horses will be under your authority. ’"
    },
    {
      "verse": "5",
      "text": "But after King Ahab died, the king of Moab turned against the king of Israel."
    },
    {
      "verse": "6",
      "text": "So King Jehoram left Samaria to bring all Israel's army together. They were ready to attack Moab."
    },
    {
      "verse": "7",
      "text": "He also sent this message to Jehoshaphat, the king of Judah: ‘The king of Moab has turned against me. Will you go with me to fight against the Moabites? ’Jehoshaphat replied, ‘Yes, I will go with you. We will have one army. My soldiers will join with your soldiers. My horses will be under your authority. ’"
    },
    {
      "verse": "8",
      "text": "King Jehoram asked, ‘What road should we go on to attack Moab? ’ King Jehoshaphat replied, ‘We should travel through the Edom desert. ’"
    },
    {
      "verse": "9",
      "text": "So the king of Israel, the king of Judah and the king of Edom joined together to attack Moab. They were travelling along the road for seven days. After that time, there was no more water for the army or for their animals."
    },
    {
      "verse": "10",
      "text": "The king of Israel was very upset. He said, ‘What has happened? Perhaps the Lord has brought us three kings here to put us under the power of the king of Moab! ’"
    },
    {
      "verse": "11",
      "text": "But King Jehoshaphat asked, ‘There must surely be a prophet of the Lord here somewhere. We could ask him what the Lord wants us to do. ’An officer of the king of Israel answered him, ‘Yes, Shaphat's son Elisha is here. He was Elijah's servant. ’"
    },
    {
      "verse": "12",
      "text": "Jehoshaphat said, ‘He will tell us what the Lord is saying. ’ So the king of Israel, King Jehoshaphat and the king of Edom went to meet Elisha."
    },
    {
      "verse": "13",
      "text": "Elisha said to the king of Israel, ‘We have nothing to say to each other! Instead, go to the prophets that your father and your mother liked to listen to. ’ The king of Israel replied, ‘No! The Lord told us three kings to come here together. Now he is putting us under Moab's power. ’"
    },
    {
      "verse": "14",
      "text": "Elisha said to him, ‘I serve the Lord Almighty. I promise you, as surely as the Lord lives, I would never even look at you! But I do respect Jehoshaphat, the king of Judah, who is with you. So I will help you."
    },
    {
      "verse": "15",
      "text": "But now, bring someone to play music on a harp for me. ’While the man was making music, the Lord's power came to Elisha."
    },
    {
      "verse": "16",
      "text": "Elisha said, ‘This is what the Lord says: Dig many holes in this dry valley,"
    },
    {
      "verse": "17",
      "text": "because the Lord says this: You will not see any wind or any rain. But this valley will become full of water! You, your cows and your other animals will have water to drink."
    },
    {
      "verse": "18",
      "text": "This is an easy thing for the Lord to do. He will also put the Moabites under your power."
    },
    {
      "verse": "19",
      "text": "You will destroy all their strong cities and all their important towns. You will cut down every good tree. You will stop their springs giving any water. You will cover their fields with stones so that nothing grows there. ’"
    },
    {
      "verse": "20",
      "text": "The next morning, at the time when they offered the morning sacrifice, the water appeared! It came from the direction of Edom so that the land was full of water!"
    },
    {
      "verse": "21",
      "text": "All the people in Moab had heard that the kings had come to attack them. So the leaders of Moab brought together every man who was old enough to fight. They put these men on Moab's border."
    },
    {
      "verse": "22",
      "text": "When the Moabites woke up early the next morning, the sun was shining on the water. When they looked at the water from where they were, it looked like blood!"
    },
    {
      "verse": "23",
      "text": "They said to each other, ‘That is blood! The armies of those kings have fought against each other. Now they are all dead! We must go and take all their valuable things! ’"
    },
    {
      "verse": "24",
      "text": "So the Moabites arrived at the camp of the Israelite army. Then Israel's soldiers attacked the Moabites. The Moabites ran away back to their own land. The Israelites chased them and they completely destroyed them."
    },
    {
      "verse": "25",
      "text": "They destroyed the Moabites' towns. Each Israelite soldier threw a stone onto all the good fields, until they covered them with stones. They filled the springs so that they gave no water. They cut down all the good trees. Only the city of Kir-Hareseth was still there with its stone walls. But the Israelite soldiers stood all around the city. They attacked it with stones from their slings."
    },
    {
      "verse": "26",
      "text": "The king of Moab realized that he was not winning the battle. So he took 700 of his soldiers who had swords. They tried to attack their enemies and reach the king of Edom. But they failed to do that."
    },
    {
      "verse": "27",
      "text": "So the king of Moab took his oldest son who would have become king after him. He killed him on the wall of the city as a burnt offering to their god. This made the Israelite soldiers become very upset. So they went away from the city and they returned to their own land."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "There was a woman whose husband belonged to the group of prophets. When her husband died, she called out to Elisha for help. She said, ‘Your servant, my husband, is dead. He served the Lord faithfully. My husband was in debt to a certain man. Now that man wants to take my two children to be his slaves. ’"
    },
    {
      "verse": "2",
      "text": "Elisha said to her, ‘How can I help you? Tell me, what things do you have in your house? ’She said to Elisha, ‘Please sir, I have nothing in the house. All I have is a small jar of olive oil. ’ She said to Elisha, ‘Please sir, I have nothing in the house. All I have is a small jar of olive oil. ’"
    },
    {
      "verse": "3",
      "text": "Then Elisha said to her, ‘Go to all your neighbours. Ask them to lend you empty jars. Make sure that you get a lot of them."
    },
    {
      "verse": "4",
      "text": "Then take the jars into your house. Go in with your sons and shut the door behind you. Pour the olive oil from your jar into all the other jars. When each jar is full, put it in a safe place. ’"
    },
    {
      "verse": "5",
      "text": "The widow left Elisha. She went into her house with her sons and she shut the door behind her. They brought the jars to her and she poured the oil into them."
    },
    {
      "verse": "6",
      "text": "When all the jars were full, she said to one of her sons, ‘Bring me another jar. ’ But he said, ‘There are no more jars. ’ Then there was no more olive oil to pour from her jar."
    },
    {
      "verse": "7",
      "text": "Then the widow went back to Elisha, the man of God. She told him what had happened. He said, ‘Go and sell the oil. Use some of the money to pay the debt to the man. Use the money that remains to buy food for you and your sons. Then you will live. ’"
    },
    {
      "verse": "8",
      "text": "One day, Elisha went to Shunem. A rich woman lived there. She asked Elisha to eat a meal with her family. So every time that he went near her house, he stopped there to eat a meal."
    },
    {
      "verse": "9",
      "text": "Then the woman said to her husband, ‘Listen! I believe that this man who often eats with us is a holy man who serves God."
    },
    {
      "verse": "10",
      "text": "We should make a small room on the roof of our house for him. We can put a bed, a table, a chair and a lamp in the room. Then, when he comes to visit us, he can stay there. ’"
    },
    {
      "verse": "11",
      "text": "One day, Elisha came to Shunem again. He went up to the room on the roof. He lay down to rest there."
    },
    {
      "verse": "12",
      "text": "He told Gehazi, his servant, ‘Ask the woman to come here. ’ So Gehazi did that. The woman came and she stood in front of Elisha."
    },
    {
      "verse": "13",
      "text": "Elisha said to Gehazi, ‘Say to her, “You have done a lot to take care of us. So what can we do for you? Can we speak on your behalf to the king, or to the officer who leads the army? ” ’ The woman replied, ‘I live here safely among my own people. ’"
    },
    {
      "verse": "14",
      "text": "But Elisha asked Gehazi again, ‘What can we do to help her? ’ Gehazi said, ‘She has no son. But her husband is an old man. ’"
    },
    {
      "verse": "15",
      "text": "Elisha said, ‘Ask her to come here. ’ When Gehazi did that, she came and she stood near the door."
    },
    {
      "verse": "16",
      "text": "Elisha said to her, ‘About this time next year, you will hold a son in your arms. ’ The woman said, ‘No, my master! You are a man of God. Please do not tell me lies. ’"
    },
    {
      "verse": "17",
      "text": "But the woman did become pregnant. At that time next year she gave birth to a son. Elisha had said that this would happen."
    },
    {
      "verse": "18",
      "text": "One day, when the child was older, he went out to see his father. His father was working in a field with his men at harvest time."
    },
    {
      "verse": "19",
      "text": "He said to his father, ‘My head is hurting! Yes, it hurts! ’ His father said to a servant, ‘Carry the boy to his mother. ’"
    },
    {
      "verse": "20",
      "text": "So the servant lifted him up and he carried him to his mother. The boy sat on his mother's knees until midday. Then he died."
    },
    {
      "verse": "21",
      "text": "She took the boy upstairs and she put him on the bed of the man of God. Then she went out of the room and she shut the door."
    },
    {
      "verse": "22",
      "text": "She sent a message to her husband. She said, ‘Send to me one of the servants with one of the donkeys. I must go quickly to see the man of God and then I will return. ’"
    },
    {
      "verse": "23",
      "text": "Her husband asked, ‘Why do you want to go and see him today? It is not a special day with a new moon. It is not a Sabbath day. ’ She said, ‘All is well. ’"
    },
    {
      "verse": "24",
      "text": "Then she prepared the donkey. She said to her servant, ‘You go ahead and lead! Go as fast as you can unless I say, “Go more slowly. ” ’"
    },
    {
      "verse": "25",
      "text": "So the woman went to see Elisha, the man of God, at Mount Carmel. Elisha saw her when she was a long way away. He said to his servant Gehazi, ‘Look! There is the woman from Shunem!"
    },
    {
      "verse": "26",
      "text": "Run to meet her. Ask her, “Are you well? Is your husband well? Is your son well? ” ’ The woman replied, ‘All is well. ’"
    },
    {
      "verse": "27",
      "text": "But when she reached the man of God at Mount Carmel, she took hold of his feet. Gehazi came to push her away. But the man of God said, ‘Leave her alone. She is very upset. But the Lord has hidden the reason from me. He did not tell me about her problem. ’"
    },
    {
      "verse": "28",
      "text": "The woman said, ‘My master, I did not ask you for a son, did I? I told you not to tell me lies. ’"
    },
    {
      "verse": "29",
      "text": "Elisha said to Gehazi, ‘Tie your belt around you. Prepare to travel! Take my stick with you and run there quickly. If you meet anyone, do not stop to speak. If anyone speaks to you, do not stop to answer them. When you get there, put my stick on the boy's face. ’"
    },
    {
      "verse": "30",
      "text": "But the child's mother said, ‘I promise you, as surely as the Lord lives and you live, I will not leave you. ’ So Elisha got up and he went back to Shunem with her."
    },
    {
      "verse": "31",
      "text": "Gehazi ran ahead and he arrived before they did. He put Elisha's stick on the boy's face. But the boy did not move or make any sound. So Gehazi went back to meet Elisha. He said to him, ‘The boy did not wake up. ’"
    },
    {
      "verse": "32",
      "text": "When Elisha arrived at the house, the boy was lying on the bed. He saw that the boy was dead."
    },
    {
      "verse": "33",
      "text": "Elisha went into the room by himself. He shut the door. Elisha prayed to the Lord."
    },
    {
      "verse": "34",
      "text": "Then he got onto the bed and he lay across the boy. He put his mouth on the boy's mouth. He put his eyes over the boy's eyes. He put his hands on the boy's hands. When he lay across the boy's body, it became warm."
    },
    {
      "verse": "35",
      "text": "Elisha went away from the bed. He walked round the room a few times. Then he got onto the bed again. He lay down across the boy. The boy sneezed seven times and then he opened his eyes."
    },
    {
      "verse": "36",
      "text": "Then Elisha called Gehazi to come to him. He said, ‘Tell the boy's mother to come here. ’ Gehazi did that. When the woman came, Elisha said to her, ‘Take your son. ’"
    },
    {
      "verse": "37",
      "text": "She came in to the room. She bent down low near Elisha's feet with her face towards the ground. Then she took her son and she left the room."
    },
    {
      "verse": "38",
      "text": "After that, Elisha went back to Gilgal. There was a famine in that region. The group of prophets came to meet with Elisha. He said to his servant, ‘Put the large pot over the fire. Cook some soup for the prophets. ’"
    },
    {
      "verse": "39",
      "text": "One of the prophets went out into the fields to get some herbs to put in the soup. He found a wild plant and he picked some of its fruits. He filled the pockets of his coat with them. He brought the fruits back with him and he cut them into pieces. He put the pieces into the pot of soup. But he did not know what they were."
    },
    {
      "verse": "40",
      "text": "They poured out the soup for the men to eat. But when they started to eat it, they shouted, ‘Man of God, this soup will kill us! ’ They could not eat it."
    },
    {
      "verse": "41",
      "text": "Then Elisha said, ‘Bring some flour. ’ He put the flour into the pot. He said, ‘Now pour out some more soup for the people to eat. ’ Then there was nothing in the soup that would hurt them."
    },
    {
      "verse": "42",
      "text": "One day, a man came from Baal Shalishah. He brought 20 bread loaves for the man of God. The flour for the bread was made from the first barley that he had picked at harvest time. He also brought some fresh grain. Elisha said, ‘Give this food to the people to eat. ’"
    },
    {
      "verse": "43",
      "text": "But his servant said, ‘There is not enough food here to feed 100 men! ’ Elisha said, ‘Give it to the people for them to eat. Do it, because the Lord says, “They will all eat as much as they want. There will even be some food left. ” ’"
    },
    {
      "verse": "44",
      "text": "So the servant gave the bread to the prophets to eat. They ate as much as they wanted and some food still remained. The Lord had said that this would happen."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Naaman was the leader of the king of Syria's army. Naaman's master respected him as a great man. The Lord had used Naaman to help Syria win wars against their enemies. Naaman was a brave soldier, but he had a bad disease of his skin."
    },
    {
      "verse": "2",
      "text": "Groups of soldiers from Syria had gone to attack places in Israel. They had caught a young girl as their prisoner. She became a servant of Naaman's wife."
    },
    {
      "verse": "3",
      "text": "One day, the girl said to her master's wife, ‘I would like my master Naaman to meet the prophet who is in Samaria. The prophet would take away his disease. ’"
    },
    {
      "verse": "4",
      "text": "So Naaman went to see his master, the king of Syria. He told him what the girl from Israel had said."
    },
    {
      "verse": "5",
      "text": "The king of Syria replied, ‘Go to meet this prophet! I will send a letter to the king of Israel. ’ So Naaman went to Israel. He took with him 30, 000 pieces of silver, 6, 000 pieces of gold, and 10 sets of clothes."
    },
    {
      "verse": "6",
      "text": "He also took the letter for the king of Israel. The message from the king of Syria said, ‘I am sending my servant Naaman to you, with this letter. I want you to take away the disease of his skin. ’"
    },
    {
      "verse": "7",
      "text": "When the king of Israel read the letter, he was very upset. He tore his clothes. He said, ‘I am not God, am I? I cannot kill people or make them alive again. Why does he think that I can make this man well again? I see that he is trying to start a fight with me. ’"
    },
    {
      "verse": "8",
      "text": "Elisha, the man of God, heard that the king of Israel had torn his clothes. So he sent this message to him: ‘You did not have to tear your clothes. Tell the man from Syria to come to me. Then he will know that there is a true prophet in Israel. ’"
    },
    {
      "verse": "9",
      "text": "So Naaman went to see Elisha. He took with him his horses and his chariots. He stood outside the door of Elisha's house."
    },
    {
      "verse": "10",
      "text": "Elisha sent his servant with a message to Naaman. He said, ‘Go to the Jordan River. Wash yourself seven times in the river. Then your skin will be clean again. You will not have the disease. ’"
    },
    {
      "verse": "11",
      "text": "But Naaman was angry and he went away. He said, ‘I thought that the prophet would come out of his house to see me. Then he would stand here with me. He would pray in the name of the Lord his God. Then he would move his hand over the bad place in my skin. After that my skin would be clean again. That is what I thought he would do."
    },
    {
      "verse": "12",
      "text": "The Abana and Pharpar rivers in Damascus are better than any of the rivers in Israel. Surely, I could wash in those rivers and become clean! ’ So Naaman turned around and he went away. He was very angry."
    },
    {
      "verse": "13",
      "text": "But Naaman's servants went to him. One of them said, ‘My master, the prophet might have asked you to do something very difficult. Then you surely would have done it! Now he says to you, “Wash yourself! Then you will be clean. ” That is much easier for you to do. ’"
    },
    {
      "verse": "14",
      "text": "So Naaman went down to the Jordan River. He washed himself in it seven times, as the man of God had told him to do. Naaman's skin became well again. It became as clean as a young child's skin."
    },
    {
      "verse": "15",
      "text": "Then Naaman and all his servants went back to see Elisha, the man of God. Naaman stood in front of him and he said, ‘Now I know that there is no God in the whole world except the one in Israel. Please accept a gift from me, your servant. ’"
    },
    {
      "verse": "16",
      "text": "But Elisha replied, ‘I serve the Lord. I promise you, as surely as he lives, I will not accept a gift from you. ’ Naaman asked him many times to accept a gift but Elisha refused."
    },
    {
      "verse": "17",
      "text": "So Naaman said, ‘So, you will not accept my gift. But please agree to let me take home some soil from here. I will take as much soil as two mules can carry. Then I will never again make any sacrifices or burnt offerings to any other god. I will only worship the Lord."
    },
    {
      "verse": "18",
      "text": "But I pray that the Lord will forgive me, your servant, when I do this one thing: My master, the king of Syria, often goes into the temple of our god, Rimmon. When he bends down low to worship Rimmon, he takes hold of my arm. So I also have to bend down low with him. I ask the Lord to forgive me when I do that. ’"
    },
    {
      "verse": "19",
      "text": "Elisha said to Naaman, ‘Go home with peace in your mind. ’ Then Naaman started on his way home."
    },
    {
      "verse": "20",
      "text": "Elisha's servant, Gehazi, thought, ‘My master did not accept the gifts that Naaman offered to him. He made it too easy for that Syrian man. As surely as the Lord lives, I will run after him. I will accept a gift from him. ’"
    },
    {
      "verse": "21",
      "text": "So Gehazi ran quickly after Naaman before he had gone very far. Naaman saw that a man was running after him. So he got down from his chariot to meet him. Naaman asked Gehazi, ‘Is everything well? ’"
    },
    {
      "verse": "22",
      "text": "Gehazi answered, ‘Everything is well. My master sent me with this message: “Two young men from the group of prophets have just arrived at my house. They have come from the hill country of Ephraim. Please give them 3, 000 pieces of silver and two sets of clothes. ” ’"
    },
    {
      "verse": "23",
      "text": "Naaman said, ‘Yes, I will. But please agree to take 6, 000 pieces of silver. ’ He asked Gehazi to accept them. He put the 6, 000 pieces of silver into two bags, as well as two sets of clothes. He gave them to two of his servants and they carried them in front of Gehazi."
    },
    {
      "verse": "24",
      "text": "When Gehazi reached a hill near Elisha's house, he took the things from the servants. He put them in his own room. He told the servants to go back to Naaman."
    },
    {
      "verse": "25",
      "text": "Gehazi went in and he stood in front of his master. Elisha asked Gehazi, ‘Where have you been? ’ Gehazi answered, ‘I have not been anywhere, sir. ’ Then Gehazi went away from Elisha. His skin had already become white like snow because of the disease."
    },
    {
      "verse": "26",
      "text": "But Elisha said to him, ‘My spirit was with you when you went out. It was there when the man came down from his chariot to meet you. This is not the proper time to accept gifts of money, clothes, olive trees, vineyards, sheep, cows or servants."
    },
    {
      "verse": "27",
      "text": "Now you will have the same disease in your skin that Naaman had! It will always be with you and your descendants. ’Then Gehazi went away from Elisha. His skin had already become white like snow because of the disease."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "One day, the group of prophets said to Elisha, ‘The place where we meet with you is too small for us."
    },
    {
      "verse": "2",
      "text": "We must go to the Jordan River to cut down some trees. Each one of us can bring back some wood to build a new place for us to meet in. ’ Elisha agreed and he told them to go."
    },
    {
      "verse": "3",
      "text": "One of the prophets said, ‘Please come with us, sir. ’ Elisha replied, ‘I will come with you. ’"
    },
    {
      "verse": "4",
      "text": "So he went with them. They arrived at the Jordan River. They started to cut down some trees."
    },
    {
      "verse": "5",
      "text": "While one of them was cutting down a tree, his iron axe fell into the water. He shouted, ‘Oh! My master! The axe did not belong to me! ’"
    },
    {
      "verse": "6",
      "text": "Elisha asked him, ‘Where did it fall in the water? ’ He showed Elisha the place. Then Elisha cut a branch from a tree. He threw it in the water at that place. It caused the iron axe to come to the top of the water."
    },
    {
      "verse": "7",
      "text": "Elisha told the prophet, ‘Lift it out of the water. ’ So the man took hold of it with his hand."
    },
    {
      "verse": "8",
      "text": "There was a war between the king of Syria and Israel. The king of Syria talked with his officers. He said to them, ‘I will attack Israel at a certain place. ’"
    },
    {
      "verse": "9",
      "text": "But Elisha, the man of God, sent a message to the king of Israel. He said, ‘Do not travel through that place. The Syrian army is going there to attack us. ’"
    },
    {
      "verse": "10",
      "text": "So the king of Israel warned the people in that place to be careful. Several times Elisha told the king where the Syrian army would attack so that the king would be careful."
    },
    {
      "verse": "11",
      "text": "This made the king of Syria very angry. He asked his officers to come to him. He said to them, ‘One of you is helping the king of Israel. Who is it? ’"
    },
    {
      "verse": "12",
      "text": "One of his officers said, ‘None of us is helping him, my master the king. There is a prophet who lives in Israel. His name is Elisha. He tells the king of Israel every word that you speak secretly, even what you say in your bedroom! ’"
    },
    {
      "verse": "13",
      "text": "The king of Syria said, ‘Go and find the place where he is. Then I will send some men there to catch him. ’A report came back to the king of Syria, ‘Elisha is in Dothan. ’"
    },
    {
      "verse": "14",
      "text": "So the king sent a big army of soldiers there, with horses and chariots. They arrived during the night and they made their camp all around the city."
    },
    {
      "verse": "15",
      "text": "The servant of Elisha, the man of God, got up early the next morning. He went out and he saw an army with horses and chariots all around the city. He said to Elisha, ‘Oh! My master! What can we do? ’"
    },
    {
      "verse": "16",
      "text": "Elisha replied, ‘Do not be afraid. There are more men to fight for us than there are for them. ’"
    },
    {
      "verse": "17",
      "text": "Then Elisha prayed, ‘Lord, please open my servant's eyes so that he can see clearly. ’ The Lord opened the servant's eyes. Now he could see lots of horses and chariots that burned with fire. They were on the hill all around Elisha."
    },
    {
      "verse": "18",
      "text": "When the enemy soldiers came towards Elisha, he prayed, ‘Lord, please make these people become blind. ’ The Lord did what Elisha had asked. He made the enemy soldiers become blind."
    },
    {
      "verse": "19",
      "text": "Elisha said to them, ‘You are on the wrong road. You have come to the wrong city. Follow me! I will lead you to the man that you are looking for. ’ Elisha led them to Samaria."
    },
    {
      "verse": "20",
      "text": "After they had gone into the city of Samaria, Elisha prayed again, ‘Lord, please open the eyes of these men so that they can see again. ’ The Lord opened their eyes. Now they could see that they were in the middle of Samaria!"
    },
    {
      "verse": "21",
      "text": "When the king of Israel saw the Syrian army in his city, he asked Elisha, ‘My master, what should I do? Should I kill them? ’"
    },
    {
      "verse": "22",
      "text": "Elisha answered, ‘You must not kill them. That would not be right. You did not win a fight against them with your weapons. Give them some food and water. Then they can eat and drink before they go back to their master. ’"
    },
    {
      "verse": "23",
      "text": "So the king of Israel made a big feast for them. They had a lot of food and drink. Then he sent them back to their master, the king of Syria. After this happened, no more groups of Syrian soldiers came to attack Israel."
    },
    {
      "verse": "24",
      "text": "But later, King Ben-Hadad of Syria sent his whole army to attack Samaria. His soldiers made their camp all around the city."
    },
    {
      "verse": "25",
      "text": "As a result, there was a famine in the city. The Syrian army were all around the city for a long time. Food in the city was very expensive. A donkey's head cost 80 pieces of silver. A small cup of dove's dung cost five pieces of silver."
    },
    {
      "verse": "26",
      "text": "While the king of Israel was walking on the wall of the city, a woman shouted to him, ‘Please help me, my master the king! ’"
    },
    {
      "verse": "27",
      "text": "The king replied, ‘Why do you ask me? Only the Lord can help you. I have no wheat or wine to give you. ’"
    },
    {
      "verse": "28",
      "text": "Then the king asked her, ‘What is your problem? ’ She answered, ‘This woman here said to me, “Let us take your son today, so that we can eat him. Tomorrow we will eat my son. ”"
    },
    {
      "verse": "29",
      "text": "So we cooked my son and we ate him. The next day I said to her, “Now we will take your son, so that we can eat him. ” But she has hidden him somewhere! ’"
    },
    {
      "verse": "30",
      "text": "When the king heard the woman's words, he was very upset. He tore his clothes. As he walked along the wall, people could see what he was wearing. They saw that he was wearing sackcloth under his other clothes."
    },
    {
      "verse": "31",
      "text": "He said, ‘I will certainly cut off Elisha's head today! May God punish me with death if Elisha still has his head by the end of the day! ’"
    },
    {
      "verse": "32",
      "text": "Elisha was sitting in his house. The leaders of the city were with him. The king sent a man to Elisha with a message. But before he arrived, Elisha said to the leaders, ‘I tell you this. That murderer, the king, has sent someone to cut off my head. When the king's man arrives, shut the door. Stop him from coming in here. We will soon hear the sound of his master as he arrives too. ’"
    },
    {
      "verse": "33",
      "text": "While Elisha was still talking to the city's leaders, the king's man arrived with this message: ‘The Lord has caused this terrible trouble to happen to us. I cannot wait any longer for the Lord to help us. ’"
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "Elisha said, ‘Now listen to the Lord's message! This is what the Lord says: “About this time tomorrow, five kilograms of good flour will cost only one piece of silver. Ten kilograms of barley will also cost one piece of silver. You will be able to buy this food at the gate of Samaria. ” ’"
    },
    {
      "verse": "2",
      "text": "The special officer who was near to the king said to the man of God, ‘That will never happen! Even if the Lord opens the skies and sends us rain, it could not happen so soon. ’ Elisha said, ‘You yourself will see this happen, but you will not eat any of the food! ’"
    },
    {
      "verse": "3",
      "text": "At this time, there were four men who had leprosy. They were at Samaria's gate where people went in to the city. They said to each other, ‘We should not stay here. If we wait here we will die."
    },
    {
      "verse": "4",
      "text": "There is no food in the city. If we go in there we will die. And if we stay here, we will die. So we will go out to the camp of the Syrian army. We will ask them to be kind to us. They may let us stay alive, or they may kill us. But we would have died anyway. ’"
    },
    {
      "verse": "5",
      "text": "At evening time, the men went towards the Syrian army's camp. When they reached the edge of the camp, they saw that there was nobody there!"
    },
    {
      "verse": "6",
      "text": "The Lord God had caused the Syrian soldiers to hear the sound of horses, chariots and a very big army. So they said among themselves, ‘Listen! The king of Israel has paid the king of the Hittites and the king of Egypt to come here and attack us! ’"
    },
    {
      "verse": "7",
      "text": "So, that evening, the Syrian soldiers all ran away. They left their tents, their horses and their donkeys. They did not take anything with them. They ran away to save their lives."
    },
    {
      "verse": "8",
      "text": "When the four men reached the edge of the camp, they went into one of the tents. They ate and they drank what was there. They carried away silver and gold and clothes. They went away and they hid those things. Then they came back and they went into another tent. They took the valuable things from there too and they hid them."
    },
    {
      "verse": "9",
      "text": "Then they said to each other, ‘We should not be doing this. It is not right! This is a day of good news and we have not told anyone. If we wait until the morning, we will be in trouble. We must go now and tell the king's officers what has happened. ’"
    },
    {
      "verse": "10",
      "text": "So they went back to the city's gate and they called out to the guards. They said to them, ‘We went out to the camp of the Syrian army. There was nobody there! We did not hear anyone at all. The horses and donkeys are still there, where the soldiers had tied them. The tents are still there, as they were before. ’"
    },
    {
      "verse": "11",
      "text": "The guards at the city gate then shouted the news. People in the king's palace heard the news."
    },
    {
      "verse": "12",
      "text": "The king got up in the middle of the night. He said to his officers, ‘I will tell you what the Syrian soldiers have done to deceive us. They know that we have no food. So they have left their tents and they have hidden in the fields. They are thinking, “The Israelites will surely come out of the city. Then we will catch them while they are still alive. We will then get into their city. ” ’"
    },
    {
      "verse": "13",
      "text": "One of the king's officers answered him, ‘Send some men with five of the horses that are still in our city. We will see what happens to them. All of us Israelites in the city will soon die. If the Syrian soldiers kill those men, they would have died anyway. So send them out of the city to find out what is happening. ’"
    },
    {
      "verse": "14",
      "text": "So they prepared two chariots with their horses. The king sent the men to see what had happened to the Syrian army. He commanded the men, ‘Go and look for them. ’"
    },
    {
      "verse": "15",
      "text": "The king's men followed the Syrian soldiers as far as the Jordan River. They saw many things that the soldiers had dropped along the road. They had dropped clothes and weapons because they were in a hurry to run away. So the men returned to the king. They told him what they had seen."
    },
    {
      "verse": "16",
      "text": "Then the people in Samaria went out of the city. They took all the valuable things from the Syrian soldiers' tents. So then people could buy five kilograms of good flour for one piece of silver. They could also buy ten kilograms of barley for one piece of silver. That is what the Lord had said would happen."
    },
    {
      "verse": "17",
      "text": "The king had told his special officer to stand at the gate of the city. When the people ran out of the city, they knocked him down. He fell under their feet and he died. The man of God had already said that this would happen, when the king had come to his house."
    },
    {
      "verse": "18",
      "text": "Elisha had said to the king, ‘This time tomorrow, five kilograms of good flour will cost only one piece of silver. Ten kilograms of barley will also cost one piece of silver. You will be able to buy this food at the gate of Samaria. ’"
    },
    {
      "verse": "19",
      "text": "But the officer had replied to the man of God, ‘That will never happen! Even if the Lord opens the skies and sends us rain, it could not happen so soon. ’ Elisha had said, ‘You yourself will see this happen, but you will not eat any of the food! ’"
    },
    {
      "verse": "20",
      "text": "That is what really happened to him! At the city gate, the people ran over the king's officer and he died."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Elisha had said to the woman whose son he had made alive again, ‘Go away from here. The Lord says that there will be a famine in this country for seven years. So you and your family should go to live somewhere else during that time. ’"
    },
    {
      "verse": "2",
      "text": "The woman had done what the man of God had told her to do. She and her family went to live in the country of the Philistines for seven years."
    },
    {
      "verse": "3",
      "text": "After seven years, she came back from there. She went to the king to ask for her house and her land."
    },
    {
      "verse": "4",
      "text": "The king was talking to Gehazi, the servant of the man of God. The king said to Gehazi, ‘Tell me about all the great things that Elisha has done. ’"
    },
    {
      "verse": "5",
      "text": "So Gehazi was telling the king that Elisha had made dead people alive again. While Gehazi was saying this, the woman from Shunem came in to ask the king for her house and her fields. It was her son that Elisha had made alive again. Gehazi said, ‘My master the king, this is the woman! And this is her son that Elisha made alive again! ’"
    },
    {
      "verse": "6",
      "text": "The king asked the woman about it. She told him what had happened. Then the king commanded one of his officers to take care of her. The king said to him, ‘This woman must receive back everything that belongs to her. She must also receive the value of all the crops that have grown in her fields since the day that she went away. ’"
    },
    {
      "verse": "7",
      "text": "Ben-Hadad, the king of Syria, was ill in Damascus. Elisha went to Damascus at that time. Somebody told the king, ‘The man of God has come to the city. ’"
    },
    {
      "verse": "8",
      "text": "The king said to Hazael, ‘Take a gift with you to go and meet the man of God. Ask him to get a message from the Lord. Ask him, “Will I get well again after this disease? ” ’"
    },
    {
      "verse": "9",
      "text": "So Hazael went to meet Elisha. He took a gift with him. There were 40 camels that carried many kinds of valuable things that came from Damascus. He arrived at Elisha's house and he stood in front of him. Hazael said, ‘Your servant, Ben-Hadad, king of Syria, has sent me to you. He asks, “Will I get well again after this disease? ” ’"
    },
    {
      "verse": "10",
      "text": "Elisha answered, ‘Go back to the king. Tell him, “Certainly, you will get well again. ” But the Lord has shown me that the king will surely die. ’"
    },
    {
      "verse": "11",
      "text": "Then Elisha looked at him with open eyes until Hazael became ashamed. Then the man of God began to weep."
    },
    {
      "verse": "12",
      "text": "So Hazael asked him, ‘Why are you weeping, my master? ’ Elisha replied, ‘Because I know that you will cause great trouble for Israel's people. You will destroy their strong cities with fire. You will fight their young men and you will kill them. You will knock down their children to kill them. You will cut open their pregnant women. ’"
    },
    {
      "verse": "13",
      "text": "Hazael said, ‘I am only an ordinary man, sir. I am not more important than a dog! How could I ever do great things like that? ’ Elisha answered, ‘The Lord has shown me that you will become the king of Syria. ’"
    },
    {
      "verse": "14",
      "text": "Then Hazael left Elisha. He returned to his master, the king. King Ben-Hadad asked him, ‘What did Elisha say to you? ’ Hazael replied, ‘He told me that you will surely get well again. ’"
    },
    {
      "verse": "15",
      "text": "The next day, Hazael took a thick cloth. He used water to make it wet. Then he put it over the king's face so that he could not breathe. So King Ben-Hadad died. Hazael became king of Syria after him."
    },
    {
      "verse": "16",
      "text": "When Ahab's son Joram had been king of Israel for five years, Jehoshaphat's son Jehoram started to rule Judah as king."
    },
    {
      "verse": "17",
      "text": "years old when he became king. He ruled in Jerusalem for eight years."
    },
    {
      "verse": "18",
      "text": "He lived in the same bad way that the kings of Israel did. He did what the family of Ahab had done. He married a daughter of King Ahab and he became as wicked as King Ahab's family was. He did things that the Lord said were evil."
    },
    {
      "verse": "19",
      "text": "But the Lord did not want to destroy the nation of Judah, because of his promise to his servant, David. The Lord had promised that King David would always have descendants who would rule the nation."
    },
    {
      "verse": "20",
      "text": "While Jehoram was king, Edom's people turned against Judah. They would no longer accept the king of Judah's authority over them. They decided to have their own king."
    },
    {
      "verse": "21",
      "text": "So King Jehoram travelled to Zair with all his chariots. The Edomite army came and they were all around him. But that night, Jehoram and his officers attacked the Edomites and they escaped. The Israelite army ran away to go back home."
    },
    {
      "verse": "22",
      "text": "Even today, Edom's people do not obey the rulers of Judah. The people of Libnah city also turned against Judah at the same time."
    },
    {
      "verse": "23",
      "text": "The other things that happened while Jehoram was king are written in a book. The book is called ‘The history of Judah's kings’. It tells about all the things that Jehoram did."
    },
    {
      "verse": "24",
      "text": "Jehoram died and they buried him with his ancestors in the City of David. His son Ahaziah became king after him."
    },
    {
      "verse": "25",
      "text": "When Ahab's son Joram had been king of Israel for 12 years, Jehoram's son Ahaziah started to rule Judah as king."
    },
    {
      "verse": "26",
      "text": "years old when he became king. He ruled in Jerusalem for one year. His mother's name was Athaliah. She was a granddaughter of Omri, king of Israel."
    },
    {
      "verse": "27",
      "text": "Ahaziah lived in the same bad way that Ahab's family had done. He did things that the Lord said were evil, as Ahab's family had done. That was because he had married a woman from Ahab's family."
    },
    {
      "verse": "28",
      "text": "King Ahaziah went with Ahab's son, King Joram of Israel, to fight against Hazael, the king of Syria. They fought a battle at Ramoth Gilead. The Syrian army won the fight and they hurt King Joram."
    },
    {
      "verse": "29",
      "text": "King Joram returned to Jezreel, so that his wounds could get better after the battle. While he was there, King Ahaziah went to visit him, because of his wounds."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "The prophet Elisha told a man from the group of prophets to come to him. Elisha said to him, ‘Tie your belt around you and prepare to travel. Take this bottle of olive oil with you and go to Ramoth Gilead."
    },
    {
      "verse": "2",
      "text": "When you arrive there, look for Jehu. He is the son of Jehoshaphat, the son of Nimshi. Go to him and take him into a room away from his friends."
    },
    {
      "verse": "3",
      "text": "Pour the oil from the bottle onto his head. Say to him, “This is what the Lord says to you: I have now chosen you to be king of Israel. ” Then open the door and run away quickly! ’"
    },
    {
      "verse": "4",
      "text": "The young prophet that Elisha had sent went to Ramoth Gilead. Then the young prophet opened the door and he ran away."
    },
    {
      "verse": "5",
      "text": "When he arrived there, he found the army officers. They were sitting together. The prophet said, ‘Captain, I have a message for you. ’ Jehu asked him, ‘The message is for which of us? ’ The prophet replied, ‘It is for you, sir. ’"
    },
    {
      "verse": "6",
      "text": "So Jehu stood up and he went into the house. The young prophet poured the oil onto Jehu's head. He said to him, ‘This is what the Lord, Israel's God, says to you: “I have now chosen you to be king of the Lord's people, Israel."
    },
    {
      "verse": "7",
      "text": "You will destroy the family of your master, Ahab. In this way I will punish Ahab's wife Jezebel, because she killed the prophets and other people who served me."
    },
    {
      "verse": "8",
      "text": "The whole family of Ahab must die. I will kill every male among his descendants in Israel, whoever they are."
    },
    {
      "verse": "9",
      "text": "I will destroy Ahab's family as I did to the family of Nebat's son Jeroboam and the family of Ahijah's son Baasha."
    },
    {
      "verse": "10",
      "text": "Dogs will eat Jezebel's body on the ground in Jezreel. Nobody will bury her. ” ’Then the young prophet opened the door and he ran away."
    },
    {
      "verse": "11",
      "text": "Jehu went out to the other army officers. They asked him, ‘Is everything well? Why did that crazy man come to you? ’ Jehu replied, ‘It was not important. You know what that man is like and the kind of things he says. ’"
    },
    {
      "verse": "12",
      "text": "But the officers said, ‘That is not true! Tell us what he said. ’ So Jehu told them what the prophet had said. He told them, ‘The prophet said, “This is what the Lord says: I have now chosen you to be the king of Israel. ” ’"
    },
    {
      "verse": "13",
      "text": "The other officers then quickly took their coats. They put them on the stone steps for Jehu to walk on. Then they made a loud noise with a trumpet. They shouted, ‘Jehu is king! ’"
    },
    {
      "verse": "14",
      "text": "So Jehu, the son of Jehoshaphat and grandson of Nimshi, became an enemy of King Joram. Joram had been in Ramoth Gilead with the whole army of Israel. They were fighting against Hazael, the king of Syria, who wanted to attack Israel."
    },
    {
      "verse": "15",
      "text": "The Syrian soldiers had hurt King Joram in the battle against King Hazael. So he returned to Jezreel to get well again. Jehu said to his men, ‘If you really want to help me, do not let anyone leave this city. Nobody must go to warn the people in Jezreel. ’"
    },
    {
      "verse": "16",
      "text": "Then Jehu got into his chariot and he rode to Jezreel, because King Joram was resting there. Ahaziah, the king of Judah, had also gone to Jezreel to visit King Joram."
    },
    {
      "verse": "17",
      "text": "A guard was standing on the tower in Jezreel to watch for enemies. He saw Jehu's soldiers coming towards the city. He shouted, ‘I can see a group of soldiers who are coming here on horses. ’King Joram said, ‘Send out a man on a horse to meet the soldiers. Ask them. “Are you coming to us as friends? ” ’"
    },
    {
      "verse": "18",
      "text": "The man on the horse rode out of the city to meet Jehu. He said to Jehu, ‘The king asks you, “Are you coming here as friends? ” ’ Jehu replied, ‘Whether we are friends or not, turn round and ride behind me! ’The guard on the tower reported to Joram, ‘The man that you sent with the message has reached them. But he is not coming back yet. ’"
    },
    {
      "verse": "19",
      "text": "So King Joram sent a second man out on a horse. The rider said to Jehu, ‘The king asks you, “Are you coming here as friends? ” ’ Jehu replied, ‘Whether we are friends or not, turn round and ride behind me! ’"
    },
    {
      "verse": "20",
      "text": "The guard reported to Joram, ‘The man has reached them, but he is not coming back yet either. Their leader is driving his chariot like Nimshi's son, Jehu. He drives like a crazy man! ’"
    },
    {
      "verse": "21",
      "text": "Then King Joram commanded, ‘Prepare my chariot for me. ’ So they brought his chariot to him. Then King Joram of Israel and King Ahaziah of Judah rode out of the city to meet Jehu. Each king was riding in his own chariot. They met Jehu at the piece of land that had once belonged to Naboth, the man from Jezreel."
    },
    {
      "verse": "22",
      "text": "When Joram saw Jehu, he asked, ‘Have you come as a friend, Jehu? ’ Jehu replied, ‘We cannot be friends. Your mother Jezebel still causes people to worship idols and to use magic. ’"
    },
    {
      "verse": "23",
      "text": "Joram turned his chariot round and he drove away quickly. He shouted to King Ahaziah, ‘Ahaziah, they have deceived us! ’"
    },
    {
      "verse": "24",
      "text": "Then Jehu used his bow to shoot an arrow at Joram. The arrow hit Joram between his shoulders and it went through his heart. He fell over in his chariot and he died."
    },
    {
      "verse": "25",
      "text": "Jehu gave a command to his officer, Bidkar. He said to him, ‘Pick him up! Throw his body onto the field that once belonged to Naboth. Remember, you and I rode together in chariots behind Joram's father, Ahab. That was when the Lord said this about Ahab:"
    },
    {
      "verse": "26",
      "text": "“Yesterday, I saw the blood of Naboth and his sons where you murdered them. One day, I will punish you as you deserve. I will do it here on this piece of land. That is what the Lord says. ” So now pick up Joram's body and throw it on this piece of land. Do what the Lord has promised he would do. ’"
    },
    {
      "verse": "27",
      "text": "King Ahaziah of Judah saw what had happened to Joram. So he rode away quickly on the road towards Beth Haggan. Jehu chased after him and he shouted, ‘Kill him too! ’ Jehu's men shot arrows at Ahaziah as he rode in his chariot up the hill to Gur, near Ibleam. He escaped to Megiddo and he died there."
    },
    {
      "verse": "28",
      "text": "King Ahaziah's servants took his body back to Jerusalem in a chariot. They buried him there in a grave beside his ancestors in the City of David."
    },
    {
      "verse": "29",
      "text": "Ahaziah had become king of Judah when Ahab's son Joram had been king of Israel for 11 years."
    },
    {
      "verse": "30",
      "text": "After that, Jehu went to Jezreel. Jezebel heard what had happened. So she made her eyes and her hair look beautiful. Then she looked out of a window in the palace."
    },
    {
      "verse": "31",
      "text": "When Jehu came through the gate of the city, Jezebel called out to him, ‘Have you come as a friend, Zimri? No, you have murdered your master! ’"
    },
    {
      "verse": "32",
      "text": "Jehu looked up at the window and he saw her. Then he shouted, ‘Who wants to help me? Anyone there? ’ Two or three eunuchs looked out though a window at him."
    },
    {
      "verse": "33",
      "text": "Jehu shouted to them, ‘Throw her down! ’ So they threw her down. When she hit the ground, some of her blood splashed on the wall. It also splashed on Jehu's horses as he drove them over her body."
    },
    {
      "verse": "34",
      "text": "Jehu went into the palace and he ate a meal. Then he said, ‘Take away that evil woman's body. She was the daughter of a king, so you should bury her properly. ’"
    },
    {
      "verse": "35",
      "text": "But when they went out to bury her, not much of her body was still there. They found only her skull, her feet and her hands."
    },
    {
      "verse": "36",
      "text": "They went back and they told Jehu. He said, ‘The Lord told his servant, Elijah from Tishbe, that this would happen. He said, “Dogs will eat Jezebel's dead body on the ground in Jezreel."
    },
    {
      "verse": "37",
      "text": "Her dead body will lie on the ground in Jezreel like dung. Nobody will be able to recognize who it is. ” ’"
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "sons who lived in Samaria. So Jehu wrote letters and he sent them to Samaria. He sent them to Jezreel's officers and leaders, as well as to the men who took care of Ahab's sons."
    },
    {
      "verse": "2",
      "text": "This was what the letter said:‘When this letter reaches you, your master's sons will be with you. You also have his chariots and horses in a strong city. And you have weapons."
    },
    {
      "verse": "3",
      "text": "Choose the best person to be king from among your master's sons. Make him your king instead of his father. Then prepare to fight on behalf of your master's family. ’"
    },
    {
      "verse": "4",
      "text": "But the letter made the officers in Samaria very afraid. They said, ‘Even two kings could not win against Jehu. So we can never fight against him and win! ’"
    },
    {
      "verse": "5",
      "text": "So these people sent a message to Jehu: the officer who took care of the king's palace, the man who ruled the city of Samaria, the city's leaders, and the men who took care of Ahab's children. The message said, ‘We are your servants. We will do anything that you tell us. We will not make anyone king. You must do what you think is right. ’ The message said, ‘We are your servants. We will do anything that you tell us. We will not make anyone king. You must do what you think is right. ’"
    },
    {
      "verse": "6",
      "text": "So Jehu wrote a second letter to them. It said, ‘If you are ready to help me and you will obey me, do this: Bring the heads of your master's sons here to me in Jezreel. Bring them by this time tomorrow. ’At that time, important leaders of the city were taking care of the king's 70 sons."
    },
    {
      "verse": "7",
      "text": "When the letter arrived, these men took hold of the king's sons. They killed all 70 of them. They put their heads in baskets. Then they sent them to Jehu in Jezreel."
    },
    {
      "verse": "8",
      "text": "Someone told Jehu, ‘They have brought the heads of the king's sons. ’ Then Jehu said, ‘Put them in two heaps at the gate of the city. Leave them there until the morning. ’"
    },
    {
      "verse": "9",
      "text": "The next morning, Jehu went out to the city's gate. He stood there in front of all the people. He said to them, ‘You are not guilty of any murder. I was the one who decided to kill my master, the king. But who killed these descendants of Ahab? It was not my decision!"
    },
    {
      "verse": "10",
      "text": "You must realize this: Every punishment that the Lord said would happen to Ahab's family must happen. The Lord has done what he told his servant Elijah he would do. ’"
    },
    {
      "verse": "11",
      "text": "After that, Jehu killed everybody in Jezreel who was a descendant of Ahab. He also killed Ahab's officers, his friends and his priests. No descendant of Ahab remained alive."
    },
    {
      "verse": "12",
      "text": "Jehu left Jezreel and he went towards Samaria. He came to Beth Eked, where shepherds had a camp."
    },
    {
      "verse": "13",
      "text": "He met some relatives of Ahaziah, the king of Judah. Jehu asked them, ‘Who are you? ’ They said, ‘We are relatives of Ahaziah. We are going to Jezreel to visit the families of the king and his mother. ’"
    },
    {
      "verse": "14",
      "text": "Jehu said to his men, ‘Catch them, but do not kill them! ’ So they took hold of them. Then they killed them all near the well at Beth Eked. They killed 42 people, so that none of them remained alive."
    },
    {
      "verse": "15",
      "text": "When Jehu left Beth Eked, he met Rekab's son Jehonadab. He was coming to meet Jehu. Jehu said, ‘Hello! Do you trust me, as I trust you? ’ Jehonadab answered, ‘Yes, I do! ’ Jehu replied, ‘Then hold your hand out to me. ’ So he did that and Jehu pulled him up into his chariot."
    },
    {
      "verse": "16",
      "text": "Jehu said, ‘Come with me. You will see that I want to serve the Lord faithfully. ’ So Jehonadab rode with Jehu in his chariot."
    },
    {
      "verse": "17",
      "text": "Jehu arrived in Samaria. He killed all the descendants of Ahab who were still alive in Samaria. The Lord had told Elijah that this would happen."
    },
    {
      "verse": "18",
      "text": "Then Jehu called all the people to come together. He said to them, ‘Ahab served Baal, but he did not do it very well. But I, Jehu, will serve Baal much better!"
    },
    {
      "verse": "19",
      "text": "So tell all the prophets who serve Baal to come here, as well as all Baal's servants and his priests. Make sure that they all come. I want to offer a great sacrifice to Baal. If any of them does not come, I will punish him with death. ’But Jehu was deceiving them. He wanted to kill all Baal's servants."
    },
    {
      "verse": "20",
      "text": "He gave a command, ‘Prepare a special day when we can all worship Baal. ’ So Jehu's servants told everybody about it."
    },
    {
      "verse": "21",
      "text": "Jehu sent a notice to everyone in Israel. All the servants of Baal came to the meeting. There was nobody who did not come. They all went into the temple of Baal, so that it was completely full of people."
    },
    {
      "verse": "22",
      "text": "Then Jehu said to the man who took care of the special clothes, ‘Bring out the robes for the servants of Baal to wear. ’ So the man brought out the robes for them."
    },
    {
      "verse": "23",
      "text": "Then Jehu and Rekab's son Jehonadab went into the temple of Baal. Jehu said to the servants of Baal, ‘Look around carefully. Be sure that there are no servants of the Lord here with you. There must only be servants of Baal here. ’"
    },
    {
      "verse": "24",
      "text": "So they went into the temple to offer sacrifices and burnt offerings. But Jehu had put 80 of his men outside the temple. He had said to them, ‘Do not let any of these men escape. If you let anyone escape, I will punish you with death. ’"
    },
    {
      "verse": "25",
      "text": "When Jehu had finished offering the sacrifices, he said to the guards and the soldiers, ‘Go into the temple and kill all Baal's servants. Do not let any of them escape. ’ So the guards and soldiers used their swords to cut all the people down. They threw the dead bodies out of the temple. Then they went into the inside room of the temple."
    },
    {
      "verse": "26",
      "text": "They took out the stones from the house of Baal and they destroyed them."
    },
    {
      "verse": "27",
      "text": "They broke the special stone pillar of Baal and they destroyed the temple. People still use it as a toilet, even today!"
    },
    {
      "verse": "28",
      "text": "That is how Jehu stopped people from worshipping Baal in Israel."
    },
    {
      "verse": "29",
      "text": "But Jehu did not turn away from the sins of Nebat's son, Jeroboam. Jeroboam had caused Israel to worship images of calves. There were still gold calves at Bethel and Dan."
    },
    {
      "verse": "30",
      "text": "The Lord said to Jehu, ‘You have done well. You have done the things that I say are right. You have punished Ahab's family in the way that I wanted. So your descendants will be kings of Israel for four generations. ’"
    },
    {
      "verse": "31",
      "text": "But Jehu was not careful to obey completely the law of the Lord, Israel's God. He did not turn away from the sins of Jeroboam which he had caused Israel to do."
    },
    {
      "verse": "32",
      "text": "In those days, the Lord began to make Israel's land smaller. King Hazael of Syria could attack the Israelites anywhere in their land"
    },
    {
      "verse": "33",
      "text": "east of the Jordan River. He took from them all the land of Gilead. That included the land that belonged to the tribes of Gad, Reuben and Manasseh. Hazael took the land all the way from Aroer, along the Arnon Valley to Gilead and Bashan."
    },
    {
      "verse": "34",
      "text": "The other things that happened while Jehu was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about all the great things that Jehu did."
    },
    {
      "verse": "35",
      "text": "Jehu died and they buried him with his ancestors in Samaria. His son Jehoahaz became king after him."
    },
    {
      "verse": "36",
      "text": "years."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "Ahaziah's mother, Athaliah, heard the news that her son was dead. So she started to kill all the royal family."
    },
    {
      "verse": "2",
      "text": "Jehosheba was the daughter of King Jehoram of Judah and the sister of Ahaziah. When Athaliah's servants had come to murder the royal sons, Jehosheba took Ahaziah's son Joash away and she hid him. She put him in a bedroom in the temple to hide him from Athaliah. So Joash stayed alive."
    },
    {
      "verse": "3",
      "text": "Joash and his nurse stayed safely in a room in the Lord's temple while Queen Athaliah ruled Judah for six years."
    },
    {
      "verse": "4",
      "text": "In the seventh year that Athaliah ruled Judah, the priest Jehoiada asked some of the king's officers to come to him. They were officers of army groups, the king's special guards and the palace guards. They came to meet with Jehoiada in the Lord's temple. There, he made them promise to agree with his idea. Then he showed the king's son Joash to them. They came to meet with Jehoiada in the Lord's temple. There, he made them promise to agree with his idea. Then he showed the king's son Joash to them."
    },
    {
      "verse": "5",
      "text": "Jehoiada said to the officers, ‘This is what you must do: The men who come to work on the Sabbath day must make three groups. One group will keep the palace safe."
    },
    {
      "verse": "6",
      "text": "Another group must stand at the Sur Gate. The third group must stand at the gate behind the special guards."
    },
    {
      "verse": "7",
      "text": "The two groups of soldiers who would not come to work on the Sabbath day must do this: They must be guards at the Lord's temple. They must keep the new king safe."
    },
    {
      "verse": "8",
      "text": "You must stand around the king. Each man must hold his weapon in his hand. If anyone comes near to you, you must kill them. You must stay near to the king everywhere that he goes. ’"
    },
    {
      "verse": "9",
      "text": "The officers of the army groups did what Jehoiada the priest told them to do. Each officer brought his group of men to Jehoiada. That included the men who worked on the Sabbath and those who did not."
    },
    {
      "verse": "10",
      "text": "Then Jehoiada gave some weapons that were in the Lord's temple to the officers. He gave them the spears and the shields that had belonged to King David."
    },
    {
      "verse": "11",
      "text": "The guards held their weapons in their hands. They stood around the king to keep him safe. They stood in a line from the south side of the temple to the north side. They were around the altar at the front of the temple."
    },
    {
      "verse": "12",
      "text": "Then Jehoiada brought the king's son out of the temple room. He put the crown onto Joash's head. He gave him a copy of the royal covenant. They poured olive oil on his head to show that he was now the king. They clapped their hands and they shouted, ‘May the king have a long life! ’"
    },
    {
      "verse": "13",
      "text": "Queen Athaliah heard the soldiers and the people as they were shouting. So she went to the Lord's temple where all the people were. When Athaliah saw this, she was very upset. She tore her clothes. She shouted, ‘Treason! Treason! ’"
    },
    {
      "verse": "14",
      "text": "Then she saw the king! He was standing in the king's place beside the pillar in the temple. The army officers and the men with trumpets were standing beside the king. All the people of Judah were shouting with joy. Many of them made music with trumpets. When Athaliah saw this, she was very upset. She tore her clothes. She shouted, ‘Treason! Treason! ’"
    },
    {
      "verse": "15",
      "text": "Jehoiada the priest gave a command to the army officers who had authority over groups of soldiers. He told them, ‘Bring her out of the temple to the line of guards outside. Use your swords to kill anyone who follows her. ’ That was because Jehoiada had said, ‘You must not kill her inside the Lord's temple. ’"
    },
    {
      "verse": "16",
      "text": "So they took hold of Athaliah. They took her through the gate for the king's horses into the yard of the palace. They killed her there."
    },
    {
      "verse": "17",
      "text": "Jehoiada prepared a covenant with the Lord. All the people and the king agreed to serve the Lord as his people. The people also agreed to serve the king faithfully."
    },
    {
      "verse": "18",
      "text": "Then people everywhere in the country went to the temple of Baal. They destroyed it. They completely knocked down its altars and idols. They killed Baal's priest, Mattan, in front of Baal's altars. Then Jehoiada the priest put guards to keep the Lord's temple safe."
    },
    {
      "verse": "19",
      "text": "Jehoiada took with him the officers of army groups, the king's special guards, the palace guards and all the people. They went together to bring the king down from the Lord's temple into the palace. They went into the palace through the gate of the king's royal guards. Then Joash sat on his throne as king."
    },
    {
      "verse": "20",
      "text": "All the people were very happy. There was no longer any trouble in Jerusalem now that Athaliah was dead. They had punished her with death at the palace."
    },
    {
      "verse": "21",
      "text": "And Joash was seven years old when he began to rule Judah as king."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "Joash became king of Judah in the seventh year that Jehu was king of Israel. Joash ruled in Jerusalem for 40 years. His mother's name was Zibiah. She came from Beersheba."
    },
    {
      "verse": "2",
      "text": "Jehoiada the priest taught Joash to do what was right. So Joash pleased the Lord all through his life."
    },
    {
      "verse": "3",
      "text": "But Joash did not remove the altars on the hills. The people continued to offer sacrifices and to burn incense on those altars."
    },
    {
      "verse": "4",
      "text": "Joash said to all the priests, ‘Bring together all the money that people have offered to the Lord in his temple. This includes: the money that each person pays as his tax, the money that people have given because of a promise, and the money that people have chosen to give for the temple."
    },
    {
      "verse": "5",
      "text": "Each priest should receive the money that he needs to make repairs to the temple. When he sees that something is broken, he can use some of the people's money to mend it. ’"
    },
    {
      "verse": "6",
      "text": "years, the priests had still not made any repairs to the temple."
    },
    {
      "verse": "7",
      "text": "So King Joash called Jehoiada and the other priests to come to him. He said to them, ‘You have made no repairs to the temple yet! Why not? Do not take any more of your people's money! It must only be used to make repairs to the temple. ’"
    },
    {
      "verse": "8",
      "text": "The priests agreed that they would not take any more money from the people. They agreed that they would not make repairs to the temple themselves."
    },
    {
      "verse": "9",
      "text": "Jehoiada the priest took a large box and he made a hole in the top of it. He put it outside the entrance of the temple, on the right side of the altar. The priests who were guards at the temple door took care of the box. When people brought gifts of money to the Lord's temple, the priests put the money in the box."
    },
    {
      "verse": "10",
      "text": "Whenever there was a lot of money in the box, the king's secretary and the leader of the priests counted the money. Then they put those gifts for the temple into bags."
    },
    {
      "verse": "11",
      "text": "When they knew how much money was there, they gave it to the men who had authority over the work. Then those men paid the carpenters and the builders who were working on the Lord's temple."
    },
    {
      "verse": "12",
      "text": "They also paid the men that cut the stones and the men who used the stones to build with. They bought wood and they bought stones that people had cut to use for the repairs to the Lord's temple. They used the money to pay for any work on the repairs."
    },
    {
      "verse": "13",
      "text": "But they did not use any of this money to buy things that they used in the temple. This included: silver bowls, small tools that they used for the lamps, bowls for water, trumpets, and anything else that was made with silver or gold."
    },
    {
      "verse": "14",
      "text": "Instead, they used all the money to give to the men who had authority over the repairs to the Lord's temple."
    },
    {
      "verse": "15",
      "text": "Those men did not have to give a report on how they used the money. People knew that they were honest men."
    },
    {
      "verse": "16",
      "text": "But the money that people gave when they made a guilt offering or a sin offering belonged to the priests. It did not pay for the repairs on the temple."
    },
    {
      "verse": "17",
      "text": "At that time, Hazael, the king of Syria, attacked Gath. His army took the city for him. Then King Hazael decided to attack Jerusalem."
    },
    {
      "verse": "18",
      "text": "Joash, the king of Judah, took all the valuable things that he and his ancestors had given to God. Those ancestors were the kings of Judah: Jehoshaphat, Jehoram and Ahaziah. He also took gold that was in the palace and in the temple. He sent all those valuable things to Hazael, king of Syria. When Hazael received the gifts from Joash, he took his army away from Jerusalem."
    },
    {
      "verse": "19",
      "text": "The other things that happened while Joash was king are written in a book. The book is called ‘The history of Judah's kings’. It tells about all the things that Joash did."
    },
    {
      "verse": "20",
      "text": "Joash's officers decided to kill him. Two of them murdered him at Beth Millo, on the road that goes down to Silla."
    },
    {
      "verse": "21",
      "text": "The officers that killed him were Shimeath's son Jozabad and Shomer's son Jehozabad. People buried Joash beside his ancestors in the City of David. His son Amaziah became king after him."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "Jehu's son Jehoahaz became king of Israel when Ahaziah's son Joash had been king of Judah for 23 years. Jehoahaz ruled as king in Samaria for 17 years."
    },
    {
      "verse": "2",
      "text": "But he did things that the Lord said were evil. He did the same bad things that Nebat's son Jeroboam had done. Jeroboam had caused many people in Israel to do those sins, and Jehoahaz did not stop doing them himself."
    },
    {
      "verse": "3",
      "text": "So the Lord was very angry with Israel. For many years the Lord put the Israelites under the power of King Hazael of Syria and his son Ben-Hadad."
    },
    {
      "verse": "4",
      "text": "Then King Jehoahaz asked the Lord for help. The Lord saw that the king of Syria was being very cruel to Israel, so he answered the prayer of Jehoahaz."
    },
    {
      "verse": "5",
      "text": "The Lord sent a leader to rescue Israel from Syria's power. So the Israelites lived safely in their own homes, as they had done before this time."
    },
    {
      "verse": "6",
      "text": "But the Israelites still did not turn away from the sins that Jeroboam and his family had done. Jeroboam had caused the Israelites to do bad things, and they still continued to do them. There were still Asherah poles that people worshipped in Samaria."
    },
    {
      "verse": "7",
      "text": "The king of Syria had destroyed most of Jehoahaz's army. All that remained were:50 soldiers that rode horses. 10 chariots. 10, 000 other soldiers. The king of Syria completely destroyed all the rest of the army. Only dust remained! The king of Syria completely destroyed all the rest of the army. Only dust remained!"
    },
    {
      "verse": "8",
      "text": "The other things that happened while Jehoahaz was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about all the things that Jehoahaz used his power to do."
    },
    {
      "verse": "9",
      "text": "Jehoahaz died and they buried him beside his ancestors in Samaria. His son Jehoash became king after him."
    },
    {
      "verse": "10",
      "text": "Jehoahaz's son Jehoash became the king of Israel when Joash had been king of Judah for 37 years. He ruled as king in Samaria for 16 years."
    },
    {
      "verse": "11",
      "text": "But he did things that the Lord said were evil. He did not turn away from the bad things that Nebat's son Jeroboam had done. Jeroboam had caused many people in Israel to do those sins, and Jehoahaz did not stop doing them himself."
    },
    {
      "verse": "12",
      "text": "The other things that happened while Jehoash was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about all the great things that Jehoash did. It tells about the war that he fought against Amaziah, king of Judah"
    },
    {
      "verse": "13",
      "text": "Jehoash died and they buried him in Samaria beside the other kings of Israel. Jeroboam became king of Israel after him."
    },
    {
      "verse": "14",
      "text": "When Jehoash was still king of Israel, Elisha became very ill. It was the illness from which he would soon die. Jehoash went to visit him. Jehoash stood beside Elisha and he wept. Jehoash said, ‘My father! My father! You are riding in Israel's chariot! Israel's men are riding on the horses! ’"
    },
    {
      "verse": "15",
      "text": "Elisha said to King Jehoash, ‘Fetch a bow and some arrows. ’ The king did that."
    },
    {
      "verse": "16",
      "text": "Then Elisha said to the king of Israel, ‘Prepare to shoot an arrow. ’ When he had done that, Elisha put his hands on the king's hands."
    },
    {
      "verse": "17",
      "text": "Elisha said, ‘Open the window towards the east. ’ When the king opened it, Elisha said, ‘Shoot the arrow! ’ The king shot the arrow and Elisha said, ‘That is the Lord's arrow which shows that you will win the battle against Syria. You will completely destroy Syria's army at Aphek. ’"
    },
    {
      "verse": "18",
      "text": "Then Elisha said, ‘Pick up the other arrows. ’ When the king of Israel took them, Elisha said to him, ‘Hit the ground with them. ’ The king hit the ground three times and then he stopped."
    },
    {
      "verse": "19",
      "text": "The man of God then became angry with King Jehoash. He said, ‘You should have hit the ground five times or six times. Then you would have completely destroyed Syria's army. But now you will only win three battles against Syria. ’"
    },
    {
      "verse": "20",
      "text": "After that, Elisha died and they buried him. Every year in spring, groups of fighters from Moab came to attack places in Israel."
    },
    {
      "verse": "21",
      "text": "One day some Israelites were burying a man who had died. While they were doing that, they saw a group of fighters from Moab. So they quickly threw the dead body into Elisha's grave. When the body touched Elisha's bones, the dead man became alive again! He jumped up and he stood there!"
    },
    {
      "verse": "22",
      "text": "All the time that Jehoahaz was king of Israel, King Hazael of Syria was cruel to the Israelites."
    },
    {
      "verse": "23",
      "text": "But the Lord was kind to them and he helped them. He loved them because of his covenant with their ancestors, Abraham, Isaac and Jacob. So he has never wanted to destroy them or to send them away from him, even until now."
    },
    {
      "verse": "24",
      "text": "Hazael, the king of Syria, died. His son Ben-Hadad became king after him."
    },
    {
      "verse": "25",
      "text": "Then Jehoahaz's son, King Jehoash, took back some Israelite cities from Ben-Hadad. They were cities that Hazael had taken from Jehoahaz in war. King Jehoash won three battles against Ben-Hadad and he took back those cities for Israel."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "Joash's son Amaziah became the king of Judah when Jehoahaz's son Jehoash had been the king of Israel for two years."
    },
    {
      "verse": "2",
      "text": "years old when he began to rule as king. He ruled in Jerusalem for 29 years. His mother's name was Jehoaddin. She was from Jerusalem."
    },
    {
      "verse": "3",
      "text": "Amaziah did things that the Lord said were good. He lived in the way that his father Joash had done. But he did not do as well as his ancestor King David had done."
    },
    {
      "verse": "4",
      "text": "He did not remove the altars on the hills. The people continued to offer sacrifices and to burn incense on those altars."
    },
    {
      "verse": "5",
      "text": "Amaziah made himself strong to rule his kingdom with authority. Then he killed the officers who had murdered his father, King Joash."
    },
    {
      "verse": "6",
      "text": "But he did not punish their sons with death. He obeyed the Lord's command that was written in the Book of the Law of Moses. The command says, ‘Do not punish fathers with death when their sons do bad things. Do not punish children with death when their fathers do bad things. Each person must die only because of his own sins. ’"
    },
    {
      "verse": "7",
      "text": "Amaziah killed 10, 000 soldiers from Edom in Salt valley. He attacked Sela city and he took it for himself. He gave it a new name, ‘Joktheel’. That is still its name."
    },
    {
      "verse": "8",
      "text": "Then Amaziah sent men with a message to King Jehoash of Israel. He was the son of Jehoahaz and the grandson of Jehu. Amaziah's message said, ‘Come here and meet me. ’"
    },
    {
      "verse": "9",
      "text": "But King Jehoash of Israel sent this message back to King Amaziah of Judah: ‘In Lebanon, a thorn bush sent this message to a cedar tree: “Please give your daughter to my son, to be his wife. ” Then a wild animal of Lebanon came and knocked down the thorn bush. It walked all over it!"
    },
    {
      "verse": "10",
      "text": "Yes! You have won the fight against Edom. But do not boast about your power! You may be very happy, but stay at home! Do not try to fight against us. If you do that, you will cause trouble that destroys both you and your kingdom, Judah. ’"
    },
    {
      "verse": "11",
      "text": "But Amaziah did not accept Jehoash's message. So King Jehoash of Israel prepared to attack Amaziah's army. Jehoash and Amaziah met together in battle at Beth Shemesh, a town in Judah."
    },
    {
      "verse": "12",
      "text": "Israel's army won the battle against Judah's army. All the soldiers from Judah ran back home."
    },
    {
      "verse": "13",
      "text": "At Beth Shemesh, King Jehoash of Israel caught the king of Judah, Amaziah, the son of Joash and the grandson of Ahaziah. Then King Jehoash went to attack Jerusalem. He destroyed the wall of Jerusalem, between the Ephraim Gate and the Corner Gate. That part of the wall was 180 metres long."
    },
    {
      "verse": "14",
      "text": "He took all the gold and silver and all the valuable things from the Lord's temple and the palace. He also took some of the people away with him as prisoners. Then he returned to Samaria."
    },
    {
      "verse": "15",
      "text": "The other things that happened while Jehoash was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about all the great things that Jehoash did. It tells about the war that he fought against King Amaziah of Judah."
    },
    {
      "verse": "16",
      "text": "Jehoash died and they buried him beside the other kings of Israel in Samaria. His son Jeroboam became king after him."
    },
    {
      "verse": "17",
      "text": "Joash's son Amaziah, the king of Judah, lived for 15 years after Jehoahaz's son Jehoash, the king of Israel, died."
    },
    {
      "verse": "18",
      "text": "The other things that happened while Amaziah was king are written in a book. The book is called ‘The history of Judah's kings’."
    },
    {
      "verse": "19",
      "text": "Some people in Jerusalem made a plan to kill Amaziah. So he ran away to Lachish. But the people in Jerusalem sent men to catch him in Lachish. They killed Amaziah there."
    },
    {
      "verse": "20",
      "text": "They carried his dead body back to Jerusalem on a horse. They buried him there beside his ancestors in the City of David."
    },
    {
      "verse": "21",
      "text": "All the people in Judah made Amaziah's son Azariah king instead of his father. Azariah was 16 years old."
    },
    {
      "verse": "22",
      "text": "He was the king who built Elath into a strong city again. He put it back under Judah's power. He did that after his father Amaziah had died."
    },
    {
      "verse": "23",
      "text": "Jehoash's son Jeroboam became the king of Israel when Joash's son Amaziah had been king of Judah for 15 years. Jeroboam ruled Israel for 41 years in Samaria."
    },
    {
      "verse": "24",
      "text": "He did things that the Lord said were evil. He did not turn away from the bad things that Nebat's son Jeroboam had done. He had caused many people in Israel to do those sins."
    },
    {
      "verse": "25",
      "text": "Jeroboam was the king who made Israel's border strong between Lebo-Hamath and the Salt Sea. The Lord, Israel's God, had already told his prophet Jonah that this would happen. Jonah was the son of Amittai and he came from Gath Hepher."
    },
    {
      "verse": "26",
      "text": "Everyone in Israel had a lot of trouble and pain, whoever they were. There was no leader who could rescue them. The Lord had seen this, so he helped Jeroboam."
    },
    {
      "verse": "27",
      "text": "The Lord had never said that he would completely remove Israel from the earth. So he gave Jehoash's son Jeroboam the power to rescue them."
    },
    {
      "verse": "28",
      "text": "The other things that happened while Jeroboam was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about all the great things that Jeroboam did. It tells how he fought battles to get back power for Israel over Damascus and Hamath."
    },
    {
      "verse": "29",
      "text": "Jeroboam died and they buried him beside the other kings of Israel in Samaria. His son Zechariah became king after him."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "Amaziah's son Azariah became king of Judah when Jeroboam had been king of Israel for 27 years."
    },
    {
      "verse": "2",
      "text": "years old when he became king. He ruled in Jerusalem for 52 years. His mother's name was Jecoliah. She came from Jerusalem."
    },
    {
      "verse": "3",
      "text": "Azariah did things that the Lord said were good, as his father Amaziah had done."
    },
    {
      "verse": "4",
      "text": "But he did not remove the altars on the hills. The people continued to offer sacrifices and to burn incense on those altars."
    },
    {
      "verse": "5",
      "text": "The Lord caused the king to have a bad disease in his skin. He had the disease until the day that he died. He lived in a house away from other people. His son Jotham had authority in the palace and he ruled the people of Judah."
    },
    {
      "verse": "6",
      "text": "The other things that happened while Azariah was king are written in a book. The book is called ‘The history of Judah's kings’. It tells about the things that Azariah did."
    },
    {
      "verse": "7",
      "text": "Azariah died and they buried him beside his ancestors in the City of David. His son Jotham became king after him."
    },
    {
      "verse": "8",
      "text": "Jeroboam's son Zechariah became king of Israel when Azariah had been king of Judah for 38 years. He ruled Israel as king in Samaria for six months."
    },
    {
      "verse": "9",
      "text": "Zechariah did things that the Lord said were evil, as his ancestors had done. He did not turn away from the bad things that Nebat's son Jeroboam had done. Jeroboam had caused many people in Israel to do those sins."
    },
    {
      "verse": "10",
      "text": "Jabesh's son Shallum made a plan to kill Zechariah. Shallum murdered Zechariah at Ibleam and he became king himself."
    },
    {
      "verse": "11",
      "text": "The other things that happened while Zechariah was king are written in a book. The book is called ‘The history of Israel's kings’."
    },
    {
      "verse": "12",
      "text": "The Lord had given this promise to Jehu: ‘Your descendants will be kings of Israel for four generations. ’ That is what happened."
    },
    {
      "verse": "13",
      "text": "Jabesh's son Shallum became the king of Israel when Uzziah had been king of Judah for 39 years. He ruled as king in Samaria for one month."
    },
    {
      "verse": "14",
      "text": "Then Gadi's son Menahem went from Tirzah up to Samaria. He attacked King Shallum and he killed him. Menahem became king of Israel instead."
    },
    {
      "verse": "15",
      "text": "The other things that happened while Shallum was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about the plan that he made to kill King Zechariah."
    },
    {
      "verse": "16",
      "text": "At that time, when Menahem came from Tirzah, he attacked the city of Tiphsah. The people who lived there refused to let him go into their city. So he killed them all. He even cut open the pregnant women."
    },
    {
      "verse": "17",
      "text": "Gadi's son Menahem became the king of Israel when Azariah had been king of Judah for 39 years. He ruled as king in Samaria for ten years."
    },
    {
      "verse": "18",
      "text": "Menahem did things that the Lord said were evil. He did not turn away from the bad things that Nebat's son Jeroboam had done. Jeroboam had caused many people in Israel to do those sins."
    },
    {
      "verse": "19",
      "text": "Then Pul, the king of Assyria, attacked the land of Israel. Menahem paid him 34 tons of silver to help him to rule Israel with greater power."
    },
    {
      "verse": "20",
      "text": "Menahem made all the rich people in Israel pay taxes to him. Every rich man had to pay 50 silver coins. Menahem gave that money to the king of Assyria. Then the king of Assyria went away. He did not stay any longer in Israel."
    },
    {
      "verse": "21",
      "text": "The other things that happened while Menahem was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about the things that Menahem did."
    },
    {
      "verse": "22",
      "text": "Menahem died and his son, Pekahiah, became king after him."
    },
    {
      "verse": "23",
      "text": "Menahem's son Pekahiah became the king of Israel when Azariah had been king of Judah for 50 years. He ruled Israel as king in Samaria for two years."
    },
    {
      "verse": "24",
      "text": "Pekahiah did things that the Lord said were evil. He did not turn away from the bad things that Nebat's son Jeroboam had done. Jeroboam had caused many people in Israel to do those sins."
    },
    {
      "verse": "25",
      "text": "One of Pekahiah's officers was Remaliah's son, Pekah. Pekah made a plan to kill Pekahiah. He took 50 men from Gilead with him, and he killed King Pekahiah. He also killed Argob and Arieh. He killed them all in a strong room in the king's palace in Samaria. Pekah then became king instead of Pekahiah."
    },
    {
      "verse": "26",
      "text": "The other things that happened while Pekahiah was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about the things that Pekahiah did."
    },
    {
      "verse": "27",
      "text": "Remaliah's son Pekah became the king of Israel when Azariah had been king of Judah for 52 years. He ruled Israel as king in Samaria for 20 years."
    },
    {
      "verse": "28",
      "text": "Pekah did things that the Lord said were evil. He did not turn away from the bad things that Nebat's son Jeroboam had done. Jeroboam had caused many people in Israel to do those sins."
    },
    {
      "verse": "29",
      "text": "While Pekah was the king of Israel, the king of Assyria, Tiglath-Pileser, attacked towns in Israel. He took these places for himself: Ijon, Abel Beth Maakah, Janoah, Kedesh, Hazor, Gilead, Galilee and all of Naphtali's land. He took the people that lived in those places as prisoners to Assyria."
    },
    {
      "verse": "30",
      "text": "Then Elah's son Hoshea made a plan to kill Remaliah's son, Pekah. Hoshea murdered Pekah and he became king instead. That happened when Uzziah's son Jotham had been king of Judah for 20 years."
    },
    {
      "verse": "31",
      "text": "The other things that happened while Pekah was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about the things that Pekah did."
    },
    {
      "verse": "32",
      "text": "Uzziah's son Jotham became the king of Judah when Remaliah's son Pekah had been king of Israel for two years."
    },
    {
      "verse": "33",
      "text": "years old when he became king. He ruled Judah as king in Jerusalem for 16 years. His mother's name was Jerusha. She was Zadok's daughter."
    },
    {
      "verse": "34",
      "text": "Jotham did things that the Lord said were good, as his father Uzziah had done."
    },
    {
      "verse": "35",
      "text": "But he did not remove the altars on the hills. The people continued to offer sacrifices and to burn incense on those altars. Jotham built the Higher Gate of the Lord's temple."
    },
    {
      "verse": "36",
      "text": "The other things that happened while Jotham was king are written in a book. The book is called ‘The history of Judah's kings’. It tells about the things that Jotham did."
    },
    {
      "verse": "37",
      "text": "While Jotham was king, the Lord began to send King Rezin of Syria and Remaliah's son Pekah to attack Judah."
    },
    {
      "verse": "38",
      "text": "Jotham died and they buried him beside his ancestors in the City of David, who was his ancestor. His son Ahaz became king after him."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "Jotham's son Ahaz became the king of Judah when Remaliah's son Pekah had been king of Israel for 17 years."
    },
    {
      "verse": "2",
      "text": "years old when he became king. He ruled Judah as king in Jerusalem for 16 years. He did not do the things that the Lord his God said were good. So he was not like his ancestor, King David."
    },
    {
      "verse": "3",
      "text": "He lived in the same bad way that the kings of Israel did. He even caused his son to walk through fire. In this way he copied the terrible sins of the other nations in Canaan. Those were the nations that the Lord had chased out so that the Israelites could live there."
    },
    {
      "verse": "4",
      "text": "Ahaz offered sacrifices and he burned incense on altars on the hills, as well as under all the big trees."
    },
    {
      "verse": "5",
      "text": "At that time, King Rezin of Syria and Remaliah's son, King Pekah of Israel, attacked Jerusalem. Their armies made a camp all around the city while Ahaz was there. But they could not win the battle against him."
    },
    {
      "verse": "6",
      "text": "(At the same time, King Rezin got Elath town back for Syria. He chased out the people of Judah who were living there. People from Edom then moved into Elath, and they are still living there. )"
    },
    {
      "verse": "7",
      "text": "King Ahaz sent a message to Tiglath-Pileser, the king of Assyria. He said, ‘I am your servant and I need your help. The king of Syria and the king of Israel have brought their armies to attack me in Jerusalem. Please come here to rescue me. ’"
    },
    {
      "verse": "8",
      "text": "Ahaz took the silver and gold things that were stored in the Lord's temple and in the palace. He sent them all as a gift to the king of Assyria."
    },
    {
      "verse": "9",
      "text": "So the king of Assyria agreed to do what Ahaz had asked him to do. He attacked Damascus and he took the city for himself. He sent the people who had lived there to Kir as his prisoners. He punished King Rezin with death."
    },
    {
      "verse": "10",
      "text": "King Ahaz went to Damascus to meet King Tiglath-Pileser of Assyria. When he was there, he saw an altar. He sent a picture and a plan of the altar to Uriah, the priest, so that someone could build one for him."
    },
    {
      "verse": "11",
      "text": "So Uriah built an altar that copied the plan that King Ahaz had sent from Damascus. Uriah finished it before King Ahaz returned."
    },
    {
      "verse": "12",
      "text": "When the king arrived in Jerusalem from Damascus, he saw the new altar. He went near it to offer sacrifices on it."
    },
    {
      "verse": "13",
      "text": "He made a burnt offering and a grain offering. He poured wine as a drink offering. He splashed the blood from his peace offerings onto the altar."
    },
    {
      "verse": "14",
      "text": "A bronze altar stood in front of the Lord's temple to bring sacrifices to him. Now it stood between the new altar and the front of the temple. So Ahaz moved it away from there. He put it on the north side of the new altar. Splash the blood from all these sacrifices on the new altar. But I will use the bronze altar myself, to find out about my future times. ’"
    },
    {
      "verse": "15",
      "text": "Then King Ahaz commanded Uriah the priest, ‘On the large new altar, offer these gifts: A burnt offering for each morning. A grain offering for each evening. A burnt offering and a grain offering on behalf of the king. A burnt offering on behalf of all the people of Israel. A grain offering and drink offerings on behalf of the people. Splash the blood from all these sacrifices on the new altar. But I will use the bronze altar myself, to find out about my future times. ’"
    },
    {
      "verse": "16",
      "text": "So Uriah the priest did what King Ahaz had commanded him to do."
    },
    {
      "verse": "17",
      "text": "King Ahaz also removed the pieces on the sides of the carts which carried the buckets for water. He also removed the buckets. He took the large bath called ‘the Sea’ from the top of the bronze bulls that it stood on. He stood it on a big flat stone instead."
    },
    {
      "verse": "18",
      "text": "He removed the roof that gave shade for people in the temple yard on the Sabbath days. He also removed the king's special entrance into the temple yard. He did these things to please the king of Assyria."
    },
    {
      "verse": "19",
      "text": "The other things that happened while Ahaz was king are written in a book. The book is called ‘The history of Judah's kings’. It tells about the things that Ahaz did."
    },
    {
      "verse": "20",
      "text": "Ahaz died and they buried him beside his ancestors in the City of David. His son Hezekiah became king after him."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "Elah's son Hoshea became the king of Israel when Ahaz had been king of Judah for 12 years. Hoshea ruled Israel as king in Samaria for nine years."
    },
    {
      "verse": "2",
      "text": "Hoshea did things that the Lord said were evil. But he was not as wicked as the kings of Israel who lived before him."
    },
    {
      "verse": "3",
      "text": "Shalmaneser, the king of Assyria, came to attack Hoshea in Samaria. Hoshea agreed to accept Shalmaneser's authority. Israel had to pay a lot of money as taxes to Shalmaneser each year."
    },
    {
      "verse": "4",
      "text": "Then King Shalmaneser discovered that Hoshea had decided to turn against him. Hoshea had sent a message to So, the king of Egypt, to ask for his help. He had also refused to send the taxes for that year to the king of Assyria. So King Shalmaneser took hold of Hoshea and he put him in prison."
    },
    {
      "verse": "5",
      "text": "The king of Assyria took his army and he marched through all the land of Israel. He attacked Samaria. His army made their camp around the city for three years."
    },
    {
      "verse": "6",
      "text": "When Hoshea had been king of Israel for nine years, the king of Assyria won the war against Samaria. He took the Israelites away to Assyria as his prisoners. He caused them to live in Halah, in Gozan beside the River Habor and in towns in Media."
    },
    {
      "verse": "7",
      "text": "All this happened because the Israelites did bad things against the Lord, their God. The Lord had brought them safely out of Egypt. He had rescued them from the power of Pharaoh, the king of Egypt. But now they worshipped other gods."
    },
    {
      "verse": "8",
      "text": "They did the same bad things that the nations that lived in Canaan did. The Lord had chased those nations out of Canaan so that the Israelites could live there. The Israelites copied the bad things that the kings of Israel were doing."
    },
    {
      "verse": "9",
      "text": "They secretly did things that the Lord their God said were not right. In all their towns, they built altars to worship false gods. They built them everywhere, in small villages and in strong cities."
    },
    {
      "verse": "10",
      "text": "They put up stone pillars and Asherah poles to worship their gods. They put them on top of all the high hills and under all the big trees."
    },
    {
      "verse": "11",
      "text": "At all those places they burned incense to worship their gods, as the nations in Canaan had done. The Lord had chased those nations out of Canaan so that the Israelites could live there. The Israelites did evil things that made the Lord very angry."
    },
    {
      "verse": "12",
      "text": "They refused to obey the Lord's command and they worshipped useless idols."
    },
    {
      "verse": "13",
      "text": "The Lord had used his prophets and his other servants to warn the people of Israel and Judah. He told them, ‘Stop living in an evil way. Obey my Law, with its commands and its rules. I gave my Law to your ancestors so that they would obey it. I also used my servants, the prophets, to teach it to you. ’"
    },
    {
      "verse": "14",
      "text": "But the Israelites would not agree to obey God's Law. They were proud and they refused to obey. Like their ancestors, they did not trust in the Lord their God."
    },
    {
      "verse": "15",
      "text": "They did not obey God's rules. They did not accept the covenant that he had made with their ancestors. They did not listen when he warned them. Instead, they worshipped useless idols, which caused them to become useless themselves. The Lord had commanded them not to live in the same way that the nations around them did. But they did that anyway."
    },
    {
      "verse": "16",
      "text": "They turned away from all the commands of the Lord their God. They used metal to make images of two calves as their idols. They also made an Asherah pole to worship. They worshipped all the stars in the sky and they served Baal."
    },
    {
      "verse": "17",
      "text": "They burned their sons and their daughters in fire as offerings to Baal. They used magic to find out what would happen in the future. They chose to do things that the Lord said were evil. That made him very angry."
    },
    {
      "verse": "18",
      "text": "The Lord was so angry with Israel that he sent them far away from himself. Only the tribe of Judah remained."
    },
    {
      "verse": "19",
      "text": "But even the people of Judah did not obey the commands of the Lord their God. They did the same bad things that the Israelites had done."
    },
    {
      "verse": "20",
      "text": "So the Lord turned against all the descendants of Israel. He punished them. He put them under the power of robbers. In that way, he chased them far away from himself."
    },
    {
      "verse": "21",
      "text": "God made Israel become a separate kingdom from David's family, Judah. Then Israel chose Nebat's son Jeroboam to be their king. Jeroboam caused the Israelites to turn away from the Lord. He led them to do terrible sins."
    },
    {
      "verse": "22",
      "text": "The Israelites continued to live in the bad way that Jeroboam showed them. They did not turn away from those sins."
    },
    {
      "verse": "23",
      "text": "In the end, the Lord sent the Israelites away from himself. He had used his servants, the prophets, to warn them that this would happen. As a result, the Assyrian army took the Israelites away from their own land as prisoners to Assyria. They still live there, even today."
    },
    {
      "verse": "24",
      "text": "The king of Assyria brought foreign people to live in the towns of Samaria. They came from Babylon, Cuthah, Avva, Hamath and Sepharvaim. They lived in places in Samaria where the Israelites had lived. They took Samaria for themselves and they lived in its towns."
    },
    {
      "verse": "25",
      "text": "When those people first lived in Samaria, they did not worship the Lord. So the Lord sent lions among them. The lions were killing some of the people."
    },
    {
      "verse": "26",
      "text": "People told the king of Assyria, ‘You sent some nations of people to go and live in the towns of Samaria. But they do not know how to obey the rules of that country's god. So he has sent lions to attack them. The lions are killing them because they do not know the rules of that country's god. ’"
    },
    {
      "verse": "27",
      "text": "The king of Assyria replied, ‘You took some Israelite priests away from Samaria as prisoners. Send one of them back to live there. Then he can teach the people what the god of that country wants them to do. ’"
    },
    {
      "verse": "28",
      "text": "So they sent back one of the priests that they had caught and taken away to Assyria. He went to live in Bethel. He taught the people how to worship the Lord properly."
    },
    {
      "verse": "29",
      "text": "But the people of each nation that had gone to live in Samaria made their own idols to worship. They put them at the altars that the Israelites had built on the hills. They did this in each town where they lived."
    },
    {
      "verse": "30",
      "text": "The people from Babylon made idols of the god called Succoth-Benoth. The people from Cuthah made idols of the god called Nergal. The people from Hamath made idols of the god called Ashima."
    },
    {
      "verse": "31",
      "text": "The people from Avva made idols of their gods called Nibhaz and Tartak. The people from Sepharvaim burned their children in fire as offerings to their gods, Adrammelech and Anammelech."
    },
    {
      "verse": "32",
      "text": "The foreign people in Samaria also worshipped the Lord. They chose some of their own people to serve as priests at the altars on the hills."
    },
    {
      "verse": "33",
      "text": "In this way, they worshipped the Lord, but they also served their own gods. They did that in the way that they had always done in their own countries. That was what they did before the Assyrians sent them to live in Samaria."
    },
    {
      "verse": "34",
      "text": "Even today, they still do things in the same way that they have always done them. They do not truly worship the Lord. They do not obey his rules, his laws or his teaching. They do not obey the commands that the Lord gave to the descendants of Jacob. Jacob was the man that the Lord gave a new name to. He gave him the name ‘Israel’."
    },
    {
      "verse": "35",
      "text": "The Lord made a covenant with the descendants of Israel. He said to them, ‘Do not worship any other gods. Do not bend down low to give them honour. Do not serve them. Do not offer any sacrifices to them."
    },
    {
      "verse": "36",
      "text": "Instead, you must worship only the Lord. He is the one who used his great power to bring you safely out of Egypt. Bend down low to give him honour. Offer sacrifices to him."
    },
    {
      "verse": "37",
      "text": "You must be careful to obey his rules, his teaching, his laws and his commands that he wrote for you. You must not worship other gods."
    },
    {
      "verse": "38",
      "text": "Never forget the covenant that I made with you. Do not worship any other gods."
    },
    {
      "verse": "39",
      "text": "Instead, you must only worship the Lord your God. It is he who will save you from the power of all your enemies. ’"
    },
    {
      "verse": "40",
      "text": "But the foreign people who now lived in Samaria would not accept the Lord's teaching. They continued to live in the way that they always had done."
    },
    {
      "verse": "41",
      "text": "Even while they were worshipping the Lord, they continued to serve their own idols. Their children and their grandchildren continue to live as their fathers did, even today."
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "Ahaz's son Hezekiah became the king of Judah when Elah's son Hoshea had been king of Israel for three years."
    },
    {
      "verse": "2",
      "text": "years old when he became king. He ruled Judah as king in Jerusalem for 29 years. His mother's name was Abijah. She was the daughter of Zechariah."
    },
    {
      "verse": "3",
      "text": "Hezekiah did things that the Lord said were good, as his ancestor King David had done."
    },
    {
      "verse": "4",
      "text": "He removed the altars on the hills. He knocked down the stone pillars that people worshipped and he cut down the Asherah poles. He broke into pieces the bronze snake that Moses had made. Until then, the Israelites had burned incense as an offering to it. It was called Nehushtan."
    },
    {
      "verse": "5",
      "text": "Hezekiah trusted the Lord, Israel's God. None of the other kings of Judah was like him, either before him or after him."
    },
    {
      "verse": "6",
      "text": "He served the Lord faithfully. He obeyed the laws that the Lord had given to Moses."
    },
    {
      "verse": "7",
      "text": "The Lord was with Hezekiah so that he was successful in everything that he decided to do. He turned against the king of Assyria. He refused to serve him."
    },
    {
      "verse": "8",
      "text": "He won battles against the Philistines as far as Gaza. He took all their towns, large and small."
    },
    {
      "verse": "9",
      "text": "When Hezekiah had been king for four years, Shalmaneser, the king of Assyria, took his army to attack Samaria. That was when Hoshea had been king of Israel for seven years. The Assyrian army made their camp around the city of Samaria."
    },
    {
      "verse": "10",
      "text": "After three years, the Assyrian army took the city. So that happened in the sixth year that Hezekiah ruled Judah. It was the ninth year that King Hoshea ruled over Israel."
    },
    {
      "verse": "11",
      "text": "The king of Assyria took the Israelites as prisoners to Assyria. He caused them to live in Halah, at Gozan beside the River Habor and in the towns in Media."
    },
    {
      "verse": "12",
      "text": "This happened because they had not obeyed the Lord their God. They had not obeyed the covenant that he had made with them. They did not accept the teaching that Moses, the Lord's servant, had commanded them to obey."
    },
    {
      "verse": "13",
      "text": "years, King Sennacherib of Assyria attacked Judah with his army. He took all the strong cities in Judah for himself."
    },
    {
      "verse": "14",
      "text": "So King Hezekiah of Judah sent a message to the king of Assyria, who was in Lachish. Hezekiah said, ‘What I did was wrong. Please take your army out of Judah. Then I will pay you everything that you ask me to pay. ’ The king of Assyria told King Hezekiah that he must pay ten tons of silver and one ton of gold."
    },
    {
      "verse": "15",
      "text": "So Hezekiah gave Sennacherib all the silver that was stored in the Lord's temple and in the palace."
    },
    {
      "verse": "16",
      "text": "At the same time, Hezekiah removed the gold that he had used to cover the doors of the Lord's temple. He also took the gold off the wood at the sides of the doors. He gave all that gold to the king of Assyria."
    },
    {
      "verse": "17",
      "text": "King Sennacherib of Assyria sent his three most important officers from Lachish to Jerusalem, to speak to King Hezekiah. The three officers took a large army with them. They arrived in Jerusalem. They went and stood at the stream of water that came from the higher pool. It was on the road to the field where people washed clothes. They arrived in Jerusalem. They went and stood at the stream of water that came from the higher pool. It was on the road to the field where people washed clothes."
    },
    {
      "verse": "18",
      "text": "They told King Hezekiah to come to them. These three people went out to meet them: Hilkiah's son Eliakim, who was the most important officer in the king's palace. Shebna, a government officer. Asaph's son Joah, the king's secretary."
    },
    {
      "verse": "19",
      "text": "One of Sennacherib's officers said to them, ‘Tell Hezekiah that the king of Assyria, the great king, says this to him: “Why are you so sure that someone will rescue you from our power?"
    },
    {
      "verse": "20",
      "text": "You say that you have good plans. You say that your army is strong. But those are only useless words! You have turned against me, so who are you trusting to save you?"
    },
    {
      "verse": "21",
      "text": "Listen to me! You think that Egypt is strong enough to help you, do you? But you should not trust Pharaoh, the king of Egypt. He is like a weak stick. If you use it to walk with, it will break! A broken piece of stick will make a hole through your hand and give you much pain! That is the trouble that the king of Egypt brings to everyone who trusts him to help them."
    },
    {
      "verse": "22",
      "text": "But maybe you will say to me, ‘We are trusting the Lord our God to help us. ’ But it was your king, Hezekiah, who removed the altars and the special places where you worship your God. He told the people of Judah and Jerusalem, ‘You must worship God only at the altar here in Jerusalem. ’ ”"
    },
    {
      "verse": "23",
      "text": "So you should make an agreement with my master, the king of Assyria. I will give you 2, 000 horses if you have enough riders to put on them."
    },
    {
      "verse": "24",
      "text": "You cannot refuse what I offer to you! And I am only an unimportant officer who serves my master. You are hoping that Egypt will give you chariots and men to ride on horses. But you will never be strong enough to win a battle against us."
    },
    {
      "verse": "25",
      "text": "You should also understand this: It was the Lord himself who commanded me to bring my army here and attack Jerusalem. He said to me, “Attack this country and destroy it! ” ’"
    },
    {
      "verse": "26",
      "text": "Then Hilkiah's son Eliakim, Shebna and Joah said to the leader of the Assyrian army, ‘Please sir, speak to us in the Aramaic language. We can understand it. Do not speak to us in the Hebrew language because all the people who are on the wall of the city will understand it. ’"
    },
    {
      "verse": "27",
      "text": "But the Assyrian army leader replied, ‘My master did not send me here to give this message only to your king and to you. The men who are sitting on the city wall also need to hear my master's message. Like you, they will soon have to eat their own dung and to drink their own urine. ’"
    },
    {
      "verse": "28",
      "text": "Then the Assyrian army leader stood there and he shouted in the Hebrew language, ‘Listen to this message from the king of Assyria, the great king!"
    },
    {
      "verse": "29",
      "text": "This is what the king says: “Do not let Hezekiah deceive you. He cannot save you from my power."
    },
    {
      "verse": "30",
      "text": "Do not believe Hezekiah when he tells you that you can trust the Lord to help you. He says, ‘The Lord will surely rescue us. He will not let the king of Assyria take this city for himself. ’"
    },
    {
      "verse": "31",
      "text": "Do not believe what Hezekiah says. ” This is what the king of Assyria says: “Show me that you accept my offer of peace and come out of your city. Then you will all live safely in your homes. You will eat the fruit from your own vines and fig trees. You will drink the water from your own wells."
    },
    {
      "verse": "32",
      "text": "Later, I will come to Jerusalem. I will take you away to a country that is like your own land here. There will be plenty of grain and new wine for you in that country. There will be bread and there will be vineyards. There will be olive trees and there will be honey. Choose life instead of death! Do not listen to Hezekiah. He is deceiving you when he says, ‘The Lord will rescue us. ’"
    },
    {
      "verse": "33",
      "text": "No god of any nation has ever saved his country from the king of Assyria's power."
    },
    {
      "verse": "34",
      "text": "The gods of Hamath and Arpad could not help their people. The gods of Sepharvaim, Hena and Ivvah could not help their people either. No god was able to rescue Samaria from my power."
    },
    {
      "verse": "35",
      "text": "No god among all the gods of those countries could save their people from my power. So do not think that the Lord can save Jerusalem from my power. ” ’"
    },
    {
      "verse": "36",
      "text": "When the people who were sitting on the wall heard this, they were quiet. They did not reply, because King Hezekiah had said, ‘Do not answer him. ’"
    },
    {
      "verse": "37",
      "text": "Then King Hezekiah's three officers, Eliakim, Shebna and Joah, went back to Hezekiah. They had torn their clothes because they were very upset. They told the king what the Assyrian officer had said."
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "When King Hezekiah heard the report of his officers, he tore his clothes. Then he put on rough sackcloth and he went into the Lord's temple."
    },
    {
      "verse": "2",
      "text": "He sent Eliakim, Shebna and the leaders of the priests to Amoz's son, Isaiah the prophet. Eliakim was the most important officer in the king's palace. Shebna was a government officer. They were all wearing sackcloth."
    },
    {
      "verse": "3",
      "text": "They told Hezekiah's message to Isaiah: ‘This is a time of great trouble. Assyria has insulted us to make us ashamed. Our nation is like a woman who is ready to give birth, but she is too weak to push the child out."
    },
    {
      "verse": "4",
      "text": "The Assyrian officer has brought a message from his king to insult the God who lives for ever. Maybe the Lord your God has heard that message. He should punish the officer for his wicked message. So please pray for the people who remain in Jerusalem. ’"
    },
    {
      "verse": "5",
      "text": "When King Hezekiah's officers told their message to Isaiah,"
    },
    {
      "verse": "6",
      "text": "Isaiah said to them, ‘Tell your master that the Lord says this: “Do not let the words that you have heard make you afraid. The servants of the king of Assyria have insulted me, the Lord."
    },
    {
      "verse": "7",
      "text": "Listen to me! I will put a spirit into the king of Assyria's mind. He will hear a report which will cause him to return to his own country. There, in his own land, I will cause someone to kill him with a sword. ” ’"
    },
    {
      "verse": "8",
      "text": "At that time, the king of Assyria had left Lachish city. When the Assyrian officer heard that news, he left Jerusalem. He went to meet the king at Libnah, where the king was now fighting a battle."
    },
    {
      "verse": "9",
      "text": "Then the king of Assyria heard a report about Tirhakah, the king of Ethiopia. People told him, ‘He has brought his army from Ethiopia to fight against you. ’When the king of Assyria heard that news, he sent another message to Hezekiah in Jerusalem."
    },
    {
      "verse": "10",
      "text": "This was his message to King Hezekiah of Judah: ‘You are hoping that your God will help you. Your God may say that the king of Assyria will not destroy Jerusalem. But do not let him deceive you."
    },
    {
      "verse": "11",
      "text": "You have heard how the kings of Assyria have completely destroyed all other countries. So do not think that your God will rescue you."
    },
    {
      "verse": "12",
      "text": "The gods of those other countries did not save them. Our kings destroyed the nations of Gozan, Haran and Rezeph. They killed the people of Eden who lived in Tel Assar."
    },
    {
      "verse": "13",
      "text": "The kings of Hamath and Arpad have gone. The king of Sepharvaim city has gone. The kings of Hena and Ivvah have also gone. ’"
    },
    {
      "verse": "14",
      "text": "When Hezekiah received the letter with this message, he read it. Then he went up to the Lord's temple. He put the letter there, in front of the Lord."
    },
    {
      "verse": "15",
      "text": "Hezekiah prayed to the Lord. He said, ‘Lord, you are Israel's God. You sit on your throne between the cherubs. Only you are the God who rules all the kingdoms in the world. You have made the heavens and the earth."
    },
    {
      "verse": "16",
      "text": "Lord, please listen carefully to me. Lord, look carefully at this letter. Listen to Sennacherib's message. He is insulting you, the God who lives for ever."
    },
    {
      "verse": "17",
      "text": "It is true, Lord, that the kings of Assyria have destroyed these nations and their lands."
    },
    {
      "verse": "18",
      "text": "They have thrown the gods of these nations into the fire. Those idols are not really gods. People used wood and stone to make them. So the Assyrians could destroy them."
    },
    {
      "verse": "19",
      "text": "So now, our Lord and our God, please save us from the power of Sennacherib! Then all the kingdoms in the world will know that you Lord are the only God. ’"
    },
    {
      "verse": "20",
      "text": "Then Amoz's son Isaiah sent this message to Hezekiah: ‘The Lord, Israel's God, says, “I heard your prayer to me about Sennacherib, the king of Assyria. ” “The holy people of Zion laugh at you! They think that you are useless. Yes, the people of Jerusalem shake their heads as you run away."
    },
    {
      "verse": "21",
      "text": "This is the Lord's reply. The Lord says this about King Sennacherib:“The holy people of Zion laugh at you! They think that you are useless. Yes, the people of Jerusalem shake their headsas you run away."
    },
    {
      "verse": "22",
      "text": "Who do you think it is that you have insulted? Who have you shouted at? Who have you looked at so proudly? The answer is the Holy God of Israel! Who have you shouted at? Who have you looked at so proudly? The answer is the Holy God of Israel!"
    },
    {
      "verse": "23",
      "text": "You have sent your servantsto insult the Lord God. You have said, ‘I have taken all my chariotsand I have gone up high mountains, the highest mountains in Lebanon. I have cut down its tall cedar trees, and I have cut down its best pine trees. I went up to its highest places, and I went far into its forests. to insult the Lord God. You have said, ‘I have taken all my chariots and I have gone up high mountains, the highest mountains in Lebanon. I have cut down its tall cedar trees, and I have cut down its best pine trees. I went up to its highest places, and I went far into its forests."
    },
    {
      "verse": "24",
      "text": "I dug wells in other countries, and they gave me water to drink. My army marched through all the rivers in Egypt, and the rivers became dry. ’ and they gave me water to drink. My army marched through all the rivers in Egypt, and the rivers became dry. ’"
    },
    {
      "verse": "25",
      "text": "You said that, but now listen to this! You must surely have heard it already. I decided what to do a long time ago! Now I am causing it to happen. I decided that you would destroy strong citiesso that they became heaps of stones. You must surely have heard it already. I decided what to do a long time ago! Now I am causing it to happen. I decided that you would destroy strong cities so that they became heaps of stones."
    },
    {
      "verse": "26",
      "text": "The people of those cities have no power. They are afraid and they are confused. They are like plants in a field, that cannot live for a long time. They are like fresh green grass, or grass that grows on the roof of a house. When a hot wind blows on them, it burns them and they die. They are afraid and they are confused. They are like plants in a field, that cannot live for a long time. They are like fresh green grass, or grass that grows on the roof of a house. When a hot wind blows on them, it burns them and they die."
    },
    {
      "verse": "27",
      "text": "I know everything about you. I know where you live. I know when you go out. And I know when you return home. I know how much you shout against me, when you are angry. I know where you live. I know when you go out. And I know when you return home. I know how much you shout against me, when you are angry."
    },
    {
      "verse": "28",
      "text": "Yes, you do shout at me! And I have heard all your proud noise. So I will put my hook in your nose. I will tie a rope to your mouth. Then I will pull you back homeby the same way that you came. ” And I have heard all your proud noise. So I will put my hook in your nose. I will tie a rope to your mouth. Then I will pull you back home by the same way that you came. ”"
    },
    {
      "verse": "29",
      "text": "King Hezekiah, this is how you will know that I have spoken a true message from the Lord. This year, you will eat crops that grow by themselves. And next year you will eat what grows from the same seeds. But in the third year you will plant seeds for yourselves, and they will give you a harvest of crops. You will plant vines again and you will eat grapes from them."
    },
    {
      "verse": "30",
      "text": "The people who remain in Judah will be like strong plants that put their roots down into the ground. Their branches will give lots of fruit."
    },
    {
      "verse": "31",
      "text": "A small number of people will still be alive in Jerusalem. They will leave Mount Zion and they will go to other places. The great love that the Lord Almighty has for his people will cause that to happen!"
    },
    {
      "verse": "32",
      "text": "This is what the Lord says about the king of Assyria:“His army will not come into this city. His soldiers will not shoot any arrows here. They will not attack the city as they hold their shields. They will not build heaps of earth against the city's walls. “His army will not come into this city. His soldiers will not shoot any arrows here. They will not attack the city as they hold their shields. They will not build heaps of earth against the city's walls."
    },
    {
      "verse": "33",
      "text": "No! The king will return home by the way that he came. He will not come into this city. ”That is what the Lord says. He will not come into this city. ” That is what the Lord says."
    },
    {
      "verse": "34",
      "text": "“I will make this city safe and I will rescue it. I will do that to show that I am great. I promised my servant David that I would do it. So I will do it. ” ’ I will do that to show that I am great. I promised my servant David that I would do it. So I will do it. ” ’"
    },
    {
      "verse": "35",
      "text": "That night, the Lord's angel went to the camp of the Assyrian army. He killed 185, 000 of their soldiers. When people got up in the morning, they saw all those dead bodies!"
    },
    {
      "verse": "36",
      "text": "So King Sennacherib of Assyria took his army away. He returned to Assyria and he lived in Nineveh."
    },
    {
      "verse": "37",
      "text": "One day, Sennacherib was worshipping his god Nisrok in Nisrok's temple. Two of Sennacherib's sons, Adrammelech and Sharezer, went in and they killed him with their swords. Then they ran away to the region of Ararat. Sennacherib's son Esarhaddon now ruled Assyria as king."
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "At that time, Hezekiah became very ill. He nearly died. Then Amoz's son, Isaiah the prophet, went to Hezekiah. He said to Hezekiah, ‘This is what the Lord says: “You will soon die. You will not get better. So you must tell your family what to do after your death. ” ’"
    },
    {
      "verse": "2",
      "text": "Then Hezekiah turned his face towards the wall and he prayed to the Lord."
    },
    {
      "verse": "3",
      "text": "He said, ‘Lord, please remember that I have served you well. I have always obeyed you. You could trust me to do the things that you told me to do. ’ Hezekiah wept very much."
    },
    {
      "verse": "4",
      "text": "While Isaiah was still in the middle yard of the palace, the Lord gave him this message:"
    },
    {
      "verse": "5",
      "text": "‘Go back! Say to Hezekiah, the leader of my people, “This is what the Lord says, the God that your ancestor David worshipped. I have heard your prayer and I have seen your tears. I will make you well again. On the third day from now you will go to the Lord's temple."
    },
    {
      "verse": "6",
      "text": "more years. I will rescue you and this city from the power of the king of Assyria. I will keep Jerusalem safe, because I do what is right and I made a promise to my servant David. ” ’"
    },
    {
      "verse": "7",
      "text": "Then Isaiah said, ‘Take some figs to make a medicine. ’ So the king's servants did what Isaiah had said. They put the medicine on Hezekiah's boil. He became well again."
    },
    {
      "verse": "8",
      "text": "Hezekiah had asked Isaiah, ‘What will show me that the Lord will make me well again? How will I know that I will go up to the Lord's temple on the third day from now? ’"
    },
    {
      "verse": "9",
      "text": "Isaiah answered, ‘The Lord will do a miracle to show you that he will do what he has promised. Do you want the shadow on these stairs to move down ten steps? Or do you want the shadow to go back up ten steps? ’"
    },
    {
      "verse": "10",
      "text": "Hezekiah said, ‘It is easy to cause the shadow to move down ten steps. So I want it to go back up ten steps. ’"
    },
    {
      "verse": "11",
      "text": "Then Isaiah the prophet asked the Lord to do this. The Lord caused the shadow to go back up ten steps on the stairs that King Ahaz had made."
    },
    {
      "verse": "12",
      "text": "At that time, Baladan's son, Merodach-Baladan, was the king of Babylon. Merodach-Baladan sent letters and a gift to Hezekiah. He had heard the news that Hezekiah had been ill."
    },
    {
      "verse": "13",
      "text": "Hezekiah was happy to meet the officers who came from the king of Babylon. Hezekiah showed them the places where he stored his valuable things. He showed them his silver and gold things, his spices and very valuable olive oil. He also showed them all his weapons. Hezekiah showed them all his valuable things. There was nothing in his palace or in his whole kingdom that he did not show to the king of Babylon's officers."
    },
    {
      "verse": "14",
      "text": "Then Isaiah the prophet went to King Hezekiah. Isaiah asked the king, ‘What did those men say? Where did they come from? ’ Hezekiah replied, ‘They came from Babylon, far away. ’"
    },
    {
      "verse": "15",
      "text": "Isaiah asked, ‘What did they see in your palace? ’ Hezekiah said, ‘They saw everything that is in my palace. I showed all my valuable things to them. ’"
    },
    {
      "verse": "16",
      "text": "Then Isaiah said to Hezekiah, ‘Listen to this message from the Lord:"
    },
    {
      "verse": "17",
      "text": "“Understand this! One day, soldiers from Babylon will carry away all your valuable things. Everything that you and your ancestors have stored here until now will go to Babylon. They will leave nothing here."
    },
    {
      "verse": "18",
      "text": "Some of your own descendants will also go to Babylon. Soldiers from Babylon will take them away from here. Your descendants will become eunuchs in the king of Babylon's palace. ” That is what the Lord says. ’"
    },
    {
      "verse": "19",
      "text": "Hezekiah said to Isaiah, ‘The Lord's message that you have spoken to me is good. ’ But he was thinking, ‘While I am still alive, people will live safely without any trouble. ’"
    },
    {
      "verse": "20",
      "text": "The other things that happened while Hezekiah was king are written in a book. The book is called ‘The history of Judah's kings’. It tells about the things that Hezekiah did. It includes a report about the pool and the stream that he built to bring water into the city of Jerusalem."
    },
    {
      "verse": "21",
      "text": "So Hezekiah died and they buried him beside his ancestors. His son Manasseh became king after him."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "years old when he became king. He ruled as king in Jerusalem for 55 years. His mother's name was Hephzibah."
    },
    {
      "verse": "2",
      "text": "Manasseh did things that the Lord said were evil. He did the same terrible sins that the other nations in Canaan had done. Those were the nations that the Lord had chased out so that the Israelites could live there."
    },
    {
      "verse": "3",
      "text": "Manasseh built again the altars on the hills that his father Hezekiah had destroyed. He built altars for people to worship Baal. He also made an Asherah pole, as King Ahab of Israel had done. He bent down low to worship all the stars in the sky."
    },
    {
      "verse": "4",
      "text": "He built altars in the Lord's temple. The Lord had said about his temple, ‘That is my home in Jerusalem where people will worship me. ’"
    },
    {
      "verse": "5",
      "text": "Manasseh built altars to give honour to the stars, in both yards of the Lord's temple."
    },
    {
      "verse": "6",
      "text": "He burnt his own son with fire as a sacrifice. He used magic and false gods to find out what would happen in the future. He took advice from magicians and people who talked to the spirits of dead people. He did many things that the Lord said were very evil. This made the Lord very angry."
    },
    {
      "verse": "7",
      "text": "Manasseh used wood to make an image of the false god, Asherah. He put this idol in the Lord's temple. The Lord had said this about his temple to King David and to his son King Solomon: ‘My people will worship me in my temple here in Jerusalem. That is the place that I have chosen to be my home for ever. I have chosen it from among all the tribes of Israel."
    },
    {
      "verse": "8",
      "text": "I will never cause the Israelite people to leave this land that I gave to their ancestors. But they must be careful to obey all my commands and all my Law that my servant Moses gave to them. ’"
    },
    {
      "verse": "9",
      "text": "But the people did not obey the Lord. Manasseh caused them to turn away from God. The Israelites did more evil things than the people who lived in Canaan before them. The Lord had destroyed those nations so that the Israelites could live there."
    },
    {
      "verse": "10",
      "text": "So the Lord used his servants, the prophets, to say this:"
    },
    {
      "verse": "11",
      "text": "‘Manasseh, the king of Judah, has done terrible sins. He has done more evil things than the Amorites did, who lived in Canaan before him. He has caused the people of Judah to do wrong things as they worship his idols."
    },
    {
      "verse": "12",
      "text": "So the Lord, Israel's God, says this: “I will cause great trouble to happen in Jerusalem and in all the kingdom of Judah. Everyone who hears the news about it will be very surprised."
    },
    {
      "verse": "13",
      "text": "I will judge Jerusalem and I will punish the people, as I punished Samaria and the family of King Ahab. I will remove the people from Jerusalem, like someone who washes the dirt from both sides of a plate."
    },
    {
      "verse": "14",
      "text": "I will no longer help those of my own people who still remain. I will put them under the power of their enemies. All their enemies will rob them. They will take all their valuable things for themselves."
    },
    {
      "verse": "15",
      "text": "My people have done things that I say are evil. They have made me very angry. They have continued to do that since their ancestors came out from Egypt, until today. ” ’"
    },
    {
      "verse": "16",
      "text": "Also, Manasseh murdered many people who had not done anything wrong. Their blood was in all the streets of Jerusalem! He caused the people in Judah to do bad things too. He caused them to do things that the Lord said were evil."
    },
    {
      "verse": "17",
      "text": "The other things that happened while Manasseh was king are written in a book. The book is called ‘The history of Judah's kings’. It tells about the things that Manasseh did, including all his terrible sins."
    },
    {
      "verse": "18",
      "text": "Manasseh died and they buried him in the garden of his palace. It is called Uzza's garden. His son Amon became king after him."
    },
    {
      "verse": "19",
      "text": "years old when he became king. He ruled as king in Jerusalem for two years. His mother's name was Meshullemeth. She was the daughter of Haruz, who came from Jotbah."
    },
    {
      "verse": "20",
      "text": "Amon did things that the Lord said were evil, as his father Manasseh had done."
    },
    {
      "verse": "21",
      "text": "He lived in the same bad way as his father did. He bent down low to worship the useless idols that his father had worshipped."
    },
    {
      "verse": "22",
      "text": "He turned away from the Lord, the God that his ancestors worshipped. He did not obey the Lord's teaching."
    },
    {
      "verse": "23",
      "text": "Amon's officers decided to kill him. They killed him in his palace."
    },
    {
      "verse": "24",
      "text": "Then the people of Judah punished all Amon's murderers with death. They chose his son Josiah to be king after him."
    },
    {
      "verse": "25",
      "text": "The other things that Amon did are written in a book. The book is called ‘The history of Judah's kings’"
    },
    {
      "verse": "26",
      "text": "People buried him in his grave in Uzza's garden. His son Josiah became king after him."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "Josiah was eight years old when he became king. He ruled as king in Jerusalem for 31 years. His mother's name was Jedidah. She was the daughter of Adaiah, who came from Bozkath."
    },
    {
      "verse": "2",
      "text": "Josiah did things that the Lord said were right. He lived in the good ways of his ancestor, King David. He did not turn away from the Lord's teaching in any way."
    },
    {
      "verse": "3",
      "text": "years, he sent Shaphan to the Lord's temple. Shaphan was the son of Azaliah, and the grandson of Meshullam. He was the king's secretary. Josiah told Shaphan,"
    },
    {
      "verse": "4",
      "text": "‘Go to meet Hilkiah, the leader of the priests. Ask him to count the money that people have brought as gifts into the Lord's temple. Those are the offerings that the temple guards have received from people."
    },
    {
      "verse": "5",
      "text": "The priests must give the money to the men who have authority over the work on the Lord's temple. Those leaders must pay the men who are doing the repairs."
    },
    {
      "verse": "6",
      "text": "Those workers are the carpenters, the builders and the men who work with stones. The leaders of the work must also buy wood. And they must buy stones that are ready to use. They need those things to repair the temple."
    },
    {
      "verse": "7",
      "text": "The leaders of the work are honest men. So they do not need to give a report on how they use the money. ’"
    },
    {
      "verse": "8",
      "text": "Hilkiah, the leader of the priests, told Shaphan, the king's secretary, ‘I have found the Book of the Law in the Lord's temple. ’ He gave the book to Shaphan and Shaphan read it."
    },
    {
      "verse": "9",
      "text": "Then Shaphan went to the king. He said to him, ‘Your officers have paid out all the money that was in the Lord's temple. They have given it to the men who are working on the temple repairs and to their leaders. ’"
    },
    {
      "verse": "10",
      "text": "Then Shaphan told the king, ‘Hilkiah the priest has given me a book. ’ Shaphan started to read the book while the king listened."
    },
    {
      "verse": "11",
      "text": "When the king heard the words from the Book of the Law, he was very upset. He tore his clothes."
    },
    {
      "verse": "12",
      "text": "He gave a command to Hilkiah the priest, Shaphan's son Ahikam, Micaiah's son Acbor, Shaphan the secretary and Asaiah the king's servant."
    },
    {
      "verse": "13",
      "text": "He told them, ‘Go to the temple. Ask the Lord about the message in this book that Hilkiah has found. I need to know what I should do, as well as all the people of Judah. The Lord has become very angry with us because our ancestors have not obeyed the words in this book. They have not done the things that it tells us we should do. ’"
    },
    {
      "verse": "14",
      "text": "So Hilkiah, Ahikam, Acbor, Shaphan and Asaiah went to speak to Huldah. Huldah was a prophetess who lived in the north part of Jerusalem. She was the wife of Shallum, the son of Tikvah. Tikvah was the son of Harhas, who took care of the king's clothes. The king's men told Huldah why they had come to meet her."
    },
    {
      "verse": "15",
      "text": "She said to them, ‘The Lord, Israel's God, says, “Tell this to the man who sent you here to me:"
    },
    {
      "verse": "16",
      "text": "This is what the Lord says. I will bring great trouble to this place and the people who live here. The message of the book that the king of Judah has read tells about what will happen."
    },
    {
      "verse": "17",
      "text": "I will send this trouble because they have turned away from me. They have offered sacrifices to other gods. I am very angry with them because of all the idols that they have made for themselves. My anger is like a fire that is burning and nobody can stop it! ”"
    },
    {
      "verse": "18",
      "text": "The king of Judah sent you here to ask for the Lord's answer. Say to the king, “The Lord, Israel's God, says this about the message that you have heard:"
    },
    {
      "verse": "19",
      "text": "When you heard the message that I had spoken, you were very upset. You made yourself humble to respect me. You tore your clothes and you wept. You did that when you heard how I would punish this place and the people who live here. I said that I would destroy this place so that people would use its name as a curse. Because you became so upset, I have heard your prayer. The men took Huldah's answer back to the king."
    },
    {
      "verse": "20",
      "text": "So I will let you die in peace and people will bury you beside your ancestors. You yourself will never see the great trouble that I will bring to this place. ” That is what the Lord says. ’The men took Huldah's answer back to the king."
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "King Josiah told all the leaders of Judah and Jerusalem to come and meet with him."
    },
    {
      "verse": "2",
      "text": "He went up to the Lord's temple. All the people who lived in Jerusalem and in the rest of Judah went with him. They included the priests, the prophets, young people and old people. Everyone went to the temple. They all listened while the king read to them all the words in the Book of God's Covenant. That was the book that Hilkiah had found in the Lord's temple."
    },
    {
      "verse": "3",
      "text": "Then the king stood in his place beside the pillar in the temple. He promised the Lord that he would obey the covenant. He agreed to serve the Lord faithfully and to obey his commands, laws and rules. Josiah agreed to obey what was written in the Book of God's Covenant. All the people also promised to obey the covenant."
    },
    {
      "verse": "4",
      "text": "Then the king gave a command to Hilkiah, the leader of the priests, and to the other priests and the temple guards. He told them to bring out from the Lord's temple everything that people used there to worship false gods. People used those things to worship Baal, Asherah and all the stars in the sky. King Josiah burned those things outside Jerusalem, in the fields of the Kidron Valley. Then he took all the ashes to Bethel."
    },
    {
      "verse": "5",
      "text": "He removed the priests who served false gods. The kings of Judah had chosen those priests to make offerings at the altars on the hills. They were on the hills in Judah's cities and all around Jerusalem. These priests offered sacrifices to Baal, to the sun, to the moon and to all the stars in the sky."
    },
    {
      "verse": "6",
      "text": "He also removed the Asherah pole from the Lord's temple. He took it outside Jerusalem, to the Kidron Valley. He burned it there. He made its ashes into dust. He threw the dust over the graves of ordinary people."
    },
    {
      "verse": "7",
      "text": "King Josiah also destroyed the rooms in the Lord's temple where the male prostitutes lived. Women also made clothes there for the idol of Asherah."
    },
    {
      "verse": "8",
      "text": "He brought from the towns of Judah all the priests who served false gods. He destroyed the altars on the hills where those priests offered sacrifices. He did that everywhere in Judah, from Geba to Beersheba. He destroyed the altar that was on the left side of one of Jerusalem city's gates. It was called the Gate of Joshua. Joshua was an officer who had authority over the city."
    },
    {
      "verse": "9",
      "text": "The priests who served at those altars did not have authority to serve at the altar in the Lord's temple in Jerusalem. But they could eat the same flat bread that the other priests ate."
    },
    {
      "verse": "10",
      "text": "King Josiah destroyed the place called Topheth, which was in the Valley of Ben Hinnom. After that, nobody could burn his son or his daughter there in the fire as a sacrifice to Molech."
    },
    {
      "verse": "11",
      "text": "He removed the images of horses that the kings of Judah had put beside the entrance to the Lord's temple. He also burned the chariots that were there. The kings had put the horses and chariots there to give honour to the sun god. They were in the temple yard near the room of Nathan Melech, a palace officer."
    },
    {
      "verse": "12",
      "text": "King Josiah knocked down the altars that were on the roof of the palace. The kings of Judah had built the altars there, above the high room of King Ahaz. He also knocked down the altars that King Manasseh had built in the two yards of the Lord's temple. Josiah broke the altars into small pieces. He threw the bits into the Kidron Valley."
    },
    {
      "verse": "13",
      "text": "King Josiah also destroyed the altars that were on the hills east of Jerusalem. Those altars were on the south side of Mount Trouble. King Solomon had built them to worship these false gods: Ashtoreth, a wicked female god that the people in Sidon worshipped. Chemosh, a wicked god that the people in Moab worshipped. Molech, the evil god that the people in Ammon worshipped."
    },
    {
      "verse": "14",
      "text": "Josiah broke the stone pillars that people worshipped into small pieces. He cut down the Asherah poles. He covered the ground where they had been with human bones."
    },
    {
      "verse": "15",
      "text": "Josiah also destroyed the altar at Bethel. It was an altar for false gods that Nebat's son, King Jeroboam had made. King Jeroboam had caused the people of Israel to do bad things. Josiah completely destroyed that altar. He broke its stones into small pieces so that only dust remained. He also burned the Asherah pole."
    },
    {
      "verse": "16",
      "text": "Then Josiah looked around and he saw graves on the hill. He sent someone to bring the bones from them. He burned them on the altar, so that people could not use it again. The Lord had said that this would happen when King Jeroboam was standing beside the altar. A man of God had spoken God's message to Jeroboam during a festival. Josiah looked up and he saw the grave of the man of God who had spoken God's message."
    },
    {
      "verse": "17",
      "text": "He asked, ‘Whose grave stone is that? ’ The men from Bethel city said to him, ‘It is the grave of the man of God who came from Judah. You have now done to this altar at Bethel the things that he said would happen. ’"
    },
    {
      "verse": "18",
      "text": "King Josiah said, ‘Do not do anything to his grave. Do not remove his bones. ’ So they did not do anything with the bones of the man of God. They also left the bones of the old prophet who had come from Samaria."
    },
    {
      "verse": "19",
      "text": "King Josiah removed the altars on the hills in all the towns of Samaria. The kings of Israel had built those altars and that had made the Lord angry. Josiah destroyed all of them, in the same way that he destroyed the altar at Bethel."
    },
    {
      "verse": "20",
      "text": "He punished with death all the priests who served false gods at those altars. He killed them on their own altars. He burned human bones on all the altars. After he had done that, he went back to Jerusalem."
    },
    {
      "verse": "21",
      "text": "Then the king commanded all the people, ‘The Book of God's Covenant teaches about the Passover festival. Now you must eat that Passover meal to give honour to the Lord your God. ’"
    },
    {
      "verse": "22",
      "text": "Since the time when the judges ruled Israel, the Israelites had not had a Passover festival like that. They had never had it during the time when kings ruled Judah and Israel."
    },
    {
      "verse": "23",
      "text": "But in the 18th year that Josiah ruled Judah as king, the people once again had a Passover festival to give honour to the Lord."
    },
    {
      "verse": "24",
      "text": "Josiah did other things to obey the rules that were written in the Book of God's Law. That was the book that Hilkiah the priest had found in the Lord's temple. Josiah removed the people who spoke to the spirits of dead people and the other magicians. He destroyed the images that people worshipped in their homes. He destroyed all the other idols that people had started to worship in Jerusalem and in all Judah."
    },
    {
      "verse": "25",
      "text": "Josiah turned to the Lord and he served the Lord faithfully with all his strength. He obeyed all the Law of Moses. No other king was like Josiah, either before him or after him."
    },
    {
      "verse": "26",
      "text": "But the Lord continued to be angry with the people of Judah. The wicked things that King Manasseh did had made him very angry."
    },
    {
      "verse": "27",
      "text": "So the Lord said, ‘I will also send Judah away from me, as I sent Israel away. I will refuse to stay in Jerusalem and in my temple. I chose the city to be my home and the place where people would worship me. But now I will leave there. ’"
    },
    {
      "verse": "28",
      "text": "The other things that happened while Josiah was king are written in a book. The book is called ‘The history of Judah's kings’. It tells about the things that Josiah did."
    },
    {
      "verse": "29",
      "text": "While Josiah was king, Pharaoh Necho, the king of Egypt, took his army up to the River Euphrates. He went there to help the king of Assyria. King Josiah took his army to fight against Pharaoh Necho. But Necho killed Josiah in a battle at Megiddo."
    },
    {
      "verse": "30",
      "text": "Josiah's servants put his dead body in a chariot. They took it from Megiddo to Jerusalem. They buried him in his own grave. Then the people of Judah poured olive oil on the head of Josiah's son Jehoahaz. So he became king after his father."
    },
    {
      "verse": "31",
      "text": "years old when he became king. He ruled as king in Jerusalem for three months. His mother's name was Hamutal. She was the daughter of Jeremiah, who came from Libnah."
    },
    {
      "verse": "32",
      "text": "Jehoahaz did things that the Lord said were evil."
    },
    {
      "verse": "33",
      "text": "Pharaoh Necho kept him in a prison at Riblah, so that Jehoahaz could not rule in Jerusalem. Riblah is in the Hamath region. Necho made Judah pay tax to him. It was 3, 400 kilograms of silver and 34 kilograms of gold."
    },
    {
      "verse": "34",
      "text": "Pharaoh Necho made Josiah's son Eliakim become the new king of Judah. Necho changed Eliakim's name to Jehoiakim. Then he took Jehoahaz away to Egypt. Later, Jehoahaz died in Egypt."
    },
    {
      "verse": "35",
      "text": "King Jehoiakim paid Pharaoh Necho all the silver and gold that he asked for. But King Jehoiakim had to make the people of Judah pay taxes so that he could pay Pharaoh Necho. Each person in Judah had to pay what was right, if they were rich or if they were poor."
    },
    {
      "verse": "36",
      "text": "years old when he became king. He ruled for 11 years as king in Jerusalem. His mother's name was Zebidah. She was the daughter of Pedaiah, who came from Rumah."
    },
    {
      "verse": "37",
      "text": "Jehoiakim did things that the Lord said were evil, as his ancestors had done."
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "While Jehoiakim was king, King Nebuchadnezzar of Babylon attacked Judah. Jehoiakim was under Nebuchadnezzar's authority for three years. But then Jehoiakim turned against Nebuchadnezzar."
    },
    {
      "verse": "2",
      "text": "The Lord sent groups of soldiers to attack towns in Judah. The soldiers came from Babylon, Syria, Moab and Ammon. The Lord sent them to destroy Judah. He had already sent his servants, the prophets, to warn the people of Judah about this."
    },
    {
      "verse": "3",
      "text": "The Lord had said that these things must happen. He had decided to send Judah away from himself because of the sins that King Manasseh had done."
    },
    {
      "verse": "4",
      "text": "Manasseh had murdered people who had not done anything wrong. Their blood was in the streets of Jerusalem. The Lord would not agree to forgive Manasseh for his sins."
    },
    {
      "verse": "5",
      "text": "The other things that happened while Jehoiakim was king are written in a book. The book is called ‘The history of Judah's kings’. It tells about the things that Jehoiakim did."
    },
    {
      "verse": "6",
      "text": "Jehoiakim died and they buried him beside his ancestors. His son Jehoiachin became king after him."
    },
    {
      "verse": "7",
      "text": "The king of Egypt did not take his army out of his own country again. That was because the king of Babylon had taken a lot of Egypt's land for himself. He had taken all the land between the Stream of Egypt and the River Euphrates. Before that, the king of Egypt had authority over that land."
    },
    {
      "verse": "8",
      "text": "years old when he became king. He ruled as king in Jerusalem for three months. His mother's name was Nehushta. She was the daughter of Elnathan, who came from Jerusalem."
    },
    {
      "verse": "9",
      "text": "Jehoiachin did things that the Lord said were evil, as his father had done."
    },
    {
      "verse": "10",
      "text": "King Nebuchadnezzar's officers took their army to attack Jerusalem. They made their camp all around the city."
    },
    {
      "verse": "11",
      "text": "Then King Nebuchadnezzar of Babylon came up to Jerusalem himself while his officers were there."
    },
    {
      "verse": "12",
      "text": "Jehoiachin, the king of Judah, went out of the city to put himself under King Nebuchadnezzar's authority. He went with his mother, his servants, his leaders and his palace officers. In the eighth year that King Nebuchadnezzar ruled as king, he made Jehoiachin his prisoner."
    },
    {
      "verse": "13",
      "text": "King Nebuchadnezzar took all the valuable things from the Lord's temple and from the king's palace. He cut away all the gold things that King Solomon had made for the Lord's temple. The Lord had already warned that this would happen."
    },
    {
      "verse": "14",
      "text": "Nebuchadnezzar took away as his prisoners all the people who lived in Jerusalem. There were 10, 000 people. They included all the officers and all the soldiers. He also took away the people who had special skills to work with wood and metal. The only people who remained in Judah were the very poor people."
    },
    {
      "verse": "15",
      "text": "Nebuchadnezzar took Jehoiachin away from Jerusalem as his prisoner to Babylon. He also took the king's mother, his wives, his officers and the important leaders of Judah."
    },
    {
      "verse": "16",
      "text": "The king of Babylon also took away to Babylon all the soldiers of Judah's army. There were 7, 000 soldiers. They included the best fighters. He also took 1, 000 workers who had special skills to make things with wood and metal."
    },
    {
      "verse": "17",
      "text": "Nebuchadnezzar chose Jehoiachin's uncle, Mattaniah, to be king instead of Jehoiachin. Nebuchadnezzar changed Mattaniah's name to Zedekiah."
    },
    {
      "verse": "18",
      "text": "years old when he became king. He ruled in Jerusalem for 11 years. His mother's name was Hamutal. She was the daughter of Jeremiah, who came from Libnah."
    },
    {
      "verse": "19",
      "text": "Zedekiah did things that the Lord said were evil, as Jehoiakim had done."
    },
    {
      "verse": "20",
      "text": "All this trouble happened to Jerusalem and to Judah because the Lord was very angry with them. In the end, the Lord sent them away from himself. This is what happened when King Zedekiah turned against the king of Babylon."
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "Nebuchadnezzar, the king of Babylon, marched with all his army to attack Jerusalem. He arrived on the 10th day of the 10th month, in the 9th year when Zedekiah had ruled Judah. His soldiers made their camp all around the city. They built heaps of earth all around Jerusalem's walls."
    },
    {
      "verse": "2",
      "text": "Babylon's army stayed around the city until the 11th year that Zedekiah had been king."
    },
    {
      "verse": "3",
      "text": "By the 9th day of the 4th month, there was a very bad famine in the city. There was no food for the people to eat."
    },
    {
      "verse": "4",
      "text": "Then Babylon's army broke down Jerusalem's wall so that they could go into the city. Their soldiers were all around the city. So the king of Judah and all his army tried to escape in the night. They went through the gate that was near the king's garden. The path went between the two walls of the city. They ran towards the Jordan Valley."
    },
    {
      "verse": "5",
      "text": "But the soldiers of Babylon's army chased after the king. They caught him on the flat land near Jericho. All King Zedekiah's soldiers ran away from him in many directions."
    },
    {
      "verse": "6",
      "text": "Babylon's soldiers took hold of King Zedekiah. They took him to King Nebuchadnezzar at Riblah. Nebuchadnezzar decided how to punish Zedekiah."
    },
    {
      "verse": "7",
      "text": "They killed all Zedekiah's sons as their punishment, while Zedekiah watched. Then they cut out Zedekiah's eyes to make him blind. They tied him with chains and they took him to Babylon."
    },
    {
      "verse": "8",
      "text": "King Nebuchadnezzar had an officer whose name was Nebuzaradan. He was the captain of the king's royal guards. Nebuzaradan came to Jerusalem when Nebuchadnezzar had ruled Babylon for 19 years. It was on the 7th day of the 5th month."
    },
    {
      "verse": "9",
      "text": "Nebuzaradan destroyed the Lord's temple, the king's palace and all the other houses in Jerusalem. He burned them all with fire, so that he destroyed every important building in the city."
    },
    {
      "verse": "10",
      "text": "Then Nebuzaradan commanded his whole army to knock down the walls around Jerusalem."
    },
    {
      "verse": "11",
      "text": "Captain Nebuzaradan sent away as prisoners all the people who remained in Jerusalem. He also sent away those people who had agreed to serve the king of Babylon and the workers who were still there."
    },
    {
      "verse": "12",
      "text": "But Nebuzaradan let some of the poorest people stay there. He gave them vineyards and fields to work in."
    },
    {
      "verse": "13",
      "text": "The soldiers from Babylon broke the two bronze pillars that were in the Lord's temple. They also broke the carts which carried the buckets for water and the large bath called ‘the Sea’. They carried all the bronze pieces away to Babylon."
    },
    {
      "verse": "14",
      "text": "They also took away the pots, the spades, the small tools for the lamps, and the dishes. They took all the bronze tools that the priests used in the temple."
    },
    {
      "verse": "15",
      "text": "Nebuzaradan also took away the baskets that carried hot coals and the bowls for water. He took away everything that was made from gold or silver."
    },
    {
      "verse": "16",
      "text": "The bronze from the things that King Solomon had made for the Lord's temple was very heavy. They included the two bronze pillars, the large bath called ‘the Sea’ and the carts which carried the buckets for water. The bronze from all these things was more than they could weigh."
    },
    {
      "verse": "17",
      "text": "metres high. The bronze piece on the top of one pillar was more than 1 metre high. It had rows of chains with images of pomegranates made from bronze all around it. The other pillar, with its rows of chains and pomegranates, was the same."
    },
    {
      "verse": "18",
      "text": "Captain Nebuzaradan took hold of these people: Seraiah, the leader of the priests, Zephaniah, the next most important priest, and the three temple guards."
    },
    {
      "verse": "19",
      "text": "He also took hold of these people who remained in Jerusalem: The palace officer with authority over the soldiers, five of the king's advisors, the army secretary who took men to join the army, and 60 other people of Judah who were in the city."
    },
    {
      "verse": "20",
      "text": "Nebuzaradan took hold of all those people. He brought them to the king of Babylon at Riblah, in the Hamath region. That was how Judah's people went into exile, away from their own land."
    },
    {
      "verse": "21",
      "text": "There, at Riblah, the king of Babylon commanded his soldiers to punish them all with death. That was how Judah's people went into exile, away from their own land."
    },
    {
      "verse": "22",
      "text": "King Nebuchadnezzar of Babylon chose Gedaliah, to have authority to rule the people who were still in Judah. Gedaliah was the son of Ahikam and the grandson of Shaphan."
    },
    {
      "verse": "23",
      "text": "The officers of Judah's army and their men heard news that the king of Babylon had chosen Gedaliah to be the ruler of Judah. So they went to meet Gedaliah at Mizpah. The army officers were: Nethaniah's son Ishmael, Kareah's son Johanan, Seraiah, the son of Tanhumeth, who came from Netophah, and Jaazaniah, whose father came from Maakah."
    },
    {
      "verse": "24",
      "text": "Gedaliah promised that he would not hurt these officers or the men who were with them. He said to them, ‘Do not be afraid to serve the soldiers from Babylon. Make your homes here in our land, but agree to serve the king of Babylon. If you do that, you will be successful. ’"
    },
    {
      "verse": "25",
      "text": "But in the seventh month of that year, Ishmael went to Mizpah with ten of his men. Ishmael was the son of Nethaniah and the grandson of Elishama, who belonged to the king's family. They murdered Gedaliah, and the other men who were with him in Mizpah. Some of those men were from Judah and some of them were from Babylon."
    },
    {
      "verse": "26",
      "text": "When that happened, all the people of Judah ran away to Egypt. They included the army officers, as well as ordinary people and important people. They were all afraid that the people of Babylon would come to punish them."
    },
    {
      "verse": "27",
      "text": "years after King Jehoiachin of Judah had gone as a prisoner to Babylon, Evil-Merodach became the king of Babylon. On the 27th day of the 12th month, he took Jehoiachin out from his prison so that he became free."
    },
    {
      "verse": "28",
      "text": "King Evil-Merodach spoke in a kind way to Jehoiachin. He gave him more honour than the other kings who were with him in Babylon."
    },
    {
      "verse": "29",
      "text": "Jehoiachin no longer had to wear the clothes of a prisoner. Every day until he died, he ate a meal at the king's table in Babylon."
    },
    {
      "verse": "30",
      "text": "The king of Babylon gave Jehoiachin everything that he needed each day for the rest of his life."
    }
  ]
};