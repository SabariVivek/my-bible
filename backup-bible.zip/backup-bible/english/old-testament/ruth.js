module.exports = {
  "1": [
    {
      "verse": "3",
      "text": "Elimelech died while they were living in Moab. Naomi and her two sons remained there alone."
    },
    {
      "verse": "4",
      "text": "Then Naomi's sons married women from Moab. Mahlon married a woman called Ruth. Kilion married a woman called Orpah."
    },
    {
      "verse": "5",
      "text": "After they had all lived in Moab for about ten years, both Mahlon and Kilion died. Now Naomi was completely alone, without her husband or her sons."
    },
    {
      "verse": "6",
      "text": "Naomi received news from Judah that the Lord had helped his people. There was now enough food in Judah again. So Naomi decided to leave Moab and return to Judah with Ruth and Orpah."
    },
    {
      "verse": "7",
      "text": "Naomi and her sons' wives left their home in Moab. They began to travel together on the way back to Judah."
    },
    {
      "verse": "8",
      "text": "On the way, Naomi said to Ruth and Orpah, ‘Listen! You should return to your mothers' homes in Moab and stay there. Your husbands are dead now. You have been kind to them and to me. I pray that the Lord will be as kind to you."
    },
    {
      "verse": "9",
      "text": "I also pray that God will give to each of you another husband and a new home. ’ Naomi kissed them and said ‘goodbye’. Ruth and Orpah began to weep loudly."
    },
    {
      "verse": "10",
      "text": "They said to Naomi, ‘No! We will go with you to live with your people. ’"
    },
    {
      "verse": "11",
      "text": "But Naomi said, ‘My daughters, you should return to your own country. You should not choose to come back to Judah with me. I will not give birth to any more sons for you to marry them."
    },
    {
      "verse": "12",
      "text": "Return to your own country, my daughters. I am too old to marry another husband. Even if I did marry a man immediately, when might I give birth to sons?"
    },
    {
      "verse": "13",
      "text": "I am sure that you do not want to wait until they are old enough for you to marry them! Would you wait all that time and not marry anyone else? So, my daughters, you must not return to Judah with me. You should not have to share my pain. The Lord has turned against me. ’"
    },
    {
      "verse": "14",
      "text": "Ruth and Orpah wept loudly again. Orpah kissed Naomi and she said ‘goodbye’. But Ruth would not leave Naomi. She held on to her."
    },
    {
      "verse": "15",
      "text": "Naomi said to Ruth, ‘Look! Orpah has returned to her family. She has returned to serve the gods of Moab. Go back home with her. ’"
    },
    {
      "verse": "16",
      "text": "Ruth said to Naomi, ‘Do not say that I must leave you. I will go with you, wherever you go. I will live wherever you live. You belong to Israel's people. I will belong to them too. Your God will be my God."
    },
    {
      "verse": "17",
      "text": "I will die in the same place that you die. That is where people will bury me. I will stay beside you until death makes us separate. If I ever leave you, the Lord should punish me. ’"
    },
    {
      "verse": "18",
      "text": "Then Naomi understood that Ruth would not agree to return to her own country. So she stopped saying that Ruth should leave her."
    },
    {
      "verse": "19",
      "text": "Naomi and Ruth travelled together to Bethlehem. When they arrived there, the people were very surprised. The women from the town said, ‘Is this really Naomi? ’"
    },
    {
      "verse": "20",
      "text": "Naomi said to them, ‘Do not call me Naomi. Call me Mara, instead. The Almighty God has made my life very sad."
    },
    {
      "verse": "21",
      "text": "I left here with everything that I needed. Now the Lord has brought me back here with nothing. The Almighty Lord has turned against me, so that I have suffered. It is not right for you to call me Naomi. ’"
    },
    {
      "verse": "22",
      "text": "That is how Naomi returned from Moab with Ruth. Ruth was from Moab. She was the wife of Naomi's son Mahlon. Naomi and Ruth arrived in Bethlehem when the harvest of barley was beginning."
    },
    {
      "verse": "1",
      "text": "There was a time when judges ruled Israel. During that time there was a famine in Judah. A man who lived in Bethlehem, in Judah, had a wife and two sons. His name was Elimelech."
    },
    {
      "verse": "2",
      "text": "Elimelech's wife was called Naomi, and his sons were called Mahlon and Kilion. They were from Ephrathah's clan. Because there was not enough food in Judah, Elimelech and his family left Bethlehem. They went to live as strangers in Moab."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Boaz was a rich and important man who lived in Bethlehem. He was from the family of Naomi's husband, Elimelech."
    },
    {
      "verse": "2",
      "text": "One day, Ruth, the woman from Moab, said to Naomi, ‘Let me go to the fields to pick up some grain from the harvest. I will walk behind anyone who lets me do that. ’ Naomi said, ‘Yes, my daughter, go and do that. ’"
    },
    {
      "verse": "3",
      "text": "So Ruth went to the fields. She began to pick up the grains of barley that the men dropped on the ground. It happened that she was in part of a field that belonged to Boaz. Boaz was from Elimelech's clan."
    },
    {
      "verse": "4",
      "text": "Just then, Boaz arrived from Bethlehem town. He said ‘hello’ to the workers. ‘I pray that the Lord will help you, ’ he said. The men replied, ‘We pray that the Lord will bless you! ’"
    },
    {
      "verse": "5",
      "text": "Boaz asked the leader of his workers, ‘Who is that young woman? Which family does she belong to? ’"
    },
    {
      "verse": "6",
      "text": "The man said, ‘She is that young woman from Moab, who returned from Moab with Naomi."
    },
    {
      "verse": "7",
      "text": "She asked me, “Please let me walk behind your workers. Then I can pick up the grains of barley that they leave on the ground. ” She has worked very hard in the field since she arrived this morning. She only had a short rest in the hut. ’"
    },
    {
      "verse": "8",
      "text": "So Boaz said to Ruth, ‘Young woman, listen to me. Do not go and pick up grains of barley in any other field. Stay here in this field and work beside my servant girls."
    },
    {
      "verse": "9",
      "text": "Watch carefully where the men are working. Then follow behind the other women. I have told the male workers not to touch you. Whenever you are thirsty, go and drink water from the jars. My servants fill those jars with water to drink. ’"
    },
    {
      "verse": "10",
      "text": "Ruth went down on her knees with her head towards the ground in front of Boaz. She said, ‘I am a foreign woman. So why do you choose to be so kind to me? Why are you taking care of me? ’"
    },
    {
      "verse": "11",
      "text": "Boaz replied, ‘People have told me all about you. When your husband died, you helped Naomi very much. You chose to leave your father, your mother and your country. You came here to live with people who were strangers to you."
    },
    {
      "verse": "12",
      "text": "You have done many good things. So I pray that the Lord will do good things for you in return. You have come here to be safe with the Lord, who is Israel's God. I pray that he will bless you. ’"
    },
    {
      "verse": "13",
      "text": "Ruth said, ‘Thank you, sir. You are being very kind to me. Your words cause me to feel happy and strong. I am not even as important as one of your servant girls, but you have been kind to me. ’"
    },
    {
      "verse": "14",
      "text": "When it was time to eat a meal, Boaz said to Ruth, ‘Come here and eat with us. Take some bread and mix it with the wine. ’ So Ruth sat down to eat with the workers. Boaz gave her some grain that someone had cooked. She ate all that she wanted, and she still had some with her."
    },
    {
      "verse": "15",
      "text": "After the meal, Ruth returned to work in the field. Boaz said to his workers, ‘Let her pick up grains anywhere, even near the heaps of barley that you have cut down. Do not chase her away."
    },
    {
      "verse": "16",
      "text": "You should also pull out some barley and drop it for her to pick up. Do not be angry with her. ’"
    },
    {
      "verse": "17",
      "text": "Ruth picked up grains in Boaz's field until evening. Then she hit the grains with a stick so that the seeds came out. The grains of barley that she took home filled a large basket."
    },
    {
      "verse": "18",
      "text": "She carried the barley back to Naomi's home in the town. Naomi saw how much Ruth had picked up. Ruth also took the grains that she did not eat at the meal and she gave them to Naomi."
    },
    {
      "verse": "19",
      "text": "Naomi asked Ruth, ‘Where did you work today, to pick up all this barley? I want God to bless the man who was so kind to you. ’ So Ruth told Naomi about the man whose field she had worked in. She said, ‘The man that I worked with today is called Boaz. ’"
    },
    {
      "verse": "20",
      "text": "Naomi said to Ruth, ‘He has been kind to us! He has thought about our husbands who have died and he has helped us who are still alive. I pray that the Lord will bless him in return. That man is our relative. He is one of our family-redeemers. ’"
    },
    {
      "verse": "21",
      "text": "Then Ruth said, ‘Boaz even said to me, “Stay with my workers until they have finished the work in my fields. ” ’"
    },
    {
      "verse": "22",
      "text": "Naomi said to Ruth, ‘Yes, my daughter, it will be good for you to work beside the young women in his fields. You will be safe there, but the workers in another field might hurt you. ’"
    },
    {
      "verse": "23",
      "text": "So Ruth worked beside Boaz's women workers until they finished the harvest of barley and wheat. She continued to live with Naomi."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "One day, Naomi said to Ruth, ‘My daughter, I must find a home for you. There you will have everything that you need."
    },
    {
      "verse": "2",
      "text": "You have worked with Boaz's women workers, and he is our relative. Tonight, he will be at the threshing floor where he prepares the barley seeds."
    },
    {
      "verse": "3",
      "text": "So wash yourself carefully. Put some perfume on yourself. Put on your best clothes. Then go down to the threshing floor. Do not let Boaz know that you are there. Wait quietly until he has finished his food and drink."
    },
    {
      "verse": "4",
      "text": "After that, he will lie down to sleep. Then you will see where he is lying. Go and lift the cloth from over his feet. Lie down there. Then he will tell you what you should do. ’"
    },
    {
      "verse": "5",
      "text": "Ruth said, ‘I will do what you have said to me. ’"
    },
    {
      "verse": "6",
      "text": "So she went down to the threshing floor. She did everything that Naomi had told her to do."
    },
    {
      "verse": "7",
      "text": "Boaz felt very happy when he had finished his food and drink. He lay down next to the heap of barley seeds. Ruth went to him very quietly. She lifted the cloth that covered his feet. Then she lay down there."
    },
    {
      "verse": "8",
      "text": "In the middle of the night, something caused Boaz to wake up suddenly. When he turned over, he saw a woman who was lying there at his feet!"
    },
    {
      "verse": "9",
      "text": "He asked, ‘Who are you? ’ Ruth replied, ‘I am your servant, Ruth. You are our family-redeemer, so please cover me with the corner of your cloth. ’"
    },
    {
      "verse": "10",
      "text": "Boaz replied, ‘Young woman, I pray that the Lord will bless you. You have already been very kind to Naomi. Now you have been even more kind to me. You have not tried to marry a man who is younger than me, whether he is rich or poor."
    },
    {
      "verse": "11",
      "text": "So, young woman, do not be afraid. All the people in this town know that you are a good woman. I will do everything for you that you have asked me to do."
    },
    {
      "verse": "12",
      "text": "It is true that I am a family-redeemer for your family. But there is another relative who is nearer to your family than I am."
    },
    {
      "verse": "13",
      "text": "Stay here for this night. In the morning, we will see what to do. If this relative wants to take care of you, let him do it. If he does not agree, then I will do it. As surely as the Lord lives, I will do it. So just lie here until the morning. ’"
    },
    {
      "verse": "14",
      "text": "So Ruth lay beside Boaz's feet until morning arrived. Then she got up before anyone could see her. Boaz said to her, ‘Nobody must know that a woman came here to the threshing floor. ’"
    },
    {
      "verse": "15",
      "text": "He said to Ruth, ‘Bring me the coat that you are wearing. ’ She brought the coat to him. Then Boaz poured six bowls of barley seeds onto it. He tied it together and put it on her shoulder. Later, he returned to the town."
    },
    {
      "verse": "16",
      "text": "When Ruth returned home to Naomi, Naomi asked her, ‘My daughter, what happened last night? ’ Then Ruth told her everything that Boaz had done for her."
    },
    {
      "verse": "17",
      "text": "She said to Naomi, ‘He also gave me all this barley. He said, “Do not return to Naomi with nothing to give to her. ” ’"
    },
    {
      "verse": "18",
      "text": "Naomi said, ‘My daughter, you must be patient. We must wait to see what will happen. Boaz will surely do what he needs to do today. ’"
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "In the morning, Boaz went to the gate of the town and he sat down there. Later, the family-redeemer that Boaz had talked about to Ruth came there. Boaz said to him, ‘Come here, my friend, and sit down. ’ So the man went to sit with Boaz."
    },
    {
      "verse": "2",
      "text": "Boaz chose ten of the town's leaders and he said to them, ‘Come and sit here. ’ So they sat down."
    },
    {
      "verse": "3",
      "text": "Then Boaz said to the family-redeemer, ‘Naomi has returned from Moab. She wants to sell the piece of land that belonged to our relative, Elimelech."
    },
    {
      "verse": "4",
      "text": "I thought that I must tell you about this, in front of the leaders of our town. Tell us if you will buy this land from Naomi, so that all the people who sit here know what you decide. If you want to buy it, then you should buy it. If you do not want to buy it, then you must tell me. Then I will know what to do. You are the person who must decide. If you do not choose to buy the land, then I can buy it. ’ The relative said, ‘I will buy it. ’"
    },
    {
      "verse": "5",
      "text": "Then Boaz said, ‘You should also know this: When you buy the land from Naomi, you also have to marry the Moabite woman, Ruth. She is the widow of Elimelech's son. She will give birth to your children and Elimelech's land will continue to belong to his family. ’"
    },
    {
      "verse": "6",
      "text": "When Boaz said that, the relative replied, ‘If that is true, I cannot buy the land. It would not belong to my own children when I die. You may buy the land instead of me. I cannot buy it myself. ’"
    },
    {
      "verse": "7",
      "text": "In Israel at this time, when somebody agreed to sell land, he removed his shoe. He gave it to the man who was buying the land. Then everyone could see that they both agreed. They could not change their minds."
    },
    {
      "verse": "8",
      "text": "So the relative said to Boaz, ‘You may buy the land. ’ When he said that, he removed his shoe."
    },
    {
      "verse": "9",
      "text": "Boaz said to the town's leaders and to all the people there, ‘You have all seen today that I have bought the land from Naomi. I have bought all the land that belonged to Elimelech, Kilion and Mahlon."
    },
    {
      "verse": "10",
      "text": "I will also marry Ruth, who came here from Moab. She was Mahlon's wife. In that way, the land will still belong to his family. Ruth's descendants will still have his family's name. His family will continue to belong to this town where he lived. Today you have seen that this is what we have agreed together. ’"
    },
    {
      "verse": "11",
      "text": "Then all the leaders and the other people at the gate said, ‘We have seen that this is true. We pray that the Lord will bless the woman who is coming into your home as your wife. We pray that he will bless her as he blessed Rachel and Leah. They gave birth to many children for the family of Israel. We pray that you will become a rich man in Ephrathah's clan. And we pray that you will become famous in Bethlehem town."
    },
    {
      "verse": "12",
      "text": "We pray that this woman will give birth to many children for you. Then the Lord will give you many descendants, so that you have a large family. We pray that your family will be like the family of Perez, who was the son of Judah and his wife, Tamar. ’"
    },
    {
      "verse": "13",
      "text": "So Boaz married Ruth. He lived with her as his wife. The Lord blessed her so that she became pregnant. She gave birth to a son."
    },
    {
      "verse": "14",
      "text": "The women of Bethlehem said to Naomi, ‘We praise the Lord! Today, he has given to you a relative to take care of you! We pray that the child will become famous everywhere in Israel!"
    },
    {
      "verse": "15",
      "text": "He will help you to feel young again. He will take care of you when you are old. Your son's wife, Ruth, has given birth to this boy. She loves you and she has helped you more than seven sons could ever do. ’"
    },
    {
      "verse": "16",
      "text": "Naomi took the child and she held him near to her. She took care of him as if he was her own son."
    },
    {
      "verse": "17",
      "text": "The women who lived there said, ‘Now Naomi has a son again! ’ They called the boy Obed. He became the father of Jesse, who became the father of David."
    },
    {
      "verse": "18",
      "text": "These are the descendants of Perez: Perez was the father of Hezron."
    },
    {
      "verse": "19",
      "text": "Hezron was the father of Ram. Ram was the father of Amminadab."
    },
    {
      "verse": "20",
      "text": "Amminadab was the father of Nahshon. Nahshon was the father of Salmon."
    },
    {
      "verse": "21",
      "text": "Salmon was the father of Boaz. Boaz was the father of Obed."
    },
    {
      "verse": "22",
      "text": "Obed was the father of Jesse. Jesse was the father of David."
    }
  ]
};