module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "In the beginning, God made the heavens and the earth."
    },
    {
      "verse": "2",
      "text": "The earth was without shape and it was empty. Deep water covered the earth and everywhere was dark. The Spirit of God moved above the water."
    },
    {
      "verse": "3",
      "text": "God said, ‘There will be light! ’And there was light. And there was light."
    },
    {
      "verse": "4",
      "text": "God saw that the light was good. He caused the light and the dark to be separate. He caused the light and the dark to be separate."
    },
    {
      "verse": "5",
      "text": "God called the light ‘day’. He called the dark ‘night’. Evening passed and then it was morning. That was the first day. Evening passed and then it was morning. That was the first day."
    },
    {
      "verse": "6",
      "text": "Then God said, ‘A wide space will appear between the waters. So the waters will be in two separate places. ’"
    },
    {
      "verse": "7",
      "text": "So God made this wide space. He made the water under the space separate from the water that was above it. What God said happened."
    },
    {
      "verse": "8",
      "text": "God called the wide space ‘sky’. Evening passed and then it was morning. That was the second day. Evening passed and then it was morning. That was the second day."
    },
    {
      "verse": "9",
      "text": "God said, ‘The water that is under the sky will come together in one place. Then dry ground will appear. ’And what God said happened. And what God said happened."
    },
    {
      "verse": "10",
      "text": "God called the dry ground ‘land’. He called the water that had come together ‘sea’. God looked at what he had made. He saw that it was good. God looked at what he had made. He saw that it was good."
    },
    {
      "verse": "11",
      "text": "Then God said, ‘The land will cause plants to grow. There will be plants with their seeds and trees with their fruits. Each kind of plant and tree will have its own seeds and fruits. ’And what God said happened. And what God said happened."
    },
    {
      "verse": "12",
      "text": "All kinds of plants and trees began to grow in the ground. The plants made seeds. The trees made fruits with seeds in them. Each plant made its own kind of seeds. God looked at what he had made. He saw that it was good. God looked at what he had made. He saw that it was good."
    },
    {
      "verse": "13",
      "text": "Evening passed and then it was morning. That was the third day. That was the third day."
    },
    {
      "verse": "14",
      "text": "God said, ‘There will be lights all across the sky. They will make the day different from the night. They will show the seasons, days and years. And what God said happened."
    },
    {
      "verse": "15",
      "text": "The lights in the sky will give light to the earth. ’And what God said happened."
    },
    {
      "verse": "16",
      "text": "God made two great lights. The brighter light ruled over the day. The less bright light ruled over the night. God also made the stars."
    },
    {
      "verse": "17",
      "text": "God put all these lights in the sky to shine their light on the earth."
    },
    {
      "verse": "18",
      "text": "They were to rule over the day and night. They were to make the time of light separate from the time of dark. God looked at what he had made. He saw that it was good. God looked at what he had made. He saw that it was good."
    },
    {
      "verse": "19",
      "text": "Evening passed and then it was morning. That was the fourth day. That was the fourth day."
    },
    {
      "verse": "20",
      "text": "God said, ‘The waters will become full with many living things. Birds will appear and fly above the earth, all across the sky. ’"
    },
    {
      "verse": "21",
      "text": "God made big animals to live in the sea. He made every different kind of living thing that filled the sea. He made every different kind of bird to fly in the sky. God looked at what he had made. He saw that it was good. God looked at what he had made. He saw that it was good."
    },
    {
      "verse": "22",
      "text": "God blessed the animals and the birds. He said to them, ‘Give birth to many young ones, so that you grow in number. Fill all the water in the seas. The birds also should become very many, all across the earth. ’"
    },
    {
      "verse": "23",
      "text": "Evening passed and then it was morning. That was the fifth day. That was the fifth day."
    },
    {
      "verse": "24",
      "text": "God said, ‘Different kinds of animals will now appear on the land. There will be farm animals and wild animals. There will also be other small animals that move along the ground. There will be many kinds of animals and each kind will be different. ’And what God said happened. And what God said happened."
    },
    {
      "verse": "25",
      "text": "God made the different kinds of wild animals and the different kinds of farm animals. He made all the different kinds of animals that move along the ground. God looked at what he had made. He saw that it was good. God looked at what he had made. He saw that it was good."
    },
    {
      "verse": "26",
      "text": "Then God said, ‘We will make humans so that they are very much like us. They will rule over the fish in the sea and over the birds in the sky. They will rule over the farm animals. They will rule over the whole earth and all the animals that move along the ground. ’"
    },
    {
      "verse": "27",
      "text": "God made humans. He made them to be like himself. He made some of them males and some of them females. He made them to be like himself. He made some of them males and some of them females."
    },
    {
      "verse": "28",
      "text": "God blessed them. He said to them, ‘Give birth to children. Grow in number. Fill the earth and rule over it. Rule over the fish in the sea. Rule over the birds in the sky. Rule over every different kind of living animal that moves along the ground. ’"
    },
    {
      "verse": "29",
      "text": "Then God said, ‘Listen! I now give to you every plant on the earth as your food. I give you every plant that has seeds in it. I give you every tree that has fruit with a seed in it. I give them to you for your food."
    },
    {
      "verse": "30",
      "text": "I give to the animals green plants for their food. It will be food for all the animals on the earth, all the birds in the sky and all the animals that move along the ground. Everything that has life may eat every kind of green plant. ’And what God said happened. And what God said happened."
    },
    {
      "verse": "31",
      "text": "God looked at everything that he had made. He saw that it was very good. Evening passed. And then it was morning. That was the sixth day."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "In that way God finished making the heavens and the earth, and everything that was in them."
    },
    {
      "verse": "2",
      "text": "The seventh day came. Then God stopped the work that he had been doing. He had finished his work and he rested on the seventh day."
    },
    {
      "verse": "3",
      "text": "God blessed the seventh day. He made it a special day, because he had finished making everything. He did not work on that day."
    },
    {
      "verse": "4",
      "text": "This is what happened when God made the heavens and the earth. When the Lord God made the heavens and the earth,"
    },
    {
      "verse": "5",
      "text": "there were no plants or grasses growing on the earth. That was because the Lord God had not sent any rain on the earth. Also, there was nobody to dig the soil so that plants would grow."
    },
    {
      "verse": "6",
      "text": "But streams of water were coming up from the earth. The water made all the top of the ground wet."
    },
    {
      "verse": "7",
      "text": "Then the Lord God took some soil from the ground and he made a man. He breathed air into the nose of the man to give him life. So the man became alive."
    },
    {
      "verse": "8",
      "text": "The Lord God planted a garden. It was in the east, in a place called Eden. God took the man that he had made and he put him in the garden."
    },
    {
      "verse": "9",
      "text": "The Lord God made all kinds of trees grow from the ground there. The trees were beautiful to look at. The fruit from the trees was good for people to eat. In the middle of the garden were two special trees. One was the tree that gives life. The other was the tree that gives knowledge of what is good and what is evil."
    },
    {
      "verse": "10",
      "text": "A river began in Eden. It went through the garden and it gave water for the ground. After that, it became four separate rivers."
    },
    {
      "verse": "11",
      "text": "The name of the first river is the Pishon. It goes through the whole land of Havilah. There is gold in that land."
    },
    {
      "verse": "12",
      "text": "The gold there is very good. Bdellium and onyx stone are also in Havilah."
    },
    {
      "verse": "13",
      "text": "The name of the second river is the Gihon. It goes through the whole land of Cush."
    },
    {
      "verse": "14",
      "text": "The third river is called the Tigris. It goes along the east side of Assyria. The fourth river is called the Euphrates."
    },
    {
      "verse": "15",
      "text": "The Lord God took the man and he put him in the Garden of Eden. God wanted the man to work in the garden and to take care of it."
    },
    {
      "verse": "16",
      "text": "Then the Lord God told the man, ‘You may eat the fruit from any tree in the garden, as much as you like."
    },
    {
      "verse": "17",
      "text": "But you must not eat any fruit from the tree that gives knowledge of good and evil. If you do eat fruit from that tree, that day you will certainly die. ’"
    },
    {
      "verse": "18",
      "text": "Then the Lord God said, ‘It is not good for the man to live alone. I will make a helper who is right for him. ’"
    },
    {
      "verse": "19",
      "text": "The Lord God took soil from the ground and he made all the animals and birds. He brought them to the man. God wanted to know what names the man would call them. Whatever the man called each living thing, that became its name."
    },
    {
      "verse": "20",
      "text": "So the man gave names to the farm animals, to the birds in the sky and to all the other animals. But none of these animals was the right helper for the man."
    },
    {
      "verse": "21",
      "text": "So the Lord God caused the man to sleep. While the man was sleeping, God took a rib from the man. Then he closed up the place in his body and he covered it again."
    },
    {
      "verse": "22",
      "text": "The Lord God used the man's rib to make a woman. He brought the woman to the man."
    },
    {
      "verse": "23",
      "text": "Then the man said, ‘Finally, this is someone who is right for me. She has bones that are taken from my bones. Her body comes from my body. I will call her “woman” because God used me, a man, to make her. ’"
    },
    {
      "verse": "24",
      "text": "Because of this, when a man marries, he leaves his father and his mother. Instead, God joins the man and his wife together. The two people become as one body."
    },
    {
      "verse": "25",
      "text": "The man and his wife were not wearing any clothes. But they did not feel ashamed."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "The Lord God made many wild animals. But the snake was the most clever of them all. The snake asked the woman, ‘Did God say, “You must not eat the fruit from any tree in the garden”? Is that really true? ’"
    },
    {
      "verse": "2",
      "text": "The woman replied, ‘We may eat fruit from the trees in the garden."
    },
    {
      "verse": "3",
      "text": "But God said, “You must not eat fruit from the tree that is in the middle of the garden. You must not even touch it. If you do that, you will die. ” ’"
    },
    {
      "verse": "4",
      "text": "Then the snake said to the woman, ‘No, you will not die."
    },
    {
      "verse": "5",
      "text": "God knows that when you eat the fruit from this tree, you will understand things. You will become like God himself. You will know about good things and evil things. ’"
    },
    {
      "verse": "6",
      "text": "The woman looked at the fruit on the tree. She saw that it would be good to eat, and it was beautiful to look at. She wanted to eat it because it would make her become wise. So she took some fruit and she ate it. Then she gave some of the fruit to her husband who was with her. He also ate it."
    },
    {
      "verse": "7",
      "text": "Then they understood what they had done. They realized that they were not wearing any clothes. So they took some leaves from fig trees. They tied them together to cover their bodies."
    },
    {
      "verse": "8",
      "text": "In the evening there was a nice cool wind. The Lord God walked in the garden. The man and the woman heard the sound of the Lord God. They hid themselves behind some trees, so that God would not see them."
    },
    {
      "verse": "9",
      "text": "The Lord God called out to the man. He said to him, ‘Where are you? ’"
    },
    {
      "verse": "10",
      "text": "The man replied, ‘I heard you in the garden. I was afraid because I had no clothes. So I hid myself from you. ’"
    },
    {
      "verse": "11",
      "text": "The Lord God said, ‘Who told you that you had no clothes? Have you eaten fruit from the tree that I said you must not eat? ’"
    },
    {
      "verse": "12",
      "text": "The man said, ‘It was the woman that you put here with me. She gave me some fruit from the tree. So I ate it. ’"
    },
    {
      "verse": "13",
      "text": "Then the Lord God said to the woman, ‘Why have you done a thing like that? ’ The woman replied, ‘It was the snake. The snake deceived me with a lie. So I ate the fruit. ’"
    },
    {
      "verse": "14",
      "text": "The Lord God said to the snake, ‘Because you have done this, I will curse you. Among all the farm animals and wild animals, you are the one that I will curse. From now on, you will move across the ground on your stomach. You will eat dust from the ground. You will do this for your whole life. ‘Because you have done this, I will curse you. Among all the farm animals and wild animals, you are the one that I will curse. From now on, you will move across the ground on your stomach. You will eat dust from the ground. You will do this for your whole life."
    },
    {
      "verse": "15",
      "text": "I will cause you and the woman to become enemies. Your descendants and her descendants will always be enemies. One of her descendants will attack your head. You will attack his heel. ’ Your descendants and her descendants will always be enemies. One of her descendants will attack your head. You will attack his heel. ’"
    },
    {
      "verse": "16",
      "text": "God said to the woman, ‘I will cause you to have great pain when you give birth to children. You will want to please your husband. But he will rule over you as your master. ’"
    },
    {
      "verse": "17",
      "text": "Then God said to Adam, ‘You listened to your wife and you did what she said. You ate fruit from the tree after I told you, “You must not eat fruit from this tree. ” Because you did that, I will curse the ground. You will have to work very hard to make plants grow in it for your food. It will be like this for your whole life."
    },
    {
      "verse": "18",
      "text": "Thorn bushes and thistles will grow in the ground. But you will eat plants that grow in the fields."
    },
    {
      "verse": "19",
      "text": "You will have to work hard for a long time before you have any food to eat. You will do this for your whole life until you die. Then you will return into the ground. That is where you came from. I made you from the soil of the ground, and you will become soil again. ’"
    },
    {
      "verse": "20",
      "text": "Adam gave his wife a name. He called her Eve. This was because she would become the mother of all people."
    },
    {
      "verse": "21",
      "text": "The Lord God made clothes for Adam and Eve to wear. He used the skins from animals to make them."
    },
    {
      "verse": "22",
      "text": "The Lord God said, ‘The man has now become like one of us because he understands good and evil. So we must not let him take fruit from the tree that gives life. If he eats that fruit, he will live for ever. ’"
    },
    {
      "verse": "23",
      "text": "So the Lord God sent Adam out of the Garden of Eden. To get his food, Adam had to dig the ground that God had used to make him."
    },
    {
      "verse": "24",
      "text": "Then God put cherubs to be guards for the garden. God put them on the east side of the garden. There was also a sword of fire that moved quickly from side to side. As a result, nobody could go near to the tree that gives life."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Adam had sex with his wife, Eve. She became pregnant. She gave birth to Cain. She said, ‘With the Lord's help, I have given birth to a son. ’"
    },
    {
      "verse": "2",
      "text": "Some time later, Eve gave birth to Cain's brother. She called him Abel. When they had grown to become men, Abel took care of sheep. Cain worked on the land as a farmer."
    },
    {
      "verse": "3",
      "text": "One day, it was time for the harvest. Cain brought to the Lord some of his crops as an offering."
    },
    {
      "verse": "4",
      "text": "But Abel brought to God some of the first lambs that his sheep had given birth to. He brought pieces of fat from the best of his lambs to offer them to God. Abel and his gift pleased the Lord."
    },
    {
      "verse": "5",
      "text": "But God was not pleased with Cain and his gift. So Cain became very angry. His face looked sad."
    },
    {
      "verse": "6",
      "text": "Then the Lord said to Cain, ‘Why are you angry? Why do you look sad?"
    },
    {
      "verse": "7",
      "text": "If you do what is right, I will accept you. But if you do not do the right thing, sin will be very near to you. It will be like a wild animal at your door that is ready to eat you. But you must become its master. ’"
    },
    {
      "verse": "8",
      "text": "One day Cain said to his brother Abel, ‘We should go out to the fields. ’ While they were in the fields, Cain attacked his brother Abel. He killed Abel."
    },
    {
      "verse": "9",
      "text": "Then the Lord said to Cain, ‘Where is Abel, your brother? ’ Cain replied, ‘I do not know where he is. Must I always keep my brother safe? ’"
    },
    {
      "verse": "10",
      "text": "Then the Lord God said, ‘Why have you done this bad thing? Now your brother's blood is lying there on the ground. That is like his voice which is shouting to me for help."
    },
    {
      "verse": "11",
      "text": "The ground received your brother's blood when you killed him. As a result, the ground no longer accepts you. It has brought a curse on you."
    },
    {
      "verse": "12",
      "text": "When you work hard to dig the ground, no plants will grow in it for your food. You will travel from place to place. You will not have your own home. ’"
    },
    {
      "verse": "13",
      "text": "Cain said to the Lord, ‘That punishment is too much! It will give me too much pain."
    },
    {
      "verse": "14",
      "text": "Now you are making me leave my home here on the land. I will be far away from where you are. I will be a traveller without a home. If someone sees me, they will kill me. ’"
    },
    {
      "verse": "15",
      "text": "But the Lord said to Cain, ‘No! If anyone kills Cain, I will punish that person seven times more than I have punished you. ’Then the Lord put a special mark on Cain. This was to tell other people that they must not kill Cain. Then the Lord put a special mark on Cain. This was to tell other people that they must not kill Cain."
    },
    {
      "verse": "16",
      "text": "Cain went away from the Lord. He went to live in the land called Nod, which is east of Eden."
    },
    {
      "verse": "17",
      "text": "Cain had sex with his wife. She became pregnant and she gave birth to Enoch. Cain started to build a city. He called the city Enoch because that was his son's name."
    },
    {
      "verse": "18",
      "text": "Enoch became the father of Irad. Irad became the father of Mehujael. Mehujael became the father of Methushael. Methushael became the father of Lamech."
    },
    {
      "verse": "19",
      "text": "Lamech married two women. One was called Adah. The other was called Zillah."
    },
    {
      "verse": "20",
      "text": "Adah gave birth to Jabal. Jabal became the father of people who live in tents and they take care of animals."
    },
    {
      "verse": "21",
      "text": "Jabal had a brother called Jubal. Jubal became the father of people who make music with harps and flutes."
    },
    {
      "verse": "22",
      "text": "Zillah gave birth to a son. His name was Tubal-Cain. He used bronze and iron to make tools. Tubal-Cain had a sister. Her name was Naamah."
    },
    {
      "verse": "23",
      "text": "Lamech said to his two wives, ‘Adah and Zillah, listen to me! My wives, hear my words! A man attacked me, so I killed him. Yes, I killed a young man because he hurt me. ‘Adah and Zillah, listen to me! My wives, hear my words! A man attacked me, so I killed him. Yes, I killed a young man because he hurt me."
    },
    {
      "verse": "24",
      "text": "If someone kills Cain, God will punish that person seven times more. But if someone attacks me, I will punish that person 77 times more! ’ But if someone attacks me, I will punish that person 77 times more! ’"
    },
    {
      "verse": "25",
      "text": "Adam again had sex with his wife, Eve. She gave birth to another son. She called him Seth. Eve said, ‘God has given me another child to take the place of Abel, because Cain killed Abel. ’ At that time, people began to use the name of the Lord to worship him."
    },
    {
      "verse": "26",
      "text": "Later Seth had a son and he called him Enosh. At that time, people began to use the name of the Lord to worship him."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "This is the report about Adam and his family. When God made men and women, he made them like himself."
    },
    {
      "verse": "2",
      "text": "God made male and female people and he called them ‘human’. He blessed them."
    },
    {
      "verse": "3",
      "text": "years old, he had a son who was like him. Adam called him Seth."
    },
    {
      "verse": "4",
      "text": "After Seth was born, Adam lived for 800 years. During this time, he had other sons and daughters."
    },
    {
      "verse": "5",
      "text": "years old when he died."
    },
    {
      "verse": "6",
      "text": "years old, he had a son. He called him Enosh."
    },
    {
      "verse": "7",
      "text": "After Enosh was born, Seth lived for 807 years. During this time, he had other sons and daughters."
    },
    {
      "verse": "8",
      "text": "years old when he died."
    },
    {
      "verse": "9",
      "text": "years old, he had a son. He called him Kenan."
    },
    {
      "verse": "10",
      "text": "After Kenan was born, Enosh lived for 815 years. During this time, he had other sons and daughters."
    },
    {
      "verse": "11",
      "text": "years old when he died."
    },
    {
      "verse": "12",
      "text": "years old, he had a son. He called him Mahalalel."
    },
    {
      "verse": "13",
      "text": "After Mahalalel was born, Kenan lived for 840 years. During this time, he had other sons and daughters."
    },
    {
      "verse": "14",
      "text": "years old when he died."
    },
    {
      "verse": "15",
      "text": "years old, he had a son. He called him Jared."
    },
    {
      "verse": "16",
      "text": "After Jared was born, Mahalalel lived for 830 years. During this time, he had other sons and daughters."
    },
    {
      "verse": "17",
      "text": "years old when he died."
    },
    {
      "verse": "18",
      "text": "years old, he had a son. He called him Enoch."
    },
    {
      "verse": "19",
      "text": "After Enoch was born, Jared lived for 800 years. During this time, he had other sons and daughters."
    },
    {
      "verse": "20",
      "text": "years old when he died."
    },
    {
      "verse": "21",
      "text": "years old, he had a son. He called him Methuselah."
    },
    {
      "verse": "22",
      "text": "After Methuselah was born, Enoch lived as God wanted for 300 years. During this time, he had other sons and daughters."
    },
    {
      "verse": "23",
      "text": "years."
    },
    {
      "verse": "24",
      "text": "Enoch lived to please God all this time, then Enoch was not there any more. God took Enoch to be with him."
    },
    {
      "verse": "25",
      "text": "years old, he had a son. He called him Lamech."
    },
    {
      "verse": "26",
      "text": "After Lamech was born, Methuselah lived for 782 years. During this time, he had other sons and daughters."
    },
    {
      "verse": "27",
      "text": "years old when he died."
    },
    {
      "verse": "28",
      "text": "years old, he had a son."
    },
    {
      "verse": "29",
      "text": "He called his son Noah. Lamech said, ‘He will help us in our difficult work on the land. We have pain when we work on the land to get food. That is because the Lord God cursed the ground. ’"
    },
    {
      "verse": "30",
      "text": "After Noah was born, Lamech lived for 595 years. During this time, he had other sons and daughters."
    },
    {
      "verse": "31",
      "text": "years old when he died."
    },
    {
      "verse": "32",
      "text": "years old, he became the father of Shem, Ham and Japheth."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "People began to grow in number all over the earth. They gave birth to daughters."
    },
    {
      "verse": "2",
      "text": "The sons of God saw that the daughters of men were beautiful. They chose for themselves any of them that they wanted to become their wives."
    },
    {
      "verse": "3",
      "text": "The Lord said, ‘My Spirit will not give life to humans for ever. One day they will die. I will not let them live for more than 120 years. Then they will die. ’"
    },
    {
      "verse": "4",
      "text": "The Nephilites lived on the earth at that time, and for some time after that. During that time, the sons of God were having sex with the daughters of men, who gave birth to their children. The Nephilites were famous great men and fighters."
    },
    {
      "verse": "5",
      "text": "The Lord saw that men and women on the earth had become very bad. They thought only of evil things all the time."
    },
    {
      "verse": "6",
      "text": "The Lord was sorry that he had made humans and put them on the earth. He became very upset."
    },
    {
      "verse": "7",
      "text": "So the Lord said, ‘I made humans, but now I will destroy them. I will completely take them off the earth. As well as human people, I will also destroy the animals, the living things that move on the ground, and the birds. I am sorry that I made them. ’"
    },
    {
      "verse": "8",
      "text": "But as for Noah, the Lord was happy about him."
    },
    {
      "verse": "9",
      "text": "This is the report about Noah and his family. Noah was a good man. He was the only person at that time who lived in a completely right way. He stayed near to God in his life."
    },
    {
      "verse": "10",
      "text": "Noah became the father of Shem, Ham and Japheth."
    },
    {
      "verse": "11",
      "text": "God saw that everything on the earth had become spoiled. Everywhere, people were attacking each other."
    },
    {
      "verse": "12",
      "text": "God saw how much the earth had become spoiled. Everyone was doing bad things."
    },
    {
      "verse": "13",
      "text": "God said to Noah, ‘I will destroy everyone. That is what I have decided to do. Everywhere on the earth, people are attacking each other. Now I will destroy the people and also the earth."
    },
    {
      "verse": "14",
      "text": "So make a ship for yourself. Use wood from cypress trees to make it. The ship must have rooms in it. Cover the inside and the outside of the ship with tar."
    },
    {
      "verse": "15",
      "text": "This is how you will build the ship: It must be 150 metres long, 25 metres wide and 15 metres high."
    },
    {
      "verse": "16",
      "text": "Make a roof for the ship. Leave a space 45 centimetres high all round under the roof. Put a door in the side of the ship. Inside the ship, make three floors above each other."
    },
    {
      "verse": "17",
      "text": "I will cover the earth with deep water. I will destroy all living things, wherever they live. Everything that breathes will die."
    },
    {
      "verse": "18",
      "text": "But I will make a covenant with you, Noah. You will go into the ship. You will take your wife with you, and also your three sons and their wives."
    },
    {
      "verse": "19",
      "text": "You must also take two of every different kind of animal into the ship. One will be male and the other will be female. Then they will stay alive with you."
    },
    {
      "verse": "20",
      "text": "Bring two of every different kind of bird, two of every different animal and two of every different living thing that moves along the ground. All these will come to you. You will take care of them so that they will stay alive."
    },
    {
      "verse": "21",
      "text": "You must also take every different kind of food. That will be food for you and food for the animals. ’"
    },
    {
      "verse": "22",
      "text": "Noah obeyed God. He did everything that God had told him to do."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "Then the Lord said to Noah, ‘Go into the ship. Take your wife and family with you. I can see that you alone do what is right, among all the people on the earth."
    },
    {
      "verse": "2",
      "text": "Take seven of every different kind of clean animal. Take a male and a female together. Take two of every different kind of unclean animal. Take a male and a female together."
    },
    {
      "verse": "3",
      "text": "Take seven of every kind of bird. Take males and females. Do this so that they will give birth to young ones. Then each different kind of animal and bird will continue to live on the earth."
    },
    {
      "verse": "4",
      "text": "In seven days, I will cause rain to fall on the earth. It will rain for 40 days and 40 nights. In that way, I will destroy every living thing that I have made on the earth. ’"
    },
    {
      "verse": "5",
      "text": "Noah did everything that God told him to do."
    },
    {
      "verse": "6",
      "text": "years old when the deep water covered the earth."
    },
    {
      "verse": "7",
      "text": "Noah and his wife went into the ship. His sons and their wives also went in. They all went into the ship to be safe from the deep water."
    },
    {
      "verse": "8",
      "text": "Pairs of clean animals and unclean animals came to Noah in the ship. Also, pairs of birds and pairs of all the living things that move across the ground came to him."
    },
    {
      "verse": "9",
      "text": "Each pair was one male and one female. They all came to Noah in the ship. Everything happened as God had said to Noah."
    },
    {
      "verse": "10",
      "text": "After seven days had passed, God sent the deep water to cover the earth."
    },
    {
      "verse": "11",
      "text": "years old, on the 17th day of the second month, streams of water came up everywhere from below the earth. Also, the water in the heavens poured down on the earth."
    },
    {
      "verse": "12",
      "text": "days and 40 nights."
    },
    {
      "verse": "13",
      "text": "On the day that the rain began to fall, Noah and his wife went into the ship. Noah's three sons (Shem, Ham and Japheth) and their three wives also went in."
    },
    {
      "verse": "14",
      "text": "With them was every different kind of wild animal and every different kind of farm animal. They also had with them every kind of living thing that moves along the ground. Every different kind of bird and other flying things were there too."
    },
    {
      "verse": "15",
      "text": "Pairs of every kind of animal that lived came to Noah and went into the ship."
    },
    {
      "verse": "16",
      "text": "Each pair was one male and one female. This happened in the way that God had told Noah. When they were all in the ship, the Lord shut the door."
    },
    {
      "verse": "17",
      "text": "days, the water on the earth became deeper. The water lifted the ship high above the ground."
    },
    {
      "verse": "18",
      "text": "The water became even deeper and completely covered the earth. The ship went safely on top of the water."
    },
    {
      "verse": "19",
      "text": "More water came until it covered all the high mountains on the earth."
    },
    {
      "verse": "20",
      "text": "metres higher than the tops of the mountains."
    },
    {
      "verse": "21",
      "text": "As a result, everything that had lived on the earth now died. The birds, the farm animals and the wild animals died. Every living thing that moved across the ground died, and so did all the people."
    },
    {
      "verse": "22",
      "text": "Everything that lived on the dry land died. Nothing could breathe any more."
    },
    {
      "verse": "23",
      "text": "God destroyed everything that lived on the earth. He destroyed people, animals, living things that move across the ground, and birds. God removed them from the earth. Only Noah and his family, together with the animals that were in the ship, stayed alive."
    },
    {
      "verse": "24",
      "text": "days."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Then God thought of Noah, and all the wild animals and the farm animals that were with him in the ship. He caused a wind to blow over the earth. As a result, the water began to go down."
    },
    {
      "verse": "2",
      "text": "Streams of water stopped coming up from below the earth. Rain stopped coming down from the sky."
    },
    {
      "verse": "3",
      "text": "The deep water continued to go down for 150 days."
    },
    {
      "verse": "4",
      "text": "On the 17th day of the seventh month, the ship stopped on the ground. It was sitting on the top of Ararat mountains."
    },
    {
      "verse": "5",
      "text": "The water continued to go down until the tenth month. On the first day of the tenth month, the tops of the mountains appeared above the water."
    },
    {
      "verse": "6",
      "text": "more days, Noah opened a window in the ship."
    },
    {
      "verse": "7",
      "text": "He sent a raven to fly away. The raven flew away from the ship and then it returned. It continued to do this until the earth was dry."
    },
    {
      "verse": "8",
      "text": "Then Noah sent out a dove. He wanted to see if the water had gone away from the top of the ground."
    },
    {
      "verse": "9",
      "text": "But the dove could not find anywhere to stand. Water still covered all the ground. So it returned to Noah in the ship. Noah put out his hand and took the dove back into the ship."
    },
    {
      "verse": "10",
      "text": "He waited for seven days. Then he sent the dove out of the ship again."
    },
    {
      "verse": "11",
      "text": "The dove returned to Noah in the evening. It carried a fresh leaf from an olive tree in its mouth. Then Noah knew that the water had gone down."
    },
    {
      "verse": "12",
      "text": "He waited for seven more days. Then he sent the dove out again. This time, it did not return to Noah."
    },
    {
      "verse": "13",
      "text": "years old. On the first day of the first month, the water that had covered the earth was now gone. The ground had become dry. Noah made a hole in the roof of the ship and he looked around. He saw that the top of the ground was dry."
    },
    {
      "verse": "14",
      "text": "By the 27th day of the second month, the earth had become completely dry."
    },
    {
      "verse": "15",
      "text": "God said to Noah,"
    },
    {
      "verse": "16",
      "text": "‘Come out of the ship. Bring your wife, your sons and their wives with you."
    },
    {
      "verse": "17",
      "text": "Bring every different kind of living animal out of the ship. Bring out the birds, the animals, and the living things that move across the ground. Now they may give birth to young ones again. They can grow in number all over the earth. ’"
    },
    {
      "verse": "18",
      "text": "Noah went out of the ship, together with his wife, his sons and their wives."
    },
    {
      "verse": "19",
      "text": "All the living animals also went out of the ship. The birds and the living things that move across the ground all went out. Every different kind of animal came out of the ship, each of them in its own group."
    },
    {
      "verse": "20",
      "text": "Then Noah built an altar to make sacrifices to the Lord. He took one from each kind of clean animal and clean bird. He offered them to the Lord as sacrifices which he burned on the altar."
    },
    {
      "verse": "21",
      "text": "The Lord smelled the sacrifice and it made him happy. The Lord said to himself, ‘I will never curse the ground again because of the bad things that people do. From the time that they are children, they want to do bad things. But I will never again destroy everything that breathes, as I have done this time."
    },
    {
      "verse": "22",
      "text": "As long as the earth continues to be here, the time for people to plant seeds will come each year. The time for harvest will come each year. Times of cold and heat will always come. Summer and winter will always come. Day and night will never stop. ’"
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "God blessed Noah and his sons. He said to them, ‘Give birth to many children so that you become very many people. Your descendants will live all over the earth."
    },
    {
      "verse": "2",
      "text": "All the animals and all the birds will be afraid of you. You have authority over them. You also have authority over all the living things that move across the ground and all the fish in the sea."
    },
    {
      "verse": "3",
      "text": "You may now eat anything that lives and moves. Before, I gave you the green plants to eat. Now I give you everything to eat as your food."
    },
    {
      "verse": "4",
      "text": "But you must not eat meat that still has the blood of life in it."
    },
    {
      "verse": "5",
      "text": "If any person or animal kills a human, I will certainly punish them. Their punishment will be death."
    },
    {
      "verse": "6",
      "text": "God made people so that they were like himself. So if anyone kills a human, another human must kill him. So if anyone kills a human, another human must kill him."
    },
    {
      "verse": "7",
      "text": "But as for you, you should give birth to many children so that you become very many people. There will be many people and they will live all over the earth. ’"
    },
    {
      "verse": "8",
      "text": "God said to Noah and to his sons,"
    },
    {
      "verse": "9",
      "text": "‘I promise you that I will obey the covenant that I am making with you. I promise this to you and to all your descendants."
    },
    {
      "verse": "10",
      "text": "I also promise this to all the animals and birds that came out of the ship with you. That is everything that lives on the earth."
    },
    {
      "verse": "11",
      "text": "This is the covenant that I promise to keep: I will never cause water to destroy all living things on the earth again. Deep water will never again come again to destroy the earth. ’"
    },
    {
      "verse": "12",
      "text": "Then God said, ‘I will show you clearly that I have made this covenant with you, and with every living animal. I will keep this promise for ever, for as long as people live on the earth."
    },
    {
      "verse": "13",
      "text": "I have put my rainbow among the clouds in the sky. It will show you clearly that I have made this covenant with everything on the earth."
    },
    {
      "verse": "14",
      "text": "When I bring clouds over the earth, a rainbow will sometimes appear."
    },
    {
      "verse": "15",
      "text": "Then I will remember the covenant that I have made with you and with all the different kinds of living things. Never again will the water become so deep that it destroys everything that lives."
    },
    {
      "verse": "16",
      "text": "When I see the rainbow in the clouds, I will remember my covenant. It is a promise that I have made with every kind of living thing on the earth. ’"
    },
    {
      "verse": "17",
      "text": "Then God said to Noah, ‘The rainbow will show you that I will certainly keep my promise. I will keep my covenant that is between me and everything that lives on the earth. ’"
    },
    {
      "verse": "18",
      "text": "The names of Noah's sons were Shem, Ham and Japheth. They all came out of the ship with Noah. Ham later became the father of a son called Canaan."
    },
    {
      "verse": "19",
      "text": "All the people who live on the earth are descendants of Noah's three sons."
    },
    {
      "verse": "20",
      "text": "Noah was a farmer. He was the first person to plant vines."
    },
    {
      "verse": "21",
      "text": "He used the grapes to make wine. One day, he drank some of the wine and he became drunk. He lay inside his tent and he slept. He was not wearing any clothes."
    },
    {
      "verse": "22",
      "text": "Canaan's father, Ham, saw that Noah was not wearing any clothes. He went out of the tent. He told his two brothers what he had seen."
    },
    {
      "verse": "23",
      "text": "Then Shem and Japheth took Noah's coat and they put it between their shoulders. They walked into Noah's tent with their backs to Noah. In this way they covered their father with the coat. They looked away from their father so that they did not see him. They did this because Noah was not wearing any clothes."
    },
    {
      "verse": "24",
      "text": "Later, when he was no longer drunk with the wine, Noah woke up. He found out what his youngest son, Ham, had done."
    },
    {
      "verse": "25",
      "text": "He said, ‘I curse Canaan! He will become a slave that must serve his brothers. ’"
    },
    {
      "verse": "26",
      "text": "Noah also said, ‘I praise the Lord, the God of Shem! Let Canaan become Shem's slave!"
    },
    {
      "verse": "27",
      "text": "I pray that God will make the land of Japheth and his descendants grow bigger. I pray that the descendants of Japheth will share good things with Shem. I pray that Canaan will become Japheth's slave. ’"
    },
    {
      "verse": "28",
      "text": "years after God covered the earth with deep water."
    },
    {
      "verse": "29",
      "text": "In his whole life, Noah lived for 950 years. Then he died."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "This is the report about Noah's sons, Shem, Ham and Japheth, and their families. After the deep water went away, they all had children themselves. After the deep water went away, they all had children themselves."
    },
    {
      "verse": "2",
      "text": "These are the sons of Japheth: Gomer, Magog, Madai, Javan, Tubal, Meshech and Tiras."
    },
    {
      "verse": "3",
      "text": "These are the sons of Gomer: Ashkenaz, Riphath and Togarmah."
    },
    {
      "verse": "4",
      "text": "These are the sons of Javan: Elishah, Tarshish, the Kittim people and the Rodanim people."
    },
    {
      "verse": "5",
      "text": "These people lived by the sea. They lived in groups. Each group went to live in a different place. Each group spoke its own language."
    },
    {
      "verse": "6",
      "text": "These are the sons of Ham: Cush, Mizraim, Put and Canaan."
    },
    {
      "verse": "7",
      "text": "These are the sons of Cush: Seba, Havilah, Sabtah, Raamah and Sabteca. These are the sons of Raamah: Sheba and Dedan."
    },
    {
      "verse": "8",
      "text": "Cush was also the father of Nimrod. Nimrod became the first brave soldier in the world."
    },
    {
      "verse": "9",
      "text": "The Lord helped Nimrod to be a great hunter. That is why people say, ‘Like Nimrod, a great hunter that the Lord helped. ’"
    },
    {
      "verse": "10",
      "text": "The first of Nimrod's lands were Babylon, Erech, Akkad and Calneh, in Shinar."
    },
    {
      "verse": "11",
      "text": "From that land he went to Assyria. This is where he built Nineveh, Rehoboth-Ir and Calah."
    },
    {
      "verse": "12",
      "text": "He also built Resen. Resen is between Nineveh and Calah, which is a large city."
    },
    {
      "verse": "13",
      "text": "Mizraim was the ancestor of the Ludites, Anamites, Lehabites, Naphtuhites,"
    },
    {
      "verse": "14",
      "text": "Pathrusites, Kasluhites and Caphtorites. The Philistines were descendants of the Kasluhites."
    },
    {
      "verse": "15",
      "text": "Canaan was the father of Sidon, who was born first. Canaan was also the ancestor of the Hittites,"
    },
    {
      "verse": "16",
      "text": "Jebusites, Amorites, Girgashites,"
    },
    {
      "verse": "17",
      "text": "Hivites, Arkites, Sinites,"
    },
    {
      "verse": "18",
      "text": "Arvadites, Zemarites and Hamathites. After some time had passed, the Canaanite families separated to different places."
    },
    {
      "verse": "19",
      "text": "The land of Canaan went from Sidon to Gerar, as far as Gaza. It went to Sodom, Gomorrah, Admah and Zeboiim, as far as Lasha."
    },
    {
      "verse": "20",
      "text": "These are all descendants of Ham. They lived in groups in their own parts of the land. Each group spoke their own language."
    },
    {
      "verse": "21",
      "text": "Shem also had sons. Shem was Japheth's older brother. All the sons of Eber are descendants of Shem."
    },
    {
      "verse": "22",
      "text": "These are the sons of Shem: Elam, Asshur, Arphaxad, Lud and Aram."
    },
    {
      "verse": "23",
      "text": "These are the sons of Aram: Uz, Hul, Gether and Meshech."
    },
    {
      "verse": "24",
      "text": "Arphaxad was the father of Shelah. Shelah was the father of Eber."
    },
    {
      "verse": "25",
      "text": "Eber had two sons. The name of one son was Peleg. When he was alive, people began to live in different places on the earth. That is why his name was Peleg. Peleg's brother's name was Joktan."
    },
    {
      "verse": "26",
      "text": "Joktan was the father of Almodad, Sheleph, Hazarmaveth, Jerah,"
    },
    {
      "verse": "27",
      "text": "Hadoram, Uzal, Diklah,"
    },
    {
      "verse": "28",
      "text": "Obal, Abimael, Sheba,"
    },
    {
      "verse": "29",
      "text": "Ophir, Havilah and Jobab. All those were Joktan's sons."
    },
    {
      "verse": "30",
      "text": "The land where they lived went from Mesha to Sephar. This is in the land with hills in the east."
    },
    {
      "verse": "31",
      "text": "These are the descendants of Shem. They lived in groups in their own parts of the land. Each group spoke their own language."
    },
    {
      "verse": "32",
      "text": "All these people are descendants of Noah's sons, and their children. They went to live in different parts of the earth and their children became different nations. This happened after God covered the earth with water and then the water went away."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "At this time, everyone who lived on the earth spoke one language. They used the same words."
    },
    {
      "verse": "2",
      "text": "People moved to the east. They reached a large flat piece of land called Shinar. They stayed there to live."
    },
    {
      "verse": "3",
      "text": "They said to each other, ‘We should make bricks and cook them until they are hard. ’ These people used bricks instead of stones to build houses. They used tar to hold the bricks together, instead of cement."
    },
    {
      "verse": "4",
      "text": "They said, ‘Let us build a city to live in. We should also build a very tall tower. The tower will go up into the heavens. Then we will always be famous. If we do that, we will not have to separate and go to live in different places on the earth. ’"
    },
    {
      "verse": "5",
      "text": "But the Lord came down to see the city and the tower. He saw that the people had started to build them."
    },
    {
      "verse": "6",
      "text": "The Lord said, ‘Because they all speak the same language, they are able to do this. If they can do this together, they may decide to do whatever they want."
    },
    {
      "verse": "7",
      "text": "Now we must go down to them. We must make their language become confused. Then they will not be able to understand each other. ’"
    },
    {
      "verse": "8",
      "text": "So the Lord separated the people from one another. They went to live in different lands all over the earth. They stopped building the city for themselves."
    },
    {
      "verse": "9",
      "text": "That is why people called the city Babel. It was because the Lord confused all the people of the world and he gave them different languages to speak. From that time, the Lord separated the people from each other so that they lived in different places all over the earth."
    },
    {
      "verse": "10",
      "text": "This is the report about Shem and his family. Two years after the deep water went away from the earth, Shem was 100 years old. He became the father of Arphaxad."
    },
    {
      "verse": "11",
      "text": "After Arphaxad was born, Shem lived for 500 years. He had other sons and daughters."
    },
    {
      "verse": "12",
      "text": "years old, he became the father of Shelah."
    },
    {
      "verse": "13",
      "text": "After Shelah was born, Arphaxad lived for 403 years. He had other sons and daughters."
    },
    {
      "verse": "14",
      "text": "years old, he became the father of Eber."
    },
    {
      "verse": "15",
      "text": "After Eber was born, Shelah lived for 403 years. He had other sons and daughters."
    },
    {
      "verse": "16",
      "text": "years old, he became the father of Peleg."
    },
    {
      "verse": "17",
      "text": "After Peleg was born, Eber lived for 430 years. He had other sons and daughters."
    },
    {
      "verse": "18",
      "text": "years old, he became the father of Reu."
    },
    {
      "verse": "19",
      "text": "After Reu was born, Peleg lived for 209 years. He had other sons and daughters."
    },
    {
      "verse": "20",
      "text": "years old, he became the father of Serug."
    },
    {
      "verse": "21",
      "text": "After Serug was born, Reu lived for 207 years. He had other sons and daughters."
    },
    {
      "verse": "22",
      "text": "years old, he became the father of Nahor."
    },
    {
      "verse": "23",
      "text": "After Nahor was born, Serug lived for 200 years. He had other sons and daughters."
    },
    {
      "verse": "24",
      "text": "years old, he became the father of Terah."
    },
    {
      "verse": "25",
      "text": "After Terah was born, Nahor lived for 119 years. He had other sons and daughters."
    },
    {
      "verse": "26",
      "text": "years old, he became the father of Abram, Nahor and Haran."
    },
    {
      "verse": "27",
      "text": "This is the report about Terah and his family. Terah became the father of Abram, Nahor and Haran. Haran became the father of Lot."
    },
    {
      "verse": "28",
      "text": "While Terah was still alive, his son, Haran, died. Haran died in Ur, the land of the Chaldeans. That was where Haran had been born."
    },
    {
      "verse": "29",
      "text": "Abram married Sarai. Nahor married Milcah. Milcah was Haran's daughter. Haran was the father of Milcah and Iscah."
    },
    {
      "verse": "30",
      "text": "Sarai could not give birth to children. She did not have any children."
    },
    {
      "verse": "31",
      "text": "Terah took his son Abram and his grandson Lot. (Lot was Haran's son. ) Terah also took Abram's wife Sarai. They all left Ur, the land of the Chaldeans. They began to go to Canaan. But when they came to Haran, they stayed there."
    },
    {
      "verse": "32",
      "text": "years. Then he died in Haran."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "The Lord had said to Abram, ‘Leave your country and the people of your father's family. Go to the land that I will show you."
    },
    {
      "verse": "2",
      "text": "I will cause your descendants to become a great nation. I will bless you. Everyone will know your name. You will bring my blessing to other people."
    },
    {
      "verse": "3",
      "text": "I will bless those people who bless you. But I will curse anyone who insults you. Through you, I will bless all the families of people on the earth. ’"
    },
    {
      "verse": "4",
      "text": "Abram did what the Lord had told him. He left Haran. Abram was 75 years old when he left Haran. Lot went with him."
    },
    {
      "verse": "5",
      "text": "Abram took his wife Sarai, and his nephew Lot. He took everything that belonged to them. He also took the people that worked for them in Haran. They all left to go to the land of Canaan. When they arrived in Canaan,"
    },
    {
      "verse": "6",
      "text": "Abram walked through the land. He went as far as Shechem, to the special oak tree of Moreh. At that time, Canaanites lived in this land."
    },
    {
      "verse": "7",
      "text": "The Lord appeared to Abram there. He said, ‘I will give this land to your descendants. ’ So Abram built an altar in that place to worship the Lord. He did that because the Lord had appeared to him."
    },
    {
      "verse": "8",
      "text": "Then Abram left Shechem. He went to the hills that are on the east of Bethel. He put up his tent in that place. Bethel was towards the west, and Ai was towards the east. Abram also built an altar there to worship the Lord."
    },
    {
      "verse": "9",
      "text": "Then Abram took his tent and he left that place. He continued to travel towards the Negev."
    },
    {
      "verse": "10",
      "text": "There was a famine in the land of Canaan. So Abram went to live in Egypt for some time, because the famine was very bad."
    },
    {
      "verse": "11",
      "text": "When Abram came near to Egypt, he said to his wife Sarai, ‘Listen to me. I know that you are a very beautiful woman."
    },
    {
      "verse": "12",
      "text": "When the Egyptians see you they will say, “This is Abram's wife. ” Then they will kill me, but they will let you live."
    },
    {
      "verse": "13",
      "text": "So tell them that you are my sister. Then they will do good things to me, because they want to please you. They will not kill me because they will think that you are my sister. ’"
    },
    {
      "verse": "14",
      "text": "When Abram arrived in Egypt, the people saw that Sarai was a very beautiful woman."
    },
    {
      "verse": "15",
      "text": "The king's officers saw her. They told Pharaoh that she was very beautiful. They took her to the king's palace."
    },
    {
      "verse": "16",
      "text": "Pharaoh did good things to help Abram because of Sarai. He gave Abram sheep, cows, donkeys and camels. He also gave Abram male servants and female servants."
    },
    {
      "verse": "17",
      "text": "But the Lord made Pharaoh and the people in his palace very ill. The Lord did this because the king had taken Abram's wife Sarai."
    },
    {
      "verse": "18",
      "text": "So Pharaoh called Abram to come to him. Pharaoh said, ‘You have done this bad thing to me! You did not tell me that Sarai is your wife! Why not?"
    },
    {
      "verse": "19",
      "text": "You told me “She is my sister”. As a result, I took her to be my wife. Now, here is your wife. Take her and go away! ’"
    },
    {
      "verse": "20",
      "text": "Pharaoh told his officers what to do with Abram. They sent Abram away, with his wife and everything that belonged to them."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "Abram left Egypt and he travelled north to the Negev. He took his wife and everything that belonged to him. Lot also went with him."
    },
    {
      "verse": "2",
      "text": "Abram had many valuable things. He had many cows, and much silver and gold."
    },
    {
      "verse": "3",
      "text": "Then Abram left the Negev and he went to different places. He arrived at Bethel. He returned to the place where he had put up his tent before. That place was between Bethel and Ai."
    },
    {
      "verse": "4",
      "text": "It was where Abram had first built an altar to worship the Lord."
    },
    {
      "verse": "5",
      "text": "Lot was travelling with Abram. Lot also had many cows, sheep and tents."
    },
    {
      "verse": "6",
      "text": "But the land could not grow enough food for all of them to eat. They could not all live together in the same place, because they had so many animals and people with them."
    },
    {
      "verse": "7",
      "text": "Abram's shepherds and Lot's shepherds began to quarrel with each other. (At that time, Canaanites and Perizzites also lived in the land. )"
    },
    {
      "verse": "8",
      "text": "Abram said to Lot, ‘We must not quarrel with each other. Your shepherds and my shepherds must not quarrel with each other. Remember that we belong to the same family."
    },
    {
      "verse": "9",
      "text": "Look everywhere! There is enough land for all of us. We must go different ways. If you go to the left, I will go to the right. If you go to the right, I will go to the left. ’"
    },
    {
      "verse": "10",
      "text": "Lot looked up and he saw the flat land of Jordan, as far as Zoar. He saw that it had lots of water, like the garden of the Lord. It was good land, like the land of Egypt. (This was before the Lord destroyed the cities there called Sodom and Gomorrah. )"
    },
    {
      "verse": "11",
      "text": "So Lot chose for himself the valley of the Jordan River. He travelled towards the east."
    },
    {
      "verse": "12",
      "text": "Abram stayed in the land of Canaan and he lived there. But Lot lived near the cities that were in the Jordan Valley. He put up his tents near the city of Sodom."
    },
    {
      "verse": "13",
      "text": "The people of Sodom were very wicked. They did not obey the Lord at all."
    },
    {
      "verse": "14",
      "text": "After Lot had gone away, the Lord said to Abram, ‘Stand where you are and look all around! Look to the north, the south, the east and the west."
    },
    {
      "verse": "15",
      "text": "I will give you all the land that you can see. I will give it to you and your descendants. It will belong to them for ever."
    },
    {
      "verse": "16",
      "text": "I will make your descendants become very many. Like the dust of the ground, people will not be able to count them all."
    },
    {
      "verse": "17",
      "text": "Go and travel round all this land. Look at it, because I am giving it to you! ’"
    },
    {
      "verse": "18",
      "text": "So Abram moved his tents. He went to live near the special oak trees of Mamre. That place is at Hebron. Abram built an altar to worship the Lord there."
    }
  ],
  "14": [
    {
      "verse": "5",
      "text": "In the 14th year, Kedorlaomer and the kings with him won against the Rephaites. This was in Ashteroth Karnaim. They won against the Zuzites in Ham. They won against the Emites in Shaveh Kiriathaim."
    },
    {
      "verse": "6",
      "text": "And they won against the Horites in the country of Seir. This was as far as El Paran near the desert."
    },
    {
      "verse": "7",
      "text": "They then went back. They went to En Mishpat. (That is Kadesh. ) They took the whole land of the Amalekites. They also took the land of the Amorites who were living in Hazezon Tamar."
    },
    {
      "verse": "8",
      "text": "Then, the king of Sodom, the king of Gomorrah, the king of Admah, the king of Zeboiim and the king of Bela (that is Zoar) went to fight. That was in the Valley of Siddim."
    },
    {
      "verse": "9",
      "text": "They fought against Kedorlaomer king of Elam, Tidal king of Goiim, Amraphel king of Shinar and Arioch king of Ellasar. There were four kings fighting against five kings."
    },
    {
      "verse": "10",
      "text": "The Valley of Siddim had many holes in the ground. The holes were filled with tar. The kings of Sodom and Gomorrah ran away. Some of their men fell into the deep tar. The other men ran away to the hills."
    },
    {
      "verse": "11",
      "text": "The four kings took everything in Sodom and Gomorrah, including all the food. Then they went away."
    },
    {
      "verse": "12",
      "text": "Abram's nephew, Lot, was living in Sodom at that time. So they took him away from there, and everything that belonged to him."
    },
    {
      "verse": "13",
      "text": "At that time, Abram, the Hebrew man, was living near the special oak trees of Mamre. Mamre was an Amorite. He was the brother of Eshcol and Aner. These men had agreed to be Abram's friends. A man ran away from Sodom. He told Abram everything that had happened."
    },
    {
      "verse": "14",
      "text": "Abram understood that the kings had caught his nephew. So he called 318 men to come together. These men had been born in Abram's camp and they knew how to fight. Abram took his men with him. They went to attack the men who had caught Lot. They went as far as Dan."
    },
    {
      "verse": "15",
      "text": "During the night, Abram separated his men into two groups. Then they attacked Kedorlaomer and his men who had taken Lot. Those men ran away and Abram followed them as far as Hobah. Hobah is north of Damascus."
    },
    {
      "verse": "16",
      "text": "Abram took back everything that those men had taken from Sodom. He also brought back his nephew Lot, together with the women and the other people."
    },
    {
      "verse": "17",
      "text": "In that way, Abram won against Kedorlaomer and the kings with him. As Abram was returning home, the king of Sodom came out to meet him. They met in the Valley of Shaveh, which people call the King's Valley."
    },
    {
      "verse": "18",
      "text": "Melchizedek was the king of Salem, and he was a priest of the Most High God. He brought out bread and wine for Abram. After that, Abram gave Melchizedek a tenth part of everything."
    },
    {
      "verse": "19",
      "text": "He blessed Abram. He said, ‘I pray that the Most High God who made heaven and earth will bless Abram."
    },
    {
      "verse": "20",
      "text": "Praise the Most High God! He has given you power over your enemies. ’After that, Abram gave Melchizedek a tenth part of everything."
    },
    {
      "verse": "21",
      "text": "Then the king of Sodom said to Abram, ‘Give back to me all my people. Take everything else for yourself. ’"
    },
    {
      "verse": "22",
      "text": "But Abram said to the king of Sodom, ‘I have made a strong promise to the Lord, the Most High God who made heaven and earth."
    },
    {
      "verse": "23",
      "text": "I promised that I would not take anything that belonged to you. I will not take the smallest thing, not even a piece of string, or part of a shoe. Then you will never be able to say, “I made Abram become rich. ”"
    },
    {
      "verse": "24",
      "text": "I myself will accept only the food that my young men have eaten. But Aner, Eshcol and Mamre went with me to help me to fight. They should take their part of the things that we brought back with us. ’"
    },
    {
      "verse": "1",
      "text": "Now there were many kings living in that land, at that time. They fought against each other. One fight was when Kedorlaomer had ruled over the other kings for 12 years."
    },
    {
      "verse": "2",
      "text": "And in the next year, five kings made one group like that and fought against him. Kedorlaomer joined with three other kings. So it was four kings against five other kings."
    },
    {
      "verse": "3",
      "text": "The four kings were Amraphel king of Shinar, Arioch king of Ellasar, Kedorlaomer king of Elam and Tidal king of Goiim. Those kings fought a war against Bera king of Sodom, Birsha king of Gomorrah, Shinab king of Admah, Shemeber king of Zeboiim and the king of Bela. (Bela is another name for the town of Zoar."
    },
    {
      "verse": "4",
      "text": ") They fought in the Valley of Siddim. (That is the Salt Sea."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "After this, the Lord spoke to Abram in a dream. God said, ‘Do not be afraid Abram. I will keep you safe. I myself will give you many good gifts. ’"
    },
    {
      "verse": "2",
      "text": "But Abram said, ‘Almighty Lord, there is one gift that I want. I still have no children. When I die, Eliezer of Damascus will receive everything that I have."
    },
    {
      "verse": "3",
      "text": "Because you have not given me any children, understand this: Everything that I have will one day belong to a servant in my house. ’"
    },
    {
      "verse": "4",
      "text": "The Lord gave Abram this message: ‘No! Eliezer will not be the one who receives your things. You will have your own son. He will be the one who receives everything that you have. ’"
    },
    {
      "verse": "5",
      "text": "The Lord took Abram outside. He said to Abram, ‘Look up at the sky. Count the stars. They are too many for you to count! ’ Then God said, ‘That is how many descendants you will have. ’"
    },
    {
      "verse": "6",
      "text": "Abram believed the Lord. As a result, the Lord accepted Abram as right with him."
    },
    {
      "verse": "7",
      "text": "The Lord also said to Abram, ‘I am the Lord. I brought you out of Ur of the Chaldeans to bring you to this land. I am giving it to you. It will belong to you. ’"
    },
    {
      "verse": "8",
      "text": "But Abram said, ‘Almighty Lord, how can I be sure that this land will belong to me? ’"
    },
    {
      "verse": "9",
      "text": "The Lord said to Abram, ‘Bring a young cow, a goat and a male sheep to offer them to me. Each animal must be three years old. Also bring a dove and a young pigeon. ’"
    },
    {
      "verse": "10",
      "text": "Abram brought the three animals and the two birds to offer to God. Abram cut each animal in two pieces. He put the halves opposite each other. But he did not cut the birds in two pieces."
    },
    {
      "verse": "11",
      "text": "Some birds flew down to eat the animals' dead bodies. But Abram sent them away."
    },
    {
      "verse": "12",
      "text": "When the sun was going down, Abram started to sleep. Suddenly he became very afraid because it was dark all around him."
    },
    {
      "verse": "13",
      "text": "Then the Lord said to Abram, ‘Be sure of this: Your descendants will live in a foreign country. They will be strangers there. People will do bad things to them and they will become slaves. This will continue for 400 years."
    },
    {
      "verse": "14",
      "text": "But I will punish the people of that country who give them trouble. After this, your descendants will leave that country. They will take many valuable things with them."
    },
    {
      "verse": "15",
      "text": "But as for you, Abram, you will have a long life. When you die, you will have peace in your mind."
    },
    {
      "verse": "16",
      "text": "After four generations, your descendants will come back here to Canaan. At that time, I will punish the Amorites because they do very bad things. But the time has not yet arrived that I will punish them. ’"
    },
    {
      "verse": "17",
      "text": "Then the sun went down and it became dark. Abram saw a pot that had coals in it. The coals were burning and making smoke. There was also a branch that burned with bright fire. These passed between the halves of the animals that Abram had cut in two pieces."
    },
    {
      "verse": "18",
      "text": "On that day, the Lord made a covenant with Abram. The Lord promised, ‘I give this land to your descendants. The land starts from the river of Egypt and continues as far as the River Euphrates."
    },
    {
      "verse": "19",
      "text": "These people live in the land: Kenites, Kenizzites, Kadmonites,"
    },
    {
      "verse": "20",
      "text": "Hittites, Perizzites, Rephaites,"
    },
    {
      "verse": "21",
      "text": "Amorites, Canaanites, Girgashites and Jebusites. ’"
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "Abram's wife, Sarai, had not given birth to any children. She had an Egyptian servant. The servant's name was Hagar."
    },
    {
      "verse": "2",
      "text": "Sarai said to Abram, ‘The Lord has not let me have any children. Go and sleep with my servant. Then if she gives birth, her children will be my family. ’ Abram agreed to do this."
    },
    {
      "verse": "3",
      "text": "Abram had now been living in Canaan for ten years. Sarai gave her Egyptian servant, Hagar, to him. She became like another wife for Abram."
    },
    {
      "verse": "4",
      "text": "Abram had sex with Hagar and she became pregnant. When Hagar knew that she was pregnant, she no longer respected Sarai."
    },
    {
      "verse": "5",
      "text": "Then Sarai said to Abram, ‘It is because of you that Hagar is now insulting me. I gave her to you so that you could have sex with her. Now she is pregnant and she does not respect me. The Lord will decide who is right, you or me. ’"
    },
    {
      "verse": "6",
      "text": "Abram said to Sarai, ‘Hagar is your servant and you have authority over her. Do to her whatever you think is right. ’ Then Sarai caused trouble for Hagar. So Hagar ran away from Sarai."
    },
    {
      "verse": "7",
      "text": "The angel of the Lord found Hagar. She was by a spring of water in the desert. The spring was near the road to Shur."
    },
    {
      "verse": "8",
      "text": "The angel said, ‘Sarai's servant, Hagar, where have you come from? Where are you going? ’ Hagar replied, ‘I am running away from Sarai. I am her servant. ’"
    },
    {
      "verse": "9",
      "text": "The angel of the Lord told Hagar, ‘Go back to Sarai. You are her servant and you must obey her. ’"
    },
    {
      "verse": "10",
      "text": "The angel also said, ‘I will make the number of your descendants become very many. They will be too many for people to count. ’"
    },
    {
      "verse": "11",
      "text": "The angel of the Lord said to Hagar, ‘Now you are pregnant and you will give birth to a son. When you cried in pain, the Lord heard you, so you must give your son the name “Ishmael”. ‘Now you are pregnant and you will give birth to a son. When you cried in pain, the Lord heard you, so you must give your son the name “Ishmael”."
    },
    {
      "verse": "12",
      "text": "Like a wild donkey, nobody will be able to rule him. He will fight against everyone, and everyone will fight against him. He will think that everyone is his enemy. He will keep away from his brothers. ’ He will fight against everyone, and everyone will fight against him. He will think that everyone is his enemy. He will keep away from his brothers. ’"
    },
    {
      "verse": "13",
      "text": "When Hagar heard what the angel said, she said to herself, ‘I have seen the God who sees me! ’ So she called the Lord ‘The God who sees me. ’"
    },
    {
      "verse": "14",
      "text": "That is why they called the well in that place ‘Beer Lahai Roi’. The well is between Kadesh and Bered."
    },
    {
      "verse": "15",
      "text": "After some time Hagar gave birth to a son. Abram was his father. Abram gave his son the name ‘Ishmael’."
    },
    {
      "verse": "16",
      "text": "years old when Hagar gave birth to Ishmael."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "years old, the Lord appeared to him. The Lord said, ‘I am God Almighty. In all your life, obey me and do nothing wrong."
    },
    {
      "verse": "2",
      "text": "Then I will certainly keep my covenant with you. I will make your descendants grow in number. ’"
    },
    {
      "verse": "3",
      "text": "Abram fell down so that his face touched the ground. God said to him,"
    },
    {
      "verse": "4",
      "text": "‘As for me, this is my covenant that I have made with you. You will become the ancestor of many nations of people."
    },
    {
      "verse": "5",
      "text": "Your name will not be Abram any more. Instead your name will be Abraham, because I will cause you to become the ancestor of many nations."
    },
    {
      "verse": "6",
      "text": "I will give you many descendants. These will make many nations of people. Some of your descendants will become kings."
    },
    {
      "verse": "7",
      "text": "My covenant with you is very strong. I am making it with you and with your descendants. It will continue for generation after generation of your descendants, for all time. I will be your God. I will also be the God of all your descendants."
    },
    {
      "verse": "8",
      "text": "You are now living here in Canaan as a foreign person. But I will give all of this land to you and to your descendants. It will belong to them for ever. I will be their God. ’"
    },
    {
      "verse": "9",
      "text": "God continued to speak to Abraham. He said, ‘As for you, you must agree to obey me. You must obey the rules of my covenant. You, and all your descendants after you must obey it."
    },
    {
      "verse": "10",
      "text": "This is what you and all your descendants must do to obey my covenant: Every male person in your family must be circumcised."
    },
    {
      "verse": "11",
      "text": "Your circumcision will show that you have agreed to my covenant with you."
    },
    {
      "verse": "12",
      "text": "Every male child among you must be circumcised when he is eight days old. You must continue to do this for every generation. Do it for every male that lives with you, not just your own family. Circumcise servants that have been born in your house. Also circumcise foreign servants that you have bought with money."
    },
    {
      "verse": "13",
      "text": "You must circumcise all the male servants who work for you in your house. Circumcision will be a mark in your bodies which shows that you accept my covenant. It will continue for all time."
    },
    {
      "verse": "14",
      "text": "If any male person among you has not been circumcised, I will not accept him as one of my people. He must become separate from his people. He has not obeyed my covenant. ’"
    },
    {
      "verse": "15",
      "text": "Then God said to Abraham, ‘As for your wife, do not call her Sarai any more. Instead, her name will be Sarah."
    },
    {
      "verse": "16",
      "text": "I will bless her. She will give birth to a son for you. Many nations of people will be her descendants. Some of them will become kings. That is how much I will bless her! ’"
    },
    {
      "verse": "17",
      "text": "Abraham fell down so that his face touched the ground. He laughed and he said to himself, ‘I am now 100 years old. That is too old to have a son. Sarah is 90 years old, so she could never give birth to a child. That is too old to have a child. ’"
    },
    {
      "verse": "18",
      "text": "So Abraham said to God, ‘I would be happy if you would bless Ishmael as my son. ’"
    },
    {
      "verse": "19",
      "text": "God said to Abraham, ‘No, your wife Sarah will give birth to a son for you. You must give him the name “Isaac”. I will make my covenant with him and with his descendants for all time."
    },
    {
      "verse": "20",
      "text": "I have heard what you want me to do for Ishmael. I will bless him. I will cause him to have many descendants. Among his descendants there will be 12 rulers. His descendants will become a great nation."
    },
    {
      "verse": "21",
      "text": "But I will make my covenant with Isaac, not with Ishmael. At about this time next year, Sarah will give birth to your son, Isaac. ’"
    },
    {
      "verse": "22",
      "text": "When God had finished speaking to Abraham, he went away."
    },
    {
      "verse": "23",
      "text": "On that same day, Abraham circumcised Ishmael and every male person in his house. He circumcised every male servant that was born in his house, as well as those that he had bought with money. He did this in the way that God had told him."
    },
    {
      "verse": "24",
      "text": "years old."
    },
    {
      "verse": "25",
      "text": "His son, Ishmael, was 13 years old when he was circumcised."
    },
    {
      "verse": "26",
      "text": "Abraham and Ishmael were circumcised on the same day."
    },
    {
      "verse": "27",
      "text": "As well as them, all the male people living in Abraham's house were circumcised. This included the male servants that had been born in his house and those that he had bought with money."
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "The Lord appeared to Abraham near the special oak trees of Mamre. It was the hot time of day and Abraham was sitting by the door of his tent."
    },
    {
      "verse": "2",
      "text": "Abraham looked up and he saw three men. He ran in a hurry to meet them. He bent down to the ground to respect them."
    },
    {
      "verse": "3",
      "text": "Abraham said, ‘Please sir, stop here and let me serve you. That would make me very happy."
    },
    {
      "verse": "4",
      "text": "Let us bring some water so that you can all wash your feet. Then you can rest under this tree."
    },
    {
      "verse": "5",
      "text": "Let me also bring some food for you to eat. Now that you have come to my home, you should rest and become strong again. Then you will be ready to continue with your journey. ’ The men replied, ‘That is good. Please do what you have said. ’"
    },
    {
      "verse": "6",
      "text": "Abraham went quickly to the tent. He said to Sarah, ‘Be quick! Get plenty of good flour and make bread with it. ’"
    },
    {
      "verse": "7",
      "text": "Then Abraham ran to his cows. He chose a very nice young cow. He gave it to his servant. The servant quickly prepared it for the men to eat."
    },
    {
      "verse": "8",
      "text": "Then Abraham also brought some cream and some milk, as well as the meat from the cow. He put all the food in front of the men. While they ate it, Abraham stood near them, under a tree."
    },
    {
      "verse": "9",
      "text": "Then the men asked Abraham, ‘Where is Sarah, your wife? ’ Abraham replied, ‘She is there in the tent. ’"
    },
    {
      "verse": "10",
      "text": "Then one of the men said, ‘I will certainly return to you at about this time next year. At that time Sarah, your wife, will have a son! ’Sarah was listening to all this. She was at the door of the tent, near to where they were talking."
    },
    {
      "verse": "11",
      "text": "Abraham and Sarah were now very old. Sarah was past the age when she could give birth to a child."
    },
    {
      "verse": "12",
      "text": "So Sarah laughed to herself. She thought, ‘I have become old and weak. My husband is also old. I will never have a baby and be happy like that. ’"
    },
    {
      "verse": "13",
      "text": "Then the Lord said to Abraham, ‘Why did Sarah laugh like that? She said, “I am too old to have a child. ”"
    },
    {
      "verse": "14",
      "text": "But surely, nothing is too difficult for the Lord to do. At this time next year, I will return to you and Sarah will have a son. ’"
    },
    {
      "verse": "15",
      "text": "Then Sarah was afraid. So she told a lie. She said, ‘I did not laugh. ’ But the Lord said, ‘Yes, you did laugh. ’"
    },
    {
      "verse": "16",
      "text": "Then Abraham's visitors started to leave. They looked down in the valley towards Sodom. Abraham was walking with them to say ‘goodbye’ to them."
    },
    {
      "verse": "17",
      "text": "Then the Lord said to himself, ‘I should tell Abraham what I have decided to do."
    },
    {
      "verse": "18",
      "text": "Abraham's descendants will become a great nation of people. They will be very powerful. Through him, I will bless all the nations of the earth."
    },
    {
      "verse": "19",
      "text": "I have chosen him so that he will teach my message to his children and their families. He will teach them to do what is right and what is fair. Then I, the Lord, will do for Abraham everything that I have promised to him. ’"
    },
    {
      "verse": "20",
      "text": "So the Lord said to Abraham, ‘I have heard how bad the people in Sodom and Gomorrah are. Everybody says that their sins are very bad."
    },
    {
      "verse": "21",
      "text": "So I must go down there to see if it is really true. I will see if those people are as bad as everybody says they are. Then I will know what is true. ’"
    },
    {
      "verse": "22",
      "text": "The other two men then turned away and they went towards Sodom. But Abraham stayed there to talk with the Lord."
    },
    {
      "verse": "23",
      "text": "Then Abraham went near to the Lord and he asked, ‘Will you destroy the good people as well as the bad people?"
    },
    {
      "verse": "24",
      "text": "people in the city who live in a good way. Will you still destroy the whole city? Or will you leave it there, because there are 50 good people in it?"
    },
    {
      "verse": "25",
      "text": "Will you kill them all, the good people and the bad people? Surely you would not do anything like that! You would not punish good people in the same way as bad people. You are the great judge of everyone on the earth. You will surely do what is right! ’"
    },
    {
      "verse": "26",
      "text": "The Lord replied, ‘If I see that there are 50 good people in the city of Sodom, I will not destroy that place. Because of those 50 good people, I will leave the city there. ’"
    },
    {
      "verse": "27",
      "text": "Then Abraham spoke again. He said, ‘I have been brave enough to speak to the Lord. I know that I am nothing more than dust and ashes."
    },
    {
      "verse": "28",
      "text": "But let me ask you this. What will you do if there are 45 good people in the city? Will you destroy the city, because there are only five fewer good people there? ’ The Lord replied, ‘If I see that there are 45 good people in the city, I will not destroy it. ’"
    },
    {
      "verse": "29",
      "text": "Abraham spoke to God again. He said, ‘What will you do if only 40 good people are there? ’ The Lord said, ‘Because of 40 good people, I will not destroy the city. ’"
    },
    {
      "verse": "30",
      "text": "Then Abraham said, ‘Please do not be angry, Lord. Let me speak again. What will you do if there are only 30 good people there? ’ The Lord answered, ‘I will not destroy the city if I find 30 good people there. ’"
    },
    {
      "verse": "31",
      "text": "Abraham said, ‘I have been brave to speak to you, Lord. What will you do if only 20 good people are there? ’ The Lord said, ���Because of 20 good people, I will not destroy the city. ’"
    },
    {
      "verse": "32",
      "text": "After all that, Abraham said, ‘Please do not be angry, Lord. Let me speak just one more time. If there are only ten good people there, what will you do? ’ The Lord replied, ‘Because of ten good people, I will not destroy the city. ’"
    },
    {
      "verse": "33",
      "text": "The Lord had finished speaking with Abraham. So he continued on his journey. Abraham returned home."
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "The two angels arrived at Sodom. It was evening and Lot was sitting near the city gate. When Lot saw the angels, he got up to meet them. He turned his face towards the ground to respect them."
    },
    {
      "verse": "2",
      "text": "Lot said, ‘My lords, please come to stay in my house. You can wash your feet and stay the night there. Then you can continue your journey early in the morning. ’ The angels replied, ‘No, we will stay the night here in this public place. ’"
    },
    {
      "verse": "3",
      "text": "But Lot continued to ask them to stay with him. So the angels went with Lot to his house. Lot prepared a big meal for them, with some bread that he had baked without yeast. The angels ate the food."
    },
    {
      "verse": "4",
      "text": "After that, they were preparing to go to bed. Then all the men who lived in Sodom came to Lot's house. They were old men and young men, who came from every part of the city. They stood all round the house."
    },
    {
      "verse": "5",
      "text": "The men shouted to Lot, ‘Where are the men who are staying with you tonight? Bring them out here to us. We want to have sex with them. ’"
    },
    {
      "verse": "6",
      "text": "Lot went outside to talk to the men. He shut the door of his house behind him."
    },
    {
      "verse": "7",
      "text": "He said, ‘No, my friends. Please do not do this evil thing."
    },
    {
      "verse": "8",
      "text": "See here! I have two daughters. They have never had sex with a man. Let me bring them out to you. Then you can do whatever you want with them. But do not do anything to these men. They are my visitors and I cannot let anyone hurt them. ’"
    },
    {
      "verse": "9",
      "text": "The men from the city said, ‘Do not try to stop us! You are a stranger here in this city. You cannot tell us what to do! Be careful or we will do even worse things to you. ’ They pushed against Lot and tried to reach the door of his house. They wanted to break the door and go in to the house."
    },
    {
      "verse": "10",
      "text": "The two visitors who were inside the house opened the door. They pulled Lot back into his house and they shut the door quickly."
    },
    {
      "verse": "11",
      "text": "Then they caused all the men outside to become blind. The young men of the city and the old men all became blind. As a result, they could not find the door of the house, even though they tried for some time."
    },
    {
      "verse": "12",
      "text": "The two visitors asked Lot, ‘Do you have any of your family here in the city? Do you have any sons or daughters, or husbands for your daughters? If you have any family, you must take them away from here."
    },
    {
      "verse": "13",
      "text": "We will soon destroy this city. Everybody knows how bad the people who live here are. As a result, the Lord has sent us to destroy this place. ’"
    },
    {
      "verse": "14",
      "text": "So Lot went out of his house. He spoke to the men who would marry his daughters. He said to them, ‘Hurry! Leave this city now, because the Lord has decided to destroy it. ’ But the men did not believe Lot. They thought he was not being serious."
    },
    {
      "verse": "15",
      "text": "At dawn, the two angels told Lot he must leave quickly. They said to him, ‘Hurry! Take your wife and take your two daughters who are here. If you do not go quickly, you will all die when the Lord destroys the city. ’"
    },
    {
      "verse": "16",
      "text": "But Lot did not move. So the angels took hold of Lot's hand, as well as the hands of his wife and his two daughters. The Lord was very kind to Lot and his family and the angels led them away from the city."
    },
    {
      "verse": "17",
      "text": "When they had reached a place outside the city, one of the angels said, ‘Now run! Your lives are in danger. Do not look behind you! Do not stop anywhere in this valley. Run up into the mountains or you will die. ’"
    },
    {
      "verse": "18",
      "text": "But Lot said, ‘No! Please, my lords, I cannot do that!"
    },
    {
      "verse": "19",
      "text": "I am your humble servant and you have been very kind to me. You have saved my life. But I cannot run away into the mountains. If I try to do that, this punishment will catch me before I reach there. Then I will surely die."
    },
    {
      "verse": "20",
      "text": "Look! See that town over there. It is near and I can run to it safely. And it is a small town. So please let me run there. You can see that it is only a small place. If I go there, I will stay alive. ’"
    },
    {
      "verse": "21",
      "text": "The angel said to Lot, ‘OK, I will let you do what you have asked. I will not destroy that town."
    },
    {
      "verse": "22",
      "text": "But run there quickly. I cannot do anything until you arrive in the town. ’ (The name of the town became ‘Zoar’, because it was small. )"
    },
    {
      "verse": "23",
      "text": "Lot reached Zoar at the time when the sun was rising that morning."
    },
    {
      "verse": "24",
      "text": "Then the Lord poured sulphur that was on fire down on Sodom and Gomorrah. It fell from the sky like rain."
    },
    {
      "verse": "25",
      "text": "In that way God destroyed those cities and everything in the valley. He killed all the people who lived in those cities. And he killed all the plants that grew on the land."
    },
    {
      "verse": "26",
      "text": "But as they ran away, Lot's wife looked back at the city. When she did that, she became a large piece of salt, like a pillar."
    },
    {
      "verse": "27",
      "text": "Early in the morning, Abraham returned to the place where he had spoken with the Lord."
    },
    {
      "verse": "28",
      "text": "He looked towards Sodom and Gomorrah and the whole valley. He saw thick dark smoke that was rising from the land. It was the smoke from a big fire."
    },
    {
      "verse": "29",
      "text": "When God destroyed the cities of the valley, he saved Lot from that punishment. God remembered what Abraham had asked him. He took Lot away from the cities where he had lived. Then God destroyed those cities."
    },
    {
      "verse": "30",
      "text": "Lot was afraid to live in Zoar. So he took his two daughters and they went up into the mountains. They lived together in a cave."
    },
    {
      "verse": "31",
      "text": "One day, the older daughter said to her sister, ‘Our father is now old. There are no men who live near here, so there is nobody to marry us. We cannot have sex like everyone on the earth wants to do."
    },
    {
      "verse": "32",
      "text": "So we should give our father much wine to drink. When he becomes drunk, we will have sex with him. Then our father's family will continue to have descendants. ’"
    },
    {
      "verse": "33",
      "text": "That night they caused their father to become drunk with wine. The older daughter had sex with him. Lot was very drunk. He did not know when she came to him. And he did not know when she left him."
    },
    {
      "verse": "34",
      "text": "The next day the older daughter said to her younger sister, ‘Last night I had sex with my father. We should make him drunk with wine again tonight. Then you can have sex with him. As a result, our father's family will continue. ’"
    },
    {
      "verse": "35",
      "text": "So that night, they caused their father to become drunk again. The younger daughter had sex with her father. He did not know when she came to him. And he did not know when she left him."
    },
    {
      "verse": "36",
      "text": "In that way, Lot caused both of his daughters to become pregnant."
    },
    {
      "verse": "37",
      "text": "The older daughter gave birth to a son. She called him Moab. He became the ancestor of the Moabites."
    },
    {
      "verse": "38",
      "text": "The younger daughter also gave birth to a son. She called him Ben-Ammi. He became the ancestor of the Ammonites."
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "Abraham travelled south to the Negev desert. He lived between Kadesh and Shur. For a time he stayed in Gerar."
    },
    {
      "verse": "2",
      "text": "While he was there, Abraham told people that his wife, Sarah, was his sister. Because of this, the king of Gerar took Sarah so that she would become his wife. The king's name was Abimelech."
    },
    {
      "verse": "3",
      "text": "But God appeared to Abimelech in a dream. He said to Abimelech, ‘Now you will die! The woman that you have taken to be your wife is already a married woman. ’"
    },
    {
      "verse": "4",
      "text": "But Abimelech had not yet touched Sarah. He said to God, ‘Lord, I have not done anything wrong. Surely you will not destroy me and my people."
    },
    {
      "verse": "5",
      "text": "Abraham told me that Sarah was his sister. And she herself said, “I am his sister. ” So I am not guilty! I did not think that I was doing a bad thing. ’"
    },
    {
      "verse": "6",
      "text": "God spoke to Abimelech again in a dream. He said, ‘That is true. You did not think that you were doing something wrong. I know that. So I did not let you touch her. I stopped you from doing anything wrong against me."
    },
    {
      "verse": "7",
      "text": "You must now give her back to her husband. He is a prophet and he will pray for you. Because of that, you will not die. But if you do not give her back, you and all your people will surely die. ’"
    },
    {
      "verse": "8",
      "text": "Early the next morning, Abimelech called together his officers. He told them what had happened. When the officers heard about it, they were very afraid."
    },
    {
      "verse": "9",
      "text": "Abimelech called Abraham to come to him. He said to Abraham, ‘Why have you done this bad thing against us? I have not done anything wrong against you. Now you have made me and the people in my kingdom guilty of a very bad thing. Nobody should ever do the things that you have done to me. ’"
    },
    {
      "verse": "10",
      "text": "Abimelech asked Abraham, ‘What caused you to do this? ’"
    },
    {
      "verse": "11",
      "text": "Abraham replied, ‘I did it because I was afraid. I thought, “The people here do not respect God. They will kill me so that they can take my wife from me. ”"
    },
    {
      "verse": "12",
      "text": "And also, she really is my sister. She is the daughter of my father. But she is not the daughter of my mother. And she became my wife."
    },
    {
      "verse": "13",
      "text": "God told me to leave my father's house and to travel. At that time I said to Sarah, “This is how you can show that you love me. Everywhere we go, tell people that I am your brother. ” ’"
    },
    {
      "verse": "14",
      "text": "Then Abimelech brought sheep and cows to give to Abraham. He also gave to Abraham male and female servants. And he gave Sarah back to Abraham."
    },
    {
      "verse": "15",
      "text": "Abimelech said, ‘Look! See my land all round you. Go and live anywhere that you want to live. ’"
    },
    {
      "verse": "16",
      "text": "Abimelech said to Sarah, ‘I have given 1, 000 pieces of silver to your brother. This is to show everyone that you yourself did nothing wrong. It will pay you for any trouble that you have received. ’"
    },
    {
      "verse": "17",
      "text": "Then Abraham prayed to God. As a result, God made Abimelech become well again. He also made Abimelech's wife and his female slaves become well, so that they could have children again."
    },
    {
      "verse": "18",
      "text": "The Lord had made them unable to have children. He did this because of what happened to Abraham's wife, Sarah."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "The Lord was kind to Sarah. He did what he had promised to do for her."
    },
    {
      "verse": "2",
      "text": "Sarah became pregnant. She gave birth to a son for Abraham when he was very old. This happened at the time when God had said that it would."
    },
    {
      "verse": "3",
      "text": "Abraham called his son ‘Isaac’. This is the son that Sarah gave birth to."
    },
    {
      "verse": "4",
      "text": "When Isaac was eight days old, Abraham circumcised him. That is what God had told him to do."
    },
    {
      "verse": "5",
      "text": "years old when his son, Isaac, was born."
    },
    {
      "verse": "6",
      "text": "Sarah said, ‘Now God has made me laugh. Everyone who hears about what has happened will be happy with me. ’"
    },
    {
      "verse": "7",
      "text": "She also said, ‘Abraham would never have thought that I would feed a child at my breasts. But I have given birth to a son for him, even when he is old. ’"
    },
    {
      "verse": "8",
      "text": "The child grew stronger, and he began to eat food. On that day, Abraham prepared a big party meal."
    },
    {
      "verse": "9",
      "text": "Then Sarah saw that Ishmael was laughing at Isaac. (Ishmael was the son of Abraham and Hagar, the Egyptian servant. )"
    },
    {
      "verse": "10",
      "text": "So Sarah said to Abraham, ‘Send that slave woman and her son away from here. Ishmael must never receive any of our family's things. Everything must belong to my own son, Isaac. ’"
    },
    {
      "verse": "11",
      "text": "This made Abraham very sad, because Ishmael was his own son."
    },
    {
      "verse": "12",
      "text": "God said to Abraham, ‘Do not be upset about Ishmael or about Hagar. Do whatever Sarah tells you. Your family's descendants will come through Isaac, not Ishmael."
    },
    {
      "verse": "13",
      "text": "But, because Ishmael is also your son, I will make his descendants become a great nation of people too. ’"
    },
    {
      "verse": "14",
      "text": "Abraham woke up early the next morning. He took some food and some water in a bottle that was made from animal skin. He gave them to Hagar and he put them on her shoulders. Then he sent Hagar away, with their son, Ishmael. She went and she travelled round the wilderness of Beersheba."
    },
    {
      "verse": "15",
      "text": "After they had drunk all the water, Hagar put her son in the shade under a bush."
    },
    {
      "verse": "16",
      "text": "metres away from him. She thought, ‘I cannot watch the boy die. ’ As she sat there, she began to cry."
    },
    {
      "verse": "17",
      "text": "Ishmael was crying and God heard him. The angel of God spoke to Hagar from heaven. He said, ‘What is the trouble, Hagar? Do not be afraid. God has heard the boy while he is crying there."
    },
    {
      "verse": "18",
      "text": "Go over to him and lift him up. Take hold of his hand and help him to stand. I will make him become a great nation of people. ’"
    },
    {
      "verse": "19",
      "text": "Then God helped Hagar to see clearly. She saw a well with water in it. She went to the well and she filled the bottle with water. She gave the boy some water to drink."
    },
    {
      "verse": "20",
      "text": "God took care of Ishmael while he grew up. The boy lived in the desert. He became a hunter of wild animals."
    },
    {
      "verse": "21",
      "text": "He lived in the Paran wilderness. Hagar, his mother, found an Egyptian wife for him to marry."
    },
    {
      "verse": "22",
      "text": "At that time Phicol was the leader of King Abimelech's army. Abimelech and Phicol said to Abraham, ‘We see that God helps you in everything that you do."
    },
    {
      "verse": "23",
      "text": "So please make a promise to me in front of God. Promise that you will never deceive me, or my children, or my descendants. You are living here in this land as a stranger. I have been kind to you, so please show that you will also be kind to us. ’"
    },
    {
      "verse": "24",
      "text": "Abraham said, ‘I promise to do all that. ’"
    },
    {
      "verse": "25",
      "text": "One day, Abraham complained to Abimelech about a certain well of water. Abimelech's servants had taken the well from Abraham. They said that the well belonged to them."
    },
    {
      "verse": "26",
      "text": "Abimelech said, ‘I do not know who has done this. You did not tell me before. I did not hear about it until today. ’"
    },
    {
      "verse": "27",
      "text": "So Abraham brought some sheep and some cows and he gave them to Abimelech. The two men made a promise to help each other."
    },
    {
      "verse": "28",
      "text": "Abraham took seven female lambs from the sheep. He put them in a different place from the other animals."
    },
    {
      "verse": "29",
      "text": "Abimelech asked Abraham, ‘Why have you put these seven lambs in a different place? ’"
    },
    {
      "verse": "30",
      "text": "Abraham replied, ‘You must accept these seven lambs as a gift from me. That will show that you agree that I dug this well. Everyone will know that it belongs to me. ’"
    },
    {
      "verse": "31",
      "text": "Because of that, the name of the place became ‘Beersheba’, because the two men made a promise there."
    },
    {
      "verse": "32",
      "text": "In that way, they made a promise at Beersheba to help one another. Then Abimelech and Phicol, the leader of his army, returned to the land of the Philistines."
    },
    {
      "verse": "33",
      "text": "Abraham planted a tamarisk tree in Beersheba. In that place, he worshipped the Lord who is God for ever."
    },
    {
      "verse": "34",
      "text": "Abraham lived in the land of the Philistines for a long time."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "Some time later, God wanted to see if Abraham really trusted him. God said to him, ‘Abraham! ’ Abraham replied, ‘Here I am. ’"
    },
    {
      "verse": "2",
      "text": "God said, ‘Take your son and go to the land of Moriah. Take your only son Isaac, whom you love. You must offer him to me there as a burnt offering. I will show you the mountain where you must do this. ’"
    },
    {
      "verse": "3",
      "text": "Abraham got up early the next morning. He made his donkey ready for the journey. He took two servants with him, and also his son Isaac. First, he cut wood for the fire to make the burnt offering. Then he started on his journey to the place that God had told him."
    },
    {
      "verse": "4",
      "text": "On the third day of the journey, Abraham could see the place. It was not very far away."
    },
    {
      "verse": "5",
      "text": "He said to his servants, ‘Stay here with the donkey. I will take the boy and we will go over there. We will worship God in that place and then we will come back to you. ’"
    },
    {
      "verse": "6",
      "text": "Abraham took the wood for the burnt offering. He gave it to Isaac to carry. Abraham himself carried the fire and the knife. The two of them walked on together."
    },
    {
      "verse": "7",
      "text": "Isaac spoke to his father, Abraham. He said, ‘Father? ’ Abraham replied ‘Yes my son, what is it? ’ Isaac replied, ‘I see that the fire and the wood are here. But where is the lamb so that we can make the burnt offering? ’"
    },
    {
      "verse": "8",
      "text": "Abraham replied, ‘My son, God himself will bring the lamb for the burnt offering. ’The two of them continued to walk on together."
    },
    {
      "verse": "9",
      "text": "They came to the place that God told them. Abraham built an altar there. He put the wood on it, ready for the fire. Then he tied his son Isaac. He lifted him up and he put him on top of the wood on the altar."
    },
    {
      "verse": "10",
      "text": "Then Abraham took hold of the knife. He was ready to kill his son as a sacrifice."
    },
    {
      "verse": "11",
      "text": "But then the angel of the Lord spoke to Abraham from heaven. He said, ‘Abraham! Abraham! ’ Abraham replied, ‘Here I am. ’"
    },
    {
      "verse": "12",
      "text": "The angel said, ‘Do not hurt the boy! Do not do anything to him. Now I know that you respect God and you obey him. Isaac is your only son and you agreed to offer him to me as a sacrifice. You did not try to keep him safe. ’"
    },
    {
      "verse": "13",
      "text": "Just then, Abraham looked round and he saw a male sheep behind him. Its horns were caught in some bushes. So he went and he took hold of the sheep. Abraham killed the sheep on the altar as a burnt offering to God. In that way, he killed the sheep as a sacrifice, instead of his son."
    },
    {
      "verse": "14",
      "text": "Abraham called that place ‘The Lord will give me what I need. ’ People still say today, ‘On the mountain of the Lord, he will give us what we need. ’"
    },
    {
      "verse": "15",
      "text": "The angel of the Lord called from heaven to Abraham again."
    },
    {
      "verse": "16",
      "text": "The angel said, ‘This is what the Lord says: I promise that this is what I will do for you. You did not try to keep your son safe, but you offered him to me. And he was your only son."
    },
    {
      "verse": "17",
      "text": "Because you have done this, I will bless you. I will make your descendants become so many that people cannot count them. They will be as many as the stars that are in the sky. They will be as many as the pieces of sand on the shore by the sea. Your descendants will win against their enemies and their enemies' cities."
    },
    {
      "verse": "18",
      "text": "I will bless all the nations on the earth through your descendants. I will do this because you have obeyed me. ’"
    },
    {
      "verse": "19",
      "text": "Then Abraham returned to his servants, with Isaac. Together they all left to go to Beersheba. Abraham lived there for a time."
    },
    {
      "verse": "20",
      "text": "Later, someone told Abraham ‘Milcah also has given birth to children. Your brother Nahor is their father. ’"
    },
    {
      "verse": "21",
      "text": "The names of the children were: Uz, the son who was born first. Then his brother Buz. Then Kemuel, who is the father of Aram."
    },
    {
      "verse": "22",
      "text": "Then five more sons: Kesed, Hazo, Pildash, Jidlaph and Bethuel."
    },
    {
      "verse": "23",
      "text": "Bethuel later became the father of Rebekah. Those were the eight sons of Milcah and Abraham's brother, Nahor."
    },
    {
      "verse": "24",
      "text": "Nahor also had a slave wife. Her name was Reumah. She also gave birth to sons for Nahor. Their names were: Tebah, Gaham, Tahash and Maakah."
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "years."
    },
    {
      "verse": "2",
      "text": "She died in the land of Canaan, at Kiriath Arba. That place is also called Hebron. Abraham was very sad. He went to her tent and he cried very much, because she was dead."
    },
    {
      "verse": "3",
      "text": "Then Abraham went to the Hittite people and he said to them,"
    },
    {
      "verse": "4",
      "text": "‘I am living as a stranger among you. Please, sell me some land here, so that it belongs to me. Then I can use it to bury my wife properly. ’"
    },
    {
      "verse": "5",
      "text": "The Hittites replied,"
    },
    {
      "verse": "6",
      "text": "‘Sir, please listen to what we say. We respect you as a great and powerful person. We have good places where we bury our people who have died. Choose the best one that you like. None of us will refuse to give you the place that you choose. Then you will be able to bury your dead wife there. ’"
    },
    {
      "verse": "7",
      "text": "Abraham stood up. He turned his face towards the ground to respect the Hittites who lived in that place."
    },
    {
      "verse": "8",
      "text": "He said to them, ‘Since you have agreed to help me, please do this. Speak to Zohar's son, Ephron, for me."
    },
    {
      "verse": "9",
      "text": "Ask him to sell the cave of Machpelah to me. It belongs to Ephron. It is at the edge of his field. You will see that I pay the proper price to him. Then it will belong to me. I can bury my family there when they die. ’"
    },
    {
      "verse": "10",
      "text": "Ephron was sitting there with his people, at the city gate. He spoke so that all the Hittites could hear him."
    },
    {
      "verse": "11",
      "text": "Ephron said, ‘No sir. Please listen to me. You may take my field as well as the cave. I promise in front of my people that I will give all this to you. Then you can bury your dead wife there. ’"
    },
    {
      "verse": "12",
      "text": "Abraham again turned his face towards the ground to respect the people who lived in that place."
    },
    {
      "verse": "13",
      "text": "While they were listening, he said to Ephron, ‘Let me say this. I will pay you the price to buy the field. Please accept the money from me. Then I can bury my dead wife there. ’"
    },
    {
      "verse": "14",
      "text": "Ephron replied to Abraham,"
    },
    {
      "verse": "15",
      "text": "‘Listen to me, sir. The land is worth 400 shekels of silver. But the price is not important, because we are friends. Now bury your dead wife there. ’"
    },
    {
      "verse": "16",
      "text": "Abraham agreed to the price that Ephron had asked for. He weighed the correct amount of silver to give to Ephron. The Hittites there knew that it had been done properly. The weight of 400 shekels agreed with the weights that people used at that time."
    },
    {
      "verse": "17",
      "text": "In that way, Ephron's field in Machpelah, near Mamre, now belonged to Abraham. This included the field, the cave in the field and all the trees in the field as far as its edge."
    },
    {
      "verse": "18",
      "text": "All the Hittite people who were sitting there at the city gate agreed that Abraham was the new owner."
    },
    {
      "verse": "19",
      "text": "After this, Abraham buried his wife, Sarah, in the cave in the field of Machpelah. This field was near Mamre, in the land of Canaan. That place is also called Hebron."
    },
    {
      "verse": "20",
      "text": "That is how Abraham bought the field and the cave that was in it from the Hittite people. He bought it so that he could bury there his family who died."
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "Abraham was now a very old man. The Lord had blessed him in every way."
    },
    {
      "verse": "2",
      "text": "Abraham had an important servant in his house. He had authority over everything that belonged to Abraham. Abraham said to him, ‘Come here and make a promise to me. Put your hand between my legs to show that I can trust you."
    },
    {
      "verse": "3",
      "text": "You must make a serious promise to me in front of the Lord. He is the God who rules both heaven and earth. I am living among the Canaanite people, but you must promise this to me: Do not get a Canaanite woman to be a wife for my son."
    },
    {
      "verse": "4",
      "text": "Instead, you must go to my own country. Go to my family there to find a wife for my son Isaac. ’"
    },
    {
      "verse": "5",
      "text": "The servant asked Abraham, ‘What should I do if the woman will not agree? Maybe she will not come back with me to this land? Must I then take your son to the country that you came from? ’"
    },
    {
      "verse": "6",
      "text": "Abraham replied, ‘No! You must never take my son back there."
    },
    {
      "verse": "7",
      "text": "The Lord, the God of heaven, took me away from there. He took me out of my father's house. He took me away from the land where my family lives. God made a serious promise to me. He said, “I will give this land to your descendants. ” Because God has promised this, he will send his angel to go in front of you. When you arrive there, you will find a woman to marry my son."
    },
    {
      "verse": "8",
      "text": "But perhaps the woman will not agree to come back here with you. If that happens, you do not have to keep this promise. But do not take my son back to that land. ’"
    },
    {
      "verse": "9",
      "text": "So the servant put his hand between Abraham's legs. The servant promised that he would do everything that Abraham had told him."
    },
    {
      "verse": "10",
      "text": "After that, Abraham's servant left to go on his journey. He took with him ten of his master's camels. He also took many different kinds of valuable gifts that Abraham had given to him. He travelled towards Aram Naharaim. He arrived in the town of Nahor."
    },
    {
      "verse": "11",
      "text": "Abraham's servant stopped outside the town. He made the camels go down on their knees near a well. It was the evening time, when women came to the well to get water."
    },
    {
      "verse": "12",
      "text": "The servant prayed to God. He prayed, ‘Lord, God of Abraham, my master, please be my guide today. Be kind to my master Abraham, as you have promised him."
    },
    {
      "verse": "13",
      "text": "See, I am standing here near this well. The daughters of the people who live in the town will come to get water from the well."
    },
    {
      "verse": "14",
      "text": "I will say to one of the young women, “Please let me have a drink of water from your pot. ” If she is the right woman for your servant Isaac to marry, please may she say, “Yes, drink. Then I will give water to your camels also”. If that happens, then I will know that you have kept your promise to my master. ’"
    },
    {
      "verse": "15",
      "text": "The servant was still praying when Rebekah came to the well. She had her pot on her shoulder. Rebekah was the daughter of Bethuel, who was the son of Milcah. Milcah was the wife of Abraham's brother, Nahor."
    },
    {
      "verse": "16",
      "text": "The young woman was very beautiful. She had not had sex with any man. She went down to the well. She filled her pot with water and she came back up again."
    },
    {
      "verse": "17",
      "text": "Abraham's servant hurried to meet her. He said, ‘Please give me a little water to drink from your pot. ’"
    },
    {
      "verse": "18",
      "text": "She replied, ‘Yes sir, please drink. ’ She quickly took the pot down from her shoulders. She held the pot with her hands and gave him a drink."
    },
    {
      "verse": "19",
      "text": "After she had done that, she said, ‘Now I will get some water for your camels too. I will do this until they have drunk as much water as they want. ’"
    },
    {
      "verse": "20",
      "text": "So Rebekah quickly poured the water from her pot into the place where the animals drank. She ran back to the well to get more water. She did this until the camels had drunk enough."
    },
    {
      "verse": "21",
      "text": "Abraham's servant watched the girl, but he did not say anything. He wanted to know if the Lord had helped him to find a wife for Isaac."
    },
    {
      "verse": "22",
      "text": "The camels finished drinking. Then Abraham's servant took out a valuable gold nose ring. It weighed one half shekel. He also took out two large gold rings for Rebekah's arms. They weighed 10 shekels each."
    },
    {
      "verse": "23",
      "text": "The servant gave them to Rebekah and he asked her, ‘Whose daughter are you? Please tell me. Is there a room in your father's house for me and my men to sleep there tonight? ’"
    },
    {
      "verse": "24",
      "text": "Rebekah replied ‘I am the daughter of Bethuel. Nahor is his father, and Milcah is his mother."
    },
    {
      "verse": "25",
      "text": "We have plenty of grass and food for the camels. And there is a room for you to stay with us for the night. ’"
    },
    {
      "verse": "26",
      "text": "Then the man turned his face towards the ground. He worshipped the Lord."
    },
    {
      "verse": "27",
      "text": "He said, ‘I praise the Lord who is the God of my master, Abraham. He has been very kind to my master. He has done what he promised to do for him. The Lord has been kind to me too. He has led me here to the house of my master's family. ’"
    },
    {
      "verse": "28",
      "text": "Rebekah quickly ran back home. She told her mother and her family about what had happened."
    },
    {
      "verse": "29",
      "text": "Rebekah had a brother. His name was Laban."
    },
    {
      "verse": "30",
      "text": "Laban saw the nose ring and the arm rings that Rebekah was wearing. Rebekah told him what the man had said to her. So Laban went out quickly to the well to meet the servant. He found him standing near the well, together with his camels."
    },
    {
      "verse": "31",
      "text": "Laban said to him, ‘The Lord has blessed you! You should not continue to stand out here. Come with me. I have prepared a room for you in my house. There is also a place for your camels. ’"
    },
    {
      "verse": "32",
      "text": "So Abraham's servant went with Laban to the house. They took the luggage off the camels. Someone brought grass and food for the camels. They also brought water so that Abraham's servant and his men could wash their feet."
    },
    {
      "verse": "33",
      "text": "They prepared food for the servant but he said, ‘I will not eat yet. First I must tell you why I have come here. ’ Laban said, ‘Please tell us. ’"
    },
    {
      "verse": "34",
      "text": "So the servant said, ‘I am Abraham's servant."
    },
    {
      "verse": "35",
      "text": "The Lord has blessed my master very much, so that he has become very rich. The Lord has given him sheep and cows, and silver and gold. He has also given him male servants and female servants, camels and donkeys."
    },
    {
      "verse": "36",
      "text": "Sarah is my master's wife. She has given birth to a son for him, even when she was very old. My master has given his son everything that belongs to him."
    },
    {
      "verse": "37",
      "text": "My master told me to make a serious promise to him. He said, “I live as a stranger among the Canaanite people. But you must not get a Canaanite woman to be a wife for my son."
    },
    {
      "verse": "38",
      "text": "Instead, go to the land where my father lived and find a wife for my son from among my family there. ”"
    },
    {
      "verse": "39",
      "text": "So I asked my master, “What should I do if the woman will not return with me? ”"
    },
    {
      "verse": "40",
      "text": "My master said “I have lived to please the Lord. He will send his angel to go with you. You will find a wife for my son, because the Lord will help you. You will find a wife for him from among my own family."
    },
    {
      "verse": "41",
      "text": "Go to the place where my family group live. If they refuse to let you take her, you will no longer have to keep your promise to me. ”"
    },
    {
      "verse": "42",
      "text": "I arrived at the town well today. I prayed, “Lord, God of my master Abraham, please help me to find a wife for my master's son. This is why I have travelled here."
    },
    {
      "verse": "43",
      "text": "See, I am standing here near this well. If a young woman comes to get water, I will say to her, ‘Please let me drink some water from your pot. ’"
    },
    {
      "verse": "44",
      "text": "If she is the woman that the Lord has chosen to marry my master's son, please may she say to me, ‘Yes, drink. Then I will also get some water for your camels to drink. ’ ”"
    },
    {
      "verse": "45",
      "text": "While I was still praying quietly, Rebekah came to the well. She carried her pot on her shoulder. She went down to the well, and got some water. Then I said to her “Please give me some water to drink. ”"
    },
    {
      "verse": "46",
      "text": "She quickly took her pot down from her shoulder. She said, “Drink. Then I will get water for your camels too. ” So I drank. And she also gave water to the camels."
    },
    {
      "verse": "47",
      "text": "I asked her, “Whose daughter are you? ” She said, “I am the daughter of Bethuel. Nahor is his father and Milcah is his mother. ” When I heard that, I put the ring in her nose. I put the rings on her arms."
    },
    {
      "verse": "48",
      "text": "I turned my face towards the ground and I worshipped the Lord. I praised the Lord, the God of my master, Abraham. The Lord led me to the right place so that I met the granddaughter of my master's brother. The Lord has led me to her, for my master's son."
    },
    {
      "verse": "49",
      "text": "So tell me what you will say. If you will show true love to my master, then please say, “Yes. ” But if not, then tell me. Then I will know what to do. ’"
    },
    {
      "verse": "50",
      "text": "Laban and Bethuel replied, ‘We know that the Lord has caused all this to happen. So what we ourselves say is not important."
    },
    {
      "verse": "51",
      "text": "Here is Rebekah. Take her with you to become the wife of your master's son. That is what the Lord has shown to be right. ’"
    },
    {
      "verse": "52",
      "text": "When Abraham's servant heard their answer, he turned his face towards the ground to thank the Lord."
    },
    {
      "verse": "53",
      "text": "He brought his master's gifts to give them to Rebekah. They were valuable things made from gold and silver, as well as beautiful clothes. He also gave valuable things to her brother and to her mother."
    },
    {
      "verse": "54",
      "text": "After that, the servant ate a meal. The men who were with him also ate and drank. They stayed there for the night. When they woke up the next morning, the servant said, ‘Let me leave now so that I can go back to my master. ’"
    },
    {
      "verse": "55",
      "text": "Rebekah's brother and her mother replied, ‘Please let Rebekah stay with us for a few more days. After about ten days, she can go with you. ’"
    },
    {
      "verse": "56",
      "text": "But the servant said, ‘Do not make me stay longer. The Lord has given me what I came here for. Let me leave now so that I can go back to my master. ’"
    },
    {
      "verse": "57",
      "text": "Rebekah's brother and mother said, ‘Let us call the girl. We can ask her what she wants to do. ’"
    },
    {
      "verse": "58",
      "text": "So they called Rebekah to come. They asked her, ‘Will you go with this man now? ’ Rebekah said, ‘Yes, I will go. ’"
    },
    {
      "verse": "59",
      "text": "So they agreed to let their sister Rebekah go. Her nurse went with her. They left there with Abraham's servant, and his men. ‘Our sister, may you become the mother of millions of descendants. May your descendants win against their enemies, and may they go into their enemies' cities. ’"
    },
    {
      "verse": "60",
      "text": "As Rebekah was leaving, her brother and her mother blessed her. They said, ‘Our sister, may you become the mother of millions of descendants. May your descendants win against their enemies, and may they go into their enemies' cities. ’"
    },
    {
      "verse": "61",
      "text": "Then Rebekah and her female servants left there, together with Abraham's servant. They took camels to ride on. That was how the servant took Rebekah and left."
    },
    {
      "verse": "62",
      "text": "At this time Isaac had returned from Beer Lahai Roi. He was now living in the Negev."
    },
    {
      "verse": "63",
      "text": "It was evening time. Isaac went out to walk in the fields. He looked up and he saw some camels. They were coming towards him."
    },
    {
      "verse": "64",
      "text": "Rebekah also looked up and she saw Isaac. She got down from her camel."
    },
    {
      "verse": "65",
      "text": "She asked Abraham's servant, ‘I see a man in the field who is coming towards us. Who is he? ’ The servant replied, ‘He is my master’. Rebekah covered her face with a piece of cloth."
    },
    {
      "verse": "66",
      "text": "Then the servant told Isaac everything that happened."
    },
    {
      "verse": "67",
      "text": "Isaac took Rebekah into the tent that his mother Sarah had lived in. Rebekah became Isaac's wife. And Isaac loved Rebekah. So Isaac was happy again, after the death of his mother."
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "Abraham then married another woman. Her name was Keturah."
    },
    {
      "verse": "2",
      "text": "She gave birth to Zimran, Jokshan, Medan, Midian, Ishbak and Shuah."
    },
    {
      "verse": "3",
      "text": "Jokshan later became the father of Sheba and Dedan. The descendants of Dedan were the Asshurites, the Letushites and the Leummites."
    },
    {
      "verse": "4",
      "text": "Midian had sons who were called Ephah, Epher, Hanoch, Abida and Eldaah. All those were descendants of Abraham's wife, Keturah."
    },
    {
      "verse": "5",
      "text": "When Abraham died, he left everything that belonged to him to Isaac."
    },
    {
      "verse": "6",
      "text": "But while he was still alive, he gave gifts to the sons of his slave wives. He sent these sons away to the land of the east. He wanted to keep them far away from Isaac."
    },
    {
      "verse": "7",
      "text": "years. So they buried Abraham there. It was in the cave where his wife, Sarah, had also been buried."
    },
    {
      "verse": "8",
      "text": "He died after a good and long life, when he was very old. He joined his ancestors who had died before him."
    },
    {
      "verse": "9",
      "text": "His sons, Isaac and Ishmael, buried his body in the cave of Machpelah. That was near Mamre. The cave is in the field that belonged to Zohar's son, Ephron. He was a Hittite."
    },
    {
      "verse": "10",
      "text": "Abraham had bought the field from the Hittites. So they buried Abraham there. It was in the cave where his wife, Sarah, had also been buried."
    },
    {
      "verse": "11",
      "text": "After Abraham's death, God blessed his son, Isaac. Isaac was living near Beer Lahai Roi."
    },
    {
      "verse": "12",
      "text": "This is the report about Abraham's son, Ishmael, and his family. Sarah's female servant gave birth to Ishmael. Her name was Hagar. She was from Egypt."
    },
    {
      "verse": "13",
      "text": "These are the names of Ishmael's sons. The list starts from the firstborn son and ends with the last son. Nebaioth was the first son of Ishmael. Then there were Kedar, Adbeel, Mibsam,"
    },
    {
      "verse": "14",
      "text": "Mishma, Dumah, Massa,"
    },
    {
      "verse": "15",
      "text": "Hadad, Tema, Jetur, Naphish and Kedemah."
    },
    {
      "verse": "16",
      "text": "These were all Ishmael's sons. Their names became the names of 12 groups of people. They separated and lived in their own lands. Ishmael's sons ruled over the 12 groups of people."
    },
    {
      "verse": "17",
      "text": "years then he died. He joined his ancestors who had died before him."
    },
    {
      "verse": "18",
      "text": "Ishmael's descendants lived in the lands from Havilah to Shur. These are near Egypt, towards Asshur. They were always at war with each other."
    },
    {
      "verse": "19",
      "text": "This is the report about Abraham's son, Isaac, and his family. Abraham became the father of Isaac."
    },
    {
      "verse": "20",
      "text": "years old, he married Rebekah. Rebekah was the daughter of Bethuel. Bethuel was an Aramean from Paddan Aram. She was the sister of Laban the Aramean."
    },
    {
      "verse": "21",
      "text": "Rebekah could not have children. So Isaac prayed to the Lord for Rebekah. The Lord did as Isaac asked. And Isaac's wife, Rebekah, became pregnant."
    },
    {
      "verse": "22",
      "text": "The babies inside her were fighting with each other. Rebekah said, ‘Why is this happening to me? ’ So Rebekah went to ask the Lord."
    },
    {
      "verse": "23",
      "text": "The Lord said to Rebekah, ‘The two children who are in your body will become two separate nations of people. One group will be stronger than the other. The older son will become a servant to the younger son. ’"
    },
    {
      "verse": "24",
      "text": "The time came for Rebekah to give birth. There were two babies inside her."
    },
    {
      "verse": "25",
      "text": "The first baby to come out had a red body. Hair covered the whole of his body. They called him Esau."
    },
    {
      "verse": "26",
      "text": "After this, his brother came out. His hand was holding the back of Esau's foot. They called him Jacob. Isaac was 60 years old when Rebekah gave birth to them."
    },
    {
      "verse": "27",
      "text": "Time passed and the boys grew. Esau became a good hunter, out in the fields. Jacob was a quiet man. He stayed near to the tents."
    },
    {
      "verse": "28",
      "text": "Isaac liked to eat the meat from the animals that Esau killed. So he loved Esau. But Rebekah loved Jacob."
    },
    {
      "verse": "29",
      "text": "One day, Jacob was cooking a meal. Esau came back from the country. He was very hungry."
    },
    {
      "verse": "30",
      "text": "He said to Jacob ‘Quick, let me have some of that red food! I am very hungry. ’ (That is why he was also called Edom. )"
    },
    {
      "verse": "31",
      "text": "Jacob said, ‘You must first sell me your birthright. ’"
    },
    {
      "verse": "32",
      "text": "Esau said, ‘Look, I am so hungry that I will die. Then my birthright will not help me at all! ’"
    },
    {
      "verse": "33",
      "text": "Jacob said, ‘First, make a serious promise to me. ’ So Esau promised to sell his birthright to Jacob. In that way, Esau showed that he did not think that his birthright was important."
    },
    {
      "verse": "34",
      "text": "Then Jacob gave Esau some bread and the soup made from grains. Esau ate the food and he drank. Then he got up and he left. In that way, Esau showed that he did not think that his birthright was important."
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "There was another famine in the land. This had happened before, when Abraham was alive. Now Isaac went to Gerar to visit Abimelech, the king of the Philistines."
    },
    {
      "verse": "2",
      "text": "The Lord appeared to Isaac. He said, ‘Do not go to Egypt. Instead, live in the land that I will show to you."
    },
    {
      "verse": "3",
      "text": "Stay in this land, and I will be with you. I will bless you. I will give these lands to you and your descendants. I made a strong promise to your father Abraham. I will make that promise become true."
    },
    {
      "verse": "4",
      "text": "I will give you many descendants. They will be as many as the stars in the sky. And I will give these lands to them. Because of your descendants, I will bless everyone on the earth."
    },
    {
      "verse": "5",
      "text": "This will happen because Abraham obeyed me. He obeyed all my laws and rules, and he did what I told him to do. ’"
    },
    {
      "verse": "6",
      "text": "So Isaac stayed in Gerar."
    },
    {
      "verse": "7",
      "text": "The men of Gerar asked Isaac about his wife. He told them, ‘She is my sister. ’ He was afraid to say, ‘She is my wife. ’ He thought that the men of Gerar might kill him because Rebekah was very beautiful."
    },
    {
      "verse": "8",
      "text": "Isaac stayed in Gerar for a long time. One day Abimelech, the king of the Philistines, looked down from his window. He saw that Isaac was kissing Rebekah."
    },
    {
      "verse": "9",
      "text": "Abimelech called Isaac to come to him. He said, ‘Rebekah is your wife! Why did you say, “She is my sister”? ’ Isaac replied, ‘I thought that someone might kill me because of her. ’"
    },
    {
      "verse": "10",
      "text": "Abimelech said, ‘You have done a bad thing against us! One of my men might have had sex with your wife. Then we would have been guilty of a bad sin. ’"
    },
    {
      "verse": "11",
      "text": "So Abimelech told his people, ‘I will kill anyone who hurts this man, or his wife. ’"
    },
    {
      "verse": "12",
      "text": "Isaac planted crops in the land and they grew very well. They made 100 times the amount of food that he had planted. This was because the Lord blessed him."
    },
    {
      "verse": "13",
      "text": "Isaac became rich. His riches continued to grow so that he became a very important person."
    },
    {
      "verse": "14",
      "text": "He had many sheep, goats and cows. He also had many servants in his house. He had so many servants that the Philistines became jealous of him."
    },
    {
      "verse": "15",
      "text": "So they took dirt from the ground and they filled up Isaac's wells. When Abraham was alive, his servants had dug these wells to get water."
    },
    {
      "verse": "16",
      "text": "Abimelech said to Isaac ‘You have become too powerful for us. Go and live somewhere else. ’"
    },
    {
      "verse": "17",
      "text": "So Isaac moved away from that place. He put his tents in the Valley of Gerar and he stayed there."
    },
    {
      "verse": "18",
      "text": "Isaac dug the dirt out of the wells that Abraham had dug. After Abraham died the Philistines had filled them with dirt. Isaac gave these wells the same names as his father had given them."
    },
    {
      "verse": "19",
      "text": "Isaac's servants went to dig in the valley. They found another well there. It was full of fresh water."
    },
    {
      "verse": "20",
      "text": "But the shepherds of Gerar quarrelled with Isaac's shepherds. They said, ‘The water belongs to us! ’ So Isaac called that well Esek, because they quarrelled with him there."
    },
    {
      "verse": "21",
      "text": "So Isaac's servants dug another well. But the shepherds of Gerar quarrelled about that one too. Isaac called that well Sitnah."
    },
    {
      "verse": "22",
      "text": "Isaac moved away from Sitnah and he dug another well. No one quarrelled with him about this well. So he called it Rehoboth. He said, ‘Now the Lord has given us a place to live. We will have many good things in this land. ’"
    },
    {
      "verse": "23",
      "text": "From that place, Isaac went to Beersheba."
    },
    {
      "verse": "24",
      "text": "That night the Lord appeared to him. The Lord said, ‘I am the God of your father Abraham. Do not be afraid, because I am with you. I will bless you. I will give you many descendants because of my servant Abraham. ’"
    },
    {
      "verse": "25",
      "text": "Isaac built an altar there and he worshipped the Lord. He put up his tent there. His servants dug a well."
    },
    {
      "verse": "26",
      "text": "During that time, Abimelech came from Gerar to visit Isaac. He came with Ahuzzath his officer and with Phicol the leader of his army."
    },
    {
      "verse": "27",
      "text": "Isaac asked them, ‘Why have you come to me? You hated me and you sent me away from you. ’"
    },
    {
      "verse": "28",
      "text": "They replied, ‘We saw that the Lord is with you. So we said to one another, “There should be an agreement between us and you. ” So let us promise to be friends."
    },
    {
      "verse": "29",
      "text": "Promise that you will not hurt us. We did not hurt you. We did only good things for you. We sent you away as friends. Now the Lord is blessing you. ’"
    },
    {
      "verse": "30",
      "text": "Then Isaac made a large meal for them. And they all ate happily together."
    },
    {
      "verse": "31",
      "text": "Early the next morning, they promised each other to be friends. Then Isaac said ‘goodbye’ to them. They left as his friends."
    },
    {
      "verse": "32",
      "text": "The same day, Isaac's servants came to him. They told him about a well that they had dug. They said, ‘We have found water! ’"
    },
    {
      "verse": "33",
      "text": "Isaac called the well Shibah. So the town is still called Beersheba."
    },
    {
      "verse": "34",
      "text": "years old, he got married. He married Judith. She was the daughter of Beer the Hittite. He also married Basemath. She was the daughter of Elon the Hittite."
    },
    {
      "verse": "35",
      "text": "Esau's wives brought a lot of trouble to Isaac and Rebekah."
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "Isaac became old. He could not see anything because his eyes were weak. He called for his older son, Esau. Isaac said, ‘My son. ’ Esau replied, ‘Yes, I am here. ’"
    },
    {
      "verse": "2",
      "text": "Isaac said, ‘I am an old man. I may die very soon."
    },
    {
      "verse": "3",
      "text": "Get your bow and your arrows. Go out into the country and kill some wild animals for me."
    },
    {
      "verse": "4",
      "text": "Then prepare the food that I like to eat. Bring it to me so that I can eat it. Then I will give you my blessing before I die. ’"
    },
    {
      "verse": "5",
      "text": "Rebekah listened to what Isaac said to Esau. She waited until Esau went out to the country to kill an animal and bring back the meat."
    },
    {
      "verse": "6",
      "text": "Then she said to Jacob, ‘I heard your father say this to Esau:"
    },
    {
      "verse": "7",
      "text": "“Bring me some meat and prepare the food that I like to eat. When I have eaten it, I will give you my blessing. I will bless you in front of the Lord before I die. ”"
    },
    {
      "verse": "8",
      "text": "Now my son, listen carefully and do as I tell you."
    },
    {
      "verse": "9",
      "text": "Go out to the animals and bring two goats to me. They must be very good young goats. Then I will prepare some food that your father likes to eat. I will cook the meat in the way that he likes."
    },
    {
      "verse": "10",
      "text": "Then take the food to your father. When he has eaten it, he will give you his blessing before he dies. ’"
    },
    {
      "verse": "11",
      "text": "Jacob said to his mother Rebekah, ‘That will be difficult. Hair covers my brother's skin. But my skin does not have any hair."
    },
    {
      "verse": "12",
      "text": "My father may touch me. Then he will know that I am deceiving him. He will not bless me. He will curse me instead. ’"
    },
    {
      "verse": "13",
      "text": "Jacob's mother said, ‘My son, the curse will happen to me, not you. Do what I say. Go and get the things that I told you. ’"
    },
    {
      "verse": "14",
      "text": "Jacob went and he got the goats. He brought them to his mother. She prepared some food in the way that Isaac liked to eat."
    },
    {
      "verse": "15",
      "text": "Then Rebekah took some of Esau's best clothes that were in her house. She put them on Jacob, her younger son."
    },
    {
      "verse": "16",
      "text": "She covered Jacob's hands with the skin from the goats. She also covered the part of his neck that had no hair."
    },
    {
      "verse": "17",
      "text": "Then she gave to Jacob the food that Isaac liked to eat. And she gave him some bread that she had made."
    },
    {
      "verse": "18",
      "text": "Jacob went to his father. He said, ‘My father. ’ Isaac replied ‘Yes, my son. Who are you, Esau or Jacob? ’"
    },
    {
      "verse": "19",
      "text": "Jacob said, ‘I am Esau. I am your firstborn son. I have done as you told me. Please sit up. Eat some of the meat from the wild animal that I killed. Then you can bless me. ’"
    },
    {
      "verse": "20",
      "text": "Isaac asked his son, ‘My son, how did you find it so quickly? ’ Jacob replied, ‘The Lord your God helped me find it. ’"
    },
    {
      "verse": "21",
      "text": "Isaac said to Jacob, ‘Come near to me so that I can touch you, my son. Then I will know if you really are my son Esau. ’"
    },
    {
      "verse": "22",
      "text": "Jacob went near to his father. Isaac touched him and he said, ‘The voice is Jacob's voice. But the hands are Esau's hands. ’"
    },
    {
      "verse": "23",
      "text": "Isaac did not know that it was Jacob because he could feel the hair on Jacob's hands. They felt like Esau's hands. So Isaac blessed Jacob."
    },
    {
      "verse": "24",
      "text": "Isaac asked again, ‘Are you really my son Esau? ’ Jacob replied, ‘I am. ’"
    },
    {
      "verse": "25",
      "text": "Isaac said, ‘My son, bring me some of your meat. I will eat it. Then I will bless you. ’ So Jacob brought the food to him and Isaac ate it. Jacob also brought some wine and Isaac drank it."
    },
    {
      "verse": "26",
      "text": "Then Isaac said, ‘Come here my son and kiss me. ’ ‘The smell of my son is like the smell of a field. It is like a field that the Lord has blessed."
    },
    {
      "verse": "27",
      "text": "So Jacob went to Isaac and kissed him. Isaac smelled the clothes that Jacob wore. Then Isaac blessed him. He said, ‘The smell of my son is like the smell of a field. It is like a field that the Lord has blessed."
    },
    {
      "verse": "28",
      "text": "May God give you rain for your crops, so that they grow well in the good ground. Then you will have plenty of grain for food. And you will have grapes to make wine. so that they grow well in the good ground. Then you will have plenty of grain for food. And you will have grapes to make wine."
    },
    {
      "verse": "29",
      "text": "May the people of many nations serve you. May they respect you as their master. You will rule over your brothers. Yes, your mother's sons will bend down to respect you. May God curse anyone who curses you. And may he bless anyone who blesses you. ’ May they respect you as their master. You will rule over your brothers. Yes, your mother's sons will bend down to respect you. May God curse anyone who curses you. And may he bless anyone who blesses you. ’"
    },
    {
      "verse": "30",
      "text": "When Isaac had blessed Jacob, Jacob left him. Just then, Esau came back from the country where he had killed an animal."
    },
    {
      "verse": "31",
      "text": "He prepared nice food that Isaac liked to eat. Then he took the food to his father, Isaac. Esau said, ‘My father, please sit up. Eat some of the meat from the wild animal that I have killed. Then you can bless me. ’"
    },
    {
      "verse": "32",
      "text": "His father Isaac asked, ‘Who are you? ’ Esau replied, ‘I am your firstborn son, Esau. ’"
    },
    {
      "verse": "33",
      "text": "Isaac's body shook very much. He asked, ‘Who was it who killed an animal and brought the meat to me? Just before you came, I ate all of it. And then I blessed him. And God will certainly bless him! ’"
    },
    {
      "verse": "34",
      "text": "Esau heard what his father had said and he cried aloud. He was very upset. He said, ‘My father, please bless me too! ’"
    },
    {
      "verse": "35",
      "text": "But Isaac said, ‘Your brother came to me. He deceived me and he took your blessing away from you. ’"
    },
    {
      "verse": "36",
      "text": "Esau said, ‘Yes, “Jacob” is the right name for him. He has cheated me twice. First he took my birthright. Now he has taken my blessing as well! ’ Then Esau asked his father, ‘You must still have some blessing left for me, don't you? ’"
    },
    {
      "verse": "37",
      "text": "Isaac replied, ‘I have made Jacob master over you. All his relatives will become his servants. I have given him crops and wine. So what can I still do to bless you, my son? ’"
    },
    {
      "verse": "38",
      "text": "Esau said, ‘My father, you surely have one blessing left for me. Please bless me too! ’ Then Esau wept loudly."
    },
    {
      "verse": "39",
      "text": "Isaac replied, ‘You will not live in a place where the ground gives good food. You will not have rain to make your crops grow. ‘You will not live in a place where the ground gives good food. You will not have rain to make your crops grow."
    },
    {
      "verse": "40",
      "text": "You will have to fight to get the things that you need. You will serve your brother as your master. But when you choose to turn against him, you will become free from his power over you. ’ You will serve your brother as your master. But when you choose to turn against him, you will become free from his power over you. ’"
    },
    {
      "verse": "41",
      "text": "Because Isaac had blessed Jacob, Esau hated his younger brother Jacob. Esau said quietly, ‘My father will die soon. When we have buried his body, I will kill my brother. ’"
    },
    {
      "verse": "42",
      "text": "Someone told Rebekah what her older son, Esau, had said. So she told her younger son, Jacob, to come to her. She said to him, ‘Your brother Esau wants to kill you, because of what you did to him."
    },
    {
      "verse": "43",
      "text": "Now my son, do what I tell you. Quickly go away from here. Go to my brother Laban who lives in Haran."
    },
    {
      "verse": "44",
      "text": "Live with him for a time. Stay there until your brother is not angry with you any longer."
    },
    {
      "verse": "45",
      "text": "He may forget what you did to him. Then I will send a message to you, so that you can come back from Haran. I do not want to lose both of my sons in one day. ’"
    },
    {
      "verse": "46",
      "text": "Then Rebekah said to Isaac, ‘I do not like living in the same place as Esau's wives. It makes me very upset, because they are Hittites. If Jacob marries one of the Hittite women who live in this land, I will be very sad. I would rather die! ’"
    }
  ],
  "28": [
    {
      "verse": "1",
      "text": "Isaac called Jacob to come to him. He blessed Jacob. He told him, ‘Do not marry a Canaanite woman."
    },
    {
      "verse": "2",
      "text": "Go now to Paddan Aram. Go to the house of your mother's father, Bethuel. Find a wife for yourself from there. Choose one of the daughters of your mother's brother, Laban."
    },
    {
      "verse": "3",
      "text": "I pray that God Almighty will bless you. I pray that he will give you many children, so that your descendants become a large nation of people."
    },
    {
      "verse": "4",
      "text": "May God bless you and your descendants with the good things that he promised to Abraham. The land that he promised to give to Abraham will then belong to you. That is the land where you now live as a foreign person. ’"
    },
    {
      "verse": "5",
      "text": "Isaac sent Jacob away and Jacob went to Paddan Aram. He went to stay with Laban, who was the son of Bethuel, the Aramean. Laban was the brother of Rebekah. Rebekah was the mother of Jacob and Esau."
    },
    {
      "verse": "6",
      "text": "Esau heard that Isaac had blessed Jacob and then sent him away to Paddan Aram. Isaac had told Jacob to find a woman from Paddan Aram that he would marry. Isaac had said to Jacob, ‘Do not marry a Canaanite woman. ’"
    },
    {
      "verse": "7",
      "text": "Esau saw that Jacob had obeyed his father and mother, and that he had gone to Paddan Aram."
    },
    {
      "verse": "8",
      "text": "So Esau then understood that his father, Isaac, did not like the Canaanite women."
    },
    {
      "verse": "9",
      "text": "So Esau went to visit Abraham's son, Ishmael. He married Ishmael's daughter, Mahalath, the sister of Nebaioth. When Esau married Mahalath, he kept his Canaanite wives as well."
    },
    {
      "verse": "10",
      "text": "Jacob left Beersheba and he went towards Haran."
    },
    {
      "verse": "11",
      "text": "He came to a place where he stayed for the night, because the sun had gone down. He took a stone and he put it under his head. Then he lay down and he went to sleep."
    },
    {
      "verse": "12",
      "text": "He had a dream. In the dream, he saw some steps. The steps went up from the earth into heaven. God's angels were going up and down the steps."
    },
    {
      "verse": "13",
      "text": "The Lord stood at the top of the steps. He said, ‘I am the Lord. I am the God of your grandfather Abraham, and the God of Isaac, your father. I will give the land that you are lying on to you and to your descendants."
    },
    {
      "verse": "14",
      "text": "Your descendants will be as many as the dust of the earth. They will go to the west and to the east. They will go to the north and to the south. Through you and your descendants I will bless all the families of people on the earth."
    },
    {
      "verse": "15",
      "text": "I am with you. I will take care of you wherever you go. I will bring you back to this land. I will not leave you until I have done what I promised to do for you. ’"
    },
    {
      "verse": "16",
      "text": "Jacob woke from his sleep. He thought, ‘The Lord is in this place and I did not know it. ’"
    },
    {
      "verse": "17",
      "text": "Jacob was afraid. He said, ‘How great this place is! This must be the house of God. This is the gate of heaven. ’"
    },
    {
      "verse": "18",
      "text": "Early in the morning Jacob got up. He took the stone that he had put under his head. He made it stand up straight in the ground. He poured oil on top of it."
    },
    {
      "verse": "19",
      "text": "Jacob called that place Bethel. Before that, the name of the place had been Luz."
    },
    {
      "verse": "20",
      "text": "Then Jacob made a promise to God. He said, ‘While I am on this journey, I want God to be with me and to take care of me. I want him to give me food to eat and clothes to wear."
    },
    {
      "verse": "21",
      "text": "Then I want to return to my father's house. If God keeps me safe, then the Lord will be my God."
    },
    {
      "verse": "22",
      "text": "This special stone that I have put here will be God's house. And from everything that God gives me, I will give God one tenth. ’"
    }
  ],
  "29": [
    {
      "verse": "1",
      "text": "Jacob continued on his journey. He came to the land where the people from the east live."
    },
    {
      "verse": "2",
      "text": "He saw a well in a field. Three groups of sheep lay near it. Shepherds took water from the well to give to their sheep. There was a large stone that covered the top of the well."
    },
    {
      "verse": "3",
      "text": "The shepherds waited until all the sheep were there together. Then they removed the stone from the top of the well. They gave their sheep water to drink, and then they put the stone back on the top of the well."
    },
    {
      "verse": "4",
      "text": "Jacob asked the shepherds, ‘My brothers, where are you from? ’ The shepherds replied, ‘We are from Haran. ’"
    },
    {
      "verse": "5",
      "text": "Jacob said, ‘Do you know Laban? He is Nahor's grandson. ’ The shepherds replied, ‘Yes, we know him. ’"
    },
    {
      "verse": "6",
      "text": "Jacob asked them, ‘Is he in good health? ’ They replied, ‘Yes, he is. Look. Here comes his daughter now, with their sheep. Her name is Rachel. ’"
    },
    {
      "verse": "7",
      "text": "Jacob said to them, ‘The sun is still high in the sky. It is not yet the right time to bring all the sheep together. So give them some water now. Then they can go back to the fields and eat more grass. ’"
    },
    {
      "verse": "8",
      "text": "The shepherds said, ‘We cannot do that. We have to wait until all the sheep are here together. Then we can remove the big stone from the well and we can give water to the sheep. ’"
    },
    {
      "verse": "9",
      "text": "When Jacob was speaking to the shepherds, Rachel arrived there. She brought her father's sheep with her. She was taking care of them."
    },
    {
      "verse": "10",
      "text": "Jacob saw Rachel. She was the daughter of his uncle Laban. Jacob saw that she had Laban's sheep with her. So Jacob went to the well and he removed the big stone. Then he gave water to Laban's sheep."
    },
    {
      "verse": "11",
      "text": "Then Jacob kissed Rachel. He began to weep loudly."
    },
    {
      "verse": "12",
      "text": "Jacob told Rachel that he was a relative of her father, Laban. He told her that he was Rebekah's son. So Rachel ran home to tell her father."
    },
    {
      "verse": "13",
      "text": "When Laban heard what Rachel said, he went quickly to meet Jacob, his sister's son. He put his arms round Jacob and he kissed him. Laban brought Jacob to his home. Jacob told Laban all his news."
    },
    {
      "verse": "14",
      "text": "Then Laban said, ‘Yes, you really are my own relative. ’ So Jacob stayed with Laban for a month."
    },
    {
      "verse": "15",
      "text": "Then Laban said to Jacob, ‘You should not work for me for nothing because you are my relative. Tell me what I should pay you. ’"
    },
    {
      "verse": "16",
      "text": "Laban had two daughters. The name of the older daughter was Leah. The name of the younger daughter was Rachel."
    },
    {
      "verse": "17",
      "text": "Leah had weak eyes. But Rachel's face and her body were beautiful."
    },
    {
      "verse": "18",
      "text": "Jacob loved Rachel. He said to Laban, ‘I will work for you for seven years. In return, I want to marry your younger daughter, Rachel. ’"
    },
    {
      "verse": "19",
      "text": "Laban said, ‘It is better for you to marry her than another man. Stay here with me. ’"
    },
    {
      "verse": "20",
      "text": "Jacob worked for seven years to have Rachel as his wife. But the years passed very quickly because Jacob loved Rachel very much. Seven years seemed like only a few days to Jacob."
    },
    {
      "verse": "21",
      "text": "After seven years, Jacob said to Laban, ‘Give me my wife. My time to work for you is finished and I want to marry her. ’"
    },
    {
      "verse": "22",
      "text": "Laban called all the people in that place to come together. He prepared a big meal for them to eat."
    },
    {
      "verse": "23",
      "text": "When evening came, Laban took his daughter Leah and he gave her to Jacob. Jacob slept that night with her as his wife."
    },
    {
      "verse": "24",
      "text": "Laban gave his female servant to Leah to be her servant. Her name was Zilpah."
    },
    {
      "verse": "25",
      "text": "When morning came, Jacob saw that he had slept with Leah! He said to Laban, ‘You have done a very bad thing to me! I worked for you to get Rachel as my wife. Why have you deceived me? ’"
    },
    {
      "verse": "26",
      "text": "Laban replied, ‘In our land, we do not give the younger daughter to a man first. We let the older daughter marry first."
    },
    {
      "verse": "27",
      "text": "So finish this week of Leah's marriage. Then we will give you Rachel to marry too. But you must work for another seven years. ’"
    },
    {
      "verse": "28",
      "text": "So Jacob did what Laban said. He finished the marriage week with Leah. Then Laban gave Rachel to Jacob to be his wife."
    },
    {
      "verse": "29",
      "text": "Laban gave his female servant Bilhah to Rachel to become her servant."
    },
    {
      "verse": "30",
      "text": "Jacob also slept with Rachel. He loved Rachel more than he loved Leah. He worked for Laban for seven more years."
    },
    {
      "verse": "31",
      "text": "The Lord saw that Jacob did not love Leah. So he let her become pregnant. But Rachel did not give birth to any children."
    },
    {
      "verse": "32",
      "text": "Leah became pregnant and she gave birth to a son. She called him Reuben. She said, ‘It is because the Lord has seen how sad I am. My husband will love me now because I have given birth to a son. ’"
    },
    {
      "verse": "33",
      "text": "Leah became pregnant again. She gave birth to another son. She said, ‘The Lord has given me another son because he knows that I am not loved. ’ She called this son Simeon."
    },
    {
      "verse": "34",
      "text": "Leah became pregnant again. Later, she gave birth to another son. She said, ‘Now I have given my husband three sons, so he will want to stay with me. ’ She called this son Levi."
    },
    {
      "verse": "35",
      "text": "Leah became pregnant again. She gave birth to another son. She said, ‘This time I will praise the Lord. ’ She called this son Judah. Then she stopped giving birth to children."
    }
  ],
  "30": [
    {
      "verse": "1",
      "text": "Rachel now knew that she could not give birth to any children for Jacob. So she became jealous of her sister. Rachel said to Jacob, ‘Please give me children. If not, I will die. ’"
    },
    {
      "verse": "2",
      "text": "Jacob became angry with Rachel. He said, ‘Am I God? God has stopped you from giving birth to children! ’"
    },
    {
      "verse": "3",
      "text": "Rachel said, ‘Take my servant Bilhah and have sex with her. Then she can have children on my behalf. Through her, I can have a family. ’"
    },
    {
      "verse": "4",
      "text": "So Rachel gave her servant Bilhah to Jacob to become his wife."
    },
    {
      "verse": "5",
      "text": "Bilhah became pregnant and she gave birth to a son for Jacob."
    },
    {
      "verse": "6",
      "text": "Rachel said, ‘God has shown that I am right. He has listened to me and he has given a son to me. ’ Because of this, she called the boy Dan."
    },
    {
      "verse": "7",
      "text": "Rachel's servant Bilhah became pregnant again. She gave birth to another son for Jacob."
    },
    {
      "verse": "8",
      "text": "Rachel said, ‘I have fought with my sister and I have won. ’ She called this son Naphtali."
    },
    {
      "verse": "9",
      "text": "Leah saw that she had stopped having children. So she gave her servant Zilpah to Jacob as a wife."
    },
    {
      "verse": "10",
      "text": "Zilpah became pregnant and she gave birth to a son for Jacob."
    },
    {
      "verse": "11",
      "text": "Leah said, ‘This is very good. ’ She called the boy Gad."
    },
    {
      "verse": "12",
      "text": "Leah's servant Zilpah gave Jacob another son."
    },
    {
      "verse": "13",
      "text": "Leah said, ‘I am very happy! Women will call me happy. ’ So she called this boy Asher."
    },
    {
      "verse": "14",
      "text": "It was the time for the harvest of wheat. Reuben went out and he found some mandrake plants in a field. He took them to his mother, Leah. Rachel said to Leah, ‘Please give me some of the mandrakes that your son gave to you. ’"
    },
    {
      "verse": "15",
      "text": "But Leah said to Rachel, ‘You took my husband from me. That was bad enough! Now you want to take my son's mandrakes too! ’ Rachel said, ‘OK. If you give me some of your son's mandrakes, Jacob can sleep with you tonight. ’"
    },
    {
      "verse": "16",
      "text": "In the evening, Jacob came in from the fields. Leah went out to meet him. She said, ‘You must sleep with me tonight. I have paid for you with my son's mandrakes. ’ So Jacob slept with Leah that night."
    },
    {
      "verse": "17",
      "text": "God listened to Leah and she became pregnant again. She gave birth to a fifth son for Jacob."
    },
    {
      "verse": "18",
      "text": "Leah said, ‘God has helped me because I gave my servant to Jacob as a wife. ’ She called her son Issachar."
    },
    {
      "verse": "19",
      "text": "Leah became pregnant again and she gave Jacob a sixth son."
    },
    {
      "verse": "20",
      "text": "Leah said, ‘God has given me this valuable gift. Now my husband will respect me because I have given him six sons. ’ She called this son Zebulun."
    },
    {
      "verse": "21",
      "text": "After some time, Leah became pregnant again. She gave birth to a daughter. She called her daughter Dinah."
    },
    {
      "verse": "22",
      "text": "Then God decided to help Rachel. He listened to her and he let her become pregnant."
    },
    {
      "verse": "23",
      "text": "She became pregnant and she gave birth to a son. Rachel said, ‘I am not ashamed any longer, because God has given me a son. ’"
    },
    {
      "verse": "24",
      "text": "Rachel called her son Joseph. She said, ‘I pray that the Lord will give me another son. ’"
    },
    {
      "verse": "25",
      "text": "After Rachel gave birth to Joseph, Jacob spoke to Laban. He said, ‘Let me go away now. I want to go home to my own land."
    },
    {
      "verse": "26",
      "text": "Let me take my wives and my children with me. I have worked for you so that I could have them. You must let me leave, because you know how much I have worked for you. ’"
    },
    {
      "verse": "27",
      "text": "Laban said to Jacob, ‘If you are happy with me then please stay here. I know that the Lord has blessed me because you are here with me. I have used magic to know that. ’"
    },
    {
      "verse": "28",
      "text": "Laban also said to Jacob, ‘Tell me how much I should pay you for your work. I will pay whatever you want. ’"
    },
    {
      "verse": "29",
      "text": "Jacob replied, ‘You know how much I have worked for you. You know that you have many more animals now, because I have taken care of them."
    },
    {
      "verse": "30",
      "text": "Before I came, you had only a few sheep and goats. Now you have many more valuable things. Wherever I have worked for you, the Lord has blessed you. But now I want to work to help my own family. I must do that soon. ’"
    },
    {
      "verse": "31",
      "text": "Laban asked, ‘What must I give to you? ’ Jacob replied, ‘You do not need to give me anything. But just do one thing for me. Then I will still take care of your animals. I will make sure that nothing bad happens to them."
    },
    {
      "verse": "32",
      "text": "Do this: Let me go among all your animals today. Let me remove any animal that has a mark on it or that has more than one colour on its skin. I will also take any black lambs. That is what you will give me for my work."
    },
    {
      "verse": "33",
      "text": "In the future, this will show that I am honest. You can check on my animals whenever you want to. I will only have sheep or goats that have marks on their skin, or black lambs. If I have any other animals, you may call me a robber. ’"
    },
    {
      "verse": "34",
      "text": "Laban said, ‘I agree to this. It will be as you have said. ’"
    },
    {
      "verse": "35",
      "text": "On that same day, Laban went to his animals. He quickly removed all the goats that had marks, both male and female goats. He also removed all the black lambs. He gave these animals to his sons to take care of them."
    },
    {
      "verse": "36",
      "text": "He sent those animals a long way away. It would take Jacob three days to reach them. While this was happening, Jacob was taking care of Laban's other animals."
    },
    {
      "verse": "37",
      "text": "Jacob took branches that he had cut from trees. He took them from poplar trees, almond trees and plane trees. He cut white lines on the branches. He stripped off the outside part of the wood to show white lines."
    },
    {
      "verse": "38",
      "text": "Then he put the branches in the place where there were big bowls of water for the animals to drink. They were in front of the animals when they came to drink. The animals could see the branches when it was the right time for them to have sex together."
    },
    {
      "verse": "39",
      "text": "When they had sex in front of the branches, they gave birth to babies that had skin with marks."
    },
    {
      "verse": "40",
      "text": "Jacob kept these lambs separate from Laban's animals. He took the rest of Laban's female animals to join with the animals that had marks or were black. In that way he got more animals that would belong to him. He kept them separate from Laban's animals."
    },
    {
      "verse": "41",
      "text": "Jacob waited until the stronger female animals were ready to have sex. Then he put the special branches in front of them, near the big bowls of water. Then these animals would see the branches when they had sex together."
    },
    {
      "verse": "42",
      "text": "But if the female animals were weak, he did not put the branches in front of them when they had sex. As a result, the weak animals would belong to Laban, but Jacob would keep the strong animals."
    },
    {
      "verse": "43",
      "text": "In this way, Jacob became very rich. Many sheep and goats belonged to him. He also had female servants and male servants, as well as camels and donkeys."
    }
  ],
  "31": [
    {
      "verse": "1",
      "text": "Jacob heard that Laban's sons were complaining about him. They were saying, ‘Jacob has taken everything that belonged to our father. He has taken things from our father and he has become rich himself. ’"
    },
    {
      "verse": "2",
      "text": "And Jacob could see that Laban was not as nice to him as he had been before."
    },
    {
      "verse": "3",
      "text": "Then the Lord said to Jacob, ‘Go back to the land where your father and grandfather lived. Go back to your relatives. I will be with you there. ’"
    },
    {
      "verse": "4",
      "text": "Jacob sent a message to Rachel and Leah. He said that they must come to the field where he was taking care of his animals."
    },
    {
      "verse": "5",
      "text": "Jacob said to them, ‘I see that your father is not as nice to me now as he was before. But the God of my father has been with me."
    },
    {
      "verse": "6",
      "text": "You know that I have worked very hard for your father. I have worked as well as I can."
    },
    {
      "verse": "7",
      "text": "But your father has cheated me many times. He has changed what I receive for my work at least ten times. But God has protected me from him."
    },
    {
      "verse": "8",
      "text": "Sometimes Laban said, “I will pay you with the animals that have different colours on their skin. ” If he said that, all the animals gave birth to babies with different colours on their skins. Sometimes he said, “I will pay you with the animals that have marks on them. ” Then all the animals gave birth to babies with marks on them."
    },
    {
      "verse": "9",
      "text": "In this way God took away your father's animals, and he gave them to me."
    },
    {
      "verse": "10",
      "text": "One night I had a dream. It was at the time when the animals were becoming pregnant. In the dream, I saw that the male goats had marks and different colours on their skin."
    },
    {
      "verse": "11",
      "text": "The angel of God spoke to me in the dream. He said, “Jacob. ” I replied, “Yes, here I am. ”"
    },
    {
      "verse": "12",
      "text": "The angel said, “Look carefully. See all the male goats that are having sex with the female goats. They all have marks and different colours on their skin. I am helping you because I have seen the bad things that Laban has done to you."
    },
    {
      "verse": "13",
      "text": "I am the God who appeared to you at Bethel. That is where you poured oil on the special stone and you made a promise to me. Now I am telling you to leave this land. Go back to the land where you were born. ” ’"
    },
    {
      "verse": "14",
      "text": "Rachel and Leah replied, ‘Our father will not give us anything more when he dies."
    },
    {
      "verse": "15",
      "text": "He now thinks of us like foreigners. You worked hard for him so that we could become your wives. He has cheated us as well as you!"
    },
    {
      "verse": "16",
      "text": "So everything that God has taken away from our father really belongs to us and to our children. So you must do everything that God has told you to do. ’"
    },
    {
      "verse": "17",
      "text": "So Jacob put his children and wives on his camels."
    },
    {
      "verse": "18",
      "text": "He put together all his animals and everything that he had received in Paddan Aram. He took them with him to go to the land of Canaan. He left to go back to his father Isaac."
    },
    {
      "verse": "19",
      "text": "Before they left, Laban had gone to cut the wool from his sheep. While he was away from the house, Rachel took the idols that Laban worshipped in his house."
    },
    {
      "verse": "20",
      "text": "Jacob deceived Laban the Aramean. He did not tell Laban that he was going away."
    },
    {
      "verse": "21",
      "text": "Jacob went away quickly and he took all his things. He went across the Euphrates river. He went towards the hill country of Gilead."
    },
    {
      "verse": "22",
      "text": "After three days, someone told Laban that Jacob had gone away."
    },
    {
      "verse": "23",
      "text": "So Laban took his relatives with him and he followed Jacob. After seven days, he found him in the hill country of Gilead."
    },
    {
      "verse": "24",
      "text": "Then God appeared to Laban the Aramean in a dream at night. God warned him, ‘Be careful what you say to Jacob. Do not say anything good or bad to him. ’"
    },
    {
      "verse": "25",
      "text": "Jacob had put up his tent in the hill country of Gilead. That is where Laban found him. So Laban and his relatives also put up their tents in that place."
    },
    {
      "verse": "26",
      "text": "Laban said to Jacob, ‘Why did you do that? You have deceived me. You have taken my daughters away as if you had caught them in a war."
    },
    {
      "verse": "27",
      "text": "Why did you go away secretly? Yes, you have deceived me. You should have told me that you were leaving. Then I would have prepared a big meal. We would have been happy together, with songs and music."
    },
    {
      "verse": "28",
      "text": "But you did not even let me say “goodbye” to my daughters or my grandchildren. What you have done is not right."
    },
    {
      "verse": "29",
      "text": "I have the power to hurt you. But last night the God of your father appeared to me. He told me, “Be careful what you say to Jacob. Do not say anything good or bad against him. ”"
    },
    {
      "verse": "30",
      "text": "I know that you want very much to return to your father's house. That is why you have left my home. But why did you take my idols? ’"
    },
    {
      "verse": "31",
      "text": "Jacob replied, ‘I left secretly because I was afraid. I thought that you might fight me to take your daughters away from me. Jacob did not know that Rachel had taken her father's idols."
    },
    {
      "verse": "32",
      "text": "But if you find your idols with anyone here, that person must die. While our relatives watch, you may look for anything that belongs to you. If you find anything then take it. ’Jacob did not know that Rachel had taken her father's idols."
    },
    {
      "verse": "33",
      "text": "So Laban went into Jacob's tent. Then he went into Leah's tent. He also went into the female servants' tent. But he did not find the idols. When he left Leah's tent, he went into Rachel's tent."
    },
    {
      "verse": "34",
      "text": "Rachel had taken the idols and she had put them inside her camel's seat. Now she was sitting on them. Laban looked everywhere in Rachel's tent but he did not find the idols."
    },
    {
      "verse": "35",
      "text": "Rachel said to him, ‘Do not be angry with me, sir. I cannot stand up in front of you. It is the time of my monthly blood loss. ’ So Laban looked everywhere for the idols, but he did not find them."
    },
    {
      "verse": "36",
      "text": "Then Jacob became angry and he quarrelled with Laban. He asked Laban, ‘What have I done wrong? What sin have I done against you so that you had to catch me?"
    },
    {
      "verse": "37",
      "text": "Now you have looked through everything that I have. Did you find anything that belongs to you? If you have found anything, put it here. Then your relatives and my relatives can see it. Our relatives can decide which of us is right, you or me! ’"
    },
    {
      "verse": "38",
      "text": "Jacob continued to say to Laban, ‘I have worked for you for 20 years. Your female sheep and goats have all safely given birth to young ones. I have not taken any of your male animals as food for myself."
    },
    {
      "verse": "39",
      "text": "If wild animals attacked your sheep or goats, I did not show them to you. I myself paid you for them. If any animal was lost, in the day or at night, you said that I must pay you for it."
    },
    {
      "verse": "40",
      "text": "This is what it was like to work for you: I worked in the strong heat of the sun in the day. I had pain from the cold at night. I could not always sleep."
    },
    {
      "verse": "41",
      "text": "years as I worked like a slave for you. I worked for 14 years to pay you for your two daughters. Then I worked for six years for your sheep and goats. You changed what you paid me at least ten times!"
    },
    {
      "verse": "42",
      "text": "The God of my father, the God of Abraham and the Fear of Isaac was with me. If he had not helped me, then you would have sent me away with nothing. But God has seen what you have done to hurt me. He has seen how hard I have worked for you. So last night he told you that you had done wrong. ’"
    },
    {
      "verse": "43",
      "text": "Laban replied to Jacob, ‘These women are my daughters. Their children are my grandchildren. The animals are my animals. Everything that you have with you here belongs to me. But there is nothing that I can do today about my daughters or about their children."
    },
    {
      "verse": "44",
      "text": "So we should be friends. Let us make an agreement together. It will show that we have agreed to be friends. ’"
    },
    {
      "verse": "45",
      "text": "So Jacob took a large stone and made it stand up in the ground."
    },
    {
      "verse": "46",
      "text": "He said to his relatives, ‘Go and get some stones. ’ So they brought some stones and they put them together on the ground. Then they all ate a meal together, near the heap of stones."
    },
    {
      "verse": "47",
      "text": "Laban called that place Jegar Sahadutha. Jacob called it Galeed."
    },
    {
      "verse": "48",
      "text": "Laban said, ‘These stones show that we have made an agreement today. ’ That is why the place was called Galeed."
    },
    {
      "verse": "49",
      "text": "The place was also called Mizpah. That was because Laban said, ‘May the Lord watch you and me when we are away from each other."
    },
    {
      "verse": "50",
      "text": "Remember that God is watching you. If you do wrong to my daughters, God will see it. And if you marry any other women, remember this. God is watching you. Even if no one else sees you, God will know. ’"
    },
    {
      "verse": "51",
      "text": "Laban also said, ‘I have put this special stone here, and the heap of stones near it. They stand there between your land and my land."
    },
    {
      "verse": "52",
      "text": "I will not go past the stones to your side to hurt you. And you must not go past them to my side to hurt me."
    },
    {
      "verse": "53",
      "text": "Let the God of Abraham, Nahor, and their ancestors decide if one of us is guilty. ’So Jacob made a promise in the name of the God that his father Isaac worshipped."
    },
    {
      "verse": "54",
      "text": "He offered a sacrifice to God there in the hill country. He asked his relatives to eat a meal with him. After they had eaten, they stayed the night there."
    },
    {
      "verse": "55",
      "text": "Early the next morning, Laban got up to return home. He kissed his grandchildren and his daughters. He said ‘goodbye’ and he blessed them. Then he left and he went back to his home."
    }
  ],
  "32": [
    {
      "verse": "1",
      "text": "Jacob continued on his journey to his father's house. On his way the angels of God met him."
    },
    {
      "verse": "2",
      "text": "When Jacob saw them, he said, ‘This is where God's army has put up their tents! ’ So he called that place Mahanaim."
    },
    {
      "verse": "3",
      "text": "Jacob sent men with a message to his brother Esau. Esau was living in the land of Seir, also called Edom."
    },
    {
      "verse": "4",
      "text": "Jacob told his men, ‘This is what you must say to my master Esau: Your servant Jacob says, “I have been staying with Laban until now."
    },
    {
      "verse": "5",
      "text": "I have cows, donkeys, sheep and goats. I have male and female servants. Now I am sending this message to my lord so that you will be happy with me. ” ’"
    },
    {
      "verse": "6",
      "text": "When the men returned, they said to Jacob, ‘We went to your brother Esau. Now he is coming to meet you and he has 400 men with him. ’"
    },
    {
      "verse": "7",
      "text": "Jacob was very frightened and upset when he heard this. So he separated his people into two groups. He also separated his animals."
    },
    {
      "verse": "8",
      "text": "He thought, ‘If Esau attacks one group, the other group may run away safely. ’"
    },
    {
      "verse": "9",
      "text": "Then Jacob prayed, ‘God of my grandfather Abraham and my father Isaac, Lord, you said to me, “Go back to your country and to your relatives. I will do good things for you there. ”"
    },
    {
      "verse": "10",
      "text": "You have always loved me. You have continued to be kind to me. I do not deserve this. When I crossed the Jordan River to go to Haran, I only had my stick. But now I can make two big groups of people and animals."
    },
    {
      "verse": "11",
      "text": "I pray that you will save me from the power of my brother Esau. I am afraid that he will come and attack me. He may also attack my family."
    },
    {
      "verse": "12",
      "text": "But you have said, “I will give you many good things. I will give you so many descendants that nobody will be able to count them. They will be as many as the pieces of sand on the shore of the sea. ” ’"
    },
    {
      "verse": "13",
      "text": "Jacob stayed in that place for the night. He chose some of his animals as a gift for Esau."
    },
    {
      "verse": "14",
      "text": "female goats, 20 male goats, 200 female sheep and 20 male sheep."
    },
    {
      "verse": "15",
      "text": "female camels, with their young ones, 40 cows and ten bulls, 20 female donkeys and ten male donkeys."
    },
    {
      "verse": "16",
      "text": "He told his servants to take care of them. He separated each group of animals from the other groups. Jacob said to his servants, ‘Go in front of me. Keep some space between each group of animals. ’"
    },
    {
      "verse": "17",
      "text": "He told the servant who led the first group of animals, ‘When my brother Esau meets you, he may ask, “Who do you belong to? Where are you going? Who do all these animals belong to? ”"
    },
    {
      "verse": "18",
      "text": "Then you must say, “They belong to your servant Jacob. They are a gift that he has sent to my lord Esau. Jacob himself is coming behind us. ” ’"
    },
    {
      "verse": "19",
      "text": "Jacob also told the servants who led the other groups of animals, as well as the servants who followed behind them, ‘You are to say the same thing to Esau, when you meet him."
    },
    {
      "verse": "20",
      "text": "You must also say “Your servant Jacob is coming behind us. ” ’Jacob thought, ‘Esau will be happy to receive my gifts. He will no longer be angry with me. Then, when I meet him, he will not hurt me. ’"
    },
    {
      "verse": "21",
      "text": "So Jacob sent the men with his gifts to go on to meet Esau. But he himself stayed in that place for the night."
    },
    {
      "verse": "22",
      "text": "During the night Jacob took with him his two wives, his two female servants and his eleven sons. They went across the Jabbok river where there was a place to cross."
    },
    {
      "verse": "23",
      "text": "After Jacob had sent his family across, he also sent all his things across the stream."
    },
    {
      "verse": "24",
      "text": "Then Jacob was alone. A man came and fought with him for a long time. They continued until dawn."
    },
    {
      "verse": "25",
      "text": "The man saw that he was not winning the fight against Jacob. So he hit Jacob's hip while they were fighting. In that way, Jacob's hip moved out of its proper place."
    },
    {
      "verse": "26",
      "text": "Then the man said to Jacob, ‘Now let me go because dawn has come. ’ But Jacob said, ‘I will not let you go unless you bless me. ’"
    },
    {
      "verse": "27",
      "text": "The man asked Jacob, ‘What is your name? ’ Jacob replied, ‘My name is Jacob. ’"
    },
    {
      "verse": "28",
      "text": "Then the man said, ‘Your name will not be Jacob any longer. Your name will now be Israel. That is because you have fought with God and you have fought with men. And you have won! ’"
    },
    {
      "verse": "29",
      "text": "Then Jacob said, ‘Please tell me your name. ’ But the man said, ‘Why do you want to know my name? ’ Then he blessed Jacob in that place."
    },
    {
      "verse": "30",
      "text": "So Jacob called the place Peniel. He said, ‘I have seen God face to face, and I am still alive! ’"
    },
    {
      "verse": "31",
      "text": "The sun rose in the sky as Jacob passed through Peniel. He could not walk properly because of his hip."
    },
    {
      "verse": "32",
      "text": "Even today, the Israelite people do not eat the meat of an animal where it joins to the hip. This is because God touched Jacob's hip."
    }
  ],
  "33": [
    {
      "verse": "1",
      "text": "Jacob looked up. He saw Esau with 400 men coming towards him. So he separated his children into groups. Some went with Leah, some went with Rachel, and some went with his two female servants."
    },
    {
      "verse": "2",
      "text": "He put his female servants and their children at the front of the group. Then came Leah and her children. But Jacob put his son Joseph with Rachel at the back of the group."
    },
    {
      "verse": "3",
      "text": "Jacob himself went in front of these groups. He bent down to the ground to respect Esau. He did this seven times as he came nearer to his brother."
    },
    {
      "verse": "4",
      "text": "But Esau ran to meet Jacob and he hugged him. He put his arms round Jacob's neck and he kissed him. They both wept."
    },
    {
      "verse": "5",
      "text": "Then Esau looked up. He saw the women and children. He asked, ‘Who are these people with you? ’ Jacob replied, ‘They are the children that God has given to me, your servant. ’"
    },
    {
      "verse": "6",
      "text": "Then the female servants and their children came to Esau. As they came near to him, they bent down to the ground."
    },
    {
      "verse": "7",
      "text": "Then Leah and her children came and they bent down in front of Esau. Last of all, Joseph and Rachel came to Esau and they also bent down to the ground."
    },
    {
      "verse": "8",
      "text": "Esau asked Jacob, ‘Why did you send all those animals in front of you? ’ Jacob replied, ‘So that you would be happy to see me, my lord. ’"
    },
    {
      "verse": "9",
      "text": "But Esau said, ‘Keep your animals for yourself, my brother. I have enough animals of my own. ’"
    },
    {
      "verse": "10",
      "text": "But Jacob replied, ‘No! If you are happy to see me, please accept these animals as a gift from me. When you met me and I saw your face, it was as if I saw the face of God himself. I am happy that you have met me as a friend."
    },
    {
      "verse": "11",
      "text": "So please accept the gift that I brought to you. God has been very kind to me so that I have everything that I need. ’ So Esau accepted the gifts because Jacob would not agree to keep them."
    },
    {
      "verse": "12",
      "text": "Then Esau said, ‘Let us continue to go on our way. I will travel with you. ’"
    },
    {
      "verse": "13",
      "text": "But Jacob said, ‘My lord, the children are not very strong. Many of the animals have young babies. If we go too far in one day, then all the animals will die."
    },
    {
      "verse": "14",
      "text": "So you should go in front of me, my lord. I will travel slowly with the animals and children, so that they are comfortable. Then, my lord, I will come to you in Seir. ’"
    },
    {
      "verse": "15",
      "text": "Esau said, ‘Then let me leave some of my men to travel with you. ’ But Jacob replied, ‘You do not need to do that. All I want is for you to be happy with me. ’"
    },
    {
      "verse": "16",
      "text": "So Esau began his journey back to Seir that same day."
    },
    {
      "verse": "17",
      "text": "But Jacob went to Succoth instead. He built a house for himself, and he made huts for his animals. That is why the place is called Succoth."
    },
    {
      "verse": "18",
      "text": "After Jacob left Paddan Aram, he travelled safely to Canaan. He put up his tents there, near the city of Shechem."
    },
    {
      "verse": "19",
      "text": "He bought the piece of ground where he had put up his tents. He paid 100 pieces of silver to Hamor's sons to buy the land. Hamor was the father of Shechem."
    },
    {
      "verse": "20",
      "text": "Jacob built an altar in that place. He called the altar ‘The God of Israel is the true God’."
    }
  ],
  "34": [
    {
      "verse": "1",
      "text": "Dinah was the daughter of Leah and Jacob. One day she went out to visit the young women who lived near Shechem city."
    },
    {
      "verse": "2",
      "text": "Hamor the Hivite ruled that region. When his son, Shechem, saw Dinah, he took hold of her. Dinah could not get free and Shechem had sex with her."
    },
    {
      "verse": "3",
      "text": "He liked Dinah very much. He loved her. He spoke kind words to her so that she would love him too."
    },
    {
      "verse": "4",
      "text": "Shechem said to his father, Hamor, ‘I want to marry this girl. Please get her for me. ’"
    },
    {
      "verse": "5",
      "text": "Jacob heard that Shechem had had sex with his daughter. At that time, Jacob's sons were taking care of his animals in the fields. So he did not do anything until his sons came home."
    },
    {
      "verse": "6",
      "text": "Shechem's father, Hamor, went to talk to Jacob about Dinah."
    },
    {
      "verse": "7",
      "text": "Jacob's sons now heard what had happened and they came home from the fields. They were very angry because Shechem had done such a bad thing. When he caught Dinah and had sex with her, he had brought shame on Jacob's family. It was a bad thing that nobody should ever do."
    },
    {
      "verse": "8",
      "text": "Hamor said to Jacob and his sons, ‘My son Shechem loves your daughter. Please give her to him so that she can be his wife."
    },
    {
      "verse": "9",
      "text": "There should be more marriages between your people and our people. Our men should marry your daughters and our daughters should become wives for your men."
    },
    {
      "verse": "10",
      "text": "Then you can live among us. You can live anywhere you want to in this land. You should live here, buy and sell things. Buy land and houses here. ’"
    },
    {
      "verse": "11",
      "text": "Then Shechem said to Dinah's father and brothers, ‘I would like to make you happy. So ask me for whatever you want and I will give it to you."
    },
    {
      "verse": "12",
      "text": "I will pay you the gifts that you ask for Dinah. It can be as much as you like. I will pay it all, because I want to have Dinah as my wife. ’"
    },
    {
      "verse": "13",
      "text": "Because of the bad thing that Shechem had done to Dinah, Jacob's sons decided to deceive him. And they deceived his father Hamor too."
    },
    {
      "verse": "14",
      "text": "They said, ‘We cannot give our sister to a man who has not been circumcised. We would be ashamed to do this."
    },
    {
      "verse": "15",
      "text": "If you want to marry Dinah, you must do one thing. You must circumcise all your males. Then you will become like us and we will agree for you to marry Dinah."
    },
    {
      "verse": "16",
      "text": "Then we will give you our daughters so that your men can marry them. And our men will marry your daughters. We will live among you, so that we become one people with you."
    },
    {
      "verse": "17",
      "text": "But your men must agree to be circumcised. If not, we will take our sister with us and we will leave this place. ’"
    },
    {
      "verse": "18",
      "text": "This idea seemed good to Hamor and his son Shechem."
    },
    {
      "verse": "19",
      "text": "Shechem's family respected him as an important person. So Shechem and his father quickly did what Jacob's sons told them. Shechem agreed to do it because he wanted very much to marry Dinah."
    },
    {
      "verse": "20",
      "text": "So Hamor and his son Shechem went to the gate of the city. They spoke to their men there."
    },
    {
      "verse": "21",
      "text": "They said, ‘Jacob's family are our friends. Let them live in our land, and buy and sell things. This land is big enough for them and us. We can marry their daughters, and they can marry our daughters."
    },
    {
      "verse": "22",
      "text": "But we must do the one thing that they have asked us to do. We must circumcise all our males in the same way that they do. If we do that, they will agree to live among us."
    },
    {
      "verse": "23",
      "text": "Then their things and their animals will all become our things. So we should agree to be circumcised, as they ask. Then they will live among us. ’"
    },
    {
      "verse": "24",
      "text": "All the men who were at the city gate agreed with Hamor and Shechem. So every male in the city was circumcised."
    },
    {
      "verse": "25",
      "text": "Three days after the men were circumcised, they still had a lot of pain. Then two of Jacob's sons attacked Shechem's men with their swords. None of the men were ready to fight. Jacob's two sons were Simeon and Levi, Dinah's brothers. They killed every male in the city."
    },
    {
      "verse": "26",
      "text": "They killed Hamor and his son Shechem. Then they took Dinah from Shechem's house and they left."
    },
    {
      "verse": "27",
      "text": "Jacob's other sons also saw that the men of the city were dead. So they took everything that they wanted from the city. They did that because it was the place where Shechem had done a very bad thing against their sister."
    },
    {
      "verse": "28",
      "text": "They took all the sheep, goats, cows and donkeys. They took everything that was in the city and in the fields near there."
    },
    {
      "verse": "29",
      "text": "They carried away every valuable thing for themselves. They also took all the men's wives and their children. They took everything from the houses in the city."
    },
    {
      "verse": "30",
      "text": "When they returned to Jacob, he said to Simeon and Levi, ‘You have brought bad trouble to me! The people who live in this land, the Canaanites and the Perizzites, will hate me. I will be like a bad smell to them. We do not have many men to fight for us. If the Perizzites and Canaanites join together and they attack us, they will destroy our whole family! ’"
    },
    {
      "verse": "31",
      "text": "But Simeon and Levi replied, ‘Shechem should not have had sex with our sister as if she were a prostitute. ’"
    }
  ],
  "35": [
    {
      "verse": "1",
      "text": "After these things had happened, God said to Jacob, ‘Go to Bethel and live there. Build an altar to worship me. I am the God who appeared to you when you were running away from Esau. ’"
    },
    {
      "verse": "2",
      "text": "So Jacob told the people in his house and everyone who was with him, ‘Throw out all the foreign idols that you have with you. Wash your body very well and put on clean clothes."
    },
    {
      "verse": "3",
      "text": "Then we will go to Bethel. I will build an altar there to worship God. He is the one who answered me when I was in trouble. And he has been with me everywhere that I went. ’"
    },
    {
      "verse": "4",
      "text": "So the people gave to Jacob all their idols and the rings that were in their ears. Jacob buried these things under the oak tree near Shechem city."
    },
    {
      "verse": "5",
      "text": "Then they began their journey. All the towns near there were afraid of God's power. So no one attacked Jacob and his people."
    },
    {
      "verse": "6",
      "text": "Jacob and everyone with him arrived at Luz, now called Bethel. That is in the land of Canaan."
    },
    {
      "verse": "7",
      "text": "Jacob built an altar there. He called the place El Bethel, because that was where God appeared to him. God had appeared to him when he was running away from his brother Esau."
    },
    {
      "verse": "8",
      "text": "Rebekah's nurse, Deborah, died at that time. Jacob buried her under the oak tree near Bethel. That is why they call the place Allon Bacuth."
    },
    {
      "verse": "9",
      "text": "After Jacob returned from Paddan Aram, God appeared to him again. God blessed Jacob."
    },
    {
      "verse": "10",
      "text": "He said to Jacob, ‘Your name is Jacob, but you will no longer be called Jacob. Instead, your name will be Israel. ’ So God gave the name Israel to Jacob."
    },
    {
      "verse": "11",
      "text": "Then God said to him, ‘I am Almighty God. Give birth to many children so that your descendants become very many. They will become many nations and some of them will be kings."
    },
    {
      "verse": "12",
      "text": "I give to you the land that I gave to Abraham and Isaac. Yes, I will give this land to your descendants that come after you. ’"
    },
    {
      "verse": "13",
      "text": "Then God went away from the place where he spoke to Jacob."
    },
    {
      "verse": "14",
      "text": "Jacob set up a special stone on the ground. It showed the place where God had spoken to him. He poured a drink offering on the stone. He also poured olive oil on it."
    },
    {
      "verse": "15",
      "text": "In that way, Jacob called the place where God spoke to him Bethel."
    },
    {
      "verse": "16",
      "text": "Then they left Bethel and they continued to travel. When they were still a long way from Ephrath, Rachel began to give birth. She had a lot of pain."
    },
    {
      "verse": "17",
      "text": "As she was having even more pain, the woman who was helping her said, ‘Do not be afraid. You have another son! ’"
    },
    {
      "verse": "18",
      "text": "But Rachel was dying. With her last breath, she gave to her son the name Ben-Oni. But Jacob, his father, called him Benjamin."
    },
    {
      "verse": "19",
      "text": "After Rachel died, they buried near the road that goes to Ephrath."
    },
    {
      "verse": "20",
      "text": "Jacob set up a special stone over the place where they buried Rachel. This stone still shows the place."
    },
    {
      "verse": "21",
      "text": "Israel then travelled on again. He put up his tents beyond Migdal Eder."
    },
    {
      "verse": "22",
      "text": "While Israel stayed there, his son Reuben had sex with Bilhah. She was Israel's slave wife, and Israel heard what had happened. Jacob had 12 sons:"
    },
    {
      "verse": "23",
      "text": "The sons of Leah were Jacob's firstborn, Reuben, then Simeon, Levi, Judah, Issachar and Zebulun."
    },
    {
      "verse": "24",
      "text": "The sons of Rachel were Joseph and Benjamin."
    },
    {
      "verse": "25",
      "text": "The sons of Rachel's servant, Bilhah, were Dan and Naphtali."
    },
    {
      "verse": "26",
      "text": "The sons of Leah's servant, Zilpah, were Gad and Asher. Those were Jacob's sons who were born to him in Paddan Aram. Those were Jacob's sons who were born to him in Paddan Aram."
    },
    {
      "verse": "27",
      "text": "Jacob arrived back at his father Isaac's home. This was in Mamre, also called Kiriath Arba, or Hebron. It was the place where Abraham and Isaac had stayed."
    },
    {
      "verse": "28",
      "text": "years."
    },
    {
      "verse": "29",
      "text": "Then he died and he joined his ancestors. He was an old man who had lived a long life. His sons, Esau and Jacob, buried him."
    }
  ],
  "36": [
    {
      "verse": "1",
      "text": "This is the report about Esau and his family. (Esau is also called Edom. )"
    },
    {
      "verse": "2",
      "text": "Esau took women from Canaan to be his wives. They were: Adah, the daughter of Elon the Hittite, Oholibamah, the daughter of Anah and granddaughter of Zibeon the Hivite,"
    },
    {
      "verse": "3",
      "text": "and Basemath, the daughter of Ishmael and sister of Nebaioth."
    },
    {
      "verse": "4",
      "text": "Esau's wife Adah gave birth to a son called Eliphaz. Basemath gave birth to a son called Reuel."
    },
    {
      "verse": "5",
      "text": "Oholibamah gave birth to three sons: Jeush, Jalam and Korah. These were Esau's sons that were born in the land of Canaan."
    },
    {
      "verse": "6",
      "text": "Esau went to a land that was a long way from his brother Jacob. He took with him his wives, his sons and daughters and everyone in his house. He took his animals and all the things that he had got while he lived in Canaan."
    },
    {
      "verse": "7",
      "text": "Esau and Jacob both had too many animals to live together in the same place. There was not enough land to give food to all their animals."
    },
    {
      "verse": "8",
      "text": "So Esau went to live in the hills of Seir. He was also called Edom."
    },
    {
      "verse": "9",
      "text": "This is a list of Esau's descendants, the Edomites. They lived in the hill country of Seir."
    },
    {
      "verse": "10",
      "text": "These are the names of Esau's sons: Eliphaz, the son of Esau's wife, Adah, and Reuel, the son of Esau's wife, Basemath."
    },
    {
      "verse": "11",
      "text": "The sons of Eliphaz were Teman, Omar, Zepho, Gatam and Kenaz."
    },
    {
      "verse": "12",
      "text": "Esau's son Eliphaz also had a slave wife. Her name was Timna. She gave birth to a son called Amalek. Those were the grandsons of Esau's wife, Adah."
    },
    {
      "verse": "13",
      "text": "The sons of Reuel were Nahath, Zerah, Shammah and Mizzah. Those were grandsons of Esau's wife, Basemath."
    },
    {
      "verse": "14",
      "text": "Esau's wife Oholibamah was the daughter of Anah and the granddaughter of Zibeon. Her sons were Jeush, Jalam and Korah."
    },
    {
      "verse": "15",
      "text": "These were Esau's descendants who became leaders of their clans: The sons of Esau's firstborn son, Eliphaz were Teman, Omar, Zepho, Kenaz,"
    },
    {
      "verse": "16",
      "text": "Korah, Gatam and Amalek. These were the clan leaders who were descendants of Eliphaz in Edom. They were grandsons of Adah."
    },
    {
      "verse": "17",
      "text": "The sons of Esau's son, Reuel, who became clan leaders in Edom were Nahath, Zerah, Shammah and Mizzah. They were grandsons of Esau's wife Basemath."
    },
    {
      "verse": "18",
      "text": "The sons of Esau's wife, Oholibamah, who became clan leaders were Jeush, Jalam and Korah. Oholibamah was the daughter of Anah."
    },
    {
      "verse": "19",
      "text": "All those were the sons of Esau and they became the leaders of their clans."
    },
    {
      "verse": "20",
      "text": "These were the descendants of Seir the Horite. They lived in that land before Esau arrived there. They were Lotan, Shobal, Zibeon, Anah,"
    },
    {
      "verse": "21",
      "text": "Dishon, Ezer and Dishan. These descendants of Seir were leaders of the Horite clans in Edom."
    },
    {
      "verse": "22",
      "text": "Lotan's sons were Hori and Homam. Lotan's sister was Timna."
    },
    {
      "verse": "23",
      "text": "Shobal's sons were Alvan, Manahath, Ebal, Shepho and Onam."
    },
    {
      "verse": "24",
      "text": "Zibeon's sons were Aiah and Anah. This was the same Anah who found a place with hot water in the wilderness when he was taking care of his father Zibeon's donkeys."
    },
    {
      "verse": "25",
      "text": "Anah's children were Dishon and Oholibamah (his daughter)."
    },
    {
      "verse": "26",
      "text": "Dishon's sons were Hemdan, Eshban, Ithran and Keran."
    },
    {
      "verse": "27",
      "text": "Ezer's sons were Bilhan, Zaavan and Akan."
    },
    {
      "verse": "28",
      "text": "Dishan's sons were Uz and Aran."
    },
    {
      "verse": "29",
      "text": "These were the leaders of the Horite clans in the land of Seir: Lotan, Shobal, Zibeon, Anah,"
    },
    {
      "verse": "30",
      "text": "Dishon, Ezer and Dishan."
    },
    {
      "verse": "31",
      "text": "Before any kings ruled over the Israelites, these kings ruled in the land of Edom:"
    },
    {
      "verse": "32",
      "text": "Beor's son Bela became king of Edom. His city was called Dinhabah."
    },
    {
      "verse": "33",
      "text": "When Bela died, Zerah's son Jobab became the next king."
    },
    {
      "verse": "34",
      "text": "When Jobab died, Husham from the land of the Temanites became the next king."
    },
    {
      "verse": "35",
      "text": "When Husham died, Bedad's son Hadad became the next king. Bedad had won the war against the Midianites in the region of Moab. Hadad's city was called Avith."
    },
    {
      "verse": "36",
      "text": "When Hadad died, Samlah became the next king. He was from Masrekah."
    },
    {
      "verse": "37",
      "text": "When Samlah died, Shaul became the next king. He was from Rehoboth on the river."
    },
    {
      "verse": "38",
      "text": "When Shaul died, Akbor's son Baal-Hanan became the next king."
    },
    {
      "verse": "39",
      "text": "When Baal-Hanan died, Hadad became the next king. His city was called Pau. Hadad's wife was Mehetabel. She was the daughter of Matred, and the granddaughter of Me-Zahab."
    },
    {
      "verse": "40",
      "text": "These descendants of Esau were the leaders of their clans: Timna, Alvah, Jetheth, All those people are the descendants of Esau, the ancestor of the Edomites."
    },
    {
      "verse": "41",
      "text": "Oholibamah, Elah, Pinon,"
    },
    {
      "verse": "42",
      "text": "Kenaz, Teman, Mibzar,"
    },
    {
      "verse": "43",
      "text": "Magdiel and Iram. These were the leaders who lived with their families in different places in the land. Each place was called the same name as the clan leader who lived there. All those people are the descendants of Esau, the ancestor of the Edomites."
    }
  ],
  "37": [
    {
      "verse": "1",
      "text": "Jacob lived in Canaan, the land where his father had lived."
    },
    {
      "verse": "2",
      "text": "This is the report about Jacob and his family. Joseph was Jacob's son. When he was 17 years old, he took care of his father's sheep and goats. He did this together with his brothers. These were the sons of his father's wives, Bilhah and Zilpah. Sometimes Joseph told his father bad things about his brothers. Joseph was Jacob's son. When he was 17 years old, he took care of his father's sheep and goats. He did this together with his brothers. These were the sons of his father's wives, Bilhah and Zilpah. Sometimes Joseph told his father bad things about his brothers."
    },
    {
      "verse": "3",
      "text": "Jacob loved Joseph more than he loved any of his other sons. This was because Joseph was born when Jacob was old. So Jacob made a special coat for Joseph."
    },
    {
      "verse": "4",
      "text": "Joseph's brothers knew that Jacob loved him more than he loved them. So they hated Joseph. They could not say anything nice to him."
    },
    {
      "verse": "5",
      "text": "One night, Joseph had a dream and he told his brothers about it. When they heard about the dream, Joseph's brothers hated him even more than they did before."
    },
    {
      "verse": "6",
      "text": "Joseph said to his brothers, ‘Listen to what happened in my dream:"
    },
    {
      "verse": "7",
      "text": "We were out in the field tying the crops together into bundles. Then my bundle stood up. Your bundles stood in a circle round my bundle. And all your bundles bent down to respect my bundle. ’"
    },
    {
      "verse": "8",
      "text": "Joseph's brothers said to him, ‘Do you really think that you will be like a king and rule over us like that? ’ They hated Joseph even more because of what he told them about his dream."
    },
    {
      "verse": "9",
      "text": "Then Joseph had another dream and he told his brothers about it. He said, ‘Listen to me. I have had another dream. This is what happened: The sun, the moon and 11 stars bent down in front of me. ’"
    },
    {
      "verse": "10",
      "text": "Joseph told his father and his brothers about the dream. Jacob, his father, was angry with him. He said to Joseph, ‘You should not tell us about a dream like that! Do you really think that I, your mother and your brothers will come and bend down in front of you? ’"
    },
    {
      "verse": "11",
      "text": "Joseph's brothers were very jealous of him. But Jacob thought carefully about what Joseph had said."
    },
    {
      "verse": "12",
      "text": "One day, Joseph's brothers had taken their father's sheep to eat grass in the fields. This was near Shechem city."
    },
    {
      "verse": "13",
      "text": "Jacob said to Joseph, ‘You know that your brothers have taken my sheep to eat grass near Shechem. I want you to go to them. ’ Joseph replied, ‘I am ready to go. ’"
    },
    {
      "verse": "14",
      "text": "So Jacob said to Joseph, ‘Go and see if your brothers are well. See if the sheep have enough grass to eat. Then come back and tell me news about them. ’ Then Jacob sent Joseph from the Valley of Hebron to go to them."
    },
    {
      "verse": "15",
      "text": "When Joseph arrived near Shechem and he was walking in the fields there, a man met him. He asked Joseph, ‘What are you looking for? ’"
    },
    {
      "verse": "16",
      "text": "Joseph replied, ‘I am looking for my brothers. They have taken the sheep to eat grass. Please tell me where they are. ’"
    },
    {
      "verse": "17",
      "text": "The man said, ‘They have moved away from here. I heard them say, “Let us go to Dothan. ” ’So Joseph went to look for his brothers. He found them at Dothan."
    },
    {
      "verse": "18",
      "text": "But his brothers recognized Joseph, while he was still far away. Before he had arrived where they were, they decided on a way to kill him."
    },
    {
      "verse": "19",
      "text": "They said to each other, ‘Here comes the man who likes to dream!"
    },
    {
      "verse": "20",
      "text": "We will kill him. We can throw him into one of the dry wells. We can tell people that a wild animal ate him. Then his dreams will never become true! ’"
    },
    {
      "verse": "21",
      "text": "When Reuben heard this, he tried to save Joseph from the other brothers. He said, ‘We should not kill him."
    },
    {
      "verse": "22",
      "text": "Do not even get his blood on your hands. Just throw him into this dry well here in the wilderness. But do not attack him. ’ Reuben said this to save Joseph, so that his brothers would not kill him. Then later, Reuben could take Joseph back to his father."
    },
    {
      "verse": "23",
      "text": "So Joseph arrived at where his brothers were. He was wearing his special coat, but they took it off him."
    },
    {
      "verse": "24",
      "text": "Then they took hold of Joseph and they threw him into the empty well. It had no water in it."
    },
    {
      "verse": "25",
      "text": "Then the brothers sat down to eat their meal. They looked up and they saw a group of Ishmaelites coming towards them. They were coming from Gilead region. They were riding on camels that carried spices, and different kinds of oils for medicine. They were taking them to sell in Egypt."
    },
    {
      "verse": "26",
      "text": "Judah said to his brothers, ‘We could kill our brother and then hide his body. But then we will not get anything for ourselves."
    },
    {
      "verse": "27",
      "text": "So let us sell him to these Ishmaelites. We do not need to hurt him. Then we will not have to kill him. We should remember that he is our brother. He is our own relative. ’ Judah's brothers agreed with what he said."
    },
    {
      "verse": "28",
      "text": "When the Midianite traders came near to Joseph's brothers, they pulled him out of the dry well. They sold him to the Ishmaelites for 20 silver coins. The Ishmaelites took Joseph with them to Egypt."
    },
    {
      "verse": "29",
      "text": "Later, Reuben returned to the dry well. He saw that Joseph was not there. He tore his clothes because he was very upset."
    },
    {
      "verse": "30",
      "text": "Reuben went back to his brothers. He said to them, ‘The boy is not in the well! What can I do now? ’"
    },
    {
      "verse": "31",
      "text": "Then the brothers killed a goat. They took its blood and they put the blood all over Joseph's special coat."
    },
    {
      "verse": "32",
      "text": "They took the coat back to their father and they told him, ‘We found this coat. Look at it. Tell us if it is your son's coat. ’"
    },
    {
      "verse": "33",
      "text": "Jacob saw that it was Joseph's coat. He said, ‘It is my son's coat! A wild animal must have eaten him! The animal has torn Joseph's body into pieces. ’"
    },
    {
      "verse": "34",
      "text": "Jacob was so upset that he tore his own clothes. He put on clothes made from sackcloth to show how sad he was. He wept for many days because his son had died."
    },
    {
      "verse": "35",
      "text": "All Jacob's sons and daughters came to comfort him. But Jacob was very sad, so they could not make him happy. Jacob said, ‘I will be sad until the day that I die, because my son is dead. ’ Jacob wept because Joseph was dead."
    },
    {
      "verse": "36",
      "text": "While this was happening, the Midianites took Joseph into Egypt. They sold him to Potiphar, one of Pharaoh's officers. Potiphar had authority over all of Pharaoh's guards."
    }
  ],
  "38": [
    {
      "verse": "1",
      "text": "At that time, Judah left his brothers. He went to stay with a man from the town of Adullam. His name was Hirah."
    },
    {
      "verse": "2",
      "text": "While he was there, Judah met the daughter of a Canaanite man called Shua. Judah married her and he had sex with her."
    },
    {
      "verse": "3",
      "text": "She became pregnant, and she gave birth to a son. Judah gave him the name ‘Er’."
    },
    {
      "verse": "4",
      "text": "His wife became pregnant again, and she gave birth to another son. She gave him the name ‘Onan’."
    },
    {
      "verse": "5",
      "text": "Later, she gave birth to another son. She gave him the name ‘Shelah’. She gave birth to Shelah in Kezib."
    },
    {
      "verse": "6",
      "text": "Judah found a wife for his oldest son, Er. Her name was Tamar."
    },
    {
      "verse": "7",
      "text": "But the Lord saw that Er, Judah's firstborn son, was very bad. So the Lord caused him to die."
    },
    {
      "verse": "8",
      "text": "Then Judah said to Onan, ‘You should marry your dead brother's wife and have sex with her. You are her dead husband's brother. You must have a son who will become your dead brother's descendant. ’"
    },
    {
      "verse": "9",
      "text": "But Onan did not want Tamar to give birth to his child. He knew that the child would not belong to him. So when he had sex with his brother's wife Tamar, he made his semen go onto the ground. Onan did this so that Tamar would not give birth to a child for his dead brother."
    },
    {
      "verse": "10",
      "text": "What Onan did was bad, and the Lord was not pleased with him. So the Lord caused Onan to die too."
    },
    {
      "verse": "11",
      "text": "Then Judah said to his son's widow, Tamar, ‘Go back to your father's house and live there as a widow. Stay there until my son Shelah grows older. ’ Judah thought, ‘I do not want Shelah to die in the way that his brothers died. ’ So Tamar went to live in her father's house."
    },
    {
      "verse": "12",
      "text": "After a long time, Judah's wife, the daughter of Shua, died. When Judah had stopped being sad because of her death, he left his home to travel. He went with his friend, Hirah the Adullamite, to a place called Timnah. He went to see the men who were cutting the wool from his sheep."
    },
    {
      "verse": "13",
      "text": "Someone told Tamar, ‘Your husband's father is going to Timnah to get the wool from his sheep. ’"
    },
    {
      "verse": "14",
      "text": "Tamar knew that Judah's son Shelah had now become a man. But Judah had not yet let Shelah marry her. So Tamar took off her widow's clothes and she put on other clothes. She covered her head with a veil. She did not want anyone to recognize her. Then she sat at the gate of Enaim. Enaim is a town on the road that goes to Timnah."
    },
    {
      "verse": "15",
      "text": "Judah saw her as she sat there. He thought that she was a prostitute, because she had covered her face."
    },
    {
      "verse": "16",
      "text": "He did not know that she was his son's widow. He went to her at the side of the road. He said, ‘Let me have sex with you. ’ Tamar asked him, ‘If I have sex with you, what will you give me? ’"
    },
    {
      "verse": "17",
      "text": "Judah replied, ‘I will take a young goat from my animals and I will give it to you. ’ Tamar said, ‘Please give me something now to show me that you will really send the goat to me. ’"
    },
    {
      "verse": "18",
      "text": "Judah asked her, ‘What should I give you? ’ Tamar replied, ‘Give me your special ring and the string that holds it. And give me the stick that is in your hand. ’ So Judah gave them to her. He had sex with her. As a result, she became pregnant."
    },
    {
      "verse": "19",
      "text": "After this, Tamar left there and she took off her veil. She put her widow's clothes on again."
    },
    {
      "verse": "20",
      "text": "Judah sent his friend Hirah, the Adullamite, to take a young goat back to where the woman had been. Judah wanted to get his special things back from the woman. But Hirah could not find the woman."
    },
    {
      "verse": "21",
      "text": "He asked some men who lived there, ‘Where is the temple prostitute who sat by the road at Enaim? ’ But the men said, ‘There has not been any prostitute here. ’"
    },
    {
      "verse": "22",
      "text": "So Hirah went back to Judah, with the goat. He told him, ‘I did not find her. The men who lived there said, “There has not been any temple prostitute here. ” ’"
    },
    {
      "verse": "23",
      "text": "So Judah said, ‘Let her keep the things that I gave to her. People will laugh at me if you go back there again. I sent this young goat for her, as I promised, but you could not find her. ’"
    },
    {
      "verse": "24",
      "text": "Three months later, someone told Judah, ‘Your dead son's wife, Tamar, has become a prostitute and now she is pregnant. ’ Judah said, ‘Take her out of the town and burn her to death! ’"
    },
    {
      "verse": "25",
      "text": "So they took Tamar away to kill her. But she sent a message to her dead husband's father. She said, ‘The man that these things belong to had sex with me. That is why I am pregnant. Look at these things carefully. Do you know who the ring, its string, and the stick belong to? ’"
    },
    {
      "verse": "26",
      "text": "Judah saw that the things belonged to him. He said, ‘She is more honest than I am. She has done this because I would not give her to my son, Shelah, as his wife. ’ Judah did not have sex with Tamar again."
    },
    {
      "verse": "27",
      "text": "The time came for Tamar to give birth, and there were twins!"
    },
    {
      "verse": "28",
      "text": "While she was giving birth, one baby put out his hand. The woman who was helping Tamar tied a red string to that baby's arm. She said, ‘This baby came out first. ’"
    },
    {
      "verse": "29",
      "text": "But then the baby moved his hand back inside and his brother came out first. The woman said, ‘You have opened a way for yourself to come out! ’ So they gave him the name ‘Perez’."
    },
    {
      "verse": "30",
      "text": "Then his brother came out, with the red string on his arm. They gave him the name ‘Zerah’."
    }
  ],
  "39": [
    {
      "verse": "1",
      "text": "The Ishmaelites took Joseph to Egypt and they sold him there as a slave. Potiphar bought Joseph from the Ishmaelites. He was one of Pharaoh's officers. He had authority over all the guards."
    },
    {
      "verse": "2",
      "text": "The Lord was with Joseph, so that good things happened to him. Joseph lived in the house of Potiphar, his Egyptian master."
    },
    {
      "verse": "3",
      "text": "Potiphar saw that the Lord was with Joseph. He saw that the Lord helped Joseph to do good work."
    },
    {
      "verse": "4",
      "text": "So Joseph pleased Potiphar. Potiphar gave Joseph authority as his special servant. Joseph took care of everything that belonged to Potiphar."
    },
    {
      "verse": "5",
      "text": "From the time that Potiphar gave Joseph authority over everything in his house, the Lord blessed the people of Potiphar's house, his animals and his crops. The Lord blessed Potiphar because of Joseph."
    },
    {
      "verse": "6",
      "text": "So Potiphar told Joseph to take care of everything that belonged to him. Potiphar did not worry about anything in his house. The only thing that he thought about was the food that he ate. Joseph was a strong and handsome man."
    },
    {
      "verse": "7",
      "text": "After some time had passed, Potiphar's wife saw that Joseph was handsome. She said, ‘Come to bed with me! ’"
    },
    {
      "verse": "8",
      "text": "But Joseph refused to do that. He said, ‘My master does not need to think about anything in the house. I take care of everything that belongs to him."
    },
    {
      "verse": "9",
      "text": "No one has more authority in this house than I do. My master keeps nothing from me, except you. That is because you are his wife. I could not do such a bad thing. I could not do a sin that is against God. ’"
    },
    {
      "verse": "10",
      "text": "Potiphar's wife continued to speak to Joseph every day. But he would not agree to go to bed with her. He would not even go near her."
    },
    {
      "verse": "11",
      "text": "One day Joseph went into the house to do his work. None of the other servants were there in the house."
    },
    {
      "verse": "12",
      "text": "Potiphar's wife suddenly took hold of Joseph's coat. She said, ‘Come to bed with me! ’ Joseph left his coat in her hand and he ran out of the house."
    },
    {
      "verse": "13",
      "text": "Potiphar's wife saw that Joseph had left his coat in her hand. She saw that he had run out of the house."
    },
    {
      "verse": "14",
      "text": "So she called her servants to come. She said to them, ‘Look at this! The Hebrew man that Potiphar brought to work here does not respect us! He came in here and he tried to have sex with me. But I screamed loudly."
    },
    {
      "verse": "15",
      "text": "When he heard me scream like that, he ran out of the house. But he left his coat here with me. ’"
    },
    {
      "verse": "16",
      "text": "Potiphar's wife kept the coat beside her until Joseph's master, Potiphar, came home."
    },
    {
      "verse": "17",
      "text": "Then she told him this story: ‘The Hebrew slave that you brought to us tried to insult me. He wanted to sleep with me."
    },
    {
      "verse": "18",
      "text": "But I screamed loudly for help. So he left his coat with me and he ran out of the house. ’"
    },
    {
      "verse": "19",
      "text": "Joseph's master heard the story that his wife told him. She said, ‘This is what your slave did to me. ’ When Potiphar heard that, he was very angry."
    },
    {
      "verse": "20",
      "text": "He took hold of Joseph, and he put him in prison. It was the place where the king put his own prisoners."
    },
    {
      "verse": "21",
      "text": "While Joseph was there in the prison, the Lord was still with him. He was kind to Joseph. He caused the leader of the prison guards to like Joseph."
    },
    {
      "verse": "22",
      "text": "So this man gave Joseph authority over all the other prisoners. Joseph was responsible for everything that they did in the prison."
    },
    {
      "verse": "23",
      "text": "The prison guard did not worry about anything that Joseph had authority over. He saw that the Lord was with Joseph. Whatever Joseph did, the Lord helped him to do it well."
    }
  ],
  "40": [
    {
      "verse": "1",
      "text": "Some time later, two of the king's officers made him angry. One of them was the king's cupbearer. The other was the king's baker."
    },
    {
      "verse": "2",
      "text": "Pharaoh was angry with his two officers, both the cupbearer and the baker."
    },
    {
      "verse": "3",
      "text": "Pharaoh put them in the same prison that Joseph was in. That was in the house of the captain of the king's guards."
    },
    {
      "verse": "4",
      "text": "They were in the prison for a long time. The captain of the guards made Joseph their servant, to help them."
    },
    {
      "verse": "5",
      "text": "One night, both of the king's officers had a dream. Each dream had its own meaning."
    },
    {
      "verse": "6",
      "text": "When Joseph came to them the next morning, he saw that they were upset."
    },
    {
      "verse": "7",
      "text": "So Joseph asked the two officers, ‘What are you sad about? ’"
    },
    {
      "verse": "8",
      "text": "They replied, ‘We both had dreams last night, but there is nobody to tell us what they mean. ’ Joseph said, ‘Only God can tell you the meaning of dreams. Tell your dreams to me. ’"
    },
    {
      "verse": "9",
      "text": "So the king's cupbearer told Joseph his dream. He said, ‘In my dream I saw a vine in front of me."
    },
    {
      "verse": "10",
      "text": "There were three branches on it. New leaves came on the branches, and then flowers came. After that, there were grapes which became ripe."
    },
    {
      "verse": "11",
      "text": "Pharaoh's cup was in my hand. I took the grapes and I squeezed them. Then I put the juice into the cup and I gave the cup to Pharaoh. ’"
    },
    {
      "verse": "12",
      "text": "Joseph said, ‘This is what your dream means. The three branches tell us about three days."
    },
    {
      "verse": "13",
      "text": "In three days, Pharaoh will lift up your head and he will make you his officer again. You will put Pharaoh's cup into his hand, as you did before."
    },
    {
      "verse": "14",
      "text": "But when these good things happen to you, remember to be kind to me. Tell Pharaoh about me so that I will get out of this prison."
    },
    {
      "verse": "15",
      "text": "Men took hold of me in the land of the Hebrews and they brought me here. Even here, I have not done anything wrong. I should not be in this prison. ’"
    },
    {
      "verse": "16",
      "text": "The king's baker heard what Joseph had said to the cupbearer. He realized that the meaning of the cupbearer's dream was good. So he said to Joseph, ‘This was my dream: I had three baskets of bread on my head."
    },
    {
      "verse": "17",
      "text": "The top basket contained many different kinds of bread for Pharaoh. But birds were eating them out of the basket on my head. ’"
    },
    {
      "verse": "18",
      "text": "Joseph said, ‘This is what your dream means. The three baskets tell us about three days."
    },
    {
      "verse": "19",
      "text": "In three days, Pharaoh will lift off your head. He will hang you on a tree. Then birds will eat the meat off your body. ’"
    },
    {
      "verse": "20",
      "text": "Three days later, it was Pharaoh's birthday. He gave a feast for all his officers. He lifted up the head of the cupbearer and he lifted off the head of the baker! He brought them both out of the prison so that all his officers could see."
    },
    {
      "verse": "21",
      "text": "Pharaoh caused the cupbearer to be his own cupbearer again. As a result, the cupbearer put Pharaoh's cup into his hand again, as he did before."
    },
    {
      "verse": "22",
      "text": "But Pharaoh hanged the baker to kill him. So it all happened in the way that Joseph said it would happen."
    },
    {
      "verse": "23",
      "text": "But the cupbearer did not think about Joseph at all. He completely forgot about him."
    }
  ],
  "41": [
    {
      "verse": "1",
      "text": "Two years later, Pharaoh had a dream. In his dream, he was standing by the River Nile."
    },
    {
      "verse": "2",
      "text": "Seven cows walked up out of the river. They were fat and good to look at. They ate the grass at the side of the river."
    },
    {
      "verse": "3",
      "text": "After those seven fat cows, Pharaoh saw seven other cows that also came up out of the river. Those cows were thin and not good to look at. They stood next to the other cows at the side of the river."
    },
    {
      "verse": "4",
      "text": "The thin cows ate the seven fat cows! Then Pharaoh woke up."
    },
    {
      "verse": "5",
      "text": "Pharaoh went to sleep again and he had another dream. He saw seven groups of grain that were growing on one branch. The grains were fat and good to look at."
    },
    {
      "verse": "6",
      "text": "Then he saw seven other groups of grain that grew after the first seven groups. These grains were thin, because the hot east wind had burned them."
    },
    {
      "verse": "7",
      "text": "Then the groups of thin grains ate the seven groups of grains that were good and fat. Then Pharaoh woke up. He realized that it was a dream."
    },
    {
      "verse": "8",
      "text": "In the morning, Pharaoh had trouble in his mind. So he told all the magicians and the wise men in Egypt to come to him. Pharaoh told them about his dreams. But no one could tell Pharaoh what his dreams meant."
    },
    {
      "verse": "9",
      "text": "Then the king's cupbearer said to Pharaoh, ‘Now I remember that I have done a wrong thing!"
    },
    {
      "verse": "10",
      "text": "Two years ago, you were angry with me and with your special baker. You put us in prison, in the house of the guards' captain."
    },
    {
      "verse": "11",
      "text": "One night we both had a dream. Each of our dreams had its own meaning."
    },
    {
      "verse": "12",
      "text": "A young Hebrew man was there with us. He was a servant of the guards' captain. We told the Hebrew man about our dreams. Then he told each of us the meaning of our dream."
    },
    {
      "verse": "13",
      "text": "And everything happened as he had told us! You gave me my job as cupbearer again. But you hanged the baker to kill him. ’"
    },
    {
      "verse": "14",
      "text": "So Pharaoh called Joseph to come to him. They quickly brought Joseph from the prison. Joseph washed himself and he cut his beard from his face. He put on clean clothes. Then he went and he stood in front of Pharaoh."
    },
    {
      "verse": "15",
      "text": "Pharaoh said to Joseph, ‘I had a dream, and no one can tell me what it means. But people have told me about you. They say that you can tell the meaning of dreams. ’"
    },
    {
      "verse": "16",
      "text": "Joseph replied to Pharaoh, ‘I cannot do this. But God will give you an answer that will make you happy. ’"
    },
    {
      "verse": "17",
      "text": "Then Pharaoh said to Joseph, ‘In my dream, I stood at the side of the River Nile."
    },
    {
      "verse": "18",
      "text": "I saw seven cows that came up out of the river. They were fat, and good to look at. They were eating the grass at the side of the river."
    },
    {
      "verse": "19",
      "text": "After them, seven more cows came up out of the river. They were thin and they were not good to look at. I have never seen cows as bad as these in Egypt before."
    },
    {
      "verse": "20",
      "text": "The thin cows ate the seven fat cows that came out of the river first."
    },
    {
      "verse": "21",
      "text": "When they had eaten them, you would not have known it! They still seemed to be as thin as they were before they ate the fat cows. Then I woke up."
    },
    {
      "verse": "22",
      "text": "In another dream, I also saw seven groups of grain that grew on one branch. The grains were fat and good."
    },
    {
      "verse": "23",
      "text": "After those, seven other groups of grain grew. Those grains were thin because the hot east wind had burned them."
    },
    {
      "verse": "24",
      "text": "The thin grains ate the seven groups of fat grains. I told those dreams to my wise men and magicians. But none of them could tell me the meaning of my dreams. ’"
    },
    {
      "verse": "25",
      "text": "Then Joseph said to Pharaoh, ‘Your dreams both have the same meaning. God has shown you what he will soon do."
    },
    {
      "verse": "26",
      "text": "The seven fat cows tell us about seven years. And the seven groups of fat grains also mean seven years. Both dreams have the same meaning."
    },
    {
      "verse": "27",
      "text": "The seven thin cows that came out of the river mean seven years. And the seven groups of thin grains mean seven years. Both of these tell us about seven years of famine."
    },
    {
      "verse": "28",
      "text": "This is what your dreams mean. As I said, God has shown Pharaoh what he will do."
    },
    {
      "verse": "29",
      "text": "There will be plenty of food for seven years all over the land of Egypt."
    },
    {
      "verse": "30",
      "text": "But then seven years of famine will follow. People will forget about the seven years when they had plenty of food. The famine will destroy the land of Egypt."
    },
    {
      "verse": "31",
      "text": "No one will remember the seven good years, because the famine will be so bad."
    },
    {
      "verse": "32",
      "text": "God gave you two dreams with the same meaning because these things will certainly happen. God will cause them to happen very soon."
    },
    {
      "verse": "33",
      "text": "Now Pharaoh should look for a clever man. He should look for a man who knows what is right and wrong. Tell him to rule over the land of Egypt."
    },
    {
      "verse": "36",
      "text": "Then you will be ready for the seven years of famine that will happen everywhere in Egypt. The people in Egypt will have enough food, and the famine will not destroy the land. ’"
    },
    {
      "verse": "37",
      "text": "Pharaoh and his officers thought that Joseph's idea was good."
    },
    {
      "verse": "38",
      "text": "Pharaoh said to his officers, ‘This man has the Spirit of God in him. We will never find anyone else like him. ’"
    },
    {
      "verse": "39",
      "text": "So Pharaoh said to Joseph, ‘God himself has helped you to know all these things. So there is no one who is as wise and clever as you are."
    },
    {
      "verse": "40",
      "text": "I will give you authority in my palace. All my people will do whatever you tell them to do. Only I will be greater than you, because I am the king. ’"
    },
    {
      "verse": "41",
      "text": "Pharaoh also said to Joseph, ‘I give you authority in the whole land of Egypt. ’"
    },
    {
      "verse": "42",
      "text": "Then Pharaoh took his king's ring from his finger and he put it on Joseph's finger. He dressed Joseph in beautiful clothes made of linen. He put a gold chain round Joseph's neck."
    },
    {
      "verse": "43",
      "text": "Pharaoh gave Joseph a chariot to ride in. It showed that Joseph was Pharaoh's most important officer. Only Pharaoh had more authority. As Joseph travelled, his servants shouted to the people, ‘Bend your knees to respect Joseph! ’In this way Pharaoh gave Joseph authority over everything in the land of Egypt."
    },
    {
      "verse": "44",
      "text": "Pharaoh said to Joseph, ‘I rule Egypt as Pharaoh. But nobody who lives anywhere in Egypt will do anything, unless you tell them to. ’"
    },
    {
      "verse": "45",
      "text": "Pharaoh gave Joseph the name Zaphenath-Paneah. He also gave Asenath to Joseph to be his wife. She was the daughter of Potiphera, who was a priest in Heliopolis. Everyone knew that Joseph had authority in all the land of Egypt."
    },
    {
      "verse": "46",
      "text": "years old when he began to serve Pharaoh, king of Egypt. Joseph then left Pharaoh's palace and he travelled all over Egypt."
    },
    {
      "verse": "47",
      "text": "During the seven good years, lots of food grew in the land."
    },
    {
      "verse": "48",
      "text": "Joseph got all the extra food that grew in the seven good years. He stored it in Egypt's cities, near the fields where it had grown."
    },
    {
      "verse": "49",
      "text": "In this way, Joseph stored a lot of food. The food grains were as many as the sand by the sea! Joseph stopped counting how much food he had stored because there was too much food to measure."
    },
    {
      "verse": "50",
      "text": "Before the years of famine arrived, Joseph became the father of two sons. Asenath, daughter of Potiphera, a priest in Heliopolis, was their mother."
    },
    {
      "verse": "51",
      "text": "Joseph called his firstborn son Manasseh. Joseph said, ‘God has made me forget all the trouble that my family has given to me. ’"
    },
    {
      "verse": "52",
      "text": "Joseph called his second son Ephraim. Joseph said, ‘God has given children to me in the land where I have received pain. ’"
    },
    {
      "verse": "53",
      "text": "The seven good years with plenty of food in Egypt, came to an end."
    },
    {
      "verse": "54",
      "text": "The seven years of famine began, in the same way that Joseph had said would happen. There was a famine in all the other countries too. But in Egypt, the people still had food to eat."
    },
    {
      "verse": "55",
      "text": "When the Egyptian people became hungry, they cried out to Pharaoh for food. When they did that, Pharaoh told all the Egyptians, ‘Go to Joseph. Do whatever he tells you to do. ’"
    },
    {
      "verse": "56",
      "text": "The famine became very bad everywhere. Joseph opened all the places where he had stored the food. He sold grain to the Egyptians because there was a bad famine in all of Egypt."
    },
    {
      "verse": "57",
      "text": "People from all the other countries came to Egypt to buy food from Joseph. They came because the famine was very bad all over the world."
    },
    {
      "verse": "34",
      "text": "This is what you should do: Choose some officers. Give them authority to store food during the good years when there is plenty. They must take a fifth part of all the food that grows everywhere in Egypt."
    },
    {
      "verse": "35",
      "text": "They must store the extra food during the good years that will come soon. Give these officers authority to store and to take care of the food in the cities."
    }
  ],
  "42": [
    {
      "verse": "1",
      "text": "Jacob heard that there was food in Egypt. So he said to his sons, ‘There is no food here, so why are you just sitting there?"
    },
    {
      "verse": "2",
      "text": "I have heard that there is food in Egypt. Go there and buy some for us. Then we may continue to live and not die. ’"
    },
    {
      "verse": "3",
      "text": "So ten of Joseph's brothers went to Egypt to buy food."
    },
    {
      "verse": "4",
      "text": "But Jacob did not send his youngest son, Benjamin, with them. Jacob was afraid that something bad might happen to Benjamin."
    },
    {
      "verse": "5",
      "text": "Jacob's sons went to Egypt, as well as other people who went there to buy food. They all went to Egypt because there was a bad famine in Canaan."
    },
    {
      "verse": "6",
      "text": "Joseph had authority to rule Egypt at that time. He was the man who sold food to all the Egyptians. When Joseph's brothers arrived there, they bent down in front of him, with their faces to the ground."
    },
    {
      "verse": "7",
      "text": "As soon as Joseph saw the men, he knew that they were his brothers. But he spoke to them as if they were strangers. He did not speak to them in a kind way. He asked them, ‘Where do you come from? ’ They replied, ‘We come from the land of Canaan. We have come here to buy food. ’"
    },
    {
      "verse": "8",
      "text": "Joseph recognized his brothers, but they did not recognize him."
    },
    {
      "verse": "9",
      "text": "Then Joseph remembered the dream that he had dreamed about his brothers. He said to them, ‘You have come here secretly to see how your people can attack our land. ’"
    },
    {
      "verse": "10",
      "text": "They replied ‘No, my lord, that is not true! We are your servants and we have come to buy food."
    },
    {
      "verse": "11",
      "text": "We are all the sons of one man. We are honest men. We are not your enemies. ’"
    },
    {
      "verse": "12",
      "text": "But Joseph said, ‘No! You have come here to see if our country is weak so that you can attack us. ’"
    },
    {
      "verse": "13",
      "text": "Joseph's brothers replied, ‘We belong to a family of 12 brothers. We are the sons of one man who lives in Canaan. Our youngest brother stayed at home with our father. One other brother is not with us any more. ’"
    },
    {
      "verse": "14",
      "text": "Joseph said to them, ‘It is as I told you. You are our enemies!"
    },
    {
      "verse": "15",
      "text": "I will see if what you say is true. This is what I will do. I promise by the life of Pharaoh himself, I will not let you leave this place. You must first bring your youngest brother here. I will only let you go after that."
    },
    {
      "verse": "16",
      "text": "One of you must go to bring your brother here. I will keep you others in prison. In that way I will know if what you said is true. If your youngest brother does not come, then I will certainly know that you are enemies! ’"
    },
    {
      "verse": "17",
      "text": "Then Joseph put his brothers in prison for three days."
    },
    {
      "verse": "18",
      "text": "On the third day Joseph said to them, ‘Do what I say. Then you will stay alive, because I respect God."
    },
    {
      "verse": "19",
      "text": "If you are honest men, let one of your brothers stay here in prison. The other brothers can go back to Canaan. You may take food back with you, because your families are hungry."
    },
    {
      "verse": "20",
      "text": "But you must return to Egypt and you must bring your youngest brother to me. Then I will know that what you have said is true. Then you will not die. ’ Joseph's brothers agreed to do what he told them."
    },
    {
      "verse": "21",
      "text": "The brothers said to each other, ‘This punishment is happening to us because of what we did to Joseph. We saw how upset he was when he asked us not to kill him. But we refused to be kind to him. That is why we have all this trouble. ’"
    },
    {
      "verse": "22",
      "text": "Reuben said, ‘I told you not to do anything bad to the boy. But you would not agree! We killed him and now we must receive the punishment. ’"
    },
    {
      "verse": "23",
      "text": "While they said all this, they did not know that Joseph could understand them. Joseph had been speaking in the Egyptian language and someone else told the brothers his message in Hebrew."
    },
    {
      "verse": "24",
      "text": "Joseph went away from his brothers and he began to weep. But then he returned to speak to them again. While they watched, Joseph told his men to tie Simeon's hands and take him away."
    },
    {
      "verse": "25",
      "text": "Then Joseph told his servants to fill the brothers' bags with food. He also told them to put each man's money back into his bag. He told them to give the brothers enough food for their journey. The servants did what Joseph told them."
    },
    {
      "verse": "26",
      "text": "Then the brothers put the bags of food on to their donkeys. Then they left."
    },
    {
      "verse": "27",
      "text": "They travelled until they reached a place to sleep that night. One of the brothers opened his bag to get food for his donkey. Then he saw his money inside his bag, at the top."
    },
    {
      "verse": "28",
      "text": "He said to his brothers, ‘They have given back my money! Here it is in my bag! ’ All the brothers were upset and frightened. They asked each other, ‘What has God done to us? ’"
    },
    {
      "verse": "29",
      "text": "After some time they arrived back in Canaan. They went to their father, Jacob. They told him everything that had happened to them."
    },
    {
      "verse": "30",
      "text": "They said, ‘We met the man who is lord over Egypt. He spoke strong words to us. He thought that we were enemies who had come to find a way to attack Egypt."
    },
    {
      "verse": "31",
      "text": "But we said to him, “We are honest men. We are not your enemies."
    },
    {
      "verse": "32",
      "text": "brothers, all the sons of one father. One brother is not with us any more, and the youngest brother is at home with our father in Canaan. ”"
    },
    {
      "verse": "33",
      "text": "Then the man who is lord over Egypt said, “I want to know if you are honest men. This is what I will do. You must leave one of your brothers here, with me. Then take food for your hungry families and leave Egypt."
    },
    {
      "verse": "34",
      "text": "But then you must bring your youngest brother here to me. If you do that, I will know that you are really honest men. I will know that you are not our enemies. Then I will give your brother back to you. You will be able to stay in Egypt and you can buy and sell things here. ” ’"
    },
    {
      "verse": "35",
      "text": "The brothers started to take the food out of their bags. And in their bags, they found each man's money! When the brothers and their father saw the money, they were frightened."
    },
    {
      "verse": "36",
      "text": "Their father Jacob said to them, ‘You are taking my children away from me! Joseph is not here any more. Simeon also is not here. Now you want to take Benjamin away from me. Everything that happens is hurting me! ’"
    },
    {
      "verse": "37",
      "text": "Then Reuben said to his father, Jacob, ‘I will bring Benjamin back to you. If I do not, then you can kill both of my sons. Trust me to take care of him. I will bring him back. ’"
    },
    {
      "verse": "38",
      "text": "But Jacob said, ‘My son will not go with you. His brother is already dead. Benjamin is the only one left. Something bad may happen to him on your journey. I am already an old man. If I lose Benjamin, I would be so sad that I would die. ’"
    }
  ],
  "43": [
    {
      "verse": "1",
      "text": "The famine was still bad in Canaan."
    },
    {
      "verse": "2",
      "text": "Jacob's family ate all the food that they had brought from Egypt. So Jacob said to his sons, ‘Go back to Egypt, and buy some more food for us. ’"
    },
    {
      "verse": "3",
      "text": "But Judah said, ‘The man told us many times, “Unless your brother is with you, I will not let you see me again. ”"
    },
    {
      "verse": "4",
      "text": "So you must send Benjamin with us. Then we will go and buy food for you."
    },
    {
      "verse": "5",
      "text": "But if you do not send Benjamin, we will not go. The man clearly said to us, “Unless your brother is with you, you will not see me again. ” ’"
    },
    {
      "verse": "6",
      "text": "Jacob said to them, ‘You have brought great trouble to me! You should not have told the man that you had another brother. ’"
    },
    {
      "verse": "7",
      "text": "The brothers replied, ‘The man asked us many questions about our family. He asked us, “Is your father still alive? Do you have another brother? ” We only answered his questions. We did not know that he would say, “Bring your brother here. ” ’"
    },
    {
      "verse": "8",
      "text": "Then Judah said to his father Jacob, ‘Agree to send the boy with me. We will go to Egypt immediately. Then all our family can continue to live. We will not die."
    },
    {
      "verse": "9",
      "text": "I promise you to keep Benjamin safe. I myself will take care of him and I will bring him back to you. If I do not bring him back home, then you should say that I am guilty. I will be guilty for all of my life."
    },
    {
      "verse": "10",
      "text": "We must go now! We have already talked for too long. By now, we could have gone to Egypt and returned twice! ’"
    },
    {
      "verse": "11",
      "text": "Then their father Jacob said to them, ‘If you must take Benjamin, do what I tell you. Put some of the best things from our land in your bags. Take them to the man as a gift. Take some oil, some honey and some spices. Also take some myrrh, and some nuts."
    },
    {
      "verse": "12",
      "text": "Also take twice the amount of money with you. You must give back the money that they put back into your bags last time. It may have been a mistake."
    },
    {
      "verse": "13",
      "text": "Take your brother Benjamin too. Go back to the man now."
    },
    {
      "verse": "14",
      "text": "I pray that God Almighty will help you. I pray that God will cause the man to be kind to you. Then he will let your older brother go free. He and Benjamin will return here with you. As for me, if I must lose my sons, then I will lose them. There is nothing that I can do to stop it. ’"
    },
    {
      "verse": "15",
      "text": "So the brothers took the gifts, and they took twice as much money with them. They took Benjamin and they hurried to Egypt. When they arrived there, they went to meet Joseph."
    },
    {
      "verse": "16",
      "text": "Joseph saw that Benjamin was with them. So he said to his servant who took care of his house, ‘Take these men to my house. Kill an animal and prepare it for a meal. These men will eat with me at noon. ’"
    },
    {
      "verse": "17",
      "text": "The servant did as Joseph told him. He took the men to Joseph's house."
    },
    {
      "verse": "18",
      "text": "The brothers were frightened when the servant took them to Joseph's house. They thought, ‘He has brought us here because of the money that we found in our bags last time. Someone put it there before we returned home. Now he wants to punish us. He will take us to be his slaves. He will take our donkeys too. ’"
    },
    {
      "verse": "19",
      "text": "So the brothers went to Joseph's servant. They spoke to him at the door of Joseph's house before they went in."
    },
    {
      "verse": "20",
      "text": "They said, ‘Please sir. The first time we came here, we came to buy food."
    },
    {
      "verse": "21",
      "text": "But on our journey back, we stopped at a place to sleep for the night. When we opened our bags, each of us found our money there. It was the same amount of money that each of us had taken to buy food in Egypt. The money was in the top of our bags. Now we have brought the money back here."
    },
    {
      "verse": "22",
      "text": "We have also brought more money so that we can buy more food. We do not know who put the money back into our bags. ’"
    },
    {
      "verse": "23",
      "text": "The servant replied, ‘Do not worry. Everything is all right. Your God, the God of your father, put the valuable silver coins there. I received your money. No problem! ’ Then the servant brought Simeon out to see his brothers."
    },
    {
      "verse": "24",
      "text": "The servant took the men into Joseph's house. He gave them water to wash their feet. He also gave food to their donkeys."
    },
    {
      "verse": "25",
      "text": "The brothers prepared their gifts to give to Joseph when he would arrive at noon. The servant had told them that they would eat a meal there."
    },
    {
      "verse": "26",
      "text": "When Joseph arrived home, the brothers gave him the gifts that they had brought with them. They bent down low to the ground in front of him."
    },
    {
      "verse": "27",
      "text": "Joseph asked them if they were well. Then he said, ‘You told me last time about your old father. How is he? Is he still alive? ’"
    },
    {
      "verse": "28",
      "text": "The brothers replied, ‘Your servant, our father, is still alive. And he is well. ’ They bent down to the ground again, to respect Joseph."
    },
    {
      "verse": "29",
      "text": "Then Joseph saw his brother Benjamin, his own mother's son. Joseph asked, ‘Is this your youngest brother? Is he the one that you told me about? ’ Joseph said to Benjamin, ‘I pray that God will bless you, my son. ’"
    },
    {
      "verse": "30",
      "text": "Joseph loved Benjamin very much. He quickly went out of the room because he wanted to weep. Joseph went into his own room and he wept there."
    },
    {
      "verse": "31",
      "text": "After that, he washed his face. He returned to his brothers. He controlled himself and he said, ‘Prepare the food for them to eat. ’"
    },
    {
      "verse": "32",
      "text": "The servants gave food to Joseph at his own table. The brothers sat together at a different table. And the Egyptians who ate there also sat together. The Egyptians could not eat a meal with Hebrews, because that would make the Egyptians ashamed."
    },
    {
      "verse": "33",
      "text": "The brothers sat in a place where Joseph could see them. The servants told each of them where to sit, by their age. The oldest brother was at one end, all along to the youngest brother at the other end. The brothers were very surprised to see this."
    },
    {
      "verse": "34",
      "text": "Then the servants took food from Joseph's table and they gave it to the brothers. Benjamin received the biggest amount of food. It was five times more than any of his brothers. The brothers also drank wine with Joseph and they were all very happy."
    }
  ],
  "44": [
    {
      "verse": "1",
      "text": "Joseph told the servant who took care of his house, ‘Fill the men's bags. Give them as much food as their animals can carry. Put each man's money back in the top of his bag."
    },
    {
      "verse": "2",
      "text": "Then take my silver cup and put it in the top of the youngest man's bag. Put it with the money that he brought to pay for his food. ’ The servant did what Joseph had told him to do."
    },
    {
      "verse": "3",
      "text": "When morning came, the men started their journey with their donkeys."
    },
    {
      "verse": "4",
      "text": "They had travelled only a short way from the city. Then Joseph said to his servant, ‘Go now and follow those men. When you find them, say to them, “My master was kind to you. So why have you done this bad thing against us?"
    },
    {
      "verse": "5",
      "text": "You have taken my master's own special cup. It is the cup that he drinks from. He also uses it to find out about future things. You have done a very bad thing! ” ’"
    },
    {
      "verse": "6",
      "text": "So Joseph's servant followed the men and he reached them. He told them Joseph's message."
    },
    {
      "verse": "7",
      "text": "But the brothers said to him, ‘Sir, why do you say these things? We are your servants. We would not do anything like that!"
    },
    {
      "verse": "8",
      "text": "When we found the money in our bags last time, we brought it back to you from Canaan. So we would never take valuable silver or gold things from your master's house."
    },
    {
      "verse": "9",
      "text": "If any one of us has this silver cup, he must die. We others will become your slaves, sir. ’"
    },
    {
      "verse": "10",
      "text": "The servant said, ‘What you say is fair. Whoever has the cup, will become my slave. The rest of you will go free. ’"
    },
    {
      "verse": "11",
      "text": "Each of the brothers quickly put his bag on the ground and opened it."
    },
    {
      "verse": "12",
      "text": "Then the servant began to look in the bags. He began with the oldest brother's bag and he finished with the youngest brother's bag. Then he found the cup in Benjamin's bag!"
    },
    {
      "verse": "13",
      "text": "When this happened, all the brothers were very upset. They tore their clothes. Then they put their bags back on their donkeys. They returned to the city."
    },
    {
      "verse": "14",
      "text": "Joseph was still in his house when Judah and his brothers arrived. They threw themselves on the ground in front of Joseph."
    },
    {
      "verse": "15",
      "text": "Joseph said, ‘Why have you done this bad thing? You should have known about an important man like me. I can use magic to find out what people do. ’"
    },
    {
      "verse": "16",
      "text": "Judah said, ‘We do not know what to say to you, my lord. We cannot say that we did not do this. God has shown that we are guilty of this sin. Now we are your slaves. We are all your slaves, as well as the one who had your cup in his bag. ’"
    },
    {
      "verse": "17",
      "text": "But Joseph said, ‘I would not do a thing like that! Only the man who had the cup will be my slave. The rest of you can return to your father. You may go as my friends. ’"
    },
    {
      "verse": "18",
      "text": "Then Judah went and he spoke to Joseph. He said, ‘Please, my lord. Let me speak to you. You have all of Pharaoh's authority, but please do not be angry with me, your servant."
    },
    {
      "verse": "19",
      "text": "You asked us, “Do you have a father or another brother? ”"
    },
    {
      "verse": "20",
      "text": "And we replied, “We have a father who is very old. He has a young son who was born when our father was already old. That son's brother is dead. He is the only son of his mother who still lives. His father loves him. ”"
    },
    {
      "verse": "21",
      "text": "Then you said, “Bring your youngest brother to me so that I can see him. ”"
    },
    {
      "verse": "22",
      "text": "And we said, “The boy cannot leave his father. If he leaves him, his father will die. ”"
    },
    {
      "verse": "23",
      "text": "But you said to us, “Your youngest brother must come with you. If he does not come, I will not let you see me again. ”"
    },
    {
      "verse": "24",
      "text": "We returned to our father and we told him what you said."
    },
    {
      "verse": "25",
      "text": "After some time, our father said, “Go back to Egypt and buy some more food for us. ”"
    },
    {
      "verse": "26",
      "text": "But we said, “We cannot go back there. We can only go if our youngest brother goes with us. If he is not with us, we will not be able to see the man again. ”"
    },
    {
      "verse": "27",
      "text": "Then my father said to us, “My wife gave birth to two sons."
    },
    {
      "verse": "28",
      "text": "One of them went away and he never returned. So I said, ‘A wild animal must have eaten him. ’ I have not seen him since that happened."
    },
    {
      "verse": "29",
      "text": "If you take my youngest son away from me too, something bad may happen to him. I am already an old man. If I lose Benjamin, I would be so sad that I would die. ” ’"
    },
    {
      "verse": "30",
      "text": "Judah continued and he said, ‘So, my lord, I could not go back to my father without his youngest son. My father stays alive because of this boy."
    },
    {
      "verse": "31",
      "text": "If my father sees that his son is not with us, he will die. Because we did not bring the boy back to him, he will be sad enough to die."
    },
    {
      "verse": "32",
      "text": "I promised my father that I would take care of the boy. I said, “I will bring the boy back. If I do not, then you can say that I am guilty. I will be guilty for all of my life. ”"
    },
    {
      "verse": "33",
      "text": "Please sir, let me stay here as your slave, instead of the boy. Let the boy return home with his brothers."
    },
    {
      "verse": "34",
      "text": "I cannot go back to my father if the boy is not with me. I never want to see how upset my father would be. ’"
    }
  ],
  "45": [
    {
      "verse": "1",
      "text": "After Judah said this, Joseph could not control himself. He did not want to cry in front of all his servants. So he shouted, ‘Make everyone go away from me! ’ So there was no one still there with Joseph, except his brothers. Then he told his brothers who he was."
    },
    {
      "verse": "2",
      "text": "Joseph wept loudly, so that the Egyptians heard him. All the people in Pharaoh's house knew about it."
    },
    {
      "verse": "3",
      "text": "Joseph said to his brothers, ‘I am Joseph! Is my father still alive? ’ But his brothers could not answer him because they were too frightened. They could see Joseph was there in front of them!"
    },
    {
      "verse": "4",
      "text": "Then Joseph said to them, ‘Come near to me. ’ So they did that. He said, ‘I am your brother Joseph. I am the one that you sold to become a slave in Egypt!"
    },
    {
      "verse": "5",
      "text": "But do not be upset. Do not be angry with yourselves because you sold me like that. No! It was God who sent me here! He sent me here before you came. He did that so that I could save people's lives."
    },
    {
      "verse": "6",
      "text": "There has been a famine for two years already. No food will grow for another five years."
    },
    {
      "verse": "7",
      "text": "But God sent me to come here before you. Because of that, your family would stay alive. God would do a great thing to save you and your descendants."
    },
    {
      "verse": "8",
      "text": "So you did not really send me here. It was God who did that! He made me Pharaoh's most important officer, as if I am his father. I take care of everything in Pharaoh's palace. I have authority to rule over all of Egypt."
    },
    {
      "verse": "9",
      "text": "Now hurry back to my father. Say to him, “This is what your son Joseph says: God has made me lord over all Egypt. Come here to me. Come now."
    },
    {
      "verse": "10",
      "text": "You can live in the region called Goshen. You, your children and your grandchildren can live there. You can bring your sheep, goats and cows, together with everything that you have. In Goshen you will all be near me."
    },
    {
      "verse": "11",
      "text": "I will take care of you there. I will give food to you, because there will be five more years of famine. If you do not come here, you and all your family and servants will become very poor. ” ’"
    },
    {
      "verse": "12",
      "text": "Joseph continued to say to his brothers, ‘As I speak to you now, you can all see clearly that I really am Joseph. My brother Benjamin also knows that."
    },
    {
      "verse": "13",
      "text": "Tell my father about the authority that I have here in Egypt. Tell him about everything that you have seen here. Then bring my father here quickly. ’"
    },
    {
      "verse": "14",
      "text": "Then Joseph hugged his brother Benjamin and he wept. Benjamin hugged Joseph and he also wept."
    },
    {
      "verse": "15",
      "text": "Joseph continued to weep as he kissed each of his other brothers too. After this, his brothers began to talk to Joseph."
    },
    {
      "verse": "16",
      "text": "Pharaoh then heard that Joseph's brothers had arrived in Egypt. Pharaoh and his officers were happy to know that."
    },
    {
      "verse": "17",
      "text": "Pharaoh said to Joseph, ‘Tell your brothers to do this. Say to them, “Put food on your donkeys and return home to Canaan."
    },
    {
      "verse": "18",
      "text": "Then bring your father and your families to come here to me. I will give you the best land in Egypt to live on. You will have all the best things that the land gives to you. ”"
    },
    {
      "verse": "19",
      "text": "You must also tell your brothers, “Take some carts from here in Egypt. Your wives and children can ride in them to come back here. Bring your father and come quickly."
    },
    {
      "verse": "20",
      "text": "Do not worry. You do not have to bring all your things from your own country. The best things of Egypt will belong to you. ” ’"
    },
    {
      "verse": "21",
      "text": "So Jacob's sons did what Pharaoh said. Joseph gave them carts as Pharaoh had told him to do. He also gave them food for their journey."
    },
    {
      "verse": "22",
      "text": "Joseph gave new clothes to each of his brothers. But he gave 300 silver coins and five sets of clothes to Benjamin."
    },
    {
      "verse": "23",
      "text": "Joseph also sent these things to his father:10 donkeys that carried the best things from Egypt, 10 female donkeys that carried food and grain, and other food for his father's journey."
    },
    {
      "verse": "24",
      "text": "Then Joseph sent his brothers to start their journey. As they left, he said to them, ‘Do not argue with each other on your way home! ’"
    },
    {
      "verse": "25",
      "text": "The brothers left Egypt and they returned home to their father Jacob in Canaan."
    },
    {
      "verse": "26",
      "text": "They told him, ‘Joseph is still alive! He rules over all of Egypt! ’ Jacob was so surprised that he did not believe what they said."
    },
    {
      "verse": "27",
      "text": "So Jacob's sons told him everything that Joseph had said to them. Jacob saw the carts that Joseph had sent to carry him back to Egypt. Then Jacob felt stronger again."
    },
    {
      "verse": "28",
      "text": "Jacob said, ‘Now I believe you! My son Joseph is still alive! I will go and see him before I die. ’"
    }
  ],
  "46": [
    {
      "verse": "1",
      "text": "So Jacob left Canaan. He took everything that belonged to him. When he came to Beersheba, he offered sacrifices to God, the God of his father Isaac."
    },
    {
      "verse": "2",
      "text": "During the night, God spoke to Israel in a dream. He said, ‘Jacob! Jacob! ’ Jacob replied, ‘Yes, I am here. ’"
    },
    {
      "verse": "3",
      "text": "God said, ‘I am God. I am the God that your father worshipped. Do not be afraid to go to Egypt. Your descendants will be very many so that you become a great nation there."
    },
    {
      "verse": "4",
      "text": "I will go with you to Egypt. I will also bring you back again. Joseph will be with you when you die. ’"
    },
    {
      "verse": "5",
      "text": "Then Jacob left Beersheba and he continued to travel. Jacob's sons took their father as well as their wives and children. They rode in the carts that Pharaoh had sent to take them to Egypt."
    },
    {
      "verse": "6",
      "text": "They also took all their animals and everything that they had got in Canaan. In that way, Jacob and all his family went to Egypt."
    },
    {
      "verse": "7",
      "text": "He took his sons and his grandsons, his daughters and granddaughters. He took all his family with him to Egypt."
    },
    {
      "verse": "8",
      "text": "These are the names of the descendants of Israel who went to Egypt, (that is, the sons of Jacob): Reuben was the firstborn son of Jacob."
    },
    {
      "verse": "9",
      "text": "The sons of Reuben: Hanoch, Pallu, Hezron and Carmi."
    },
    {
      "verse": "10",
      "text": "The sons of Simeon: Jemuel, Jamin, Ohad, Jakin, Zohar and Shaul the son of a Canaanite woman."
    },
    {
      "verse": "11",
      "text": "The sons of Levi: Gershon, Kohath and Merari."
    },
    {
      "verse": "12",
      "text": "The sons of Judah: Er, Onan, Shelah, Perez and Zerah. Er and Onan died in the land of Canaan. The sons of Perez were Hezron and Hamul."
    },
    {
      "verse": "13",
      "text": "The sons of Issachar: Tola, Puah, Jashub and Shimron."
    },
    {
      "verse": "14",
      "text": "The sons of Zebulun: Sered, Elon and Jahleel."
    },
    {
      "verse": "15",
      "text": "These were the sons that Leah gave birth to in Paddan Aram. Jacob was their father. Leah also gave birth to a daughter, Dinah. These sons and daughters of Jacob were 33 in all."
    },
    {
      "verse": "16",
      "text": "The sons of Gad: Zephon, Haggi, Shuni, Ezbon, Eri, Arodi and Areli."
    },
    {
      "verse": "17",
      "text": "The sons of Asher: Imnah, Ishvah, Ishvi and Beriah. Their sister was Serah. The sons of Beriah were Heber and Malkiel."
    },
    {
      "verse": "18",
      "text": "These were the children that Zilpah gave birth to. Jacob was their father. Leah gave Zilpah to Jacob as a wife. There were 16 children in all."
    },
    {
      "verse": "19",
      "text": "The sons of Jacob's wife Rachel: Joseph and Benjamin."
    },
    {
      "verse": "20",
      "text": "Manasseh and Ephraim were born to Joseph in Egypt. Their mother was Asenath daughter of Potiphera, priest of On."
    },
    {
      "verse": "21",
      "text": "The sons of Benjamin: Bela, Becher, Ashbel, Gera, Naaman, Ehi, Rosh, Muppim, Huppim and Ard."
    },
    {
      "verse": "22",
      "text": "These were the sons of Rachel, born to Jacob. There were 14 in all."
    },
    {
      "verse": "23",
      "text": "The son of Dan: Hushim."
    },
    {
      "verse": "24",
      "text": "The sons of Naphtali: Jahziel, Guni, Jezer and Shillem."
    },
    {
      "verse": "25",
      "text": "These were the sons that Bilhah gave birth to. She was Rachel's servant that Laban gave to her. Bilhah gave birth to these sons for Jacob. There were seven in all."
    },
    {
      "verse": "26",
      "text": "Jacob's descendants who went with him to Egypt were 66. That does not include his son's wives."
    },
    {
      "verse": "27",
      "text": "Joseph had two sons that were born in Egypt. So there were 70 people of Jacob's family who were there in Egypt."
    },
    {
      "verse": "28",
      "text": "Then Jacob sent Judah to go to Joseph before he got there himself. He learned how to get to Goshen and they arrived there."
    },
    {
      "verse": "29",
      "text": "Joseph prepared his chariot and he went to Goshen to meet Jacob, his father. When they met, Joseph hugged his father and he wept for a long time."
    },
    {
      "verse": "30",
      "text": "Jacob said to Joseph, ‘Now I am ready to die. I have seen for myself that you are still alive. ’"
    },
    {
      "verse": "31",
      "text": "Then Joseph spoke to his brothers and to his father's people. He said, ‘I will go and say to Pharaoh, “My brothers and all my father's people have arrived here from Canaan."
    },
    {
      "verse": "32",
      "text": "The men are shepherds. They take care of their animals. They have brought with them their sheep, goats and cows, and everything that they have. ”"
    },
    {
      "verse": "33",
      "text": "Pharaoh will call you to meet him. He will ask you, “What is your job? ”"
    },
    {
      "verse": "34",
      "text": "Then you should answer, “We have always taken care of cows and sheep since we were young men. Our ancestors have always done this work. ” Egyptians do not want to live near people who take care of sheep. So Pharaoh will let you stay in the region called Goshen. ’"
    }
  ],
  "47": [
    {
      "verse": "1",
      "text": "Joseph went to Pharaoh. He told him, ‘My father and brothers have arrived from Canaan. They have come with their animals and everything that belongs to them. They are now in Goshen. ’"
    },
    {
      "verse": "2",
      "text": "Joseph took five of his brothers to go with him to meet Pharaoh."
    },
    {
      "verse": "3",
      "text": "Pharaoh asked the brothers, ‘What is your job? ’ The brothers replied, ‘We are shepherds, sir. We take care of animals, just like our ancestors did. ’"
    },
    {
      "verse": "4",
      "text": "They also said to Pharaoh, ‘We have come to stay here for a short time because there is a bad famine in Canaan. Our animals do not have any grass to eat there. Please sir, let us stay in Goshen. ’"
    },
    {
      "verse": "5",
      "text": "Pharaoh said to Joseph, ‘Your father and your brothers have now come to you."
    },
    {
      "verse": "6",
      "text": "The whole land of Egypt is here for them. Your father and your brothers should stay in the best part of the land. They may live in Goshen. Choose the best shepherds from among them to take care of my own animals. ’"
    },
    {
      "verse": "7",
      "text": "Then Joseph brought his father Jacob to meet Pharaoh. Jacob blessed Pharaoh."
    },
    {
      "verse": "8",
      "text": "Then Pharaoh asked Jacob, ‘How old are you? ’"
    },
    {
      "verse": "9",
      "text": "Jacob replied, ‘I have been alive for 130 years. My years have been few, and they have been difficult. I have not lived for as long as my ancestors lived. ’"
    },
    {
      "verse": "10",
      "text": "Then Jacob blessed Pharaoh again and he left."
    },
    {
      "verse": "11",
      "text": "So Joseph helped his father and his brothers to make their home in Egypt. He gave them a good place to live in the best region of Egypt. This was in the region that is now called Rameses. Joseph did for his family what Pharaoh had told him to do."
    },
    {
      "verse": "12",
      "text": "Joseph also sent food to his father, his brothers and all his father's people. He gave them enough food for themselves and all their children."
    },
    {
      "verse": "13",
      "text": "But because the famine was bad, no food grew in all of Egypt. As a result, the people of Egypt and Canaan became hungry and weak."
    },
    {
      "verse": "14",
      "text": "Joseph received money from the people when he sold food to them. He took all the money to Pharaoh's palace."
    },
    {
      "verse": "15",
      "text": "Soon the people of Egypt and Canaan did not have any more money. All the Egyptians went to Joseph and they said, ‘Give us food to eat. If not, we will die! We do not have any more money. ’"
    },
    {
      "verse": "16",
      "text": "Joseph said to the people, ‘If you have no money, bring me your animals. I will give you food if you pay me with your animals instead of money. ’"
    },
    {
      "verse": "17",
      "text": "So the people brought their animals to Joseph. They brought horses, sheep, goats, cows and donkeys. Joseph sold food to them in return for their animals. In that way, he sold enough food for them to eat that year."
    },
    {
      "verse": "18",
      "text": "When that year finished, the people came to Joseph again. They said to him, ‘Sir, you know that we do not have any money. Our animals now belong to you. We have nothing left to give to you. We only have our land and our own bodies."
    },
    {
      "verse": "19",
      "text": "Do not let us die here and now! Do not destroy our land! If you give food to us, we will pay you with ourselves and with our land. We will become Pharaoh's slaves. Our land will become Pharaoh's land. Give us grain to eat and seed to plant. Then we will not die. Our fields will not be empty. ’"
    },
    {
      "verse": "20",
      "text": "Joseph bought all the land in Egypt for Pharaoh. Because the famine was very bad, all the Egyptians sold their fields to buy food. So all the land now belonged to Pharaoh."
    },
    {
      "verse": "21",
      "text": "Joseph made all the people become slaves, wherever they lived in Egypt."
    },
    {
      "verse": "22",
      "text": "But Joseph did not buy the land which belonged to the priests. Pharaoh himself gave the priests enough food. So the priests did not have to sell their land."
    },
    {
      "verse": "23",
      "text": "Joseph said to the people, ‘Now I have bought you and your land for Pharaoh. So I will give you some seed to plant in your fields."
    },
    {
      "verse": "24",
      "text": "But when the plants are ready to eat, you must give one fifth part to Pharaoh. You may keep the other four parts. You may keep it for seed to plant again and you may eat it. It will be food for you, for your people and for your children. ’"
    },
    {
      "verse": "25",
      "text": "The people said, ‘You have saved our lives! Because you have been kind to us, we agree to become Pharaoh's slaves. ’"
    },
    {
      "verse": "26",
      "text": "So Joseph made a law which everybody in Egypt has to obey. The law says that one fifth of all food that people grow belongs to Pharaoh. Only the priests' land did not become Pharaoh's land. This law still has authority today."
    },
    {
      "verse": "27",
      "text": "The Israelites stayed in Egypt, in the region called Goshen. They had their own land there. They gave birth to many children so that they became very many people."
    },
    {
      "verse": "28",
      "text": "years. His whole life was 147 years."
    },
    {
      "verse": "29",
      "text": "The time came for him to die. So he called his son Joseph to come to him. Jacob said to him, ‘If you agree, make a serious promise to me. Put your hand between my legs to show that I can trust you. Promise that you will be kind to me and that you will do as I ask. When I die, do not bury me here in Egypt."
    },
    {
      "verse": "30",
      "text": "Carry my body out of Egypt. Bury me in the grave of my ancestors. ’ Joseph said, ‘I will do as you say. ’"
    },
    {
      "verse": "31",
      "text": "Jacob said, ‘Promise me that you will do this. ’ Then Joseph made a promise to him. After that, Jacob rested on his bed and he thanked God."
    }
  ],
  "48": [
    {
      "verse": "1",
      "text": "After some time, someone told Joseph, ‘Your father is ill. ’ So Joseph went to see Jacob and he took his two sons, Manasseh and Ephraim, with him."
    },
    {
      "verse": "2",
      "text": "Someone told Jacob, ‘Your son Joseph has come to see you. ’ Jacob's body became stronger and he sat up on the bed."
    },
    {
      "verse": "3",
      "text": "Jacob said to Joseph, ‘God Almighty appeared to me at Luz, in Canaan. God blessed me there."
    },
    {
      "verse": "4",
      "text": "He said to me, “I will give you many children, so that your descendants are many. In that way, you will become the ancestor of many nations. I will give this land to you so that it belongs to your descendants for ever. ” ’"
    },
    {
      "verse": "5",
      "text": "Jacob continued to say to Joseph, ‘You have two sons that were born to you in Egypt before I came here. They will become my own sons. Ephraim and Manasseh will be my sons, just as Reuben and Simeon are my sons."
    },
    {
      "verse": "6",
      "text": "Any children born to you after them will be your own children. They will receive part of the land that belongs to their brothers, Ephraim and Manasseh."
    },
    {
      "verse": "7",
      "text": "As for me, I was very sad when your mother Rachel died on our journey from Paddan. She died near to Ephrath. So I buried her there, next to the road to Ephrath (that is now called Bethlehem). ’"
    },
    {
      "verse": "8",
      "text": "Joseph brought Ephraim and Manasseh to his father, Jacob. Jacob asked him, ‘Who are these boys? ’"
    },
    {
      "verse": "9",
      "text": "Joseph replied, ‘They are the sons that God has given to me here in Egypt. ’ Then Israel said, ‘Bring them near to me so that I can bless them. ’"
    },
    {
      "verse": "10",
      "text": "Jacob's eyes had become weak because he was very old. He was almost blind. So Joseph brought his sons near to his father. His father kissed them and he hugged them."
    },
    {
      "verse": "11",
      "text": "Jacob said to Joseph, ‘I never thought that I would see you again. But now God has let me see your children too. ’"
    },
    {
      "verse": "12",
      "text": "Then Joseph removed his sons from Jacob's knees. He bent down low, with his face towards the ground."
    },
    {
      "verse": "13",
      "text": "He took his two sons near to Jacob. With his right hand, he put Ephraim beside Jacob's left hand. With his left hand, he put Manasseh beside Jacob's right hand."
    },
    {
      "verse": "14",
      "text": "Jacob then put out his right hand. But he put it on Ephraim's head, even though Ephraim was the younger son. Jacob crossed his arms so that he put his left hand on Manasseh's head. Manasseh was Joseph's firstborn son."
    },
    {
      "verse": "15",
      "text": "Then Jacob blessed Joseph. He said, ‘May God bless these two boys. He is the God that my ancestors, Abraham and Isaac, served. Like a shepherd takes care of his sheep, God has taken care of me all my life, until this day. ‘May God bless these two boys. He is the God that my ancestors, Abraham and Isaac, served. Like a shepherd takes care of his sheep, God has taken care of me all my life, until this day."
    },
    {
      "verse": "16",
      "text": "He is the Angel who has kept me safe. I pray that he will bless these boys. I pray that, because of them, people will remember my name, and the names of my ancestors, Abraham and Isaac. I pray that they will have many descendants who live all over the earth. ’ I pray that he will bless these boys. I pray that, because of them, people will remember my name, and the names of my ancestors, Abraham and Isaac. I pray that they will have many descendants who live all over the earth. ’"
    },
    {
      "verse": "17",
      "text": "Joseph saw that his father had put his right hand on Ephraim's head. This made Joseph upset. So he took hold of his father's right hand. He moved it from Ephraim's head on to Manasseh's head."
    },
    {
      "verse": "18",
      "text": "Joseph said to Jacob, ‘No, my father. This boy is the firstborn son. Put your right hand on his head. ’"
    },
    {
      "verse": "19",
      "text": "But Jacob refused to change. He said, ‘I know, my son. I know what I am doing. Manasseh will also have many descendants who become a great nation. But his younger brother, Ephraim, will become even greater. Ephraim's descendants will become many great nations. ’"
    },
    {
      "verse": "20",
      "text": "So Jacob blessed both of Joseph's sons that day. He said, ‘In your name Israel's people will give this blessing:“May God be good to you, just like he was to Ephraim and Manasseh. ” ’In this way, Jacob put Ephraim before Manasseh when he blessed them. “May God be good to you, just like he was to Ephraim and Manasseh. ” ’ In this way, Jacob put Ephraim before Manasseh when he blessed them."
    },
    {
      "verse": "21",
      "text": "Then Jacob said to Joseph, ‘I will die soon. But God will be with you. He will take you back to the land where your ancestors lived."
    },
    {
      "verse": "22",
      "text": "I give to you more than I give to your brothers. I give to you the good part of the land that I took from the Amorites. I fought against them with my weapons to take that land. ’"
    }
  ],
  "49": [
    {
      "verse": "1",
      "text": "Then Jacob called for all his sons. He said, ‘Come here to me. Then I can tell you what will happen to you, in future years."
    },
    {
      "verse": "2",
      "text": "You sons of Jacob, come together now and listen to your father, Israel. ’"
    },
    {
      "verse": "3",
      "text": "Jacob said, ‘Reuben you are my firstborn son. You were born first, when I was a strong young man. Of all my sons, you are the most famous and the strongest."
    },
    {
      "verse": "4",
      "text": "Yet you are as wild as the sea. You had sex with your father's slave wife. This bad thing brought me shame. So you will not become great."
    },
    {
      "verse": "5",
      "text": "Simeon and Levi are brothers. They use their swords as weapons to destroy people."
    },
    {
      "verse": "6",
      "text": "I will not join them when they decide to do bad things. I will not meet with them. They have killed people when they are angry. They have hurt animals because it makes them happy."
    },
    {
      "verse": "7",
      "text": "Their anger is so strong that God will curse them. Their anger makes them do cruel things. So God will curse them. I will make your descendants separate from one another. They will live all over the country of Israel."
    },
    {
      "verse": "8",
      "text": "Judah, your brothers will praise you. You will win against your enemies. Your father's sons will bend down towards the ground in front of you."
    },
    {
      "verse": "9",
      "text": "Judah is like a young lion who has eaten good food. He has eaten what he killed and now he rests. Nobody would want to try and wake him up!"
    },
    {
      "verse": "10",
      "text": "Judah's descendants will always rule as king. They will continue to hold the stick and the sceptre that show the king's authority. They will do that until the man comes who truly has that authority. People from all nations will obey that king."
    },
    {
      "verse": "11",
      "text": "Judah will tie his young donkey to a vine. It will be a vine that has the best grapes. He will wash his clothes in the red wine that is made from those grapes."
    },
    {
      "verse": "12",
      "text": "His eyes will become red because he drinks so much wine. His teeth will become white because he drinks so much milk."
    },
    {
      "verse": "13",
      "text": "Zebulun will live by the shore of the sea. His town will be a safe place for ships to stay. His land will go as far as Sidon."
    },
    {
      "verse": "14",
      "text": "Issachar is like a strong donkey that is lying down between two of its bags."
    },
    {
      "verse": "15",
      "text": "He will see that he has a good place to live, with good land. Then he will agree to work hard. He will work like a slave for other people."
    },
    {
      "verse": "16",
      "text": "Dan will be a ruler for his people. His descendants will be equal with the other tribes of Israel."
    },
    {
      "verse": "17",
      "text": "He will be small and dangerous, like a snake that lies beside the road. He will be like a snake that bites the legs of horses so that the riders fall off."
    },
    {
      "verse": "18",
      "text": "I trust you to save me from trouble, Lord."
    },
    {
      "verse": "19",
      "text": "Robbers will attack Gad, but he will fight back against them."
    },
    {
      "verse": "20",
      "text": "Asher will have much good food. It will be good enough for kings to eat."
    },
    {
      "verse": "21",
      "text": "Naphtali is like a deer that runs freely and gives birth to beautiful babies."
    },
    {
      "verse": "22",
      "text": "Joseph is like a vine that has lots of fruit. It grows near a well and its branches go over a wall."
    },
    {
      "verse": "23",
      "text": "His enemies will be angry with him. They will attack him with arrows."
    },
    {
      "verse": "24",
      "text": "But he will hold his own bow strongly. He will shoot his arrows well. The Mighty One of Jacob will give Joseph strength. God, who is Israel's Shepherd and Rock, will help him."
    },
    {
      "verse": "25",
      "text": "The Almighty God, the God of your father, will help you and he will bless you. He will give you rain that comes from the sky above. He will give you springs of water from below the ground. He will cause you to have many descendants. That is how God will bless you."
    },
    {
      "verse": "26",
      "text": "The blessings that I, your father, give to you are great! They are greater than any good things that the old mountains or hills can give to you. They are special blessings for you, Joseph, because you are the leader of your brothers."
    },
    {
      "verse": "27",
      "text": "Benjamin is like a hungry wolf. He kills an animal and eats it in the morning. In the evening, he gives what remains to his people. ’"
    },
    {
      "verse": "28",
      "text": "tribes of Israel. This is what their father said to them when he blessed them. He told each of his sons what was right for them and their descendants."
    },
    {
      "verse": "29",
      "text": "sons, ‘I will soon die. You must take my dead body back to Canaan. Bury me there with my ancestors. Bury me in the cave in the field that belonged to Ephron the Hittite."
    },
    {
      "verse": "30",
      "text": "The cave is at Machpelah, near Mamre in Canaan. Abraham bought this cave from Ephron as a place to bury his family."
    },
    {
      "verse": "31",
      "text": "That is where they buried Abraham and his wife Sarah. They also buried Isaac and his wife Rebekah there. I buried Leah there too."
    },
    {
      "verse": "32",
      "text": "Abraham bought the cave and the field from the Hittites. ’"
    },
    {
      "verse": "33",
      "text": "Jacob finished telling his sons what they should do. Then he lay down on his bed again. He breathed for the last time and he died there."
    }
  ],
  "50": [
    {
      "verse": "1",
      "text": "Joseph bent down near his father's face. He wept over him and he kissed him."
    },
    {
      "verse": "2",
      "text": "Then Joseph told some of his servants to take Jacob's body. They knew how to put special oil on the body so that it would not become spoiled. Joseph's servants did what he told them to do."
    },
    {
      "verse": "3",
      "text": "days, which is the usual time. The Egyptians wept for 70 days because of Jacob's death."
    },
    {
      "verse": "4",
      "text": "The time for them to weep came to an end. Joseph said to Pharaoh's officers, ‘If you agree, speak to Pharaoh for me. Tell him this:"
    },
    {
      "verse": "5",
      "text": "My father made me make a promise. He said, “I will soon die. Bury me in the grave that I prepared for myself in Canaan. ” So please let me go and bury my father there. Then I will return. ’"
    },
    {
      "verse": "6",
      "text": "Pharaoh said, ‘Go and bury your father's body in the way that you promised him. ’"
    },
    {
      "verse": "7",
      "text": "So Joseph went to Canaan to bury his father. All Pharaoh's officers went with him. The important people who lived in Pharaoh's palace, as well as the important Egyptian officers, all went with Joseph."
    },
    {
      "verse": "8",
      "text": "Everyone in Joseph's family also went with him. His brothers and their families went, but they did not take their young children or their animals. They left those in Goshen."
    },
    {
      "verse": "9",
      "text": "Many soldiers also went with them. Some of them rode in chariots and some rode on horses."
    },
    {
      "verse": "10",
      "text": "They came to Atad's threshing floor, near the Jordan River. They stayed there for seven days to weep for the death of Jacob. They were very sad."
    },
    {
      "verse": "11",
      "text": "The Canaanite people who lived near there saw how sad Joseph and his people were. So they gave Atad's threshing floor a different name. They called it ‘Abel Mizraim’. They said, ‘The Egyptians are showing that they are very sad because an important person has died. ’"
    },
    {
      "verse": "12",
      "text": "So Jacob's sons did what he had told them to do."
    },
    {
      "verse": "13",
      "text": "They carried his body to Canaan. They buried him there in the cave, in the field at Machpelah, near Mamre. That is the cave that Abraham had bought from Ephron the Hittite. He had bought it as a grave for him and for his family."
    },
    {
      "verse": "14",
      "text": "When Joseph had buried his father, he returned to Egypt together with his brothers. Everyone who had gone to Canaan with him also returned to Egypt."
    },
    {
      "verse": "15",
      "text": "Now Jacob was dead and Joseph's brothers became frightened. They said to each other, ‘We did a bad thing to Joseph. Now he will be angry and he will punish us for what we did. ’"
    },
    {
      "verse": "16",
      "text": "So they sent a message to Joseph. They said, ‘Your father said this to us before he died."
    },
    {
      "verse": "17",
      "text": "He told us to say to you, “Please forgive your brothers for the very bad thing that they did against you. They did a very cruel thing to you. ” So please forgive our sin. We are servants of your father's God. ’When Joseph received their message, he was very upset and he wept."
    },
    {
      "verse": "18",
      "text": "His brothers came to see him. They bent down low to the ground in front of Joseph. They said to him, ‘We are your slaves. ’"
    },
    {
      "verse": "19",
      "text": "But Joseph said to them, ‘Do not be afraid of me. It is God who has the authority to punish people. I am not God!"
    },
    {
      "verse": "20",
      "text": "You decided to hurt me. But God caused a good thing to happen because of that. God brought me here to save the lives of many people. You can see how that has really happened!"
    },
    {
      "verse": "21",
      "text": "So do not be afraid. I will continue to take care of you. You and your children will receive what you need. ’ In this way Joseph comforted them and he spoke kind words to them."
    },
    {
      "verse": "22",
      "text": "Joseph lived in Egypt, together with his father's family. He lived for 110 years."
    },
    {
      "verse": "23",
      "text": "And he was still alive to see Ephraim's children and grandchildren. He also saw Makir's children. Makir was Manasseh's son. Joseph took Makir's children to be his own children."
    },
    {
      "verse": "24",
      "text": "Then Joseph said to his brothers, ‘I will soon die. But God will come to you and he will help you. He will take you out of Egypt. He will take you back to the land that he promised to give to Abraham, Isaac and Jacob. ’"
    },
    {
      "verse": "25",
      "text": "He also said, ‘God will help you to leave Egypt. When that happens, you must carry my bones away from here. ’ Joseph made the other sons of Israel promise that they would do that."
    },
    {
      "verse": "26",
      "text": "years old. They put special oil on his body so that it would not become spoiled. Then they put his body in a box there in Egypt."
    }
  ]
};