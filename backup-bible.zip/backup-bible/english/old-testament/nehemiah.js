module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "These are the words of Nehemiah, Hacaliah's son. It was the month Kislev. This was when King Artaxerxes had ruled for 20 years. I was in the big city of Susa."
    },
    {
      "verse": "2",
      "text": "Hanani, my brother, and some other men arrived from Judah. I asked them for news of the Jews who had returned there from exile in Babylon. I asked them for news about Jerusalem."
    },
    {
      "verse": "3",
      "text": "They told me, ‘The Jews who returned to Judah are in much trouble. The walls of the city still have lots of holes in them. Fire has burned the city's gates down to the ground. So the people are very ashamed. ’"
    },
    {
      "verse": "4",
      "text": "After they told me this, I sat down and I wept. I was very sad for many days. I did not eat or drink anything and I prayed to God."
    },
    {
      "verse": "5",
      "text": "I prayed, ‘Lord, God of heaven, you are great and powerful. You always continue to love your people, as you have promised to do. You are kind to those people who love you and obey your commands."
    },
    {
      "verse": "6",
      "text": "Please listen to my prayer. I am your servant. I am praying in the day and in the night on behalf of your servants, the Israelites. I agree that we have all done wrong things. That includes me and my family. We have not obeyed you."
    },
    {
      "verse": "7",
      "text": "We have done wicked things against you. We have not obeyed the commands, the laws and the rules that you gave to your servant Moses."
    },
    {
      "verse": "8",
      "text": "Remember what you told your servant, Moses. You told him, “If the Israelites turn away from me, I will make them live among foreign people in many different places."
    },
    {
      "verse": "9",
      "text": "But if they return to me and they obey my commands, I will be kind to them. I will bring them back together again from all the different places where they are living. Even if they live far away, I will find them. I will bring them to the place that I have chosen to give honour to my name. ”"
    },
    {
      "verse": "10",
      "text": "Lord, these are your people and your servants. You used your great power and strength to rescue them. I was the king's cupbearer."
    },
    {
      "verse": "11",
      "text": "Please listen to my prayer, my Lord. Hear the prayers of your people who love to respect your name. Please cause the king to be kind to me. May he give me what I ask for. ’I was the king's cupbearer."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "It was the month of Nisan, when King Artaxerxes had ruled Babylon for 20 years. I had the king's wine ready for him to drink. I took it to give to him. He saw that I was sad. I had not been sad in front of the king before."
    },
    {
      "verse": "2",
      "text": "The king asked me, ‘Why are you sad? You are not ill. This must mean that you are very upset. ’ I was very frightened."
    },
    {
      "verse": "3",
      "text": "I replied to the king, ‘May the king live for ever! I am sad because enemies have destroyed the city where my ancestors are buried. They burned the city's gates. ’"
    },
    {
      "verse": "4",
      "text": "The king asked me, ‘What do you want me to do for you? ’ So I prayed to our God who rules from heaven."
    },
    {
      "verse": "5",
      "text": "Then I said to the king, ‘Please sir, if you think it is a good idea and you are pleased with me, let me go to Judah. If you agree to send me there, I can build again the city where my ancestors are buried. ’"
    },
    {
      "verse": "6",
      "text": "The king was sitting with the queen next to him. The king asked me, ‘How long will you be away? When will you return? ’ I told the king how long I would be away. Because the king was happy to send me, I told him when I would leave. The king agreed to do what I asked him, because my God was with me."
    },
    {
      "verse": "7",
      "text": "I said to the king, ‘If the king agrees, please give me some letters to say that I have your authority. I will show the letters to your officers who rule the region on the west side of the Euphrates river. Then I will be able to travel safely on the journey to Judah."
    },
    {
      "verse": "8",
      "text": "Also give me a letter for Asaph, who takes care of the king's forest there. Tell him to give me wood from the trees. I need to make beams to mend the gates of the strong place near the temple. I also need to mend the city's wall. And I need to build a house for myself to live in. ’The king agreed to do what I asked him, because my God was with me."
    },
    {
      "verse": "9",
      "text": "The king sent officers of his army to keep me safe on the journey. He also sent soldiers who rode on horses. I went to the king's officers on the west side of the Euphrates river. I gave them the letters which the king had written."
    },
    {
      "verse": "10",
      "text": "But two important men were not happy when they heard that I had come to help the Israelite people. They were Sanballat, who came from Horon, and Tobiah, an Ammonite officer."
    },
    {
      "verse": "11",
      "text": "I arrived in Jerusalem city. After three days,"
    },
    {
      "verse": "12",
      "text": "I went out at night. I took a few of my friends with me. I was riding on a donkey. That was the only animal that we took with us. I did not tell anyone the idea that God had put in my mind about Jerusalem."
    },
    {
      "verse": "13",
      "text": "I went through the Valley Gate to the Jackal Well and the Dung Gate. As I went, I looked carefully at Jerusalem's walls. They were broken. Fire had destroyed the city's gates."
    },
    {
      "verse": "14",
      "text": "I went to the Fountain Gate and then to the King's Pool. The path there was too narrow for my donkey to pass through."
    },
    {
      "verse": "15",
      "text": "So I went along the path in the valley while it was still night. I continued to look at the wall. I reached the Valley Gate again and I went back into the city."
    },
    {
      "verse": "16",
      "text": "The city's officers did not know that I had done this. I had not told anyone what I had decided to do. I had not told any of the other Jews, their priests, their leaders or the city's officers. I had not told any of the people who would help to do the work on the wall."
    },
    {
      "verse": "17",
      "text": "But then I said to them, ‘We have a big problem. Jerusalem has become a heap of stones. Fire has burned the gates. You must help to build the city's walls again. Then we will no longer be ashamed of our city. ’"
    },
    {
      "verse": "18",
      "text": "I told the people how God had helped me to come to Jerusalem. I told them what the king had said to me. Then the people said, ‘We will start to build now! ’The people prepared to start this good work."
    },
    {
      "verse": "19",
      "text": "But Sanballat, Tobiah and an Arab man called Geshem heard about what we were doing. They laughed at us and they insulted us. They said, ‘What are you trying to do? Have you turned against the king's authority? ’"
    },
    {
      "verse": "20",
      "text": "I replied to them, ‘Our God who rules from heaven will help us. We are his servants and we will start to build. But you have never been true citizens of Jerusalem. ’"
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "The leader of the priests, Eliashib, and the other priests built the Sheep Gate. They fixed the doors in it again. They built the wall as far as the Tower of the Hundred and the Tower of Hananel. They dedicated it all to God."
    },
    {
      "verse": "2",
      "text": "The men from Jericho built the next part of the city wall. Imri's son, Zakkur, built the next part of the wall."
    },
    {
      "verse": "3",
      "text": "The clan of Hassenaah built the Fish Gate. They put up the beams and they fixed its doors in their place. They made wooden bars and iron bars so that they could lock the doors."
    },
    {
      "verse": "4",
      "text": "Meremoth, son of Uriah, the son of Hakkoz, worked on the next part of the wall. Meshullam, son of Berekiah, the son of Meshezabel, repaired the wall next to Meremoth. Baana's son, Zadok, repaired the next part of the wall."
    },
    {
      "verse": "5",
      "text": "The men from Tekoa repaired the next part. But their town's leaders refused to do the hard work."
    },
    {
      "verse": "6",
      "text": "Paseah's son, Joiada, and Besodeiah's son, Meshullam, worked on the Old Gate. They put up the beams and they fixed its doors in their place. They made wooden bars and iron bars so that they could lock the doors."
    },
    {
      "verse": "7",
      "text": "Men from Gibeon and Mizpah repaired the wall next to the Old Gate. They included Melatiah from Gibeon and Jadon, who came from Meronoth. The officer who ruled the region on the west side of the Euphrates river had authority over those towns."
    },
    {
      "verse": "8",
      "text": "Harhaiah's son, Uzziel, repaired the next part of the wall. Uzziel was a man who made things from gold. Hananiah repaired the wall next to Uzziel. Hananiah knew how to make perfume. Hananiah and Uzziel repaired the wall as far as the Broad Wall."
    },
    {
      "verse": "9",
      "text": "Hur's son, Rephaiah, repaired the next part of the wall. Rephaiah ruled over part of Jerusalem."
    },
    {
      "verse": "10",
      "text": "Harumaph's son, Jedaiah, worked on the next part of the wall that was near to his own house. Hashabneiah's son, Hattush, repaired the wall next to Jedaiah."
    },
    {
      "verse": "11",
      "text": "Harim's son, Malkijah, and Pahath-Moab's son, Hasshub, worked on another part of the wall. They also repaired the Tower of the Ovens."
    },
    {
      "verse": "12",
      "text": "Hallohesh's son, Shallum, repaired the next part of the wall. He ruled over part of Jerusalem. Shallum's daughters helped him with the work."
    },
    {
      "verse": "13",
      "text": "Hanun and the people who lived in Zanoah repaired the Valley Gate. They built it and they fixed its doors in their place. They made wooden bars and iron bars so that they could lock the doors. The same people also repaired 450 metres of the city wall, as far as the Dung Gate."
    },
    {
      "verse": "14",
      "text": "Recab's son, Malkijah, repaired the Dung Gate. He put the doors in their place, as well as their wooden bars and iron bars. Malkijah had authority over the region of Beth Hakkerem."
    },
    {
      "verse": "15",
      "text": "Col-Hozeh's son, Shallun, repaired the Fountain Gate. He was the ruler of the region of Mizpah. Shallun built a roof over the Fountain Gate. He fixed its doors in their place, as well as their wooden bars and iron bars. Shallun also repaired the wall of the Pool of Siloam, near the king's garden. He repaired the wall as far as the steps that come down from the City of David."
    },
    {
      "verse": "16",
      "text": "Azbuk's son, Nehemiah, worked on another part of the wall. He was ruler of part of the region of Beth Zur. He repaired the wall along to the place of the royal graves. He continued to work as far as the pool that people had built and the House of the Brave Soldiers."
    },
    {
      "verse": "17",
      "text": "Levites worked along the next part of the wall. Bani's son, Rehum, worked there. Hashabiah repaired the next part of the wall. He ruled over part of the region of Keilah. He did the work on behalf of that region."
    },
    {
      "verse": "18",
      "text": "More Levites worked on the next part. Henadad's son, Binnui, worked there. He also ruled over part of Keilah."
    },
    {
      "verse": "19",
      "text": "Jeshua's son, Ezer, worked on another part of the wall. It was in front of the building where the soldiers kept their weapons. He repaired the wall as far as the corner. Ezer ruled over Mizpah."
    },
    {
      "verse": "20",
      "text": "Next, Zabbai's son, Baruch, worked hard on another part of the wall. He started from the corner of the wall and went as far as the door of Eliashib's house. Eliashib was the leader of the priests."
    },
    {
      "verse": "21",
      "text": "Meremoth, son of Uriah, the son of Hakkoz, repaired the next part, from the door of Eliashib's house to the end of it."
    },
    {
      "verse": "22",
      "text": "Priests from the region near Jerusalem repaired the next part of the wall."
    },
    {
      "verse": "23",
      "text": "Benjamin and Hasshub repaired the wall in front of their house. Next, Azariah, son of Maaseiah, the son of Ananiah, repaired the wall near his house."
    },
    {
      "verse": "24",
      "text": "Henadad's son, Binnui, repaired from Azariah's house to the corner, where it has a strong point."
    },
    {
      "verse": "25",
      "text": "Uzai's son, Palal, worked near the corner and the tower on the top of the king's palace. That was beside the yard for the guards. Parosh's son, Pedaiah,"
    },
    {
      "verse": "26",
      "text": "repaired the next part of the wall, towards the east. The temple servants who lived on Ophel Hill worked with them. They repaired the wall as far as the Water Gate and the tower which stands there."
    },
    {
      "verse": "27",
      "text": "The men from Tekoa repaired the wall from the place near the great tower as far as the wall of Ophel."
    },
    {
      "verse": "28",
      "text": "The priests repaired the wall on the north side of the Horse Gate. Each priest repaired the wall in front of his house."
    },
    {
      "verse": "29",
      "text": "Immer's son, Zadok, repaired the wall in front of his house. Next to him, Shecaniah's son, Shemaiah, repaired the wall. He was the guard at the city's East Gate."
    },
    {
      "verse": "30",
      "text": "Next, Shelemiah's son, Hananiah, repaired the wall. Hanun worked with him. He was the sixth son of Zalaph. Berekiah's son, Meshullam, repaired the wall in front of the place where he lived."
    },
    {
      "verse": "31",
      "text": "Malkijah repaired the wall as far as the temple servants' house. He continued to work as far as the traders' houses in front of the Meeting Gate. He repaired the wall as far as the room above the wall's corner. Malkijah made things from gold."
    },
    {
      "verse": "32",
      "text": "Between there and the Sheep Gate the traders and the men who worked with gold repaired the wall."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Sanballat heard that we were building the wall. He was very angry and upset. He laughed at the Jews."
    },
    {
      "verse": "2",
      "text": "His officers and Samaria's army were with him. He said to them, ‘Those Jews have great ideas, but they are weak. How will they ever repair the wall? Will they give sacrifices to their God? Will that help them to repair the wall in one day? They will never build anything from this heap of stones that fire has destroyed! ’"
    },
    {
      "verse": "3",
      "text": "Tobiah the Ammonite was with him. Tobiah said, ‘The wall that the Jews are trying to build is very weak. Even if a little fox climbs up on it, the stones would all fall down again! ’"
    },
    {
      "verse": "4",
      "text": "So I prayed, ‘Hear us, our God. Our enemies think that we are fools. Make them seem like fools themselves! Let their enemies take them away as slaves."
    },
    {
      "verse": "5",
      "text": "Do not forgive their sins. Do not say that they are not guilty. They have insulted us when we are trying to build. ’"
    },
    {
      "verse": "6",
      "text": "The people worked hard because they wanted to build the wall. As a result, the wall all round the city soon became half as high as the old wall."
    },
    {
      "verse": "7",
      "text": "Sanballat, Tobiah, the Arab people, the Ammonites and the people who came from Ashdod all heard that the work was continuing. They could see that we were repairing the holes in the wall. So they were very angry."
    },
    {
      "verse": "8",
      "text": "They met together to decide what they should do. They decided to attack Jerusalem so that there would be trouble."
    },
    {
      "verse": "9",
      "text": "So we continued to pray to our God. We also put guards on the walls in the day and the night, to keep the city safe."
    },
    {
      "verse": "10",
      "text": "Then the people in Judah complained, ‘Our workers are becoming weak. There are so many stones and rubbish! We cannot finish the work on the wall! ’"
    },
    {
      "verse": "11",
      "text": "At the same time, our enemies were boasting, ‘Before the Jews even see us, we will attack them. We will kill them before they know what is happening. That will be the end of their work on the wall! ’"
    },
    {
      "verse": "12",
      "text": "The Jews who lived near our enemies warned us many times. They told us that our enemies would attack us wherever we went."
    },
    {
      "verse": "13",
      "text": "So I put some men behind the lowest part of the wall where there were holes. Each of the families had guards with swords, spears, bows and arrows."
    },
    {
      "verse": "14",
      "text": "I went round the city and I looked at everything. I said to the leaders, the officers and the people, ‘Do not be afraid of our enemies. Remember that our Lord God is great and powerful. Fight on behalf of your brothers, your sons, your daughters and your wives. Fight to keep your homes safe. ’"
    },
    {
      "verse": "15",
      "text": "Our enemies realized that we knew what they had decided to do. God had stopped them from doing what they wanted. So each of us went back to our work on the wall."
    },
    {
      "verse": "16",
      "text": "After that day, half of my men continued to do the work on the wall. The other half carried spears, shields and bows. They also wore armour. The officers stood behind the people while they built the wall."
    },
    {
      "verse": "17",
      "text": "The men who were carrying materials held them with one hand. They held a weapon in their other hand."
    },
    {
      "verse": "18",
      "text": "All of the builders had swords tied on their belts while they were building. There was a man who would make a sound with his trumpet if there was danger. He stayed near me."
    },
    {
      "verse": "19",
      "text": "I said to the leaders, the officers and all the people, ‘It is hard work and the wall is very long. So we are not working near to each other."
    },
    {
      "verse": "20",
      "text": "When you hear the sound of the trumpet, come to join us here. Our God will fight on our behalf. ’"
    },
    {
      "verse": "21",
      "text": "We continued to work on the wall every day, from dawn until it became dark. Half of the men held spears to be our guards."
    },
    {
      "verse": "22",
      "text": "I said to the people, ‘Everybody must stay in Jerusalem each night, together with those who are helping them. Then they can be our guards to keep us safe at night. During each day they can do the work. ’"
    },
    {
      "verse": "23",
      "text": "I did not take my clothes off at night time, and neither did any of my friends. The workers and the guards who were with me kept their clothes on all the time. Everyone carried his own weapon whatever he was doing."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Some men and their wives were upset, because of the things that some other Jews were doing."
    },
    {
      "verse": "2",
      "text": "Many of them said, ‘We are big families, with many sons and daughters. We need to have food to eat so that we can stay alive. ’"
    },
    {
      "verse": "3",
      "text": "Other people said, ‘People have to lend us money to buy food. We have to give them our fields, our vineyards and our homes until we can pay them back. ’"
    },
    {
      "verse": "4",
      "text": "Other people said, ‘We have to pay taxes to the king for our fields and our vineyards. People had to lend us money to pay the taxes."
    },
    {
      "verse": "5",
      "text": "Now we have to sell our sons and daughters as slaves so that we can pay back the money. But we are from the same human family as those other Jews. Our children are not different from their children. Already some of our daughters have become slaves. Our fields and vineyards now belong to other people, so we are helpless to do anything. ’"
    },
    {
      "verse": "6",
      "text": "When I heard what they were complaining about, I was very angry."
    },
    {
      "verse": "7",
      "text": "I thought carefully about what they had said. Then I said to the Jewish leaders and officers, ‘You are cheating your own people! You are taking back more money than you have lent to them. ’I told the Jews to come together for a big meeting."
    },
    {
      "verse": "8",
      "text": "I said to them all, ‘When our own Jewish people have become slaves of foreign people, we have tried hard to buy them back. But now you are making your own people sell their children to you. And you want us to pay you to buy them back again! ’ The Jewish leaders kept quiet. They had nothing to say."
    },
    {
      "verse": "9",
      "text": "Then I said to them, ‘You are doing something that is completely wrong. Instead, you should obey God and live in a good way. Then the foreign people who are our enemies will not have a chance to insult us."
    },
    {
      "verse": "10",
      "text": "I myself have agreed to lend poor people money and food. My family and my friends have done the same thing. But we must not make those poor people pay back more to us."
    },
    {
      "verse": "11",
      "text": "Now you must give back to them their fields, their vineyards, their gardens of olive trees and their houses. Do not make them pay any extra money for the money, food, wine or olive oil that you lent to them. ’"
    },
    {
      "verse": "12",
      "text": "The leaders replied, ‘We will give everything back to them. We will not make them pay back their debts to us. We will do everything that you have said. ’I told the priests to come to our meeting. While they were with us, I made the Jewish leaders and officers make a strong promise. They agreed to do what they had promised to do."
    },
    {
      "verse": "13",
      "text": "I shook my coat so that everything fell out of its pockets. I said, ‘You must all do what you have promised to do. If not, I pray that God will shake you out like that! He will take away your homes and all your things. You will be left with nothing! ’ Everyone at the meeting said, ‘Amen, we agree! ’ They praised the Lord. All the people did what they had promised to do. All the people did what they had promised to do."
    },
    {
      "verse": "14",
      "text": "All the time that I ruled the land of Judah, I did not eat the government officer's special food. I was the ruler from the 20th year of King Artaxerxes until his 32nd year as king. For all those 12 years, I and my relatives refused to eat the special food."
    },
    {
      "verse": "15",
      "text": "The officers who ruled there before I came made much trouble for the people. They took food and wine from the people, as well as 40 silver coins every day. Their servants also gave the people much trouble. But I did not live like them, because I wanted to please God."
    },
    {
      "verse": "16",
      "text": "I worked hard to help the work on the city's walls. I did not take any land for myself. All my servants also had to join with me in the work."
    },
    {
      "verse": "17",
      "text": "Jews and their officers ate meals with me. There were also people who came to visit from countries that were near to us."
    },
    {
      "verse": "18",
      "text": "Every day, my servants cooked one ox, six good sheep and some birds for us to eat. Every ten days they bought for me many different kinds of wine. But I did not ask to receive the extra food that the ruler usually receives. The people were working hard on the wall and I did not want to give them more trouble."
    },
    {
      "verse": "19",
      "text": "My God, please remember the many things that I have done to help my people. Please bless me."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "We had finished building the city's wall. There were no holes in it now, but we had not fixed the doors in the gates. Sanballat, Tobiah, Geshem (the Arab) and all our enemies heard that we had finished building the wall."
    },
    {
      "verse": "2",
      "text": "Sanballat and Geshem sent this message to me: ‘Come and meet with us in a village on the low land of Ono. ’I realized that they wanted to cause trouble for me."
    },
    {
      "verse": "3",
      "text": "So I sent this message back to them: ‘I am too busy to come and meet you. The work here is too important. I cannot stop the work here to come and meet you. ’"
    },
    {
      "verse": "4",
      "text": "They sent me the same message four times. Each time, I refused."
    },
    {
      "verse": "5",
      "text": "Then Sanballat sent his officer to me with a fifth message. He carried a letter that was open for anyone to read."
    },
    {
      "verse": "6",
      "text": "This is what the letter said: ‘To Nehemiah. Other nations have heard the news that you and the other Jews have decided to turn against the king. Geshem also says that this is true. This is why you are building the city's wall. People are saying that you want to rule the Jews as their king."
    },
    {
      "verse": "7",
      "text": "You have chosen some prophets to speak your message in Jerusalem. You have told them to say, “There is now a king in Judah! ” The king of Persia will surely hear this news. So we must meet together and talk about it. ’"
    },
    {
      "verse": "8",
      "text": "I sent this reply: ‘What you say is not true. Nothing like that is happening. You are only speaking your own ideas. ’"
    },
    {
      "verse": "9",
      "text": "All our enemies wanted to frighten us. They thought, ‘The Jews will be so afraid that they will not be able to work well. They will not finish building the wall. ’So I prayed to God, ‘Give me strength to continue the work. ’ So I prayed to God, ‘Give me strength to continue the work. ’"
    },
    {
      "verse": "10",
      "text": "One day I went to Shemaiah's house. He was the son of Delaiah, Mehetabel's son. He could not go out of his house. He said to me, ‘Meet me inside the temple of God. We will close the temple's doors. Our enemies are coming to kill you. One night soon, they will come to kill you. ’"
    },
    {
      "verse": "11",
      "text": "But I said, ‘I am not a man who would run away to be safe. I will not go into the temple to save my life. ’"
    },
    {
      "verse": "12",
      "text": "Then I realized that Shemaiah was not telling me a message from God. I knew that Tobiah and Sanballat had paid him to say this to me."
    },
    {
      "verse": "13",
      "text": "They wanted to frighten me so that I would hide in the temple. My enemies knew that this would be a sin. If I did that, I would be ashamed. People would no longer respect me."
    },
    {
      "verse": "14",
      "text": "My God, please remember all the bad things that Tobiah and Sanballat have done. Also remember the prophetess, Noadiah, and the other prophets who have tried to frighten me."
    },
    {
      "verse": "15",
      "text": "We finished the city's wall on the 25th day of the month Elul. It had taken 52 days to build the wall again."
    },
    {
      "verse": "16",
      "text": "When our enemies heard this news, they were afraid. The people of all the nations who lived near Jerusalem were very afraid. They knew that our God had helped us to finish this great work."
    },
    {
      "verse": "17",
      "text": "During this time, the leaders in Judah were sending letters to Tobiah. Tobiah was also sending his replies to them."
    },
    {
      "verse": "18",
      "text": "Many people in Judah had promised to obey Tobiah. That was because his wife was the daughter of Arah's son, Shecaniah. Also, his son Jehohanan had married the daughter of Berekiah's son, Meshullam."
    },
    {
      "verse": "19",
      "text": "The leaders would often speak about the good things that Tobiah had done. They would then go and tell Tobiah everything that I had said. So Tobiah continued to send letters to frighten me."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "When we had built the wall, we fixed the doors in their places. We chose men to be guards for the city's gates. We also chose singers and Levites to serve God."
    },
    {
      "verse": "2",
      "text": "I gave authority over Jerusalem to my brother Hanani and to Hananiah. Hananiah was the leader of the men in Jerusalem's strong building. He was a faithful man who respected God more than many men do."
    },
    {
      "verse": "3",
      "text": "I said to them, ‘Do not open Jerusalem's gates until the sun is high in the sky. Shut the gates and lock them while the guards are still there. Choose people who live in Jerusalem to be guards for the city. Some guards must stand at the city's gates. Other guards must stand near their own houses. ’"
    },
    {
      "verse": "4",
      "text": "Jerusalem was a large city, but not many people lived in it. We had not yet built many houses."
    },
    {
      "verse": "5",
      "text": "It was not easy to keep the city safe. Then God put an idea in my mind. I called the leaders, the officers and the other people to meet together. I wanted to check the lists of their families. I found the list of those people who had first returned to Jerusalem."
    },
    {
      "verse": "6",
      "text": "This is the list of the Jews who returned to Jerusalem and the other towns of Judah. King Nebuchadnezzar had taken them away as prisoners to Babylon. Now each of them had returned to live in his own town. This is a list of the number of men in each Israelite clan who returned:"
    },
    {
      "verse": "7",
      "text": "These people came from Babylon with Zerubbabel, Jeshua, Nehemiah, Azariah, Raamiah, Nahamani, Mordecai, Bilshan, Mispereth, Bigvai, Nehum and Baanah. This is a list of the number of men in each Israelite clan who returned:"
    },
    {
      "verse": "8",
      "text": "The clan of Parosh: 2, 172."
    },
    {
      "verse": "9",
      "text": "The clan of Shephatiah: 372."
    },
    {
      "verse": "10",
      "text": "The clan of Arah: 652."
    },
    {
      "verse": "11",
      "text": "The clan of Pahath-Moab (descendants of Jeshua and Joab): 2, 818."
    },
    {
      "verse": "12",
      "text": "The clan of Elam: 1, 254."
    },
    {
      "verse": "13",
      "text": "The clan of Zattu: 845."
    },
    {
      "verse": "14",
      "text": "The clan of Zaccai: 760."
    },
    {
      "verse": "15",
      "text": "The clan of Binnui: 648."
    },
    {
      "verse": "16",
      "text": "The clan of Bebai: 628."
    },
    {
      "verse": "17",
      "text": "The clan of Azgad: 2, 322."
    },
    {
      "verse": "18",
      "text": "The clan of Adonikam: 667."
    },
    {
      "verse": "19",
      "text": "The clan of Bigvai: 2, 067."
    },
    {
      "verse": "20",
      "text": "The clan of Adin: 655."
    },
    {
      "verse": "21",
      "text": "The clan of Ater (descendants of Hezekiah): 98."
    },
    {
      "verse": "22",
      "text": "The clan of Hashum: 328."
    },
    {
      "verse": "23",
      "text": "The clan of Bezai: 324."
    },
    {
      "verse": "24",
      "text": "The clan of Hariph: 112."
    },
    {
      "verse": "25",
      "text": "The clan of Gibeon: 95."
    },
    {
      "verse": "26",
      "text": "The number of men who belonged to these towns: Bethlehem and Netophah: 188."
    },
    {
      "verse": "27",
      "text": "Anathoth: 128."
    },
    {
      "verse": "28",
      "text": "Beth Azmaveth: 42."
    },
    {
      "verse": "29",
      "text": "Kiriath-Jearim, Kephirah and Beeroth: 743."
    },
    {
      "verse": "30",
      "text": "Ramah and Geba: 621."
    },
    {
      "verse": "31",
      "text": "Michmash: 122."
    },
    {
      "verse": "32",
      "text": "Bethel and Ai: 123."
    },
    {
      "verse": "33",
      "text": "The other Nebo: 52."
    },
    {
      "verse": "34",
      "text": "The other Elam: 1, 254."
    },
    {
      "verse": "35",
      "text": "Harim: 320."
    },
    {
      "verse": "36",
      "text": "Jericho: 345."
    },
    {
      "verse": "37",
      "text": "Lod, Hadid and Ono: 721."
    },
    {
      "verse": "38",
      "text": "Senaah: 3, 930."
    },
    {
      "verse": "39",
      "text": "These priests also returned: The clan of Jedaiah (descendants of Jeshua): 973."
    },
    {
      "verse": "40",
      "text": "The clan of Immer: 1, 052."
    },
    {
      "verse": "41",
      "text": "The clan of Pashhur: 1, 247."
    },
    {
      "verse": "42",
      "text": "The clan of Harim: 1, 017."
    },
    {
      "verse": "43",
      "text": "These Levites also returned: The clans of Jeshua and Kadmiel (descendants of Hodaviah): 74."
    },
    {
      "verse": "44",
      "text": "Singers who were descendants of Asaph: 148."
    },
    {
      "verse": "45",
      "text": "Temple guards who were descendants of Shallum, Ater, Talmon, Akkub, Hatita and Shobai: 138."
    },
    {
      "verse": "46",
      "text": "These were the families of the temple servants who returned: Ziha, Hasupha, Tabbaoth,"
    },
    {
      "verse": "47",
      "text": "Keros, Sia, Padon,"
    },
    {
      "verse": "48",
      "text": "Lebana, Hagaba, Shalmai,"
    },
    {
      "verse": "49",
      "text": "Hanan, Giddel, Gahar,"
    },
    {
      "verse": "50",
      "text": "Reaiah, Rezin, Nekoda,"
    },
    {
      "verse": "51",
      "text": "Gazzam, Uzza, Paseah,"
    },
    {
      "verse": "52",
      "text": "Besai, Meunim, Nephussim,"
    },
    {
      "verse": "53",
      "text": "Bakbuk, Hakupha, Harhur,"
    },
    {
      "verse": "54",
      "text": "Bazluth, Mehida, Harsha,"
    },
    {
      "verse": "55",
      "text": "Barkos, Sisera, Temah,"
    },
    {
      "verse": "56",
      "text": "Neziah and Hatipha."
    },
    {
      "verse": "57",
      "text": "These were the servants of King Solomon whose descendants returned: Sotai, Sophereth, Perida,"
    },
    {
      "verse": "58",
      "text": "Jaala, Darkon, Giddel,"
    },
    {
      "verse": "59",
      "text": "Shephatiah, Hattil, Pokereth-Hazzebaim and Amon."
    },
    {
      "verse": "60",
      "text": "The temple servants and the descendants of Solomon's servants were 392 men."
    },
    {
      "verse": "61",
      "text": "There were some people who came from the towns of Tel Melah, Tel Harsha, Kerub, Addon and Immer. But they had no lists to show that they belonged to Israelite families."
    },
    {
      "verse": "62",
      "text": "There were from the clans of Delaiah, Tobiah and Nekoda: 642."
    },
    {
      "verse": "63",
      "text": "There were also some priests from the clans of Hobaiah, Hakkoz and Barzillai. (Barzillai was a man who had married a daughter of Barzillai, who came from Gilead. So he took Barzillai's name for himself. )"
    },
    {
      "verse": "64",
      "text": "These people could not find any lists to show who their ancestors were. Because of this, they could not serve God as priests."
    },
    {
      "verse": "65",
      "text": "The officer who ruled in Judah said that they must not eat the priests' special food. They must wait until there was a priest who could use the Urim and Thummim to decide the right thing to do."
    },
    {
      "verse": "66",
      "text": "The number of all the people who returned to Judea was 42, 360."
    },
    {
      "verse": "67",
      "text": "There were also 7, 337 male and female servants, as well as 245 male and female singers."
    },
    {
      "verse": "68",
      "text": "horses and 245 mules,"
    },
    {
      "verse": "69",
      "text": "camels and 6, 720 donkeys."
    },
    {
      "verse": "70",
      "text": "Some of the family leaders gave money to help build the wall. The officer who ruled there gave 8. 5 kilograms of gold, 50 bowls and 530 sets of special clothes for the priests."
    },
    {
      "verse": "71",
      "text": "kilograms of gold and 1, 300 kilograms of silver."
    },
    {
      "verse": "72",
      "text": "kilograms of gold and 1, 300 kilograms of silver. They also gave 67 sets of special clothes for the priests."
    },
    {
      "verse": "73",
      "text": "The priests, the Levites, the temple guards, the singers and the temple servants now lived in towns near Jerusalem. The other people also lived in the towns of Judah. When the seventh month of the year arrived, all the Israelite people were living in their towns and cities."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "All the people met together in the open place near the Water Gate. They asked Ezra to bring the book of the Law of Moses. The Lord had given those laws to the Israelites so that they would obey them."
    },
    {
      "verse": "2",
      "text": "On the first day of the seventh month, Ezra brought the book of the Law to the people. In the crowd, there were men and women, as well as children who were old enough to understand."
    },
    {
      "verse": "3",
      "text": "Ezra read aloud while he stood there, in the open place near the Water Gate. He read to all the men, women and children from dawn until noon. Everyone listened carefully to Ezra while he read the book of the Law."
    },
    {
      "verse": "4",
      "text": "Ezra stood on a tall tower to speak to the people. They had built it from wood so that they could hear him. Mattithiah, Shema, Anaiah, Uriah, Hilkiah and Maaseiah stood at his right side. Pedaiah, Mishael, Malkijah, Hashum, Hashbaddanah, Zechariah and Meshullam stood at his left side."
    },
    {
      "verse": "5",
      "text": "Ezra opened the book. All the people could see him because he was high above them. When he opened the book, the crowd all stood up."
    },
    {
      "verse": "6",
      "text": "Ezra praised the Lord, the great God. All the people lifted their hands and they shouted, ‘Amen! Amen! ’ They bent their heads to the ground and they worshipped the Lord."
    },
    {
      "verse": "7",
      "text": "As the people listened, some Levites taught them the meaning of God's Law. The names of the Levites were: Jeshua, Bani, Sherebiah, Jamin, Akkub, Shabbethai, Hodiah, Maaseiah, Kelita, Azariah, Jozabad, Hanan and Pelaiah."
    },
    {
      "verse": "8",
      "text": "They read the book of the Law and they explained it to the people. They helped the people to understand what Ezra read to them."
    },
    {
      "verse": "9",
      "text": "Then Ezra (the priest who studied God's Law), Nehemiah (the ruler) and the Levites who were teaching the people said to all the people, ‘Do not cry or weep. Today is a special holy day for the Lord your God. ’They said this because the people were weeping. The words of the Law had made them sad."
    },
    {
      "verse": "10",
      "text": "Nehemiah said to the people, ‘Go to your homes and eat some good food. Drink sweet drinks. Share your food and your drink with people who do not have enough for themselves. This is a holy day for our Lord, so do not be sad. The Lord will give you joy so that you can be strong. ’"
    },
    {
      "verse": "11",
      "text": "The Levites also comforted the people. They said, ‘Do not weep. Today is a holy day, so do not be sad. ’"
    },
    {
      "verse": "12",
      "text": "Then the people went away to eat and to drink. They shared their food with other people. They were very happy because they now understood God's word that they had heard."
    },
    {
      "verse": "13",
      "text": "On the second day of the seventh month, the leaders of families met together. They met with the priests, the Levites and with Ezra. They wanted to study the message of God's Law."
    },
    {
      "verse": "14",
      "text": "They discovered what the Lord had commanded about a certain feast. The Lord had told Moses that the Israelites should live in huts during this feast. They should do that in the seventh month of each year."
    },
    {
      "verse": "15",
      "text": "They discovered that they must send a message to everyone in Jerusalem and all Judah's cities. They must tell people, ‘Go into the hill country. Bring back branches from olive trees, wild olive trees, myrtle trees, palm trees and other trees with lots of leaves. Use these branches to build huts to live in. That is what God's Law teaches. ’"
    },
    {
      "verse": "16",
      "text": "So the people went out and they brought back branches. They built huts on their roofs and in the yards of their houses. They also built them in the yards of the temple and in the open places near the Water Gate and the Gate of Ephraim."
    },
    {
      "verse": "17",
      "text": "Everyone who had returned from exile built a hut. They lived in them during the feast and they were very happy. The Israelites had not done this before, since the time of Nun's son, Joshua."
    },
    {
      "verse": "18",
      "text": "Every day of the feast, Ezra read aloud from the book of God's Law. The feast continued for seven days. On the eighth day, the people all met together, as the Law said that they should do."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "On the 24th day of the same month, the Israelite people met together. They did not eat or drink. They wore sackcloth and they put dust on their heads."
    },
    {
      "verse": "2",
      "text": "The Israelite people made themselves separate from foreign people. They stood up and they told God that they were sorry for their sins. They agreed that their ancestors had also done many bad things."
    },
    {
      "verse": "3",
      "text": "While the Israelites stood there, they read from the book of God's Law during a quarter of the day. During another quarter of the day they told the Lord their God about their sins and they worshipped him."
    },
    {
      "verse": "4",
      "text": "The Levites stood on some high steps. They called out in a loud voice to the Lord their God. Those Levites were Jeshua, Binnui, Kadmiel, Shebaniah, Bunni, Sherebiah, Bani and Kenani."
    },
    {
      "verse": "5",
      "text": "Then the Levites (Jeshua, Kadmiel, Bani, Hashabneiah, Sherebiah, Hodiah, Shebaniah and Pethahiah) said, ‘Stand up and praise the Lord your God. He lives always and for ever. ’They said, ‘Your name is great and wonderful. We praise you more than words could ever say."
    },
    {
      "verse": "6",
      "text": "Only you are the Lord. You made the sky and the heavens above the sky. You made all the stars, the earth and everything on it. You made the seas and everything in them. You give life to everything. The great crowd of angels in heaven bend down low to worship you."
    },
    {
      "verse": "7",
      "text": "You are the Lord God who chose Abram. You brought him out of Ur, in Babylonia. You changed his name to be Abraham."
    },
    {
      "verse": "8",
      "text": "You knew that Abraham trusted you, so you made a covenant with him. You promised to give the land of Canaan to his descendants. That was the country where the Canaanites, Hittites, Amorites, Perizzites, Jebusites and Girgashites lived. You have done what you promised to do, because you are righteous."
    },
    {
      "verse": "9",
      "text": "You saw that our ancestors had trouble and pain in Egypt. You heard them cry to you for help at the Red Sea."
    },
    {
      "verse": "10",
      "text": "You did great miracles to show your power against Pharaoh, his officers and all his people. You knew that they were being cruel to your people. You showed everyone that you are a great God. And people still know that it is true."
    },
    {
      "verse": "11",
      "text": "You divided the sea into two parts so that your people could cross it on a dry path. When Pharaoh's soldiers chased after them, you threw them into the sea. They drowned in the water, like a heavy stone."
    },
    {
      "verse": "12",
      "text": "During the day, you led your people with a pillar of cloud. At night, you led them with a pillar of fire to give them light. You showed them the way that they should travel."
    },
    {
      "verse": "13",
      "text": "At Sinai mountain, you came down from heaven and you spoke to your people. You gave them your laws, rules and commands, which are good, fair and true."
    },
    {
      "verse": "14",
      "text": "You told them about the Sabbath and how to make it a special day. You gave all your laws to Moses so that he would teach them to your people."
    },
    {
      "verse": "15",
      "text": "You gave your people bread from heaven when they were hungry. You gave them water from a rock to drink when they were thirsty. You commanded them to go to the land that you had promised to give them. You told them to take it for themselves."
    },
    {
      "verse": "16",
      "text": "But our ancestors turned away from you. They would not agree to obey your commands."
    },
    {
      "verse": "17",
      "text": "They refused to obey you. They forgot about all the miracles that you had done to help them. Instead, they turned against you. They chose a leader to take them back to Egypt, where they had been slaves. But you are a God who forgives people. You are kind to people. You are slow to get angry and your love for your people always continues. So you did not leave your people alone."
    },
    {
      "verse": "18",
      "text": "Our ancestors made an image of a young cow to be their god. They said to each other, “This is our god who brought us out of Egypt. ” They insulted you in that way, but you still did not turn away from your people."
    },
    {
      "verse": "19",
      "text": "You were kind to them while they travelled in the desert. You continued to lead them with a pillar of cloud in the day. At night, you continued to show them the way with a pillar of fire. So they always knew which way to go."
    },
    {
      "verse": "20",
      "text": "You gave them your good Spirit to teach them what to do. You continued to give them manna from heaven to eat. You gave them water from a rock to drink."
    },
    {
      "verse": "21",
      "text": "years you took care of them in the desert. Their clothes did not spoil. Their feet did not become big with pain."
    },
    {
      "verse": "22",
      "text": "You gave kingdoms and nations to your people. The borders of their land reached a long way. The land of King Sihon of Heshbon became their own land. So did the land of King Og of Bashan."
    },
    {
      "verse": "23",
      "text": "You caused your people to have many descendants, as many as the stars in the sky. You brought them to the land that you had promised to their ancestors. You had told them to go and live in it."
    },
    {
      "verse": "24",
      "text": "Their descendants went there and they took the land for themselves. You gave them power over the Canaanites and the other kings and nations who lived there. They could do whatever they wanted with those people."
    },
    {
      "verse": "25",
      "text": "They took their strong cities and their good land for themselves. The houses of those people were full of many good things. Your people could use the things that were already there. They had their wells, their vineyards, their olive trees and other fruit trees. They had as much food as they could eat, so they became fat. The many good things that you gave them made them very happy."
    },
    {
      "verse": "26",
      "text": "But your people did not obey you. They turned against you. They stopped obeying your laws. You sent your prophets to warn your people to return to you. But they killed the prophets that you sent to them. Your people insulted you in many bad ways."
    },
    {
      "verse": "27",
      "text": "So you put them under the power of their enemies. And their enemies were cruel to them. Then your people called to you for help because they were in trouble. You heard them from your home in heaven. Because you are so kind, you gave them strong leaders. And those leaders saved them from their enemies."
    },
    {
      "verse": "28",
      "text": "But when your people were living safely again, they did evil things again. So you left them to the power of their enemies. Your people called to you again for help. You heard them again from your home in heaven. Because you are so kind, you rescued them like that many times."
    },
    {
      "verse": "29",
      "text": "You warned them to obey your laws. But they refused to listen to you. They did not obey your commands. You had given them rules which would help them to have true life if they obeyed them. But they would not obey your laws. They turned away from you and they continued to do bad things."
    },
    {
      "verse": "30",
      "text": "You continued to help your people for many years. You sent your prophets to tell them messages from your Spirit. You warned them, but they refused to listen. So you put them under the power of the nations who lived near them."
    },
    {
      "verse": "31",
      "text": "But because you are very kind, you did not turn away from them or destroy them. You are a God who is very kind and you forgive people."
    },
    {
      "verse": "32",
      "text": "So we pray to you, our God. You are great and powerful. You continue to love your people as you have promised in your covenant with us. Please see how much trouble has come to us! Our kings, our leaders, our priests, our prophets and our ancestors and your people all belong to you. We have all had many great troubles since the time that the kings of Assyria attacked us."
    },
    {
      "verse": "33",
      "text": "But when you punished us like that, you were right to do it. You have always been faithful. It is us who have done wicked things."
    },
    {
      "verse": "34",
      "text": "Our kings, our leaders, our priests and our ancestors have not obeyed your laws. They have not listened to your commands. You warned them but they would not listen."
    },
    {
      "verse": "35",
      "text": "When they had their own kingdom, they still would not agree to serve you. You gave them a good land to live in, with plenty of food. They enjoyed your good gifts, but they would not obey you. They did not stop doing evil things."
    },
    {
      "verse": "36",
      "text": "So today we live like slaves. Yes, we are slaves in the land that you gave to our ancestors. You wanted them to enjoy all the good things that grow here."
    },
    {
      "verse": "37",
      "text": "But because of our sins you have caused foreign kings to rule over us. They take the food that grows in our fields. They use us and our animals in any way that they like. So we are very upset! ’"
    },
    {
      "verse": "38",
      "text": "‘Because of this we Israelite people are all making a promise. We are writing down our agreement to serve the Lord. Our leaders, our Levites and our priests will write their names on it to give it their authority. ’"
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "These people put their mark of authority on the promise that they had written: Hacaliah's son, Nehemiah (the government officer), and Zedekiah."
    },
    {
      "verse": "2",
      "text": "Seraiah, Azariah, Jeremiah,"
    },
    {
      "verse": "3",
      "text": "Pashhur, Amariah, Malkijah,"
    },
    {
      "verse": "4",
      "text": "Hattush, Shebaniah, Malluch,"
    },
    {
      "verse": "5",
      "text": "Harim, Meremoth, Obadiah,"
    },
    {
      "verse": "6",
      "text": "Daniel, Ginnethon, Baruch,"
    },
    {
      "verse": "7",
      "text": "Meshullam, Abijah, Mijamin,"
    },
    {
      "verse": "8",
      "text": "Maaziah, Bilgai and Shemaiah. Those were the priests."
    },
    {
      "verse": "9",
      "text": "The Levites were: Azaniah's son, Jeshua, Binnui from the clan of Henadad, Kadmiel."
    },
    {
      "verse": "10",
      "text": "Their relatives: Shebaniah, Hodiah, Kelita, Pelaiah, Hanan,"
    },
    {
      "verse": "11",
      "text": "Mica, Rehob, Hashabiah,"
    },
    {
      "verse": "12",
      "text": "Zaccur, Sherebiah, Shebaniah,"
    },
    {
      "verse": "13",
      "text": "Hodiah, Bani and Beninu."
    },
    {
      "verse": "14",
      "text": "The Israelite leaders: Parosh, Pahath-Moab, Elam, Zattu, Bani,"
    },
    {
      "verse": "15",
      "text": "Bunni, Azgad, Bebai,"
    },
    {
      "verse": "16",
      "text": "Adonijah, Bigvai, Adin,"
    },
    {
      "verse": "17",
      "text": "Ater, Hezekiah, Azzur,"
    },
    {
      "verse": "18",
      "text": "Hodiah, Hashum, Bezai,"
    },
    {
      "verse": "19",
      "text": "Hariph, Anathoth, Nebai,"
    },
    {
      "verse": "20",
      "text": "Magpiash, Meshullam, Hezir,"
    },
    {
      "verse": "21",
      "text": "Meshezabel, Zadok, Jaddua,"
    },
    {
      "verse": "22",
      "text": "Pelatiah, Hanan, Anaiah,"
    },
    {
      "verse": "23",
      "text": "Hoshea, Hananiah, Hasshub,"
    },
    {
      "verse": "24",
      "text": "Hallohesh, Pilha, Shobek,"
    },
    {
      "verse": "25",
      "text": "Rehum, Hashabnah, Maaseiah,"
    },
    {
      "verse": "26",
      "text": "Ahiah, Hanan, Anan,"
    },
    {
      "verse": "27",
      "text": "Malluch, Harim and Baanah."
    },
    {
      "verse": "28",
      "text": "The other people joined their leaders to make the same promise. They were priests, Levites, guards, singers and temple servants. There were also people who had kept themselves separate from their foreign neighbours so that they could obey God's Law. Their wives, sons and daughters also joined with them, as well as children who were old enough to understand."
    },
    {
      "verse": "29",
      "text": "All these people joined with their leaders and they promised to obey the agreement. They agreed that God should punish them if they did not obey all of God's Law. That was the Law that God had given to his servant Moses. They promised very strongly to obey all the commands, rules and laws of the Lord, our Lord."
    },
    {
      "verse": "30",
      "text": "They said, ‘We promise not to let our daughters marry the foreign people of this land. We will not let our sons marry their daughters."
    },
    {
      "verse": "31",
      "text": "If foreign traders come to us on a Sabbath day, we will not buy their things. We will not buy their things on Sabbath days or on any special feast day. Every seventh year we will not plant any crops. We will also remove the debts of other people in every seventh year. They will not have to pay us back."
    },
    {
      "verse": "32",
      "text": "We will obey the command to give a third of a shekel each year to take care of the temple of our God."
    },
    {
      "verse": "33",
      "text": "That will pay for the special bread on the table in the temple. It will also pay for grain offerings and burnt offerings each day, as well as offerings on Sabbath days, feasts at each new moon, and other festivals. We will also use it for the sin offerings that take away Israel's guilt. And we will use it for all the work in the temple of our God."
    },
    {
      "verse": "34",
      "text": "Each year we will throw dice to decide when different families must bring wood to the temple of our God. The priests, the Levites and the other people must do this. The wood will burn sacrifices on the altar of the Lord our God. We will do this in the way that the Law of the Lord our God teaches. We agree that we will always take care of the temple of our God. ’"
    },
    {
      "verse": "35",
      "text": "We will also agree to bring the first crops from our land each year and the first fruits from our trees. We will bring these to the Lord's temple."
    },
    {
      "verse": "36",
      "text": "We will also bring our firstborn sons, as well as the first babies that our cows, sheep and goats give birth to. We will bring them to the priests who serve our God in the temple. That is what God's Law teaches us to do."
    },
    {
      "verse": "37",
      "text": "We will also bring the first of everything that is ready for us to eat. That includes flour, fruit, wine, olive oil and other special offerings. We will bring them all to the priests and they will store them in the rooms of the temple. We will give tithes of the crops that grow on our land to the Levites. They receive the tithes that belong to them in each of the towns where we work."
    },
    {
      "verse": "38",
      "text": "When the Levites receive their tithes, a priest of Aaron's family will be with them. Then the Levites will bring a tenth part of the tithes that they received to store in the temple."
    },
    {
      "verse": "39",
      "text": "The Levites and the other Israelites will bring their gifts of grain, wine and olive oil to store in the temple's rooms. The priests will store them with the things that they use to serve God in the temple. That is the place where the priests who are working at that time, the temple guards and the singers stay. We agree that we will always take care of the temple of our God. ’"
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "The leaders of the Israelite people lived in Jerusalem. The other people threw dice to choose which other families would live there too. From every group of ten families they chose one family to live in Jerusalem, God's special city. The other families would stay in their own towns."
    },
    {
      "verse": "2",
      "text": "The people asked God to bless all the men who chose to live in Jerusalem."
    },
    {
      "verse": "3",
      "text": "These are the leaders of the region of Judah who went to live in Jerusalem. Other Israelites, priests, Levites, temple servants and descendants of King Solomon's servants lived in the other towns of Judah. Each of them lived in their own homes. From the tribe of Judah:"
    },
    {
      "verse": "4",
      "text": "But some of Judah's and Benjamin's descendants went to live in Jerusalem. This is who they were: From the tribe of Judah: Athaiah, son of Uzziah and Zechariah's grandson. His other ancestors were: Amariah, Shephatiah and Mahalalel. They were descendants of Judah's son, Perez."
    },
    {
      "verse": "5",
      "text": "Maaseiah, son of Baruch and Col-Hozeh's grandson. His other ancestors were: Hazaiah, Adaiah, Joiarib and Zechariah. They were descendants of Judah's son, Shelah."
    },
    {
      "verse": "6",
      "text": "descendants of Perez who went to live in Jerusalem. They were all brave men."
    },
    {
      "verse": "7",
      "text": "From the tribe of Benjamin: Sallu, son of Meshullam and Joed's grandson. His other ancestors were: Pedaiah, Kolaiah, Maaseiah, Ithiel and Jeshaiah."
    },
    {
      "verse": "8",
      "text": "Sallu's relatives, Gabbai and Sallai were also there. There were 928 men from Benjamin's tribe."
    },
    {
      "verse": "9",
      "text": "Zicri's son, Joel, was the officer with authority over them. Hassenuah's son, Judah, was the next most important officer in the city."
    },
    {
      "verse": "10",
      "text": "From the priests: Joiarib's son, Jedaiah, and Jakin."
    },
    {
      "verse": "11",
      "text": "Seraiah, son of Hilkiah and Meshullam's grandson. His other ancestors were: Zadok, Meraioth and Ahitub. Ahitub had been the most important priest in God's temple."
    },
    {
      "verse": "12",
      "text": "Their relatives worked with them in the temple. There were 822 men from that clan. Adaiah, son of Jeroham and Pelaliah's grandson. His other ancestors were: Amzi, Zechariah, Pashhur and Malkijah."
    },
    {
      "verse": "13",
      "text": "His relatives were with him. There were 242 men from that clan who were leaders of their families. Amashsai, son of Azarel and Ahzai's grandson. Ahzai was the son of Meshillemoth, son of Immer."
    },
    {
      "verse": "14",
      "text": "His friends were with him. They were 128 strong brave men from that clan. Haggedolim's son, Zabdiel, was the officer with authority over them."
    },
    {
      "verse": "15",
      "text": "From the Levites: Shemaiah, son of Hasshub and Azrikam's grandson. Azrikam was the son of Hashabiah, son of Bunni."
    },
    {
      "verse": "16",
      "text": "Shabbethai and Jozabad were leaders of the Levites who had authority over work on the outside of God's temple."
    },
    {
      "verse": "17",
      "text": "Mattaniah, son of Mica and Zabdi's grandson. Zabdi was Asaph's son. Mattaniah led the people when they prayed and they thanked God. Bakbukiah helped Mattaniah, as well as Shammua's son, Abda. Shammua was the son of Galal, the son of Jeduthun."
    },
    {
      "verse": "18",
      "text": "Levites lived in the holy city, Jerusalem."
    },
    {
      "verse": "19",
      "text": "The temple guards were: Akkub, Talmon and their relatives. There were 172 guards who watched the gates."
    },
    {
      "verse": "20",
      "text": "The other Israelite people, priests and Levites lived in the other towns of Judah. They lived in the homes that belonged to their families."
    },
    {
      "verse": "21",
      "text": "The temple servants lived on Ophel Hill. Ziha and Gishpa had authority over them."
    },
    {
      "verse": "22",
      "text": "Uzzi was the leader of the Levites in Jerusalem. He was the son of Bani and grandson of Hashabiah. His other ancestors were Mattaniah and Mica. Uzzi was one of Asaph's descendants. Asaph's family were the singers who had authority for the music in the temple."
    },
    {
      "verse": "23",
      "text": "The king commanded the singers what they must do each day."
    },
    {
      "verse": "24",
      "text": "Meshezabel's son, Pethahiah, was one of the king's advisors. He helped the king of Persia to know how to rule the Israelite people. Pethahiah was a descendant of Judah's son, Zerah."
    },
    {
      "verse": "25",
      "text": "Many people of Judah lived in villages with their farms near them. Some of them lived in Kiriath Arba, Dibon and Jekabzeel, and in the villages near those towns."
    },
    {
      "verse": "26",
      "text": "Other people lived in Jeshua, Moladah, Beth Pelet"
    },
    {
      "verse": "27",
      "text": "and Hazar-Shual, as well as in Beersheba and the villages near it."
    },
    {
      "verse": "28",
      "text": "Other people lived in Ziklag and Meconah and the villages near it."
    },
    {
      "verse": "29",
      "text": "Some people lived in En Rimmon, Zorah, Jarmuth,"
    },
    {
      "verse": "30",
      "text": "Zanoah and Adullam and the villages near to those towns. Other people lived in Lachish and its fields, and in Azekah and its villages. The people were living everywhere from Beersheba to the Hinnom Valley."
    },
    {
      "verse": "31",
      "text": "Some of Benjamin's descendants lived in Geba, Michmash, Aija, Bethel and its villages."
    },
    {
      "verse": "32",
      "text": "Some of them lived in Anathoth, Nob, Ananiah,"
    },
    {
      "verse": "33",
      "text": "Hazor, Ramah and Gittaim."
    },
    {
      "verse": "34",
      "text": "They also lived in Hadid, Zeboim Neballat,"
    },
    {
      "verse": "35",
      "text": "Lod, Ono and Ge-Harashim."
    },
    {
      "verse": "36",
      "text": "Some of the Levites' clans who belonged with Judah went to live in Benjamin's land."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "This is a list of the priests and the Levites who returned with Zerubbabel, son of Shealtiel, and with Jeshua: Seraiah, Jeremiah, Ezra, These men were the leaders of the priests and the people who helped them in the time of Jeshua."
    },
    {
      "verse": "2",
      "text": "Amariah, Malluch, Hattush,"
    },
    {
      "verse": "3",
      "text": "Shecaniah, Rehum, Meremoth,"
    },
    {
      "verse": "4",
      "text": "Iddo, Ginnethon, Abijah,"
    },
    {
      "verse": "5",
      "text": "Mijamin, Moadiah, Bilgah,"
    },
    {
      "verse": "6",
      "text": "Shemaiah, Joiarib, Jedaiah,"
    },
    {
      "verse": "7",
      "text": "Sallu, Amok, Hilkiah and Jedaiah. These men were the leaders of the priests and the people who helped them in the time of Jeshua."
    },
    {
      "verse": "8",
      "text": "The Levites were: Jeshua, Binnui, Kadmiel, Sherebiah, Judah and Mattaniah. Mattaniah and his relatives had authority for the songs which they sang to thank God in the temple."
    },
    {
      "verse": "9",
      "text": "Bakbukiah and Unni and their relatives joined them when they sang."
    },
    {
      "verse": "10",
      "text": "Jeshua was the father of Joiakim. Joiakim was the father of Eliashib. Eliashib was the father of Joiada,"
    },
    {
      "verse": "11",
      "text": "Joiada was the father of Jonathan, and Jonathan was the father of Jaddua."
    },
    {
      "verse": "12",
      "text": "In the time of Joiakim, these were the priests who were leaders of their clans: Meraiah was the leader of Seraiah's clan. Hananiah was the leader of Jeremiah's clan."
    },
    {
      "verse": "13",
      "text": "Meshullam was the leader of Ezra's clan. Jehohanan was the leader of Amariah's clan."
    },
    {
      "verse": "14",
      "text": "Jonathan was the leader of Malluch's clan. Joseph was the leader of Shecaniah's clan."
    },
    {
      "verse": "15",
      "text": "Adna was the leader of Harim's clan. Helkai was the leader of Meremoth's clan."
    },
    {
      "verse": "16",
      "text": "Zechariah was the leader of Iddo's clan. Meshullam was the leader of Ginnethon's clan."
    },
    {
      "verse": "17",
      "text": "Zicri was the leader of Abijah's clan. Piltai was the leader of the clans of Miniamin and Moadiah."
    },
    {
      "verse": "18",
      "text": "Shammua was the leader of Bilgah's clan. Jehonathan was the leader of Shemaiah's clan."
    },
    {
      "verse": "19",
      "text": "Mattenai was the leader of Joiarib's clan. Uzzi was the leader of Jedaiah's clan."
    },
    {
      "verse": "20",
      "text": "Kallai was the leader of Sallu's clan. Eber was the leader of Amok's clan."
    },
    {
      "verse": "21",
      "text": "Hashabiah was the leader of Hilkiah's clan. Nethanel was the leader of Jedaiah's clan."
    },
    {
      "verse": "22",
      "text": "During the time when Eliashib, Joiada, Johanan and Jaddua were the leaders of the priests, they recorded the names of the Levites and the priests who were leaders of their clans. At the time when King Darius ruled Persia, they stopped doing this."
    },
    {
      "verse": "23",
      "text": "They wrote the names of Levi's descendants who were leaders of their clans in the history book of Israel. They did that until the time of Eliashib's son, Johanan."
    },
    {
      "verse": "24",
      "text": "The leaders of the Levites were: Hashabiah, Sherebiah, Kadmiel's son, Jeshua, and their relatives. The two groups stood opposite each other to sing and praise and thank God. They did this in the way that God's servant, King David, had commanded. The two groups stood opposite each other to sing and praise and thank God. They did this in the way that God's servant, King David, had commanded."
    },
    {
      "verse": "25",
      "text": "The guards for the temple gates were: Mattaniah, Bakbukiah, Obadiah, Meshullam, Talmon and Akkub. They watched the temple rooms near the gates, where they stored special things."
    },
    {
      "verse": "26",
      "text": "They served as guards in the time of Joiakim, son of Jeshua and grandson of Jozadak. This was in the time when Nehemiah had authority over Judah, and Ezra the priest was teaching people God's Law."
    },
    {
      "verse": "27",
      "text": "This is what happened when we dedicated the wall of Jerusalem to God. The people told the Levites to come to Jerusalem from the places where they lived. They wanted the Levites to help them to praise God with joy. The Levites would sing songs to thank God. They would make music with cymbals, harps and lyres."
    },
    {
      "verse": "28",
      "text": "The temple singers came together from places near Jerusalem. They came from villages round Netophah,"
    },
    {
      "verse": "29",
      "text": "and from Beth Gilgal, Geba and Azmaveth. The singers had built these villages so that they could live near to Jerusalem."
    },
    {
      "verse": "30",
      "text": "The priests and the Levites made themselves clean to serve God. Then they made the people clean, as well as the city's gates and its wall."
    },
    {
      "verse": "31",
      "text": "I took the leaders of Judah to go and stand on top of the wall. I chose two large groups of singers to thank God with songs. I told the first group to walk along the wall to the south, in the direction of the Dung Gate."
    },
    {
      "verse": "32",
      "text": "Hoshaiah and half of the leaders of Judah followed this group of singers."
    },
    {
      "verse": "33",
      "text": "Azariah, Ezra, Meshullam,"
    },
    {
      "verse": "34",
      "text": "Judah, Benjamin, Shemaiah and Jeremiah also followed them."
    },
    {
      "verse": "35",
      "text": "Some priests with trumpets went with them. They included Jonathan's son, Zechariah. He was a descendant of Asaph, through Shemaiah, Mattaniah, Micaiah and Zaccur, Asaph's son."
    },
    {
      "verse": "36",
      "text": "These other people helped Zechariah: Shemaiah, Azarel, Milalai, Gilalai, Maai, Nethanel, Judah and Hanani. They all had musical instruments, as King David had told them. Ezra, the teacher of God's Law, led this group of people."
    },
    {
      "verse": "37",
      "text": "When they arrived at the Fountain Gate they all went up the steps of the City of David. While they went up the steps, they passed King David's palace. Then they continued along the wall to the Water Gate, on the east side of the city."
    },
    {
      "verse": "38",
      "text": "The second group of singers went in the opposite direction. I followed them along the top of the wall, with half of the people. We went past the Tower of the Ovens and we continued to the Broad Wall."
    },
    {
      "verse": "39",
      "text": "Then we went over the Gate of Ephraim and over the Jeshanah Gate. We went along to the Fish Gate, the Tower of Hananel, the Tower of the Hundred and the Sheep Gate. We stopped at the Gate of the Guards."
    },
    {
      "verse": "40",
      "text": "Then the two groups of singers went to stand in the yard of God's temple. I went with them, together with half of the officers."
    },
    {
      "verse": "41",
      "text": "The priests who had trumpets were there: Eliakim, Maaseiah, Miniamin, Micaiah, Elioenai, Zechariah and Hananiah."
    },
    {
      "verse": "42",
      "text": "Maaseiah, Shemaiah, Eleazar, Uzzi, Jehohanan, Malkijah, Elam and Ezer followed them. Jezrahiah led the groups of singers, so that they sang loudly."
    },
    {
      "verse": "43",
      "text": "On that day, the people offered many sacrifices to God. They were full of joy because God had caused them to be very happy. Men, women and children were all shouting with joy. Far away from the city, people could hear the noise!"
    },
    {
      "verse": "44",
      "text": "On the same day, we chose men to take care of the rooms where they stored the people's gifts. Those gifts to God were the first fruits from the harvest and the tithes. They had to bring these gifts from the fields near each city. They read this in the law. They were gifts for the Levites and the priests, as God's Law commanded. The people of Judah were happy to help the priests and Levites who served God."
    },
    {
      "verse": "45",
      "text": "The priests and the Levites did the work that God had given them to make the people clean. The temple singers and guards also served God in the way that King David and his son Solomon had commanded."
    },
    {
      "verse": "46",
      "text": "Long ago, at the time when King David and Asaph were alive, there had been people to lead the singers. They sang songs to praise God and to thank him."
    },
    {
      "verse": "47",
      "text": "In the time of Zerubbabel and Nehemiah, all the Israelites shared their food with the singers and the guards. Every day they kept separate the part that was for the Levites. The Levites also kept separate the part that was for the priests."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "On that day, we read the book of Moses aloud to the people. One of the laws said that no descendant of Ammon or Moab should ever join with God's people when they met together."
    },
    {
      "verse": "2",
      "text": "This was because they had not given the Israelites food and water. Instead, they had paid Balaam to curse the Israelites. But God did not agree to curse them. He blessed them instead."
    },
    {
      "verse": "3",
      "text": "When the Israelite people heard this law, they sent away all the people who had foreign ancestors."
    },
    {
      "verse": "4",
      "text": "Before this happened, I had given Eliashib the priest authority over the temple rooms where they stored special things. Eliashib was a friend of Tobiah."
    },
    {
      "verse": "5",
      "text": "Eliashib let Tobiah use one of these rooms in the temple. It was a large room where they had stored the grain offerings, the incense and the special plates and tools that they used in the temple. They also stored the tithes of grain, wine and olive oil in that room. These gifts were for the Levites, the temple singers and guards, and also for the priests."
    },
    {
      "verse": "6",
      "text": "But when this happened, I was not in Jerusalem. In the 32nd year that King Artaxerxes ruled in Babylon, I had returned to visit him. After I had been there for some time, I asked the king to let me return to Jerusalem."
    },
    {
      "verse": "7",
      "text": "When I arrived back in Jerusalem, I heard about the evil thing that Eliashib had done. He had given Tobiah a large room in the yards of God's temple."
    },
    {
      "verse": "8",
      "text": "I was very angry, so I threw all Tobiah's things out of the room."
    },
    {
      "verse": "9",
      "text": "I gave a command that they must make the rooms clean again. Then I put back the special plates and tools that they used in the temple. I also put back the grain offerings and the incense."
    },
    {
      "verse": "10",
      "text": "I also discovered that there was no food that should have been there for the Levites. As a result, the Levites and the singers had returned to work in their fields. They were not doing their work in God's temple."
    },
    {
      "verse": "11",
      "text": "I warned the officers. I told them, ‘You have stopped taking care of God's temple! ’ Then I told the Levites and the other workers to return to their jobs in the temple."
    },
    {
      "verse": "12",
      "text": "After that, all the people in Judah brought their tithes of grain and wine and olive oil to store in the temple rooms."
    },
    {
      "verse": "13",
      "text": "I gave Shelemiah the priest, Zadok, the student of God's Law, and Pedaiah, a Levite, authority to take care of the rooms. Hanan, son of Zaccur and Mattaniah's grandson, helped them. People knew that these men were faithful workers. They had authority to give out the offerings to the other workers who served God."
    },
    {
      "verse": "14",
      "text": "Please remember what I have done, my God. I have been faithful to take care of the temple of my God, so that people can worship you there."
    },
    {
      "verse": "15",
      "text": "In those days, I saw people in Judah who were working on Sabbath days. They were making wine. They were bringing their grain from the fields. They were making their donkeys carry the grain, as well as wine, grapes, figs and other things. They were bringing all those things into Jerusalem when it was a Sabbath day. I warned them that they must not sell things on any Sabbath day."
    },
    {
      "verse": "16",
      "text": "People from Tyre who lived in Jerusalem sold fish and other things when it was a Sabbath day. They even brought those things into Jerusalem and sold them to the people of Judah."
    },
    {
      "verse": "17",
      "text": "I was angry with the leaders of Judah. I said to them, ‘You are doing an evil thing. You are not making the Sabbath a special day."
    },
    {
      "verse": "18",
      "text": "Your ancestors did the same thing. That is why God punished them and he brought trouble on this city. Now you will make God even more angry with us, Israel's people. You are insulting God's Sabbath day. ’"
    },
    {
      "verse": "19",
      "text": "So I gave a command to the guards at the city's gates. I told them, ‘You must close the gates in the evening before each Sabbath day begins. Do not open the gates again until the Sabbath day has finished. ’ I told some of my own men to stand at the gates. They would watch carefully so that no traders would bring things into Jerusalem on any Sabbath day."
    },
    {
      "verse": "20",
      "text": "A few times, some traders stayed outside Jerusalem all night, with the things that they wanted to sell. My God, please remember this good thing that I have done. Because of your faithful love, please be kind to me."
    },
    {
      "verse": "21",
      "text": "I warned them, ‘Do not stay beside the city's wall all night. If you do this again, I will take hold of you. ’ After I said that, they did not come again to Jerusalem on a Sabbath day."
    },
    {
      "verse": "22",
      "text": "Then I told the Levites that they must make themselves ready to serve God. I told them to go and stand at the gates as guards. They must keep the Sabbath day as a special day for God. My God, please remember this good thing that I have done. Because of your faithful love, please be kind to me."
    },
    {
      "verse": "23",
      "text": "Also at that time, I discovered that men from Judah had married foreign women. They were women who came from Ashdod, Ammon and Moab."
    },
    {
      "verse": "24",
      "text": "Half of their children spoke the language of Ashdod, or a language of the other foreign nations. They did not know how to speak the language of Judah."
    },
    {
      "verse": "25",
      "text": "I was angry with them. I asked God to curse them. I hit some of the men. I pulled out the hair of some of them. I told them to make a promise in God's name. I said to them, ‘You must not let your daughters marry the sons of those foreign people. You must not let their daughters marry your sons. You yourselves must not marry foreign women either."
    },
    {
      "verse": "26",
      "text": "Solomon, king of Israel, did a bad thing when he married foreign women. There was no other king as great as him in any other nation. God loved him. God chose him to be king over all Israel. But Solomon's foreign wives caused him to do bad things, even though he was so great."
    },
    {
      "verse": "27",
      "text": "We can never agree to all the evil things that you have done. If we all married foreign women, we would not be faithful to our God. ’"
    },
    {
      "verse": "28",
      "text": "Joiada was the son of Eliashib, the leader of the priests. One of Joiada's sons had married a daughter of Sanballat, who came from Horon. I sent Joiada's son away from Jerusalem."
    },
    {
      "verse": "29",
      "text": "My God, remember what these people have done. They have not been faithful to you as your priests. They have spoiled the covenant that you made with the priests and the other descendants of Levi."
    },
    {
      "verse": "30",
      "text": "After that, I made the priests and the Levites clean to serve God. I made them become separate from any foreign thing. I told each of them which job they should do. My God, please remember to bless me."
    },
    {
      "verse": "31",
      "text": "I also made sure that people brought wood to the temple for sacrifices on the altar. I made them bring the first crops and fruits from their fields for the offerings. My God, please remember to bless me."
    }
  ]
};