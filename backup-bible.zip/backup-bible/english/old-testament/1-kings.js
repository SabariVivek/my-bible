module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "King David was now a very old man. He could not stay warm, even when people put blankets over him."
    },
    {
      "verse": "2",
      "text": "So his servants said to him, ‘We will look for a young woman who has never had sex, for you, our master the king. She can take care of you and she can be your nurse. She can also sleep beside you, so that our master the king will be warm. ’"
    },
    {
      "verse": "3",
      "text": "So they looked through all the land of Israel for a beautiful young woman. They chose Abishag, who lived in Shunem. They brought her to the king."
    },
    {
      "verse": "4",
      "text": "She was very beautiful. She took care of the king as his servant. But the king did not have sex with her."
    },
    {
      "verse": "5",
      "text": "At that time, David's son Adonijah, was telling everyone, ‘I will become the next king. ’ He got for himself chariots and men who would ride on horses. He also had 50 men to run in front of him as his guards. Haggith was Adonijah's mother."
    },
    {
      "verse": "6",
      "text": "His father, David, had never warned him when he did something wrong. He never asked Adonijah, ‘Why are you doing that? ’ Adonijah was also very handsome. He was born after Absalom as David's next son."
    },
    {
      "verse": "7",
      "text": "Adonijah spoke with Zeruiah's son Joab and with Abiathar, the priest. They said that they would help Adonijah."
    },
    {
      "verse": "8",
      "text": "But these people did not join Adonijah's group: Zadok the priest, Jehoiada's son Benaiah, Nathan the prophet, Shimei and Rei. David's own special soldiers did not join Adonijah either."
    },
    {
      "verse": "9",
      "text": "Then Adonijah went to the Stone of Zoheleth that was near En Rogel. He killed sheep, cows and fat calves as sacrifices there. He asked these people to join him: all his brothers, who were King David's sons, all the men of Judah who were the king's officers."
    },
    {
      "verse": "10",
      "text": "But he did not ask these people to come: Nathan the prophet, Benaiah, David's own special soldiers, his brother Solomon."
    },
    {
      "verse": "11",
      "text": "Nathan said to Bathsheba, Solomon's mother, ‘Have you heard about the things that Haggith's son Adonijah is doing? He has become king, but our master, David, does not know about it."
    },
    {
      "verse": "12",
      "text": "Please accept my advice so that you can save your life and the life of Solomon, your son."
    },
    {
      "verse": "13",
      "text": "Go to King David and say to him, “My master the king, do you remember your strong promise to me? You told me that my son Solomon would certainly become king after you. You said that he would sit on your throne. So why has Adonijah now become king? ”"
    },
    {
      "verse": "14",
      "text": "While you are still talking to the king, I will come in. I will say that your report is true. ’"
    },
    {
      "verse": "15",
      "text": "So Bathsheba went to see the king in his bedroom. The king was very old. Abishag, the young woman from Shunem, was taking care of him."
    },
    {
      "verse": "16",
      "text": "Bathsheba bent down low in front of the king. The king asked her, ‘What do you want? ’"
    },
    {
      "verse": "17",
      "text": "She replied, ‘My master, you made a strong promise to me in the name of the Lord your God. You said to me, “Your son Solomon will become king after me. He will sit on my throne. ”"
    },
    {
      "verse": "18",
      "text": "But see what has happened! Adonijah has become king. But, my master the king, you do not even know about it!"
    },
    {
      "verse": "19",
      "text": "Adonijah has killed many cows, fat calves and sheep as sacrifices. He has asked the all the king's sons, Abiathar the priest and Joab the leader of the army to join him. But he did not ask your servant Solomon to come."
    },
    {
      "verse": "20",
      "text": "My master the king, everyone in Israel is waiting for you to speak. You must tell them who you have chosen to sit on the throne after you."
    },
    {
      "verse": "21",
      "text": "If you do not decide this now, there will be trouble for me and my son Solomon. Soon after they bury you in the grave of your ancestors, they will punish us as bad people. ’"
    },
    {
      "verse": "22",
      "text": "While Bathsheba was saying this to the king, Nathan the prophet arrived."
    },
    {
      "verse": "23",
      "text": "The king's servants told him, ‘Nathan the prophet is here. ’ So Nathan went in to the king's bedroom. He bent low with his face towards the ground."
    },
    {
      "verse": "24",
      "text": "Nathan said, ‘My master the king, have you decided that Adonijah will become king after you? Have you said that he will sit on your throne?"
    },
    {
      "verse": "25",
      "text": "Today Adonijah has killed many cows, fat calves and sheep as sacrifices. He has asked all the king's sons, the leaders of the army and Abiathar the priest to join with him. Even now, they are having a big feast with him. They are saying, “May King Adonijah live for a long time! ”"
    },
    {
      "verse": "26",
      "text": "But he did not ask me, your servant, to join him. He did not ask Zadok the priest, Jehoiada's son Benaiah, or your servant Solomon."
    },
    {
      "verse": "27",
      "text": "Has my master the king decided this, but you have not told us, your servants? We must know who will sit on your throne to rule as king after you. ’"
    },
    {
      "verse": "28",
      "text": "King David answered Nathan, ‘Send Bathsheba to me! ’ So Bathsheba came and she stood in front of the king."
    },
    {
      "verse": "29",
      "text": "Then the king made a strong promise. He said, ‘The Lord has saved me from every kind of trouble. I promise this, as surely as the Lord lives!"
    },
    {
      "verse": "30",
      "text": "I will certainly do what I already promised to you in the name of the Lord, Israel's God. Your son Solomon will become king after me. He will sit on my throne to rule. ’"
    },
    {
      "verse": "31",
      "text": "Then Bathsheba bent down low with her face towards the ground. She said, ‘I pray that my master King David will live for ever! ’"
    },
    {
      "verse": "32",
      "text": "King David said, ‘Send to me Zadok the priest, Nathan the prophet and Jehoiada's son Benaiah. ’ So they came to the king."
    },
    {
      "verse": "33",
      "text": "The king said to them, ‘Take my officers with you and put my son Solomon on my own mule. Then lead him down to Gihon, as he rides on the mule."
    },
    {
      "verse": "34",
      "text": "There, Zadok the priest and Nathan the prophet can anoint him to be king over Israel. Make a loud noise with a trumpet and shout, “May King Solomon live for a long time! ”"
    },
    {
      "verse": "35",
      "text": "After that, you must follow him back here. He will sit on my throne as king instead of me. I have chosen him to be ruler over all Israel and Judah. ’"
    },
    {
      "verse": "36",
      "text": "Jehoiada's son Benaiah answered the king, ‘Amen! I agree! I pray that the Lord will cause it to happen! He is the God that my master the king serves."
    },
    {
      "verse": "37",
      "text": "The Lord has helped you, my master the king. We pray that he will also be with Solomon. We pray that he will make Solomon's kingdom even greater than the kingdom of my master, King David! ’"
    },
    {
      "verse": "38",
      "text": "So Zadok the priest, Nathan the prophet and Jehoiada's son Benaiah went to Solomon. David's own personal guards, the Kerethites and the Pelethites, went with them. They put Solomon on King David's mule and they led him to Gihon."
    },
    {
      "verse": "39",
      "text": "Zadok the priest filled a horn with special olive oil from the holy tent. Then he poured it on Solomon to anoint him as king. Then they made a loud noise with a trumpet. All the people shouted, ‘May King Solomon live for a long time! ’"
    },
    {
      "verse": "40",
      "text": "Then all the people followed Solomon up into Jerusalem. They made music with flutes and they shouted with joy. The noise caused the ground to shake!"
    },
    {
      "verse": "41",
      "text": "Adonijah and all the people who were with him heard the noise. They had just finished eating their feast together. When Joab heard the sound of the trumpet, he asked, ‘Why is there all that noise in the city? ’"
    },
    {
      "verse": "42",
      "text": "While Joab was still speaking, Jonathan, the son of Abiathar the priest, arrived. Adonijah said to him, ‘Come in! You are an honest man, so I am sure that you are bringing good news. ’"
    },
    {
      "verse": "43",
      "text": "Jonathan replied to Adonijah, ‘No, it is not good news! Our master King David has made Solomon king!"
    },
    {
      "verse": "44",
      "text": "He sent these people to put Solomon onto the king's mule: Zadok the priest, Nathan the prophet, Jehoiada's son Benaiah, and the king's personal guards. They took Solomon to Gihon."
    },
    {
      "verse": "45",
      "text": "Then Zadok the priest and Nathan the prophet anointed Solomon at Gihon to become king. They have taken him from there into the city with happy shouts. People are shouting everywhere. That is the noise that you can hear."
    },
    {
      "verse": "46",
      "text": "So Solomon now sits on the king's throne."
    },
    {
      "verse": "47",
      "text": "The king's officers have told our master King David that he has done a good thing. They have said to him, “We pray that your God will make Solomon even more famous than you. We pray that his kingdom will be greater than your kingdom. ” After they said that, the king bent his head down as he lay on his bed."
    },
    {
      "verse": "48",
      "text": "He said, “We should praise the Lord, Israel's God. He deserves this, because he has chosen one of my sons to become king after me. The Lord has let me see this happen. ” ’"
    },
    {
      "verse": "49",
      "text": "When all the people with Adonijah heard Jonathan's report, they were very afraid. They got up from the feast and they ran away in different directions."
    },
    {
      "verse": "50",
      "text": "But Adonijah was afraid of what Solomon would do to punish him. So he ran to the holy tent. He took hold of the horns of the altar there."
    },
    {
      "verse": "51",
      "text": "Someone told Solomon, ‘Adonijah is afraid of you. He has taken hold of the horns of the altar. He says, “I want King Solomon to promise me today that he will not punish me with death. I am his servant. ” ’"
    },
    {
      "verse": "52",
      "text": "Solomon said, ‘If he serves me faithfully, I will not hurt him at all. But if he turns against me, he will die. ’"
    },
    {
      "verse": "53",
      "text": "Then King Solomon sent men to the holy tent to bring Adonijah down from the altar. So Adonijah came. He bent down low to respect King Solomon. Solomon said to him, ‘Go to your home. ’"
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "David knew that he would soon die. So this is what he said to his son Solomon:"
    },
    {
      "verse": "2",
      "text": "‘Soon I will die, as everyone must die one day. Be strong and brave, as a man should be. “Your descendants must be careful in how they live. They must serve me faithfully with all their mind and strength. If they do that, one of your descendants will always rule Israel as king. ”"
    },
    {
      "verse": "3",
      "text": "Do what the Lord your God tells you to do. Live in a way that pleases him. Obey his rules, commands and laws that Moses has written down in his books of God's Law. Then everything that you do will go well, wherever you go."
    },
    {
      "verse": "4",
      "text": "The Lord will also do what he has promised me that he will do. He promised this to me:“Your descendants must be careful in how they live. They must serve me faithfully with all their mind and strength. If they do that, one of your descendants will always rule Israel as king. ”"
    },
    {
      "verse": "5",
      "text": "Do not forget what Zeruiah's son Joab did to me. He killed the two leaders of Israel's armies, Ner's son Abner and Jether's son Amasa. Joab killed them as if they were his enemies in a war. But there was no war. So he is guilty of their deaths when they had done nothing wrong. Their blood is on his belt and on his shoes."
    },
    {
      "verse": "6",
      "text": "So you should punish him in a way that you think is right. Do not let him die in peace as an old man."
    },
    {
      "verse": "7",
      "text": "Be kind to the sons of Barzillai, who lived in Gilead. Let them eat meals at your table. Help them, because they helped me when I was running away from your brother Absalom."
    },
    {
      "verse": "8",
      "text": "Remember that Shimei is still there to give you trouble. He is the son of Gera who came from Bahurim, and he belonged to Benjamin's tribe. When I went to Mahanaim, he prayed that terrible things would happen to me. But when he came to meet me at the Jordan River, I made a promise to him. I promised him in the Lord's name that I would not punish him with death."
    },
    {
      "verse": "9",
      "text": "But remember that he is guilty! You are a wise man, so you will know what to do to him. Even if he is an old man, make sure that he has a violent death. ’"
    },
    {
      "verse": "10",
      "text": "Then David died. They buried him in the City of David."
    },
    {
      "verse": "11",
      "text": "years. He ruled for seven years in Hebron. Then he ruled for 33 years in Jerusalem."
    },
    {
      "verse": "12",
      "text": "So Solomon ruled as king on the throne of his father David. His kingdom became strong."
    },
    {
      "verse": "13",
      "text": "Haggith's son Adonijah visited Bathsheba, Solomon's mother. She asked him, ‘Do you come in peace? ’ He answered, ‘Yes, I come in peace. ’"
    },
    {
      "verse": "14",
      "text": "Then he said, ‘I want to say something to you. ’ She replied, ‘Tell me. ’"
    },
    {
      "verse": "15",
      "text": "Adonijah said, ‘You know that the kingdom should belong to me. All the Israelite people thought that I should be their king. But everything changed, and now my brother is the king instead of me. The Lord decided that he should be king."
    },
    {
      "verse": "16",
      "text": "Now I have one thing to ask you. Please do not refuse me. ’ Bathsheba replied, ‘Tell me. ’"
    },
    {
      "verse": "17",
      "text": "So Adonijah said, ‘Please ask King Solomon to give me Abishag, the girl from Shunem, to be my wife. He will do it if you ask him. ’"
    },
    {
      "verse": "18",
      "text": "Bathsheba said, ‘I will speak to the king on your behalf. ’"
    },
    {
      "verse": "19",
      "text": "So Bathsheba went to King Solomon, to speak on behalf of Adonijah. The king stood up to meet her. He bent his head down to respect her. Then he sat on his throne. He commanded his servants to bring another throne for his mother. So she sat down at his right side."
    },
    {
      "verse": "20",
      "text": "She said, ‘I have one small thing to ask you. Please do not refuse to do it for me. ’ The king said to her, ‘Ask me, mother! I will not refuse you! ’"
    },
    {
      "verse": "21",
      "text": "So she said, ‘Please let your brother Adonijah marry Abishag, the girl from Shunem. ’"
    },
    {
      "verse": "22",
      "text": "But King Solomon said to his mother, ‘You are asking me to give Abishag to Adonijah as his wife! You should also ask me to give my kingdom to him, my older brother! That would be the same thing. Then he would rule together with Abiathar the priest and Zeruiah's son Joab! ’"
    },
    {
      "verse": "23",
      "text": "Then King Solomon made this strong promise in the Lord's name. He said, ‘Because Adonijah has asked to have Abishag as his wife, I will certainly punish him with death. If I do not do that, I pray that God will punish me instead!"
    },
    {
      "verse": "24",
      "text": "As surely as the Lord lives, Adonijah must die today. The Lord has done everything that he promised to me. He has made me strong so that now I rule on the throne of my father David. And my descendants will continue to rule as kings after me. ’"
    },
    {
      "verse": "25",
      "text": "So King Solomon commanded Jehoiada's son Benaiah to kill Adonijah. So Adonijah died."
    },
    {
      "verse": "26",
      "text": "Then the king said to Abiathar the priest, ‘Go back to your fields in Anathoth. You also deserve to die. But I will not kill you now because you served my father David. You carried the Covenant Box of the Almighty Lord when David was king. Also, the trouble that happened to my father happened to you too. ’"
    },
    {
      "verse": "27",
      "text": "Solomon sent Abiathar away so that he was no longer a priest who served the Lord. That was the punishment that the Lord had said would happen to Eli's family. So what the Lord had promised at Shiloh now happened."
    },
    {
      "verse": "28",
      "text": "When Adonijah had tried to become king, Joab had joined with him. (But he had not joined with Absalom. ) Joab heard the news about what had happened to Adonijah and Abiathar. So he hurried to the Lord's holy tent. He took hold of the horns of the altar there. So Benaiah sent a message to tell the king what Joab had said."
    },
    {
      "verse": "29",
      "text": "King Solomon heard that Joab had gone to the altar in the Lord's holy tent. He commanded Jehoiada's son Benaiah, ‘Go there! Knock Joab down to kill him! ’"
    },
    {
      "verse": "30",
      "text": "So Benaiah went to the Lord's holy tent. When he arrived there, he said to Joab, ‘The king says, “Come out! ” ’ But Joab answered, ‘No! I will die here! ’So Benaiah sent a message to tell the king what Joab had said."
    },
    {
      "verse": "31",
      "text": "The king replied, ‘Do as Joab said. Kill him there and bury him. He has killed people who did not deserve to die. Punish Joab with death. Then I and my father's family will no longer be guilty for the cruel murders that he has done."
    },
    {
      "verse": "32",
      "text": "The Lord will now punish him because of the murders that he did. He used his sword to attack and kill two men, but he did not tell my father David about it. He murdered Ner's son Abner, the leader of Israel's army. He also murdered Jether's son Amasa, the leader of Judah's army. Both those men were better and more honest than Joab was."
    },
    {
      "verse": "33",
      "text": "Joab and his descendants will always receive the punishment for those murders. But the Lord will cause David's descendants, his family and his kingdom to enjoy peace always. ’"
    },
    {
      "verse": "34",
      "text": "So Jehoiada's son Benaiah went to the holy tent and he punished Joab with death. They buried Joab at his home in the wilderness."
    },
    {
      "verse": "35",
      "text": "Then the king chose Benaiah to be the leader of the army instead of Joab. The king also chose Zadok to be the priest instead of Abiathar."
    },
    {
      "verse": "36",
      "text": "Then the king told Shimei to come to him. He said to Shimei, ‘Build a house for yourself here in Jerusalem. Live in it all the time. Never leave to go anywhere else."
    },
    {
      "verse": "37",
      "text": "If you ever leave the city and you cross the Kidron stream, you will certainly die. That will be a death that you choose for yourself. ’"
    },
    {
      "verse": "38",
      "text": "Shimei said to the king, ‘My lord the king, your words are good. I will do as you have decided. ’So Shimei lived in Jerusalem for a long time."
    },
    {
      "verse": "39",
      "text": "But after three years, two of his slaves ran away. They went to Achish, who was the son of Maakah, the king of Gath. Someone told Shimei, ‘Your slaves are in Gath. ’"
    },
    {
      "verse": "40",
      "text": "So Shimei prepared his donkey and he left home. He went to Achish in Gath to look for his slaves. He found them and he brought them back from Gath."
    },
    {
      "verse": "41",
      "text": "Someone told Solomon that Shimei had travelled from Jerusalem to Gath and now he had returned."
    },
    {
      "verse": "42",
      "text": "So the king told Shimei to come to him. He said to Shimei, ‘You made a strong promise to me in the Lord's name. I am sure that you remember that! I warned you never to leave Jerusalem. I said that if you went anywhere else, you would certainly die. You said to me at that time, “I agree with what you have said. ”"
    },
    {
      "verse": "43",
      "text": "But you have not done what you promised to do in the Lord's name. You should have obeyed my command. ’"
    },
    {
      "verse": "44",
      "text": "The king also said to Shimei, ‘I know that you remember how you insulted my father David. Now the Lord will punish you because of the evil things that you did."
    },
    {
      "verse": "45",
      "text": "But the Lord will bless me, King Solomon. David's descendants will continue to serve the Lord as kings for ever. ’"
    },
    {
      "verse": "46",
      "text": "Then the king commanded Jehoiada's son Benaiah to punish Shimei with death. So Benaiah went and he killed Shimei. So Solomon now ruled the kingdom with complete authority."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "Solomon made an agreement with Pharaoh, who was the king of Egypt. Solomon married Pharaoh's daughter. He brought her to live in the City of David. She lived there until Solomon could finish building his own house, the Lord's temple, and the wall around Jerusalem."
    },
    {
      "verse": "2",
      "text": "Because there was not yet a temple where people could give honour to the Lord, they offered sacrifices at altars in other places."
    },
    {
      "verse": "3",
      "text": "Solomon loved the Lord and he obeyed the rules of his father David. But he offered sacrifices and he burned incense at altars in country places."
    },
    {
      "verse": "4",
      "text": "The king went to Gibeon to offer sacrifices there. That was the place where the most important altar was. Solomon offered burnt offerings a thousand times on the altar there."
    },
    {
      "verse": "5",
      "text": "One night in Gibeon, the Lord showed himself to Solomon in a dream. God said, ‘Ask me to give you whatever you want. ’"
    },
    {
      "verse": "6",
      "text": "Solomon answered, ‘You always showed your faithful love to your servant, my father David. He served you faithfully as a good, honest man. You have continued to show your faithful love to him even now. You have given him a son to rule as king on his throne."
    },
    {
      "verse": "7",
      "text": "Lord my God, I am only a young man. I have not learned how to rule well. But you have now made me become king, as my father David was king."
    },
    {
      "verse": "8",
      "text": "I am here as your servant to lead the people that you have chosen for yourself. It is a great nation and it has too many people to count."
    },
    {
      "verse": "9",
      "text": "So please give me a wise mind that understands things well. Then I will be able to rule your people properly. I will know the difference between right things and wrong things. I will only be able to rule this great nation of your people if you do that for me. ’"
    },
    {
      "verse": "10",
      "text": "The Lord God was pleased that Solomon had asked for this."
    },
    {
      "verse": "13",
      "text": "I will give you even more than this. I will make you rich and famous, even though you did not ask for that. As long as you live, there will be no other king who is greater than you."
    },
    {
      "verse": "14",
      "text": "And if you serve me faithfully, I will also give you a long life. But you must obey my rules and my commands, as your father David did. ’"
    },
    {
      "verse": "15",
      "text": "Then Solomon woke up. He realized that it was a dream. He returned to Jerusalem and he stood in front of the Lord's Covenant Box. He offered burnt offerings and peace offerings to God there. Then he gave a feast for all his officers."
    },
    {
      "verse": "16",
      "text": "Two women who were prostitutes came to meet with the king. They stood in front of him to tell him their problem."
    },
    {
      "verse": "17",
      "text": "One woman said, ‘My lord I live in the same house with this woman. I gave birth to a baby while she lived there with me."
    },
    {
      "verse": "18",
      "text": "Three days later, she also gave birth to a baby. We were alone in the house. Only the two of us were there, no one else."
    },
    {
      "verse": "19",
      "text": "But in the night, this woman lay on her son and he died."
    },
    {
      "verse": "20",
      "text": "So she got up during the night and she took my son from my side. I was still asleep. She put my son beside her. She put her dead son beside me."
    },
    {
      "verse": "21",
      "text": "When I got up in the morning to feed my son, I saw that he was dead! So I looked carefully at him in the morning light. Then I realized that he was not my son. He was not the son that I had given birth to! ’"
    },
    {
      "verse": "22",
      "text": "Then the other woman said, ‘No, that is not true! It is my son who is alive. Your son is dead! ’But the first woman answered, ‘No! The dead baby is your son. My son is alive! ’They continued to argue like that in front of the king. But the first woman answered, ‘No! The dead baby is your son. My son is alive! ’ They continued to argue like that in front of the king."
    },
    {
      "verse": "23",
      "text": "Then the king said, ‘One of you says, “My son is alive and your son is dead. ” But the other one says, “No! Your son is dead and my son is alive. ” ’"
    },
    {
      "verse": "24",
      "text": "So the king said, ‘Bring a sword to me! ’ So they brought a sword to the king."
    },
    {
      "verse": "25",
      "text": "Then the king commanded, ‘Cut the child who is alive into two pieces. Give one piece to one woman and the other piece to the other woman. ’"
    },
    {
      "verse": "26",
      "text": "Then the mother of the child who was alive spoke to the king. She loved her son very much. So she said to the king, ‘My lord, please do not kill the baby! Instead, give him to the other woman. ’But the other woman said, ‘Neither of us should have him. Cut him in two pieces! ’ But the other woman said, ‘Neither of us should have him. Cut him in two pieces! ’"
    },
    {
      "verse": "27",
      "text": "So King Solomon said, ‘Do not kill the child! Give him to the first woman. She is his mother. ’"
    },
    {
      "verse": "28",
      "text": "Everybody in Israel heard about what the king had decided. So they respected the king's authority. They realized that God had given him wisdom to judge fairly."
    },
    {
      "verse": "11",
      "text": "So God said to him, ‘You have not asked me to give you a long life, or to make you very rich. You have not asked me to punish your enemies with death. Instead you have asked for a wise mind so that you can rule well."
    },
    {
      "verse": "12",
      "text": "Because of that, I will give you what you have asked for. Yes, I now give to you a wise mind that understands things well. You will be wiser than anyone who has already lived and wiser than anyone who will live after you."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "King Solomon ruled over all Israel as king."
    },
    {
      "verse": "2",
      "text": "These were his important officers: Zadok's son Azariah was the priest."
    },
    {
      "verse": "3",
      "text": "Shisha's sons, Elihoreph and Ahijah, were secretaries. Ahilud's son Jehoshaphat recorded what happened."
    },
    {
      "verse": "4",
      "text": "Jehoiada's son Benaiah was the leader of the army. Zadok and Abiathar were priests."
    },
    {
      "verse": "5",
      "text": "Nathan's son Azariah had authority over the 12 officers for each region. Nathan's son Zabud was a priest who gave the king advice."
    },
    {
      "verse": "6",
      "text": "Ahishar had authority over work in the palace. Abda's son Adoniram had authority over the groups of workers."
    },
    {
      "verse": "7",
      "text": "officers with authority in the regions of Israel. They supplied food for the king and for the people who lived in his palace. Each officer had to supply food to the king for one month in each year."
    },
    {
      "verse": "8",
      "text": "These are their names: Ben-Hur had authority in Ephraim's hill country."
    },
    {
      "verse": "9",
      "text": "Ben-Deker had authority in Makaz, Shaalbim, Beth Shemesh and Elon Beth Hanan."
    },
    {
      "verse": "10",
      "text": "Ben-Hesed had authority in Arubboth. That included Sokoh and all the fields around Hepher."
    },
    {
      "verse": "11",
      "text": "Ben-Abinadab had authority in Naphath Dor. He had married Solomon's daughter, Taphath."
    },
    {
      "verse": "12",
      "text": "Ahilud's son Baana had authority in Taanach and Megiddo, as well as in all of Beth-Shan that is near Zarethan, below Jezreel. He had authority from Beth-Shan to Abel-Meholah and as far as Jokmeam."
    },
    {
      "verse": "13",
      "text": "Ben-Geber had authority in Ramoth Gilead. That included the villages of Manasseh's son Jair in Gilead. It also included the region of Argob in Bashan with 60 large cities which had strong walls gates with bronze bars."
    },
    {
      "verse": "14",
      "text": "Iddo's son had authority in Mahanaim."
    },
    {
      "verse": "15",
      "text": "Ahimaaz had authority in Naphtali. He had married Solomon's daughter, Basemath."
    },
    {
      "verse": "16",
      "text": "Hushai's son Baana had authority in Asher and Aloth."
    },
    {
      "verse": "17",
      "text": "Paruah's son Jehoshaphat had authority in Issachar."
    },
    {
      "verse": "18",
      "text": "Ela's son Shimei had authority in Benjamin."
    },
    {
      "verse": "19",
      "text": "Uri's son Geber had authority in Gilead. Gilead was the region where Sihon, king of the Amorites, and Og, king of Bashan, had ruled. There was also one officer who had authority over the whole land."
    },
    {
      "verse": "20",
      "text": "The people in Judah and Israel were too many to count. There were as many of them as the sand on the shore of the sea. They had enough to eat and to drink and they were happy."
    },
    {
      "verse": "21",
      "text": "Solomon ruled over all the nations from the Euphrates river to the land of the Philistines, as far as Egypt's border. The people of these kingdoms paid taxes to Solomon. They served him all the days of his life."
    },
    {
      "verse": "22",
      "text": "This is the food that Solomon and the people in his palace ate each day:5, 000 litres of flour. 10, 000 litres of grain."
    },
    {
      "verse": "23",
      "text": "fat calves that they fed with grain. 20 calves that ate grass in the fields. 100 sheep. Many kinds of deer and fat birds."
    },
    {
      "verse": "24",
      "text": "Solomon ruled all the kingdoms west of the Euphrates river, from Tiphsah as far as Gaza. There was peace in all these places."
    },
    {
      "verse": "25",
      "text": "While Solomon was alive, Judah and Israel were safe from their enemies. In the whole country, from Dan to Beersheba, every family had a place to live and they could grow food to eat."
    },
    {
      "verse": "26",
      "text": "Solomon had places to keep 4, 000 horses that pulled his chariots. He also had 12, 000 horses."
    },
    {
      "verse": "27",
      "text": "officers in each region supplied food for King Solomon and for everybody that ate in his palace. Each region supplied food for one month each year so that there was enough for everyone."
    },
    {
      "verse": "28",
      "text": "Each officer also supplied barley and straw for the king's horses. They took the right amount to the different places where the horses lived."
    },
    {
      "verse": "29",
      "text": "God gave Solomon wisdom so that he understood things well. He knew about everything, more things than there is sand on the shore of the sea!"
    },
    {
      "verse": "30",
      "text": "Solomon was wiser than all the wise men in the East and all the wise men in Egypt."
    },
    {
      "verse": "31",
      "text": "He was wiser than any other man. This includes Ethan the Ezrahite, as well as Heman, Calcol and Darda, the sons of Mahol. Solomon was famous in all the nations around Israel."
    },
    {
      "verse": "32",
      "text": "He wrote down 3, 000 proverbs and he wrote 1, 005 songs."
    },
    {
      "verse": "33",
      "text": "He could describe many plants. These included large trees like cedar trees that grow in Lebanon and small plants like hyssop that grows on walls. He also taught people about all kinds of animals, birds, insects and fish."
    },
    {
      "verse": "34",
      "text": "People came from all countries to listen to Solomon's wise teaching. Kings of all the nations in the world who heard about Solomon's wisdom sent people to learn from him."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Hiram was the king of Tyre. He heard that Solomon had become king of Israel after his father David. Hiram had always been a friend of King David, so he sent his men to say ‘hello’ to Solomon."
    },
    {
      "verse": "2",
      "text": "Solomon then sent this message to Hiram:"
    },
    {
      "verse": "3",
      "text": "‘You know that my father David could not build a temple for the Lord his God. This was because he had to fight battles against enemies that were all around Israel. He did that until the Lord helped him to win against all of them."
    },
    {
      "verse": "4",
      "text": "But now the Lord my God has made us safe from danger. No enemy tries to attack us on any of our borders."
    },
    {
      "verse": "5",
      "text": "So I have decided to build a temple to give honour to the Lord my God. The Lord said to my father David, “I will put your son on your throne to rule as king after you. He will build a temple for people to give honour to my name. ”"
    },
    {
      "verse": "6",
      "text": "So please tell your men to cut down cedar trees in Lebanon for me. We ourselves do not have people who know how to cut wood from trees as well as your men from Sidon. So our men will help your men with the work. And I will pay your workers whatever you decide is right. ’"
    },
    {
      "verse": "7",
      "text": "Hiram was very happy when he received Solomon's message. He said, ‘Praise the Lord today, because he gave David a wise son to rule over the great nation, Israel. ’"
    },
    {
      "verse": "8",
      "text": "Then Hiram sent this message to Solomon:‘I have received the message that you sent to me. I will give you the wood that you have asked for. I will send you cedar wood and pine wood, as much as you need."
    },
    {
      "verse": "9",
      "text": "My men will take the trees from the hills of Lebanon down to the sea. Then we will tie several trees together like a boat. We will take them on the sea to the place where you want them. There we will undo the ropes so that your men can carry the trees away. You will pay me with enough food to feed the people of my palace. ’"
    },
    {
      "verse": "10",
      "text": "So Hiram supplied Solomon with all the cedar trees and pine trees that Solomon asked for."
    },
    {
      "verse": "11",
      "text": "Then Solomon supplied Hiram with 2, 000 tons of wheat as food for the people in his palace. He also supplied 450, 000 litres of olive oil. Solomon sent this every year to Hiram."
    },
    {
      "verse": "12",
      "text": "The Lord gave wisdom to Solomon, as he had promised to do. King Hiram and King Solomon made an agreement that their nations would not fight against each other. So there was peace between them."
    },
    {
      "verse": "13",
      "text": "King Solomon commanded 30, 000 men from everywhere in Israel to do the work."
    },
    {
      "verse": "14",
      "text": "He sent them to Lebanon in groups of 10, 000 men each month. They worked in Lebanon for one month, then they lived at home for two months. Adoniram was the officer who had authority over them."
    },
    {
      "verse": "15",
      "text": "Solomon also had 80, 000 men to cut stones in the hills. He had 70, 000 men to carry the stones to Jerusalem."
    },
    {
      "verse": "16",
      "text": "He also had 3, 300 officers who told the workers what they should do."
    },
    {
      "verse": "17",
      "text": "The king commanded the workers to cut large pieces of stone from the rocks. They cut the best stones into the right shape to build the foundation of the temple."
    },
    {
      "verse": "18",
      "text": "Solomon's men and Hiram's men worked together with men from Gebal. They cut the stones and the wood and they prepared them to build the temple."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "Solomon began to build the Lord's temple 480 years after the Israelites had left Egypt. It was in the fourth year that he had ruled Israel as king. He started the work in the month called Ziv, the second month of the year."
    },
    {
      "verse": "2",
      "text": "metres long. It was 9 metres wide. It was 13. 5 metres high."
    },
    {
      "verse": "3",
      "text": "The temple had an entrance room in front of its big hall. The entrance room was as wide as the temple, 9 metres wide. It came 4. 5 metres out from the front of the temple itself."
    },
    {
      "verse": "4",
      "text": "Solomon made narrow windows near the tops of the temple walls."
    },
    {
      "verse": "5",
      "text": "Solomon built rooms around the outside of the temple walls. These rooms continued outside the big hall and the inside room. The side rooms were on three levels."
    },
    {
      "verse": "6",
      "text": "The lowest level of rooms was 2. 3 metres wide. The middle level was 2. 7 metres wide and the top level was 3. 2 metres wide. Each floor was built on wooden beams. The beams rested on stones in the temple walls, so that there were no holes that they cut into the walls."
    },
    {
      "verse": "7",
      "text": "When they built the temple, they used stones that were the right shape. Workers had already cut the stones at the place where they came from. There was no sound of hammers, axes or any iron tools at the place of the temple."
    },
    {
      "verse": "8",
      "text": "The door to the lowest level of rooms on the sides of the temple was on the south side of the temple. Stairs went up to the middle level and to the top level."
    },
    {
      "verse": "9",
      "text": "Solomon finished building the temple. He made the roof with wooden beams and with cedar boards."
    },
    {
      "verse": "10",
      "text": "He also built the rooms around the sides of the temple. Each room was 2. 3 metres high. Cedar beams fixed the rooms to the temple building."
    },
    {
      "verse": "11",
      "text": "Then the Lord gave this message to Solomon:"
    },
    {
      "verse": "12",
      "text": "‘I will make my home in this temple that you are building. I will do everything for you that I promised to your father David. But you must obey my laws, rules and commands."
    },
    {
      "verse": "13",
      "text": "Then I will live among my people, the Israelites. I will never leave them. ’"
    },
    {
      "verse": "14",
      "text": "So Solomon finished building the temple."
    },
    {
      "verse": "15",
      "text": "He used cedar boards to cover the walls on the inside of the temple. The boards went from the floor of the temple up to its ceiling. He covered the floor of the temple with wood from pine trees."
    },
    {
      "verse": "16",
      "text": "He built a wall across the inside of the temple to make a separate room. That wall was 9 metres from the back wall of the temple. The inside room was the Most Holy Place. The walls were covered with cedar boards from the floor to the ceiling."
    },
    {
      "verse": "17",
      "text": "metres long."
    },
    {
      "verse": "18",
      "text": "The inside of the temple was covered with boards made of cedar wood. The workers cut pictures of fruits and flowers on the wood. The cedar boards completely covered the stone walls, so you could not see any stone."
    },
    {
      "verse": "19",
      "text": "Solomon prepared the inside room to be the Most Holy Place where they would put the Lord's Covenant Box."
    },
    {
      "verse": "20",
      "text": "metres long, 9 metres wide and 9 metres high. Solomon used pure gold to cover the walls of this room. He also covered the cedar altar with gold."
    },
    {
      "verse": "21",
      "text": "Solomon covered all the walls inside the temple with gold. He also hung gold chains across the entrance to the Most Holy Place. He covered everything there with gold."
    },
    {
      "verse": "22",
      "text": "So he covered everything inside the whole temple with gold. That included the altar that was inside the Most Holy Place."
    },
    {
      "verse": "23",
      "text": "Solomon used olive wood to make models of two cherubs to stand in the Most Holy Place. Each cherub was 4. 4 metres tall."
    },
    {
      "verse": "24",
      "text": "The first cherub had two wings that were 2. 2 metres long each. So it was 4. 4 metres from the end of one wing to the end of the other wing."
    },
    {
      "verse": "25",
      "text": "The second cherub was also 4. 4 metres across its wings. The two cherubs were the same size and the same shape."
    },
    {
      "verse": "26",
      "text": "Each cherub was 4. 4 metres high."
    },
    {
      "verse": "27",
      "text": "Solomon put the cherubs in the inside room of the temple. Their wings went from one wall of the temple to the other wall. One cherub's wing touched one wall of the temple. One of the other cherub's wings touched the other wall. And their wings touched each other in the middle of the room."
    },
    {
      "verse": "28",
      "text": "Solomon covered the cherubs with gold."
    },
    {
      "verse": "29",
      "text": "Solomon's workers cut pictures in the wood on the walls of the big hall and the inside room. They were pictures of cherubs, palm trees and flowers."
    },
    {
      "verse": "30",
      "text": "They also covered the floors of both the rooms with gold."
    },
    {
      "verse": "31",
      "text": "They used olive wood to make doors for the entrance to the Most Holy Place. The doors were fixed to wooden pillars which had five sides."
    },
    {
      "verse": "32",
      "text": "The wooden doors had pictures of cherubs, palm trees and flowers. Solomon covered the pictures of the cherubs and the palm trees with very thin gold."
    },
    {
      "verse": "33",
      "text": "The doors to the big hall of the temple were fixed to pillars made of olive wood. Those pillars had four sides."
    },
    {
      "verse": "34",
      "text": "Solomon also made two doors from pine wood. Each door had two separate parts that could turn."
    },
    {
      "verse": "35",
      "text": "He cut pictures of cherubs, palm trees and flowers on those doors too. He covered them with gold in the same way."
    },
    {
      "verse": "36",
      "text": "Solomon also built a yard around the temple building. The wall around the yard had three rows of special stones, then a row of cedar beams, and so on."
    },
    {
      "verse": "37",
      "text": "They built the foundation of the Lord's temple in the fourth year that Solomon was king. It was in the month called Ziv."
    },
    {
      "verse": "38",
      "text": "They finished building the temple in the 11th year that Solomon was king. It was the eighth month, the month called Bul. So they built the temple in seven years, exactly as the plans showed that it should be."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "Solomon was also building a palace for himself. After 13 years, he finished it."
    },
    {
      "verse": "2",
      "text": "He built the Palace of the Forest of Lebanon. It was 46 metres long, 23 metres wide and 14 metres high. It had four rows of pillars. On top of them were beams. They used cedar wood to make the pillars and the beams."
    },
    {
      "verse": "3",
      "text": "They also used cedar wood to make the roof. They put the roof on top of the pillars and the beams. There were 45 beams, with 15 beams in each row."
    },
    {
      "verse": "4",
      "text": "There were three rows of windows on each side of the room. They were opposite each other, in groups of three windows."
    },
    {
      "verse": "5",
      "text": "All the doors had square corners and four sides. There were three doors in each group."
    },
    {
      "verse": "6",
      "text": "Solomon also built a Hall of Pillars. It was 23 metres long and 14 metres wide. There was an entrance room at the front of the hall. The entrance room also had pillars and a roof."
    },
    {
      "verse": "7",
      "text": "Solomon also built a Throne Room. He covered the walls with cedar boards, from the floor to the ceiling. He called it the Hall of Justice. He judged people's arguments in that room."
    },
    {
      "verse": "8",
      "text": "Solomon also built a house for himself to live in. It was in a yard behind the Hall of Justice. It was like the other buildings. He also built a house like it for his wife who was the king of Egypt's daughter."
    },
    {
      "verse": "9",
      "text": "Solomon's workers used valuable, large stones to make all the buildings, from the front to the great yard that was behind. They cut the stones to the right size and shape with special saws. They used these stones for the foundations and all the way up to the roof."
    },
    {
      "verse": "10",
      "text": "They made the foundations with very large, valuable stones. The stones were 3. 5 metres or 4. 5 metres long."
    },
    {
      "verse": "11",
      "text": "On top of the foundation they used the best stones that they cut to the right size. They also used beams of cedar wood."
    },
    {
      "verse": "12",
      "text": "There was a wall around the great yard. This had three rows of special stones, then a row of cedar beams, and so on. It was like the wall around the yard of the Lord's temple and the entrance room."
    },
    {
      "verse": "13",
      "text": "King Solomon sent men to Tyre to fetch a man called Hiram."
    },
    {
      "verse": "14",
      "text": "Hiram was the son of a widow from the tribe of Naphtali. His father was a worker who knew how to use bronze to make things. He lived in Tyre. Hiram also had special skills. He knew how to use bronze to make many kinds of things. So he came to work for King Solomon. He did all the work that Solomon asked him to do."
    },
    {
      "verse": "15",
      "text": "Hiram made two bronze pillars. Each pillar was 8. 2 metres high and 5. 5 metres around the outside. The metal itself was about 7 centimetres thick."
    },
    {
      "verse": "16",
      "text": "He also used bronze to make a top for each pillar. Each piece was 2. 3 metres high."
    },
    {
      "verse": "17",
      "text": "Each piece had pictures like rows of chains that joined together. There were seven pictures like this on the top of each pillar."
    },
    {
      "verse": "18",
      "text": "Hiram also made pictures of two rows of pomegranates around the chains. They covered the tops of the pillars."
    },
    {
      "verse": "19",
      "text": "The tops of the two pillars were in the shape of flowers called lilies. Each one was 1. 8 metres high."
    },
    {
      "verse": "20",
      "text": "pomegranates in two rows all around the top of each pillar. They were next to the chains above the round shape at the top of the pillar."
    },
    {
      "verse": "21",
      "text": "Hiram put these two pillars at the entrance room of the temple, in front of the big hall, the hall of pillars in the temple. He called the pillar on the south side ‘Jakin’. He called the pillar on the north side ‘Boaz’."
    },
    {
      "verse": "22",
      "text": "The tops of the pillars were in the shape of flowers called lilies. Hiram finished the work on the two bronze pillars."
    },
    {
      "verse": "23",
      "text": "Hiram also used bronze to make a big bath which they called ‘the Sea’. It was in the shape of a circle 4. 5 metres across. It was 2. 3 metres deep. It was 14 metres around the outside."
    },
    {
      "verse": "24",
      "text": "All around its edge, below the top, there were two rows of round shapes. They were pictures of fruits called gourds. They were all part of the same piece of bronze as ‘the Sea’. There were 20 gourds for every metre around the edge."
    },
    {
      "verse": "25",
      "text": "Hiram fixed ‘the Sea’ on top of 12 bronze bulls. Three pointed north, three pointed west, three pointed south and three pointed east. Their backs were towards the middle of ‘the Sea’."
    },
    {
      "verse": "26",
      "text": "The walls of ‘the Sea’ were 7½ centimetres thick. Its top edge was like a cup in the shape of a lily flower. ‘The Sea’ contained about 40, 000 litres of water."
    },
    {
      "verse": "27",
      "text": "Hiram also made ten bronze carts to carry water. Each one was 1. 8 metres long, 1. 8 metres wide and 1. 3 metres deep."
    },
    {
      "verse": "28",
      "text": "This is how he made the water carts: He made them with bronze sides, which he fixed to bronze bars at the edges."
    },
    {
      "verse": "29",
      "text": "There were pictures of lions, bulls and cherubs on the bars and on the edges. There were shapes like leaves above and below the lions and the bulls."
    },
    {
      "verse": "30",
      "text": "Each cart had four bronze wheels fixed to bronze axles. The axles were fixed under each cart at four places. These places had shapes like leaves on each side."
    },
    {
      "verse": "31",
      "text": "On the top of the cart there was a round piece which held a bowl. This piece was 50 centimetres deep and 75 centimetres across. Hiram cut pictures into the metal all around it. The bronze sides of the carts were square. They were not round."
    },
    {
      "verse": "32",
      "text": "There were four wheels under each cart. They were fixed to axles. The axles and the cart joined together in one piece. Each wheel was 70 centimetres high."
    },
    {
      "verse": "33",
      "text": "The wheels were like the wheels of a chariot. Hiram used bronze to make the axles and all the parts of the wheels."
    },
    {
      "verse": "34",
      "text": "Each cart had four handles. There was one handle on each side, joined to the cart as one piece."
    },
    {
      "verse": "35",
      "text": "There was a piece of metal round the top of each cart. It was 23 centimetres deep. It was fixed at each corner of the cart with pieces of bronze. These pieces and the sides of each cart were all joined together."
    },
    {
      "verse": "36",
      "text": "Hiram cut pictures of cherubs, lions and palm trees on the sides of each cart and on the handles. He cut pictures where there was a space for them. There were also shapes of leaves all around."
    },
    {
      "verse": "37",
      "text": "Hiram used bronze to make the ten carts so that they all had the same size and shape."
    },
    {
      "verse": "38",
      "text": "And Hiram also made ten bronze buckets. Each bucket contained about 800 litres. Each bucket was 1. 8 metres across. There was one bucket for each of the ten carts."
    },
    {
      "verse": "39",
      "text": "Hiram put five of the carts on the south side of the temple. He put the other five carts on the north side of the temple. He put ‘the Sea’ on the south side of the temple, at the south-east corner."
    },
    {
      "verse": "40",
      "text": "Hiram also made dishes to carry ashes, small tools and bowls. So Hiram finished all the work in the Lord's temple that King Solomon had asked him to do. He made these things: So Hiram finished all the work in the Lord's temple that King Solomon had asked him to do. He made these things:"
    },
    {
      "verse": "41",
      "text": "Two pillars. Two pieces for the top of each pillar, with the shape of big bowls. Rows of chains on the tops of the pillars."
    },
    {
      "verse": "42",
      "text": "images of pomegranates for the two groups of chains. (There were two rows of these images around the piece at the top of each pillar, which had the shape of a bowl. )"
    },
    {
      "verse": "43",
      "text": "Ten carts with the ten buckets that were on them."
    },
    {
      "verse": "44",
      "text": "The big bath called ‘the Sea’ and the 12 bulls under it."
    },
    {
      "verse": "45",
      "text": "The dishes, small tools and bowls. King Solomon asked Hiram to make all these things for the Lord's temple. Hiram used bright bronze to make all these things."
    },
    {
      "verse": "46",
      "text": "The king told his workers to pour the hot bronze into shapes in the ground. They did that at a special place in the region of the Jordan Valley, between Succoth and Zarethan."
    },
    {
      "verse": "47",
      "text": "Solomon did not weigh any of these things, because there were so many of them. No one ever knew the weight of the bronze."
    },
    {
      "verse": "48",
      "text": "Solomon also made all these things for the Lord's temple: The gold altar. The gold table which had the special bread on it."
    },
    {
      "verse": "49",
      "text": "The pure gold lampstands. There were five lampstands on one side of the door to the Most Holy Place and five on the other side. The gold images of flowers. The lamps. The small tools that held things for the altar."
    },
    {
      "verse": "50",
      "text": "The pure gold bowls. The small tools that they used for the lamps. The bowls for water. The dishes for ashes. The baskets that carried hot coals. The gold pieces that held the doors of the Most Holy Place. The gold pieces that held the doors of the temple's big hall."
    },
    {
      "verse": "51",
      "text": "King Solomon finished all the work for the Lord's temple. Then he brought into it all the holy things that belonged to his father, David. He stored all the valuable things in a safe place in the Lord's temple. They included silver things and gold things."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Then Solomon told all the leaders of Israel to come to him in Jerusalem. They were all the leaders of the Israelite tribes and families. He wanted them to bring the Lord's Covenant Box from Mount Zion, the City of David, to put it in the temple."
    },
    {
      "verse": "2",
      "text": "So all the Israelite leaders came together to meet with King Solomon. This happened during the Festival of Huts in the seventh month of the year, called Ethanim."
    },
    {
      "verse": "3",
      "text": "When all Israel's leaders had arrived, the priests lifted up the Covenant Box."
    },
    {
      "verse": "4",
      "text": "The priests and the Levites carried the Lord's Covenant Box, the Tent of Meeting and all the holy things that were in the tent."
    },
    {
      "verse": "5",
      "text": "King Solomon and all the Israelites who were with him walked in front of the Covenant Box. They offered many sheep and bulls as sacrifices. There were more animals than anyone could count."
    },
    {
      "verse": "6",
      "text": "Then the priests brought the Lord's Covenant Box to its proper place in the inside room of the temple. That was the Most Holy Place. They put it under the wings of the cherubs."
    },
    {
      "verse": "7",
      "text": "The wings of the cherubs touched each other above the place where the Covenant Box was. The cherubs covered the Covenant Box and the poles that the Levites used to carry it."
    },
    {
      "verse": "8",
      "text": "The poles were very long. The priests could see their ends from the Holy Place, if they stood in front of the Most Holy Place. But nobody could see the poles from outside the temple. And they are still there today."
    },
    {
      "verse": "9",
      "text": "There was nothing in the Covenant Box, except the two flat stones that Moses had put there at Sinai. That was where the Lord made a covenant with the Israelites after they came out from Egypt."
    },
    {
      "verse": "10",
      "text": "When the priests came out from the Holy Place, a cloud filled the Lord's temple."
    },
    {
      "verse": "11",
      "text": "The priests could not do their work to serve the Lord, because of the cloud. The Lord's bright glory filled his temple."
    },
    {
      "verse": "12",
      "text": "Then Solomon prayed, ‘Lord, you have said that you live in a dark cloud."
    },
    {
      "verse": "13",
      "text": "Now I have built a great temple for you. It is a place where you can live for ever. ’"
    },
    {
      "verse": "14",
      "text": "While all the Israelite people stood there, the king turned round towards them. He prayed that God would bless them."
    },
    {
      "verse": "15",
      "text": "He said, ‘Praise the Lord, Israel's God, as he deserves. He has used his power to do what he promised to do for my father David."
    },
    {
      "verse": "16",
      "text": "He told David, “I brought my people, the Israelites, out from Egypt. From that time, I have not chosen a city in any of Israel's tribes to build a temple where my people would worship me. Now I have chosen David to rule Israel, my people, as king. ”"
    },
    {
      "verse": "17",
      "text": "My father David wanted very much to build a temple to give honour to the Lord, Israel's God."
    },
    {
      "verse": "18",
      "text": "But the Lord said to my father David, “It was good that you wanted to build a temple to give me honour."
    },
    {
      "verse": "19",
      "text": "But you will not build the temple. Instead, one of your own sons will build it to give honour to me. ”"
    },
    {
      "verse": "20",
      "text": "Now the Lord has done what he promised to do. I now rule Israel as king on the throne of my father David, as the Lord promised. I have built this temple to give honour to the Lord, Israel's God."
    },
    {
      "verse": "21",
      "text": "I have made a place there for the Covenant Box. It contains the covenant that the Lord made with our ancestors when he brought them out of Egypt. ’"
    },
    {
      "verse": "22",
      "text": "Then Solomon stood in front of the Lord's altar. All the Israelite people who had come together there could see him. He lifted up his hands towards the sky."
    },
    {
      "verse": "23",
      "text": "He prayed, ‘Lord, Israel's God, there is no God like you, either in heaven above or down here on the earth. You continue to do what you have promised to do for your people. You faithfully love those who want to serve you."
    },
    {
      "verse": "24",
      "text": "You have done what you promised to do for your servant, my father David. You have used your power to finish today everything that you said you would do."
    },
    {
      "verse": "25",
      "text": "Now Lord, Israel's God, there is another promise that you spoke to my father David. I pray that you will do that too. You said to David, “There will always be one of your descendants to rule Israel as my chosen king. But for this to happen, your sons must be careful to serve me well, as you have done. ”"
    },
    {
      "verse": "26",
      "text": "So now, God of Israel, please cause what you promised to my father, your servant David, to happen."
    },
    {
      "verse": "27",
      "text": "But surely God, you do not live on the earth! The whole sky, or even heaven itself, is too small to contain you! So how can you live in this temple that I have built?"
    },
    {
      "verse": "28",
      "text": "But Lord, my God, please listen to my prayer, as I ask you for help. Please answer me, your servant, because I need your help today."
    },
    {
      "verse": "29",
      "text": "Watch over this temple and take care of it day and night. This is the place about which you said, “People will give honour to my name there. ” Please answer my prayers when I turn towards this place to pray to you."
    },
    {
      "verse": "30",
      "text": "Hear the prayers of me, your servant, and the prayers of your people, the Israelites. Please answer us when we turn towards this place and we pray to you. Hear us from heaven, the place where you live. And when we pray, forgive us for our sins."
    },
    {
      "verse": "31",
      "text": "Somebody may do a bad thing against another person. Then he may come to this temple and stand in front of your altar. He may say to you that he is not guilty of any wrong thing."
    },
    {
      "verse": "32",
      "text": "Then listen from heaven to what these people are saying. Decide who is right. Punish the guilty person as he deserves. Show clearly that the other person is right, because he has not done any wrong thing."
    },
    {
      "verse": "33",
      "text": "Perhaps an enemy will win against your people, the Israelites, because we have not obeyed you. But then your people may turn back to you and worship you. They may come into this temple and pray that you will help them."
    },
    {
      "verse": "34",
      "text": "If they do that, please hear them from heaven! Please forgive the sins of your people, the Israelites. Please bring them back to the land that you gave to their ancestors."
    },
    {
      "verse": "35",
      "text": "Sometimes, there may be no rain from the sky because your people have not obeyed you. Then they may turn towards this place and pray to you. They may give honour to your name and turn away from their sins, because you have punished them."
    },
    {
      "verse": "36",
      "text": "If they do that, please hear them from heaven! Please forgive the sins of your servants, your people, the Israelites. Teach them to live in the right way. And please send rain onto this land that you gave to your people to belong to them for ever."
    },
    {
      "verse": "37",
      "text": "Sometimes, there may be other troubles in our land. There may be a famine or a bad disease. Our crops may not grow and our animals may be ill. Locusts may destroy our crops. An enemy may attack some cities in our land. Or there may be other kinds of disease or trouble."
    },
    {
      "verse": "38",
      "text": "Then, some of your people may pray to you and ask you for help. If someone is sad and upset, he may turn towards this temple and lift up his hands in prayer."
    },
    {
      "verse": "39",
      "text": "If someone does that, please hear him from your home in heaven. Please forgive the sins of your people and help them. Only you know what people are thinking. So please give to each person as they deserve."
    },
    {
      "verse": "40",
      "text": "Then your people will respect and obey you as they live in this land that you gave to our ancestors."
    },
    {
      "verse": "41",
      "text": "Foreigners, who do not belong to your people, the Israelites, will hear how great you are. Then they will come here from other countries far away."
    },
    {
      "verse": "42",
      "text": "They will hear about you and your power to do great things. Then they will turn towards this temple and pray to you."
    },
    {
      "verse": "43",
      "text": "When that happens, please hear them from your home in heaven. Please answer all the prayers of these foreign people. Then people from all the nations in the world will realize how great you are. They also will respect you and obey you, as your own people do. They will understand that this temple that I have built belongs to you."
    },
    {
      "verse": "44",
      "text": "Sometimes, your people will go to fight against their enemies at the place where you have sent them. Then they may turn towards this city and pray to the Lord. This is the city that you have chosen for me to build the temple to give you honour."
    },
    {
      "verse": "45",
      "text": "When they pray to you, please hear them from your home in heaven. Do what is right to help them win against their enemies."
    },
    {
      "verse": "46",
      "text": "There is nobody who never does a wrong thing. So when your people do not obey you, you will be angry with them. You will put them under the power of their enemies. Those enemies will take them as prisoners to their own country. Perhaps it will be a country that is far away. Perhaps it will be near."
    },
    {
      "verse": "47",
      "text": "Then your people may think about the bad things that they have done. While they are prisoners in their enemy's country, they may be sorry about their sins. They may pray to you and ask you to forgive them. They may say, “We have turned away from God and we have done wicked things. ”"
    },
    {
      "verse": "48",
      "text": "In the country where they are prisoners, they may turn back to you and worship you truly. They may turn towards this land that you gave to their ancestors. They may pray to you as they look towards this city that you have chosen. They may look towards the temple that I have built to give you honour."
    },
    {
      "verse": "49",
      "text": "If they do that, please hear them from your home in heaven. Please answer their prayers and do what is right to help them."
    },
    {
      "verse": "50",
      "text": "Please forgive your people for all the sins that they have done against you. Please cause their enemies to be kind to them."
    },
    {
      "verse": "51",
      "text": "Remember that they are your special people who belong to you. You brought them out of Egypt where they were like prisoners in a very hot oven."
    },
    {
      "verse": "52",
      "text": "I pray that you will carefully watch over me, your servant. Please answer my prayers and the prayers of your people, the Israelites. Whenever we pray to you, please listen to us."
    },
    {
      "verse": "53",
      "text": "From all the nations of the world you chose Israel to belong to you as your special people. Almighty Lord, this is what you promised to your servant Moses when you brought our ancestors out of Egypt. ’"
    },
    {
      "verse": "54",
      "text": "So Solomon finished all his prayers and everything that he wanted to ask the Lord for. He had been down on his knees with his hands lifted up towards the sky in front of the Lord's altar. Now he stood up."
    },
    {
      "verse": "55",
      "text": "When he stood up, he asked God to bless all the people in Israel. He said with a loud voice,"
    },
    {
      "verse": "56",
      "text": "‘Praise the Lord as he deserves! He has given his people, the Israelites, a safe place to live, as he has promised to do. Every great promise that the Lord gave to his servant Moses has now happened!"
    },
    {
      "verse": "57",
      "text": "I pray that the Lord our God will be with us, as he was with our ancestors. I pray that he will never leave us or turn away from us."
    },
    {
      "verse": "58",
      "text": "I pray that the Lord will cause us to respect his authority. Then we will do what he wants us to do. We will obey all his commands, rules and laws that he gave to our ancestors."
    },
    {
      "verse": "59",
      "text": "I pray that the Lord our God will continue to remember these words that I have prayed. May he keep them in his thoughts. I pray that he will do what is right to help me and his people, the Israelites. May he give us the help that we need each day."
    },
    {
      "verse": "60",
      "text": "Then all the nations of the earth will understand that the Lord is the only true God. There is no other God."
    },
    {
      "verse": "61",
      "text": "I pray that you will continue to serve the Lord our God faithfully. You must continue to obey his rules and his commands, as you do now. ’"
    },
    {
      "verse": "62",
      "text": "Then the king and all the Israelite people who were with him offered sacrifices to the Lord."
    },
    {
      "verse": "63",
      "text": "These are the friendship offerings that Solomon offered to the Lord:22, 000 cows. 120, 000 sheep and goats. In this way, King Solomon and all the Israelite people offered the temple as a gift to the Lord. In this way, King Solomon and all the Israelite people offered the temple as a gift to the Lord."
    },
    {
      "verse": "64",
      "text": "On the same day, the king gave to the Lord the yard that was in front of the temple. King Solomon offered burnt offerings and grain offerings to the Lord. He also offered the fat from the friendship offerings. The bronze altar in front of the temple was too small to contain all these offerings. So Solomon made these sacrifices in the middle of the yard instead."
    },
    {
      "verse": "65",
      "text": "At that time, Solomon and the big crowd of Israelites who were with him had a festival for seven days. They gave honour to the Lord our God. There were people from everywhere in Israel, from Hamath in the north to the Stream of Egypt in the south."
    },
    {
      "verse": "66",
      "text": "The day after the festival, Solomon sent the people away to their homes. They thanked God for the king and were very happy. They were full of joy because the Lord had done many good things for his servant David and for his people, the Israelites."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "Solomon had finished building the Lord's temple and the king's palace. He had built everything that he had wanted to build. ‘I have heard your prayer and how you have asked me to help you. I have made this temple that you have built a special place for me. People will worship me there for ever. I will always be there to watch over it."
    },
    {
      "verse": "2",
      "text": "Then the Lord appeared to Solomon a second time, as he had appeared to him at Gibeon."
    },
    {
      "verse": "3",
      "text": "The Lord said to Solomon, ‘I have heard your prayer and how you have asked me to help you. I have made this temple that you have built a special place for me. People will worship me there for ever. I will always be there to watch over it."
    },
    {
      "verse": "4",
      "text": "You must continue to serve me honestly and obey me, as your father David did. Do everything that I have commanded you to do. Obey my rules and my laws."
    },
    {
      "verse": "5",
      "text": "If you serve me truly, I will cause one of your descendants to rule over Israel as king for all time. That is what I promised to your father David when I said, “There will always be someone from your family to rule Israel as king. ”"
    },
    {
      "verse": "6",
      "text": "But if you or your descendants turn away from me, I will punish your people. I will do that if you do not obey the laws and rules that I have given to you. I will do it if you choose to serve and to worship other gods."
    },
    {
      "verse": "7",
      "text": "Then I will remove the Israelite people from the land that I have given to them. I will turn away from this temple that I have made a special place for people to worship me. People from all the other nations will insult the Israelites and they will laugh at them."
    },
    {
      "verse": "8",
      "text": "This temple will became a heap of stones. Everyone who sees it will be very surprised. They will laugh about it! They will ask, “Why has the Lord destroyed this land and this temple? ”"
    },
    {
      "verse": "9",
      "text": "People will answer, “He has done it because they have turned away from the Lord their God. He brought their ancestors out of Egypt. But they have chosen to worship other gods and to serve them. That is why the Lord has caused this trouble to happen to them. ” ’"
    },
    {
      "verse": "10",
      "text": "Solomon was building the Lord's temple and the king's palace for 20 years."
    },
    {
      "verse": "11",
      "text": "After this, he gave 20 towns in Galilee to Hiram, the king of Tyre. Solomon did this because Hiram had given him all that he needed for the work. Hiram had given him cedar wood, pine wood and gold."
    },
    {
      "verse": "12",
      "text": "So Hiram left Tyre and he went to Galilee, to see the towns that Solomon had given to him. But Hiram was not happy with them."
    },
    {
      "verse": "13",
      "text": "He said to Solomon, ‘My friend, you have given me some useless towns! ’ Hiram called that region ‘Kabul Land’. It still has that name today."
    },
    {
      "verse": "14",
      "text": "Hiram had sent to King Solomon about 4, 000 kilograms of gold."
    },
    {
      "verse": "15",
      "text": "Solomon made people work on the buildings for him. This is how he used them to build the Lord's temple, the king's palace, the Millo and the wall around Jerusalem. They also did work on the towns called Hazor, Megiddo and Gezer."
    },
    {
      "verse": "16",
      "text": "Pharaoh, the king of Egypt, had attacked Gezer and he had taken it. He had destroyed it with fire. He killed the Canaanites who lived there. Then he gave it as a gift to his daughter, when she married Solomon."
    },
    {
      "verse": "17",
      "text": "So Solomon built Gezer again. He also built Lower Beth-Horon,"
    },
    {
      "verse": "18",
      "text": "Baalath and Tadmor, which were towns in the wilderness of Judah."
    },
    {
      "verse": "19",
      "text": "Solomon also made strong the cities where he stored things and the cities where he kept his chariots and horses. He built everything that he wanted to build in Jerusalem, in Lebanon and everywhere in his kingdom."
    },
    {
      "verse": "20",
      "text": "Solomon only made people who were not Israelites do the hard work for him. They were Canaanite people who still lived in the land after the Israelites took it for themselves. They were Amorites, Hittites, Perizzites, Hivites and Jebusites."
    },
    {
      "verse": "21",
      "text": "The Israelites had not been able to remove all of these people, so their descendants remained in the land. So Solomon made them do hard work as his slaves. They are still slaves of the Israelites today."
    },
    {
      "verse": "22",
      "text": "But Solomon did not make any of the Israelites do the hard work. Instead, they served him as his soldiers, government officers and army officers. Some of the soldiers drove chariots and some were leaders of the chariot drivers."
    },
    {
      "verse": "23",
      "text": "There were also officers who had authority over the slaves who did the work. There were 550 officers who led the work."
    },
    {
      "verse": "24",
      "text": "Solomon had built a palace for his wife, Pharaoh's daughter. When the palace was ready, she came up from the City of David. After that, Solomon built the Millo."
    },
    {
      "verse": "25",
      "text": "Three times every year Solomon offered burnt offerings and friendship offerings as sacrifices to the Lord. He did this on the altar that he had built for the Lord. With these offerings, he also burned incense to worship the Lord. So the temple became the place to worship the Lord."
    },
    {
      "verse": "26",
      "text": "King Solomon also built ships at Ezion-Geber. This place is near Elath in Edom, on the shore of the Red Sea."
    },
    {
      "verse": "27",
      "text": "Hiram had sailors who knew how to sail ships on the sea. He sent some of these men to work with Solomon's sailors."
    },
    {
      "verse": "28",
      "text": "tons of gold. They gave it to King Solomon."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "The Queen of Sheba heard news that Solomon was a great king who served the Lord. So she came to ask Solomon some difficult questions to see how wise he was."
    },
    {
      "verse": "2",
      "text": "She arrived at Jerusalem with a big group of servants. She had many camels that carried spices. They also carried a lot of gold and valuable jewels. When she came to Solomon, she talked to him about everything that was in her mind."
    },
    {
      "verse": "3",
      "text": "Solomon answered all her questions. There was nothing that was too difficult for the king to explain to her."
    },
    {
      "verse": "4",
      "text": "The Queen of Sheba saw that Solomon was very wise. She saw the palace that he had built."
    },
    {
      "verse": "5",
      "text": "She saw all the food that he ate in his palace. She saw all his servants and officers and their beautiful clothes. She saw the servants who prepared his food and wine. She saw the burnt offerings that he offered in the Lord's temple. All these things caused her to hold her breath in surprise."
    },
    {
      "verse": "6",
      "text": "She said to the king, ‘In my own country I heard news about your wisdom and about all the things that you had done. Everything that I heard was true!"
    },
    {
      "verse": "7",
      "text": "But I did not believe those things until I came here. Now I have seen everything with my own eyes, and it is true! Really, they told me less than half of what was true! You are even wiser and richer than the report that people told me."
    },
    {
      "verse": "8",
      "text": "God has blessed your people and your officers! They are always with you, and they can listen to your wise words."
    },
    {
      "verse": "9",
      "text": "So we praise the Lord your God! He is happy with you and he has chosen you to rule Israel. The Lord's love for Israel will continue for ever. So he has made you king to rule in a fair and honest way. ’"
    },
    {
      "verse": "10",
      "text": "The Queen of Sheba gave to King Solomon more than 4, 000 kilograms of gold, a lot of spices and many valuable jewels. Nobody has ever brought such a big number of spices as she gave to the king."
    },
    {
      "verse": "11",
      "text": "Hiram's ships had brought gold from Ophir. They also brought from there large loads of good wood, and valuable jewels."
    },
    {
      "verse": "12",
      "text": "The king used the wood to make steps for the Lord's temple and for the king's palace. He also used it to make harps and lyres for the musicians. Nobody has ever seen such valuable wood, even until today."
    },
    {
      "verse": "13",
      "text": "So King Solomon gave the Queen of Sheba all the gifts that he chose for her. He gave her everything that she wanted. Then she left Solomon and she returned to her own country with her servants."
    },
    {
      "verse": "14",
      "text": "tons of gold each year."
    },
    {
      "verse": "15",
      "text": "He also received money from traders, from the kings of Arabia and from the rulers of each region in Israel."
    },
    {
      "verse": "16",
      "text": "King Solomon's workers used gold to make 200 large shields. They hit the gold with hammers to make it flat. They used about four kilograms of gold to cover each shield."
    },
    {
      "verse": "17",
      "text": "small shields in the same way. They used about 2 kilograms of gold to cover each shield. He put these shields in the Palace of the Forest of Lebanon."
    },
    {
      "verse": "18",
      "text": "The king used ivory to make a large throne. He covered it with gold."
    },
    {
      "verse": "19",
      "text": "There were six steps up to the throne. The back of the throne was a round shape at the top. On both sides of the seat there were places for the king to put his arms. An image of a lion stood on each side of the throne."
    },
    {
      "verse": "20",
      "text": "more images of lions on the six steps. There was one lion at each end of every step. There was no throne like it in any other kingdom."
    },
    {
      "verse": "21",
      "text": "They used gold to make all King Solomon's cups that he drank from. In the Palace of the Forest of Lebanon, all the dishes and other things were made with gold. They used pure gold. They did not make anything with silver. In Solomon's time, people did not think that silver was very valuable."
    },
    {
      "verse": "22",
      "text": "The king had many large ships that could sail across the seas. They sailed with King Hiram's ships. Every three years they returned to Solomon with their loads. They brought to him gold, silver and ivory. They also brought apes and monkeys."
    },
    {
      "verse": "23",
      "text": "King Solomon was richer and wiser than any other king in the world."
    },
    {
      "verse": "24",
      "text": "People from every nation in the world wanted to talk to Solomon. They wanted to listen to the wisdom that God had given to him."
    },
    {
      "verse": "25",
      "text": "Every year, people who came to visit Solomon brought him gifts. They brought things that were made from silver and gold, as well as clothes, weapons, spices, horses and mules."
    },
    {
      "verse": "26",
      "text": "Solomon brought together many chariots and horses for his soldiers to ride. He had 1, 400 chariots and 12, 000 horses. He kept some of them in Jerusalem where he lived as king. He put the others in cities that he had chosen for this."
    },
    {
      "verse": "27",
      "text": "While Solomon ruled as king, there was as much silver in Jerusalem as stones! There was as much wood from cedar trees as there were fig trees that grew in the low hills in the west."
    },
    {
      "verse": "28",
      "text": "Solomon brought his horses from Egypt and from Kue. He sent traders to Kue to buy them for him."
    },
    {
      "verse": "29",
      "text": "pieces of silver. Each horse cost 150 pieces of silver. They also sold chariots and horses to all the kings of the Hittites and to the kings of Syria."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "Solomon loved Pharaoh's daughter and many other foreign women. Those women were Moabites, Ammonites, Edomites, Sidonians and Hittites."
    },
    {
      "verse": "2",
      "text": "The Lord had warned the Israelites about these nations. He said, ‘You must not marry people from these nations. If you do, they will cause you to worship their own gods. ’ But Solomon did love these foreign women and he married them."
    },
    {
      "verse": "3",
      "text": "royal wives. He also had 300 slave wives. His wives caused him to turn away from the Lord."
    },
    {
      "verse": "4",
      "text": "When Solomon became old, his wives caused him to serve other gods. Solomon no longer completely loved the Lord his God as his father David had done."
    },
    {
      "verse": "5",
      "text": "Solomon worshipped Ashtoreth, the female god of the Sidonian people. He also worshipped Molech, the wicked god of the Ammonite people."
    },
    {
      "verse": "6",
      "text": "As a result, Solomon did things that the Lord said were evil. He did not serve the Lord faithfully as his father David had done."
    },
    {
      "verse": "7",
      "text": "On a hill east of Jerusalem Solomon built a place to worship false gods. He worshipped Chemosh, the wicked god of the Moabite people, and Molech, the wicked god of the Ammonite people."
    },
    {
      "verse": "8",
      "text": "Solomon also built places where his foreign wives could worship their gods. They burned incense and they offered sacrifices to their own gods in these places."
    },
    {
      "verse": "9",
      "text": "So the Lord became angry with Solomon. Solomon had turned away from the Lord, Israel's God, who had appeared to Solomon twice."
    },
    {
      "verse": "10",
      "text": "He had warned Solomon that he must not serve other gods. But Solomon did not obey the Lord's command."
    },
    {
      "verse": "11",
      "text": "So the Lord said to Solomon, ‘I see the things that you have chosen to do. You have not obeyed my covenant and the laws that I commanded you to obey. So I will take the kingdom away from you. One of your servants will rule the kingdom instead of you."
    },
    {
      "verse": "12",
      "text": "But I will not do this while you are alive, because your father David was faithful to me. Instead, I will take the kingdom away from your son."
    },
    {
      "verse": "13",
      "text": "But I will not take away the whole kingdom from him. I will leave one tribe for him to rule as king. I will do this because King David served me faithfully, and because I have chosen Jerusalem as my special city. ’"
    },
    {
      "verse": "14",
      "text": "The Lord brought an enemy to attack Solomon. He was Hadad who came from Edom. Hadad belonged to the king of Edom's family."
    },
    {
      "verse": "15",
      "text": "When David was king, he had fought against Edom's people. Joab, the leader of David's army, had gone to Edom to bury the dead Israelite soldiers. At that time, Joab killed all the men in Edom."
    },
    {
      "verse": "16",
      "text": "Joab and Israel's army stayed in Edom for six months. During that time, they killed all the men in Edom."
    },
    {
      "verse": "17",
      "text": "Hadad was a small boy at that time. He escaped from Edom with some of his father's officers. They went towards Egypt."
    },
    {
      "verse": "18",
      "text": "They went from Midian as far as Paran. They took some men from Paran and they all went to Egypt. They went to Pharaoh, the king of Egypt. Pharaoh gave Hadad a house to live in and food to eat. He also gave Hadad some land."
    },
    {
      "verse": "19",
      "text": "Pharaoh was very pleased with Hadad, so he gave Hadad a wife. She was the sister of his own wife, Queen Tahpenes."
    },
    {
      "verse": "20",
      "text": "Tahpenes's sister gave birth to Hadad's son, called Genubath. Queen Tahpenes took care of Genubath in the king's palace. Genubath lived there with Pharaoh's own children."
    },
    {
      "verse": "21",
      "text": "While Hadad was living in Egypt, he heard the news that King David had died. Joab, the leader of David's army, was also dead by this time. So Hadad said to Pharaoh, ‘Please let me return to my own country. ’"
    },
    {
      "verse": "22",
      "text": "Pharaoh asked him, ‘Why do you want to return to your own country? Is there anything that you do not have here? ’ Hadad replied, ‘There is nothing wrong, but please let me go. ’"
    },
    {
      "verse": "23",
      "text": "God also brought another enemy to attack Solomon. He was Eliada's son Rezon. He had run away from his master, Hadadezer, the king of Zobah."
    },
    {
      "verse": "24",
      "text": "After David had destroyed Hadadezer's army, Rezon became the leader of a group of bad men. Rezon went to Damascus with his men, and Rezon became ruler of the city."
    },
    {
      "verse": "25",
      "text": "Rezon was Israel's enemy all the time that Solomon was alive. He caused trouble for Solomon, as Hadad also did. Rezon ruled in Syria and he hated the Israelite people."
    },
    {
      "verse": "26",
      "text": "Nebat's son Jeroboam was one of Solomon's officers. He came from Zeredah in Ephraim. His mother was a widow. Her name was Zeruah. Jeroboam turned against King Solomon."
    },
    {
      "verse": "27",
      "text": "This is what happened: Solomon had built the Millo. He had also mended the walls of the City of David his father."
    },
    {
      "verse": "28",
      "text": "Jeroboam was a strong young man. Solomon saw that he did his work very well. So he made Jeroboam the leader of the workers who belonged to Joseph's tribe."
    },
    {
      "verse": "29",
      "text": "During that time, Jeroboam travelled out from Jerusalem. A prophet, Ahijah, met him on the road. They were alone in the country. Ahijah came from Shiloh. He was wearing a new coat."
    },
    {
      "verse": "30",
      "text": "Ahijah took off his new coat. He tore it into 12 pieces."
    },
    {
      "verse": "31",
      "text": "Then he said to Jeroboam, ‘Take ten pieces for yourself. This is what the Lord, Israel's God, is saying to you: “I will take Solomon's kingdom away from him! I will give you ten tribes to rule over."
    },
    {
      "verse": "32",
      "text": "But Solomon will continue to rule over one tribe. That is because King David served me faithfully, and because I have chosen Jerusalem as my special city. I did not choose a city in any of the other tribes of Israel."
    },
    {
      "verse": "33",
      "text": "I will take the kingdom away from Solomon because he and his people have turned away from me. They have started to worship Ashtoreth, the female god of the Sidonian people. They also worship Chemosh, the god of the Moabite people, and Molech, the god of the Ammonite people. They have not lived in a way that pleases me. They have not done the things that I say are right. They have not obeyed my rules and my laws. They have not lived in a good way, as Solomon's father David did."
    },
    {
      "verse": "34",
      "text": "But I will not take the whole kingdom away from Solomon. I will let him continue to rule as king while he still lives. I will do that because of my servant David that I chose to be king. David obeyed my commands and my rules."
    },
    {
      "verse": "35",
      "text": "I will take the kingdom away from his son and I will give ten tribes for you to rule."
    },
    {
      "verse": "36",
      "text": "But I will leave one tribe for Solomon's son to rule. Then my servant David will continue to have a descendant who serves me as king in Jerusalem. That is the city where I have chosen for people to worship me."
    },
    {
      "verse": "37",
      "text": "But I will make you, Jeroboam, king of Israel. You will rule over all the land that you want for yourself."
    },
    {
      "verse": "38",
      "text": "But you must do everything that I command you to do. You must live in a way that pleases me. You must do the things that I say are right. You must obey my rules and my commands, as my servant David did. If you do that, I will always be with you. I will cause your descendants to continue to rule Israel. What I have done for David's family, I will also do for your family. The nation of Israel will belong to you."
    },
    {
      "verse": "39",
      "text": "Because of Solomon's sins I will punish David's descendants. But I will not punish them for ever. ” ’"
    },
    {
      "verse": "40",
      "text": "Solomon then tried to kill Jeroboam, but Jeroboam escaped to Egypt. Shishak, the king of Egypt, kept Jeroboam safe. Jeroboam stayed in Egypt until Solomon died."
    },
    {
      "verse": "41",
      "text": "The other things that happened while Solomon was king are written in a book. The book is called ‘The history of Solomon’. It tells about Solomon's wisdom and everything that he did."
    },
    {
      "verse": "42",
      "text": "years while he lived in Jerusalem."
    },
    {
      "verse": "43",
      "text": "Then he died. They buried him with his ancestors, in the city of his father David. His son Rehoboam became king after him."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "Rehoboam went to Shechem, because all the Israelites had gone there to make him king."
    },
    {
      "verse": "2",
      "text": "At this time, Nebat's son Jeroboam was still in Egypt. He had been living there since he ran away from King Solomon. When he heard the news about Rehoboam, he returned home."
    },
    {
      "verse": "3",
      "text": "The Israelites sent a message to Jeroboam to meet with them. Then Jeroboam and the whole group of Israelites went to speak to Rehoboam. They said to him,"
    },
    {
      "verse": "4",
      "text": "‘Your father caused us to work too hard. Please make the work easier for us. If you do that, we will serve you as our king. ’"
    },
    {
      "verse": "5",
      "text": "Rehoboam answered them, ‘Go away for three days. Then come back to me. ’ So the people went away."
    },
    {
      "verse": "6",
      "text": "Then King Rehoboam went to talk to the older advisors who had served his father Solomon. He asked them, ‘What answer should I give to these people? ’"
    },
    {
      "verse": "7",
      "text": "The old men said to him, ‘If you agree to help these people today, they will always serve you as their king. So do what they are asking you to do. ’"
    },
    {
      "verse": "8",
      "text": "But Rehoboam did not agree with their advice. Instead he talked to some younger men. They had been his friends since they were young and now they were his advisors."
    },
    {
      "verse": "9",
      "text": "He asked them, ‘What do you think that I should say to these people? They want me to make their work easier. ’"
    },
    {
      "verse": "10",
      "text": "Rehoboam's young advisors said, ‘Those people said to you, “Your father made us work too hard. Please make our work easier. ” You should tell them, “Even my little finger is thicker than my father's whole body!"
    },
    {
      "verse": "11",
      "text": "My father made you work hard. I will make you work even harder! My father punished you with little whips. I will punish you with whips that bite your skin! ” ’"
    },
    {
      "verse": "12",
      "text": "Jeroboam and all the people returned to Rehoboam after three days. That was because the king had said, ‘Return to me in three days. ’"
    },
    {
      "verse": "13",
      "text": "King Rehoboam spoke cruel words to the people. He did not agree to say what the older men had told him to say."
    },
    {
      "verse": "14",
      "text": "Instead, he did what the young men had suggested. He said to the people, ‘My father gave you work that was too hard for you. I will make it even worse! My father punished you with little whips. I will punish you with whips that bite! ’"
    },
    {
      "verse": "15",
      "text": "So the king did not agree to do what the people wanted him to do. It was the Lord who caused this to happen. He had already given his message about this to Nebat's son Jeroboam. The prophet Ahijah who came from Shiloh had spoken the Lord's message to Jeroboam."
    },
    {
      "verse": "16",
      "text": "All the Israelites realized that the king refused to listen to them. So they said to the king, ‘We can no longer serve the family of Jesse's son, David! Israelites, go back to your homes! You descendant of David, take care of your own family! ’So the Israelites went to their homes. ‘We can no longer serve the family of Jesse's son, David! Israelites, go back to your homes! You descendant of David, take care of your own family! ’ So the Israelites went to their homes."
    },
    {
      "verse": "17",
      "text": "But Rehoboam continued to rule over the Israelites who lived in the towns of Judah."
    },
    {
      "verse": "18",
      "text": "King Rehoboam sent a man called Adoniram to talk to the Israelite people. Adoniram had authority over the men who had to work for Rehoboam. But the Israelites threw stones at Adoniram and they killed him. So King Rehoboam quickly got into his chariot and he escaped to Jerusalem."
    },
    {
      "verse": "19",
      "text": "Since that time, the tribes in the north of Israel have not accepted the authority of King David's descendants."
    },
    {
      "verse": "20",
      "text": "All the Israelites heard that Jeroboam had returned from Egypt. So they asked him to come to a meeting of the people. They decided to make him king over all Israel. Only the tribe of Judah still served David's descendant as their king."
    },
    {
      "verse": "21",
      "text": "Rehoboam arrived back in Jerusalem. He brought together all the men from the tribes of Judah and Benjamin who knew how to fight. There were 180, 000 of them. Solomon's son Rehoboam wanted to attack the Israelite tribes so that he could rule them again as king. So they obeyed the Lord's message. They went back to their homes, as the Lord had commanded them to do."
    },
    {
      "verse": "22",
      "text": "But God told the prophet Shemaiah,"
    },
    {
      "verse": "23",
      "text": "‘Say this to Solomon's son Rehoboam, the king of Judah. Say it to all the people of Judah and Benjamin, and to all the other people."
    },
    {
      "verse": "24",
      "text": "This is what the Lord says: “Do not attack your brothers, the Israelites. Do not fight against them. Instead, you must all go home. I, the Lord, have decided that this must happen. ” ’So they obeyed the Lord's message. They went back to their homes, as the Lord had commanded them to do."
    },
    {
      "verse": "25",
      "text": "Jeroboam made Shechem into a strong city. He lived there, in the hill country of Ephraim. He also went to make Penuel a strong city."
    },
    {
      "verse": "26",
      "text": "Jeroboam thought, ‘I do not want the people of my kingdom to accept David's descendants as king again."
    },
    {
      "verse": "27",
      "text": "The people that I rule will go to the Lord's temple in Jerusalem to offer sacrifices there. Then they may decide to serve Rehoboam, king of Judah, who was their master before. They might kill me and then go back to serve King Rehoboam. ’"
    },
    {
      "verse": "28",
      "text": "So King Jeroboam talked to his advisors. He used gold to make images of two young cows. He said to the people, ‘It is too difficult for you to go to Jerusalem to worship the Lord, as you have done before. So I have made these gold cows for you instead. Look at them, Israelite people! These are your gods that rescued you and brought you out from Egypt. ’"
    },
    {
      "verse": "29",
      "text": "Jeroboam put one gold cow in Bethel. He put the other gold cow in Dan."
    },
    {
      "verse": "30",
      "text": "But that caused the Israelite people to do a very bad thing. They went to Bethel and to Dan to worship the gold cows."
    },
    {
      "verse": "31",
      "text": "Jeroboam also built places on hills for people to worship. He chose men who were not from Levi's tribe to be priests."
    },
    {
      "verse": "32",
      "text": "He decided to have a festival on the 15th day of the eighth month each year. He wanted it to be like the festival that they had in Judah. He offered sacrifices on the altar in Bethel to the gold cows that he had made. He also chose priests to serve at the places that he built for people to worship."
    },
    {
      "verse": "33",
      "text": "On the 15th day of the eighth month, Jeroboam offered sacrifices on the altar that he had made at Bethel. That was the special day that he himself had decided to choose as a festival for the Israelites. On that day, he burned incense on the altar."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "King Jeroboam was standing in front of the altar at Bethel. He was ready to make an offering. At that time, the Lord told one of his servants to go from Judah to Bethel."
    },
    {
      "verse": "2",
      "text": "When he arrived at Bethel, he shouted the message that the Lord had given to him. He said, ‘Altar! Altar! This is what the Lord says to you: “Listen! One day, a son will be born in David's family. His name will be Josiah. On this altar, he will burn as sacrifices the priests who offer sacrifices on the hills. He will burn the bones of dead people on you! ” ’"
    },
    {
      "verse": "3",
      "text": "The same day, God's servant spoke another message to warn Jeroboam. He said, ‘This is the sign to show that the Lord has decided to do this: You will see the altar break into two pieces. The ashes of the sacrifices that are on it will fall to the ground. ’"
    },
    {
      "verse": "4",
      "text": "King Jeroboam heard the message that God's servant shouted against the altar at Bethel. As he stood there at the altar, the king pointed his hand at God's servant. He said, ‘Take hold of that man! ’ But when he pointed with his hand, it suddenly became useless and he could not pull it back."
    },
    {
      "verse": "5",
      "text": "Then the altar broke into two pieces and the ashes fell to the ground. That is what God's servant had said would happen, to show that he spoke with the Lord's authority."
    },
    {
      "verse": "6",
      "text": "The king said to God's servant, ‘Please pray to the Lord your God that he will be kind to me. Pray that my hand will become strong again. ’ So God's servant prayed to the Lord. And the king's hand became strong again, as it was before."
    },
    {
      "verse": "7",
      "text": "Then the king said to God's servant, ‘Come home with me. Have some food to eat. I would also like to give you a gift. ’"
    },
    {
      "verse": "8",
      "text": "But God's servant said to the king, ‘I could never go with you, even if you gave me half of your riches. I could not eat or drink anything while I am here."
    },
    {
      "verse": "9",
      "text": "The Lord commanded me, “You must not eat or drink anything there. You must not return home on the same road that you came on. ” ’"
    },
    {
      "verse": "10",
      "text": "So God's servant started to travel home on a different road. He did not go on the same road that he came to Bethel."
    },
    {
      "verse": "11",
      "text": "An old prophet lived in Bethel. His sons came home. They told him about everything that God's servant had done in Bethel that day. They told their father what God's servant had said to the king."
    },
    {
      "verse": "12",
      "text": "Their father asked them, ‘Which road did he go home on? ’ So his sons showed him the road that God's servant from Judah was on."
    },
    {
      "verse": "13",
      "text": "Then the old prophet said to his sons, ‘Prepare my donkey for me to ride. ’ When they had prepared the donkey, the old prophet got onto it."
    },
    {
      "verse": "14",
      "text": "Then he rode along the road to find God's servant. He found him as he was sitting under an oak tree. The old prophet asked him, ‘Are you the servant of God from Judah? ’ He answered, ‘I am. ’"
    },
    {
      "verse": "15",
      "text": "The old prophet said to him, ‘Come to my home with me and eat some food. ’"
    },
    {
      "verse": "16",
      "text": "God's servant said, ‘I cannot go back with you. I cannot eat or drink anything with you in this place."
    },
    {
      "verse": "17",
      "text": "The Lord commanded me, “You must not eat or drink anything there. You must not return home on the same road that you came on. ” ’"
    },
    {
      "verse": "18",
      "text": "The old prophet then said, ‘I am also a prophet, as you are. An angel gave me a message from the Lord. He said, “Bring the man back with you to your house. There, he can eat some food and drink some water. ” ’ But what the old prophet said was a lie."
    },
    {
      "verse": "19",
      "text": "So God's servant went back with him and he ate and drank in his house."
    },
    {
      "verse": "20",
      "text": "While they were sitting together to eat, the Lord gave a message to the old prophet."
    },
    {
      "verse": "21",
      "text": "He spoke this message to the servant of God who had come from Judah:‘This is what the Lord says: You have not obeyed the Lord. You have not done what the Lord your God commanded you to do."
    },
    {
      "verse": "22",
      "text": "He had told you, “You must not eat or drink anything in that place. ” But you came back here to eat and to drink. As a result, they will not bury your body in the same place as your ancestors' grave. ’"
    },
    {
      "verse": "23",
      "text": "God's servant from Judah finished his meal. Then the old prophet prepared his donkey for him to ride."
    },
    {
      "verse": "24",
      "text": "But as God's servant from Judah was travelling along the road, a lion attacked him. The lion killed him and it left his body on the road. The donkey and the lion stood beside the dead body."
    },
    {
      "verse": "25",
      "text": "When some people came along the road, they saw the dead body as it lay there. The lion was standing beside the body. The people went back to Bethel, the city where the old prophet lived. They reported what they had seen on the road."
    },
    {
      "verse": "26",
      "text": "The old prophet who had brought God's servant back to his house heard the news. He said, ‘That dead man is God's servant who did not obey the Lord. So the Lord has given him to the lion, to tear him to pieces and to kill him. The Lord had warned him that this would happen. ’"
    },
    {
      "verse": "27",
      "text": "The old prophet said to his sons, ‘Prepare my donkey for me to ride. ’ So they did that."
    },
    {
      "verse": "28",
      "text": "Then the old prophet went along the road and he found the body. It was lying on the road. The donkey and the lion were standing beside it. The lion had not eaten the body. It had not attacked the donkey."
    },
    {
      "verse": "29",
      "text": "So the old prophet picked up the body of God's servant. He put it on the donkey. He brought it back to Bethel. He showed that he was very sad that the man had died and then he buried him."
    },
    {
      "verse": "30",
      "text": "He put the body in the grave that he had prepared for himself. He and his sons were very upset, and they said, ‘Oh! My brother! ’"
    },
    {
      "verse": "31",
      "text": "When they had buried the man, the old prophet said to his sons, ‘When I die, bury me in the same grave where we buried the servant of God. Put my bones there, beside his bones."
    },
    {
      "verse": "32",
      "text": "The Lord's message that he spoke will certainly become true. He spoke against the altar in Bethel and against all the altars on the hills of Samaria's towns. ’"
    },
    {
      "verse": "33",
      "text": "Even after this happened, Jeroboam did not stop doing evil things. He chose ordinary people to be priests for the altars on the hills. If somebody wanted to become a priest, Jeroboam agreed to make him a priest."
    },
    {
      "verse": "34",
      "text": "This sin caused Jeroboam's family to disappear from the earth. He would no longer have descendants to rule the kingdom."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "At that time, Jeroboam's son Abijah became ill."
    },
    {
      "verse": "2",
      "text": "So Jeroboam said to his wife, ‘Change what you look like so that people will not recognize you as my wife. Then go to Shiloh. The prophet Ahijah lives there. He told me that I would rule the nation of Israel."
    },
    {
      "verse": "3",
      "text": "Take ten loaves of bread with you. Also take some cakes and a pot of honey. When you visit Ahijah, he will tell you what will happen to our son. ’"
    },
    {
      "verse": "4",
      "text": "Jeroboam's wife did what he told her to do. She went to Ahijah's house in Shiloh. Ahijah could not see because he was very old."
    },
    {
      "verse": "5",
      "text": "But the Lord had said to Ahijah, ‘Jeroboam's wife will come to visit you. Her son is ill and she will ask you what will happen to him. I will tell you what to say to her. When she comes, she will pretend that she is not the king's wife. ’"
    },
    {
      "verse": "6",
      "text": "Then Ahijah heard her as she walked through the door of his house. He said, ‘Come in, Jeroboam's wife! I know who you are, so do not pretend to be somebody else. The Lord has given me bad news to tell you."
    },
    {
      "verse": "7",
      "text": "Go and say to Jeroboam, “This is what the Lord, Israel's God, says to you: I chose you from among my people, the Israelites, and I made you their ruler."
    },
    {
      "verse": "8",
      "text": "I took Israel's kingdom away from David's family and I gave it to you. But you have not served me faithfully as my servant David did. He obeyed my commands. He was faithful to me and he always did the things that I say are right."
    },
    {
      "verse": "9",
      "text": "But you have done more evil things than any of the kings who lived before you. You have made me very angry. You have used metal to make images of other gods that you could worship. You have turned away from me."
    },
    {
      "verse": "10",
      "text": "Because of this, I will bring great trouble to Jeroboam's family. I will kill every male among his descendants in Israel, whoever they are. I will completely destroy Jeroboam's family, like someone burns a heap of rubbish!"
    },
    {
      "verse": "11",
      "text": "If they die in the city, dogs will eat their bodies. If they die in the country, vultures will eat them. This is what the Lord has said will happen! ”"
    },
    {
      "verse": "12",
      "text": "But you, Jeroboam's wife, should go back home now. As soon as you arrive back in the city, the boy will die."
    },
    {
      "verse": "13",
      "text": "All Israel will cry because of his death and they will bury him. He is the only person from Jeroboam's family that they will bury properly. He is the only one among Jeroboam's descendants who has pleased the Lord, Israel's God."
    },
    {
      "verse": "14",
      "text": "The Lord himself will choose another king to rule Israel. That king will destroy Jeroboam's family. This will happen very soon, even today!"
    },
    {
      "verse": "15",
      "text": "The Lord will attack the nation of Israel. He will shake it, as the wind shakes a reed that is growing in a stream. The Lord will remove the Israelites from this good land that he gave to their ancestors. He will take them to places beyond the Euphrates river. They made Asherah poles to worship, so the Lord became very angry with them."
    },
    {
      "verse": "16",
      "text": "He will put Israel under the power of its enemies because of Jeroboam's sins. Jeroboam also caused Israel's people to do bad things. ’"
    },
    {
      "verse": "17",
      "text": "Then Jeroboam's wife left Ahijah's house. She went back to Tirzah. When she walked through the door of her house, the boy died."
    },
    {
      "verse": "18",
      "text": "They buried him and all the Israelites cried because of his death. The Lord had told his servant the prophet Ahijah what would happen. And that is what happened."
    },
    {
      "verse": "19",
      "text": "The other things that happened while Jeroboam was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about the battles that Jeroboam fought and how he ruled as king."
    },
    {
      "verse": "20",
      "text": "years. Then he died and they buried him beside his ancestors. His son Nadab became king after him."
    },
    {
      "verse": "21",
      "text": "King Solomon's son, Rehoboam, ruled Judah as king. He was 41 years old when he became king. He ruled for 17 years in Jerusalem. That was the city that the Lord had chosen out of all the tribes of Israel. He chose it as the place where people would give honour to his name. Rehoboam's mother was an Ammonite woman. Her name was Naamah."
    },
    {
      "verse": "22",
      "text": "The people of Judah did things that the Lord said were evil. Their sins caused the Lord to be very angry. They did worse things than their ancestors had done."
    },
    {
      "verse": "23",
      "text": "They built altars on the hills for themselves. They put up stone pillars and Asherah poles to worship. They did this on every high hill and under every big tree."
    },
    {
      "verse": "24",
      "text": "In Judah there were even temples which had male prostitutes. The people of Judah did the same evil things as the Canaanite nations did. The Lord had chased those people out of the land so that the Israelites could live there."
    },
    {
      "verse": "25",
      "text": "In the fifth year that Rehoboam was king, King Shishak of Egypt attacked Jerusalem."
    },
    {
      "verse": "26",
      "text": "He took away the valuable things that were in the Lord's temple and in the king's palace. He took everything for himself. That included the gold shields that King Solomon had made."
    },
    {
      "verse": "27",
      "text": "So Rehoboam used bronze to make other shields instead. He gave them to the officers of his own soldiers. These soldiers stood as guards at the entrance of the king's palace."
    },
    {
      "verse": "28",
      "text": "Every time that the king went to the Lord's temple, the guards carried the shields. After that, they took them back to the guards' room where they stored them."
    },
    {
      "verse": "29",
      "text": "The other things that happened while Rehoboam was king are written in a book. The book is called ‘The history of Judah's kings’. It tells about everything that King Rehoboam did."
    },
    {
      "verse": "30",
      "text": "There was always a war between the armies of Rehoboam and Jeroboam."
    },
    {
      "verse": "31",
      "text": "Rehoboam died and they buried him beside his ancestors in the City of David. Rehoboam's mother was an Ammonite woman. Her name was Naamah. Rehoboam's son Abijah became king after him."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "Abijah became king of Judah after Nebat's son Jeroboam had been king of Israel for 18 years."
    },
    {
      "verse": "2",
      "text": "Abijah ruled in Jerusalem as king for three years. His mother's name was Maakah. She was the daughter of Abishalom."
    },
    {
      "verse": "3",
      "text": "Abijah did the same bad things that his father had done before him. He did not serve the Lord his God faithfully, as his ancestor King David had done."
    },
    {
      "verse": "4",
      "text": "But the Lord his God gave Abijah a son to rule after him in Jerusalem. He also made Jerusalem a strong city. The Lord did that because of his promise to David."
    },
    {
      "verse": "5",
      "text": "David had always done things that pleased the Lord. David had obeyed the Lord's commands in his whole life, except what he did to Uriah, the Hittite man."
    },
    {
      "verse": "6",
      "text": "In Abijah's whole life, there was a war between the armies of Rehoboam and Jeroboam."
    },
    {
      "verse": "7",
      "text": "The other things that happened while Abijah was king are written in a book. The book is called ‘The history of Judah's kings’. It tells about all the things that Abijah did. While Abijah was king, there was war between his army and Jeroboam's army."
    },
    {
      "verse": "8",
      "text": "Abijah died and they buried him beside his ancestors in the City of David. Abijah's son Asa became king after him."
    },
    {
      "verse": "9",
      "text": "years."
    },
    {
      "verse": "10",
      "text": "years. His grandmother was Maakah. She was the daughter of Abishalom."
    },
    {
      "verse": "11",
      "text": "Asa did things that pleased the Lord, as his ancestor King David had done."
    },
    {
      "verse": "12",
      "text": "He removed the male prostitutes from the altars on the hills. He sent them out of Judah. He removed all the useless idols that his ancestors had made."
    },
    {
      "verse": "13",
      "text": "He also told his grandmother Maakah that she could no longer have authority as the Queen Mother. This was because she had made a disgusting Asherah pole to worship. Asa cut down the Asherah pole and he burned it in the Kidron Valley."
    },
    {
      "verse": "14",
      "text": "Asa did not remove the altars on all the hills, but he served the Lord faithfully for his whole life."
    },
    {
      "verse": "15",
      "text": "He brought into the Lord's temple the things that he and his father had made as gifts to the Lord. They used silver and gold to make some of these things."
    },
    {
      "verse": "16",
      "text": "There was always a war between King Asa of Judah and King Baasha of Israel while they ruled."
    },
    {
      "verse": "17",
      "text": "One time, Baasha attacked Judah. He put a group of his soldiers in Ramah and he made it a strong town. As a result, nobody could travel into Judah or out of Judah, where King Asa ruled."
    },
    {
      "verse": "18",
      "text": "So Asa took all the silver and gold that they had stored in his palace and in the Lord's temple. He gave it to his servants. He told them to take it to Ben-Hadad, king of Syria, who lived in Damascus. Ben-Hadad's father was Tabrimmon and his grandfather was Hezion."
    },
    {
      "verse": "19",
      "text": "Asa sent this message to Ben-Hadad: ‘We should make an agreement to be friends, as our fathers did. I am sending you this gift of silver and gold. Please stop being friends with Baasha, king of Israel. If you no longer help him, he will have to take his soldiers out of my country. ’"
    },
    {
      "verse": "20",
      "text": "Ben-Hadad agreed to do what King Asa asked him to do. He sent his army with its leaders to attack towns in Israel. They won the battles at Ijon, Dan, Abel-Beth-Maakah, as well as the region of Kinnereth and the land of Naphtali."
    },
    {
      "verse": "21",
      "text": "When King Baasha heard this news, he stopped the work in Ramah. He left there and he went to live in Tirzah."
    },
    {
      "verse": "22",
      "text": "Then King Asa commanded all the men in Judah to do some hard work. Everyone had to do this: They must carry away from Ramah all the big stones and the wood that Baasha had been using there. Then King Asa used those things to make Geba (in Benjamin's land) and Mizpah strong towns again."
    },
    {
      "verse": "23",
      "text": "The other things that happened while Asa was king are written in a book. The book is called ‘The history of Judah's kings’. It tells about Asa's power and all the great things that he did. It also tells about the cities that he built. When Asa became an old man he had a disease in his feet."
    },
    {
      "verse": "24",
      "text": "Asa died and they buried him beside his ancestors in the City of David, his ancestor. Asa's son Jehoshaphat became king after him."
    },
    {
      "verse": "25",
      "text": "When Asa had been king of Judah for two years, Jeroboam's son became king of Israel. Nadab ruled Israel as king for two years."
    },
    {
      "verse": "26",
      "text": "He did things that the Lord said were evil. He did the same bad things that his father had done. He also caused the Israelites to do bad things."
    },
    {
      "verse": "27",
      "text": "Baasha decided to kill King Nadab. Baasha was Ahijah's son and he belonged to Issachar's tribe. This happened while Nadab and Israel's army were attacking Gibbethon, a town of the Philistines."
    },
    {
      "verse": "28",
      "text": "Baasha killed King Nadab in the third year that Asa was king of Judah. Baasha became king of Israel instead of Nadab."
    },
    {
      "verse": "29",
      "text": "When Baasha became king, he killed all Jeroboam's descendants. He did not leave anyone in Jeroboam's family alive. He killed them all. The Lord had already said that this would happen. He had given the message to his servant Ahijah, who was from Shiloh."
    },
    {
      "verse": "30",
      "text": "This happened because of Jeroboam's sins, and the sins which he caused the Israelites to do. These sins had made the Lord, Israel's God, very angry."
    },
    {
      "verse": "31",
      "text": "The other things that happened while Nadab was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about all the things that Nadab did."
    },
    {
      "verse": "32",
      "text": "There was always a war between the armies of King Asa and King Nadab."
    },
    {
      "verse": "33",
      "text": "In the third year that Asa was king of Judah, Ahijah's son Baasha became the king of all Israel. He was living in Tirzah. Baasha ruled as king for 24 years."
    },
    {
      "verse": "34",
      "text": "Baasha did things that the Lord said were evil. He did the same sins that Jeroboam had done. He also caused the Israelites to do those bad things."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "Then God gave a message to Hanani's son Jehu about punishment for King Baasha."
    },
    {
      "verse": "2",
      "text": "This was the message: ‘Even though you were not an important person, I made you the leader of my people, the Israelites. But then you did all the bad things that Jeroboam did! Also, you caused my people the Israelites to do bad things. Their sins have caused me to become very angry."
    },
    {
      "verse": "3",
      "text": "So now I am ready to destroy you and your family. I will remove your family as I did to the family of Nebat's son Jeroboam."
    },
    {
      "verse": "4",
      "text": "If people of your family die in the city, dogs will eat their bodies. If they die in the country, vultures will eat them. ’"
    },
    {
      "verse": "5",
      "text": "The other things that happened while Baasha was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about all the things that Baasha did and about his power."
    },
    {
      "verse": "6",
      "text": "Baasha died and they buried him in Tirzah. His son Elah became king after him."
    },
    {
      "verse": "7",
      "text": "Hanani's son Jehu, the prophet, had received a message from the Lord about Baasha and his family. Baasha had done many things that the Lord said were evil, in the same way that Jeroboam had done. Baasha had even destroyed Jeroboam's whole family. These bad things made the Lord very angry."
    },
    {
      "verse": "8",
      "text": "years, Baasha's son Elah became king of Israel. He ruled as king in Tirzah for two years."
    },
    {
      "verse": "9",
      "text": "Zimri was one of Elah's officers. He had authority over half of Elah's chariots. Zimri decided to kill King Elah. One day, Elah was in the home of a man called Arza, an officer who had authority over the king's palace in Tirzah. Elah was drinking too much wine and he became drunk."
    },
    {
      "verse": "10",
      "text": "Zimri came in to Arza's house. He hit Elah and he killed him. When this happened, Asa had been king of Judah for 27 years. Zimri made himself king instead of Elah."
    },
    {
      "verse": "11",
      "text": "When Zimri began to rule Israel as king, he killed everybody in Baasha's family. He did not leave any of Baasha's male relatives alive. He even killed Baasha's friends."
    },
    {
      "verse": "12",
      "text": "Zimri killed everybody in Baasha's family, as the Lord had said it would happen. The prophet Jehu had spoken the Lord's message against Baasha."
    },
    {
      "verse": "13",
      "text": "This happened because of all the sins that Baasha and his son Elah had done. They had also caused the Israelites to do bad things. The useless idols that they worshipped had made the Lord, Israel's God, very angry."
    },
    {
      "verse": "14",
      "text": "The other things that happened while Elah was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about all the things that Elah did."
    },
    {
      "verse": "15",
      "text": "years, Zimri became king of Israel. He ruled as king in Tirzah for seven days. When Zimri killed King Elah, Israel's army was attacking a Philistine town called Gibbethon."
    },
    {
      "verse": "16",
      "text": "The army received this message: ‘Zimri has turned against the king and he has killed King Elah. ’ Omri was the officer who led Israel's army. That day, Omri's soldiers decided to make Omri the king of Israel, while they were in their camp at Gibbethon."
    },
    {
      "verse": "17",
      "text": "So Omri and all Israel's army left Gibbethon and they went to attack Tirzah."
    },
    {
      "verse": "18",
      "text": "Zimri saw that Omri had taken power over the city. So he went into the strong buildings of the king's palace. He lit a fire to burn the palace all around him. Zimri himself died in the fire."
    },
    {
      "verse": "19",
      "text": "This happened because of the sins that he had done. He did things that the Lord says are evil. He did the same bad things that Jeroboam had done. He also caused the Israelites to continue doing bad things."
    },
    {
      "verse": "20",
      "text": "The other things that happened while Zimri was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about how he killed King Elah, as well as the other things that he did."
    },
    {
      "verse": "21",
      "text": "At that time, half of the Israelite people wanted Omri to be their king. But half of the people wanted Ginath's son Tibni to be their king. The two groups of people could not agree together."
    },
    {
      "verse": "22",
      "text": "But the group who wanted Omri to be king was stronger than the other group. As a result, Tibni died. Then Omri became the king of Israel."
    },
    {
      "verse": "23",
      "text": "years. Omri ruled Israel as king for 12 years. He lived in Tirzah for the first six years."
    },
    {
      "verse": "24",
      "text": "Then Omri bought a hill from a man called Shemer. He paid Shemer 70 kilograms of silver for it. He built a city on the hill and he called the city Samaria. That was because the hill had belonged to Shemer."
    },
    {
      "verse": "25",
      "text": "But Omri did many things that the Lord said were evil. He did more evil things than all the kings of Israel who lived before him."
    },
    {
      "verse": "26",
      "text": "He did the same bad things that Nebat's son Jeroboam had done and that he caused the Israelites to do. The useless idols that they worshipped caused the Lord, Israel's God, to be very angry."
    },
    {
      "verse": "27",
      "text": "The other things that happened while Omri was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about the things that he did and the power that he had."
    },
    {
      "verse": "28",
      "text": "Omri died and they buried him in Samaria. His son Ahab became king of Israel after him."
    },
    {
      "verse": "29",
      "text": "Omri's son Ahab became king of Israel when Asa had been king of Judah for 38 years. Ahab ruled Israel as king in Samaria for 22 years."
    },
    {
      "verse": "30",
      "text": "Omri's son Ahab did many things that the Lord said were evil. He did more evil things than all the kings of Israel who lived before him."
    },
    {
      "verse": "31",
      "text": "He did the same bad things that Nebat's son Jeroboam had done. He even did something that was even worse. He married Jezebel, the daughter of Ethbaal, the king of Sidon. Ahab served Baal as his god and he worshipped him."
    },
    {
      "verse": "32",
      "text": "Ahab built a temple for Baal in Samaria. He made an altar for Baal in this temple."
    },
    {
      "verse": "33",
      "text": "Ahab also made an Asherah pole to worship. He did many bad things that made the Lord, Israel's God, angry. He did more bad things than all the kings of Israel who lived before him."
    },
    {
      "verse": "34",
      "text": "While Ahab ruled as king, Hiel built Jericho city again. Hiel came from Bethel. Abiram, his firstborn son, died when Hiel built the city's foundation. Segub, his youngest son, died when he built the gates in the city's wall. The Lord had told Nun's son Joshua that this would happen."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "There was a prophet called Elijah who came from Tishbe in Gilead. He said to King Ahab, ‘I am a servant of the Lord, Israel's God. As surely as God lives, there will be no rain or dew for the next few years. Nothing will make the ground wet until I command it to happen. ’"
    },
    {
      "verse": "2",
      "text": "Then the Lord told Elijah,"
    },
    {
      "verse": "3",
      "text": "‘Leave here! Go to the east. Hide in the Kerith valley, east of the Jordan River."
    },
    {
      "verse": "4",
      "text": "You will drink water from the stream. I have also commanded the ravens to feed you there. ’"
    },
    {
      "verse": "5",
      "text": "Elijah obeyed the Lord's message. He went to live in the Kerith valley, near the Jordan River."
    },
    {
      "verse": "6",
      "text": "The ravens brought him bread and meat to eat, every morning and every evening. He drank water from the stream."
    },
    {
      "verse": "7",
      "text": "After some time the stream became dry, because there had been no rain in the whole land."
    },
    {
      "verse": "8",
      "text": "Then the Lord told Elijah,"
    },
    {
      "verse": "9",
      "text": "‘Go now to Zarephath in the region of Sidon. Go and live there. I have told a widow who lives there that she must give you food to eat. ’"
    },
    {
      "verse": "10",
      "text": "So Elijah went to Zarephath. When he arrived at the town gate, he met a widow. She was picking up some sticks. Elijah asked her, ‘Please bring me some water in a jar, so that I can drink it. ’"
    },
    {
      "verse": "11",
      "text": "While she went to get it, he said, ‘Please bring me a piece of bread too. ’"
    },
    {
      "verse": "12",
      "text": "She replied, ‘As surely as the Lord your God lives, I do not have any bread. I have only a small amount of flour in a bowl and some olive oil in a small jar. I am now picking up a few sticks to take home. Then I will cook a meal for myself and for my son. We will eat it. Then we will die because there is nothing else to eat. ’"
    },
    {
      "verse": "13",
      "text": "Elijah said to her, ‘Do not be afraid. Go home and do what you have said. But first, use some of your flour to make a small piece of bread for me. Then bring it to me. After that, you should make something for yourself and for your son."
    },
    {
      "verse": "14",
      "text": "This is what the Lord, Israel's God, says: “You will not use all the flour in your bowl. You will not use all the oil in your jar. They will not become empty until the day when the Lord causes rain to fall on the ground again. ” ’"
    },
    {
      "verse": "15",
      "text": "Then the widow went home. She did what Elijah had told her to do. After that, there was enough food every day for Elijah and for the widow and her family."
    },
    {
      "verse": "16",
      "text": "The flour in the bowl and the olive oil in the jar never finished. The Lord had promised Elijah that this would happen."
    },
    {
      "verse": "17",
      "text": "Some time after that, the widow's son became ill. He became very ill until he could no longer breathe."
    },
    {
      "verse": "18",
      "text": "The woman said to Elijah, ‘Servant of God, why have you come to hurt me like this? Did you come to kill my son so that I would remember all my sins? ’"
    },
    {
      "verse": "19",
      "text": "Elijah replied, ‘Give your son to me. ’ He took her son from her arms. He carried the boy upstairs, to the room where he was staying. He put the boy down to lie on his bed."
    },
    {
      "verse": "20",
      "text": "Then Elijah prayed to the Lord, ‘Lord, my God! Why have you caused such bad trouble to happen to this kind widow? I came to stay with her and now you have killed her son! ’"
    },
    {
      "verse": "21",
      "text": "Then Elijah lay with his body across the boy. He did that three times. He prayed to the Lord, ‘Lord, my God, please cause this boy's life to return to him! ’"
    },
    {
      "verse": "22",
      "text": "The Lord answered Elijah's prayer. The boy started to breathe again. He was alive!"
    },
    {
      "verse": "23",
      "text": "Elijah picked up the boy. He carried him down from his room into the house. He gave the boy to his mother and he said, ‘Look! Your son is alive! ’"
    },
    {
      "verse": "24",
      "text": "Then the woman said to Elijah, ‘Now I know that you are a servant of God. The words that you speak are truly a message from the Lord. ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "When there had been no rain for three years, the Lord told Elijah, ‘Go and meet King Ahab. After that, I will send rain to make the ground wet again. ’"
    },
    {
      "verse": "2",
      "text": "So Elijah went to meet Ahab. At that time, the famine in Samaria was very bad."
    },
    {
      "verse": "3",
      "text": "King Ahab told his officer Obadiah to come and meet him. Obadiah had authority over the king's palace. Obadiah obeyed the Lord very faithfully."
    },
    {
      "verse": "4",
      "text": "At one time, Ahab's wife Jezebel was killing many of the Lord's prophets. While she was doing this, Obadiah had kept 100 prophets safe. He had hidden them in two caves, with 50 prophets in each cave. He had also given them food and water."
    },
    {
      "verse": "5",
      "text": "Now Ahab said to Obadiah, ‘Go through all the land to where there are valleys and springs of water. See if we can find some grass to feed the horses and mules. Then we will not have to kill our animals. ’"
    },
    {
      "verse": "6",
      "text": "So Ahab and Obadiah went to different parts of the country. Ahab went in one direction and Obadiah went in another direction."
    },
    {
      "verse": "7",
      "text": "While Obadiah was walking along, Elijah met him. Obadiah recognized Elijah. He bent his body down towards the ground in front of Elijah. Obadiah said, ‘Is it really you, my master, Elijah? ’"
    },
    {
      "verse": "8",
      "text": "Elijah replied. ‘Yes! Now go and tell your master that Elijah is here again. ’"
    },
    {
      "verse": "9",
      "text": "Obadiah said, ‘Why are you sending me to my death? What have I done to hurt you? Ahab will certainly kill me if I tell him you are here!"
    },
    {
      "verse": "10",
      "text": "As surely as the Lord your God lives, my master, King Ahab, has sent people everywhere to look for you. He has looked in every nation and every kingdom. When they say, “Elijah is not here! ” he makes them promise that they are speaking the truth."
    },
    {
      "verse": "11",
      "text": "But now you are telling me to go to my master. You want me to say, “Elijah is here! ”"
    },
    {
      "verse": "12",
      "text": "When I leave you, I do not know where the Lord's Spirit will take you. I may not be able to find you again. Then if I tell Ahab that I have seen you, he still will not find you. So he will kill me. But I have served the Lord faithfully since I was a young man."
    },
    {
      "verse": "13",
      "text": "You know, sir, about what I did when Jezebel was killing the Lord's prophets. I hid 100 prophets in two caves. I put 50 prophets in each cave. I gave them food and water."
    },
    {
      "verse": "14",
      "text": "But now you tell me to go to my master and say, “Elijah is here! ” I know that he will kill me! ’"
    },
    {
      "verse": "15",
      "text": "Elijah said, ‘I serve the Lord Almighty. As surely as he lives, I promise that I will meet with King Ahab today. ’"
    },
    {
      "verse": "16",
      "text": "So Obadiah went to Ahab. He told Ahab where Elijah was. So King Ahab went to meet Elijah."
    },
    {
      "verse": "17",
      "text": "When Ahab saw Elijah, he said to him, ‘Is that really you, the man who brings trouble to Israel? ’"
    },
    {
      "verse": "18",
      "text": "Elijah replied, ‘I have not brought trouble to Israel. But you and your father's family have done that. You have refused to obey the Lord's commands. Instead, you have worshipped the false gods of Baal."
    },
    {
      "verse": "19",
      "text": "Now, tell people from all over Israel to come and meet me. They must meet me on Mount Carmel. Also, bring the 450 prophets who serve Baal and the 400 prophets of Asherah that Jezebel provides with food. ’"
    },
    {
      "verse": "20",
      "text": "So Ahab sent men to take that message to all the Israelites. He brought the prophets to meet together at Mount Carmel."
    },
    {
      "verse": "21",
      "text": "Elijah stood up in front of the people and he said, ‘You must now decide who to worship! If the Lord is the true God, worship him. But if Baal is God, worship him. ’ But the people said nothing."
    },
    {
      "verse": "22",
      "text": "Then Elijah said to them, ‘I am the only prophet of the Lord who is still here. Baal has 450 prophets here."
    },
    {
      "verse": "23",
      "text": "Now fetch two bulls for us. Baal's prophets can choose one bull for themselves. Then they must cut it into pieces. They must put the pieces on the wood on the altar. But they must not light the fire. After that, I will prepare the other bull and I will put it on the wood. But I will not light the fire."
    },
    {
      "verse": "24",
      "text": "Then, you pray to your god, and I will pray to the Lord. The god who answers and who sends fire to light the wood, he is the true God! ’ All the people agreed that this was a good idea."
    },
    {
      "verse": "25",
      "text": "Elijah said to Baal's prophets, ‘There are many of you, so choose one of the bulls and prepare it first. Pray to your god, but do not light the fire. ’"
    },
    {
      "verse": "26",
      "text": "So Baal's prophets took a bull as Elijah had told them. They prepared it and they put it on the altar that they had made. Then they prayed to Baal all the time, from morning until noon. They shouted, ‘Baal, answer us! ’ But there was no voice that answered them. They jumped and they danced around the altar."
    },
    {
      "verse": "27",
      "text": "At noon, Elijah began to laugh at them. ‘Shout louder! ’ he said. ‘He is a god, isn't he? Maybe he is thinking about something else! Or has he left the room for a moment? Maybe he has gone away from home on a journey. Or perhaps he is asleep and you need to wake him up! ’"
    },
    {
      "verse": "28",
      "text": "So Baal's prophets shouted louder. They cut themselves with swords and knives, as their customs taught them to do. Soon, there was blood all over them."
    },
    {
      "verse": "29",
      "text": "They continued to shout and dance all the afternoon, until the time of the evening offering. But there was no voice to reply. There was no answer at all."
    },
    {
      "verse": "30",
      "text": "Then Elijah said to all the people, ‘Come nearer to me. ’ When they came, Elijah mended the Lord's altar that had broken into pieces."
    },
    {
      "verse": "31",
      "text": "stones, one for each of the tribes that were Jacob's descendants. Jacob was the man that the Lord had given the new name ‘Israel’."
    },
    {
      "verse": "32",
      "text": "stones to build an altar that would give honour to the Lord. He dug a hole in the ground all around it. The hole was big enough to contain 15 litres of seeds."
    },
    {
      "verse": "33",
      "text": "Then he put wood on the altar. He cut the bull into pieces and he put the pieces on top of the wood. Then he said to the people, ‘Fill four large jars with water. Pour the water all over the offering and the wood. ’"
    },
    {
      "verse": "34",
      "text": "After they did that, Elijah told them, ‘Do it again! ’ So they did it again. Then he told them, ‘Do it a third time! ’ So they did it for the third time."
    },
    {
      "verse": "35",
      "text": "The water poured down all the sides of the altar. It filled the hole that was around the altar."
    },
    {
      "verse": "36",
      "text": "The time came for the evening offering. Then God's prophet Elijah came to the front of the altar. He prayed, ‘Lord, you are the God of Abraham, Isaac and Israel. Show people clearly today that you are the God who rules over Israel. Show that I am your servant. Show that I have done all these things because you commanded me to do them."
    },
    {
      "verse": "37",
      "text": "Please answer me, Lord! Answer me so that these people will know that you, Lord, are the true God. They will know that you have caused them to turn back to serve you again. ’"
    },
    {
      "verse": "38",
      "text": "Then the Lord sent fire down from above. It burned the sacrifice, the wood, the stones and the dirt. It made all the water in the hole around the altar disappear!"
    },
    {
      "verse": "39",
      "text": "When all the people saw this, they threw themselves down on the ground. They shouted, ‘The Lord is the true God! Yes, the Lord is God! ’"
    },
    {
      "verse": "40",
      "text": "Then Elijah said, ‘Take hold of Baal's prophets! Do not let any of them run away! ’ So they caught them. Then Elijah took the prophets down to the Kishon Valley. There, he punished them with death."
    },
    {
      "verse": "41",
      "text": "Then Elijah said to Ahab, ‘Go now and have some food to eat. Go quickly, because there is the sound of heavy rain that is coming. ’"
    },
    {
      "verse": "42",
      "text": "So Ahab went away to eat and to drink. But Elijah climbed to the top of Mount Carmel. He bent low down towards the ground. He put his face between his knees."
    },
    {
      "verse": "43",
      "text": "He said to his servant, ‘Go up and look towards the sea. ’ So his servant did that. He said to Elijah, ‘There is nothing to see there. ’ Elijah told his servant seven times, ‘Go back and look again. ’"
    },
    {
      "verse": "44",
      "text": "The seventh time, the servant said, ‘I can see a small cloud above the sea that is coming this way. It is only as big as a man's hand. ’ So Elijah said, ‘Go and tell Ahab, “Prepare your chariot now! Go back down quickly before the rain stops you. ” ’"
    },
    {
      "verse": "45",
      "text": "As Elijah said this, the sky became very dark with black clouds. The wind started to blow and there was a heavy storm of rain. King Ahab rode away towards Jezreel."
    },
    {
      "verse": "46",
      "text": "Then the Lord gave Elijah special power. Elijah tied his robe into his belt and he ran all the way to Jezreel. Ahab followed him."
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "King Ahab told Jezebel about everything that Elijah had done. He told her how Elijah had killed all Baal's prophets with a sword."
    },
    {
      "verse": "2",
      "text": "So Jezebel sent someone with this message to Elijah: ‘By this time tomorrow, I will make sure that you are dead, the same as Baal's prophets! If I do not do that, I pray that the gods will kill me instead. ’"
    },
    {
      "verse": "3",
      "text": "Elijah became very afraid. He ran away to save his life. He arrived at Beersheba in Judah. He left his servant there."
    },
    {
      "verse": "4",
      "text": "Then Elijah went into the desert by himself. He travelled for about a day. He found a small tree there and he sat down under it. He prayed that he might die. He said, ‘Lord, I have had enough trouble! Take my life from me. It is no better for me here than to be with my dead ancestors. ’"
    },
    {
      "verse": "5",
      "text": "Then he lay down under the tree and he slept. Suddenly, an angel came and touched him. The angel said, ‘Get up and eat something. ’"
    },
    {
      "verse": "6",
      "text": "When Elijah looked, he saw some bread near his head. Someone had baked it on a fire. There was also a jar of water. So he ate the bread and he drank the water. Then he lay down again to sleep."
    },
    {
      "verse": "7",
      "text": "The angel of the Lord came back a second time. He touched Elijah and he said, ‘Get up and eat more food. Then you will be strong enough to go on a long journey. ’"
    },
    {
      "verse": "8",
      "text": "So Elijah got up. He ate the food and he drank the water. The meal made him strong enough to travel for 40 days and 40 nights. He travelled to Sinai, the mountain of God."
    },
    {
      "verse": "9",
      "text": "Elijah went into a cave on Sinai mountain and he stayed there all night. Suddenly, the Lord spoke to Elijah. He asked Elijah, ‘Elijah, why have you come here? ’"
    },
    {
      "verse": "10",
      "text": "Elijah replied, ‘The Israelites have turned away from the covenant that you made with them. They have destroyed your altars. They have killed your prophets with swords. But I have always served the Lord God Almighty faithfully. Now I am the only prophet that is still alive and they are trying to kill me too. ’"
    },
    {
      "verse": "11",
      "text": "The Lord said, ‘Go out from the cave and stand on the mountain, in front of me. I, the Lord, will pass in front of you. ’Then a very strong wind broke the mountain apart. It broke the rocks into pieces as the Lord came near. But the Lord was not in the wind. After the wind, there was an earthquake. But the Lord was not in the earthquake."
    },
    {
      "verse": "12",
      "text": "After the earthquake, there was a fire. But the Lord was not in the fire. After the fire, there was a very quiet voice."
    },
    {
      "verse": "13",
      "text": "When Elijah heard that, he covered his face with his robe. He went out and he stood at the entrance of the cave. Then a voice said to him, ‘Elijah, why have you come here? ’"
    },
    {
      "verse": "14",
      "text": "Elijah said, ‘The Israelites have turned away from the covenant that you made with them. They have destroyed your altars. They have killed your prophets with swords. But I have always served the Lord God Almighty faithfully. Now I am the only prophet that is still alive and they are trying to kill me too. ’"
    },
    {
      "verse": "15",
      "text": "The Lord said to Elijah, ‘Go back again along the way that you came. Go to the desert which is near Damascus. When you arrive there, anoint Hazael to make him king of Syria."
    },
    {
      "verse": "16",
      "text": "You must also anoint Nimshi's grandson Jehu to make him king of Israel. Then anoint Shapat's son Elisha from Abel Meholah to be my prophet after you."
    },
    {
      "verse": "17",
      "text": "Jehu's army will kill anyone that Hazael's army does not kill. Then Elisha will kill anyone who escapes from Jehu."
    },
    {
      "verse": "18",
      "text": "But remember this: I still have 7, 000 people in Israel who have not worshipped Baal. They have not kissed his idols. ’"
    },
    {
      "verse": "19",
      "text": "Elijah went away from Sinai. He found Shaphat's son, Elisha. Elisha was ploughing a field with 12 pairs of oxen. Elisha himself was using the 12th pair of oxen to plough. Elijah went to Elisha and he threw his robe over him. Elisha said, ‘Let me go home first to kiss my father and my mother and say “goodbye”. Then I will come with you. ’ Elijah replied, ‘Yes, go back home. But do not forget about what I have done to you. ’"
    },
    {
      "verse": "20",
      "text": "So Elisha left his oxen in the field and he ran after Elijah. Elisha said, ‘Let me go home first to kiss my father and my mother and say “goodbye”. Then I will come with you. ’ Elijah replied, ‘Yes, go back home. But do not forget about what I have done to you. ’"
    },
    {
      "verse": "21",
      "text": "So Elisha went back to his field. He took his pair of oxen and he killed them as a sacrifice. He burned wood from the plough to cook the meat. He gave the meat to the people who were there and they ate it. Then he left home to go with Elijah and to become his helper."
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "Ben-Hadad was the king of Syria. He got all his army together. 32 other kings with their horses and chariots joined with him. He went to attack the city of Samaria. He put his army all around it and then he attacked it."
    },
    {
      "verse": "2",
      "text": "He sent men to take a message to Ahab, the king of Israel, who was in the city."
    },
    {
      "verse": "3",
      "text": "The message said: ‘This message is from King Ben-Hadad. He says, “Your silver and your gold now belong to me. Your best wives and your strongest children will also be mine. ” ’"
    },
    {
      "verse": "4",
      "text": "The king of Israel replied, ‘My master, the king, I agree with what you have said. I, and everything that I have, belongs to you. ’"
    },
    {
      "verse": "5",
      "text": "Ben-Hadad's men then took another message to Ahab. They said to him, ‘This is what Ben-Hadad says: “I already told you that you must give me your silver, your gold, your wives and your children."
    },
    {
      "verse": "6",
      "text": "At this time tomorrow, I will send my officers to look for things in your palace. They will also look in the houses of your officers. They will take away everything that is valuable. ” ’"
    },
    {
      "verse": "7",
      "text": "Then King Ahab told all the leaders of Israel to come to him. He said to them, ‘See what this man is doing! He wants to cause trouble! He asked me to give him my wives, my children, my silver and my gold. And I did not refuse to do it. ’"
    },
    {
      "verse": "8",
      "text": "The leaders and the people answered King Ahab, ‘Do not listen to that man. Do not agree to do what he is asking for. ’"
    },
    {
      "verse": "9",
      "text": "So King Ahab said to the men who brought the messages from King Ben-Hadad, ‘Say this to my master, the king of Syria: “I agree to do everything that you asked for the first time. But I will not let you take the other things that you want. ” ’So the men took Ahab's answer back to Ben-Hadad."
    },
    {
      "verse": "10",
      "text": "Then Ben-Hadad sent men with another message to Ahab. He said, ‘I promise that my soldiers will completely destroy Samaria! There will be nothing left! There will not even be enough dirt to fill the hands of each of my soldiers. I pray that the gods will punish me very much if that does not happen! ’"
    },
    {
      "verse": "11",
      "text": "The king of Israel replied, ‘Tell King Ben-Hadad, “Do not boast when you are preparing for a battle. Wait until the battle has finished and you know that you have won. ” ’"
    },
    {
      "verse": "12",
      "text": "When Ben-Hadad received Ahab's message, he and the other kings were drinking wine in their tents. Ben-Hadad told his officers, ‘Prepare to attack! ’ So they prepared to attack the city of Samaria."
    },
    {
      "verse": "13",
      "text": "Then a prophet came to Ahab, the king of Israel. He said, ‘The Lord says this to you: “Look at Ben-Hadad's great army! Today I will put them under your power. Then you will know that I am the Lord. ” ’"
    },
    {
      "verse": "14",
      "text": "King Ahab asked, ‘But who will fight this battle? ’ The prophet answered, ‘This is what the Lord says: “The young soldiers who are under the authority of each region's officer will do it. ” ’ Then Ahab asked, ‘Who will lead them into the battle? ’ The prophet answered, ‘You will do that. ’"
    },
    {
      "verse": "15",
      "text": "So Ahab brought together the young soldiers of each region. There were 232 of them. Then he brought together the whole Israelite army. There were 7, 000 of them."
    },
    {
      "verse": "16",
      "text": "The soldiers marched out of Samaria at noon. Ben-Hadad and the 32 other kings were still drinking in their tents. They were drunk."
    },
    {
      "verse": "17",
      "text": "The young soldiers of each region's officers went in front of the Israelite army. Ben-Hadad had sent men out to watch the Israelites. They told him, ‘Men are marching out from Samaria. ’"
    },
    {
      "verse": "18",
      "text": "Ben-Hadad commanded, ‘If they are coming to make peace with me, catch them alive. If they have come out to fight a battle, do the same thing. ’"
    },
    {
      "verse": "19",
      "text": "The Israelites marched out of the city as the young soldiers led the whole army."
    },
    {
      "verse": "20",
      "text": "Each of the Israelite soldiers killed one of the enemy's soldiers. Then the Syrian soldiers ran away as the Israelites chased them. Ben-Hadad, the king of Syria, rode away on his horse and he escaped. Some of his soldiers who rode on horses went with him."
    },
    {
      "verse": "21",
      "text": "Then the king of Israel came out of the city and he attacked the Syrian horses and chariots. He destroyed them and he won the battle against the Syrian army."
    },
    {
      "verse": "22",
      "text": "After the battle, the prophet came to the king of Israel again. He said to him, ‘Now go and make your army strong. Decide what you need to do. Do this, because next spring the king of Syria will attack you again. ’"
    },
    {
      "verse": "23",
      "text": "At the same time, some of the king of Syria's officers said to him, ‘The gods of the Israelites are gods who live in the hills. That is why the Israelites were too strong for us. But if we fight them on the lower ground, we will surely be stronger than them."
    },
    {
      "verse": "24",
      "text": "You should do this: Remove all the other kings. Put your own officers to lead the army instead."
    },
    {
      "verse": "25",
      "text": "Bring together enough men to make an army as big as the one that lost the battle. There must be the same number of horses and chariots. Then we will fight the Israelites on the low ground. If we do that, we will surely be stronger than them. ’ Ben-Hadad agreed with them. He did what they had suggested."
    },
    {
      "verse": "26",
      "text": "The next spring, King Ben-Hadad brought together the men for his army. The Syrian army marched to Aphek to fight against the Israelites."
    },
    {
      "verse": "27",
      "text": "King Ahab brought together the Israelite army and he gave them food and weapons. Then they marched out to fight against the Syrian army. The Israelite soldiers stood there in two groups. They looked like two small groups of goats! The Syrian soldiers were so many that they covered all the land around."
    },
    {
      "verse": "28",
      "text": "God's servant, the prophet, went to the king of Israel. He said to the king, ‘This is what the Lord says: “The Syrians think that the Lord is a god who lives only in the hills. They think that he has no authority in the valleys. But I will give you power over all their great army. Then you will know that I am the Lord” ’"
    },
    {
      "verse": "29",
      "text": "For seven days, the two armies stayed in their camps where they could see each other. On the seventh day, the battle started. The Israelites killed 100, 000 Syrian soldiers on that one day."
    },
    {
      "verse": "30",
      "text": "The other soldiers ran back to Aphek. When they went into the city, the city wall fell on 27, 000 of them. King Ben-Hadad also ran into the city. He hid in a room at the back of a house."
    },
    {
      "verse": "31",
      "text": "Some of Ben-Hadad's officers said to him, ‘We have heard that the family of kings who rule Israel are kind men. We should show that we are sorry. We will tie sackcloth around our bodies. We will put ropes around our heads. Then maybe King Ahab will let you live. ’"
    },
    {
      "verse": "32",
      "text": "So they tied sackcloth around themselves. They put ropes around their heads. They went to the king of Israel and they said, ‘Your servant Ben-Hadad says, “Please let me live. ” ’ King Ahab asked, ‘Is Ben-Hadad still alive? He is like my own brother. ’"
    },
    {
      "verse": "33",
      "text": "When Ben-Hadad's men heard this, they thought that it was a friendly answer. So they quickly agreed, ‘Yes! Ben-Hadad is like your own brother. ’ King Ahab said, ‘Go and fetch him. ’So Ben-Hadad came out from Aphek city. Ahab took him up into his chariot."
    },
    {
      "verse": "34",
      "text": "Ben-Hadad said, ‘I will give back to you the cities that my father took from your father. Your traders can have their own markets in Damascus, as my father had in Samaria. ’ Ahab answered, ‘If you do that, I will agree to let you go as a free man. ’ So King Ahab made an agreement with King Ben-Hadad. Then he let him go home."
    },
    {
      "verse": "35",
      "text": "At this time, the Lord gave a message to a prophet who belonged to a group of prophets. He told the prophet to say to one of his friends, ‘Hit me with your stick. ’ But his friend refused to do it."
    },
    {
      "verse": "36",
      "text": "So the prophet said to him, ‘You have not obeyed the Lord's command. Because of that, a lion will kill you as soon as you leave here. ’ After the man left the prophet, a lion attacked him and it killed him."
    },
    {
      "verse": "37",
      "text": "Then the prophet found another man. He said to him, ‘Please hit me! ’ So the man hit him. He hurt the prophet very much."
    },
    {
      "verse": "38",
      "text": "Then the prophet went and he stood beside the road. He was waiting for king Ahab to come. He tied a cloth over his eyes so that the king would not recognize him."
    },
    {
      "verse": "39",
      "text": "When the king came along the road, the prophet shouted to him, ‘Please sir, I went to fight in the middle of the battle. Then someone brought an enemy soldier to me as a prisoner. He said to me, “Keep this prisoner safe. If he escapes for any reason, you will die! To save your life, you will have to pay 3, 000 silver coins. ” King Ahab replied, ‘What you have just said shows that you deserve your punishment. ’"
    },
    {
      "verse": "40",
      "text": "But I had other things to do, sir. While I was doing them, the prisoner escaped. ’King Ahab replied, ‘What you have just said shows that you deserve your punishment. ’"
    },
    {
      "verse": "41",
      "text": "Then the prophet quickly took away the cloth that covered his eyes. The king recognized that the man was one of the prophets."
    },
    {
      "verse": "42",
      "text": "The prophet said to the king, ‘This is what the Lord says to you: “I decided that a man should die, but you have let him go free. So you must pay for his life with your life. Your people will receive the trouble that his people deserved. ” ’"
    },
    {
      "verse": "43",
      "text": "So King Ahab of Israel went home to his palace in Samaria. He was angry and upset."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "Naboth lived in a town called Jezreel. He had a vineyard in Jezreel, near to the palace of Ahab, the king of Samaria."
    },
    {
      "verse": "2",
      "text": "King Ahab said to Naboth, ‘Give me your vineyard. I want to grow vegetables in it, because it is near to my palace. I will give you a better vineyard instead of that one. Or, if you want, I will pay you its value in money. ’"
    },
    {
      "verse": "3",
      "text": "Naboth replied to Ahab, ‘The Lord will never allow that to happen! It belongs to me because it belonged to my ancestors. ’"
    },
    {
      "verse": "4",
      "text": "So Ahab went home to his palace. He was angry and upset because of what Naboth had said. He had said, ‘I will not sell you my vineyard that belonged to my ancestors. ’ Ahab lay on his bed. He covered his face and he would not eat any food."
    },
    {
      "verse": "5",
      "text": "Ahab's wife, Jezebel, came in to his room. She asked him, ‘Why are you so upset? Why do you refuse to eat anything? ’"
    },
    {
      "verse": "6",
      "text": "Ahab answered her, ‘It is because of Naboth, the man from Jezreel. I said to him, “Sell your vineyard to me. Or, if you want, I will give you another vineyard instead of that one. ” But he said, “I will not give you my vineyard. ” ’"
    },
    {
      "verse": "7",
      "text": "Jezebel said, ‘You are the king who rules Israel! Now get up from your bed and eat something. Do not be upset! I will get Naboth's vineyard for you. ’"
    },
    {
      "verse": "8",
      "text": "Jezebel wrote some letters as if King Ahab had written them. She used his special seal as a mark on them. Then she sent them to the older leaders and important men who lived in Jezreel with Naboth."
    },
    {
      "verse": "9",
      "text": "This is what she wrote in those letters: ‘Choose a day for everyone to fast. Give Naboth a seat where the people can see him."
    },
    {
      "verse": "10",
      "text": "Put two wicked men in seats near him. Tell them to accuse Naboth that he has insulted God and the king. Then take him out. Throw stones at him until he is dead. ’"
    },
    {
      "verse": "11",
      "text": "So the leaders and the important men who lived in Naboth's city, obeyed Jezebel. They did what she commanded them to do in the letters that she sent to them."
    },
    {
      "verse": "12",
      "text": "They chose a day for the people to fast. They put Naboth in a seat where the people could see him."
    },
    {
      "verse": "13",
      "text": "Then two wicked men came and they sat near to him. They accused Naboth so that the people could all hear them. They said, ‘Naboth has insulted God and the king. ’ So the people took him outside the city. They threw stones at him until he was dead."
    },
    {
      "verse": "14",
      "text": "Then the city's leaders sent a message to Jezebel. They told her, ‘The people have killed Naboth with stones. ’"
    },
    {
      "verse": "15",
      "text": "When Jezebel heard that Naboth was dead, she said to Ahab, ‘Get up from your bed! Go to Jezreel and take Naboth's vineyard for yourself. He refused to sell it to you when he was alive. But now he is dead. ’"
    },
    {
      "verse": "16",
      "text": "When Ahab knew that Naboth was dead, he got up from his bed. He went to Naboth's vineyard to take it for himself."
    },
    {
      "verse": "17",
      "text": "After this, the Lord gave a message to Elijah, the prophet from Tishbe."
    },
    {
      "verse": "18",
      "text": "He said to Elijah, ‘Go now to meet King Ahab of Israel who rules in Samaria. He is at Naboth's vineyard to take it as his own vineyard."
    },
    {
      "verse": "19",
      "text": "Say to Ahab, “This is what the Lord says to you: You have murdered a man. You have taken the dead man's field for yourself. ” Then say to him, “This is what the Lord says: In the place where the dogs drank Naboth's blood from the ground, dogs will drink your blood. Yes, they will drink your blood there too! ” ’"
    },
    {
      "verse": "20",
      "text": "When Elijah met Ahab, Ahab said to him, ‘So, my enemy, now you have found me! ’ Elijah answered, ‘Yes, I have found you to warn you! You have decided to do things that the Lord says are evil."
    },
    {
      "verse": "21",
      "text": "So the Lord says, “Now I will bring great trouble on you. I will destroy you and your family. I will kill every male among Ahab's descendants in Israel, whoever they are."
    },
    {
      "verse": "22",
      "text": "I will destroy your family as I did to the family of Nebat's son Jeroboam and the family of Ahijah's son Baasha. I will do this because you have made me angry and you have caused Israel's people to do wrong things. ”"
    },
    {
      "verse": "23",
      "text": "The Lord says this about Jezebel: “Dogs will eat Jezebel's dead body beside the city wall of Jezreel. ”"
    },
    {
      "verse": "24",
      "text": "If people of Ahab's family die in the city, dogs will eat their bodies. If they die in the country, vultures will eat them. ’"
    },
    {
      "verse": "25",
      "text": "Ahab had decided to do everything that the Lord said was evil. He was more wicked than any other person who had lived. His wife Jezebel helped him to be like that."
    },
    {
      "verse": "26",
      "text": "Ahab was so wicked that he worshipped useless idols, as the Amorites did. The Lord had chased those people out of the land so that the Israelites could live there."
    },
    {
      "verse": "27",
      "text": "When Ahab heard Elijah's message, he tore his clothes into pieces. He dressed himself in sackcloth and he did not eat any food. He even wore sackcloth when he slept on his bed. He walked slowly with a sad face."
    },
    {
      "verse": "28",
      "text": "Then the Lord said to Elijah,"
    },
    {
      "verse": "29",
      "text": "‘You have surely seen that Ahab now respects me. Because he has become humble, I will not destroy his family while he is alive. I will wait until his son rules as king. Then I will bring great trouble on Ahab's descendants. ’"
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "There was no war between Syria and Israel for three years."
    },
    {
      "verse": "2",
      "text": "But after three years, Jehoshaphat, the king of Judah, went to visit the king of Israel."
    },
    {
      "verse": "3",
      "text": "The king of Israel said to his leaders, ‘You know that Ramoth Gilead belongs to us. But we are not doing anything to take it back from the king of Syria. ’"
    },
    {
      "verse": "4",
      "text": "So the king of Israel asked Jehoshaphat, ‘Will you go with me to attack Ramoth Gilead? ’ Jehoshaphat said to the king of Israel, ‘Yes, we should work together! Use my soldiers and my horses as if they belonged to you. ’"
    },
    {
      "verse": "5",
      "text": "Then Jehoshaphat said to the king of Israel, ‘Before we go to fight, we must ask the Lord what we should do. ’"
    },
    {
      "verse": "6",
      "text": "prophets. He asked them, ‘Should I attack Ramoth Gilead, or not? ’ They answered, ‘Yes, go and attack it, because the Lord God will give it to you, our king. ’"
    },
    {
      "verse": "7",
      "text": "But Jehoshaphat then asked, ‘Is there any other prophet of the Lord that we could ask? ’"
    },
    {
      "verse": "8",
      "text": "The king of Israel said to Jehoshaphat, ‘There is still one man. We could ask him what the Lord wants us to do. But I do not like him, because he never says that anything good will happen to me. He only says that I will have trouble. He is Imlah's son, Micaiah. ’ Jehoshaphat said, ‘The king should not talk like that. ’"
    },
    {
      "verse": "9",
      "text": "So the king of Israel said to one of his officers, ‘Bring Imlah's son Micaiah here quickly. ’"
    },
    {
      "verse": "10",
      "text": "The king of Israel and Jehoshaphat, the king of Judah, were each sitting on their thrones. They were wearing their royal clothes. They sat near the threshing floor at Samaria's city gate. All the prophets stood in front of them and they were speaking messages from God."
    },
    {
      "verse": "11",
      "text": "Kenaanah's son Zedekiah had used iron to make sharp points like a bull's horns. He said, ‘This is what the Lord says: “With these sharp horns you will attack Syria's army. You will destroy them all. ” ’"
    },
    {
      "verse": "12",
      "text": "All the other prophets were speaking the same message. They said, ‘Attack Ramoth Gilead. You will win the fight. The Lord will give the city to you, our king. ’"
    },
    {
      "verse": "13",
      "text": "The man who had gone to fetch Micaiah said to him, ‘All the other prophets are saying the same thing. They say that the king will win the fight. So you must agree with what they are saying. Promise that something good will happen. ’"
    },
    {
      "verse": "14",
      "text": "But Micaiah said, ‘I can only speak what the Lord tells me to say. As surely as the Lord lives, that is what I must do. ’"
    },
    {
      "verse": "15",
      "text": "When Micaiah arrived, the king asked him, ‘Micaiah, should we attack Ramoth Gilead or not? ’ Micaiah answered, ‘Yes, attack it. You will surely win the fight. The Lord will give it to you, our king. ’"
    },
    {
      "verse": "16",
      "text": "Then King Ahab said to Micaiah, ‘I have already told you many times to tell me only what is true! You must promise to do this in the name of the Lord! ’"
    },
    {
      "verse": "17",
      "text": "Then Micaiah said, ‘I saw the whole army of Israel and they were walking about on the hills without any leader. They were like sheep with no shepherd as their guide. The Lord told me, “These people have no master. They should go home quietly and they should not fight. ” ’"
    },
    {
      "verse": "18",
      "text": "The king of Israel said to King Jehoshaphat, ‘I told you what he would say! He never says that anything good will happen to me. He only says that I will have trouble. ’"
    },
    {
      "verse": "19",
      "text": "Then Micaiah said, ‘So now listen to the Lord's message! I saw the Lord as he was sitting on his throne. The great crowd of his angels in heaven were standing around him, on his right side and on his left side."
    },
    {
      "verse": "20",
      "text": "The Lord asked, “Who will go and deceive King Ahab so that he attacks Ramoth Gilead and he dies there? ” Many of the angels suggested different things."
    },
    {
      "verse": "21",
      "text": "Then a spirit came and stood in front of the Lord. The spirit said, “I will deceive Ahab. ” The Lord asked him, “How will you do it? ”"
    },
    {
      "verse": "22",
      "text": "The spirit said, “I will give a message to all Ahab's prophets. I will cause them to speak lies. ” The Lord said, “Go and deceive King Ahab, as you have said. He will do what you say. ”"
    },
    {
      "verse": "23",
      "text": "So you see what has happened. The Lord has sent a spirit to all these prophets who serve you. This spirit has caused them to speak lies. The Lord has decided that terrible trouble will come on you. ’"
    },
    {
      "verse": "24",
      "text": "Then Kenaanah's son Zedekiah went to Micaiah. He hit Micaiah on his face. He asked Micaiah, ‘Do you say that the Lord's spirit has gone away from me and has spoken to you instead? How did he do that? ’"
    },
    {
      "verse": "25",
      "text": "Micaiah answered him, ‘One day, you will know which of us has spoken the truth. That will be the day that you go to hide in a room at the back of a house. ’"
    },
    {
      "verse": "26",
      "text": "Then the king of Israel said to his men, ‘Take hold of Micaiah. Take him back to Amon, the city officer, and to Joash, the king's son."
    },
    {
      "verse": "27",
      "text": "Say to them, “The king commands you to put this man in prison. Feed him with only a little bread and water until I return safely from the battle. ” ’"
    },
    {
      "verse": "28",
      "text": "Micaiah said, ‘If you do return safely, it will show that I have not spoken the Lord's message. ’ Then he said to all the people who were there, ‘Remember what I have said to King Ahab! ’"
    },
    {
      "verse": "29",
      "text": "So King Ahab of Israel and King Jehoshaphat of Judah went to attack Ramoth Gilead."
    },
    {
      "verse": "30",
      "text": "King Ahab said to Jehoshaphat, ‘When we go into the battle, I will wear ordinary clothes. People will not recognize me as the king. But you should wear your royal clothes. ’ So the king of Israel went into the battle as if he was an ordinary soldier."
    },
    {
      "verse": "31",
      "text": "chariot officers, ‘Only fight the king of Israel. Do not fight against anyone else, whoever they are. ’"
    },
    {
      "verse": "32",
      "text": "The chariot officers saw King Jehoshaphat in his royal clothes. They thought, ‘Surely that man is the king of Israel. ’ So they turned towards him to attack him. When King Jehoshaphat saw them, he shouted out."
    },
    {
      "verse": "33",
      "text": "Then the chariot officers realized that he was not the king of Israel. So they did not chase him any more."
    },
    {
      "verse": "34",
      "text": "Then a Syrian soldier shot an arrow into the air. He did not try to shoot at anyone, but the arrow hit the king of Israel. The arrow went through a space in the king's armour. The king commanded the man who drove his chariot, ‘Turn the chariot around. Take me away from the battle. An arrow has hit me. ’"
    },
    {
      "verse": "35",
      "text": "The soldiers fought the battle all day. While they were fighting, King Ahab sat in his chariot where he could see the Syrian soldiers. His blood poured out and it covered the floor of the chariot. When evening came, Ahab died."
    },
    {
      "verse": "36",
      "text": "At sunset, the Israelite soldiers shouted to each other, ‘Leave the battle! Every man should return home to the city where he lives. ’"
    },
    {
      "verse": "37",
      "text": "So the king of Israel died. They took him to Samaria. They buried him there."
    },
    {
      "verse": "38",
      "text": "They washed his blood from the chariot at the pool of water in Samaria. It was the place where the prostitutes washed themselves. The dogs drank Ahab's blood there. The Lord had said that this would happen."
    },
    {
      "verse": "39",
      "text": "The other things that happened while Ahab was king are written in a book. The book is called ‘The history of Israel's kings’. It tells about all the great things that he did. It also tells about the beautiful palace and the cities that he built."
    },
    {
      "verse": "40",
      "text": "Ahab died and they buried him beside his ancestors. His son Ahaziah became king after him."
    },
    {
      "verse": "41",
      "text": "In the fourth year that Ahab ruled Israel as king, Asa's son Jehoshaphat became the king of Judah."
    },
    {
      "verse": "42",
      "text": "years old when he became king. He ruled in Jerusalem for 25 years. His mother's name was Azubah. She was the daughter of Shilhi."
    },
    {
      "verse": "43",
      "text": "Jehoshaphat lived in the good way that his father Asa had lived. He only did things that the Lord says are right. But he did not remove all the altars that were on the hills. People continued to offer sacrifices on those altars and they continued to burn incense there."
    },
    {
      "verse": "44",
      "text": "Jehoshaphat agreed not to fight against the king of Israel."
    },
    {
      "verse": "45",
      "text": "The other things that happened while Jehoshaphat was king are written in a book. The book is called ‘The history of Judah's kings’. It tells about the great things that he did and the battles that he fought."
    },
    {
      "verse": "46",
      "text": "He also removed the male prostitutes who lived near the special altars. His father Asa had removed many of them when he ruled as king. Jehoshaphat removed those who were still there."
    },
    {
      "verse": "47",
      "text": "At this time there was no king who ruled Edom. Their ruler was an officer that King Jehoshaphat had chosen."
    },
    {
      "verse": "48",
      "text": "Jehoshaphat built some big ships to bring back gold from Ophir. But they never left Ezion-Geber because a storm destroyed them. So they never travelled anywhere."
    },
    {
      "verse": "49",
      "text": "At that time, Ahab's son Ahaziah said to Jehoshaphat, ‘Let my sailors join with your sailors on the ships. ’ But Jehoshaphat refused."
    },
    {
      "verse": "50",
      "text": "Jehoshaphat died and they buried him beside his ancestors in the City of David, his ancestor. Jehoshaphat's son Jehoram became king after him."
    },
    {
      "verse": "51",
      "text": "years, Ahab's son Ahaziah became the king of Israel in Samaria. Ahaziah ruled Israel as king for two years."
    },
    {
      "verse": "52",
      "text": "He did things that the Lord said were evil. He lived in the way that his father and mother had lived. He caused the Israelites to do bad things, as Nebat's son Jeroboam had done."
    },
    {
      "verse": "53",
      "text": "Ahaziah served Baal as his god and he worshipped him. He made the Lord, Israel's God, very angry, as his father had also done."
    }
  ]
};