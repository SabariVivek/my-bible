module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "There was a man whose name was Elkanah. He lived in a town called Ramah. This town was in the hill country where Ephraim's tribe lived. Elkanah was the son of Jeroham. Jeroham was the son of Elihu. Elihu was the son of Tohu. Tohu was the son of Zuph. Zuph belonged to the tribe of Ephraim."
    },
    {
      "verse": "2",
      "text": "Elkanah had two wives. One wife was called Hannah and the other wife was called Peninnah. Peninnah had children but Hannah did not have any children."
    },
    {
      "verse": "3",
      "text": "Every year, Elkanah left his home in Ramah to go to the town of Shiloh. He went there to worship the Lord Almighty and to offer sacrifices to him. Hophni and Phinehas served the Lord at Shiloh as his priests. Eli was their father."
    },
    {
      "verse": "4",
      "text": "Every year, when Elkanah offered his sacrifices to God, he gave some of the meat to his wife Peninnah and to her sons and daughters."
    },
    {
      "verse": "5",
      "text": "Because Elkanah loved Hannah very much, he always gave twice as much meat to her. But the Lord had not let Hannah give birth to any children."
    },
    {
      "verse": "6",
      "text": "Peninnah was not kind to Hannah and she made Hannah very upset. She did this because the Lord had not let Hannah give birth to any children."
    },
    {
      "verse": "7",
      "text": "This happened every year when they went to the Lord's house in Shiloh. Peninnah would cause Hannah to be upset. Then Hannah would weep. She would refuse to eat anything."
    },
    {
      "verse": "8",
      "text": "Hannah's husband, Elkanah, said to her, ‘Why should you weep and refuse to eat? Do not be so sad. I love you, and that is better than ten sons. ’"
    },
    {
      "verse": "9",
      "text": "One day they had offered sacrifices at Shiloh. They had finished eating and drinking. Hannah stood up to pray to God. Eli the priest was sitting on his chair beside the door of the Lord's temple."
    },
    {
      "verse": "10",
      "text": "Hannah was very upset as she prayed to the Lord. She could not stop weeping."
    },
    {
      "verse": "11",
      "text": "She made a promise to God. She prayed, ‘Lord Almighty, you can see how sad I am. Please be kind to me, your servant. Remember me and do not forget me. Please give a son to me, your servant. If you do that, I will give him to serve you for all of his life. Nobody will ever cut his hair. ’"
    },
    {
      "verse": "12",
      "text": "Hannah continued to pray to the Lord. Eli watched her mouth while it moved."
    },
    {
      "verse": "13",
      "text": "Hannah was praying quietly inside herself. Her lips moved but Eli could not hear her voice. So he thought that she was drunk."
    },
    {
      "verse": "14",
      "text": "He said to her, ‘Are you always drunk like that? Throw away your wine. ’"
    },
    {
      "verse": "15",
      "text": "Hannah replied, ‘No, sir, I have not drunk any wine or strong drink. I have much trouble deep inside myself. I have told the Lord about all my problems."
    },
    {
      "verse": "16",
      "text": "Please sir, do not think that I am a bad woman. I am praying like this because I am very sad and upset. ’"
    },
    {
      "verse": "17",
      "text": "Eli said to Hannah, ‘Go and let your mind have peace. I pray that Israel's God will give you what you have asked him for. ’"
    },
    {
      "verse": "18",
      "text": "Hannah said to him, ‘I will try to do what pleases you, sir. ’Then Hannah went away and she ate some food. Her face was not sad now. Then Hannah went away and she ate some food. Her face was not sad now."
    },
    {
      "verse": "19",
      "text": "Elkanah and his family got up early the next morning and they worshipped the Lord. Then they went back to their home in Ramah. Elkanah had sex with his wife Hannah. The Lord remembered what she had asked him for."
    },
    {
      "verse": "20",
      "text": "Hannah became pregnant. Later, she gave birth to a son. She gave him the name ‘Samuel’. She said, ‘His name is Samuel because I asked the Lord for him. ’"
    },
    {
      "verse": "21",
      "text": "Next year, Elkanah went to Shiloh to offer sacrifices to the Lord, as he had promised to do. His family went with him."
    },
    {
      "verse": "22",
      "text": "But Hannah did not go as well. She said to her husband, ‘I will not go until the boy is older. When he can eat proper food, I will take him to Shiloh to give him to the Lord. Then he will live there for all his life. ’"
    },
    {
      "verse": "23",
      "text": "Elkanah said to Hannah, ‘You must do what seems right to you. Stay here at home until the boy begins to eat proper food. May the Lord help you, as he has promised. ’So Hannah stayed at home with her son while he continued to drink milk from her breasts. So Hannah stayed at home with her son while he continued to drink milk from her breasts."
    },
    {
      "verse": "24",
      "text": "When Samuel started to eat proper food, Hannah took him to Shiloh. She took him to the Lord's house there when he was still a young boy. She took with her a bull that was three years old. She also took a big bag of flour and a leather bag full of wine. Then Elkanah's family worshipped the Lord there."
    },
    {
      "verse": "25",
      "text": "They killed the bull for the sacrifice. Then Hannah took Samuel to Eli."
    },
    {
      "verse": "26",
      "text": "Hannah said to Eli, ‘Please believe me sir. I am the woman who stood here before. You saw me when I was praying to the Lord."
    },
    {
      "verse": "27",
      "text": "I prayed that the Lord would give me a son and he answered my prayer."
    },
    {
      "verse": "28",
      "text": "Now I will give this child to serve the Lord. He will be the Lord's servant for his whole life. ’Then Elkanah's family worshipped the Lord there."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Hannah prayed and she said, ‘I am very happy when I think about what the Lord has done. The Lord has made me very strong. I can laugh at my enemies because you, Lord, have saved me. That makes me very happy. ‘I am very happy when I think about what the Lord has done. The Lord has made me very strong. I can laugh at my enemies because you, Lord, have saved me. That makes me very happy."
    },
    {
      "verse": "2",
      "text": "Nobody else is holy like the Lord. There is no other God except you, our God. You are the only Rock where we can be safe. There is no other God except you, our God. You are the only Rock where we can be safe."
    },
    {
      "verse": "3",
      "text": "Do not boast or speak proud words! The Lord is a God who knows everything. He judges everything that people do. The Lord is a God who knows everything. He judges everything that people do."
    },
    {
      "verse": "4",
      "text": "The weapons of brave soldiers may break. But weak people who fall become strong again. But weak people who fall become strong again."
    },
    {
      "verse": "5",
      "text": "People who had plenty of food to eat have to work for it now. But the people who were hungry have enough food now. Women who could not have any children have now given birth to seven children. But those who had many children are now alone. But the people who were hungry have enough food now. Women who could not have any children have now given birth to seven children. But those who had many children are now alone."
    },
    {
      "verse": "6",
      "text": "The Lord gives both life and death. He sends some people to their graves, and he raises other people up. He sends some people to their graves, and he raises other people up."
    },
    {
      "verse": "7",
      "text": "The Lord makes some people poorand he makes other people rich. He causes some people to be importantand he puts other people low down. and he makes other people rich. He causes some people to be important and he puts other people low down."
    },
    {
      "verse": "8",
      "text": "He raises up weak people from the ground. He lifts poor people up out of the dirt. He makes them become friends of princes. He puts them in places of honour. The deep places of the earth belong to the Lord. He built the world on a strong foundation. He lifts poor people up out of the dirt. He makes them become friends of princes. He puts them in places of honour. The deep places of the earth belong to the Lord. He built the world on a strong foundation."
    },
    {
      "verse": "9",
      "text": "He takes care of his faithful people. But he puts wicked people in a dark place where they can do nothing. It is not a person's own strength that makes him great. But he puts wicked people in a dark place where they can do nothing. It is not a person's own strength that makes him great."
    },
    {
      "verse": "10",
      "text": "The Lord will destroy his enemies. He will shout against them from heaven like loud thunder. The Lord will judge everyone on earth. He will make his king strong. He will give power to the king that he has chosen to rule. ’ He will shout against them from heaven like loud thunder. The Lord will judge everyone on earth. He will make his king strong. He will give power to the king that he has chosen to rule. ’"
    },
    {
      "verse": "11",
      "text": "Then Elkanah went back to his home at Ramah with his family. But the young boy, Samuel, stayed in Shiloh. He served the Lord there, while Eli the priest took care of him."
    },
    {
      "verse": "12",
      "text": "Eli's sons were wicked men. They did not respect the Lord."
    },
    {
      "verse": "13",
      "text": "They did not do what the priests should do. People brought sacrifices to offer to the Lord at Shiloh. When the meat was still boiling in a pot, a servant of the priest would come. He would bring a fork that had three points."
    },
    {
      "verse": "14",
      "text": "He then pushed the fork into the pot. The priest took for himself any meat that came out on the fork. The priests did that to all the Israelites when they came to Shiloh to offer sacrifices."
    },
    {
      "verse": "15",
      "text": "Their servant would even come before the fat was removed from the meat to be burned as a sacrifice. He would say to the person who had brought the sacrifice, ‘Give me some of the meat for the priest to bake. He will not accept meat that has already boiled. He will only accept meat that is fresh. ’"
    },
    {
      "verse": "16",
      "text": "Sometimes, the person said, ‘We must burn the fat first. Then you can take any meat that you want. ’ The servant would reply, ‘No. Give the meat to me now, or I will take it from you anyway. ’"
    },
    {
      "verse": "17",
      "text": "The Lord knew what Eli's sons were doing. They did not respect the sacrifices that people were offering to the Lord. The Lord saw that their sin was very bad."
    },
    {
      "verse": "18",
      "text": "But Samuel served the Lord faithfully, as a young boy. He wore a linen ephod."
    },
    {
      "verse": "19",
      "text": "Every year, Samuel's mother made a little coat for him. She took it to him when she went to Shiloh. She and her husband went there every year to offer their sacrifice to God."
    },
    {
      "verse": "20",
      "text": "Each year, Eli blessed Elkanah and his wife. He said, ‘I pray that the Lord will give you more children to take the place of Samuel. Hannah has given her son to serve the Lord, so may she give birth to other children too. ’Then they would return to their own home."
    },
    {
      "verse": "21",
      "text": "The Lord blessed Hannah. She gave birth to three more sons and two daughters. The boy Samuel continued to grow as he served at the Lord's house in Shiloh."
    },
    {
      "verse": "22",
      "text": "Eli was very old now. He heard about everything that his sons were doing to all the Israelites. He knew that his sons had sex with some of the women helpers. Those women worked at the door of the Tent of Meeting. Eli's sons did not listen to their father. The Lord had already decided to kill them."
    },
    {
      "verse": "23",
      "text": "Eli said to his sons, ‘People have told me about all the evil things that you do."
    },
    {
      "verse": "24",
      "text": "No, my sons, you should not do these terrible things. The Lord's people all complain about you."
    },
    {
      "verse": "25",
      "text": "If you do something bad to another person, God can speak on your behalf. But if you do something bad against the Lord, nobody can speak on your behalf. ’Eli's sons did not listen to their father. The Lord had already decided to kill them."
    },
    {
      "verse": "26",
      "text": "The young boy Samuel continued to grow. The Lord was pleased with him, and so were the people."
    },
    {
      "verse": "27",
      "text": "A servant of God came and he spoke to Eli. This is what he said:‘The Lord says, “A long time ago, when your ancestors were in Egypt, I showed myself to them. At that time they were slaves of Egypt's king."
    },
    {
      "verse": "28",
      "text": "I chose your ancestor, Aaron, out of all the tribes of Israel. I chose him and his descendants to be my priests. I chose them to offer sacrifices on my altar, to burn incense and to wear the special ephod. I also gave them authority to eat part of the sacrifices and burnt offerings that the Israelites offered to me."
    },
    {
      "verse": "29",
      "text": "But you and your sons do not respect the sacrifices that I have commanded people to offer in my house. Eli, you give more honour to your sons than you give to me. Your family eat all the best parts of the offerings that the Israelites bring to me. You have all become fat! ”"
    },
    {
      "verse": "30",
      "text": "Because of what you have done, the Lord, Israel's God, says this to you: “I promised your family and your ancestors that they would serve me as priests for ever. ” But now the Lord says, “That will never happen! I will give honour to people who respect me. But I will curse people who insult me."
    },
    {
      "verse": "31",
      "text": "So you and your family will soon come to an end. No one in your family will live to become old men."
    },
    {
      "verse": "32",
      "text": "You will see how trouble comes to my home here. Good things will happen to the Israelite people, but there will never be an old man in your family."
    },
    {
      "verse": "33",
      "text": "One of your descendants may continue to serve me as a priest. But he will be very sad and his eyes will become weak. Anyone who is born in your family will die when they are young."
    },
    {
      "verse": "34",
      "text": "This will show you that what I have said is true: Your two sons, Hophni and Phinehas, will both die on the same day."
    },
    {
      "verse": "35",
      "text": "I will choose another priest to serve me. He will be faithful. He will do everything that I want him to do. I will give him a strong family and he will serve my chosen king for ever."
    },
    {
      "verse": "36",
      "text": "Everyone in your family who continues to live will have to bend down low to this priest. They will ask him for a few coins and a piece of bread. ‘Please let me help the priests so that I can have something to eat, ’ they will say. ” ’"
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "The boy Samuel continued to serve the Lord. Eli the priest taught him what to do. In those days, the Lord did not often give his messages to people. He did not often show things to them in visions."
    },
    {
      "verse": "2",
      "text": "Eli's eyes had become weak. He could not see very well. One night, he was sleeping in his usual place. But Eli said, ‘I did not call your name. Go back and lie down again. ’ So Samuel went and he lay down again."
    },
    {
      "verse": "3",
      "text": "The lamp of God was still burning. Samuel was lying down to sleep near the Covenant Box in the Lord's house."
    },
    {
      "verse": "4",
      "text": "Then the Lord called out to Samuel. Samuel answered, ‘Here I am. ’"
    },
    {
      "verse": "5",
      "text": "Samuel ran to Eli and he said, ‘You called my name. Here I am. ’But Eli said, ‘I did not call your name. Go back and lie down again. ’ So Samuel went and he lay down again."
    },
    {
      "verse": "6",
      "text": "Again the Lord called out, ‘Samuel’. So Samuel went to Eli and he said, ‘You called my name. Here I am. ’Eli answered, ‘My son, I did not call your name. Go back and lie down again. ’ Eli answered, ‘My son, I did not call your name. Go back and lie down again. ’"
    },
    {
      "verse": "7",
      "text": "Samuel did not know the Lord yet. The Lord had not spoken to him before."
    },
    {
      "verse": "8",
      "text": "Then the Lord called Samuel's name for the third time. Samuel got up again. He went to Eli and he said, ‘You called my name. Here I am. ’Then Eli realized that it was the Lord who was calling the boy's name."
    },
    {
      "verse": "9",
      "text": "So Eli said to Samuel, ‘Go back and lie down again. If he calls your name again, you must say, “Speak, Lord. I am your servant and I am listening. ” ’ So Samuel went back and he lay down in his place."
    },
    {
      "verse": "10",
      "text": "The Lord came and he stood near to Samuel. He called Samuel's name again, as he had done before. He said, ‘Samuel, Samuel’. Samuel said, ‘Speak. I am your servant and I am listening. ’"
    },
    {
      "verse": "11",
      "text": "Then the Lord said to Samuel, ‘Listen to me. I am ready to do something great among the Israelite people. When people hear about it, they will shake with fear."
    },
    {
      "verse": "12",
      "text": "When that day arrives, I will punish Eli and his family in all the ways that I have said. I will start at the beginning and I will continue to the end."
    },
    {
      "verse": "13",
      "text": "I have warned Eli that I would punish his family for all time. He knew that his sons were doing very bad things. They were insulting me, God, and Eli did not stop them."
    },
    {
      "verse": "14",
      "text": "So I made a strong promise and I said, “I will never forgive the sins of Eli's family. No sacrifices or offerings will ever take away those sins. ” ’"
    },
    {
      "verse": "15",
      "text": "Samuel lay down again until the morning. Then he opened the doors of the Lord's house. He was afraid to tell Eli about the vision that he had received from God."
    },
    {
      "verse": "16",
      "text": "But Eli called out to Samuel, ‘Samuel, my son. ’ Samuel answered, ‘Here I am. ’"
    },
    {
      "verse": "17",
      "text": "Eli asked Samuel, ‘What message did the Lord speak to you? You must not hide it from me. God will certainly punish you if you do not tell me everything that he said to you. ’"
    },
    {
      "verse": "18",
      "text": "So Samuel told Eli everything. He did not hide any of God's message. Then Eli said, ‘The Lord. must do what he thinks is right. ’"
    },
    {
      "verse": "19",
      "text": "The Lord was with Samuel while he continued to grow up. So every message that Samuel spoke became true."
    },
    {
      "verse": "20",
      "text": "In all Israel, from the north to the south, everyone realized that Samuel was truly the Lord's prophet."
    },
    {
      "verse": "21",
      "text": "The Lord continued to appear at Shiloh. He showed himself to Samuel and he spoke to him there."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Samuel spoke the Lord's messages to all the Israelites. The Israelites went out to fight against the Philistines. The Israelite army put up their tents near the place called Ebenezer. The Philistine army put up their tents at Aphek."
    },
    {
      "verse": "2",
      "text": "The Philistines went to attack the Israelites. As the battle continued, the Philistines won the fight and they killed about 4, 000 Israelites."
    },
    {
      "verse": "3",
      "text": "The Israelite soldiers returned to their tents. The leaders of Israel said to each other, ‘Why did the Lord let the Philistines win against us today? We should bring the Lord's Covenant Box here from Shiloh. We will take it with us into the battle. Then it will save us from our enemies. ’"
    },
    {
      "verse": "4",
      "text": "So the people sent men to Shiloh and they brought back the Lord's Covenant Box. That is where the Lord Almighty sits between the cherubs. Eli's two sons, Hophni and Phinehas, also came with God's Covenant Box."
    },
    {
      "verse": "5",
      "text": "The men brought the Lord's Covenant Box into the place where the soldiers' tents were. When the Israelites saw it, they shouted so loudly that the ground shook."
    },
    {
      "verse": "6",
      "text": "The Philistines heard the loud noise. They asked each other, ‘What is happening there among the Hebrew people's army? ’ Then they realized that the Lord's Covenant Box had arrived there."
    },
    {
      "verse": "7",
      "text": "They were afraid and they said, ‘Their gods have come to help them fight! We are in bad trouble. Nothing like this has happened to us before."
    },
    {
      "verse": "8",
      "text": "This is terrible! Nobody can save us from those powerful gods. Those gods punished the Egyptians with many bad diseases in the desert."
    },
    {
      "verse": "9",
      "text": "Philistine soldiers, you must be brave! You must fight as strong men! If not, we will become slaves of these Hebrew people, as they were once our slaves. So be ready to fight bravely! ’"
    },
    {
      "verse": "10",
      "text": "So the Philistines did fight strongly and they won again. They killed 30, 000 Israelite soldiers in the battle. The other Israelite soldiers all ran home."
    },
    {
      "verse": "11",
      "text": "The Philistines took God's Covenant Box for themselves. Eli's two sons, Hophni and Phinehas, also died."
    },
    {
      "verse": "12",
      "text": "That same day, a soldier from the tribe of Benjamin ran from the battle. He ran to Shiloh. He had torn his clothes and he had put dirt on his head."
    },
    {
      "verse": "13",
      "text": "Eli was sitting on his chair by the side of the road in Shiloh. He was waiting for news of the battle. He wanted to know if God's Covenant Box was safe. When the soldier arrived in the city, he told the people what had happened in the battle. All the people started to cry loudly."
    },
    {
      "verse": "14",
      "text": "Eli heard the people's loud voices. He asked, ‘What is causing all the noise? ’ The soldier quickly went to tell Eli the news."
    },
    {
      "verse": "15",
      "text": "years old and he could not see at all."
    },
    {
      "verse": "16",
      "text": "The soldier said to Eli, ‘I am the man who ran here today from the battle. ’ Eli asked him, ‘What happened, my son? ’"
    },
    {
      "verse": "17",
      "text": "The soldier replied, ‘The Israelites ran away while the Philistines chased them. The Philistines killed many of our soldiers. Your two sons, Hophni and Phinehas, are dead. And the Philistines have taken away God's Covenant Box. ’"
    },
    {
      "verse": "18",
      "text": "Eli was sitting near the city's gate. He was old and fat. When the soldier spoke about God's Covenant Box, Eli fell back off his chair. His neck broke and he died. He had been a leader of Israel's people for 40 years."
    },
    {
      "verse": "19",
      "text": "At that time, Phinehas' wife was pregnant. She was ready to give birth. She heard the news that the Philistines had taken away God's Covenant Box. She heard that her husband Phinehas and his father Eli were dead. When she heard this news, she started to give birth to her baby. But she had a lot of pain."
    },
    {
      "verse": "20",
      "text": "She was dying. The women who were helping her said, ‘Do not be afraid. You have given birth to a son! ’ But this did not make her happy. She did not answer them."
    },
    {
      "verse": "21",
      "text": "She called the boy's name Ichabod, because she said, ‘God's glory has gone away from Israel. ’ She said this because the Philistines had taken away God's Covenant Box, and because her husband and his father had died."
    },
    {
      "verse": "22",
      "text": "She said, ‘God's glory has gone away from Israel because the Covenant Box has gone. ’"
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "When the Philistines took God's Covenant Box, they took it from Ebenezer to the town of Ashdod."
    },
    {
      "verse": "2",
      "text": "They carried it into the temple of Dagon, their god. They put the box next to the idol of Dagon."
    },
    {
      "verse": "3",
      "text": "The next morning, the people in Ashdod got up early. They saw that Dagon had fallen down in front of the Lord's Covenant Box. The idol's face was touching the ground. So they took Dagon and they put him back in his place."
    },
    {
      "verse": "4",
      "text": "The next morning, they got up early again. They saw that Dagon had fallen down in front of the Lord's Covenant Box again! His head and both his hands had broken off. They were lying on the step of the temple's door. Only his body remained together."
    },
    {
      "verse": "5",
      "text": "Because of that, even today Dagon's priests and other people never walk on the step of Dagon's temple in Ashdod."
    },
    {
      "verse": "6",
      "text": "The Lord punished the people who lived in Ashdod. He caused them to have a lot of pain, as well as the people in the places near Ashdod. He caused tumours to grow on their bodies."
    },
    {
      "verse": "7",
      "text": "When the people in Ashdod saw what was happening, they said, ‘The Covenant Box of Israel's God must not stay here with us. He is punishing us and our god Dagon. ’"
    },
    {
      "verse": "8",
      "text": "So the Philistine rulers met together. Ashdod's people asked them, ‘What should we do with the Covenant Box of Israel's God? ’The rulers answered, ‘Take it away to Gath. ’ So the men took it to that city. The rulers answered, ‘Take it away to Gath. ’ So the men took it to that city."
    },
    {
      "verse": "9",
      "text": "After they had moved the Covenant Box to Gath, the Lord punished the people in that city too. He made them all very afraid. He caused tumours to grow on them, young people as well as old people."
    },
    {
      "verse": "10",
      "text": "So then they took God's Covenant Box to Ekron. When God's Covenant Box arrived in Ekron, the people screamed. They said, ‘They have brought the Covenant Box of Israel's God here! They want to kill us all! ’"
    },
    {
      "verse": "11",
      "text": "So they called the Philistine rulers to meet together. Ekron's people said to them, ‘Take away the Covenant Box of Israel's God! Send it back to its proper place. If you leave it here, it will kill us and all our families. ’All the people in the town were afraid of death. God had already started to punish them a lot."
    },
    {
      "verse": "12",
      "text": "Many people had already died. All the other people in the town had tumours on their bodies. So they cried loudly up to the skies for help."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "The Philistines had the Lord's Covenant Box in their country for seven months."
    },
    {
      "verse": "2",
      "text": "Then they called their priests and their magicians to meet with them. The people asked them, ‘What must we do with the Lord's Covenant Box? Tell us how we should send it back to its home. ’"
    },
    {
      "verse": "3",
      "text": "The priests and magicians answered, ‘Send the Covenant Box of Israel's God back with a special offering. You must not send it back without anything. Send an offering so that their God will forgive you. Then you will get well again. You will understand why he has continued to punish you. ’"
    },
    {
      "verse": "4",
      "text": "The people asked, ‘What offering should we send to their God, so that he will forgive us? ’The priests and magicians replied, ‘You must send gold images of five tumours and five mice. You must make five images of each one because the Philistines have five rulers. They have the same disease that all of you have."
    },
    {
      "verse": "5",
      "text": "Make images of the tumours and the mice that are destroying everything in the country. Do that to give honour to the God of Israel. Maybe then he will stop punishing you, your gods and your land."
    },
    {
      "verse": "6",
      "text": "Do not be like the Egyptians and Pharaoh, their king. They did not agree to obey God. So God punished them a lot until they let the Israelites leave Egypt."
    },
    {
      "verse": "7",
      "text": "You must make a new cart. Find two cows that have just given birth to calves. It must be the first time that those cows have pulled a cart. Tie them to the cart with ropes so that they can pull it. Then take their calves away from them."
    },
    {
      "verse": "8",
      "text": "Put the Lord's Covenant Box on the cart. Put another box on the cart with the gold images inside it. Those are your offerings to their God so that he will forgive you. Then send the cart away."
    },
    {
      "verse": "9",
      "text": "But continue to watch it carefully. The cows may pull it across our border to Beth Shemesh in Israel. If that happens, we will know that the God of Israel has punished us with this great trouble. But if the cart goes somewhere else, we will know that it was not their God who did this to us. We will know that our disease happened only by chance. ’"
    },
    {
      "verse": "10",
      "text": "So the Philistines did what the priests and magicians told them. They took two cows that had just given birth to calves. They tied the cows to a cart. They took away their calves and they kept them at home."
    },
    {
      "verse": "11",
      "text": "They put the Lord's Covenant Box on the cart. They put the other box beside it on the cart. That box contained the gold images of the mice and the tumours."
    },
    {
      "verse": "12",
      "text": "The cows pulled the cart straight along the road towards Beth Shemesh. They did not turn off the road at all, to the left side or the right side. As they went, they made a lot of noise. The Philistine rulers walked behind the cart all the way, as far as the edge of Beth Shemesh."
    },
    {
      "verse": "13",
      "text": "The people who lived in Beth Shemesh were working in their fields in the valley. They were cutting their wheat at harvest time. They looked up and they saw the Lord's Covenant Box. It made them very happy."
    },
    {
      "verse": "16",
      "text": "The five Philistine rulers watched them as they did that. Then they returned to Ekron on the same day."
    },
    {
      "verse": "17",
      "text": "The Philistines had sent the gold tumours as an offering to the Lord. They wanted him to forgive them. There was one gold tumour for each of their five towns: Ashdod, Gaza, Ashkelon, Gath and Ekron."
    },
    {
      "verse": "18",
      "text": "The Philistines also sent five gold mice. There was one gold mouse for each of the five towns that had a ruler. Those were strong cities that had walls around them. Each town also had villages near to it. The large rock where the Levites put the Lord's Covenant Box is still there. So we remember what happened that day in Joshua's field in Beth Shemesh."
    },
    {
      "verse": "19",
      "text": "But some of the men from Beth Shemesh looked inside the Lord's Covenant Box. So God killed 70 of them. The people were very sad because the Lord had punished them so much."
    },
    {
      "verse": "20",
      "text": "The people of Beth Shemesh said, ‘The Lord is a holy God! Nobody can go near to him! We must send his Covenant Box away from us. But who can ever take care of it? ’"
    },
    {
      "verse": "21",
      "text": "So they sent people to Kiriath-Jearim with a message. They said, ‘The Philistines have sent the Lord's Covenant Box back to Israel. Please come and take it from us. Take it to your town. ’"
    },
    {
      "verse": "14",
      "text": "The cows pulled the cart into a field. It belonged to Joshua, who lived in Beth Shemesh. The cows stopped next to a large rock. The Levites took the Lord's Covenant Box off the cart. They put it on the large rock. They also put the box which contained the gold images on the rock."
    },
    {
      "verse": "15",
      "text": "The people from Beth Shemesh cut up the cart. They used the wood to make a fire. Then they killed the cows. They burnt them on the fire as a burnt offering to the Lord. That day the people of Beth Shemesh offered many burnt offerings and other sacrifices to the Lord."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "So men came from Kiriath-Jearim to fetch the Lord's Covenant Box. They took it to Abinadab's house. His house was on a hill. They chose his son, Eleazar, to take care of the Lord's Covenant Box as his special job."
    },
    {
      "verse": "2",
      "text": "The Covenant Box stayed at Kiriath-Jearim for a long time. It was there for 20 years. During this time, the Israelites were sad. They prayed for the Lord to help them again."
    },
    {
      "verse": "3",
      "text": "Then Samuel said to all the Israelite people, ‘If you truly want to turn back to the Lord, you must show that you mean it. You must remove all your foreign gods and the images of Ashtoreth. You must give your lives completely to the Lord. You must worship only the Lord. If you do that, he will save you from the power of the Philistines. ’"
    },
    {
      "verse": "4",
      "text": "So the Israelites removed all their idols of the false gods called Baal and Ashtoreth. They only worshipped the Lord."
    },
    {
      "verse": "5",
      "text": "Then Samuel told all the Israelites, ‘Meet together at Mizpah. I will pray to the Lord for you there. ’"
    },
    {
      "verse": "6",
      "text": "So they all met together at Mizpah. They got water from a well and they poured it out for the Lord. They did not eat food that day. They prayed and they said, ‘We have done bad things against the Lord. ’Samuel became leader of the Israelite people at Mizpah. Samuel became leader of the Israelite people at Mizpah."
    },
    {
      "verse": "7",
      "text": "The Philistines heard the news that the Israelites had met together at Mizpah. So the Philistine rulers led their people to attack the Israelites. When the Israelites heard about this, they became very afraid of the Philistines."
    },
    {
      "verse": "8",
      "text": "They said to Samuel, ‘Pray to the Lord our God. Do not stop. Ask him to help us. Ask him to save us from the Philistines. ’"
    },
    {
      "verse": "9",
      "text": "So Samuel took a baby lamb. He gave it as a whole burnt offering to the Lord. Samuel asked the Lord to help the Israelites. The Lord answered his prayer in this way:"
    },
    {
      "verse": "10",
      "text": "While Samuel was giving the burnt offerings to the Lord, the Philistines moved nearer to attack the Israelites. But the Lord caused a very loud noise of thunder to frighten the Philistines. They became very confused and they started to run away from the Israelites."
    },
    {
      "verse": "11",
      "text": "Then the Israelite men came out from Mizpah. They chased the Philistines as far as a place near Beth-Kar. They killed the Philistines as they chased them."
    },
    {
      "verse": "12",
      "text": "After that, Samuel took a stone. He fixed it in the ground between Mizpah and Shen. He called the stone Ebenezer. He said, ‘The Lord has helped us all this way. ’"
    },
    {
      "verse": "13",
      "text": "That is how the Israelites won the fight against the Philistines. The Philistines did not attack Israel land again. All the time that Samuel was alive, the Lord stopped the Philistines from attacking Israel."
    },
    {
      "verse": "14",
      "text": "The Israelites took back the towns and the land that the Philistines had taken from them. These towns were between Ekron and Gath. Also, the Israelites and the Amorites did not fight against each other."
    },
    {
      "verse": "15",
      "text": "Samuel continued to be the leader of the Israelites while he was alive."
    },
    {
      "verse": "16",
      "text": "Every year, he travelled to Bethel, Gilgal and Mizpah. In all those towns he was a judge for the Israelite people."
    },
    {
      "verse": "17",
      "text": "But he always returned to his home at Ramah. He was a judge for the Israelite people there too. He built an altar in Ramah to worship the Lord there."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "When Samuel was old, he made his sons judges for the Israelites."
    },
    {
      "verse": "2",
      "text": "The name of his firstborn son was Joel. The name of his second son was Abijah. They were judges in Beersheba town."
    },
    {
      "verse": "3",
      "text": "But Samuel's sons did not live in a good way, as Samuel had done. They took money from people in ways that were not honest. They accepted bribes so that they did not judge in a fair way."
    },
    {
      "verse": "4",
      "text": "So all of Israel's leaders went together to meet Samuel at Ramah."
    },
    {
      "verse": "5",
      "text": "They said to him, ‘You are old. Your sons do not live in the way that you have done. All the other nations have kings to lead them. So choose a king to rule over us, like they have. ’"
    },
    {
      "verse": "6",
      "text": "When Israel's leaders said, ‘Choose a king who will lead us, ’ Samuel was not happy. So he prayed to the Lord."
    },
    {
      "verse": "7",
      "text": "The Lord said to Samuel, ‘Listen to everything that the people are saying to you. I myself should be their king. So it is not you that they refuse to accept. It is me that they do not accept to be their king."
    },
    {
      "verse": "8",
      "text": "They are doing what they have always done. Since I brought them out of Egypt they have continued to turn away from me. They have chosen to serve other gods. Now they are turning against you in the same way."
    },
    {
      "verse": "9",
      "text": "So do what they are asking you to do. But warn them about what will happen. Tell them how their kings will rule over them. ’"
    },
    {
      "verse": "10",
      "text": "Samuel spoke to the people who had asked him to give them a king. He told them everything that the Lord had said to him."
    },
    {
      "verse": "11",
      "text": "Samuel said to them, ‘This is how the king will rule over you: He will take your sons to be his soldiers. They will ride his horses and they will drive his chariots. They will have to run in front of his own chariot."
    },
    {
      "verse": "12",
      "text": "The king will choose some of your sons to be officers in his army. Some will be leaders of 1, 000 soldiers. Others will be leaders of 50 soldiers. Some of your sons will have to plough the king's fields. They will have to cut his crops at harvest time. They will have to make weapons for the king to fight wars. They will have to fix his chariots."
    },
    {
      "verse": "13",
      "text": "The king will take your daughters to serve him. They will have to make perfume for him. They will also have to cook and bake bread for him."
    },
    {
      "verse": "14",
      "text": "The king will take your best fields, vines and olive trees away from you. He will give all these to his own officers."
    },
    {
      "verse": "15",
      "text": "He will take a tenth part of all your seeds and grapes. He will give them to his officers and servants."
    },
    {
      "verse": "16",
      "text": "He will take your male and female servants for himself. He will take your best cows and your donkeys. He will use them for his own work."
    },
    {
      "verse": "17",
      "text": "He will take a tenth of all your sheep and your goats. You yourselves will become his servants too."
    },
    {
      "verse": "18",
      "text": "Then you will complain loudly to the Lord about your king that you have chosen to lead you. But the Lord will not answer you when you do that. ’"
    },
    {
      "verse": "19",
      "text": "But the people would not listen to Samuel. They said, ‘No! We want a king to rule us."
    },
    {
      "verse": "20",
      "text": "We want to be like all the other nations! We want a king to rule us. He will be our leader when we go to fight our enemies. ’"
    },
    {
      "verse": "21",
      "text": "Samuel listened to everything that the people said. Then he told the Lord about it all. Then Samuel told Israel's people, ‘Return to your own towns, each of you. ’"
    },
    {
      "verse": "22",
      "text": "The Lord said to Samuel, ‘You must do what they want. You must give a king to them. ’Then Samuel told Israel's people, ‘Return to your own towns, each of you. ’"
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "Kish was an important man from the tribe of Benjamin. He was the son of Abiel. Abiel was the son of Zeror. Zeror was the son of Becorath. Becorath was the son of Aphiah. Aphiah was a descendant of Benjamin."
    },
    {
      "verse": "2",
      "text": "Kish had a son whose name was Saul. Saul was a handsome young man. No other Israelite was more handsome than he was. When Saul stood with other people, you could see his head above everyone else."
    },
    {
      "verse": "3",
      "text": "Some of Kish's donkeys had run away. Kish said to Saul, ‘Go and look for my donkeys. Take one of the servants with you. ’"
    },
    {
      "verse": "4",
      "text": "So Saul and the servant travelled through the hill country of Ephraim. They went across Shalisha region. But they did not find the donkeys there. Then they went to Shaalim region. The donkeys were not there either. They travelled through all the tribe of Benjamin's land. They still did not find the donkeys anywhere."
    },
    {
      "verse": "5",
      "text": "They reached the land of Zuph's clan. Saul said to his servant, ‘We must return home now. We have been away for a long time. My father will start to think that we have become lost. He will not be thinking about the donkeys any more. ’"
    },
    {
      "verse": "6",
      "text": "The servant replied, ‘There is a servant of God who lives in this town. Everything that he says will happen really happens. So people respect him very much. We should go to meet him. Perhaps he will tell us which way we should go from here. ’"
    },
    {
      "verse": "7",
      "text": "Saul said to his servant, ‘That is good, but what will we give to him? We have eaten all the food that we brought with us in our bags. What else do we have? We must give him something. ’"
    },
    {
      "verse": "8",
      "text": "The servant answered, ‘I still have one small silver coin. I will give that to the servant of God. Then he will tell us which way we should go. ’"
    },
    {
      "verse": "9",
      "text": "(That was the custom in Israel. If someone needed to hear a message from God, he would say, ‘We should go and talk with the seer. ’ The man that we now call a prophet was called a ‘seer’ at that time. )"
    },
    {
      "verse": "10",
      "text": "Saul said to his servant, ‘That is a good idea. We should go now and see him. ’ So they went to the town where the servant of God lived."
    },
    {
      "verse": "11",
      "text": "They went up the hill to the town. Some young women came out of the town to get some water at a well. Saul and his servant asked them, ‘Is the seer here? ’"
    },
    {
      "verse": "12",
      "text": "They said, ‘Yes, he is here. Go straight along this road. You must hurry. The seer came to the town today because the people will offer a sacrifice. He will go with them to the altar on the hill."
    },
    {
      "verse": "13",
      "text": "When you go into the town, you will find him before he goes up there. The people will not start to eat until he comes. First, he must bless the sacrifice. Then he will eat with the people who are there. Go up into the town now and you will find him. ’"
    },
    {
      "verse": "14",
      "text": "Saul and his servant went up towards the town. When they arrived there, Samuel came towards them. He was going up to the altar on the hill."
    },
    {
      "verse": "15",
      "text": "The day before Saul arrived, the Lord had already spoken to Samuel. He had said,"
    },
    {
      "verse": "16",
      "text": "‘Tomorrow I will send a man to you who comes from the land of Benjamin. He will arrive at about this time of day. Anoint him to be the ruler over my people, Israel. He will save my people from the power of the Philistines. My people have called out to me for help. Now I have decided to help them. ’"
    },
    {
      "verse": "17",
      "text": "When Samuel saw Saul, the Lord said to him, ‘Here is the man that I told you about. He will rule over my people. ’"
    },
    {
      "verse": "18",
      "text": "Saul met Samuel at the gate of the town. Saul said to him, ‘Please tell me where the seer's house is. ’"
    },
    {
      "verse": "19",
      "text": "Samuel said to him, ‘I am the seer! Go in front of me now to the altar on the hill. You and your servant will eat a meal with me there. Tomorrow morning I will send you back to your home. Before that, I will tell you what you want to know."
    },
    {
      "verse": "20",
      "text": "Someone has already found the donkeys that you lost three days ago. Do not think any more about them. The only thing that the Israelite people want now is you! They want you and all your father's family. ’"
    },
    {
      "verse": "21",
      "text": "Saul answered, ‘I belong to the tribe of Benjamin. It is the smallest tribe in the nation of Israel. And my family belongs to the smallest clan in that tribe. So why do you speak like this to me? ’"
    },
    {
      "verse": "22",
      "text": "Then Samuel took Saul and his servant into the room where they would eat the meal. He made them sit in the most important seats in front of all the other people. About 30 people had come to eat the meal."
    },
    {
      "verse": "23",
      "text": "Samuel said to the cook, ‘Please bring me the special piece of meat that I gave to you. I told you to keep that piece separate. ’"
    },
    {
      "verse": "24",
      "text": "So the cook brought the leg of meat and he put it down in front of Saul. Samuel said to Saul, ‘I kept this special piece of meat for you to eat. Eat it now. I kept it separate for this time when we would eat together. I chose it for you when I asked the people to come and eat this special meal. ’So Saul ate the meal with Samuel that day. So Saul ate the meal with Samuel that day."
    },
    {
      "verse": "25",
      "text": "They came down from the hill and they went into the town. Samuel took Saul onto the roof of his house and they talked together."
    },
    {
      "verse": "26",
      "text": "They got up at dawn the next day. Saul had been sleeping on the roof. Samuel shouted up to him, ‘Get up and prepare to leave. I will send you on your journey. ’Saul got ready to leave to go home. Saul and Samuel went out into the street together."
    },
    {
      "verse": "27",
      "text": "They walked to the edge of the town. Samuel said to Saul, ‘Tell your servant to go on in front of us. ’ So he did that. Then Samuel said, ‘Stay here for a moment. I need to tell you God's message. ’"
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "Then Samuel took a jar of oil and he poured the oil on Saul's head. He kissed Saul. He said:‘The Lord has anointed you as the leader of his people. You will rule over them and you will rescue them from the power of their enemies. This is how you will know that the Lord has chosen you to be the leader of the Israelite people: ‘The Lord has anointed you as the leader of his people. You will rule over them and you will rescue them from the power of their enemies. This is how you will know that the Lord has chosen you to be the leader of the Israelite people:"
    },
    {
      "verse": "2",
      "text": "After you leave me today, you will meet two men at Zelzah on the border of Benjamin's land. They will be near the grave where Rachel is buried. The men will say to you, “Someone has found the donkeys that you were looking for. Your father is no longer thinking about his donkeys. Now he is upset because he does not know where you are. He continues to ask, ‘What can I do about my son? ’ ”"
    },
    {
      "verse": "3",
      "text": "After you leave there, you will reach the big tree at Tabor. Three men will meet you there. They are going to Bethel to worship God there. One of the men will have three young goats with him. One of them will have three loaves of bread. The third man will have a bag full of wine."
    },
    {
      "verse": "4",
      "text": "They will say “hello” to you and they will offer you two loaves of bread. You must accept the bread."
    },
    {
      "verse": "5",
      "text": "Then you must go to God's special hill at Gibeah. Some Philistine soldiers have their camp there. When you reach the town, you will meet a group of prophets. They will be coming down from the hill where people worship God. They will be making music with their harps, tambourines, flutes and lyres. They will be prophesying as they go along."
    },
    {
      "verse": "6",
      "text": "Then the Lord's Spirit will come to you with power. You will start to prophesy too. You will change to become like a different person."
    },
    {
      "verse": "7",
      "text": "After you see these things happen, you must do whatever seems right to you. God will be with you."
    },
    {
      "verse": "8",
      "text": "You must go to Gilgal and then I will come there. I will join with you there to offer burnt offerings and peace offerings to God. You must wait for seven days until I come. When I arrive at Gilgal, I will tell you what you should do. ’"
    },
    {
      "verse": "9",
      "text": "Saul turned away to leave Samuel. At that moment, God gave Saul a new nature. Everything that Samuel had said to Saul happened that day."
    },
    {
      "verse": "10",
      "text": "When Saul and his servant arrived at Gibeah, a group of prophets met them. God's Spirit came on Saul with power. He started to prophesy as the prophets were doing."
    },
    {
      "verse": "11",
      "text": "People who already knew Saul could not understand what was happening. When they saw him prophesying along with the prophets, they asked each other, ‘What has happened to this son of Kish? Has Saul himself become a prophet? ’"
    },
    {
      "verse": "12",
      "text": "A man who lived in Gibeah asked, ‘Do you know who is the father of all these prophets? ’ Because of what happened, it became a proverb to say, ‘Has Saul himself become a prophet? ’"
    },
    {
      "verse": "13",
      "text": "When Saul had finished prophesying, he went up to the hill where people worship God."
    },
    {
      "verse": "14",
      "text": "When Saul's uncle saw Saul and his servant, he asked them, ‘Where have you been? ’ Saul said, ‘We went to look for the donkeys. We could not find them so we went to visit Samuel. ’"
    },
    {
      "verse": "15",
      "text": "Saul's uncle said, ‘What did Samuel say to you? ’"
    },
    {
      "verse": "16",
      "text": "Saul replied, ‘He told us that someone had found the donkeys. ’ But Saul did not tell his uncle that Samuel had said that he would become the king."
    },
    {
      "verse": "17",
      "text": "Samuel sent a message to all Israel's people. He told them to come to Mizpah to meet with the Lord."
    },
    {
      "verse": "18",
      "text": "He said to them, ‘This is a message from the Lord, Israel's God: “I led you Israelites out from Egypt. I saved you from the power of the Egyptians. I also saved you from other kingdoms that were cruel to you."
    },
    {
      "verse": "19",
      "text": "I am the one who saves you from all your pain and troubles. But now you have turned against me, your God. You have said, ‘No! We want a king to rule over us instead. ’ So now come and stand in front of the Lord. Stand together in your tribes and in your clans. ” ’"
    },
    {
      "verse": "20",
      "text": "So each tribe came forward to Samuel, tribe by tribe. God chose Benjamin's tribe."
    },
    {
      "verse": "21",
      "text": "Then each family from Benjamin's tribe went forward. God chose the family of Matri. Then God chose Kish's son Saul from the family of Matri. They looked for Saul but nobody could find him."
    },
    {
      "verse": "22",
      "text": "So they asked the Lord, ‘Has Saul arrived here yet? ’ The Lord said, ‘Yes, but he is hiding among the luggage. ’"
    },
    {
      "verse": "23",
      "text": "So they ran to find Saul. They brought him out from there. When Saul stood among the people, you could see his head above everyone else."
    },
    {
      "verse": "24",
      "text": "Samuel said to all the people, ‘Look! Here is the man that the Lord has chosen. There is nobody like him among all the people. ’ Then the people shouted, ‘May the king live for a long time! ’"
    },
    {
      "verse": "25",
      "text": "Then Samuel explained to the people all the rules about a king. He wrote everything in a book. He put the book in a special place where they worshipped the Lord. Then Samuel told all the people to go to back to their homes."
    },
    {
      "verse": "26",
      "text": "Saul himself went back to his home at Gibeah. A group of brave men went with him. God had caused them to want to do that."
    },
    {
      "verse": "27",
      "text": "But some wicked men were complaining. They said, ‘This man will never be able to save us. ’ They did not respect Saul. They did not bring him any gifts. But Saul did not say anything against them."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "One month later, Nahash went with his army to attack Jabesh, a town in Gilead region. Nahash was an Ammonite. The people in Jabesh said to him, ‘Make an agreement with us so that we will serve you. ’"
    },
    {
      "verse": "2",
      "text": "Nahash said, ‘I will make an agreement with you only if you let me do this. I must cut out the right eye of every person in your town. I want to bring shame on all Israel's people. ’"
    },
    {
      "verse": "3",
      "text": "The leaders of Jabesh said to him, ‘Wait for seven more days. We will send a message to all the people in Israel. We will ask them to rescue us. If nobody comes to save us, we will agree to whatever you say. ’"
    },
    {
      "verse": "4",
      "text": "Men took the message to Gibeah, the town where Saul lived. When they told the news to the people there, the people started to weep loudly."
    },
    {
      "verse": "5",
      "text": "Saul had been out on his farm. As he was returning home with his cows, he asked, ‘What has happened here? Why are the people weeping? ’ They told Saul what the men from Jabesh had said."
    },
    {
      "verse": "6",
      "text": "When Saul heard the news, God's Spirit came on him with power. He became very angry."
    },
    {
      "verse": "7",
      "text": "He killed two of his oxen. He cut their bodies into pieces. He sent men with the pieces to all the towns in Israel. In each town, the men said, ‘Everyone must join Saul and Samuel to fight in their army. If you do not agree to join them, they will cut up your oxen just like this! ’ The people became very afraid of what the Lord would do. So they all came together as one army."
    },
    {
      "verse": "8",
      "text": "They met together at Bezek. Saul counted 300, 000 men from Israel and 30, 000 men from Judah."
    },
    {
      "verse": "9",
      "text": "Saul said to the men who had brought the news from Jabesh, ‘Return to Jabesh. Tell the people, “We will come to rescue you tomorrow, before midday. ” ’So the men took the message to the people in Jabesh. The people were very happy."
    },
    {
      "verse": "10",
      "text": "The men there said to Nahash, ‘Tomorrow we will come out of the town to you. Then you can do anything that you want to us. ’"
    },
    {
      "verse": "11",
      "text": "Early the next day, Saul put his soldiers into three groups. At dawn, they attacked the camp of the Ammonite soldiers. The Israelite soldiers continued to kill the Ammonites until midday. The Ammonite soldiers who were still alive ran away in different directions. Each man ran off by himself."
    },
    {
      "verse": "12",
      "text": "The Israelite people said to Samuel, ‘Bring to us those men who said, “We do not want Saul to rule over us. ” We must kill them! ’"
    },
    {
      "verse": "13",
      "text": "Saul said, ‘No, you must not kill anyone today. It is the day when the Lord has rescued Israel's people. ’"
    },
    {
      "verse": "14",
      "text": "Samuel said to the people, ‘Now we will all go to Gilgal. We must all agree that Saul will continue to be our king. ’"
    },
    {
      "verse": "15",
      "text": "So everyone went to Gilgal. They went to the place where they worshipped the Lord. They all agreed that Saul would be their king. They offered peace offerings to the Lord. Saul and all the Israelites were very happy."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "Samuel said to all the Israelites, ‘I have done everything that you asked me to do. I have given you a king to rule over you."
    },
    {
      "verse": "2",
      "text": "Listen! You now have a king to be your leader, instead of me. I am old and my hair is grey. My sons are here with you. I have been your leader from the time when I was young until now."
    },
    {
      "verse": "3",
      "text": "Look at me. I stand here where the Lord and his chosen king can see me. Speak now if I have done any wrong thing against you. Have I taken anyone's cow or anyone's donkey? Have I cheated anyone? Have I been cruel to anyone? Have I received bribes from anyone to say that they are not guilty? If I have done any of those things, tell me! Then I will pay back my debt. ’"
    },
    {
      "verse": "4",
      "text": "The Israelites answered, ‘You have not cheated us. You have not been cruel to us. You have not robbed any of us. ’"
    },
    {
      "verse": "5",
      "text": "Samuel said to them, ‘The Lord and his chosen king have heard what you have said today. They know that I have not done a wrong thing against any of you. ’The people replied, ‘Yes, the Lord knows what we have said. ’ The people replied, ‘Yes, the Lord knows what we have said. ’"
    },
    {
      "verse": "6",
      "text": "Then Samuel said to the people, ‘The Lord chose Moses and Aaron to lead his people. He brought your ancestors out from Egypt."
    },
    {
      "verse": "7",
      "text": "You must stand up now for the Lord to judge you. You need to remember all the great things that the Lord has done to help you and your ancestors."
    },
    {
      "verse": "8",
      "text": "After Jacob and his family went to Egypt, your ancestors called to the Lord for help. The Lord sent Moses and Aaron to help them. They led your ancestors out of Egypt. They brought them to live here in this land."
    },
    {
      "verse": "9",
      "text": "But your ancestors forgot about the Lord their God. So he let their enemies win against them. Sisera led an army from Hazor to attack the Israelites. The Philistines and the king of Moab also attacked them."
    },
    {
      "verse": "10",
      "text": "Then the Israelites called out to the Lord for help. They said, “We have done bad things. We have turned away from the Lord and we have worshipped idols of Baal and images of Ashtoreth. Please save us from our enemies and we will worship you. ”"
    },
    {
      "verse": "11",
      "text": "So the Lord sent Gideon, Barak, Jephthah and Samuel to help you. The Lord saved you from all your enemies so that you could live safely."
    },
    {
      "verse": "12",
      "text": "But then you saw that Nahash, the king of the Ammonites, was coming to attack you. So you said to me, “Now we want a king to rule over us. ” You forgot that the Lord your God is your king."
    },
    {
      "verse": "13",
      "text": "Look! Here is the king that you chose. He is the man that you asked to have. The Lord has made him your king."
    },
    {
      "verse": "14",
      "text": "You must respect the Lord with fear. You must obey what he commands you to do. You and the king who rules over you must serve only the Lord your God. If you do that, everything will go well for you."
    },
    {
      "verse": "15",
      "text": "But the Lord will punish you and your king if you do not obey him. You must not turn against him again."
    },
    {
      "verse": "16",
      "text": "Now stand where you are and watch! The Lord will do a great thing and you will see it."
    },
    {
      "verse": "17",
      "text": "This is the time of the wheat harvest. I will ask the Lord to send thunder and rain. Then you will understand that you have done an evil thing against the Lord. You asked for a king to rule over you. ’"
    },
    {
      "verse": "18",
      "text": "Samuel prayed to the Lord. That same day the Lord sent thunder and rain. All the people became afraid of the Lord and of Samuel."
    },
    {
      "verse": "19",
      "text": "They said to Samuel, ‘Please pray to the Lord your God for us. We do not want to die! We realize that we have done many bad things in past times. Now we have added to those sins when we asked to have a king. ’"
    },
    {
      "verse": "20",
      "text": "Samuel said to the people, ‘Do not be afraid. It is true that you have done an evil thing. But do not turn away from the Lord. Instead, serve him with all your strength."
    },
    {
      "verse": "21",
      "text": "Do not worship idols. They are useless things. They cannot help you. They will never save you."
    },
    {
      "verse": "22",
      "text": "The Lord was pleased to choose you to be his own people. He will show that he is faithful and he will not leave you alone."
    },
    {
      "verse": "23",
      "text": "As for me, I will not stop praying for you. That would be a sin against the Lord. I will teach you how to live in the right way."
    },
    {
      "verse": "24",
      "text": "But you must respect and obey the Lord. You must serve him faithfully with all your strength. Remember the great things that he has done for you."
    },
    {
      "verse": "25",
      "text": "If you continue to do evil things, that will be the end of you and your king. ’"
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "years old when he became king. He ruled Israel as king for 42 years."
    },
    {
      "verse": "2",
      "text": "He chose 3, 000 men from Israel's army to be with him. 2, 000 of those men stayed with him at Michmash and in the hill country of Bethel. Then 1, 000 men were with his son Jonathan at Gibeah, in the land of Benjamin's tribe. Saul sent all the other men of the army back to their homes."
    },
    {
      "verse": "3",
      "text": "Some Philistine soldiers had a camp at Geba. Jonathan attacked them there and all the Philistines heard about it. Saul sent a message through all Israel to warn people of the danger. He said, ‘Listen, all you Hebrew people! ’"
    },
    {
      "verse": "4",
      "text": "Everyone in Israel heard this message: ‘Saul has attacked the Philistines' camp. Now the Philistines hate the Israelites even more than they did before. ’ So all the soldiers in Israel came to join Saul at Gilgal."
    },
    {
      "verse": "5",
      "text": "The Philistines' army came together to fight against the Israelites. The Philistines had 3, 000 chariots. They had 6, 000 soldiers who rode on horses. Their whole army had more soldiers than the sand on the shore of the sea! The Philistine army went to make their camp at Michmash, which was east of Beth Aven."
    },
    {
      "verse": "6",
      "text": "The Israelites realized that they would be in big trouble if the Philistines attacked them. Some of them went and hid in caves or among the bushes. Others hid among the rocks, in holes in the ground or in wells."
    },
    {
      "verse": "7",
      "text": "Some of the Israelite soldiers crossed the Jordan River. They escaped to the land of Gad and Gilead. Saul himself stayed at Gilgal. All the soldiers that were still with him were shaking with fear."
    },
    {
      "verse": "8",
      "text": "Samuel had told Saul that he must wait for him to come to Gilgal. Saul waited for seven days as Samuel had said. But Samuel still had not arrived. Saul's army began to leave him."
    },
    {
      "verse": "9",
      "text": "So Saul said, ‘Bring the burnt offering and the peace offerings to me. ’ Then Saul offered the burnt offering to God."
    },
    {
      "verse": "10",
      "text": "Just as he finished doing that, Samuel arrived. Saul went to meet Samuel and to say ‘hello’."
    },
    {
      "verse": "11",
      "text": "Samuel asked Saul, ‘What have you done? ’Saul replied, ‘The soldiers were starting to leave me. You had not arrived here at the time that you said you would come. I could see that the Philistine soldiers were preparing for battle at Michmash."
    },
    {
      "verse": "12",
      "text": "I thought that they would come to attack me at Gilgal. I thought, “Before they do that, I must ask the Lord to help us in the fight. ” Because of that, I had to offer the burnt offering to him. ’"
    },
    {
      "verse": "13",
      "text": "Samuel said, ‘You have done a foolish thing. You have not obeyed the command of the Lord your God. If you had obeyed the Lord, he would have let you and your family rule Israel for ever."
    },
    {
      "verse": "14",
      "text": "But because of what you have done, your kingdom will not continue. Instead, the Lord will find a man who pleases him. The Lord has decided that this man will become the leader of his people, instead of you. He will do that because you have not obeyed his command. ’"
    },
    {
      "verse": "15",
      "text": "After that, Samuel left Gilgal. He went to Gibeah in the land of Benjamin's tribe. Saul counted the soldiers who were still with him. There were about 600 men."
    },
    {
      "verse": "16",
      "text": "Saul and his son Jonathan were staying in Geba, in the land of Benjamin's tribe. They had their soldiers with them there. The Philistines had their camp at Michmash."
    },
    {
      "verse": "17",
      "text": "The Philistines sent out three small groups of soldiers to attack towns in Israel. One group went towards Ophrah in the land of Shual."
    },
    {
      "verse": "18",
      "text": "The second group went towards Beth Horon. The third group went to Israel's border where they could see across Zeboim Valley towards the wilderness."
    },
    {
      "verse": "19",
      "text": "At that time, there were no people in Israel who could use iron to make things. The Philistines had said, ‘We must not let the Hebrew people make swords and spears. ’"
    },
    {
      "verse": "20",
      "text": "So the Israelites had to ask the Philistines to mend their ploughs, axes, hoes and knives that they used on their farms."
    },
    {
      "verse": "21",
      "text": "The Israelites had to pay eight grams of silver for the Philistines to make each plough or hoe sharp again. They paid four grams of silver for each axe, knife or ox-goad."
    },
    {
      "verse": "22",
      "text": "So when the fight started, the soldiers that were with Saul and Jonathan did not have any swords or spears. Only Saul and his son Jonathan had them."
    },
    {
      "verse": "23",
      "text": "A group of Philistine soldiers went to the narrow road across the hills at Michmash."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "A young man carried the armour of Saul's son Jonathan. One day, Jonathan said to the young man, ‘Come with me. We will go over to the place where the Philistine soldiers have their camp. ’ But Jonathan did not tell his father what he was doing."
    },
    {
      "verse": "2",
      "text": "Saul was staying near Gibeah. He sat under a big fruit tree at Migron. There were about 600 soldiers with him."
    },
    {
      "verse": "3",
      "text": "The priest Ahijah was with Saul. Ahijah wore the priest's ephod. Ahijah was the son of Ichabod's brother, Ahitub. Ahitub was the son of Phinehas and the grandson of Eli. Eli was the priest who had served the Lord in Shiloh. Nobody knew that Jonathan had left."
    },
    {
      "verse": "4",
      "text": "To reach the Philistines, he had to go along a narrow valley. There were high rocks on both sides of the road. The name of one rock was ‘Bozez’. The name of the other rock was ‘Seneh’."
    },
    {
      "verse": "5",
      "text": "The rock on the north side of the road was near Michmash. The rock on the south side was near Geba."
    },
    {
      "verse": "6",
      "text": "Jonathan said to the young man who carried his armour, ‘Now we will go to the camp of those foreign people. Perhaps the Lord will help us to win the fight. He can win a battle whether there are many soldiers or only a few. ’"
    },
    {
      "verse": "7",
      "text": "The young man said, ‘You must do whatever you think is right. I will serve you faithfully all the way. ’"
    },
    {
      "verse": "8",
      "text": "Jonathan said, ‘Listen! We will go across to the Philistines now. We will let them see us."
    },
    {
      "verse": "9",
      "text": "They may tell us to stop and wait for them to come to us. If they say that, we will stay here."
    },
    {
      "verse": "10",
      "text": "But they may ask us to go up and fight against them. Then we will do that. We will know that the Lord has put them under our power. It will be his sign to us. ’"
    },
    {
      "verse": "11",
      "text": "Jonathan and the young man stood where the Philistine soldiers could see them. The Philistines said, ‘Look! The Hebrews are coming out of the holes where they have been hiding. ’ Jonathan said to the young man, ‘Follow me as I climb up to them. The Lord has put those men under Israel's power! ’"
    },
    {
      "verse": "12",
      "text": "They shouted to Jonathan and the young man, ‘Come up here to fight against us! We will teach you how to fight! ’Jonathan said to the young man, ‘Follow me as I climb up to them. The Lord has put those men under Israel's power! ’"
    },
    {
      "verse": "13",
      "text": "Jonathan climbed up the rock wall on his hands and his feet. The young man climbed up behind him. Jonathan attacked and killed some of the Philistines. The young man followed behind Jonathan and killed more of them."
    },
    {
      "verse": "14",
      "text": "In the first fight, Jonathan and his young man killed about 20 Philistines in a small area."
    },
    {
      "verse": "15",
      "text": "All the other soldiers in the Philistine army then became very afraid. This included the soldiers in the camp, those in the fields, those who were guards, and the groups who were attacking other towns. Even the ground shook because God had made them all very afraid."
    },
    {
      "verse": "16",
      "text": "Some of Saul's soldiers who were with him in Gibeah were watching the Philistines. They saw that their soldiers were running away in different directions."
    },
    {
      "verse": "17",
      "text": "Saul said to his men, ‘Count our soldiers. Find out who is not here. ’ When they did that, Jonathan and the young man who carried his armour were not there."
    },
    {
      "verse": "18",
      "text": "Saul said to Ahijah the priest, ‘Bring the ephod here. ’ At that time, Ahijah was wearing the ephod."
    },
    {
      "verse": "19",
      "text": "While Saul was saying this, the Philistine soldiers were making more and more noise. They were all very confused. So Saul said to the priest, ‘Take your hand out of the ephod. It is time to go! ’"
    },
    {
      "verse": "20",
      "text": "Then Saul and all the soldiers who were with him marched out to battle. They found that the Philistines were completely confused. They were fighting each other with their swords."
    },
    {
      "verse": "21",
      "text": "Before this time, some of the Hebrew men had gone to join with the Philistine army. Now they went back to join the Israelite army with Saul and Jonathan."
    },
    {
      "verse": "22",
      "text": "The Israelite soldiers who had hidden in the hill country of Ephraim also heard the news. When they knew that the Philistine soldiers were running away, they chased after them as well."
    },
    {
      "verse": "23",
      "text": "In that way, the Lord saved Israel's people on that day. The battle moved all the way to Beth Aven and beyond it."
    },
    {
      "verse": "24",
      "text": "The Israelite soldiers became very weak and hungry that day. Saul had told his army to agree to this promise: ‘Nobody may eat any food before this evening. By then I will have won against my enemies. If anyone eats anything before then, may God curse him! ’ So no soldier in Saul's army ate any food."
    },
    {
      "verse": "25",
      "text": "Saul's army went into a forest. There was honey on the ground."
    },
    {
      "verse": "26",
      "text": "The men saw all the honey but none of them ate any of it. They were afraid that God would curse them."
    },
    {
      "verse": "27",
      "text": "But Jonathan had not heard about the soldiers' promise to his father. He pushed the end of his stick into the honey. He took some honey on his fingers and he ate it. Then he felt stronger."
    },
    {
      "verse": "28",
      "text": "One of the soldiers told Jonathan, ‘Your father made us promise not to eat any food today. We all agreed that God should curse anyone who eats anything. That is why we are all so weak. ’"
    },
    {
      "verse": "29",
      "text": "Jonathan said, ‘My father has caused a lot of trouble for all the people. Look what happened when I ate only a little bit of honey. I became strong again!"
    },
    {
      "verse": "30",
      "text": "When our army won against our enemies today, we could have eaten the food that they left. Then our soldiers would have been strong enough to kill many more Philistines. ’"
    },
    {
      "verse": "31",
      "text": "That day, the Israelite army killed many Philistine soldiers. They chased the Philistines all the way from Michmash to Aijalon. After this, the Israelites became tired and weak."
    },
    {
      "verse": "32",
      "text": "So they quickly took sheep, cows and calves from the Philistines as food to eat. The soldiers were so hungry that they killed the animals on the ground. Then they ate the meat with the blood still in it."
    },
    {
      "verse": "33",
      "text": "Someone told Saul, ‘Look at what the army is doing. They are eating meat that still has blood in it. That is a sin against the Lord. ’Saul said to his soldiers, ‘You have turned against the Lord! Find a large stone and roll it here to me. ’ Saul said to his soldiers, ‘You have turned against the Lord! Find a large stone and roll it here to me. ’"
    },
    {
      "verse": "34",
      "text": "Then Saul said, ‘Go around to tell all the soldiers, “Bring the cows and the sheep here. Kill them properly and eat them here. Do not eat meat which still has blood in it. That is a sin against the Lord. ” ’ So that night every soldier brought an animal. They killed their animals on the stone."
    },
    {
      "verse": "35",
      "text": "Then Saul built an altar to worship the Lord. It was the first time that he had built an altar for the Lord."
    },
    {
      "verse": "36",
      "text": "Then Saul said, ‘We will go tonight and we will attack the Philistines again. We will chase them all night until dawn. We will kill all of them. ’The men answered, ‘Do whatever you think is right. ’But the priest said, ‘We should ask God first. ’ The men answered, ‘Do whatever you think is right. ’ But the priest said, ‘We should ask God first. ’"
    },
    {
      "verse": "37",
      "text": "Saul asked God, ‘Should we attack the Philistines? Will you give us power over them? ’ But God did not answer Saul that day."
    },
    {
      "verse": "38",
      "text": "So Saul said to all the leaders of the army, ‘Come here. Someone has done a bad thing today. We must find out who has done it."
    },
    {
      "verse": "39",
      "text": "The Lord is the one who rescues Israel. As surely as the Lord lives, I promise that I will punish the man who has done this bad thing. Whoever it is must die, even if it is my own son Jonathan. ’ But nobody in the army said anything."
    },
    {
      "verse": "40",
      "text": "Saul said to all the Israelites, ‘You stand on this side. My son Jonathan and I will stand on the other side. ’The people answered, ‘Do what you think is right. ’ The people answered, ‘Do what you think is right. ’"
    },
    {
      "verse": "41",
      "text": "Then Saul prayed to the Lord, Israel's God. He said, ‘Please show us who has done this sin. Let the special stones, Urim and Thummim, show who has done it. ’ The stones chose Jonathan and Saul. They did not choose the soldiers of the army."
    },
    {
      "verse": "42",
      "text": "Then Saul said, ‘Let the stones show whether it was Jonathan or me. ’ The stones chose Jonathan."
    },
    {
      "verse": "43",
      "text": "Saul said to Jonathan, ‘Tell me what you have done. ’Jonathan told him, ‘I pushed the end of my stick into some honey. I ate a little bit. You have said that I must die. ’ Jonathan told him, ‘I pushed the end of my stick into some honey. I ate a little bit. You have said that I must die. ’"
    },
    {
      "verse": "44",
      "text": "Saul said, ‘Jonathan, you must surely die! I ask God to kill me if I do not punish you with death. ’"
    },
    {
      "verse": "45",
      "text": "But the soldiers said to Saul, ‘No! Jonathan must not die! He has rescued Israel in battle. As surely as the Lord lives, we promise that he will not lose even one hair on his head. It is God who has helped Jonathan to win the fight today. ’In that way, the army saved Jonathan from death. In that way, the army saved Jonathan from death."
    },
    {
      "verse": "46",
      "text": "After that, Saul stopped fighting against the Philistines. The Philistines returned to their homes."
    },
    {
      "verse": "47",
      "text": "After Saul became king of Israel, he fought against all their enemies. He fought against the Moabites, the Ammonites and the Edomites. He fought against the kings who ruled in Zobah. He also fought against the Philistines. Saul won against all Israel's enemies, wherever they were."
    },
    {
      "verse": "48",
      "text": "He fought very bravely and he won against the Amalekites. Saul kept Israel safe from all the people who attacked them."
    },
    {
      "verse": "49",
      "text": "Saul's sons were Jonathan, Ishvi and Malki-Shua. Saul had two daughters. Merab was his older daughter. Michal was his younger daughter."
    },
    {
      "verse": "50",
      "text": "The name of Saul's wife was Ahinoam. She was the daughter of Ahimaaz. Abner was the leader of Saul's army. He was the son of Saul's uncle, Ner."
    },
    {
      "verse": "51",
      "text": "Abiel was the father of both Saul's father, Kish, and Abner's father, Ner."
    },
    {
      "verse": "52",
      "text": "During all of Saul's life there were wars between the Philistines and the Israelites. If Saul found a strong soldier or a brave man, he caused the man to join his army."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "Samuel said to Saul, ‘The Lord sent me to anoint you as king to rule his people, the Israelites. So now listen to this message from the Lord."
    },
    {
      "verse": "2",
      "text": "This is what the Lord Almighty says: “It is time to punish the Amalekites! When the Israelites came out of Egypt, the Amalekites attacked them."
    },
    {
      "verse": "3",
      "text": "Now go and attack the Amalekites. Completely destroy everything that they have. Do not save anything. Kill the men and women, as well as their children and babies. Kill their cows, sheep, camels and donkeys. ” ’"
    },
    {
      "verse": "4",
      "text": "So Saul called his army to come together. The men met at Telaim and Saul counted them. There were 200, 000 soldiers from Israel and another 10, 000 men from Judah's tribe."
    },
    {
      "verse": "5",
      "text": "Saul and his army went to the city of the Amalekites. They waited in a small valley to attack their enemy."
    },
    {
      "verse": "6",
      "text": "Saul said to the Kenite people, ‘Go away from here! I will kill the Amalekites, but I do not want to kill you. You were kind to the Israelites when they came out from Egypt. ’ So the Kenites moved away from the Amalekites."
    },
    {
      "verse": "7",
      "text": "Then Saul attacked the Amalekites. He fought them all the way from Havilah to Shur, which is east of Egypt."
    },
    {
      "verse": "8",
      "text": "Saul caught their king, Agag, while he was still alive. Saul's soldiers used their swords to kill all of Agag's people."
    },
    {
      "verse": "9",
      "text": "But Saul and the army let King Agag live. Also, they did not kill the best sheep, lambs, cows and fat calves. They kept all the good things and they did not agree to destroy them. But they killed everything that was weak and useless."
    },
    {
      "verse": "10",
      "text": "Then the Lord gave this message to Samuel: When Samuel heard that, he was very upset. He prayed aloud to the Lord all that night."
    },
    {
      "verse": "11",
      "text": "‘I am sorry that I chose Saul to be king. He has turned away from me. He has not obeyed my commands. ’When Samuel heard that, he was very upset. He prayed aloud to the Lord all that night."
    },
    {
      "verse": "12",
      "text": "Samuel got up early the next morning. He went to meet Saul. Someone told Samuel, ‘Saul went to Carmel. He has put up a tall stone to give himself honour. Now he has left there and he has gone to Gilgal. ’"
    },
    {
      "verse": "13",
      "text": "Samuel went and he found Saul. Saul said to Samuel, ‘I pray that the Lord will bless you. I have obeyed the Lord's command. ’"
    },
    {
      "verse": "14",
      "text": "But Samuel said, ‘If that is true, why can I hear the noise of sheep and cows? ’"
    },
    {
      "verse": "15",
      "text": "Saul answered, ‘My soldiers took them from the Amalekites. They saved the best sheep and cows. They will offer them to the Lord your God as sacrifices. We killed all the other animals. ’"
    },
    {
      "verse": "16",
      "text": "Samuel said to Saul, ‘Listen to me! I will tell you what the Lord said to me last night. ’ Saul said, ‘Tell me. ’"
    },
    {
      "verse": "17",
      "text": "Samuel said, ‘At one time, you thought that you were not an important person. Now you have become the leader of all the tribes of Israel. The Lord chose you to be king of Israel."
    },
    {
      "verse": "18",
      "text": "He gave you a job to do. He told you, “Go and kill all those wicked Amalekites. Fight against them until you have destroyed them all. ”"
    },
    {
      "verse": "19",
      "text": "Why did you not obey the Lord? Instead you have been greedy. You have hurried to take things for yourself. You have done something evil that does not please the Lord. ’"
    },
    {
      "verse": "20",
      "text": "Saul said to Samuel, ‘I did obey the Lord! I did the job that the Lord told me to do. I killed all the Amalekites and I brought back Agag, their king."
    },
    {
      "verse": "21",
      "text": "But the army did not kill all the sheep and cows that they took from the Amalekites. They brought the best animals to offer as a sacrifice to the Lord your God at Gilgal. ’"
    },
    {
      "verse": "22",
      "text": "But Samuel said, ‘What makes the Lord happy? Which is better? Is he more pleased when people offer burnt offerings and sacrifices to him? Or is he more pleased when people obey him? Listen! It is better to obey the Lord than to offer sacrifices to him. That is true even if you offer to him the best animals that you have."
    },
    {
      "verse": "23",
      "text": "You have turned against God. That is worse than using magic. You think that you know what is right better than God does. That is as bad as worshipping idols. You decided not to obey the Lord's command. Now the Lord has decided that you will not be king any longer. ’"
    },
    {
      "verse": "24",
      "text": "Then Saul said to Samuel, ‘It is true, I have done a bad thing. I did not obey the Lord's command. I did not do what you told me to do. I was afraid of the army. I agreed to do what they wanted."
    },
    {
      "verse": "25",
      "text": "Please forgive my sin. Return with me so that I can worship the Lord. ’"
    },
    {
      "verse": "26",
      "text": "But Samuel said to Saul, ‘I will not return with you. You refused to obey the Lord's command. So now the Lord has decided that you will no longer be king of Israel. ’"
    },
    {
      "verse": "27",
      "text": "Samuel turned away to leave Saul. But Saul pulled the edge of Samuel's coat and it tore."
    },
    {
      "verse": "28",
      "text": "Samuel said to him, ‘The Lord has torn the kingdom of Israel away from you today. He has given it to a man who is better than you."
    },
    {
      "verse": "29",
      "text": "The great God who rules over Israel always does what he says he will do. He does not change his mind. People may change their minds, but he does not! ’"
    },
    {
      "verse": "30",
      "text": "Saul said again, ‘I have done a bad thing. But please show Israel's leaders and people that you respect me. Please return with me so that I can worship the Lord your God. ’"
    },
    {
      "verse": "31",
      "text": "So Samuel went back with Saul. Saul worshipped the Lord."
    },
    {
      "verse": "32",
      "text": "Then Samuel said, ‘Bring Agag, king of the Amalekites, to me. ’Agag came to Samuel. Agag was happy because he thought, ‘I am sure that now I will not have to die a painful death. ’ Agag came to Samuel. Agag was happy because he thought, ‘I am sure that now I will not have to die a painful death. ’"
    },
    {
      "verse": "33",
      "text": "But Samuel said to Agag, ‘You have used your sword to kill the children of many mothers. Now your own mother will have no children that are still alive. ’ Then Samuel cut Agag into pieces at the Lord's altar in Gilgal."
    },
    {
      "verse": "34",
      "text": "Then Samuel left Gilgal and he went to his home in Ramah. Saul went to his home in Gibeah."
    },
    {
      "verse": "35",
      "text": "Until Samuel died, he never saw Saul again. Samuel was very sad about Saul. But the Lord was sorry that he had chosen Saul to be king of Israel."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "The Lord said to Samuel, ‘Stop being sad about Saul. I have decided that he will no longer be the king of Israel. Fill your horn with olive oil and go. I am sending you to a man whose name is Jesse. He lives in Bethlehem. I have chosen one of his sons to become king. ’"
    },
    {
      "verse": "2",
      "text": "Samuel said, ‘If I go to do that, people will tell Saul about it. Then he will kill me. ’The Lord said, ‘Take a calf with you. Tell the people that you have come to offer a sacrifice to the Lord."
    },
    {
      "verse": "3",
      "text": "Then ask Jesse to come to the sacrifice. I will show you what to do after that. I will show you the person that you must anoint with the oil. ’"
    },
    {
      "verse": "4",
      "text": "Samuel obeyed the Lord. He went to Bethlehem. The leaders of the town went to meet Samuel, but they were very afraid. They asked him, ‘Have you come to visit us as a friend? ’"
    },
    {
      "verse": "5",
      "text": "Samuel replied, ‘Yes. I do not bring any trouble. I have come to offer a sacrifice to the Lord. Make yourselves clean. Then come to the sacrifice with me. ’Samuel made Jesse and his sons clean to worship the Lord. Then he took them with him to the sacrifice. Samuel made Jesse and his sons clean to worship the Lord. Then he took them with him to the sacrifice."
    },
    {
      "verse": "6",
      "text": "When they arrived, Samuel saw Jesse's son Eliab. Samuel thought, ‘I am sure that the Lord has chosen this man to be king. ’"
    },
    {
      "verse": "7",
      "text": "But the Lord said to Samuel, ‘Do not look at how handsome or how tall Eliab is. I have not chosen him. The Lord does not look at people in the way that people do. People look at the face and body of a person. But the Lord sees what they are like inside. ’"
    },
    {
      "verse": "8",
      "text": "Then Jesse called his son Abinadab. Jesse caused him to stand in front of Samuel. But Samuel said, ‘The Lord has not chosen this man either. ’"
    },
    {
      "verse": "9",
      "text": "Jesse caused his son Shammah to stand in front of Samuel. But Samuel said, ‘The Lord has not chosen this man. ’"
    },
    {
      "verse": "10",
      "text": "Jesse caused seven of his sons to stand in front of Samuel. But Samuel said to Jesse, ‘The Lord has not chosen any of these men. ’"
    },
    {
      "verse": "11",
      "text": "Samuel asked Jesse, ‘Are those all of your sons? ’Jesse answered, ‘I have one more son. He is the youngest. He is taking care of my sheep. ’Samuel said, ‘Send someone to bring him here. We cannot continue to offer the sacrifice until he arrives. ’ Jesse answered, ‘I have one more son. He is the youngest. He is taking care of my sheep. ’ Samuel said, ‘Send someone to bring him here. We cannot continue to offer the sacrifice until he arrives. ’"
    },
    {
      "verse": "12",
      "text": "So Jesse told his men to bring his youngest son for Samuel to see. This young man was handsome and strong and he had beautiful eyes. The Lord said to Samuel, ‘I have chosen this man. Now anoint him as king. ’ The Lord said to Samuel, ‘I have chosen this man. Now anoint him as king. ’"
    },
    {
      "verse": "13",
      "text": "Samuel took the horn that was full of olive oil. He poured the oil over David's head to anoint him. Samuel did this in front of David's brothers. From that moment, the Spirit of the Lord came on David with great power. Then Samuel returned to his home in Ramah. Then Samuel returned to his home in Ramah."
    },
    {
      "verse": "14",
      "text": "The Spirit of the Lord had now gone away from Saul. The Lord sent an evil spirit to Saul. It gave Saul trouble and fear in his mind."
    },
    {
      "verse": "15",
      "text": "Saul's servants said to him, ‘We know that God has sent an evil spirit which is giving you much trouble."
    },
    {
      "verse": "16",
      "text": "If you agree, we will look for a man who can make music on a harp. When the evil spirit gives you trouble, this man can make music. Then you will not feel so upset. ’"
    },
    {
      "verse": "17",
      "text": "Saul agreed and he said to his servants, ‘Find someone who can make good music with a harp. Then bring him to me. ’"
    },
    {
      "verse": "18",
      "text": "One of the servants said, ‘I know one man who can play a harp very well. He is one of Jesse's sons, who lives in Bethlehem. This man is a brave soldier. He speaks well and he is handsome. The Lord is with him. ’"
    },
    {
      "verse": "19",
      "text": "So Saul sent his men to Jesse with this message: ‘Tell your son David to come to me. That is your son who takes care of your sheep. ’"
    },
    {
      "verse": "20",
      "text": "So Jesse took some loaves of bread, a bag with wine in it, and a young goat. He put them on the back of a donkey and he sent them to Saul with his son David."
    },
    {
      "verse": "21",
      "text": "David went to Saul. He became Saul's servant. Saul loved David. David carried Saul's armour for him."
    },
    {
      "verse": "22",
      "text": "Then Saul sent a message to Jesse. He said, ‘I am very pleased with David. Let him stay here as my servant. ’"
    },
    {
      "verse": "23",
      "text": "So, when the evil spirit brought trouble to Saul, David made music on his harp. Then Saul would feel happier and the evil spirit would leave him."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "The Philistine army came together. They were ready to fight the Israelites. They met together near Socoh, a town in Judah. They put up their tents at Ephes Dammim between Socoh and Azekah."
    },
    {
      "verse": "2",
      "text": "Saul and the Israelite army put up their tents in the valley of Elah. The soldiers prepared to fight against the Philistines."
    },
    {
      "verse": "3",
      "text": "The Philistines were standing on one hill. The Israelites were on another hill. The valley was between the two armies."
    },
    {
      "verse": "4",
      "text": "The Philistines had a strong, brave soldier. His name was Goliath and he came from a town called Gath. He was nearly three metres tall!"
    },
    {
      "verse": "5",
      "text": "He wore a helmet and armour that were made of bronze. The armour for his body weighed about 57 kilograms."
    },
    {
      "verse": "6",
      "text": "He had pieces of bronze to protect his legs. He had a bronze sword that he tied on his back."
    },
    {
      "verse": "7",
      "text": "He also carried a heavy spear. It was as thick as a tree. The iron point on the spear weighed about seven kilograms. A man who carried Goliath's shield walked in front of him."
    },
    {
      "verse": "8",
      "text": "Goliath stood up and he shouted to the Israelite soldiers, ‘Why have you all got ready to fight against us? I am the great soldier of the Philistine army. You serve Saul as his soldiers. Is that not true? So you must choose one of your men to come and fight against me."
    },
    {
      "verse": "9",
      "text": "If he can kill me in a fight, we Philistines will become your slaves. But if I knock him down and I kill him, then you Israelites will become our slaves. ’"
    },
    {
      "verse": "10",
      "text": "Then Goliath said, ‘I am not afraid of any of your soldiers! Choose one of your men and we will fight against each other. ’"
    },
    {
      "verse": "11",
      "text": "King Saul and all the Israelite soldiers heard what Goliath said. It made them very upset and afraid."
    },
    {
      "verse": "12",
      "text": "At this time, David's father Jesse was a very old man. Jesse belonged to the clan of Ephrathah. He came from Bethlehem town in Judah. He had e ight sons."
    },
    {
      "verse": "13",
      "text": "Jesse's three oldest sons had joined Saul's army to fight the war. They were Eliab, Jesse's oldest son, his second son, Abinadab, and his third son, Shammah."
    },
    {
      "verse": "14",
      "text": "David was Jesse's youngest son. While Jesse's three oldest sons were in Saul's army,"
    },
    {
      "verse": "15",
      "text": "David would sometimes leave Saul and go back home to Bethlehem. He did that to take care of his father's sheep."
    },
    {
      "verse": "16",
      "text": "days, Goliath would stand up and insult the Israelite army every morning and every evening."
    },
    {
      "verse": "17",
      "text": "One day, Jesse said to his son David, ‘Take some food to your brothers in the army. Here is a large bag of grain that we have cooked, and ten loaves of bread. Take them quickly to the army camp."
    },
    {
      "verse": "18",
      "text": "Also take these ten pieces of cheese to the officer who leads their group of soldiers. Find out whether your brothers are well. Bring something back to me to show how they are."
    },
    {
      "verse": "19",
      "text": "They are in Elah Valley with Saul and the Israelite army, where they are fighting against the Philistines. ’"
    },
    {
      "verse": "20",
      "text": "So David got up early the next morning. He left his father's sheep with another shepherd to take care of them. He did what his father had told him to do. He took the food to give to his brothers. When David arrived at the camp of the Israelite army, the soldiers were going out to fight. They were shouting their war songs while they went."
    },
    {
      "verse": "21",
      "text": "The Israelite army and the Philistine army stood in their places ready for the fight. They looked towards each other across the valley."
    },
    {
      "verse": "22",
      "text": "David gave his gifts to the officer who took care of the army's food. Then he ran to the place where the Israelite soldiers were standing. He said ‘hello’ to his brothers to see if they were well."
    },
    {
      "verse": "23",
      "text": "While David was talking to his brothers, Goliath marched out from the Philistine army. He was the great Philistine soldier from Gath. As he came, Goliath was insulting the Israelites as he did every day. David heard what he said."
    },
    {
      "verse": "24",
      "text": "When all the Israelite soldiers saw Goliath, they were very afraid. They ran away from him."
    },
    {
      "verse": "25",
      "text": "The Israelites said to each other, ‘Look at this man! He is so strong! He comes every day to insult us. King Saul will give great riches to any man who can kill Goliath. The king will give his daughter to that man, for him to marry her. His family will never again have to pay taxes to the king. ’"
    },
    {
      "verse": "26",
      "text": "David asked the men who were standing near him, ‘If someone kills this Philistine soldier and takes away the shame from Israel, what gift will he get? He is an unclean Philistine! He must stop insulting the army of our God, who lives for ever. ’"
    },
    {
      "verse": "27",
      "text": "The men then told David what the king had promised to do. They said, ‘This is what the king will do to help the man who kills that Philistine soldier. ’"
    },
    {
      "verse": "28",
      "text": "When David was speaking with the soldiers, his oldest brother, Eliab, heard him. He became angry with David. He asked David, ‘Why have you come here? You should be taking care of a few sheep in the wilderness. Who is taking care of them now? I know how proud you are! I know about your wicked ideas! You came here only to watch the battle. ’"
    },
    {
      "verse": "29",
      "text": "David said, ‘Have I done anything wrong? I only asked a question. ’"
    },
    {
      "verse": "30",
      "text": "So David went away and he asked other people the same question. All the men gave him the same answer."
    },
    {
      "verse": "31",
      "text": "Some of the soldiers went to King Saul and they told him what David had said. Saul told David to come to him."
    },
    {
      "verse": "32",
      "text": "David said to King Saul, ‘We should not be afraid of this Philistine! I am your servant. I am ready to go and fight against him. ’"
    },
    {
      "verse": "33",
      "text": "Saul replied, ‘You could not fight against this strong Philistine. You are only a boy! He has been a brave soldier since he was a young man. ’"
    },
    {
      "verse": "34",
      "text": "But David said to Saul, ‘Sir, I have been a shepherd who takes care of his father's sheep. Sometimes a lion or a bear would come to take a lamb from among the sheep. So Saul said to David, ‘Then do it! I pray that the Lord will help you. ’"
    },
    {
      "verse": "35",
      "text": "Then I would chase after the lion or the bear. I would knock it down and I would save the lamb from its mouth. If the wild animal turned to attack me, I would take hold of its neck. Then I would hit it and kill it."
    },
    {
      "verse": "36",
      "text": "I have killed lions and bears like that. I will do the same to this unclean Philistine. He has insulted the army of our God, who lives for ever."
    },
    {
      "verse": "37",
      "text": "The Lord has kept me safe from lions and bears. He will also save me from the power of this Philistine soldier. ’So Saul said to David, ‘Then do it! I pray that the Lord will help you. ’"
    },
    {
      "verse": "38",
      "text": "Saul took his own clothes and armour and he put them on David. He put his bronze helmet on David's head. So David said to Saul, ‘I cannot wear all this armour to fight. I have not used armour before. ’ So David took it all off."
    },
    {
      "verse": "39",
      "text": "David tied Saul's sword on top of the armour. Then he tried to walk. But he had not worn heavy armour like that before. So David said to Saul, ‘I cannot wear all this armour to fight. I have not used armour before. ’ So David took it all off."
    },
    {
      "verse": "40",
      "text": "Instead, David picked up his shepherd's stick. He picked up five round stones from the stream. He put them in the pocket of his shepherd's bag. He held his sling in his hand. Then he walked towards the Philistine soldier."
    },
    {
      "verse": "41",
      "text": "The Philistine slowly walked towards David. The man who was carrying his shield walked in front of him."
    },
    {
      "verse": "42",
      "text": "As he came nearer, the Philistine looked carefully at David. He saw that David was no more than a healthy, handsome boy. That made him laugh at David."
    },
    {
      "verse": "43",
      "text": "He said to David, ‘Do you think that I am just a dog? Can you knock me down with a little stick? ’ Then he prayed to his gods that they would curse David."
    },
    {
      "verse": "44",
      "text": "The Philistine said to David, ‘Come nearer to me. I will feed the birds and the wild animals with your dead body. ’"
    },
    {
      "verse": "45",
      "text": "David said to him, ‘You have come to fight against me with a sword, a knife and a spear. But I come to fight against you with the authority of the Lord Almighty. He is the God who leads Israel's army, and you have insulted him!"
    },
    {
      "verse": "46",
      "text": "Today the Lord will make me strong to win against you. I will knock you down and I will cut off your head. Today I will feed the birds and the wild animals with the dead bodies of the Philistine soldiers. Then everyone on the earth will know that there is a God who takes care of Israel."
    },
    {
      "verse": "47",
      "text": "The Lord does not need swords or spears to save his people. Everyone here will soon know that! The Lord is the one who fights our battles. He will put you under our power. ’"
    },
    {
      "verse": "48",
      "text": "The Philistine soldier started to move nearer to David to attack him. David ran forward quickly to fight against him."
    },
    {
      "verse": "49",
      "text": "David reached into his bag and he took out a stone. He put the stone into his sling and he threw it. The stone hit the Philistine man's head, above his eyes. It went in very deep. Goliath fell down with his face on the ground."
    },
    {
      "verse": "50",
      "text": "In that way, David used a sling and a stone to win against the Philistine soldier. He knocked down the Philistine and he killed him. And David did not even hold a sword in his hand! The Philistines saw that their best soldier was now dead. So they ran away."
    },
    {
      "verse": "51",
      "text": "David then ran and stood over Goliath. He pulled Goliath's sword out and he killed him. Then he used it to cut off Goliath's head. The Philistines saw that their best soldier was now dead. So they ran away."
    },
    {
      "verse": "52",
      "text": "When the soldiers from Israel and Judah saw what had happened, they chased after the Philistines. They shouted their war song as they ran. They chased the Philistines all the way to Gath, and then to the gates of Ekron town. The dead bodies of the Philistine soldiers were lying everywhere on the road to Shaaraim, as far as Gath and Ekron."
    },
    {
      "verse": "53",
      "text": "When the Israelite soldiers had finished chasing and killing the Philistines, they returned. They went into the Philistines' camp and they took their things for themselves."
    },
    {
      "verse": "54",
      "text": "David picked up Goliath's head to take it to Jerusalem. But he put Goliath's weapons in his own tent."
    },
    {
      "verse": "55",
      "text": "Saul had watched David when he went out to fight the strong Philistine soldier. Saul said to Abner, the leader of his army, ‘Tell me Abner, who is that young man? Who is his father? ’Abner replied, ‘My king, I cannot tell you a lie. I do not know who he is. ’"
    },
    {
      "verse": "56",
      "text": "The king said, ‘You must find out the name of that man's father. ’"
    },
    {
      "verse": "57",
      "text": "When David returned after he had killed Goliath, Abner took him to Saul. David was still holding Goliath's head in his hand."
    },
    {
      "verse": "58",
      "text": "Saul asked him, ‘Young man, who is your father? ’ David answered, ‘I am the son of your servant Jesse, who lives in Bethlehem. ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "David finished talking with Saul. After that, Saul's son Jonathan became a very good friend of David. Jonathan loved David as much as he loved his own life."
    },
    {
      "verse": "2",
      "text": "Saul kept David with him from that day. He did not let David go home to his father's house."
    },
    {
      "verse": "3",
      "text": "Jonathan made a special promise to be David's friend, because he loved David as much as he loved his own life."
    },
    {
      "verse": "4",
      "text": "Jonathan took off his coat and he gave it to David. He also gave his armour to David, as well as his sword, his bow and his belt."
    },
    {
      "verse": "5",
      "text": "David did whatever Saul asked him to do. And he always did it well. So Saul made David an officer to lead his army. That made the soldiers happy, and it also pleased Saul's officers."
    },
    {
      "verse": "6",
      "text": "After David had killed the Philistine, Goliath, he and the soldiers returned to their homes. Women came out from all the towns in Israel to meet King Saul. The women were happy as they sang songs and they danced. They made music with tambourines and lyres. ‘Saul has killed thousands of his enemies. And David has killed tens of thousands of his enemies. ’"
    },
    {
      "verse": "7",
      "text": "They sang this song while they danced:‘Saul has killed thousands of his enemies. And David has killed tens of thousands of his enemies. ’"
    },
    {
      "verse": "8",
      "text": "Saul did not like this song. He became very angry. He thought, ‘The women say that David has killed tens of thousands of men. But they say that I have only killed thousands of men. They will soon want David to be their king. ’"
    },
    {
      "verse": "9",
      "text": "After that, Saul was jealous of David and he watched David carefully."
    },
    {
      "verse": "10",
      "text": "The next day God caused an evil spirit to come and control Saul. Saul started to prophesy in his house. David was making music on his harp as he did every day. Saul had a spear in his hand."
    },
    {
      "verse": "11",
      "text": "He threw the spear at David. He thought, ‘I will hit David so that it fixes him to the wall. ’ He tried to do this twice, but David moved out of the way."
    },
    {
      "verse": "12",
      "text": "The Lord was with David. But the Lord had left Saul. So Saul was afraid of David."
    },
    {
      "verse": "13",
      "text": "So Saul sent David away from him. He made David the leader of 1, 000 soldiers. David led the soldiers into battles, but he always came back again."
    },
    {
      "verse": "14",
      "text": "David won all his fights because the Lord was with him."
    },
    {
      "verse": "15",
      "text": "Saul saw that David was a great soldier. So he became more afraid of David."
    },
    {
      "verse": "16",
      "text": "All the people in Israel and Judah loved David because he led the army in their battles."
    },
    {
      "verse": "17",
      "text": "Saul said to David, ‘Here is my oldest daughter Merab. I will let you marry her. But you must be a brave soldier and you must fight battles for the Lord. ’ Saul thought to himself, ‘I will not have to kill David myself. The Philistines will do that. ’"
    },
    {
      "verse": "18",
      "text": "But David said to Saul, ‘I am not an important person. My family and my father's clan are not important either. I do not deserve to marry the king's daughter. ’"
    },
    {
      "verse": "19",
      "text": "When the time came for Merab to marry David, Saul told her to marry a different man. He gave her to Adriel from Meholah to be his wife."
    },
    {
      "verse": "20",
      "text": "Saul had another daughter, Michal, and she loved David. When somebody told Saul about this, he was very happy."
    },
    {
      "verse": "21",
      "text": "He thought, ‘I will let David marry her. I will use her as a trap that will catch him. I will give the Philistines a chance to kill him. ’ So Saul said to David, ‘Now you have another chance to marry one of my daughters. ’"
    },
    {
      "verse": "22",
      "text": "Saul told his servants to say secretly to David, ‘The king is pleased with you. His servants all like you. You should now marry the king's daughter. ’"
    },
    {
      "verse": "23",
      "text": "Saul's servants said this to David. But David replied, ‘It is a great honour for someone to marry the king's daughter. But I am poor. I am not important enough. ’"
    },
    {
      "verse": "24",
      "text": "Saul's servants told him what David had said. In this way, Saul thought that he would use the Philistines to kill David."
    },
    {
      "verse": "25",
      "text": "Saul said, ‘Tell David this: The king does not want David to pay money to marry the king's daughter. He can pay for her with the foreskins of 100 dead Philistines. Saul wants David to punish his enemies. ’In this way, Saul thought that he would use the Philistines to kill David."
    },
    {
      "verse": "26",
      "text": "Saul's servants told David what Saul wanted. It made David happy to think that he could marry the king's daughter. Before the time for the wedding arrived,"
    },
    {
      "verse": "27",
      "text": "David and his men left their homes. They went and they killed 200 Philistines. David brought all their foreskins to Saul. David gave them to Saul so that he could marry the king's daughter. So Saul agreed to let David marry his daughter Michal."
    },
    {
      "verse": "28",
      "text": "Saul realized that the Lord was with David. He knew that his daughter Michal loved David."
    },
    {
      "verse": "29",
      "text": "So Saul became even more afraid of David. Saul was David's enemy for the rest of his life."
    },
    {
      "verse": "30",
      "text": "The Philistine army continued to march out and attack the Israelites. Every time that they fought, David won more fights than any of Saul's other officers. So David became very famous."
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "Saul told his son Jonathan and all his servants to kill David. But Jonathan liked David very much."
    },
    {
      "verse": "2",
      "text": "So he told David, ‘My father Saul is trying to kill you. Be careful tomorrow morning. Hide in a secret place and stay there."
    },
    {
      "verse": "3",
      "text": "I will go out with my father. I will stand with him in the field where you are hiding. I will talk to him about you. Then I will tell you what he says. ’"
    },
    {
      "verse": "4",
      "text": "Jonathan spoke to his father Saul. He said good things about David. He said to Saul, ‘The king should not do anything bad against David. David is your servant. He has not done anything that is bad against you. Everything that he does really helps you."
    },
    {
      "verse": "5",
      "text": "David was not afraid to die when he fought against the Philistine, Goliath. When David killed Goliath, the Lord helped Israel to win a great battle. When you saw it, you were very happy. So why do you now want to kill David? He is not guilty of anything that is wrong. You have no reason to kill him. ’"
    },
    {
      "verse": "6",
      "text": "Saul agreed with Jonathan. He made a promise in the Lord's name that he would not kill David."
    },
    {
      "verse": "7",
      "text": "Then Jonathan called to David. He told David everything that the king had said. Jonathan took David back to Saul. So David served King Saul as he had done before."
    },
    {
      "verse": "8",
      "text": "The war with the Philistines started again. David went out with his soldiers to fight against them. He attacked them so strongly that the Philistine soldiers ran away."
    },
    {
      "verse": "9",
      "text": "Then the Lord caused an evil spirit to control Saul. Saul was sitting in his house. He had a spear in his hand. David was making music with his harp."
    },
    {
      "verse": "10",
      "text": "Saul threw his spear at David. He wanted to fix David to the wall. But David moved out of the way and the spear hit the wall. That night, David ran away to escape from Saul."
    },
    {
      "verse": "11",
      "text": "Saul sent some of his servants to watch David's house. Saul told them to kill David when he came out in the morning. But David's wife Michal warned him. She said, ‘You must run away tonight. If you do not escape, tomorrow you will die! ’"
    },
    {
      "verse": "12",
      "text": "So Michal helped David to leave the house through a window. He ran away and he escaped."
    },
    {
      "verse": "13",
      "text": "Then Michal took an idol and she put it on the bed. She covered the idol with a blanket and she put a pillow of goat's hair at its head."
    },
    {
      "verse": "14",
      "text": "Saul sent some of his men to take hold of David. Michal told them that David was ill."
    },
    {
      "verse": "15",
      "text": "Saul then told the men to go back to David's house. He said to them, ‘Bring David to me on his bed. Then I will kill him. ’"
    },
    {
      "verse": "16",
      "text": "The men returned to David's house. They found the idol on the bed and the pillow of goat's hair at its head."
    },
    {
      "verse": "17",
      "text": "Saul said to Michal, ‘You have deceived me! You have helped my enemy to escape! ’ Michal said to him, ‘David told me that I must help him to escape. He said that he would kill me if I did not help him. ’"
    },
    {
      "verse": "18",
      "text": "David ran away and he escaped from Saul. He went to visit Samuel at Ramah. David told Samuel everything that Saul had done to him. Then David and Samuel went to live in Naioth."
    },
    {
      "verse": "19",
      "text": "Somebody told Saul that David was living at Naioth in Ramah."
    },
    {
      "verse": "20",
      "text": "So Saul sent men to take hold of David. When the men arrived, they saw a group of prophets. Samuel was their leader. They were all prophesying. Then the Spirit of God came on Saul's men. They also started to prophesy."
    },
    {
      "verse": "21",
      "text": "When people told Saul about this, he sent more men to Naioth. But they prophesied too. So Saul sent a third group of men. These men also started to prophesy."
    },
    {
      "verse": "22",
      "text": "Then Saul himself went to Ramah. He went as far as the large well at Secu. He asked the people, ‘Where are Samuel and David? ’ The people replied, ‘They are at Naioth in Ramah. ’"
    },
    {
      "verse": "23",
      "text": "Saul went to Naioth. The Spirit of God came on him also. He started to prophesy as he walked towards Naioth."
    },
    {
      "verse": "24",
      "text": "When he met Samuel, he took off his clothes and he continued to prophesy. He lay on the ground with no clothes all that day and all that night. So people still say, ‘Has Saul really become one of the prophets? ’"
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "Then David ran away from Naioth at Ramah. He went to Jonathan and he asked him, ‘What bad things have I done? What have I done to hurt your father? Why is he trying to kill me? ’"
    },
    {
      "verse": "2",
      "text": "Jonathan replied, ‘No. You will not die. My father tells me everything that he does, even the little things. So it is not true that he is trying to kill you. He would not hide this from me. ’"
    },
    {
      "verse": "3",
      "text": "But David answered, ‘Your father knows that you like me very much. He has decided that he will not tell you. He does not want to make you upset. I promise that my words are true, as truly as the Lord lives and you live. I know that I am very near to death. ’"
    },
    {
      "verse": "4",
      "text": "Jonathan said to David, ‘I will do anything that you want me to do for you. ’"
    },
    {
      "verse": "5",
      "text": "David said to Jonathan, ‘Tomorrow we have a special meal because of the new moon. I should go and eat this meal with the king. Instead, let me go and hide in the field. I will stay there until the third evening."
    },
    {
      "verse": "6",
      "text": "Your father may see that I am not at the meal. If he does, say to him, “David asked me to let him go to his home in Bethlehem. His family offer a sacrifice there at this time every year. ”"
    },
    {
      "verse": "7",
      "text": "Your father may say, “That is good. ” If he says that, I will know that I am safe. But if he becomes very angry, we will know that he has decided to hurt me."
    },
    {
      "verse": "8",
      "text": "Jonathan, please show that you love me. The Lord knows about the promise that you made, to be my friend. If I am guilty of a sin, please kill me yourself. Do not let your father kill me. ’"
    },
    {
      "verse": "9",
      "text": "Jonathan said, ‘No, that will never happen! If I ever find out that my father wants to kill you, I will surely tell you. ’"
    },
    {
      "verse": "10",
      "text": "David asked Jonathan, ‘If your father answers you in an angry way, who will tell me? ’"
    },
    {
      "verse": "11",
      "text": "Jonathan said, ‘Come with me into the field. ’ So they went there together."
    },
    {
      "verse": "12",
      "text": "Then Jonathan said to David, ‘I make this promise to you, and the Lord, Israel's God, knows that it is true. Tomorrow or the next day I will find out what my father is thinking about you. If he is feeling friendly to you, I will send someone to tell you."
    },
    {
      "verse": "13",
      "text": "But if my father wants to hurt you, I will tell you clearly. I ask the Lord to punish me, if I do not tell you. I will help you to escape and be safe. I pray that the Lord will bless you, as he blessed my father."
    },
    {
      "verse": "14",
      "text": "While I am still alive, please be kind to me. Continue to love me, as the Lord loves his people. And if I die,"
    },
    {
      "verse": "15",
      "text": "continue to be kind to my family. Even when the Lord removes every one of your enemies from the earth, do not forget about my family. ’"
    },
    {
      "verse": "16",
      "text": "So Jonathan made an agreement with David's family. He said, ‘I am asking the Lord to destroy all David's enemies. ’"
    },
    {
      "verse": "17",
      "text": "Jonathan asked David to promise again that they would be friends. That was because Jonathan loved David as much as he loved his own life."
    },
    {
      "verse": "18",
      "text": "Then Jonathan said to David, ‘Tomorrow we will have the special meal because of the new moon. Nobody will be sitting in your seat, so people will know that you are not there."
    },
    {
      "verse": "19",
      "text": "The day after tomorrow, go back to the place where you hid the other time. Wait beside the rock called Ezel."
    },
    {
      "verse": "20",
      "text": "I will shoot three arrows towards the rock to see where they go."
    },
    {
      "verse": "21",
      "text": "Then I will send a boy to find the arrows. If you are not in danger I will say to the boy, “The arrows are on this side of you. Come and bring them here. ” That will mean that you are safe. You can then come out from the place where you are hiding. As surely as the Lord lives, I promise that you will not be in trouble."
    },
    {
      "verse": "22",
      "text": "But if I say to the boy, “Look, the arrows are beyond you, ” you must run away. It will mean that the Lord has sent you away."
    },
    {
      "verse": "23",
      "text": "But never forget the promise that we have made to each other. The Lord will make sure that we are faithful to each other. ’"
    },
    {
      "verse": "24",
      "text": "So David hid in the field. At the time of the new moon, the king sat down to eat the special meal."
    },
    {
      "verse": "25",
      "text": "He sat beside the wall in his usual place. Jonathan sat with his face towards him. Abner sat beside the king. David's seat was empty."
    },
    {
      "verse": "26",
      "text": "Saul did not say anything about it that day. He thought, ‘Perhaps something has happened to David that has made him unclean. I am sure that is why he is not here. ’"
    },
    {
      "verse": "27",
      "text": "The next day after the new moon, David's seat was still empty at the meal. So Saul said to his son Jonathan, ‘Why has Jesse's son not come to the meal? He did not come yesterday or today. ’"
    },
    {
      "verse": "28",
      "text": "Jonathan answered, ‘David asked me very strongly to let him go to Bethlehem."
    },
    {
      "verse": "29",
      "text": "He said, “Please let me go. My family is offering a sacrifice to God in the town. My brother told me that I must be there. If you agree as my friend, let me go to visit my brothers. ” That is why David has not come to eat this meal with the king. ’"
    },
    {
      "verse": "30",
      "text": "Saul became very angry with Jonathan. He said, ‘You stupid man! I see that you have turned against me! You have become a friend of that son of Jesse. You have brought shame on yourself. Your mother should be ashamed that she gave birth to you!"
    },
    {
      "verse": "31",
      "text": "You will never rule as king while that son of Jesse is still alive. Send men to go and bring him to me now. He must die! ’"
    },
    {
      "verse": "32",
      "text": "Jonathan said to his father, King Saul, ‘Why must David die? What wrong thing has he done? ’"
    },
    {
      "verse": "33",
      "text": "Then Saul threw his spear at Jonathan and tried to kill him. So Jonathan knew that his father had decided to kill David."
    },
    {
      "verse": "34",
      "text": "Jonathan was very angry. He got up from the table. He did not eat anything on that second day of the special meal. He was very upset because his father had insulted David."
    },
    {
      "verse": "35",
      "text": "The next morning, Jonathan went out to the field to meet David. He took a young boy with him."
    },
    {
      "verse": "36",
      "text": "He said to the boy, ‘I will shoot some arrows. You must run and find them. ’ While the boy was running, Jonathan shot an arrow beyond him."
    },
    {
      "verse": "37",
      "text": "The boy ran to the place where the arrow had reached. Jonathan shouted to him, ‘I think that the arrow is beyond you. ’"
    },
    {
      "verse": "38",
      "text": "Then he shouted, ‘Hurry now! Go quickly. Do not wait. ’ The boy picked up the arrow and he brought it back to Jonathan."
    },
    {
      "verse": "39",
      "text": "(The boy did not understand what this meant. Only Jonathan and David knew. )"
    },
    {
      "verse": "40",
      "text": "Then Jonathan gave his bow and arrows back to the boy. He said to the boy, ‘Go now and take these things back to the town. ’"
    },
    {
      "verse": "41",
      "text": "When the boy had left, David came out from beside the rock. He went down on his knees in front of Jonathan. He bent down on the ground three times. Then David and Jonathan kissed each other and they wept. David wept even more than Jonathan did."
    },
    {
      "verse": "42",
      "text": "Jonathan said to David, ‘Go now and God will keep you safe. We have promised each other in the Lord's name that we will always be friends. The Lord will watch us to make sure that we always keep this promise. He will watch our descendants too, for ever. ’Then David left. Jonathan returned to the town."
    },
    {
      "verse": "43",
      "text": "Then David left. Jonathan returned to the town."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "David went to visit Ahimelech the priest. He lived in the town of Nob. Ahimelech shook with fear when he saw David. He asked David, ‘Why are you alone? Why is nobody with you? ’"
    },
    {
      "verse": "2",
      "text": "David answered, ‘The king has asked me to do something special. He said to me, “Do not tell anyone where I have sent you. Do not say what I have told you to do. ” So I have sent my soldiers to wait for me at a certain place."
    },
    {
      "verse": "3",
      "text": "Do you have anything to eat here? Give me five loaves of bread or anything else that you have. ’"
    },
    {
      "verse": "4",
      "text": "The priest answered David, ‘I do not have any ordinary bread that I can give to you. There is only the special holy bread. You can take it for your men to eat only if they have not had sex with women. ’"
    },
    {
      "verse": "5",
      "text": "David replied, ‘We have not been near women since we left our homes. The young men always keep themselves clean, even on ordinary journeys. So for today's important journey, they will certainly be clean. ’"
    },
    {
      "verse": "6",
      "text": "So the priest gave the holy bread to David because he did not have any other bread. This was the bread which had been on the table in the Lord's tent. The priest would take it from there each day and he would put hot, fresh bread in its place."
    },
    {
      "verse": "7",
      "text": "One of Saul's servants was there that day. His name was Doeg. He came from Edom. He was the leader of Saul's shepherds. He was staying in Nob to make offerings to the Lord."
    },
    {
      "verse": "8",
      "text": "David asked the priest, Ahimelech, ‘Is there any sword or spear here that I could take? The king sent me quickly to do an important job. So I left home without my sword or any other weapon. ’"
    },
    {
      "verse": "9",
      "text": "Ahimelech answered, ‘The sword of Goliath the Philistine is here. After you killed him in the valley of Elah, we kept the sword here. We covered it with a cloth and we put it behind the ephod. If you want it, you can take it. We do not have any other weapon except that one. ’David said, ‘Give it to me. There is no sword as good as that one. ’ David said, ‘Give it to me. There is no sword as good as that one. ’"
    },
    {
      "verse": "10",
      "text": "So on that day, David escaped from Saul. He went to Gath and he visited King Achish there. “Saul has killed thousands of his enemies. But David has killed tens of thousands of his enemies. ” ’"
    },
    {
      "verse": "11",
      "text": "The servants of King Achish said to him, ‘This man is David, the king of his country! The people sing this song about him when they dance:“Saul has killed thousands of his enemies. But David has killed tens of thousands of his enemies. ” ’"
    },
    {
      "verse": "12",
      "text": "David thought carefully about what King Achish's servants were saying. It caused him to be very afraid of Achish, king of Gath."
    },
    {
      "verse": "13",
      "text": "So when David was with them, he pretended to be crazy. He made marks with his fingers on the doors of the city's gate. He let water run out of his mouth and go down his beard."
    },
    {
      "verse": "14",
      "text": "King Achish said to his servants, ‘Look at this man! He is completely crazy! Why did you bring him to me?"
    },
    {
      "verse": "15",
      "text": "I have enough fools around me already. I do not need to see this crazy man as well. Keep him away from my house. ’"
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "Then David left Gath and he went to a cave near Adullam. His brothers and his father's family discovered where he had gone. So they all went to visit him."
    },
    {
      "verse": "2",
      "text": "Everybody who had trouble went to stay with David. People who had debts and those who were angry also went to him. About 400 men went to be with David and he became their leader."
    },
    {
      "verse": "3",
      "text": "David then went to Mizpah, a town in the land of Moab. David said to the king of Moab, ‘Please let my father and my mother stay with you for a short time. I need to learn what God will do to help me. ’"
    },
    {
      "verse": "4",
      "text": "So David left his parents to stay with the king of Moab. They stayed with the king all the time that David was hiding near there."
    },
    {
      "verse": "5",
      "text": "The prophet Gad said to David, ‘Do not stay and hide here. Go to the land of Judah. ’ So David left his safe place and he went to Hereth forest."
    },
    {
      "verse": "6",
      "text": "One day, Saul was on the hill near Gibeah. He was sitting under a tamarisk tree. He was holding a spear. All his officers stood round him. Then someone told Saul that they knew where David and his men were hiding."
    },
    {
      "verse": "7",
      "text": "Saul said to his officers, ‘Listen to me, you men of Benjamin's tribe. Do you really think that this son of Jesse will give fields and vineyards to all of you? Will he make you all officers and leaders in his army? No!"
    },
    {
      "verse": "8",
      "text": "So why are you trying to deceive me? None of you told me when my own son promised to be a friend of this son of Jesse. You do not feel sorry for me. Now my son is helping one of my own servants to attack me! Yes, he is waiting for his chance to kill me! ’"
    },
    {
      "verse": "9",
      "text": "Doeg, the man from Edom, was standing there with Saul's officers. He said, ‘I saw that son of Jesse when he came to Nob town. He visited Ahitub's son, Ahimelech."
    },
    {
      "verse": "10",
      "text": "Ahimelech asked the Lord what David should do. Then he gave some food and the sword of Goliath the Philistine to David. ’"
    },
    {
      "verse": "11",
      "text": "Then King Saul told his men to fetch Ahitub's son, Ahimelech, the priest. They also brought all his father's family who were priests at Nob. They all came to the king."
    },
    {
      "verse": "12",
      "text": "Saul said to Ahimelech, ‘Listen to me, son of Ahitub. ’ Ahimelech answered, ‘I am listening, my king. ’"
    },
    {
      "verse": "13",
      "text": "Saul said to him, ‘You and this son of Jesse have been trying to kill me! You gave him bread and a sword. You prayed to God on his behalf. Now, at this moment, he is waiting for his chance to kill me! ’"
    },
    {
      "verse": "14",
      "text": "Ahimelech answered the king, ‘David is the most faithful servant that you have. He is your daughter's husband. He is the captain of the soldiers who keep you safe. Everyone in your house respects him."
    },
    {
      "verse": "15",
      "text": "I have often prayed to God on David's behalf. This was not the first time. King Saul, do not say that my family or I have done anything wrong. I do not know anything about what is happening. ’"
    },
    {
      "verse": "16",
      "text": "But King Saul said, ‘Ahimelech, you must die, together with all your family. ’"
    },
    {
      "verse": "17",
      "text": "Then the king said to the guards who were near him, ‘Now kill the Lord's priests! They have been helping David. They knew that he was running away from me. But they did not tell me. ’ But the king's officers refused to hurt the Lord's priests."
    },
    {
      "verse": "18",
      "text": "So the king said to Doeg, ‘You must kill the priests. ’ So Doeg, the man from Edom, killed the priests that same day. He killed 85 priests who wore linen ephods."
    },
    {
      "verse": "19",
      "text": "He also killed all the people in Nob, which was the town where the priests lived. He killed the men and women, children and babies. He also killed the cows, donkeys and sheep."
    },
    {
      "verse": "20",
      "text": "But one man called Abiathar escaped. He was one of Ahimelech's sons. Abiathar ran away to see David."
    },
    {
      "verse": "21",
      "text": "Abiathar told David that Saul had killed the Lord's priests."
    },
    {
      "verse": "22",
      "text": "David said to him, ‘When I went to see your father at Nob, Doeg was there too. I knew that he would tell Saul about me. So I have caused the death of everybody in your father's family."
    },
    {
      "verse": "23",
      "text": "Please stay here with me. Do not be afraid. Saul wants to kill you and he wants to kill me too. You will be safe with me. ’"
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "The Philistines were attacking the town of Keilah. They were taking away the grain that the people had brought from their fields. Someone told David about this. The Lord answered him, ‘Go and attack the Philistines. Save Keilah town. ’"
    },
    {
      "verse": "2",
      "text": "So David asked the Lord, ‘Should I go and attack those Philistines? ’The Lord answered him, ‘Go and attack the Philistines. Save Keilah town. ’"
    },
    {
      "verse": "3",
      "text": "But David's men said to him, ‘We are afraid when we are here in Judah. If we go to attack the Philistine army at Keilah, we will be in even more danger. ’"
    },
    {
      "verse": "4",
      "text": "So David asked the Lord again. The Lord answered again, ‘Go to Keilah. I will put the Philistines under your power. ’"
    },
    {
      "verse": "5",
      "text": "So David and his men went to Keilah. They fought against the Philistines and they killed many of them. Also, they took away their animals. In that way, David saved the people who lived in Keilah."
    },
    {
      "verse": "6",
      "text": "When Ahimelech's son Abiathar had run away, he had come to David at Keilah. And he had brought the priests' ephod with him."
    },
    {
      "verse": "7",
      "text": "Someone told Saul that David was now at Keilah. Saul said, ‘God has now put David under my power. David has gone into a town that has high walls and strong gates. He will not be able to leave that place. ’"
    },
    {
      "verse": "8",
      "text": "So Saul called his army to join him. They prepared to go to Keilah and to attack David and his men."
    },
    {
      "verse": "9",
      "text": "Somebody told David that Saul was preparing to attack him. David said to Abiathar the priest, ‘Bring the ephod here. ’"
    },
    {
      "verse": "10",
      "text": "David prayed, ‘Lord, Israel's God. I am your servant. I have heard news that Saul is preparing to attack Keilah. He wants to destroy this town because I am here."
    },
    {
      "verse": "11",
      "text": "Will the leaders in Keilah give me to Saul? Will Saul really come here, as I have heard that he will? Lord, Israel's God, please tell me what will happen. ’ The Lord said, ‘Saul will come. ’"
    },
    {
      "verse": "12",
      "text": "David asked the Lord again, ‘Will the leaders in Keilah give me and my men to Saul? ’ The Lord said, ‘They will do that. ’"
    },
    {
      "verse": "13",
      "text": "men left Keilah. They moved around to stay in different places. People told Saul that David had escaped from Keilah. So Saul decided that he would not go there."
    },
    {
      "verse": "14",
      "text": "David stayed in places where he would be safe. They were in the desert, and in the hill country of Ziph. Saul always tried to find David. But God did not let Saul catch David."
    },
    {
      "verse": "15",
      "text": "David was at Horesh in the Ziph Desert. He heard news that Saul was coming there to kill him."
    },
    {
      "verse": "16",
      "text": "Saul's son, Jonathan, went to visit David at Horesh. He told David to be brave, because God would keep him safe."
    },
    {
      "verse": "17",
      "text": "Jonathan said to David, ‘Do not be afraid. My father will never be able to hurt you. You will be the next king to rule over Israel. I will be your most important officer. My father Saul also knows that is true. ’"
    },
    {
      "verse": "18",
      "text": "Jonathan and David promised again in the Lord's name that they would be faithful friends of one another. Then Jonathan went to his home. David stayed at Horesh."
    },
    {
      "verse": "19",
      "text": "Some people from Ziph went to visit Saul at Gibeah. They said to Saul, ‘David is hiding among our people. He is on Hakilah hill, south of Jeshimon. He is hiding in the Horesh hills."
    },
    {
      "verse": "20",
      "text": "Now, King Saul, we know that you want to catch David. So you can come to our land at any time. We will help you to catch him. ’"
    },
    {
      "verse": "21",
      "text": "Saul replied, ‘I ask the Lord to bless you, because you have been kind to me."
    },
    {
      "verse": "22",
      "text": "Do a bit more to help me now. Make sure that you know where he is. Find the people who have seen him there. I have heard that David is very clever."
    },
    {
      "verse": "23",
      "text": "Find all the places where he hides. When you know all about him, come back and tell me. Then I will come with you. If he is still in that region, I will surely find him. I will look through all the land of Judah and I will catch him. ’"
    },
    {
      "verse": "24",
      "text": "So the people returned to Ziph before Saul himself went there. David and his men were in the Maon Desert. This was south of Jeshimon, in the Jordan Valley."
    },
    {
      "verse": "25",
      "text": "Saul and his men started to look for David. But David heard about this. So he and his men went to hide at a great rock in the Maon Desert. When Saul heard about this, he and his men went into the Maon Desert to find David."
    },
    {
      "verse": "26",
      "text": "Saul and his men were going along one side of the mountain. David and his men were on the other side of the mountain. They were moving quickly to escape from Saul. Saul and his men were getting very near to David and his men. They would soon catch them."
    },
    {
      "verse": "27",
      "text": "But then a man arrived with a message for Saul. He said to Saul, ‘Come quickly. The Philistines are attacking our land! ’"
    },
    {
      "verse": "28",
      "text": "So Saul stopped chasing after David. Instead, he went to fight against the Philistines. So people call that place ‘The rock where they escaped’."
    },
    {
      "verse": "29",
      "text": "David left that place. He went to hide in the safe places at En Gedi."
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "When Saul had finished fighting against the Philistines, he returned to his home. Someone told him that David was in the desert at En Gedi."
    },
    {
      "verse": "2",
      "text": "So Saul chose 3, 000 of the best soldiers in Israel. They went to look for David and his men near Wild Goat Rocks."
    },
    {
      "verse": "3",
      "text": "Saul came to the place near the road where the shepherds keep their sheep. There was a cave near to this place. Saul went in there to use it as a toilet. David and his men were hiding at the back of the same cave."
    },
    {
      "verse": "4",
      "text": "David's men said to him, ‘This is the day that the Lord told you about! The Lord said to you, “I will give your enemy to you. Then you can decide what is the right thing to do to him. ” ’ So David stood up very quietly. He went and he cut off a small piece of cloth from Saul's coat. Saul did not know what had happened."
    },
    {
      "verse": "5",
      "text": "After that, David thought that he had done something wrong. He felt sorry that he had cut a piece of cloth from Saul's coat. Then Saul left the cave and he started to travel along the road."
    },
    {
      "verse": "6",
      "text": "David said to his men, ‘I ask the Lord to stop me doing anything wrong to my master. The Lord has chosen him to be Israel's king. I must never do anything to hurt him. He is the king that the Lord has chosen. ’"
    },
    {
      "verse": "7",
      "text": "David spoke like this to stop his men from attacking Saul. Then Saul left the cave and he started to travel along the road."
    },
    {
      "verse": "8",
      "text": "After that, David went out of the cave. He shouted to Saul, ‘My master and my king! ’ Saul looked behind him. David went down on his knees with his face on the ground to respect the king."
    },
    {
      "verse": "9",
      "text": "David said to Saul, ‘You should not listen to the people who say, “David wants to hurt you. ”"
    },
    {
      "verse": "10",
      "text": "You can see that the Lord has kept you safe today when I had a chance to hurt you in the cave. Some of my men wanted me to kill you, but I did not agree. I said, “I will not hurt my master, because the Lord has chosen him to be king. ”"
    },
    {
      "verse": "11",
      "text": "My father, look at what I have in my hand! It is a small piece of your coat. I cut this off the corner of your coat, but I did not kill you. So you must know that I do not want to do anything bad against you. I have not turned against you. I am not guilty of anything, but you are chasing after me so that you can kill me."
    },
    {
      "verse": "12",
      "text": "The Lord is the judge who will decide which of us is guilty. I pray that he will punish you for what you are doing to me. But I myself will never do anything to hurt you."
    },
    {
      "verse": "13",
      "text": "You know the proverb, “Evil people do evil things. ” But I will never try to hurt you."
    },
    {
      "verse": "14",
      "text": "You are Israel's king. So why are you chasing after someone like me? I am less important than a dead dog or a little fly!"
    },
    {
      "verse": "15",
      "text": "The Lord will be the judge to decide who is right. I pray that he will see that I am not guilty. I pray that he will save me from your power. ’"
    },
    {
      "verse": "16",
      "text": "When David stopped speaking, Saul said, ‘Is that really you, David my son? ’ Then Saul started to weep loudly."
    },
    {
      "verse": "17",
      "text": "He said to David, ‘You are a better man than I am. You have been kind to me even when I have tried to hurt you."
    },
    {
      "verse": "18",
      "text": "You have shown me today how kind you have been to me. The Lord gave you a chance to hurt me, but you did not kill me."
    },
    {
      "verse": "19",
      "text": "If someone catches his enemy, he does not let him escape. But you have not tried to hurt me today. So I ask that the Lord will bless you in return."
    },
    {
      "verse": "20",
      "text": "I know that you will be the king of Israel one day. The kingdom will be strong when you rule."
    },
    {
      "verse": "21",
      "text": "So promise me in the Lord's name that you will not kill any of my descendants. Please make sure that people do not forget my family's name. ’"
    },
    {
      "verse": "22",
      "text": "So David made a strong promise to Saul. Then Saul returned to his home. But David and his men went back to the place where they had been hiding."
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "Then Samuel died. All the Israelites met together and they were very sad. Then they buried Samuel at his home in Ramah. David went down to the Paran desert. David went down to the Paran desert."
    },
    {
      "verse": "4",
      "text": "While David was in the desert, he heard that Nabal was cutting the wool from his sheep."
    },
    {
      "verse": "5",
      "text": "So David sent ten young men to meet with Nabal. He said to them, ‘Go to Carmel and find Nabal. Tell him that David says “hello”."
    },
    {
      "verse": "6",
      "text": "Then give him this message: “We hope that you and your family are all well. We hope that everything you have is doing well."
    },
    {
      "verse": "7",
      "text": "David has heard that you are now cutting the wool from your sheep. When your shepherds were with us near Carmel, we did not hurt them. We did not take anything from them."
    },
    {
      "verse": "8",
      "text": "Your servants will tell you that, if you ask them. Now we have come to you at this special holiday time. So please be kind to the young men that David has sent to see you. They are your servants as well as his servants. Please give any extra food that you have to these young men and to your good friend David. ” ’"
    },
    {
      "verse": "9",
      "text": "David's men went to Carmel. They gave David's message to Nabal. They waited for Nabal to reply."
    },
    {
      "verse": "10",
      "text": "Nabal answered David's young men, ‘Who is this David? Do I know this son of Jesse? Many servants run away from their masters these days."
    },
    {
      "verse": "11",
      "text": "I have food and drink for the men who are cutting the wool from my sheep. I have cooked meat for them to eat. But I will not give anything to you. You might have come from anywhere! ’"
    },
    {
      "verse": "12",
      "text": "David's young men left Nabal. They returned to David and they told him everything that Nabal had said."
    },
    {
      "verse": "13",
      "text": "David said to his men, ‘Tie your swords onto your belts. ’ So they all did that. David put his sword on his belt too. About 400 men went with David. About 200 men stayed at their camp."
    },
    {
      "verse": "14",
      "text": "One of Nabal's servants spoke to Nabal's wife, Abigail. He said to her, ‘David sent some of his men from the desert to say “hello” to our master. But our master insulted them."
    },
    {
      "verse": "15",
      "text": "David's men have been very kind to us. When we were with them in the fields, they did not hurt us. They did not take anything from us the whole time that we were there."
    },
    {
      "verse": "16",
      "text": "They kept us safe while we took care of Nabal's sheep. They kept us safe all the time, during the day and at night."
    },
    {
      "verse": "17",
      "text": "So please think carefully about this. Decide what you can do. If you do nothing, there will be great trouble for our master and all his family and servants. He is such a wicked man that he will not listen to anyone. ’"
    },
    {
      "verse": "18",
      "text": "Abigail quickly got some food. She got 200 loaves of bread, two leather bags of wine, five sheep that she had cooked, and five jars of grain that she had cooked. She also got 100 blocks of raisins and 200 blocks of dried figs. She put all these things on some donkeys."
    },
    {
      "verse": "19",
      "text": "She said to her servants, ‘You go first and I will follow you. ’ But she did not tell her husband Nabal what she was doing."
    },
    {
      "verse": "20",
      "text": "Abigail rode her donkey along the path beside a mountain. Then she saw David and his men as they were coming towards her. So they all met each other."
    },
    {
      "verse": "21",
      "text": "David had just said to his men, ‘I kept Nabal's people and all his things safe in the desert. We did not take anything from him. But that has not helped us. I was kind to him, but he has done an evil thing to me in return."
    },
    {
      "verse": "22",
      "text": "I pray that God will punish me if I do not kill all the men in Nabal's family by tomorrow morning. ’"
    },
    {
      "verse": "23",
      "text": "When Abigail saw David, she quickly got off her donkey. She bent her body down low on the ground to respect David."
    },
    {
      "verse": "24",
      "text": "She lay down at his feet. She said to David, ‘My master, I am the one who is guilty. I am your servant. Please let me say something and please listen to me."
    },
    {
      "verse": "25",
      "text": "Please sir, do not think about that wicked man Nabal. His name means “fool” and he really is a fool. But as for me, I did not see the young men that you sent."
    },
    {
      "verse": "26",
      "text": "I know this as surely as the Lord lives and as surely as you live: The Lord has stopped you from killing anyone today. You could have done that, but he has not let you do it. I pray that God will punish all your enemies in the same way that he will punish Nabal."
    },
    {
      "verse": "27",
      "text": "My master, please accept these gifts that I have brought for you and for your men."
    },
    {
      "verse": "28",
      "text": "I am your servant. Please forgive me for any sin. I know that the Lord will always choose someone from your family to be Israel's king. The Lord will do that because you fight battles on his behalf. I pray that you will not do any evil thing in your whole life."
    },
    {
      "verse": "29",
      "text": "People may chase after you and try to kill you. But the Lord your God will always keep you safe. He will throw your enemies away like someone who throws a stone from his sling."
    },
    {
      "verse": "30",
      "text": "The Lord will surely do for you all the good things that he has promised to do. He will make you the ruler of the Israelites."
    },
    {
      "verse": "31",
      "text": "When that happens, you will not feel sorry for something bad that you might have done today. You could have killed people today for no good reason. You could have tried to punish these people yourself. So please remember me when the Lord has helped you to rule as king. ’"
    },
    {
      "verse": "32",
      "text": "David said to Abigail, ‘I praise the Lord, Israel's God. He has sent you to meet me here today."
    },
    {
      "verse": "33",
      "text": "I thank you for your wisdom. May the Lord bless you because of what you have done to help me. You have stopped me from killing people today. I would have punished these people myself."
    },
    {
      "verse": "34",
      "text": "But the Lord has not let me hurt you. As surely as the Lord, Israel's God, lives, I would have killed all the men in Nabal's family before dawn. But you came quickly to meet me. ’"
    },
    {
      "verse": "35",
      "text": "David accepted Abigail's gifts that she had brought with her. He said to her, ‘Go back to your home and do not be afraid. I have listened to what you have said. I will do what you have asked for. ’"
    },
    {
      "verse": "36",
      "text": "Abigail returned to her husband, Nabal. He was eating a big feast with people in his house. It was as good as a king's feast. Nabal was happy and drunk. So Abigail did not tell him anything until the next morning."
    },
    {
      "verse": "37",
      "text": "The next morning, Nabal was no longer drunk. So Abigail told him about everything that she had done. Nabal's heart failed. His body became like a stone."
    },
    {
      "verse": "38",
      "text": "About ten days after that, the Lord caused Nabal to die."
    },
    {
      "verse": "39",
      "text": "David heard the news that Nabal had died. He said, ‘I praise the Lord. He has shown that I was right. Nabal insulted me but the Lord has punished him for that. The Lord stopped me from doing an evil thing. Now he has punished Nabal for the evil thing that he did. ’Then David sent a message to Abigail to ask her to marry him."
    },
    {
      "verse": "40",
      "text": "David's servants went to Carmel. They said to Abigail, ‘David has sent us to you. We must take you back with us to become his wife. ’"
    },
    {
      "verse": "41",
      "text": "Abigail bent her body down low so that her face touched the ground. She said, ‘I am happy to be David's servant. I am ready to wash the feet of his servants. ’"
    },
    {
      "verse": "42",
      "text": "Abigail quickly prepared her donkey to go with David's men. She took with her five young girls to be her servants. Abigail went to David and she became his wife."
    },
    {
      "verse": "43",
      "text": "David had already married Ahinoam from Jezreel town. So these two women became his wives."
    },
    {
      "verse": "44",
      "text": "Saul's daughter Michal had been David's wife. But Saul had then given her to Palti as his wife. Palti was the son of Laish, who came from Gallim town."
    },
    {
      "verse": "2",
      "text": "There was a very rich man who lived at Maon. His name was Nabal. He was a descendant of Caleb. His wife's name was Abigail. She was wise and beautiful. But Nabal was a cruel man who did evil things."
    },
    {
      "verse": "3",
      "text": "Nabal had some land near Carmel. He had 3, 000 sheep and 1, 000 goats. He was with his men in Carmel as they cut the wool from his sheep. Nabal had some land near Carmel. He had 3, 000 sheep and 1, 000 goats. He was with his men in Carmel as they cut the wool from his sheep."
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "Some men from Ziph went to visit Saul at Gibeah. They said to him, ‘David is hiding on Hakilah hill, which is across the valley from Jeshimon. ’"
    },
    {
      "verse": "2",
      "text": "So Saul went to the desert of Ziph to look for David. He took 3, 000 strong Israelite soldiers with him."
    },
    {
      "verse": "3",
      "text": "Saul and his men arrived at Hakilah hill, near Jeshimon, where David was hiding. They put up their tents beside the road. David heard the news that Saul had followed him into the desert."
    },
    {
      "verse": "4",
      "text": "So David sent some men to see if that was true. They discovered that Saul had arrived at Hakilah."
    },
    {
      "verse": "5",
      "text": "One night, David went secretly to Saul's camp. Saul was asleep in the middle of the tents. The leader of his army, Ner's son Abner, was with him. He was asleep too. The army was all around them. David could see all this."
    },
    {
      "verse": "6",
      "text": "David spoke to two of his men. One of them was Ahimelech, a Hittite man. The other man was Abishai, who was Joab's brother (Zeruiah was their mother). David asked them, ‘Which one of you will go down into Saul's camp with me? ’Abishai said, ‘I will come with you. ’ Abishai said, ‘I will come with you. ’"
    },
    {
      "verse": "7",
      "text": "So David and Abishai went among Saul's army that night. They saw that Saul was asleep in the middle of the camp. He had pushed his spear into the ground near his head. Abner and the army were asleep around Saul."
    },
    {
      "verse": "8",
      "text": "Abishai said to David, ‘Tonight God has given your enemy into your power. I will push Saul's spear through his body and fix him to the ground. I will only have to do it once to kill him. I will not need to do it again. ’"
    },
    {
      "verse": "9",
      "text": "But David said to Abishai, ‘Do not kill Saul. He is the man that the Lord has chosen to be Israel's king. Anyone who attacks him will be guilty of a sin."
    },
    {
      "verse": "10",
      "text": "I know that the Lord himself will kill Saul one day. Saul may die when he has reached the age to die. Or someone may kill him in a battle. He will certainly come to his end."
    },
    {
      "verse": "11",
      "text": "But I ask the Lord to stop me from hurting him, because he is the Lord's chosen king. Take the spear and the jar of water that are near Saul's head. We must leave here now! ’"
    },
    {
      "verse": "12",
      "text": "So David took the spear and the jar of water from beside Saul's head. Then they left. Nobody saw them. Nobody knew that they had been in the camp. Nobody woke up. Saul's soldiers continued to sleep because the Lord caused it to happen."
    },
    {
      "verse": "13",
      "text": "David and Abishai then went across the valley to the other side of the hill. David stood on the top of the hill. He was far away from Saul's soldiers. Abner replied, ‘Who is shouting to wake up the king? Who are you? ’"
    },
    {
      "verse": "14",
      "text": "David shouted to Saul's army and to Ner's son, Abner, ‘Abner, wake up! Answer me! ’Abner replied, ‘Who is shouting to wake up the king? Who are you? ’"
    },
    {
      "verse": "15",
      "text": "David said to Abner, ‘Are you really the bravest soldier in Israel? You should have kept the king safe. Someone came into your camp to kill your master."
    },
    {
      "verse": "16",
      "text": "You have not done your job well. You and your men have not protected your master, who is the Lord's chosen king. As surely as the Lord lives, you all deserve to die. The king's spear and his water pot were beside his head. Look where they are now! ’"
    },
    {
      "verse": "17",
      "text": "Saul recognized David's voice. He said, ‘Is that you David, my son? ’David answered, ‘Yes, my master and my king, it is my voice that you can hear. ’ David answered, ‘Yes, my master and my king, it is my voice that you can hear. ’"
    },
    {
      "verse": "18",
      "text": "David also said, ‘Why are you chasing after me, my master? What have I done that is wrong? Why am I guilty?"
    },
    {
      "verse": "19",
      "text": "My master and my king, please listen to me. Has the Lord made you angry with me? If that is true, a sacrifice to him may change his thoughts. But if men have made you turn against me, I ask the Lord to curse them. They have chased me out of the land that belongs to the Lord's people. They have said to me, “Go away and worship other gods! ”"
    },
    {
      "verse": "20",
      "text": "Do not let me die a long way away from the Lord's home. You are the king of Israel and I am like a small fly. But you are trying to catch me! You are like someone who is looking for a wild bird in the mountains! ’"
    },
    {
      "verse": "21",
      "text": "Then Saul said, ‘I have done a bad thing. Return home, David, my son. You chose not to kill me today, because you knew the value of my life. So I will not hurt you again. I have done foolish things. I have made a big mistake. ’"
    },
    {
      "verse": "22",
      "text": "David said, ‘Here is your own spear. Send one of your young men here to fetch it for you."
    },
    {
      "verse": "23",
      "text": "The Lord wants everyone to do what is right and true. He blesses people who live like that. The Lord put you under my power today. But I would not agree to hurt the Lord's chosen king."
    },
    {
      "verse": "24",
      "text": "Today I knew that your life is valuable. In the same way, I pray that the Lord will know that my life is valuable. I pray that he will keep me safe through all danger. ’"
    },
    {
      "verse": "25",
      "text": "Then Saul said to David, ‘I pray that the Lord will bless you, my son. I know that you will do great things. ’So David left there and Saul returned to his home."
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "Then David thought, ‘I am sure that Saul will catch me one day. Then he will kill me. I must go to the country of the Philistines so that I will be safe from Saul. That is the best thing that I can do. When I am no longer in the land of Israel, Saul will stop looking for me here. I will escape from him. ’"
    },
    {
      "verse": "2",
      "text": "men went across the border of Israel to Gath town. Maoch's son Achish was the king there."
    },
    {
      "verse": "3",
      "text": "David and his men lived in Gath with King Achish. They had their families with them. David's two wives were with him: Ahinoam from Jezreel, and Abigail from Carmel. Abigail was Nabal's widow."
    },
    {
      "verse": "4",
      "text": "Saul heard the news that David had run away to Gath. So he stopped looking for David."
    },
    {
      "verse": "5",
      "text": "One day David said to Achish, ‘I hope that you are pleased with me. If you are, please choose a place for me to live in one of the small towns. I do not need to live in the same big city as the king. ’"
    },
    {
      "verse": "6",
      "text": "So on that day King Achish gave Ziklag town to David. Since then, Ziklag has always belonged to Judah's king."
    },
    {
      "verse": "7",
      "text": "David lived in the country of the Philistines for one year and four months."
    },
    {
      "verse": "8",
      "text": "During that time David and his men attacked the Geshurites, the Girzites and the Amalekites. These tribes had lived in that place for a very long time. Their land went as far as Shur and the border of Egypt."
    },
    {
      "verse": "9",
      "text": "Whenever David's men attacked them, they killed all the men and women. But they took all their sheep, cows, donkeys and camels, as well as their clothes. Then they would return to see King Achish."
    },
    {
      "verse": "10",
      "text": "Achish would ask David, ‘Which place did you go and attack today? ’ Sometimes David would say, ‘We robbed the people of a town in Judah's desert. ’ Or David might say, ‘We attacked a town in the desert where the people of Jerahmeel's clan live. ’ Or he might say, ‘We attacked a town in the desert where the Kenites live. ’"
    },
    {
      "verse": "11",
      "text": "David killed all the people in the places that he attacked. He never took anyone back to Gath. He thought, ‘If any of the people are still alive, they might go to Gath and tell people what we have done. ’That is what David did for the whole time that he lived among the Philistines."
    },
    {
      "verse": "12",
      "text": "So King Achish trusted David. He thought, ‘The Israelites must now hate David very much. So David will have to be my servant for ever. ’"
    }
  ],
  "28": [
    {
      "verse": "1",
      "text": "At that time, the Philistine army joined together to fight against the Israelites. King Achish said to David, ‘I hope you know that you and your men must fight with me in the battle. ’"
    },
    {
      "verse": "2",
      "text": "David said, ‘Yes, sir. Then you will see how well I can fight! ’Achish replied, ‘Good. Then you will always be my guard to keep me safe. ’ Achish replied, ‘Good. Then you will always be my guard to keep me safe. ’"
    },
    {
      "verse": "3",
      "text": "Samuel had died before this. All the Israelites had been very sad at his death. They had buried him in Ramah, the town where he had lived. When Samuel had been alive, Saul had removed magicians from Israel. Saul removed everyone who used magic to speak to the spirits of dead people."
    },
    {
      "verse": "4",
      "text": "The Philistine army came together and they put up their tents at Shunem. Saul called together the whole Israelite army. They put up their tents at Gilboa. His servants replied, ‘There is a woman at Endor who can do that. ’"
    },
    {
      "verse": "5",
      "text": "Saul saw the camp of the Philistine army. He became very afraid."
    },
    {
      "verse": "6",
      "text": "Saul asked the Lord what he should do. But the Lord did not answer him in any way. He did not give Saul a dream. He did not use the Urim. He did not give a message to the prophets."
    },
    {
      "verse": "7",
      "text": "So Saul said to his servants, ‘Look for a woman who can talk to dead people. Then I will go and ask her what will happen. ’His servants replied, ‘There is a woman at Endor who can do that. ’"
    },
    {
      "verse": "8",
      "text": "Saul changed his clothes so that no one would recognize him. At night, Saul and two of his men went to see the woman. Saul said to her, ‘Use your magic to bring up the spirit of a certain dead man. I will tell you his name. ’"
    },
    {
      "verse": "9",
      "text": "But the woman said to him, ‘You know what King Saul has done. He has removed all the magicians from Israel. Are you using a trap to catch me? Do you want me to die? ’"
    },
    {
      "verse": "10",
      "text": "Then Saul promised the woman very strongly. He said, ‘As surely as the Lord lives, nobody will punish you if you do this. ’"
    },
    {
      "verse": "11",
      "text": "The woman said, ‘Who is it that you want me to bring for you? ’ Saul replied, ‘Bring Samuel to me. ’"
    },
    {
      "verse": "12",
      "text": "The woman screamed when she saw Samuel. She said to Saul, ‘You have deceived me! You are King Saul! ’"
    },
    {
      "verse": "13",
      "text": "The king said to her, ‘Do not be afraid. Tell me what you can see. ’She replied, ‘I can see a spirit that is coming up from the ground. ’ She replied, ‘I can see a spirit that is coming up from the ground. ’"
    },
    {
      "verse": "14",
      "text": "Saul asked, ‘What does he look like? ’ She said, ‘I see an old man who is wearing a long coat. ’Saul realized that this was Samuel. He bent down low on his knees with his face towards the ground. Saul realized that this was Samuel. He bent down low on his knees with his face towards the ground."
    },
    {
      "verse": "15",
      "text": "Samuel said to Saul, ‘Why have you caused this trouble for me? Why have you brought me back? ’Saul said, ‘I have a lot of trouble. The Philistines are fighting against me. God has turned away from me. He will not use the prophets or give me dreams to answer my questions. So I have called you to come here. Please tell me what I should do. ’ Saul said, ‘I have a lot of trouble. The Philistines are fighting against me. God has turned away from me. He will not use the prophets or give me dreams to answer my questions. So I have called you to come here. Please tell me what I should do. ’"
    },
    {
      "verse": "16",
      "text": "Samuel said, ‘The Lord has turned away from you and he has become your enemy. So do not ask me what you should do."
    },
    {
      "verse": "17",
      "text": "I told you what the Lord would do. Now he has done it! The Lord has taken the kingdom away from you. He has given it to another Israelite, David."
    },
    {
      "verse": "18",
      "text": "The Lord has punished you today because you did not obey him. The Lord was very angry with the Amalekites. He told you to destroy them all. But you refused to do that."
    },
    {
      "verse": "19",
      "text": "The Lord will put you and the Israelites under the power of the Philistines. Tomorrow you and your sons will be with me in the place for dead people. The Lord will also let the Philistines win against Israel's army. ’"
    },
    {
      "verse": "20",
      "text": "Saul immediately fell down on the ground and he lay there. He was very afraid because of what Samuel had said. Saul was also very weak because he had eaten nothing all that day and night."
    },
    {
      "verse": "21",
      "text": "Then the woman came to Saul. She saw that he was very afraid. She said, ‘I have obeyed you, sir. I did what you asked me to do. I might have died because I did that."
    },
    {
      "verse": "22",
      "text": "Please listen to me now. I will give you some food to eat. Then you will be strong enough to travel back. ’"
    },
    {
      "verse": "23",
      "text": "Saul refused and he said, ‘I will not eat. ’ But the woman and Saul's servants continued to say that he must eat some food. So Saul agreed. He got up from the ground and he sat down on a bed."
    },
    {
      "verse": "24",
      "text": "The woman had a fat calf at her home. She went quickly and she killed it. Then she took some flour and she cooked some flat bread without yeast."
    },
    {
      "verse": "25",
      "text": "She gave the food to Saul and to his men and they ate it. Then they left her house that night."
    }
  ],
  "29": [
    {
      "verse": "1",
      "text": "The Philistine army put up their tents at Aphek. The Israelites made their camp near the spring of water at Jezreel. Achish said to them, ‘This is David. He was the servant of Israel's King Saul. But he came to me more than a year ago. Since he turned against King Saul and came to me, he has always been faithful to me. ’"
    },
    {
      "verse": "2",
      "text": "The Philistine rulers marched out with their groups of soldiers. They were in groups of 100 soldiers and 1, 000 soldiers. David and his men were marching with King Achish at the back of the army."
    },
    {
      "verse": "3",
      "text": "The Philistine leaders asked, ‘Why are these Hebrew people here? ’Achish said to them, ‘This is David. He was the servant of Israel's King Saul. But he came to me more than a year ago. Since he turned against King Saul and came to me, he has always been faithful to me. ’"
    },
    {
      "verse": "4",
      "text": "But the Philistine leaders were angry with Achish. They said to him, ‘Send David back to the town that you gave to him. He must not go with us to fight the battle. He might turn against us and become our enemy. Then he would start to kill our own soldiers. That would make his master, Saul, very happy! “Saul has killed thousands of his enemies. And David has killed tens of thousands of his enemies. ” ’"
    },
    {
      "verse": "5",
      "text": "Remember who this man David is! The Israelites sing this about him when they dance:“Saul has killed thousands of his enemies. And David has killed tens of thousands of his enemies. ” ’"
    },
    {
      "verse": "6",
      "text": "So Achish called David to come to him. He said, ‘As surely as the Lord lives, I know that I can trust you. I would like you to go with me to fight the battle. Since the first day that you came to me, I have never found anything wrong with you. But the other leaders do not trust you."
    },
    {
      "verse": "7",
      "text": "So return to your home and have peace in your mind. Do not do anything that will make the other Philistine leaders angry. ’"
    },
    {
      "verse": "8",
      "text": "David said to King Achish, ‘What have I done that is wrong? You say that you have found nothing wrong with me all the time that I have been with you. You are my master and king. So why should I not go with you to fight your enemies? ’"
    },
    {
      "verse": "9",
      "text": "Achish replied, ‘I believe that you are as good as an angel from God. But the Philistine leaders have said, “David must not go with us to fight the battle. ”"
    },
    {
      "verse": "10",
      "text": "So you must all get up early tomorrow morning. As soon as there is light at dawn, you must leave with the men who came with you. ’"
    },
    {
      "verse": "11",
      "text": "So David and his men got up early in the morning. They returned along the road back to Ziklag. The Philistine army went to Jezreel."
    }
  ],
  "30": [
    {
      "verse": "1",
      "text": "David and his men arrived at Ziklag three days after they left King Achish. They found that the Amalekites had attacked Ziklag and towns in the south of Judah. The Amalekites had destroyed Ziklag with fire."
    },
    {
      "verse": "2",
      "text": "They had caught the women and the other people who were in the town, both young people and old people. They did not kill any of them, but they took them away as prisoners."
    },
    {
      "verse": "3",
      "text": "So when David and his men arrived at Ziklag, they saw that the Amalekites had destroyed the city. The Amalekites had taken away their wives, their sons and their daughters as prisoners."
    },
    {
      "verse": "4",
      "text": "David and his men wept loudly. They continued to weep until they had no strength to weep any more."
    },
    {
      "verse": "5",
      "text": "The Amalekites had taken both of David's wives: Ahinoam from Jezreel and Abigail from Carmel, who was Nabal's widow."
    },
    {
      "verse": "6",
      "text": "David was very upset because his men were complaining. They wanted to kill him with stones. His men were very upset because they had lost their sons and their daughters. But David trusted the Lord his God to make him strong."
    },
    {
      "verse": "7",
      "text": "Then David spoke to Abiathar the priest, Ahimelech's son. David said to him, ‘Bring the priests' ephod to me. ’ So Abiathar took the ephod to David. The Lord answered, ‘Yes, chase after them and you will certainly catch them. You will rescue your families. ’"
    },
    {
      "verse": "8",
      "text": "David asked the Lord, ‘Should I chase after the men who attacked our town? Will I catch them? ’The Lord answered, ‘Yes, chase after them and you will certainly catch them. You will rescue your families. ’"
    },
    {
      "verse": "11",
      "text": "David's men found an Egyptian man in a field. They took him to David. They gave the man some water to drink and food to eat."
    },
    {
      "verse": "12",
      "text": "They gave him some dried figs and some raisins. Then he became stronger, because he had not eaten any food or drunk any water for three days."
    },
    {
      "verse": "13",
      "text": "David asked the man, ‘Who is your master? Where do you come from? ’The young man answered, ‘I am an Egyptian, the slave of an Amalekite man. My master left me here three days ago because I was ill."
    },
    {
      "verse": "14",
      "text": "We had attacked the south part of Judah, where the Kerethites live. We also attacked the land where the people of Caleb's clan live. We destroyed Ziklag with fire too. ’"
    },
    {
      "verse": "15",
      "text": "David said to him, ‘Can you take me to find these men? ’The man said, ‘Please promise me in God's name that you will not kill me. Promise me that you will not take me back to my master. If you do that, I will lead you to find them. ’ The man said, ‘Please promise me in God's name that you will not kill me. Promise me that you will not take me back to my master. If you do that, I will lead you to find them. ’"
    },
    {
      "verse": "16",
      "text": "So the Egyptian man took David to find the Amalekites. The men were sitting everywhere, all over the ground. They were having a party, eating and drinking. They were happy because they had taken so many things from the towns of the Philistines and from the people in Judah."
    },
    {
      "verse": "17",
      "text": "That evening, David attacked the Amalekites. The fight continued until the next evening. David and his men killed all the Amalekites except for 400 young men. Those 400 men rode away on their camels."
    },
    {
      "verse": "18",
      "text": "David got back everything that the Amalekites had taken. And he rescued his two wives."
    },
    {
      "verse": "19",
      "text": "The people had lost nothing. David brought everyone back, the young people and the old people, the sons and the daughters. He brought back all the valuable things and everything that the Amalekites had taken."
    },
    {
      "verse": "20",
      "text": "David took all the sheep, goats and cows from the Amalekites. His men led these animals in front of the other animals. They said, ‘These animals will belong to David! ’"
    },
    {
      "verse": "21",
      "text": "men who had stayed beside the Besor stream. These men had been too tired to go with David. They came to meet David and the men who were with him. When David met them, he happily said ‘hello’ to them."
    },
    {
      "verse": "22",
      "text": "But some of the men who had gone with David were wicked and stupid. They said, ‘These men did not come with us to attack the Amalekites. So we will not give them any of the things that we have brought back. Each man can have only his wife and his children. Then they must take them back home. ’"
    },
    {
      "verse": "23",
      "text": "David said, ‘No, my brothers. You cannot do that. The Lord has given all these things to us. He has kept us safe. He has helped us to win against the enemies who attacked us."
    },
    {
      "verse": "24",
      "text": "Nobody will agree with what you say. Each person will receive an equal part. The men who stayed here with our things and the men who went to fight will all receive the same amount. ’"
    },
    {
      "verse": "25",
      "text": "David made this a rule for the Israelites, and they still obey it."
    },
    {
      "verse": "26",
      "text": "David arrived back at Ziklag with all the things that they had taken from the Amalekites. He sent some of the things to the leaders of Judah who were his friends. David sent this message, ‘Here is a gift for you. We took these things from the Lord's enemies. ’"
    },
    {
      "verse": "27",
      "text": "David sent gifts to the leaders in these towns: Bethel, Ramoth in the desert in the south, Jattir, David also sent gifts to the people in the towns that he and his men had visited."
    },
    {
      "verse": "28",
      "text": "Aroer, Siphmoth, Eshtemoa,"
    },
    {
      "verse": "29",
      "text": "Racal, the towns where the clan of Jerahmeel live, the towns where the Kenites live,"
    },
    {
      "verse": "30",
      "text": "Hormah, Bor Ashan, Athach"
    },
    {
      "verse": "31",
      "text": "and Hebron. David also sent gifts to the people in the towns that he and his men had visited."
    },
    {
      "verse": "9",
      "text": "men left Ziklag. They arrived at Besor stream. Some of the men were too tired to go across the valley."
    },
    {
      "verse": "10",
      "text": "So 200 men remained there. David and the other 400 men continued to chase after the Amalekites."
    }
  ],
  "31": [
    {
      "verse": "1",
      "text": "The Philistines fought against the Israelites. The Israelites ran away, and the Philistines killed many of them on Gilboa mountain."
    },
    {
      "verse": "2",
      "text": "The Philistines chased after Saul and his sons to catch them. They killed Saul's sons, Jonathan, Abinadab and Malki-Shua."
    },
    {
      "verse": "3",
      "text": "The Philistines were fighting the battle all around Saul. Some of their soldiers saw Saul and they shot their arrows at him. The arrows hurt Saul very much and he was nearly dead."
    },
    {
      "verse": "4",
      "text": "He said to the young man who carried his armour, ‘Kill me now with your sword. I do not want these foreign men to be cruel to me as they kill me. ’ But the young man would not agree to kill Saul because he was too afraid. So Saul took his own sword and he threw himself onto it so that he died."
    },
    {
      "verse": "5",
      "text": "The young man saw that Saul was dead. So he threw himself onto his own sword and he also died."
    },
    {
      "verse": "6",
      "text": "So Saul died there, with his three sons. The young man who carried Saul's armour and all Saul's men died too."
    },
    {
      "verse": "7",
      "text": "The Israelites who lived in the Jezreel valley and on the other side of the Jordan River saw what happened. They saw that the Israelite army had run away from the Philistines. They saw that Saul and his sons were dead. So they left their towns and they ran away. Then the Philistines came to live in those towns."
    },
    {
      "verse": "8",
      "text": "The day after the battle, the Philistines came to take all the valuable things from the dead soldiers. They found the dead bodies of Saul and his three sons on Gilboa mountain."
    },
    {
      "verse": "9",
      "text": "They cut off Saul's head and they removed his armour. Then they sent men through all the country of the Philistines with the news of Saul's death. These men told the news everywhere that the Philistine people lived and in the temples of their idols."
    },
    {
      "verse": "10",
      "text": "They put Saul's armour in the temple of their god Ashtoreth. Then they hung Saul's dead body on the wall of Beth Shan town."
    },
    {
      "verse": "11",
      "text": "The Israelites who lived in Jabesh Gilead heard about what the Philistines had done to Saul's body."
    },
    {
      "verse": "12",
      "text": "So all their brave soldiers left Jabesh Gilead and they marched all night to Beth Shan. They removed the dead bodies of Saul and his sons from the town's wall. Then they took them to Jabesh Gilead. They burned the dead bodies there."
    },
    {
      "verse": "13",
      "text": "Then they took the bones and they buried them under a tamarisk tree at Jabesh Gilead. The men did not eat any food for seven days because they were so sad."
    }
  ]
};