module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This book describes the things that God showed to Jesus Christ. He wanted Jesus to show these things to his own servants. They are events that must happen soon. Jesus sent his angel to show them to me, his servant John."
    },
    {
      "verse": "2",
      "text": "I, John, have written about everything that God showed me. These things are a true message from God. They are the things that Jesus Christ says are true."
    },
    {
      "verse": "3",
      "text": "If anyone reads aloud the words of this prophecy, God will bless that person. God will also bless the people who listen to these words, if they continue to obey them. The things that are written here will soon happen."
    },
    {
      "verse": "4",
      "text": "I am John. I am writing to the seven churches that are in the region of Asia. I pray that God will be very kind to you. I pray that he will give you peace in your minds. God is alive now. He has always been alive. He will continue to be alive for ever. God will help you, and the seven spirits that are in front of his throne will help you. God will help you, and the seven spirits that are in front of his throne will help you."
    },
    {
      "verse": "5",
      "text": "Jesus Christ will also help you. He always speaks a true message. He is the first person who became alive again after death. He rules the kings of the earth. Jesus loves us and he died for us. That is how he made us free. Because of Jesus, God will not punish us for the bad things that we have done."
    },
    {
      "verse": "6",
      "text": "Jesus has brought us into his family, so that we belong to God's kingdom. He has made us priests, so that we serve his God and Father. So we praise Jesus Christ! He will always be very great! He has power for all time. Amen. This is true! So we praise Jesus Christ! He will always be very great! He has power for all time. Amen. This is true!"
    },
    {
      "verse": "7",
      "text": "Look! He will come on the clouds! At that time, everyone will see him! Even the people who pushed a spear into his body will see him. People from all the nations on earth will be sad when they see him. Yes, it is true! Amen! At that time, everyone will see him! Even the people who pushed a spear into his body will see him. People from all the nations on earth will be sad when they see him. Yes, it is true! Amen!"
    },
    {
      "verse": "8",
      "text": "The Lord God says, ‘I caused all things to begin and I will cause the end of all things. I have all power and authority. I am alive. I have always been alive. I will continue to be alive for ever. ’"
    },
    {
      "verse": "9",
      "text": "I am John. I am a believer, as you are. I am like your brother and your friend. Because we belong to Jesus' kingdom, we are having trouble and pain. So we all need to be strong and patient, as Jesus helps us. The Roman leaders punished me because I taught God's message. I told people the true message about Jesus. That is why they sent me to Patmos island."
    },
    {
      "verse": "10",
      "text": "On the Lord's day, God's Spirit caused me to see and to hear things. I heard a voice speak behind me. The sound was as loud as a trumpet."
    },
    {
      "verse": "11",
      "text": "The voice said: ‘When you see these things, write them in a book. Then you must send the book to the seven churches in these cities: Ephesus, Smyrna, Pergamum, Thyatira, Sardis, Philadelphia, Laodicea. ’"
    },
    {
      "verse": "12",
      "text": "I turned round to see who was speaking to me. When I turned, I saw seven gold lampstands with their lights."
    },
    {
      "verse": "13",
      "text": "In the middle of the lights, I saw someone like a son of man. He was wearing long clothes that reached down to his feet. He wore a gold belt around the top part of his body."
    },
    {
      "verse": "14",
      "text": "His head and his hair were white like sheep's hair. They were very white, like snow. His eyes were like fires that were burning brightly."
    },
    {
      "verse": "15",
      "text": "His feet shone like a metal that shines brightly in a very hot fire. When he spoke, his voice was very loud. It was like the sound of water that pours along a river very quickly."
    },
    {
      "verse": "16",
      "text": "He held seven stars in his right hand. A sword with two sharp edges came out of his mouth. His face was like the sun when it shines very brightly."
    },
    {
      "verse": "17",
      "text": "When I saw him, I fell down at his feet like a dead person. Then he put his right hand on me, and he said to me, ‘Do not be afraid! I am the one who is the first and also the last."
    },
    {
      "verse": "18",
      "text": "I am the one who always lives. I died once. But look! Now I am alive and I will be alive for ever. I have authority over death and over Hades, the place for dead people."
    },
    {
      "verse": "19",
      "text": "So write down the things that you have seen. Write about what you see that is happening now. Also write about the things that will happen later."
    },
    {
      "verse": "20",
      "text": "You saw seven stars that I held in my right hand. You saw seven lights in their gold lampstands. Now I will tell you what they mean. The seven stars show what the angels of the seven churches are like. The seven lights in their lampstands show what the seven churches themselves are like. ’"
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "‘Now write this to the angel of the church at Ephesus:“This is the message to you from the one who holds the seven stars. He holds them carefully in his right hand. He walks among the seven gold lampstands. “This is the message to you from the one who holds the seven stars. He holds them carefully in his right hand. He walks among the seven gold lampstands."
    },
    {
      "verse": "2",
      "text": "I know everything that you do. You have worked much for me. You have continued to work patiently. I know that you do not accept bad people as your friends. Some of these bad people say that they are apostles of Jesus. You have thought carefully about what they teach people. And you have discovered that it is not true."
    },
    {
      "verse": "3",
      "text": "You have been patient and strong in times of trouble. You have continued to serve me because you believe in me. You have not stopped when you become tired."
    },
    {
      "verse": "4",
      "text": "But I have something to say against you. You loved me very much when you first believed in me. You do not love me as much now."
    },
    {
      "verse": "5",
      "text": "Think carefully about this! You do not now live in the way you did at the beginning. So you must change the way you live. Do again the good things that you did at the beginning. If you do not change the way you live, I will come to punish you. I will take away your lampstand from its place."
    },
    {
      "verse": "6",
      "text": "But this is something that you do well: you hate the bad things that the Nicolaitans are doing. I also hate what they do."
    },
    {
      "verse": "7",
      "text": "God's Spirit is now speaking to people in the churches. You should recognize that the Spirit is speaking. Everyone who knows that should listen to what he says. I will let everyone who wins against Satan eat my fruit. This fruit is from the tree that makes us alive. And this tree grows in God's garden. ” ’"
    },
    {
      "verse": "8",
      "text": "‘Write this to the angel of the church at Smyrna:“This is the message to you from the one who is the first and the last. He was dead, but he became alive again. “This is the message to you from the one who is the first and the last. He was dead, but he became alive again."
    },
    {
      "verse": "9",
      "text": "I know that bad people are making you suffer. I also know that you are poor. But really, you are rich. Some people say that they are Jews, but they tell lies about you. So they cannot be my true people. Instead, they belong to a group of Satan's people."
    },
    {
      "verse": "10",
      "text": "I know that trouble will soon come to you. But do not be afraid. Listen! The Devil will cause some of you to go to prison. He wants to see whether you will continue to believe in me. As a result, you will suffer for ten days. But continue to trust me, even if you die. Then you will win against the Devil. I will give you a gift, as they give a crown to the winner of a race. You will have life with me for ever."
    },
    {
      "verse": "11",
      "text": "God's Spirit is speaking to you in the churches. You should understand what the Spirit is saying to you. You have ears, so listen carefully! The second death will not hurt anyone who wins against Satan. ” ’"
    },
    {
      "verse": "12",
      "text": "‘Write this to the angel of the church at Pergamum:“This is the message to you from the one who has the sharp sword with two edges. “This is the message to you from the one who has the sharp sword with two edges."
    },
    {
      "verse": "13",
      "text": "I know where you live. It is the place where Satan sits as king. But you still continue to trust me. You remember Antipas who spoke a clear message about me. Because of that, some people in your city killed him. You saw what happened to him, but you continued to believe in me. You still serve me, even there where Satan lives."
    },
    {
      "verse": "14",
      "text": "But I have a few things to say against you. Some people among you agree with what Balaam taught long ago. He taught Balak to do a bad thing against God's people. Balak caused the Israelite people to do wrong things. As a result, they ate food that people had given to idols. They also had sex with people who were not their husbands or wives."
    },
    {
      "verse": "15",
      "text": "Also, some people among you do the bad things that the Nicolaitans teach."
    },
    {
      "verse": "16",
      "text": "So you must stop doing these bad things. If you do not change how you live, I will quickly come to punish you. I will fight against those bad people with my sharp sword that comes out of my mouth."
    },
    {
      "verse": "17",
      "text": "God's Spirit is speaking to you in the churches. You should understand what the Spirit is saying to you. You have ears, so listen carefully! To everyone who wins against Satan I will give some of my special food called manna. I will also give each of them a white stone. I will write a new name on that stone. Nobody will know that name except the person who receives it. ” ’"
    },
    {
      "verse": "18",
      "text": "‘Write this to the angel of the church at Thyatira:“This is the message to you from the Son of God. He has eyes that burn brightly like flames of fire. His feet shine like bright metal. “This is the message to you from the Son of God. He has eyes that burn brightly like flames of fire. His feet shine like bright metal."
    },
    {
      "verse": "19",
      "text": "I know everything that you do. I know that you have great love. I know that you believe in me. I know that you continue to serve me well. You are patient and strong. You do these good things now more than you did at the beginning."
    },
    {
      "verse": "20",
      "text": "But I have something to say against you. You let that woman Jezebel teach you. She says that she is a prophet from God. But she leads my servants into bad ways. She teaches them to have sex with many people. And she teaches them to eat food that people have given to idols."
    },
    {
      "verse": "21",
      "text": "I have given her time to stop doing these bad things. But she refuses to change how she lives. She does not stop having sex with other men."
    },
    {
      "verse": "22",
      "text": "Listen to this! I will cause her to suffer on her bed, so that she cannot get up. Those who join her in her sins will also suffer very much, unless they change the way they live."
    },
    {
      "verse": "23",
      "text": "I will send a terrible illness to kill those who obey her. Then all the people in the churches will know that I look deep inside them. I know what you really want. I know what you really think. I will give each of you what is right for you, as a result of what you have done."
    },
    {
      "verse": "24",
      "text": "But I say this to you other people in Thyatira. You have not agreed with what Jezebel taught. You have not learned what they call ‘Satan's deep secrets’. So I say this to you: I will not tell you to obey any other difficult rules."
    },
    {
      "verse": "25",
      "text": "But continue to obey my message that you have already received. Believe in me until I come."
    },
    {
      "verse": "26",
      "text": "Continue to obey me until the end and win the fight against Satan. If anyone does that, I will give him authority to rule over the nations of the world."
    },
    {
      "verse": "27",
      "text": "That person will rule the nations with strong authority. He will destroy them, like someone who breaks clay pots into many pieces."
    },
    {
      "verse": "28",
      "text": "He will have the same authority that I received from my Father. I will also give him the morning star."
    },
    {
      "verse": "29",
      "text": "God's Spirit is speaking to you in the churches. You should understand what the Spirit is saying to you. You have ears, so listen carefully! ” ’"
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "‘Write this to the angel of the church at Sardis:“This is the message to you from the one who holds the seven spirits of God and the seven stars. I know everything that you do. I know that people praise you. They think that you are alive. But that is not true, because really you are dead in your spirits. “This is the message to you from the one who holds the seven spirits of God and the seven stars."
    },
    {
      "verse": "2",
      "text": "Wake up! You must become strong again. Do not let the little bit of life that you have completely disappear! I know that there are still more things for you to do to please my Father God."
    },
    {
      "verse": "3",
      "text": "So remember God's message that you have heard. Obey what God has said. Turn away from the wrong things that you do. Change the way that you live. If you do not wake up, I will come to punish you. I will come secretly, like someone who robs people. So you will not know what time I will come to you."
    },
    {
      "verse": "4",
      "text": "But you have a few people among you in Sardis who have not done these bad things. They are like people who have kept their clothes clean. They will walk with me and they will wear white clothes. They are good people and it is right for them to wear these white clothes."
    },
    {
      "verse": "5",
      "text": "Everyone who wins against Satan will wear white clothes like they do. I will never remove their names from God's book of life. I will say clearly to my Father and his angels that those people belong to me."
    },
    {
      "verse": "6",
      "text": "God's Spirit is speaking to you in the churches. You should understand what the Spirit is saying to you. You have ears, so listen carefully! ” ’"
    },
    {
      "verse": "7",
      "text": "‘Write this to the angel of the church at Philadelphia:“This is my message to you. I am the one who is completely good, the true God. I have King David's key in my hand. When I open a door, nobody can shut it. And when I shut a door, nobody can open it. “This is my message to you. I am the one who is completely good, the true God. I have King David's key in my hand. When I open a door, nobody can shut it. And when I shut a door, nobody can open it."
    },
    {
      "verse": "8",
      "text": "I know everything that you do. Look! I have opened a door that is in front of you. Nobody can shut that door. I know that you are not very strong. But you have obeyed what I told you. You have continued to believe in me."
    },
    {
      "verse": "9",
      "text": "Some people there say that they are Jews. But that is not true. They are telling lies. Instead, they belong to a group of Satan's people. I will cause those people to bend down low in front of you to give you honour. Then they will understand that I love you."
    },
    {
      "verse": "10",
      "text": "I have told you to be patient in this difficult time. You have obeyed what I told you. Because of that, I will keep you safe from the time of great trouble that will come. This trouble will come to everyone who lives in the world. It will show me what each person is really like."
    },
    {
      "verse": "11",
      "text": "I will come soon. Continue to obey my message that you already know. Then nobody can take away your crown which is God's gift to you."
    },
    {
      "verse": "12",
      "text": "Everyone who wins against Satan will be safe in God's house. I will make them like a strong pillar in the temple of my God. They will never leave that place again. I will write on them the name of my God and the name of his city. The name of that city is the new Jerusalem. It will come down from heaven. My God will send it down to the earth. I will also write my new name on those people."
    },
    {
      "verse": "13",
      "text": "God's Spirit is speaking to you in the churches. You should understand what the Spirit is saying to you. You have ears, so listen carefully! ” ’"
    },
    {
      "verse": "14",
      "text": "‘Write this to the angel of the church at Laodicea:“This is my message to you. I am the one whose name is ‘Amen’. I faithfully tell people God's true message. Everything that God has created starts with me. “This is my message to you. I am the one whose name is ‘Amen’. I faithfully tell people God's true message. Everything that God has created starts with me."
    },
    {
      "verse": "15",
      "text": "I know everything that you do. I know that you are neither cold nor hot. It would be better if you were either cold or hot."
    },
    {
      "verse": "16",
      "text": "But you are only warm. Because you are neither cold nor hot, I am ready to throw you away completely."
    },
    {
      "verse": "17",
      "text": "You say, ‘I am rich. God has helped me to have many things. I do not need anything more. ’ But you do not know how very poor you are really! You are like people who cannot see. You are like people who are without clothes. Really, other people should feel very sorry for you."
    },
    {
      "verse": "18",
      "text": "So I tell you that you should buy gold from me. With my gold, you would be really rich. My gold is the best, because it has been through fire. You should also buy white clothes from me to dress yourselves. Then you will not be ashamed because you have no clothes. You should also buy medicine from me to put on your eyes. Then you will be able to see well."
    },
    {
      "verse": "19",
      "text": "I help everyone that I love. When they have done wrong things, I tell them, ‘You have done a wrong thing. ’ I show them the right thing that they should do. So be serious about how you live. Stop doing wrong things and turn to me."
    },
    {
      "verse": "20",
      "text": "Look! I am standing at the door of your house. I am knocking on your door. When you hear my voice, you should open the door. Then I will come in. We will eat a meal together as friends."
    },
    {
      "verse": "21",
      "text": "Everyone who wins against Satan will come to sit with me on my throne where I rule. I won against my enemies. Then I sat down with my Father on his throne. I will give you the same authority."
    },
    {
      "verse": "22",
      "text": "God's Spirit is speaking to you in the churches. You should understand what the Spirit is saying to you. You have ears, so listen carefully! ” ’"
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "After this, I looked. There in front of me was an open door in heaven. I heard the same voice that I had heard before. It spoke like the sound of a trumpet. It said to me, ‘Come up here. I will show you the things that must happen after this. ’"
    },
    {
      "verse": "2",
      "text": "Immediately God's Spirit caused me to see and to hear more things. I saw a throne in heaven, with someone sitting on it."
    },
    {
      "verse": "3",
      "text": "The person who sat there shone with bright red and white light, like jewels called jasper and ruby. Around the throne there was a rainbow that shone with bright green light like an emerald jewel."
    },
    {
      "verse": "4",
      "text": "other thrones. 24 leaders were sitting on these thrones. They were wearing white clothes and they had gold crowns on their heads."
    },
    {
      "verse": "5",
      "text": "A storm with bright lightning came from the throne. There was the loud noise of thunder. In front of the throne there were seven lights of fire burning brightly. These lights are the seven spirits of God."
    },
    {
      "verse": "6",
      "text": "Also in front of the throne there was something like a sea of glass that shone with light. In the middle, round the throne, there were four other beings that were alive. They had eyes all over them, on their fronts and on their backs."
    },
    {
      "verse": "7",
      "text": "The first of these beings was like a lion. The second being was like an ox. The third being had a face like a man's face. And the fourth being was like an eagle that was flying. ‘The Lord God has all power and authority. He has no bad thing in him. He is completely good. He has always been alive. He is alive now. He will continue to be alive for ever. ’"
    },
    {
      "verse": "8",
      "text": "Each of these four beings had six wings. They had eyes all over them, even under their wings. All day and all night they never stop saying:‘The Lord God has all power and authority. He has no bad thing in him. He is completely good. He has always been alive. He is alive now. He will continue to be alive for ever. ’"
    },
    {
      "verse": "9",
      "text": "God sits on the throne and he is alive for ever. The four beings that are alive worship him and they thank him."
    },
    {
      "verse": "10",
      "text": "When they do this, the 24 leaders bend down to the ground. They also worship the Lord God, who sits on the throne and is alive for ever. They put their crowns in front of God's throne, and they praise him. They say:"
    },
    {
      "verse": "11",
      "text": "‘God, our Lord, you are very good! Everyone should give you honour and say how great and powerful you are! Everyone should worship you, because you created everything. You decided to make them and so you made them! That is why everything in the world is here. ’"
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Then I looked at the one who was sitting on the throne. I saw that he held a book in his right hand. Words were written on both sides, the inside and the outside. Seven seals kept the book closed."
    },
    {
      "verse": "2",
      "text": "Then I saw a powerful angel. He said with a loud voice, ‘Who is so good that they can break the seals? Who can open the book? ’"
    },
    {
      "verse": "3",
      "text": "But nobody in heaven could open the book and look inside it. Neither could anyone on the earth or anyone under the earth open it."
    },
    {
      "verse": "4",
      "text": "I wept much because there was nobody who was good enough. Nobody was so good that they could open the book. Nobody could look inside it."
    },
    {
      "verse": "5",
      "text": "Then one of the leaders said to me, ‘Do not weep! Look! There is someone who can break the seven seals and then open the book. His name is the Lion from Judah's tribe. He is called the Root of King David. He has won over all his enemies. ’"
    },
    {
      "verse": "6",
      "text": "Then I saw a Lamb. He was standing in the middle of the throne. The four beings that are alive and the leaders were around him. The Lamb appeared to be like a lamb that someone had killed. He had seven horns and seven eyes. His eyes are the seven spirits of God, that God has sent into all parts of the world. ‘You are so good! You are good enough to take the book. You can break its seals and open it. You can do this because they killed you. When you died, you bought people for God with your blood. You bought them from every tribe, from every language and every nation."
    },
    {
      "verse": "7",
      "text": "The Lamb came and he took the book. He took it from the right hand of the one who was sitting on the throne."
    },
    {
      "verse": "8",
      "text": "When he had taken the book, the four beings and the 24 leaders fell down to the ground in front of the Lamb. They worshipped him. Each leader had a harp to make music. They were also holding gold bowls which were full of incense. That nice smell shows what it is like when God's people pray to him."
    },
    {
      "verse": "9",
      "text": "The beings that are alive and the leaders sang a new song. They sang:‘You are so good! You are good enough to take the book. You can break its seals and open it. You can do this because they killed you. When you died, you bought people for God with your blood. You bought them from every tribe, from every language and every nation."
    },
    {
      "verse": "10",
      "text": "You have caused them to belong to the kingdom of our God. You have made them priests, so that they serve God. And they will rule on the earth. ’ You have made them priests, so that they serve God. And they will rule on the earth. ’"
    },
    {
      "verse": "11",
      "text": "Then I looked again, and I heard the voices of many angels. There were thousands and millions of them. They were standing around the throne, with the beings that are alive and the leaders. ‘The Lamb that people killed is completely good! He has all authority, and all things belong to him. He is wise and powerful. Everyone must agree that he is great! Everyone must praise him and worship him! ’"
    },
    {
      "verse": "12",
      "text": "They all sang with loud voices:‘The Lamb that people killed is completely good! He has all authority, and all things belong to him. He is wise and powerful. Everyone must agree that he is great! Everyone must praise him and worship him! ’"
    },
    {
      "verse": "13",
      "text": "Then I heard everything that is alive singing. That was everything in heaven and everything on the earth, and everything under the earth and everything in the sea. They were singing:‘We praise the one who sits on the throne. We praise the one who is the Lamb. We say that they are great! We worship them! They have power to rule for ever! ’ ‘We praise the one who sits on the throne. We praise the one who is the Lamb. We say that they are great! We worship them! They have power to rule for ever! ’"
    },
    {
      "verse": "14",
      "text": "The four beings that are alive agreed. They said, ‘Yes, this is true. ’ The leaders fell down and they worshipped God and the Lamb."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "Then I watched while the Lamb opened one of the seven seals on the book. I heard one of the four beings say, ‘Come! ’ It spoke very loudly with a voice like thunder."
    },
    {
      "verse": "2",
      "text": "I looked, and I saw a white horse. The person who was riding the horse held a bow. Someone gave him a crown. He had fought against many people and he had won. Now he rode out on his horse to win against many more people."
    },
    {
      "verse": "3",
      "text": "Then the Lamb opened the second seal. I heard another of the beings say, ‘Come! ’"
    },
    {
      "verse": "4",
      "text": "Then another horse came out. This horse was bright red, like fire. The person who was riding the horse had authority. He could take peace away from the earth, so that people killed each other. Someone gave him a large sword."
    },
    {
      "verse": "5",
      "text": "Then the Lamb opened the third seal. I heard the next being say, ‘Come! ’ I looked, and I saw a black horse. The person who was riding the horse held something in his hand. He used it to weigh things."
    },
    {
      "verse": "6",
      "text": "Then I heard a sound like somebody speaking among the four beings. The voice said, ‘A litre of wheat is worth one day's work. And three litres of barley is also worth one day's work. But do not destroy the olive oil and the wine. ’"
    },
    {
      "verse": "7",
      "text": "Then the Lamb opened the fourth seal. I heard the last being say, ‘Come! ’"
    },
    {
      "verse": "8",
      "text": "I looked, and I saw a grey horse. The name of the person who was riding the horse was Death. The place for dead people, called Hades, was following near to him. They had authority to kill people in a quarter of the earth. They could kill people in different ways. They could kill them in wars. They could cause people to die because there was no food. They could cause people to become very ill so that they died. They could also cause wild animals to kill people."
    },
    {
      "verse": "9",
      "text": "Then the Lamb opened the fifth seal. I saw an altar where people offered gifts to God. I saw the souls of some of God's people under the altar. These people had died because they had believed God's message. They had continued to speak the true message about Jesus Christ. That is why people had killed them."
    },
    {
      "verse": "10",
      "text": "These believers called out loudly, ‘Lord, you have all authority. You are completely good. You always do what is right. When will you decide to judge the people who live on the earth? Do not wait! You should quickly punish the people who killed us! ’"
    },
    {
      "verse": "11",
      "text": "Then each believer received white clothes. God told them to wait for a short time more. They must wait until other believers on earth also died. These believers are also servants of God. God will wait until people kill those believers too. Then the number of them will be complete."
    },
    {
      "verse": "12",
      "text": "I watched again. I saw the Lamb open the sixth seal. Then the ground shook with a great earthquake. The sun became black like thick black cloth. The whole moon became red like blood."
    },
    {
      "verse": "13",
      "text": "The stars in the sky fell to the earth. They fell like fruits fall from a tree when a strong wind blows."
    },
    {
      "verse": "14",
      "text": "The sky divided into two parts. It rolled up like a piece of paper. Every mountain and every island moved away from its place."
    },
    {
      "verse": "15",
      "text": "Then everyone on the earth hid themselves. They went to the mountains and they hid among the rocks and in holes in the rocks. Everyone tried to hide, even the kings and the rulers. The soldiers' leaders, the rich people and other powerful people all went to hide. Everyone hid, whether they were slaves or free people."
    },
    {
      "verse": "16",
      "text": "They shouted to the mountains and to the rocks, ‘Fall on us and cover us. Hide us, so that the one who sits on the throne cannot see us. Also hide us from the Lamb who is very angry with us."
    },
    {
      "verse": "17",
      "text": "Their great day has come. They will punish us because they are so angry. Nobody will be able to escape. ’"
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "After this, I saw four angels. They were standing at the four corners of the earth. They were stopping the four winds of the earth. As a result, no wind could blow on the earth, or on the sea, or on any tree."
    },
    {
      "verse": "2",
      "text": "Then I saw another angel who was coming up from the east. He was carrying the seal of the God who lives for ever. He shouted loudly to the four other angels. They had received authority to destroy the land and the sea."
    },
    {
      "verse": "3",
      "text": "But he shouted to them, ‘Do not destroy the land or the sea or the trees yet. Wait until we put a seal on the heads of God's servants. God's seal on the front of their heads will keep them safe. ’"
    },
    {
      "verse": "4",
      "text": "Then I heard how many people received God's seal. The number of people was 144, 000. They came from all the tribes of Israel's people:"
    },
    {
      "verse": "5",
      "text": "12, 000 from Judah's tribe, 12, 000 from Reuben's tribe, 12, 000 from Gad's tribe,"
    },
    {
      "verse": "6",
      "text": "12, 000 from Asher's tribe, 12, 000 from Naphtali's tribe, 12, 000 from Manasseh's tribe,"
    },
    {
      "verse": "7",
      "text": "12, 000 from Simeon's tribe, 12, 000 from Levi's tribe, 12, 000 from Issachar's tribe,"
    },
    {
      "verse": "8",
      "text": "12, 000 from Zebulun's tribe, 12, 000 from Joseph's tribe, 12, 000 from Benjamin's tribe."
    },
    {
      "verse": "9",
      "text": "After this, I looked again. I saw a very big crowd of people. There were so many people that nobody could count them. They came from every nation, from every tribe and from every language. They were standing in front of the throne and in front of the Lamb. They were wearing long white clothes and they held branches of palm trees in their hands."
    },
    {
      "verse": "10",
      "text": "They shouted loudly:‘We worship our God who sits on the throne. And we worship the Lamb. They have saved us from Satan's power. ’ ‘We worship our God who sits on the throne. And we worship the Lamb. They have saved us from Satan's power. ’"
    },
    {
      "verse": "11",
      "text": "All the angels were standing around the throne, and around the leaders and the four beings. The angels all bent down so that their faces touched the ground. They worshipped God who was on the throne in front of them. ‘This is true! We worship our God and we give him honour. He is completely wise. We thank him and we praise him. He has all power and authority for ever! Amen! ’"
    },
    {
      "verse": "12",
      "text": "They said:‘This is true! We worship our God and we give him honour. He is completely wise. We thank him and we praise him. He has all power and authority for ever! Amen! ’"
    },
    {
      "verse": "13",
      "text": "Then one of the leaders asked me, ‘Who are these people in white clothes? Where did they come from? ’"
    },
    {
      "verse": "14",
      "text": "I replied, ‘You surely know who they are, sir. ’He said to me, ‘They are the people who have had a time of very bad trouble. Now they have come out of that. They have washed their clothes in the blood of the Lamb. Now their clothes are white and clean."
    },
    {
      "verse": "15",
      "text": "Because of that, they are now standing in front of God's throne. They serve God in his house all the time, day and night. And God will keep them safe because he is with them."
    },
    {
      "verse": "16",
      "text": "They will never again be hungry. They will never be thirsty. The sun will not burn them, nor will any other strong heat burn them."
    },
    {
      "verse": "17",
      "text": "The Lamb is there with them, near to God's throne. He will take care of them, like a shepherd with his sheep. He will take them to drink fresh water that gives people life. They will no longer be sad. God will take away all the tears from their eyes. ’"
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "The Lamb opened the seventh seal. Then it became completely quiet in heaven for about half an hour."
    },
    {
      "verse": "2",
      "text": "Then I saw the seven angels who stand in front of God. Someone gave them seven trumpets."
    },
    {
      "verse": "3",
      "text": "Then another angel came. He stood at the altar where people offered gifts to God. He had a gold bowl to put incense in. He received a lot of incense and he burned it as a gift to God. It made a nice smell and it mixed with the prayers of God's people. The angel offered the incense and the prayers on the gold altar that was in front of God's throne."
    },
    {
      "verse": "4",
      "text": "When he did that, the smoke from the incense went up in front of God. The prayers of God's people also went up to God."
    },
    {
      "verse": "5",
      "text": "Then the angel took the gold bowl and he filled it with fire from the altar. Then he threw it all down onto the earth. There were loud noises and the sound of thunder. There was bright lightning, like a very bad storm. The earth shook with an earthquake."
    },
    {
      "verse": "6",
      "text": "Then the seven angels with the seven trumpets prepared to make a noise with their trumpets."
    },
    {
      "verse": "7",
      "text": "The first angel made a sound with his trumpet. Strong rain with stones of ice fell on the earth. The rain was mixed with fire and blood and it poured down. It burned a third of the earth. It destroyed a third of the trees and all the green grass."
    },
    {
      "verse": "8",
      "text": "Then the second angel made a sound with his trumpet. I saw something like a very big mountain that was burning with fire. This mountain fell down into the sea. A third of the sea became blood."
    },
    {
      "verse": "9",
      "text": "A third of the animals that lived in the sea died. It also destroyed a third of the ships on the sea."
    },
    {
      "verse": "10",
      "text": "Then the third angel made a sound with his trumpet. I saw a very big star, which was burning with a bright light. It fell from the sky on a third of the rivers and the springs of water."
    },
    {
      "verse": "11",
      "text": "The name of the star means ‘It tastes bad’. A third of the water on the earth became bad. Many people died because they drank that bad water."
    },
    {
      "verse": "12",
      "text": "Then the fourth angel made a sound with his trumpet. A third of the sun became dark. A third of the moon and a third of the stars also became dark. There was no light for a third of the day and there was no light for a third of the night."
    },
    {
      "verse": "13",
      "text": "Then I looked up. I saw an eagle that was flying high in the sky above me. I heard it say with a loud voice, ‘Great trouble! Great trouble! Yes, great trouble is coming to the people who live on the earth! Very bad things will happen when the other three angels make a sound with their trumpets! ’"
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "The fifth angel made a sound with his trumpet. Then I saw a star that had fallen down from the sky to the earth. Someone gave a key to that star. The key could open the entrance to the deep hole."
    },
    {
      "verse": "2",
      "text": "When the star opened the entrance, smoke came up out of the hole. It was like the smoke from a very big hot fire. The smoke caused the sun and the sky to become dark."
    },
    {
      "verse": "3",
      "text": "Then locusts came out of the smoke and they came down on the earth. They received power to cause great pain, like the power of scorpions."
    },
    {
      "verse": "4",
      "text": "They knew that they must not do anything bad to the grass on the earth. They must not attack any plant or any tree. They could only attack people who did not have God's seal on the front of their heads."
    },
    {
      "verse": "5",
      "text": "The locusts did not have authority to kill those people. But they could cause them very bad pain for five months. Their pain was like the great pain from a scorpion when it hurts someone."
    },
    {
      "verse": "6",
      "text": "During that time of great pain, people will want to kill themselves. They will want to die, but they will not find any way to die."
    },
    {
      "verse": "7",
      "text": "The locusts were like horses that were ready to fight in a war. They wore something on their heads that seemed to be gold crowns. Their faces looked like human faces."
    },
    {
      "verse": "8",
      "text": "Their hair was like women's hair. Their teeth were like lions' teeth."
    },
    {
      "verse": "9",
      "text": "They had shields over the front of their bodies, like shields made from iron. Their wings made a very loud noise. The sound was like many horses that are pulling chariots into a battle."
    },
    {
      "verse": "10",
      "text": "They had poison in their tails, like scorpions. They had power to attack people with their tails and to cause them pain for five months."
    },
    {
      "verse": "11",
      "text": "The king that ruled them was the angel of the deep hole. His name is ‘Abaddon’ in the Hebrew language. In the Greek language his name is ‘Apollyon’."
    },
    {
      "verse": "12",
      "text": "The first great trouble has now finished. But after all these things, there are two more great troubles still to come."
    },
    {
      "verse": "13",
      "text": "Then the sixth angel made a sound with his trumpet. I heard a voice that spoke to him from the four corners of the gold altar. This altar is near to God himself."
    },
    {
      "verse": "14",
      "text": "The voice said to the sixth angel, ‘There are four angels at the great Euphrates river. Someone has tied them so that they cannot move. You must go and undo them! ’"
    },
    {
      "verse": "15",
      "text": "So the four angels now became free. God had kept them ready for that special time, for that hour, in that day, in that month, in that year. They were now ready to kill a third of people everywhere."
    },
    {
      "verse": "16",
      "text": "I heard how many soldiers there were in their great army. There were 200 million soldiers who rode on horses."
    },
    {
      "verse": "17",
      "text": "In my vision, I saw the soldiers and their horses. The soldiers had shields over the front of their bodies. The shields had many colours. They were bright red like fire, bright blue, and yellow like sulphur. The horses' heads looked like lions' heads. Fire, smoke and sulphur came out of their mouths."
    },
    {
      "verse": "18",
      "text": "The fire, the smoke and the sulphur killed people. These three dangerous things killed a third of people everywhere."
    },
    {
      "verse": "19",
      "text": "The horses had great power in their mouths and in their tails. Their tails were like snakes, with heads that could hurt people very much."
    },
    {
      "verse": "20",
      "text": "But all the people that the fire, the smoke and the sulphur did not kill continued to do bad things. They did not change how they lived. They worshipped things that they had made for themselves. They worshipped demons and idols that they made from gold, silver, bronze, stone and wood. Those idols cannot see anything or hear anything. They cannot walk anywhere. But the people continued to worship them."
    },
    {
      "verse": "21",
      "text": "They were not sorry that they murdered other people. They were not sorry that they used magic to hurt people. They continued to have sex with people in wrong ways. They continued to rob other people. They did not want to change the way that they lived."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "Then I saw another powerful angel. He was coming down from heaven. He had a cloud all round him, like his clothes. There was a rainbow above his head. His face was like the sun and his legs shone like fire."
    },
    {
      "verse": "2",
      "text": "He had a little book in his hand and it was open. He put his right foot on the sea and he put his left foot on the land."
    },
    {
      "verse": "3",
      "text": "Then he shouted with a loud voice, like a lion that roars. When he shouted, seven loud voices answered him. They were like the noise of thunder."
    },
    {
      "verse": "4",
      "text": "When the seven voices of thunder spoke, I was ready to write. But I heard a voice that came from heaven. The voice said to me, ‘Keep secret what the seven voices of thunder have said. Do not write it down. ’"
    },
    {
      "verse": "5",
      "text": "Then I looked again at the angel who stood with one foot on the sea and his other foot on the land. He raised his right hand towards heaven."
    },
    {
      "verse": "6",
      "text": "He made a strong promise by the name of God, who lives for ever. He created heaven, the earth and the sea, as well as everything that is in them. The angel said, ‘There is no more time to wait!"
    },
    {
      "verse": "7",
      "text": "Now is the time when the seventh angel will make a sound with his trumpet. Then God will quickly finish what he wants to do. This has been a secret, but he told it long ago to the prophets who were his servants. ’"
    },
    {
      "verse": "8",
      "text": "Then I heard again the voice that spoke to me from heaven. He said, ‘Go to the angel who is standing with one foot on the sea and his other foot on the land. Go and take the book that is open in his hand. ’"
    },
    {
      "verse": "9",
      "text": "So I went to the angel. I asked him to give me the little book. He said to me, ‘Take the book and then eat it. It will be very sweet like honey in your mouth. But it will hurt your stomach like bad food. ’"
    },
    {
      "verse": "10",
      "text": "So I took the little book from the angel's hand and I ate it. It was as sweet as honey in my mouth. But when I had eaten the book, it hurt my stomach."
    },
    {
      "verse": "11",
      "text": "Then the voice said to me, ‘You must continue to tell God's message to people. You must say what will happen to people from everywhere in the world. They are the people of many nations, and people who speak many languages, and also their kings. ’"
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "Someone gave me a stick, like the sticks that people use to measure things. He told me, ‘Go and measure the size of the temple and the altar. Also count the number of people who worship God there."
    },
    {
      "verse": "2",
      "text": "But do not measure the yard that is outside God's house. Do not measure it, because God has given that yard to Gentiles who do not believe in him. They will stamp all over God's own city for 42 months and they will destroy it."
    },
    {
      "verse": "3",
      "text": "I will give authority to my two servants who speak my message clearly. They will tell people my messages for 1, 260 days. They will wear rough clothes made from goats' hair. ’"
    },
    {
      "verse": "4",
      "text": "These servants are the two olive trees and the two lampstands. They stand in front of God who is the Lord of the earth."
    },
    {
      "verse": "5",
      "text": "If anyone tries to hurt them, fire comes out of the servants' mouths. This fire destroys their enemies. Anyone who wants to hurt the two servants must die in this way."
    },
    {
      "verse": "6",
      "text": "These servants of God have authority to shut up the sky. Then there will be no rain during the time that they tell their messages from God. They also have authority to cause the water on earth to become blood. They can cause many different kinds of trouble to happen on the earth. They can do this as often as they want to."
    },
    {
      "verse": "7",
      "text": "When these two servants of God have finished speaking God's messages, a wild animal will attack them. This is the animal that lives in the deep hole. It will come up out of the hole. It will be stronger than the two servants and it will kill them."
    },
    {
      "verse": "8",
      "text": "Their dead bodies will lie in the street of the great city where people killed their Lord on a cross. This city should be called Sodom or Egypt, because it is as bad as those places."
    },
    {
      "verse": "9",
      "text": "People from everywhere in the world will look at the servants' dead bodies for three and a half days. Those are people from every nation, from every tribe and from every language. They will not agree to bury the bodies."
    },
    {
      "verse": "10",
      "text": "The people who live on the earth will be very happy because the two servants of God are now dead. They will send gifts to each other because they are so happy. These two prophets of God had caused bad trouble for them, but now they have died."
    },
    {
      "verse": "11",
      "text": "But after three and a half days, God breathed life into those dead bodies. They stood up. The people who saw them were very afraid."
    },
    {
      "verse": "12",
      "text": "Then God's two servants heard a loud voice that came from heaven. The voice said, ‘Come up here. ’ They went up to heaven in a cloud, while their enemies watched them."
    },
    {
      "verse": "13",
      "text": "At the same time the ground shook with a strong earthquake. One in every ten buildings in the city fell down. 7, 000 people died because of the earthquake. The people who were still alive became very afraid. They praised the God of heaven and said that he is very powerful."
    },
    {
      "verse": "14",
      "text": "That is the second great trouble and it has now finished. But the third great trouble will come soon."
    },
    {
      "verse": "15",
      "text": "The seventh angel made a sound with his trumpet. Then there was the sound of loud voices in heaven. They shouted:‘Our Lord God and his Messiah now have all authority! The whole world has become their kingdom. God will rule as King for ever! ’ ‘Our Lord God and his Messiah now have all authority! The whole world has become their kingdom. God will rule as King for ever! ’"
    },
    {
      "verse": "16",
      "text": "leaders were sitting on their thrones in front of God. Now they threw themselves down on their faces and they worshipped God. ‘We thank you, Lord God, because you have all authority! You are alive now and you have always been alive. You have great power and now you have begun to rule the whole world!"
    },
    {
      "verse": "17",
      "text": "They said:‘We thank you, Lord God, because you have all authority! You are alive now and you have always been alive. You have great power and now you have begun to rule the whole world!"
    },
    {
      "verse": "18",
      "text": "The nations of the world were very angry. But now it is time for you to be angry with them. Now you will judge all the people who have died. You will give good things to your servants, the prophets, and to all your people. You will bless everyone who respects and obeys you, whether they are important people or not. But you will destroy all those people who destroy the earth. The time has now come for all this to happen. ’ But now it is time for you to be angry with them. Now you will judge all the people who have died. You will give good things to your servants, the prophets, and to all your people. You will bless everyone who respects and obeys you, whether they are important people or not. But you will destroy all those people who destroy the earth. The time has now come for all this to happen. ’"
    },
    {
      "verse": "19",
      "text": "Then the door of the temple in heaven became open. Inside it, I saw God's Covenant Box. There was a great storm with bright lightning and the loud noise of thunder. There was an earthquake and strong rain with stones of ice fell from the sky."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "A very wonderful thing then appeared in the sky. I saw a woman who was wearing the sun like her clothes. The moon was under her feet. A crown of 12 stars was on her head."
    },
    {
      "verse": "2",
      "text": "She was pregnant. She screamed with pain as she tried to give birth to her baby."
    },
    {
      "verse": "3",
      "text": "Then another wonderful thing appeared in the sky. It was a very big red dragon. It had seven heads and ten horns. There was a crown on each head."
    },
    {
      "verse": "4",
      "text": "Its tail beat away a third of the stars from the sky. It threw them down on the earth. Then the dragon stood in front of the woman who would soon give birth to her baby. He was waiting there to eat her child as soon as he was born."
    },
    {
      "verse": "5",
      "text": "The woman gave birth to a son. He was a man who would rule all the nations of the world with strong authority. Then someone quickly took her child away. He went up to God and to his throne."
    },
    {
      "verse": "6",
      "text": "The woman ran away into the wilderness. God had prepared a special place to keep her safe there for 1, 260 days."
    },
    {
      "verse": "7",
      "text": "Then a war started in heaven. Michael and his angels fought against the dragon. The dragon and his army of angels fought against Michael and his angels. ‘Now God has saved his people from Satan's power! God has shown his great power as King. His Messiah has authority to rule. Satan said bad things against our people. He never stopped telling our God that our brothers and sisters are guilty. But now God has thrown him out of heaven."
    },
    {
      "verse": "8",
      "text": "But the dragon and his army were not strong enough to win the battle. They no longer had a place for themselves in heaven."
    },
    {
      "verse": "9",
      "text": "Michael and his angels threw the great dragon out of heaven. The dragon is called the Devil or Satan. He is the snake who has been there since long ago. He tells lies to deceive the whole world. They threw him down to the earth, together with all his angels."
    },
    {
      "verse": "10",
      "text": "Then I heard a loud voice in heaven that said:‘Now God has saved his people from Satan's power! God has shown his great power as King. His Messiah has authority to rule. Satan said bad things against our people. He never stopped telling our God that our brothers and sisters are guilty. But now God has thrown him out of heaven."
    },
    {
      "verse": "11",
      "text": "Our brothers and sisters fought against him and they won. They could do this because of the death of the Lamb as a sacrifice. They continued to speak God's true message. They were also ready to die as God's servants. That is why they were able to win against Satan. They could do this because of the death of the Lamb as a sacrifice. They continued to speak God's true message. They were also ready to die as God's servants. That is why they were able to win against Satan."
    },
    {
      "verse": "12",
      "text": "So be happy, everyone who lives in heaven! But terrible trouble will happen to the earth and the sea. The Devil has come down to you now and he is very angry. He knows that he has only a short time to hurt people. ’ But terrible trouble will happen to the earth and the sea. The Devil has come down to you now and he is very angry. He knows that he has only a short time to hurt people. ’"
    },
    {
      "verse": "13",
      "text": "The dragon realized that they had thrown him down to the earth. So he chased after the woman who had given birth to the baby boy. He wanted to catch her."
    },
    {
      "verse": "14",
      "text": "But the woman received the two wings of a very big eagle. Then she could fly to the place in the wilderness that God had prepared for her. In that place God would keep her safe from the big snake. God would take care of her there for a time, times and half a time."
    },
    {
      "verse": "15",
      "text": "Then the dragon poured lots of water out of his mouth like a river. He wanted the river of water to carry the woman away."
    },
    {
      "verse": "16",
      "text": "But a big hole opened in the ground. The river that poured from the dragon's mouth went down into the hole. That helped the woman to escape."
    },
    {
      "verse": "17",
      "text": "As a result, the dragon was very angry with the woman. So he went away to fight a war against her other descendants. Those are the people who obey God's commands. They continue to trust Jesus and to speak his message. After that, the dragon stood on the shore of the sea."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "Then I saw a wild animal that was coming up out of the sea. It had ten horns and there was a crown on each horn. The animal also had seven heads. On each head there was a bad name that insulted God."
    },
    {
      "verse": "2",
      "text": "The wild animal that I saw was like a leopard. But its feet were like a bear's feet and its mouth was like a lion's mouth. The dragon gave his own power and great authority to the wild animal so that it could rule as king."
    },
    {
      "verse": "3",
      "text": "Someone had hurt one of the wild animal's heads with a bad wound. It seemed that it would soon die. But the wound in the animal's head had become well again. This surprised all the people who were living on the earth. As a result, they were ready to obey what the wild animal said."
    },
    {
      "verse": "4",
      "text": "People worshipped the dragon because he had given his authority to the wild animal. They also worshipped the wild animal. They said, ‘Nobody is like this animal! Nobody is strong enough to fight against him! ’"
    },
    {
      "verse": "5",
      "text": "months. It could speak proud words and insult God."
    },
    {
      "verse": "6",
      "text": "So it started to speak against God. It insulted God's name and the place where he lives, as well as the people who live there in heaven."
    },
    {
      "verse": "7",
      "text": "It received power to fight a war against God's own people and to win against them. It received authority to rule over people from every nation, people from every tribe and people from every language."
    },
    {
      "verse": "8",
      "text": "Nearly all the people who live on the earth will worship the wild animal. But those people whose names are in the Lamb's book of life will not worship it. The Lamb wrote the names of these believers in his book from the beginning of the world. He is the Lamb that people killed as a sacrifice."
    },
    {
      "verse": "9",
      "text": "Everyone who can understand should listen carefully to these words:"
    },
    {
      "verse": "10",
      "text": "‘If it is right for someone's enemy to catch him, that is what will happen. If it is right for someone's enemy to kill him with a sword, that is what will happen. ’This means that God's people must be patient and strong. They must continue to trust God. If it is right for someone's enemy to kill him with a sword, that is what will happen. ’ This means that God's people must be patient and strong. They must continue to trust God."
    },
    {
      "verse": "11",
      "text": "Then I saw a second wild animal. This one was coming up out of the ground. It had two horns like a lamb's horns. But it spoke like a dragon."
    },
    {
      "verse": "12",
      "text": "It worked for the first wild animal and it used the authority of the first wild animal. It made all the people on earth worship the first wild animal. That first animal was the one that someone had hurt very much. It seemed that it would soon die but it had become well again."
    },
    {
      "verse": "13",
      "text": "The second wild animal did great miracles. It even caused fire to come down from heaven to the earth, while people watched."
    },
    {
      "verse": "14",
      "text": "It used the authority of the first wild animal to do many miracles. In that way, it deceived the people who lived on the earth. It told them to make an image of the first wild animal. This was the animal that was still alive after a sword had given it a bad wound."
    },
    {
      "verse": "15",
      "text": "The second wild animal received power to give life to the image of the first wild animal. As a result, the image could speak. It said, ‘Anyone who refuses to worship me must die! ’"
    },
    {
      "verse": "16",
      "text": "The second wild animal also caused everyone to receive a mark. Everyone received a mark on their right hand or on the front of their head. This included important people and ordinary people, rich people and poor people, free people and slaves."
    },
    {
      "verse": "17",
      "text": "Nobody could buy anything unless they had this mark on them. Nor could they sell anything. This mark shows the wild animal's name or the number of its name."
    },
    {
      "verse": "18",
      "text": "You must think carefully so that you can understand this number. Anyone who is wise should try to understand what the wild animal's number means. It is a human number. The number is 666."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "Then I looked again and I saw the Lamb. He was standing on Mount Zion in Jerusalem. There were 144, 000 people there with him. The Lamb's name and his Father's name were written on the front of those people's heads."
    },
    {
      "verse": "2",
      "text": "Then I heard a loud sound which came from heaven. The noise was like water that pours along a river very fast. It was like the loud noise of thunder. The sound was like people who were making music with harps."
    },
    {
      "verse": "3",
      "text": "The 144, 000 people were singing a new song that they had learned. They sang it in front of the throne. They sang in front of the four beings that are alive and in front of the leaders. Only these 144, 000 people could learn the new song. They are the people that God had saved from among the people who lived on the earth."
    },
    {
      "verse": "4",
      "text": "These 144, 000 people have kept themselves pure. They have not had sex with women in a wrong way. They follow the Lamb everywhere that he goes. God has saved them from among the people of the world and he has paid for their sins. They are the first people to become a gift to God and to the Lamb."
    },
    {
      "verse": "5",
      "text": "They have not spoken any lies. They have done nothing wrong."
    },
    {
      "verse": "6",
      "text": "Then I saw another angel who was flying high in the sky above me. He brought God's message of good news that is always true. He came to tell this news to everyone who lives on the earth. He would tell it to people from every nation, from every tribe and from every language."
    },
    {
      "verse": "7",
      "text": "He said in a loud voice, ‘Respect God and give him honour! Now it is time for him to judge people. He made the sky and the earth and the sea. He also made the springs of water. So worship him! ’"
    },
    {
      "verse": "8",
      "text": "A second angel followed the first one. He said, ‘God has destroyed Babylon! It is no longer a great city! It has caused people everywhere to do the same bad things as it enjoys. She is like a prostitute who makes men become drunk and have sex in a wrong way. She has caused them to turn away from God. ’"
    },
    {
      "verse": "9",
      "text": "A third angel followed the other two angels. He said in a loud voice, ‘If anyone worships the wild animal and its idol, God will punish them. If anyone receives that animal's mark on their head or on their hand, God will punish them."
    },
    {
      "verse": "10",
      "text": "God will be very angry with all those people. They will be like people who must drink God's strong wine. When they drink wine from the cup of God's anger, they will have terrible pain. Fire and sulphur will burn them. God's angels and the Lamb will watch while God punishes them."
    },
    {
      "verse": "11",
      "text": "The smoke will rise for ever while they burn. They will have no rest during the day or during the night. This will happen to everyone who worships the wild animal and its image. It will happen to everyone who receives the mark which shows its name. ’"
    },
    {
      "verse": "12",
      "text": "This means that God's people must go on being patient and strong. They must continue to obey God's rules. They must continue to trust Jesus."
    },
    {
      "verse": "13",
      "text": "Then I heard a voice that spoke from heaven. It said, ‘Write this: From this time, people who continue to believe in the Lord and then they die will be very happy. ’ God's Spirit says, ‘Yes, they will rest from their work. God will not forget the good things that they have done. ’"
    },
    {
      "verse": "14",
      "text": "Then I looked, and I saw a white cloud in front of me. I saw someone who was like a son of man. He was sitting on the cloud. He had a gold crown on his head and a sharp knife in his hand."
    },
    {
      "verse": "15",
      "text": "Then another angel came out from God's house in heaven. He shouted with a loud voice to the person who was sitting on the cloud. He told him, ‘Use your sharp knife and start to work. It is time to bring in the harvest. Cut down the plants and bring them in. The harvest on the earth is now ready. ’"
    },
    {
      "verse": "16",
      "text": "Then the person who sat on the cloud moved his sharp knife over the earth. He cut down the earth's plants and he brought in the harvest."
    },
    {
      "verse": "17",
      "text": "Then another angel came out from God's house in heaven. He also had a sharp knife in his hand."
    },
    {
      "verse": "18",
      "text": "Again, another angel came from the altar where people offered gifts to God. This angel had authority for the fire on the altar. He shouted with a loud voice to the angel who had the sharp knife. He told him, ‘Use your knife and cut the grapes off the earth's vine. The grapes are ready now to make wine. ’"
    },
    {
      "verse": "19",
      "text": "So the angel moved his sharp knife over the earth. He cut off the grapes which grew in the earth's vineyard. He threw the grapes into the winepress where God stamps on the grapes because he is very angry."
    },
    {
      "verse": "20",
      "text": "The winepress was outside the city. When God stamped on the grapes, the juice that came out of the winepress was blood. The river of blood was very deep. It rose as high as horses' necks and it went as far as 300 kilometres."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "Then I saw another very wonderful thing in the sky. I saw seven angels with seven terrible troubles to hurt people. They are the final troubles. When they have finished, God will stop being angry."
    },
    {
      "verse": "2",
      "text": "Then I saw what seemed to be a glass sea. Fire was mixed in it. I also saw people who were standing at the edge of the glass sea. Those people had fought against the wild animal and they had won. They had won against its image and the number that means its name. They had fought and they had won. God had given them harps. They held the harps to make music. ‘Lord God with all power, what you do is great and wonderful! Everything that you do is completely fair and honest. You are King of all nations of the world."
    },
    {
      "verse": "3",
      "text": "Now they sang the song of God's servant, Moses, and the Lamb's song. They sang this:‘Lord God with all power, what you do is great and wonderful! Everything that you do is completely fair and honest. You are King of all nations of the world."
    },
    {
      "verse": "4",
      "text": "Everyone will respect and obey you, Lord. They will say how great your name is, because only you are completely good. People from every nation have seen what you do. You always do what is right. So all people will come and stand in front of you, and they will worship you. ’ They will say how great your name is, because only you are completely good. People from every nation have seen what you do. You always do what is right. So all people will come and stand in front of you, and they will worship you. ’"
    },
    {
      "verse": "5",
      "text": "After this I looked again. I saw that God's house in heaven was open. That house is like God's tent, where he lived among his people in the wilderness."
    },
    {
      "verse": "6",
      "text": "The seven angels with the seven terrible troubles then came out of God's house. They were wearing clean, bright clothes that were made from linen. They had gold belts around the top part of their bodies."
    },
    {
      "verse": "7",
      "text": "Then one of the four beings that were alive gave seven gold bowls to the seven angels. God had poured his anger into the bowls. He is the God who is alive for ever."
    },
    {
      "verse": "8",
      "text": "Then God's house in heaven became full of smoke, which showed God's great glory and his power. As a result, nobody could go into God's house until the angels had finished sending the seven terrible troubles."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "Then I heard a loud voice speak from God's house in heaven. It said to the seven angels, ‘Take your seven bowls that are full of God's anger. Go and pour them out on the earth. ’"
    },
    {
      "verse": "2",
      "text": "The first angel went and poured out his bowl on the land. As a result, very bad and painful sores appeared on people's skin. Everyone who had the wild animal's mark on them and who worshipped the animal's image had those sores."
    },
    {
      "verse": "3",
      "text": "Then the second angel poured out his bowl on the sea. As a result, the sea became like the blood of a dead person. Everything that was living in the sea then died."
    },
    {
      "verse": "4",
      "text": "Then the third angel poured out his bowl on the rivers and on the springs of water. As a result, all the water became blood."
    },
    {
      "verse": "5",
      "text": "Then I heard the voice of the angel who had authority over the waters. He said to God, ‘Holy One, you are alive now and you always have been alive. You are right in everything that you decide. Now you have judged these people. ‘Holy One, you are alive now and you always have been alive. You are right in everything that you decide. Now you have judged these people."
    },
    {
      "verse": "6",
      "text": "They have killed your people and your prophets. They have caused your servants to bleed and to die. So now you have given these bad people blood to drink. That is what ought to happen to them. It is right. ’ They have caused your servants to bleed and to die. So now you have given these bad people blood to drink. That is what ought to happen to them. It is right. ’"
    },
    {
      "verse": "7",
      "text": "Then I heard a voice from the altar in heaven. It said, ‘Yes, Lord God, you have all authority. When you judge people, it is the punishment that they deserve. ’ ‘Yes, Lord God, you have all authority. When you judge people, it is the punishment that they deserve. ’"
    },
    {
      "verse": "8",
      "text": "Then the fourth angel poured out his bowl on the sun. God gave authority to the sun so that it burned people with fire."
    },
    {
      "verse": "9",
      "text": "The strong heat burned people and it hurt them very much. As a result, they said bad things against God's name, because he had the power to cause these terrible troubles. But they refused to change how they lived. They refused to agree that God is great."
    },
    {
      "verse": "10",
      "text": "Then the fifth angel poured out his bowl on the throne of the wild animal. As a result, the whole kingdom that the wild animal ruled became dark. People were biting their tongues because of their great pain."
    },
    {
      "verse": "11",
      "text": "They cursed the God of heaven because of their pain and because of the sores on their skin. But they did not stop doing bad things."
    },
    {
      "verse": "12",
      "text": "Then the sixth angel poured out his bowl on the great Euphrates river. As a result, the river became dry. This prepared a way for kings from the east to march across it."
    },
    {
      "verse": "13",
      "text": "Then I saw three bad spirits that looked like frogs. One bad spirit came out of the dragon's mouth. Another one came out of the first wild animal's mouth. The third one came out of the false prophet's mouth."
    },
    {
      "verse": "14",
      "text": "Those bad spirits are the spirits of demons. They had the power to do miracles. They went to all the rulers in the whole world, to bring them together to fight in a big war. That war will happen on the great day of God, who has all power and authority."
    },
    {
      "verse": "15",
      "text": "The Lord says: ‘Listen! I will come secretly, like someone who robs people. If you continue to watch carefully, you will be happy. Keep your clothes with you all the time. Then, when I come, you will not be ashamed because you have no clothes. ’"
    },
    {
      "verse": "16",
      "text": "Then the bad spirits brought the rulers together to fight in the big war. They came to the place that is called Armageddon in the Hebrew language."
    },
    {
      "verse": "17",
      "text": "Then the seventh angel poured out his bowl into the air. A voice spoke loudly from the throne in God's house. The voice said, ‘Now it has happened! ’"
    },
    {
      "verse": "18",
      "text": "There was a great storm, with bright lightning and loud noises of thunder. The ground shook with a strong earthquake. The earthquake was stronger than anything that had happened since people first lived on the earth."
    },
    {
      "verse": "19",
      "text": "As a result, the great city of Babylon broke into three parts. When the ground shook, it also destroyed the big cities of other nations in the world. God did not forget the evil things that the people of the great city of Babylon had done. So they had to drink wine from the cup of God's great anger."
    },
    {
      "verse": "20",
      "text": "When the ground shook, every island in the sea disappeared. There were no more mountains anywhere."
    },
    {
      "verse": "21",
      "text": "Strong rain with stones of ice fell from the sky. The stones hit people and caused them great pain. The weight of each stone was about 50 kilograms. The people cursed God because the strong rain and the stones of ice caused them to have such terrible pain."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "One of the seven angels that had the seven bowls came to me. ‘Come with me, ’ he said. ‘I will show you how God will punish the great prostitute. She sits at a place where there are many rivers."
    },
    {
      "verse": "2",
      "text": "It is like the kings who rule on the earth have had sex with that bad woman. She has led the people who live on the earth to do bad things. They have become drunk from the strong wine that she has given to them. ’"
    },
    {
      "verse": "3",
      "text": "Again, God's Spirit caused me to see and to hear strange things. The angel carried me away to a wilderness. There I saw a woman who was sitting on a wild animal that was bright red. All over this wild animal, names were written that insulted God. The animal had seven heads and ten horns. Powerful Babylon. Mother of all prostitutes. Mother of all the disgusting things on the earth."
    },
    {
      "verse": "4",
      "text": "The woman was wearing clothes that were made from expensive cloth. She also wore bright things that made her look beautiful. She shone with gold, valuable stones and pearls. She held a gold cup in her hand. The cup was full of the bad and disgusting things that she had caused people to do."
    },
    {
      "verse": "5",
      "text": "A name was written on the front of her head. Only God knows what it means. It was: Powerful Babylon. Mother of all prostitutes. Mother of all the disgusting things on the earth."
    },
    {
      "verse": "6",
      "text": "I saw that the woman was like a drunk. She was like someone who had drunk the blood of God's people. She had killed them because they had told other people about Jesus. When I saw her, I was very surprised."
    },
    {
      "verse": "7",
      "text": "Then the angel asked me, ‘Why are you surprised? I will explain the secret of the woman to you. I will tell you the secret of the wild animal that she rides. The wild animal that you saw has seven heads and ten horns."
    },
    {
      "verse": "8",
      "text": "This animal was once alive, but it is not alive now. Soon it will come up out of the deep hole again but then God will destroy it completely. All these things will surprise many people who live on the earth. Those are the people whose names are not written in God's book of life from the beginning of the world. They will be surprised to see the animal that was alive at one time. It is not alive now, but it will soon appear again."
    },
    {
      "verse": "9",
      "text": "If you are wise, think carefully about this. The animal's seven heads are a picture of seven hills in the place where the woman sits."
    },
    {
      "verse": "10",
      "text": "They are also a picture of seven kings. Five of these kings have already stopped ruling. Another king is ruling now. The last king has not yet come. When he does come, he must rule only for a short time."
    },
    {
      "verse": "11",
      "text": "The wild animal is a picture of an eighth king. He was alive once, but he is not alive now. He belongs to the group of seven kings, but God will destroy him completely."
    },
    {
      "verse": "12",
      "text": "The ten horns that you saw are a picture of ten more kings. They have not yet begun to rule anywhere. But they will receive authority to rule as kings for one hour. They will rule people together with the wild animal."
    },
    {
      "verse": "13",
      "text": "They all have the same purpose. They will give their power to the wild animal. They will give him authority to rule people."
    },
    {
      "verse": "14",
      "text": "Together they will fight a war against the Lamb. But the Lamb will win against them. He is the Lord above all lords. He is the King who rules over all kings. And God's people will be with him. They are the people that the Lamb has chosen to belong to him. They are the people who have continued to trust him. ’"
    },
    {
      "verse": "15",
      "text": "Then the angel said to me, ‘You saw the many rivers where the prostitute sits. Those rivers are a picture of people from many nations. They are crowds of people from different countries who speak many different languages."
    },
    {
      "verse": "16",
      "text": "The wild animal and the ten horns that you saw will hate the prostitute. Those rulers will destroy her. They will remove all her clothes. They will eat the meat on her body. Then they will burn her with fire."
    },
    {
      "verse": "17",
      "text": "They will decide to do that because God has given them those thoughts. So, they will do what he wants. They will give to the wild animal their authority to rule as king. The animal will continue to rule until everything happens that God has said will happen."
    },
    {
      "verse": "18",
      "text": "The bad woman that you saw is a picture of the great city. That city has power over all the kings who rule on the earth. ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "After these things happened, I saw another angel. He was coming down from heaven. He had great authority. He was beautiful and he shone brightly. He gave light to the whole world. ‘God has destroyed the great city of Babylon! She has become a place where demons live. She is a home for every disgusting spirit. She is a home for every unclean bird. She is a home for every unclean and disgusting animal."
    },
    {
      "verse": "2",
      "text": "He shouted with a very loud voice:‘God has destroyed the great city of Babylon! She has become a place where demons live. She is a home for every disgusting spirit. She is a home for every unclean bird. She is a home for every unclean and disgusting animal."
    },
    {
      "verse": "3",
      "text": "She has been like a prostitute who makes men become drunk. Then she leads them to have sex in a wrong way. She has caused people from every nation to turn away from God. It is like all the kings of the earth have had sex with that bad woman. All the traders of the earth have become rich, because she has bought things from them to enjoy a wicked life. ’ Then she leads them to have sex in a wrong way. She has caused people from every nation to turn away from God. It is like all the kings of the earth have had sex with that bad woman. All the traders of the earth have become rich, because she has bought things from them to enjoy a wicked life. ’"
    },
    {
      "verse": "4",
      "text": "Then I heard another voice which spoke from heaven. It said:‘My people, leave the city! Come out! Do not do the bad things that the people of that city have done. Then you will not receive the terrible troubles that God sends to them. ‘My people, leave the city! Come out! Do not do the bad things that the people of that city have done. Then you will not receive the terrible troubles that God sends to them."
    },
    {
      "verse": "5",
      "text": "They have done very many bad things. Their sins have reached as high as heaven. God has remembered to punish them. Their sins have reached as high as heaven. God has remembered to punish them."
    },
    {
      "verse": "6",
      "text": "Yes, punish the people of that city. Do to them the same things that they have done to others. Punish them with twice the bad things that they themselves have done. She caused people to drink pain from her cup. Now make her drink twice as much pain for herself! Do to them the same things that they have done to others. Punish them with twice the bad things that they themselves have done. She caused people to drink pain from her cup. Now make her drink twice as much pain for herself!"
    },
    {
      "verse": "7",
      "text": "She liked to receive honour. She bought expensive things to enjoy a wicked life. So now give her the trouble and pain that she deserves. She has said to herself, “I rule people like a queen. I do not live like a widow. I will never need to be sad. ” She bought expensive things to enjoy a wicked life. So now give her the trouble and pain that she deserves. She has said to herself, “I rule people like a queen. I do not live like a widow. I will never need to be sad. ”"
    },
    {
      "verse": "8",
      "text": "Because she speaks like that, she will receive many troubles in one single day. Her people will become very ill. They will be very sad. They will have no food to eat. Fire will destroy the city, The Lord God is powerful. So he will punish her with these troubles. ’ she will receive many troubles in one single day. Her people will become very ill. They will be very sad. They will have no food to eat. Fire will destroy the city, The Lord God is powerful. So he will punish her with these troubles. ’"
    },
    {
      "verse": "9",
      "text": "When all that happens, the kings on the earth will be very sad. They enjoyed the bad things that people did in that city. They had many expensive things so that they were happy. Now they will see the smoke from the fire that burns the city. As a result, they will cry and they will weep. ‘Terrible trouble has come to you, Babylon! Great city! Powerful city! It is very bad for you! In one single hour God has destroyed you! ’"
    },
    {
      "verse": "10",
      "text": "They will stand a long way from the city because they are afraid. They do not want to suffer in the same way. They will say, ‘Terrible trouble has come to you, Babylon! Great city! Powerful city! It is very bad for you! In one single hour God has destroyed you! ’"
    },
    {
      "verse": "11",
      "text": "The traders of this world will also be very sad. They will weep because nobody will buy their things any more."
    },
    {
      "verse": "12",
      "text": "They sold many expensive things like these: Things made from gold and silver. Valuable stones and pearls. Good linen and other kinds of expensive cloth that is red or purple. Things made from wood that has a nice smell. Many different things that are made from ivory. Many kinds of things that people had made from expensive wood, from different metals and from stone."
    },
    {
      "verse": "13",
      "text": "Different kinds of spice and incense, like myrrh and frankincense. Wine, olive oil, expensive flour and wheat. Cows and sheep. Horses and chariots. Human slaves."
    },
    {
      "verse": "14",
      "text": "The people who sold these things will say to the city, ‘You have now lost all the good things that you wanted so much. You have lost all those expensive things that made you beautiful. You will never have them again. ’"
    },
    {
      "verse": "15",
      "text": "The traders had become rich because of the city. But now they will stand a long way from the city because they are afraid. They do not want to suffer in the same way themselves. They will weep and they will be very sad. ‘Bad trouble has come to you, Babylon! Great city! It is very bad for you! You wore beautiful clothes that were made from good linen. You wore bright things that made you look beautiful. You shone with gold, valuable stones and pearls."
    },
    {
      "verse": "16",
      "text": "They will say, ‘Bad trouble has come to you, Babylon! Great city! It is very bad for you! You wore beautiful clothes that were made from good linen. You wore bright things that made you look beautiful. You shone with gold, valuable stones and pearls."
    },
    {
      "verse": "17",
      "text": "But in one single hour God has destroyed all those valuable things. ’All the sailors and the people who travel on ships will also be sad. They include every ship's captain, and everyone who works on ships on the sea. They will stand a long way from the city."
    },
    {
      "verse": "18",
      "text": "They will see the smoke from the fire that burns the city. Then they will shout, ‘There is no other city like this great city! ’ ‘Bad trouble has come to you, Babylon! Great city! It is very bad for you! Everyone who had ships on the sea became rich because of you. You used your money to buy their expensive things. But in one single hour God has destroyed that city. ’"
    },
    {
      "verse": "19",
      "text": "They will throw dirt from the ground on their heads because they are so sad. They will weep and they will shout, ‘Bad trouble has come to you, Babylon! Great city! It is very bad for you! Everyone who had ships on the sea became rich because of you. You used your money to buy their expensive things. But in one single hour God has destroyed that city. ’"
    },
    {
      "verse": "20",
      "text": "Yes, you who live in heaven, be happy! Be happy because God has punished Babylon! God's people and his apostles and his prophets, be happy! God has punished the city because of what she did to you. Be happy because God has punished Babylon! God's people and his apostles and his prophets, be happy! God has punished the city because of what she did to you."
    },
    {
      "verse": "21",
      "text": "Then a powerful angel picked up a very big, heavy stone. He threw it into the sea. He said, ‘God will throw you down, Babylon! You are a great city, but God will throw you down like this stone. Nobody will ever see you again! ‘God will throw you down, Babylon! You are a great city, but God will throw you down like this stone. Nobody will ever see you again!"
    },
    {
      "verse": "22",
      "text": "Nobody will ever hear music in the city again. Nobody will sing there. Nobody will make music with harps, or with flutes, or with trumpets. There will never be workers who make things in the city. Nobody will ever hear the sound of people who make flour again. Nobody will sing there. Nobody will make music with harps, or with flutes, or with trumpets. There will never be workers who make things in the city. Nobody will ever hear the sound of people who make flour again."
    },
    {
      "verse": "23",
      "text": "No light from people's lamps will ever shine in the city again. Nobody will ever hear the happy voices of a man and a woman when they marry. Your traders were the most powerful people on the earth. You used your magic to deceive people from all nations. Nobody will ever hear the happy voices of a man and a woman when they marry. Your traders were the most powerful people on the earth. You used your magic to deceive people from all nations."
    },
    {
      "verse": "24",
      "text": "Your people killed God's people and his prophets. Their blood lies on the ground in the city. The blood of everyone on earth that people have killed is also there. This shows that you are guilty of their murder. ’"
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "After these things, I heard a sound like the voices of a great crowd of people in heaven. They were shouting, ‘Praise the Lord our God! He has saved us! He is very powerful! We say that he is great! ‘Praise the Lord our God! He has saved us! He is very powerful! We say that he is great!"
    },
    {
      "verse": "2",
      "text": "Everything that he decides is right and fair. He has punished that great prostitute. She led people on the earth to do wicked things. She murdered God's servants with her own hands. But now God has punished her as she deserves. ’ He has punished that great prostitute. She led people on the earth to do wicked things. She murdered God's servants with her own hands. But now God has punished her as she deserves. ’"
    },
    {
      "verse": "3",
      "text": "Then the crowd of people in heaven shouted again, ‘Praise the Lord our God! The smoke from the fire that burns that city will go up for ever. ’ ‘Praise the Lord our God! The smoke from the fire that burns that city will go up for ever. ’"
    },
    {
      "verse": "4",
      "text": "leaders and the four beings that are alive then threw themselves down on the ground. They worshipped God, who was sitting on the throne. They said, ‘It is true! Praise the Lord God! ’"
    },
    {
      "verse": "5",
      "text": "Then a voice spoke from the throne. It said, ‘All of you who are God's servants, praise our God! All of you who respect God's power, worship him! Important people and ordinary people should worship him! ’ ‘All of you who are God's servants, praise our God! All of you who respect God's power, worship him! Important people and ordinary people should worship him! ’"
    },
    {
      "verse": "6",
      "text": "Then I heard a sound like the noise of a very big crowd that was shouting. The sound was like the noise of water that pours quickly along a river. It was like the noise of loud thunder. The crowd of people shouted, ‘Praise the Lord our God! He rules with all power and authority! ‘Praise the Lord our God! He rules with all power and authority!"
    },
    {
      "verse": "7",
      "text": "We must shout with joy because we are so happy! We will say that God is great! The time has come for the Lamb's wedding party. His bride has prepared herself. We will say that God is great! The time has come for the Lamb's wedding party. His bride has prepared herself."
    },
    {
      "verse": "8",
      "text": "God has given her linen clothes to wear that are bright and clean. ’These special linen clothes show the good things that God's holy people have done. These special linen clothes show the good things that God's holy people have done."
    },
    {
      "verse": "9",
      "text": "Then the angel said to me, ‘Write down this message: “There will be a special meal at the Lamb's wedding party. God has truly blessed those people that he has asked to come to that meal. ” ’ The angel also said to me, ‘This is a true message from God. ’"
    },
    {
      "verse": "10",
      "text": "Then I bent down low at the angel's feet to worship him. But he said to me, ‘You must not do that! I am only a servant of God, the same as you are. I am a servant, like all believers who show clearly that they trust in Jesus. God is the one that you should worship! When God gave a message to his prophets, it was Jesus that they spoke about. ’"
    },
    {
      "verse": "11",
      "text": "I saw that heaven was now open. I saw a white horse there! The name of the man who was riding the horse was this: ‘A faithful, honest person’. He is always right when he judges people and when he goes to punish them in war."
    },
    {
      "verse": "12",
      "text": "His eyes burn like bright flames of fire. Many crowns are on his head. He has a name that is written on him, but nobody knows that name except himself."
    },
    {
      "verse": "13",
      "text": "He wears a long shirt with a lot of blood on it. His name is: ‘The Word of God’."
    },
    {
      "verse": "14",
      "text": "Heaven's armies were following him. They were also riding on white horses. They were wearing linen clothes that were white and clean."
    },
    {
      "verse": "15",
      "text": "A sharp sword was coming out of his mouth. He will use this sword to attack the people of all the nations of the world. Then he will rule them with strong authority. He will punish them like someone who stamps on grapes in a winepress. That will show God's great anger against them. He is the Almighty God."
    },
    {
      "verse": "16",
      "text": "The man who rides on the white horse has a name that is written on his shirt. It is also written high on his leg. His name is: ‘The King who rules over all other kings. The Lord who rules over all lords’."
    },
    {
      "verse": "17",
      "text": "Then I saw an angel who was standing in the sun. He shouted loudly to all the birds that were flying high in the sky, ‘Come here! Come together to eat the big meal that God has prepared."
    },
    {
      "verse": "18",
      "text": "Eat the meat from the dead bodies of God's enemies! Come and eat the meat of kings, the meat of army captains and the meat of powerful men. Eat the meat of dead horses and the soldiers who ride them. Eat the meat of all kinds of people: slaves and free people, important people and ordinary people. ’"
    },
    {
      "verse": "19",
      "text": "Then I saw the wild animal and the kings of the earth and their armies. They had come together to fight a war. They were ready to fight a battle against the man who rode on the white horse and his army."
    },
    {
      "verse": "20",
      "text": "But the rider and his army caught the wild animal. They also caught the false prophet who had done miracles to help the wild animal. He used those miracles to deceive the people who had the wild animal's mark on them. Those people worshipped his image. Now the rider and his army threw the wild animal and the false prophet into the lake of fire. They were still alive when they threw them into the lake that burns with sulphur."
    },
    {
      "verse": "21",
      "text": "The rider of the white horse then killed all his other enemies. He killed them with the sword that came out of his mouth. So then all the birds ate the meat from the dead bodies until they were completely full."
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "Then I saw an angel who was coming down from heaven. He was holding the key to the deep hole. He also held a great chain in his hand."
    },
    {
      "verse": "2",
      "text": "He took hold of the dragon. That dragon is the Devil and Satan. He is the snake who has lived since long ago. The angel tied up the dragon with the chain for 1, 000 years."
    },
    {
      "verse": "3",
      "text": "Then he threw the dragon into the deep hole. He closed the door to the deep hole, and he locked it with the key. He put a seal on the door. During that time, Satan could no longer deceive the people of all nations. But after the 1, 000 years have finished, he must go free for a short time."
    },
    {
      "verse": "4",
      "text": "Then I saw some thrones, and I saw people who were sitting on them. These people had received authority to judge other people. I also saw the souls of people who had died because they served Jesus. People had cut off their heads because they had told the truth about Jesus, and they had spoken God's message. These believers had not worshipped the wild animal or his image. They had not received the wild animal's mark on their heads or on their hands. Now they became alive again. They ruled as kings together with Christ for 1, 000 years."
    },
    {
      "verse": "5",
      "text": "(But all the other dead people did not become alive again until the 1, 000 years had finished. ) This is the first time that God raises up dead people to become alive again."
    },
    {
      "verse": "6",
      "text": "God has blessed those people that he raises up that first time. They belong to God as his holy people. The second death has no power over them. Instead, they will be priests who serve God and Christ. They will rule as kings with him for 1, 000 years."
    },
    {
      "verse": "7",
      "text": "When the 1, 000 years have finished, God will let Satan go free out of his prison."
    },
    {
      "verse": "8",
      "text": "Satan will then go and deceive people in nations everywhere in the world. He will make them believe him. Those nations are God's enemies, Gog and Magog. Satan will bring them together to fight a war against God's people. Satan's army has many people, as much as the sand on the shore of the sea."
    },
    {
      "verse": "9",
      "text": "I saw them as they marched over the whole earth. They arrived at the city which God loves. That is where God's people had made their camp. Satan's army made their camp all around the city. Then fire came down from heaven and it destroyed them completely."
    },
    {
      "verse": "10",
      "text": "The Devil had deceived those people. I saw God throw him into the lake of fire that burns with sulphur. That is the lake where he had already thrown the wild animal and the false prophet. They will have a lot of pain in that place, all day and all night for ever."
    },
    {
      "verse": "11",
      "text": "Then I saw a great white throne. I saw that God was sitting on it. The earth and the sky rushed away from the place where he sat. There was no longer any place for them."
    },
    {
      "verse": "12",
      "text": "I also saw the people who had died, important people and ordinary people. They were standing in front of the great throne. Then someone opened books to see what was in them. God had written in them all the things that the people had done. Then someone opened another book which is God's book of life. God judged the people who had died. He looked in the books to see what they had done, and he decided what was right."
    },
    {
      "verse": "13",
      "text": "The sea brought up all the dead people who were in it. Death and Hades, the place for dead people, brought up all the dead people who were there too. God judged each person. God saw what they had done, and he decided what was right."
    },
    {
      "verse": "14",
      "text": "Then God threw Death and Hades into the lake of fire. The lake of fire is the second death for people."
    },
    {
      "verse": "15",
      "text": "If anyone's name was not written in the book of life, God threw that person into the lake of fire."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "Then I saw a new heaven and a new earth. The first heaven and the first earth had gone away. The sea also was not there any more."
    },
    {
      "verse": "2",
      "text": "I saw God's own holy city, called the new Jerusalem. It was coming down out of heaven from God. It was very beautiful, like a bride who is wearing beautiful clothes, ready to meet her husband."
    },
    {
      "verse": "3",
      "text": "I heard a voice that spoke loudly from the throne. It said, ‘Look! God's home is now among people! God will live together with them. They will be his people. God himself will be with them and he will be their God."
    },
    {
      "verse": "4",
      "text": "God will take away all the tears from their eyes. Nobody will ever die again. Nobody will be sad again. Nobody will ever cry. Nobody will have pain again. Everything that made people sad has now gone. That old world has completely gone away. ’"
    },
    {
      "verse": "5",
      "text": "God, who was sitting on the throne, said, ‘I am making everything new! ’ Then he said, ‘Write this down, because these words are true. Everyone should believe them. ’"
    },
    {
      "verse": "6",
      "text": "He also said to me, ‘Everything is now done! I caused all things to begin and I will cause the end of all things. I am the beginning and the end. If anyone is thirsty, I will give them water to drink. Nobody will have to pay anything for it. That water comes from a spring of water that gives life to people."
    },
    {
      "verse": "7",
      "text": "Everyone who wins against Satan will receive all these things from me. I will be their God and they will be my children."
    },
    {
      "verse": "8",
      "text": "But I will punish other people. They include: people who are afraid of trouble; people who do not believe in Jesus; people who do disgusting things; people who murder other people; people who have sex in a wrong way; people who use magic to hurt people; people who worship idols; people who tell lies. All these people will go into the lake of fire that burns with sulphur. That is the second death for people. ’ All these people will go into the lake of fire that burns with sulphur. That is the second death for people. ’"
    },
    {
      "verse": "9",
      "text": "Then one of the seven angels with the seven bowls that were full of the seven final troubles came to me. He said, ‘Come with me! I will show you the bride who will become the Lamb's wife. ’"
    },
    {
      "verse": "10",
      "text": "Then God's Spirit caused me to see and to hear strange things. The angel carried me away to a great mountain that was very high. He showed me God's own holy city, Jerusalem. The city was coming down out of heaven from God."
    },
    {
      "verse": "11",
      "text": "It had the bright glory of God. It shone like a valuable jewel that is called jasper. It shone like clean glass."
    },
    {
      "verse": "12",
      "text": "The city had a very big, high wall round it. The wall had 12 gates in it. 12 angels stood at the 12 gates. The names of the 12 tribes of Israel's people were written on the 12 gates."
    },
    {
      "verse": "13",
      "text": "There were three gates on each side of the city: three gates were on the east side, three gates were on the north side, three gates were on the south side, three gates were on the west side."
    },
    {
      "verse": "14",
      "text": "The city's wall has a foundation of 12 strong stones. The names of the Lamb's 12 apostles were written on those 12 stones."
    },
    {
      "verse": "15",
      "text": "The angel who talked to me had a long gold stick. He used it to measure things. So he could measure the city and its gates and its walls."
    },
    {
      "verse": "16",
      "text": "The shape of the city was a square. It was as long as it was wide. The angel measured the city with his stick. It was 12, 000 stadia (2, 400 kilometres) long. It was as wide and as high as it was long."
    },
    {
      "verse": "17",
      "text": "He also measured its wall. The size of the wall was 144 cubits (65 metres). That is the way that humans measure things. The angel also measured in the same way."
    },
    {
      "verse": "18",
      "text": "The wall was made from the jewel that is called jasper. The city was made from pure gold. The light shone through it, as light shines through clean glass."
    },
    {
      "verse": "19",
      "text": "The strong stones that were the foundation of the city's wall were very beautiful. They had valuable jewels in them that were different colours. Each great stone had its own special jewel. They were called:1. Jasper; 2. Sapphire; 3. Agate; 4. Emerald;"
    },
    {
      "verse": "20",
      "text": "5. Onyx; 6. Carnelian; 7. Quartz; 8. Beryl; 9. Topaz; 10. Chrysoprase; 11. Jacinth; 12. Amethyst."
    },
    {
      "verse": "21",
      "text": "gates were 12 pearls. They had used a single pearl to make each gate. The city's biggest street was made from pure gold. The light shone through it, as light shines through clean glass."
    },
    {
      "verse": "22",
      "text": "When I looked, I saw that there was no temple in the city. The Lord God, who has all power and authority, is there himself. The Lamb is also there. So people do not need a special place to worship him there."
    },
    {
      "verse": "23",
      "text": "Also, the city does not need the sun or the moon to shine on it. God's bright glory gives light to the city. The Lamb is the lamp that gives it light."
    },
    {
      "verse": "24",
      "text": "People from all the world's nations will live in the city's light. The earth's rulers will bring all their valuable things into it."
    },
    {
      "verse": "25",
      "text": "Nobody will ever shut the city's gates at the end of the day. It will always be day and there will be no night there."
    },
    {
      "verse": "26",
      "text": "People from all the world's nations will bring their beautiful and valuable things into the city."
    },
    {
      "verse": "27",
      "text": "But nothing that is bad or unclean will ever go in there. Nobody who does anything that God hates will go into the city. Nobody who tells lies will go in. Only those people with their names written in the Lamb's book of life can go in there."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "Then the angel showed me a river. It had water that gives true life to people. The water shone like clean glass. The river of water started from the throne where God and the Lamb sit to rule. It ran from the throne"
    },
    {
      "verse": "2",
      "text": "along the middle of the city's biggest street. I saw a tree that was growing on each side of the river. It is the tree that gives people true life. It has 12 different kinds of fruit, a new fruit every month. The tree's leaves are like medicine. They make people of every nation well again."
    },
    {
      "verse": "3",
      "text": "Nothing that is in the city will be under a curse. The throne where God and the Lamb sit to rule will be in the city. God's servants will worship him there."
    },
    {
      "verse": "4",
      "text": "They will see his face. His name will be on the front of their heads."
    },
    {
      "verse": "5",
      "text": "There will be no more night, so nobody will need a lamp to make light. They will not need light from the sun, because the Lord God will shine on them. They will rule as kings for ever."
    },
    {
      "verse": "6",
      "text": "Then the angel said to me, ‘All these words are true and everyone should believe them. The Lord God uses his prophets to speak his messages. He has sent his angel to speak to his servants. The angel will now show them what must happen soon. ’"
    },
    {
      "verse": "7",
      "text": "Jesus says, ‘Listen! I will come soon. God will bless everyone who obeys the words of the prophecy that is in this book. ’"
    },
    {
      "verse": "8",
      "text": "I am John. I myself heard these things and I saw them. When I had heard them and I had seen them, I bent down low at the angel's feet. I wanted to worship him because he had shown these things to me."
    },
    {
      "verse": "9",
      "text": "But the angel said to me, ‘You must not do that! I am only a servant of God, the same as you are. I serve God like all God's prophets, who are believers like you. I serve God like everyone who obeys God's message that is written in this book. God is the one that you must worship! ’"
    },
    {
      "verse": "10",
      "text": "Then he said to me, ‘Do not hide the words of God's prophecy that are written in this book. The time is near when these things will happen."
    },
    {
      "verse": "11",
      "text": "Let everybody continue to live as they choose. Everyone who does wrong things will continue to do wrong things. Everyone who is disgusting will continue to be disgusting. Everyone who does right things will continue to do right things. Everyone who belongs to God will continue to be holy. ’"
    },
    {
      "verse": "12",
      "text": "Jesus says, ‘Listen! I will come quickly! I know what each person has done. I will give each one what they ought to have. I am ready to do that."
    },
    {
      "verse": "13",
      "text": "I caused all things to begin and I will cause the end of all things. I am the first and the last. I am the beginning and the end."
    },
    {
      "verse": "14",
      "text": "Believers who keep themselves clean will be happy. They are like people who always wash their clothes. I will let them eat the fruit from the tree that causes people to have true life. I will let them go through the gates into the city."
    },
    {
      "verse": "15",
      "text": "But other people must stay outside the city: wicked people; people who do magic; people who have sex in a wrong way; people who murder other people; people who worship idols; everyone who likes to tell lies and deceive people."
    },
    {
      "verse": "16",
      "text": "I am Jesus. I have sent my angel to tell you this message. You must tell it to all the people in the churches. I am called the Root of King David. I am his descendant. I am the bright morning star. ’"
    },
    {
      "verse": "17",
      "text": "God's Spirit and all God's people answer Jesus. They say, ‘Yes, come! ’ God's people are like a bride for Jesus. Everyone who hears this should also say to Jesus, ‘Come! ’ Anyone who is thirsty should come to Jesus. Then that person will receive from Jesus the water that gives life. Anyone who wants it may take it. They will not have to pay anything for it."
    },
    {
      "verse": "18",
      "text": "Now John says this. I say clearly to everyone who hears the words of God's prophecy that are written in this book: If anyone adds any more words than are already in this book, God will punish them. The terrible troubles that this book describes will happen to them."
    },
    {
      "verse": "19",
      "text": "And if anyone takes away from the words that are in this book, God will punish them too. He will not let them eat the fruit from his tree that gives life. God will not let them live in his holy city either. This book describes all these things."
    },
    {
      "verse": "20",
      "text": "It is Jesus who tells us that all these messages are true. He says, ‘Yes, I will come soon! ’Amen! We agree! Come, Lord Jesus! Amen! We agree! Come, Lord Jesus!"
    },
    {
      "verse": "21",
      "text": "I pray that the Lord Jesus will continue to be kind to all of you. \u001a"
    }
  ]
};