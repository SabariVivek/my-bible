module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter comes from me, the leader of the believers. I am writing to you, my friend Gaius. I love you because we believe God's true message."
    },
    {
      "verse": "2",
      "text": "My friend, I pray that God will help you to live well. I know that you are well in your spirit. I pray that your body will also be well."
    },
    {
      "verse": "3",
      "text": "I was very happy when I heard news about you. Some Christian friends came here to tell me about you. They said that you are living in a good way. That is the way that God's true message tells us to live."
    },
    {
      "verse": "4",
      "text": "I am happy when I hear that my children are living like that. When they obey God's true message, it makes me very happy."
    },
    {
      "verse": "5",
      "text": "My friend, you do many things to help other believers. You help them even when they are strangers to you. This shows that you are serving God well."
    },
    {
      "verse": "6",
      "text": "These men have spoken to the group of believers here about your love. Please continue to help them when they visit you. Give them the things that they need to continue on their journey. That will make God happy."
    },
    {
      "verse": "7",
      "text": "They are travelling to different places to tell people about Jesus Christ. They do not accept any gifts from those people who are not Christians."
    },
    {
      "verse": "8",
      "text": "Because of that, we Christians must help them with the things that they need. In this way we will be working together with them as they tell people the true message about Christ."
    },
    {
      "verse": "9",
      "text": "I have already written something to the group of believers. But Diotrephes refuses to accept our authority. He really wants to be the only leader among them."
    },
    {
      "verse": "10",
      "text": "So, when I arrive there myself, I will speak to the believers about this. I will tell them clearly about the bad things that Diotrephes is doing. He tells other people bad things about us that are not true. Even that is not enough for him. He himself refuses to welcome the believers who are visiting. He also stops anyone else who wants to welcome those visitors. Instead, he sends them away from the group of believers."
    },
    {
      "verse": "11",
      "text": "My friend, do not copy what bad people do. Instead, you should copy the good things that people do. The person who does good things shows that he belongs to God. But anyone who does bad things does not know God."
    },
    {
      "verse": "12",
      "text": "All the believers say that Demetrius is a good person. He obeys God's true message. That also shows clearly that he is a good person. We also say the same thing about him. You know very well that what we say about him is true."
    },
    {
      "verse": "13",
      "text": "I would like to tell you many more things. But I do not want to write them in a letter."
    },
    {
      "verse": "14",
      "text": "Instead, I hope to come and visit you soon. Then I can see you and we can talk together. I pray that God will give you peace. All your Christian friends here say ‘hello’ to you. Say ‘hello’ for me to each of my friends there, one by one."
    }
  ]
};