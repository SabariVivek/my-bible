module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter is from me, Paul. I am a servant of Christ Jesus. God chose me to be his apostle. He sent me to tell his good news to people."
    },
    {
      "verse": "2",
      "text": "God promised this good news long ago, before it became true. His prophets wrote about it in the Bible."
    },
    {
      "verse": "5",
      "text": "Because of Jesus Christ, God has been very kind to us. He has chosen me to serve him as an apostle. He sent me to tell his message to people from all countries. As a result they would know that Jesus Christ is great. They would trust him and obey him."
    },
    {
      "verse": "6",
      "text": "You Christians in Rome are also among those people! God has chosen you to belong to Jesus Christ."
    },
    {
      "verse": "7",
      "text": "So I am writing to all you Christians who are in Rome. God loves you and he has chosen you to be his own people. I pray that God, our Father, and the Lord Jesus Christ will continue to help you. I pray that they will give you peace in your minds. I pray that God, our Father, and the Lord Jesus Christ will continue to help you. I pray that they will give you peace in your minds."
    },
    {
      "verse": "8",
      "text": "First, because of what Jesus Christ has done for us, I thank my God for all of you. Everywhere in the world, people are talking about how you trust in Jesus Christ."
    },
    {
      "verse": "9",
      "text": "God is the one that I serve with all my spirit. I tell people the message about his Son, which is good news. God himself knows that I pray for you all the time."
    },
    {
      "verse": "10",
      "text": "Every time that I pray for you, I ask God for a chance that I might visit you soon. I pray that he will make it possible if that is what he wants."
    },
    {
      "verse": "11",
      "text": "I want very much to come and see you. Then I can give some gift from God's Spirit to you. That will help you to be strong as you serve God."
    },
    {
      "verse": "12",
      "text": "We can help each other to be strong like that, because both you and I trust Christ."
    },
    {
      "verse": "13",
      "text": "My Christian friends, I want you to know that I have tried often to visit you. But until now, something has always stopped me. I want to help you to serve God well, in the way that I have already helped other Gentiles."
    },
    {
      "verse": "14",
      "text": "Because God has been kind to me, I must tell his message to all people. I must tell his good news to people who have learned many things, and to those who have never been to school. I must tell it to people who are wise as well as to those who are not very clever."
    },
    {
      "verse": "15",
      "text": "Because of that, I want very much to tell God's good news also to you people who live in Rome."
    },
    {
      "verse": "16",
      "text": "I am not ashamed to tell people the good news. God uses that good news to show his great power. He uses it to save all people who believe in Jesus Christ. First, God saves all Jews who are believers. And he also saves all Gentiles who are believers. ‘Everyone that God accepts as right will live, because they trust him. ’"
    },
    {
      "verse": "17",
      "text": "The good news explains how God accepts people as right with himself. He does this when they believe in Christ. It is only because of their faith. Nothing else. This is what was written in the Bible long ago:‘Everyone that God accepts as right will live, because they trust him. ’"
    },
    {
      "verse": "18",
      "text": "God in heaven shows that he is angry with people. He is angry because they do not respect him and they do bad things. Because they continue to do those bad things, they choose not to accept God's true message."
    },
    {
      "verse": "19",
      "text": "They should understand what God is like, because God himself has shown it to them clearly."
    },
    {
      "verse": "20",
      "text": "Ever since God made the world, he has been showing people clearly about himself. We cannot see God. But the things that he has made show us clearly what he is like. We can understand his great power that continues for ever. We can know that he is the true God. So there is no reason for anyone to say, ‘We could not know about God. ’"
    },
    {
      "verse": "21",
      "text": "Those people really knew about God. But they did not respect him as a great God, and they did not thank him. They did not even think clearly any more. Their minds became confused and they did not understand God's message."
    },
    {
      "verse": "22",
      "text": "They said that they were wise, but really they became fools."
    },
    {
      "verse": "23",
      "text": "They refused to worship the great God who can never die. Instead, they made false gods for themselves. They worshipped idols that were like people who must die. They also made idols that looked like birds, animals and snakes, and they worshipped them."
    },
    {
      "verse": "24",
      "text": "So God let those people do all the bad things that they wanted to do. God let those disgusting things rule their lives. As a result, they did bad things with each other's bodies. They did things that people should be ashamed to do."
    },
    {
      "verse": "25",
      "text": "They refused to believe the true things about God. Instead, they chose to believe lies. They worshipped things that God has made and they became servants of those things. But they refused to worship God himself who made those things! Everyone should praise him for ever! Amen. This is true."
    },
    {
      "verse": "26",
      "text": "Because those people turned against God, he let those bad things rule their lives. They strongly wanted to do things that they should be ashamed about. Even the women stopped having sex in a way which is proper. Instead, they began to have sex with other women, which is not proper."
    },
    {
      "verse": "27",
      "text": "Also, the men stopped having sex with women. Instead, they strongly wanted to have sex with other men. Men did bad things with other men that they should be ashamed about. Because they did such wrong things, they received in their own bodies the punishment that was right."
    },
    {
      "verse": "28",
      "text": "Those people decided that they did not need to know anything about God. So God let their minds become spoiled. As a result, they do bad things that people ought not to do."
    },
    {
      "verse": "29",
      "text": "They only think about wrong and bad things that they want to do. They want many things for themselves. They want to hurt other people. They are always jealous of other people. They kill people. They quarrel and fight with people. They are not honest or kind. They say silly things about other people."
    },
    {
      "verse": "30",
      "text": "They tell lies about people. They hate God. They insult other people. They are proud and they say how important they are. They think of many ways to do bad things. They do not obey their parents."
    },
    {
      "verse": "31",
      "text": "They do not understand what is right. They do not do what they have promised to do. They do not love anyone and they are not kind to anyone."
    },
    {
      "verse": "32",
      "text": "These people understand God's message about what is right. They know that people who do bad things like this ought to die. But they still continue to do those bad things. They are even happy when other people do those bad things too."
    },
    {
      "verse": "3",
      "text": "This good news is about God's Son, who is Jesus Christ, our Lord. Jesus was born as a human baby from King David's family."
    },
    {
      "verse": "4",
      "text": "But after Jesus died on the cross, God's Holy Spirit raised him to make him alive again. In that way God showed clearly that Jesus was his powerful Son."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "So I say this to each one of you: Do not judge other people. If you decide that someone else has done a bad thing, remember that you also do the same bad things. You are really saying that God should punish you also! When you judge someone, God will not punish them and then forgive you."
    },
    {
      "verse": "2",
      "text": "When God judges people, he does it in a way that is right and fair. He punishes people who do those kind of bad things."
    },
    {
      "verse": "3",
      "text": "I ask each of you again: ‘Do you speak against people who do bad things, but you do those same bad things yourself? ’ Then God will certainly punish you and you will not go free."
    },
    {
      "verse": "4",
      "text": "Remember that God is very kind and patient with us. He waits a long time before he punishes us. Do you not think that that is important? You should understand that God is giving you a chance to change. He waits patiently, so that you may turn away from wrong things."
    },
    {
      "verse": "5",
      "text": "But you refuse to change the way that you live. You are not sorry about the wrong things that you have done. As a result, you cause God to become even angrier with you. So he will punish you even more on the day when he will judge everyone. On that day, he will show how angry he is against people who do bad things. Everyone will know that he judges people in a right way."
    },
    {
      "verse": "6",
      "text": "He will give to each person what they ought to have because of the things that they have done."
    },
    {
      "verse": "7",
      "text": "Some people continue patiently to do good things. They want to do what is right so that God will praise them. They want to live the kind of life which death will not spoil. God will cause people like that to live with him always."
    },
    {
      "verse": "8",
      "text": "But other people think only about themselves. They refuse to obey God's true message. Instead, they continue to do things that are wrong. God will be very angry with people like that and he will punish them."
    },
    {
      "verse": "9",
      "text": "God will punish everyone who does bad things. He will do that first to the Jews, and he will do it also to the Gentiles. There will be much trouble and pain for every person who does bad things."
    },
    {
      "verse": "10",
      "text": "But God will praise every person who does good things. He will make them great and they will have peace in their minds. He will do that first for the Jews, and he will do it also for the Gentiles."
    },
    {
      "verse": "11",
      "text": "God is always fair when he judges people, whoever they are."
    },
    {
      "verse": "12",
      "text": "The Gentiles do not have God's Law that he gave to Moses. If Gentiles do wrong things, God will punish them. But he will not use his Law when he judges the Gentiles. But the Jews do have God's Law. So, if Jews do wrong things, God will use his Law to judge them. The Law will show that they have done wrong things."
    },
    {
      "verse": "13",
      "text": "Who does God accept as right with himself? It is those people who obey his Law. It is not the people who only know his Law but do not obey them."
    },
    {
      "verse": "14",
      "text": "The Gentiles do not have God's Law. But they may still do the right things that the Law teaches. They do right things because of what they themselves think is right. In that way they are showing that they have a certain law in their minds, even though they do not know God's Law."
    },
    {
      "verse": "15",
      "text": "Those people show that they know what is right. It is as if God has written his Law deep inside them. Their thoughts tell them the difference between what is right and what is wrong. Sometimes their thoughts say: ‘You did something that is wrong. ’ And sometimes their thoughts say: ‘You did what is right. ’"
    },
    {
      "verse": "16",
      "text": "That is the message that I tell people. God knows everything that people think secretly. One day he will judge everyone. He has given Jesus Christ the authority to do that."
    },
    {
      "verse": "17",
      "text": "Do you say that you are a Jew? Maybe you trust in the Law that God gave to Moses. You are proud that you belong to God."
    },
    {
      "verse": "18",
      "text": "You know what God wants people to do. His Law teaches you what is good and right."
    },
    {
      "verse": "19",
      "text": "You are sure that you yourself can teach other people about God. You think that you can be like a guide to blind people. You think that you can be like a light to people who are in the dark."
    },
    {
      "verse": "20",
      "text": "You are sure that you can teach fools and people who do not know very much. You know that God's Law tells you everything about what is true. Because it helps you to know so much, you think that you can be a great teacher!"
    },
    {
      "verse": "21",
      "text": "So you teach other people, do you? But do you teach yourself? You tell other people, ‘Do not rob anyone. ’ But maybe you yourself rob other people. ‘Because of you Jews, the Gentiles say bad things against God. ’"
    },
    {
      "verse": "22",
      "text": "You say, ‘People must not have sex with anyone who is not their wife or their husband. ’ But maybe you yourself have sex in a wrong way. You say that you hate idols. But do you rob places where people worship idols?"
    },
    {
      "verse": "23",
      "text": "You are proud that you know God's Law. But you do not obey that Law. As a result, you cause other people to speak against God."
    },
    {
      "verse": "24",
      "text": "This is written in the Bible:‘Because of you Jews, the Gentiles say bad things against God. ’"
    },
    {
      "verse": "25",
      "text": "As a Jewish man, you are proud that someone has circumcised you. That is a help to you, if you obey God's Law in your life. But if you do not obey God's Law, then it is worth nothing. You have become like a Gentile that nobody has ever circumcised."
    },
    {
      "verse": "26",
      "text": "But a Gentile may obey what God's Law teaches. Then he has shown that he belongs to God even though nobody has circumcised him."
    },
    {
      "verse": "27",
      "text": "In that way, even Gentiles will show that you who are Jews are wrong. God's Law was written to help you Jews. They circumcised you to show that you belong to God. But if you refuse to obey God's Law, then God will punish you. The Gentiles who do obey God's Law will show that God is right to punish you."
    },
    {
      "verse": "28",
      "text": "Not everyone who seems to be a Jew is really a Jew who belongs to God. God does not accept a man just because someone has circumcised that man's body."
    },
    {
      "verse": "29",
      "text": "No! A true Jew is someone who belongs to God in his spirit. He belongs to God because God's Spirit has changed his life. It is like God has circumcised him in his spirit, not in his body. The rules in God's Law cannot do that work in a person. Other people may not praise a person like that, but God will praise him."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "So someone may ask, ‘Does it help a person if they are a Jew, rather than a Gentile? Does it help a person if someone has circumcised them? ’ ‘Your message is true. It shows that you are right. People may say that you are wrong. But it will always be clear that you are right. ’"
    },
    {
      "verse": "2",
      "text": "Yes, it helps in many ways. The first is that God chose to give his messages to the Jewish people."
    },
    {
      "verse": "3",
      "text": "But you may say, ‘Some Jews did not believe God's messages as they should have done. Because of that, maybe God will not do what he said he would do. ’"
    },
    {
      "verse": "4",
      "text": "No, certainly it does not mean that! God will always do what he says. He will always say what is true, even if everyone in the world should tell lies. This is what is written in the Bible:‘Your message is true. It shows that you are right. People may say that you are wrong. But it will always be clear that you are right. ’"
    },
    {
      "verse": "5",
      "text": "Maybe some people may say, ‘The wrong things that we do show more clearly that God is always right. So perhaps God is wrong to punish us. ’"
    },
    {
      "verse": "6",
      "text": "That is not true! God always decides what is right and fair. That is why he is able to judge everyone in the world."
    },
    {
      "verse": "7",
      "text": "Someone might also say, ‘When I tell lies, that shows how great and good God is. My lies show more clearly that God always says what is true. So God should not say that I am a bad person. He should not punish me. ’"
    },
    {
      "verse": "8",
      "text": "But if that is true, you could also say, ‘We should do more and more bad things. Then something good will happen as a result. ’ Some people even say that is the message which I teach. But if they say that, they are insulting me. It is right that God should punish those people."
    },
    {
      "verse": "9",
      "text": "So then, what do we learn from that? We cannot say that we Jews are better than other people. No, certainly we cannot say that! I have said already that sin has power over everyone. That is true for both Jews and Gentiles. ‘There is nobody who is right with God. There is not even one person who is like that."
    },
    {
      "verse": "10",
      "text": "This is written in the Bible:‘There is nobody who is right with God. There is not even one person who is like that."
    },
    {
      "verse": "11",
      "text": "There is nobody who understands what is true. There is nobody who wants to worship God. There is nobody who wants to worship God."
    },
    {
      "verse": "12",
      "text": "Everyone has turned away from God. All people have become completely bad. Nobody does what is good or kind. There is not even one person who is like that. All people have become completely bad. Nobody does what is good or kind. There is not even one person who is like that."
    },
    {
      "verse": "13",
      "text": "Bad words come out of their mouth, like a very bad smell. They tell lies all the time, so that people do wrong things. The things that they say hurt people, like a snake's poison. They tell lies all the time, so that people do wrong things. The things that they say hurt people, like a snake's poison."
    },
    {
      "verse": "14",
      "text": "They are always saying bad things against people, because they want to cause trouble for them. because they want to cause trouble for them."
    },
    {
      "verse": "15",
      "text": "They hurry to kill people."
    },
    {
      "verse": "16",
      "text": "Everywhere they go, they destroy things. They only make people very sad. They only make people very sad."
    },
    {
      "verse": "17",
      "text": "They have never known how to live in peace."
    },
    {
      "verse": "18",
      "text": "They refuse to respect God in any way. ’"
    },
    {
      "verse": "19",
      "text": "So, we know that God's Law belongs to the Jews. God told them to obey everything that his Law teaches. As a result, nobody can say: ‘God should not punish me. ’ Everybody in the world must stand in front of God and he will judge them."
    },
    {
      "verse": "20",
      "text": "God's Law shows people clearly that they have done wrong things. Nobody can become right with God because they obey that Law."
    },
    {
      "verse": "21",
      "text": "But now we know how to become right with God. God has shown us the way that he will accept people as right with himself. This way is not part of the Law that he gave to Moses. But God's Law and the messages of his prophets have told us about it."
    },
    {
      "verse": "22",
      "text": "God accepts people as right with himself because Jesus Christ did what God wanted. God accepts every person who believes in Christ. It is the same way for everyone, whether they are Jews or Gentiles."
    },
    {
      "verse": "23",
      "text": "All people have done wrong things. Nobody can be good and great, as God wanted them to be."
    },
    {
      "verse": "24",
      "text": "But because God is very kind, he accepts us as right with himself. That is God's gift to us. Jesus Christ has paid for our sins so that we have become free."
    },
    {
      "verse": "25",
      "text": "God showed everyone that Jesus Christ died on the cross as a sacrifice for our sins. God forgives us if we trust in Jesus and the blood of his sacrifice. God did this to show clearly that he is always right and fair. In past times, God was patient. He did not punish people who did wrong things."
    },
    {
      "verse": "26",
      "text": "He did this to show us today that he is completely right and fair. He accepts people as right with himself if they believe in Jesus."
    },
    {
      "verse": "27",
      "text": "So then, nobody should be proud that they are good enough. Nobody becomes right with God because they have done good things. No! God accepts a person only if that person believes in Jesus Christ."
    },
    {
      "verse": "28",
      "text": "So this is what we are saying. A person becomes right with God if they trust in Christ. It is not because they do the good things which God's Law teaches."
    },
    {
      "verse": "29",
      "text": "God is not God only for Jewish people. He is also God for the Gentiles. Yes! He is the God for all people."
    },
    {
      "verse": "30",
      "text": "There is only one God. He will accept Jews as right with himself if they believe in Christ. He will also accept other people as right with himself if they believe in Christ."
    },
    {
      "verse": "31",
      "text": "What does this show us about God's Law which he gave to Moses? When we say that all people need to believe in Jesus, does that mean that God's Law has no purpose? No! When we believe in Jesus, we are showing the true purpose of God's Law."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Abraham was the ancestor of all of us who are Jews. Think about what he discovered."
    },
    {
      "verse": "2",
      "text": "God did not accept Abraham as right with him because Abraham had done good things. If God had done that, then Abraham would have been able to boast about himself. But he could not boast to God."
    },
    {
      "verse": "3",
      "text": "Remember what the Bible tells us. It says: ‘Abraham believed God. As a result, God accepted Abraham as right with him. ’"
    },
    {
      "verse": "4",
      "text": "When a person works to get money, it is right for him to receive his money. That money is not a gift. It is what that person ought to receive as a result of his work. ‘The people that God has forgiven are really happy. They have done wrong things, but he has forgiven them."
    },
    {
      "verse": "5",
      "text": "But someone may believe in God. He does not work to cause God to accept him. God accepts that person because of their faith. God says that people who have turned away from him are right with him, if they trust him. That is God's gift to them."
    },
    {
      "verse": "6",
      "text": "David also wrote about the same thing. He describes those people that God has accepted as right with himself. God has not accepted them because they have done good things, but as his gift to them. David tells us how happy people like that are."
    },
    {
      "verse": "7",
      "text": "David says:‘The people that God has forgiven are really happy. They have done wrong things, but he has forgiven them."
    },
    {
      "verse": "8",
      "text": "A person is really happy when the Lord accepts him. The Lord does not think about that person's sin any more. ’ The Lord does not think about that person's sin any more. ’"
    },
    {
      "verse": "9",
      "text": "God does this for all people, both Jews and Gentiles. All people can be really happy like this, when God accepts them. As we have said, Abraham believed God. As a result, God accepted Abraham as right with him."
    },
    {
      "verse": "10",
      "text": "They circumcised Abraham to show that he was a Jew. Think about the time when God accepted Abraham. Did it happen before they circumcised him, or after that? We know that it was before they circumcised him!"
    },
    {
      "verse": "11",
      "text": "Some time after that, God told Abraham that someone should circumcise him. That would be a mark on his body to show that God had accepted him. God had already accepted Abraham because Abraham believed in him. God did not accept Abraham because they had circumcised him as a Jewish man. This shows that Abraham is like a father to everyone that God has accepted. Like Abraham, God has accepted them because they have believed in him. It is not important that nobody has circumcised them."
    },
    {
      "verse": "12",
      "text": "But Abraham is also like the father of all Jews who believe in God. Someone has circumcised those Jews, but they have copied Abraham's example. They have believed in God, as Abraham believed before anyone had circumcised him."
    },
    {
      "verse": "13",
      "text": "God promised to Abraham, and to his descendants, that the world would belong to them one day. God did not promise that because Abraham obeyed any rules. God promised it because Abraham believed in him. That is why God accepted Abraham as right with him."
    },
    {
      "verse": "14",
      "text": "People cannot get what God promised because they obey rules. If they could get it like that, then faith in God would be worth nothing. And what God promised would be worth nothing."
    },
    {
      "verse": "15",
      "text": "The rules in Moses' Law say that God will punish people who do not obey those rules. But without any rules, there is nothing for people to obey."
    },
    {
      "verse": "16",
      "text": "So God gives us his promise as a gift, because he is very kind. We receive it when we trust him. If we believe in God like Abraham did, then God accepts us. That is God's promise to all of Abraham's family. If we believe in God, we can call Abraham our ancestor. We can all receive what God has promised. It is not only for those who have Moses' Law to obey."
    },
    {
      "verse": "17",
      "text": "In the Bible, God said to Abraham, ‘I have chosen you to become the ancestor of many different people. ’ That is what God himself promises, because Abraham believed in him. God is the one who causes dead people to become alive again. He speaks about things that are not yet there as if they were already there."
    },
    {
      "verse": "18",
      "text": "Abraham continued to trust God. He hoped to receive what God had promised. He continued to hope even when he had no good reason to hope. That is why he became the ancestor of many different people. It happened just like God had said: ‘You will have very many descendants. ’"
    },
    {
      "verse": "19",
      "text": "years old. His body was already so old that it was nearly dead. His wife, Sarah, was unable to have children. Abraham understood all that, but he did not stop trusting God."
    },
    {
      "verse": "20",
      "text": "He never stopped believing what God had promised. Instead, he believed in God more strongly. He trusted God's great power."
    },
    {
      "verse": "21",
      "text": "Abraham was sure that God was able to do what he had promised to do."
    },
    {
      "verse": "22",
      "text": "So we see that it is true: Because Abraham believed God, God accepted Abraham as right with him."
    },
    {
      "verse": "23",
      "text": "Think about those words, ‘God accepted him as right. ’ They are not only speaking about Abraham."
    },
    {
      "verse": "24",
      "text": "They are written in the Bible to help us too. If we believe in God, he will accept us as right with him. God raised our Lord Jesus, so that he became alive again after his death."
    },
    {
      "verse": "25",
      "text": "God let people kill Jesus on the cross because of the wrong things that we have done. Then God raised Jesus from death, to show that he would accept us as right with him."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "So we see that God has accepted us as right because we believe in him. As a result, we are friends with God, because of what our Lord Jesus Christ has done for us."
    },
    {
      "verse": "2",
      "text": "Also, because we trust Jesus Christ, he has caused us to know that God is very kind. That makes us strong in our lives here. We also are sure that we will live with God in heaven. So we are very happy."
    },
    {
      "verse": "3",
      "text": "We are happy even when we have troubles and pain. That is because we know that those troubles help us to become patient and strong."
    },
    {
      "verse": "4",
      "text": "And when we remain strong, we show that we trust God. When we trust God like that, it causes us to hope for God's help."
    },
    {
      "verse": "5",
      "text": "And when we hope like that, it will not disappoint us. That is because we know that God loves us very much. God has given his Holy Spirit to be with us. The Holy Spirit causes us to know God's love very well."
    },
    {
      "verse": "6",
      "text": "At one time we were weak and we could not help ourselves. Then, at the right time, Christ died to save us. He died on behalf of people who have turned away from God."
    },
    {
      "verse": "7",
      "text": "Nobody will agree to die on behalf of another person, even if that person has done what is right. Maybe someone might be brave enough to die on behalf of a person who is very good."
    },
    {
      "verse": "8",
      "text": "But God has shown us how much he loves us. Even when we still did not obey God, Christ died on our behalf."
    },
    {
      "verse": "9",
      "text": "Because Christ died on the cross, God has accepted us as right with himself. So we certainly know that Christ will save us when God judges everyone. Because of Jesus, God will not be angry with us and punish us."
    },
    {
      "verse": "10",
      "text": "While we were still God's enemies, God's Son died on our behalf. As a result, we became God's friends. So, now that we are God's friends, his Son will certainly save us. Christ will save us because he is alive again."
    },
    {
      "verse": "11",
      "text": "But that is not everything! We are very happy now because of what God has done for us. Our Lord Jesus Christ has made this possible. It is because of him that we have now become God's friends."
    },
    {
      "verse": "12",
      "text": "It was because of one man, Adam, that sin came into the world. Death was the result of Adam's sin. Because of that, death came to all people, because everyone failed to obey God."
    },
    {
      "verse": "13",
      "text": "Before God gave his Law to Moses, people did wrong things. Sin was already there in the world. But at that time, God did not say that people were guilty, because there was no law for them to obey."
    },
    {
      "verse": "14",
      "text": "But still death ruled all people, from the time when Adam lived until the time when Moses lived. Everyone died, even those who did not fail in the same way that Adam failed. Adam shows us something about God's special Messiah who would come at a future time."
    },
    {
      "verse": "15",
      "text": "But they are not the same. Adam was the man who did not obey what God said to him. Jesus Christ is the man who brought God's free gift to people. Adam was just one person but many people died because of his sin. But God has shown in a greater way that he is very kind to people. Very many people have received God's gift because of one man, Jesus Christ. Christ has been very kind to many people!"
    },
    {
      "verse": "16",
      "text": "Also, God's gift is different from the result of Adam's sin. Adam chose not to obey God once and punishment came as a result. But the result of God's gift is greater. People have done many wrong things, not only one wrong thing. But God accepts them as right with him."
    },
    {
      "verse": "17",
      "text": "One man, Adam, did not obey God, and death began to rule everyone as a result. But what the one man, Jesus Christ, did is much greater! Because of him, people can become right with God. They receive that great gift from God because he is very good and very kind. Because of what Jesus Christ has done, those people will rule like kings in their lives."
    },
    {
      "verse": "18",
      "text": "So God's punishment came to all people because of that one wrong thing that Adam did. But the one thing that Christ did makes people free. God accepts all people because of that one good thing that Christ did. Those people receive true life from God."
    },
    {
      "verse": "19",
      "text": "One man did not obey God and, as a result, many people became guilty because of their sins. But, because one man did obey God, many people will become right with God."
    },
    {
      "verse": "20",
      "text": "God gave his Law to Moses to show more clearly that people were doing wrong things. But when people did more and more wrong things, God continued to be kind in more and more ways."
    },
    {
      "verse": "21",
      "text": "We see that sin ruled people's lives and brought death to them. But God's gift makes people right with him, and that is what rules their lives. People receive that gift because God is kind. As a result, they will have life with God for ever, because of what our Lord Jesus Christ has done."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "Someone might say, ‘Perhaps we should continue to do wrong things. Then God can be kind to us in more and more ways. ’"
    },
    {
      "verse": "2",
      "text": "No! Certainly we should not do that! Sin does not rule our lives any longer. That old life is dead! So it is not right that we should continue to do wrong things."
    },
    {
      "verse": "3",
      "text": "Remember what your baptism shows: When they baptized you, it shows that you are united with Christ Jesus. It also shows that, because Christ died, your old life also died."
    },
    {
      "verse": "4",
      "text": "Your baptism shows that they buried you, just like they buried Christ after his death. It is like you died with him and they buried you with him. Because of that, God will also raise us, just as he raised Christ from death. God, the Father, is so great and powerful that he raised Christ to a new life. That means that we also can live our lives in a new way."
    },
    {
      "verse": "5",
      "text": "We have become united with Christ, and we have died like he died. Because of that, we will also be united with him in his new life. Just like Christ rose, we also will rise to a new life."
    },
    {
      "verse": "6",
      "text": "We know that God has caused our old nature to die with Christ on the cross. This happened so that God could make us free from the power of sin in our lives. We are no longer like slaves who have sin as their master."
    },
    {
      "verse": "7",
      "text": "Sin no longer has any authority over someone who has died."
    },
    {
      "verse": "8",
      "text": "So, if we have died with Christ, we believe that we will also live with him."
    },
    {
      "verse": "9",
      "text": "God raised Christ, so that he became alive again after his death. Because of that, we know that he will never die again. Death has no authority over him any more."
    },
    {
      "verse": "10",
      "text": "When Christ died, he died once to destroy the power of sin for ever. Now that he is alive again, he lives to serve God."
    },
    {
      "verse": "11",
      "text": "So you also should think about yourselves in the same way. Sin has no power over you, as if you were dead. In your new life, you live to serve God, because you belong to Christ Jesus."
    },
    {
      "verse": "12",
      "text": "So do not let sin rule your life in this world. Do not do the wrong things that your body wants to do."
    },
    {
      "verse": "13",
      "text": "Sin can use your body to do things that are wrong. So do not let any parts of your body serve sin as their master. Instead, be ready to serve God as your Master. You can do that because you now have a new life. Your old life is dead. So give every part of your body to God. Then he will use you to do right things."
    },
    {
      "verse": "14",
      "text": "Sin will no longer have authority over you. You do not have a new life because you obey the Law which God gave to Moses. You have a new life because God is very kind to you."
    },
    {
      "verse": "15",
      "text": "Someone might say: ‘So we have a new life because God is kind to us. God's Law that he gave to Moses does not rule us any more. Then maybe we should continue to do wrong things. It will not make any difference. ’ No, that is not true!"
    },
    {
      "verse": "16",
      "text": "Remember this: When you agree to serve someone as a slave, you have to obey that person as your master. You may choose to serve sin as your master. If you do that, you will die. Or you may choose to obey God. If you do that, you will live in a way that is right."
    },
    {
      "verse": "17",
      "text": "At one time, you were slaves to sin. But then you received God's true message, and you were happy to obey it. I thank God because of that!"
    },
    {
      "verse": "18",
      "text": "As a result, God has made you free from the power of sin. You are now like slaves who serve everything that is right and good."
    },
    {
      "verse": "19",
      "text": "It is difficult for you to understand these things, because you are still weak. So I am using a human picture of slaves to help you to understand better. At one time, you agreed to serve bad things as your master. You let your body do wrong and disgusting things. You continued to do more and more bad things. So now, you must use your body to serve what is right and good. Then you will do more and more good things which show that you belong to God."
    },
    {
      "verse": "20",
      "text": "When you were slaves to sin, you did not even have to think about what was right and good."
    },
    {
      "verse": "21",
      "text": "You did things that you are ashamed about now. Nothing good came from them. In the end, the result of those things is death."
    },
    {
      "verse": "22",
      "text": "But now God has made you free from the power of sin. You have become God's slaves. Many good things come from that, because God is helping you to live in a good way. In the end, the result will be that you will live with him for ever."
    },
    {
      "verse": "23",
      "text": "If you serve sin as your master, it will pay you with death. But if you belong to our Lord Jesus Christ, God gives you a gift! That gift is life with God for ever."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "My Christian friends, you know about laws. You know that we have to obey them. The laws have authority over someone while they are still alive."
    },
    {
      "verse": "2",
      "text": "So think about this. A woman who has a husband must stay with him as long as he still lives. That is what the law says. But if her husband dies, she becomes free from that law about her marriage."
    },
    {
      "verse": "3",
      "text": "While her husband is alive, the law has authority over her. If she goes to live with another man, the law says that she has done something wrong. People will call her an adulteress. But if her husband dies, she becomes free from that law. If she then marries another man, she will not be doing anything wrong."
    },
    {
      "verse": "4",
      "text": "My friends, it is like that for you too. When Christ's body died on the cross, it is as if you also died with him. Because of that, you are no longer under the authority the law. Now you are free to belong to someone else. You belong to Christ, whom God raised up after his death. As a result, we can live in a good way that will please God."
    },
    {
      "verse": "5",
      "text": "In our old lives, we did the bad things that we wanted to do. God's laws brought bad thoughts into our minds. As a result, our bodies did many wrong things. In the end, those bad things lead to death."
    },
    {
      "verse": "6",
      "text": "But now we have become free from the authority of the law. It is as if we have died. So those rules no longer control us. We do not still try to obey rules that someone has written down. That is the old way. Instead, we serve God in a new way. God's Spirit helps us to please him."
    },
    {
      "verse": "7",
      "text": "So someone might say, ‘God's Law must be bad. ’ No! Certainly, it is not bad! Without that law, I would not have known what sin really is. One rule says, ‘You must not want to take things for yourself that belong to other people. ’ Without that command, I would not have known that it is wrong to want other people's things."
    },
    {
      "verse": "8",
      "text": "But the command gave sin a chance to come into my thoughts. As a result, I started to want all kinds of wrong things. If there is no law to tell us what is wrong, then sin has no power to make us guilty."
    },
    {
      "verse": "9",
      "text": "As for me, there was a time when I did not know God's laws. I was living without any law to obey. But when I learned about that command, sin now had power in my life."
    },
    {
      "verse": "10",
      "text": "As a result, I became separate from God, as if I had died. So the command that should have brought life to me brought death instead."
    },
    {
      "verse": "11",
      "text": "That command gave sin a chance to deceive me. It caused me to become separate from God."
    },
    {
      "verse": "12",
      "text": "So we understand that God's Law and its commands are completely good. They are holy, fair and good."
    },
    {
      "verse": "13",
      "text": "But someone might say, ‘This means that something good brought death to you. ’ No! God's Law did not do that! It was sin that brought death to me. Sin used God's good Law to show that I was guilty. Because of that, we can see that sin is really very bad. The commands in God's Law help to show that sin is completely bad."
    },
    {
      "verse": "14",
      "text": "We understand that God's Law is spiritual. But I am weak and human. I am like a slave that has sin as my master."
    },
    {
      "verse": "15",
      "text": "I do not understand the things that I do. I do not do the good things that I want to do. Instead, I do the things that I hate to do."
    },
    {
      "verse": "16",
      "text": "But I do not want to do those wrong things. So I am agreeing that God's Law is good."
    },
    {
      "verse": "17",
      "text": "So it is not really I myself who am doing those wrong things. Instead, sin has power in my life. It is sin that causes me to do wrong things."
    },
    {
      "verse": "18",
      "text": "I know that there is nothing good in me. I am weak and human. I want to do what is good. But I am unable to do it."
    },
    {
      "verse": "19",
      "text": "I do not do the good things that I want to do. Instead, I continue to do the bad things that I do not want to do."
    },
    {
      "verse": "20",
      "text": "So, when I do bad things that I do not want to do, it is not really I myself who do them. It is sin that causes me to do wrong things, because it has power in my life."
    },
    {
      "verse": "21",
      "text": "So I understand what is happening in me. Whenever I want to do something good, I can only choose something bad. So with my mind I want to obey God's laws. But, at the same time, I serve sin as my master, because I am weak and human."
    },
    {
      "verse": "22",
      "text": "Deep inside myself, I really love God's laws."
    },
    {
      "verse": "23",
      "text": "So my mind tells me to obey God's laws. But my body wants to make me do something else. Every part of me fights against what my mind tells me to do. Sin has power over my body so that I am like a prisoner."
    },
    {
      "verse": "24",
      "text": "This makes me very sad! My body is leading me to death. I need someone to make me free from the power of sin over my body."
    },
    {
      "verse": "25",
      "text": "I thank God! He has made me free, because of what Jesus Christ has done. So with my mind I want to obey God's laws. But, at the same time, I serve sin as my master, because I am weak and human."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Now we know this: God has forgiven those people who are united with Christ Jesus. God will never say that they are guilty."
    },
    {
      "verse": "2",
      "text": "If you belong to Christ Jesus, God's Spirit has given you a new life. God's Spirit now rules in your life and he has made you free. Sin and death no longer have authority over you."
    },
    {
      "verse": "3",
      "text": "The Law that God gave to Moses could not make us free like that. We were too weak to obey his Law because we are human. But God has done what his Law could not do. He sent his own Son to become a person like us. His human body was like the body of people who do wrong things. God's Son died as a sacrifice to take away the punishment for our sins. In that way, God destroyed the power of sin over people who are weak and human."
    },
    {
      "verse": "4",
      "text": "God did this so that we could become right with him. God's Law showed us how to be right with him. And now we can be right with God, if we live with God's Spirit as our guide. We do not do what our weak human thoughts want us to do."
    },
    {
      "verse": "5",
      "text": "Some people do what their weak human thoughts want them to do. They think about the things that will make themselves happy. But people who live with God's Spirit as their guide think about what will make God's Spirit happy."
    },
    {
      "verse": "6",
      "text": "People who let their human thoughts rule them will die. But people who think about what God's Spirit wants will have life with God. They will have peace inside themselves."
    },
    {
      "verse": "7",
      "text": "If our weak human thoughts rule us, we become God's enemies. People like that do not want to obey God's Law. They are not even able to obey it."
    },
    {
      "verse": "8",
      "text": "People who let their human thoughts rule them cannot make God happy."
    },
    {
      "verse": "9",
      "text": "But you are not like that. You no longer obey your weak human thoughts. Instead, you obey God's Spirit as your guide. That is true if God's Spirit is really living in you. But if anyone does not have Christ's Spirit in them, that person does not belong to Christ."
    },
    {
      "verse": "10",
      "text": "But, if Christ lives in you, you have a new life because of his Spirit. Your body will die one day because of the power of sin. But your spirit lives because Christ has made you right with God."
    },
    {
      "verse": "11",
      "text": "God raised Jesus, to make him alive again after his death. Now God's Spirit lives in you. So God, who raised Christ from death, will also cause your human bodies to live again. He will do that by his Spirit who lives in you."
    },
    {
      "verse": "12",
      "text": "So, my Christian friends, we must not obey what our weak human thoughts tell us to do. We no longer have to live like that."
    },
    {
      "verse": "13",
      "text": "If you agree to live in that way, you will die. Instead, you should let God's Spirit help you with his power. Then you can stop doing the wrong things that your bodies want to do. As a result, you will have life with God."
    },
    {
      "verse": "14",
      "text": "All those people who live with God's Spirit as their guide are God's children."
    },
    {
      "verse": "15",
      "text": "The Spirit that you have received from God does not make you serve him like slaves. That would make you afraid again. No. The Spirit that God has given to you causes you to become God's children. Now he takes care of you. God's Spirit makes us call God: ‘Abba, our Father. ’"
    },
    {
      "verse": "16",
      "text": "God's Spirit himself causes us to know that we are God's children. God's Spirit and our own spirits agree that this is true."
    },
    {
      "verse": "17",
      "text": "Because we are God's children, we also know that we will receive good things from him. Those are the things that he has promised to give to his children. Together with Christ, we will receive the things that God has kept for him. That is true if we agree to have troubles like Christ did. Then we will also enjoy life in heaven like Christ does."
    },
    {
      "verse": "18",
      "text": "During this time now, we have troubles and pain. But I am sure that these troubles are not really very great. One day God will show us all the great things he has prepared for us. That will make the troubles that we have now seem very small."
    },
    {
      "verse": "19",
      "text": "The whole universe that God has made now waits for something great to happen. Everything is waiting with hope to find out who God's children really are."
    },
    {
      "verse": "20",
      "text": "God has caused everything in the universe to lose its purpose. It did not choose to be like that. It was God who decided that it should be like that. Then it could hope for something better in a future time."
    },
    {
      "verse": "21",
      "text": "At that time, the universe will not continue to become worse and worse, as it does now. It will become free from that power. It will be free to enjoy great things from God, as God's children are also free."
    },
    {
      "verse": "22",
      "text": "We know that everything in the universe is still in great pain now. Everything cries together in pain, like a woman who is ready to have a baby."
    },
    {
      "verse": "23",
      "text": "It is the same for us who are believers. We have received God's Spirit as the first of his gifts to us, but we also cry inside ourselves. We are waiting for the time when God will finish his great work. Then we will belong to him completely as his children. Our bodies will be free from the power of sin."
    },
    {
      "verse": "24",
      "text": "Ever since God saved us, we have continued to wait for this to happen. One day, we will receive what we have hoped for. Then we will not need to hope for it any more. Nobody continues to hope for something that he has already."
    },
    {
      "verse": "25",
      "text": "But we continue to hope for what we do not yet see. And so, we wait for it patiently."
    },
    {
      "verse": "26",
      "text": "God's Spirit also helps us to do this. Because we are weak, we do not know how we ought to pray. But God's Spirit himself prays for us. He cries to God on our behalf in a way that nobody could say with words."
    },
    {
      "verse": "27",
      "text": "God sees deep inside us, and he knows our thoughts. He understands what is in the mind of his Spirit. When the Holy Spirit prays on behalf of God's people, he prays as God wants him to pray."
    },
    {
      "verse": "28",
      "text": "We know that God works to help those people who love him. He uses everything that happens to them to bring something good. He does this for those people that he has chosen to serve him."
    },
    {
      "verse": "29",
      "text": "God already had those people in his thoughts from the beginning. He decided that they should become like his Son. So then, his Son would have many younger brothers and sisters."
    },
    {
      "verse": "30",
      "text": "God had already chosen those people to be his children. Because of that, he called them to come to him. He accepted those people as right with himself. And those that he accepted, he also caused them to become great."
    },
    {
      "verse": "31",
      "text": "So, because of all the things that God does for us, we can say this: If God is working on our behalf, nobody can really do anything against us."
    },
    {
      "verse": "32",
      "text": "God did not even keep his own Son safe. Instead, he gave his Son to die on behalf of all of us. So certainly, God will continue to be kind to us. As well as his Son, he will give to us all things that we need."
    },
    {
      "verse": "33",
      "text": "Nobody can say that God's people are guilty. God himself has accepted us as right with him."
    },
    {
      "verse": "34",
      "text": "So nobody can say that God should still punish us. Nobody can say that, because Christ Jesus himself died on our behalf. And God raised him so that he became alive again after his death. Now Christ is sitting at God's right side in heaven. He himself is praying to God on our behalf."
    },
    {
      "verse": "35",
      "text": "Christ will always continue to love us. Nothing can stop that! We may have troubles. Things may make us sad or afraid. People may do bad things to us. We may have no food or no clothes. There may be great danger. People may even try to kill us. But none of these things can stop Christ from loving us. ‘Because we are your people, God, people try to kill us all the time. They think that we are like sheep, and we are ready to be killed. ’"
    },
    {
      "verse": "36",
      "text": "As it says in the Bible:‘Because we are your people, God, people try to kill us all the time. They think that we are like sheep, and we are ready to be killed. ’"
    },
    {
      "verse": "37",
      "text": "Because God loves us, none of these troubles can ever beat us. He makes us win against them."
    },
    {
      "verse": "38",
      "text": "I am sure of this. Nothing can stop God from loving us. Death cannot do that. Life cannot do that. Angels cannot do that, nor can demons do that."
    },
    {
      "verse": "39",
      "text": "Nothing that happens to us now, or that will happen in a future time can do that. No powerful spirits can do that. Nothing that is high above the world can do that, nor anything that is deep down below the ground. Nothing else in the whole universe can stop God from loving us. Because of our Lord Christ Jesus, we know how much God loves us."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "What I am telling you is true. I speak as someone who belongs to Christ. I am not telling lies. God's Holy Spirit rules my thoughts and I am sure that I am right."
    },
    {
      "verse": "2",
      "text": "I tell you this: Deep inside myself, I am always very sad and upset because of Israel's people."
    },
    {
      "verse": "3",
      "text": "I belong to the same family as they do. They are my own people. I really want them to believe in Christ too. If it would help them, I would even ask God to curse me. I would ask him to make me separate from Christ."
    },
    {
      "verse": "4",
      "text": "They are Israelite people. God chose them to belong to him as his own children. He showed them that he is very great. He made many agreements with them and he gave his Law to them. He showed them how they should worship him. He promised many good things to them."
    },
    {
      "verse": "5",
      "text": "It was their ancestors that God chose to make great many years ago. And Christ himself, as a man, was born to an Israelite family. Christ is God, who rules over all things. We should praise him for ever! This is true! Amen."
    },
    {
      "verse": "6",
      "text": "God promised good things to Israel's people. But I am not saying that what God promised did not happen. It is clear that not all of Israel's people are God's true people."
    },
    {
      "verse": "7",
      "text": "Not all of them are true descendants of Abraham. God told Abraham, ‘It is only Isaac that I will call the father of your descendants. ’"
    },
    {
      "verse": "8",
      "text": "This means that not all of Abraham's children are really God's children. It is only those children who were born as a result of God's promise. Only they are the people that God calls true descendants."
    },
    {
      "verse": "9",
      "text": "This is what God promised to Abraham: ‘At this time next year I will come back. Then Sarah, your wife, will have a son. ’"
    },
    {
      "verse": "10",
      "text": "Remember this too: Later, Isaac's wife, Rebekah, gave birth to twins. Those two sons had the same father, who was our ancestor, Isaac."
    },
    {
      "verse": "11",
      "text": "And God spoke to Rebekah before her sons were born. God spoke before the boys had done anything either good or bad. God did this to show clearly that he himself was choosing one child. He was not choosing someone because of what that person had done. He himself decided who he would choose."
    },
    {
      "verse": "12",
      "text": "God said to Rebekah, ‘The older son will serve the younger son. ’"
    },
    {
      "verse": "13",
      "text": "This is written in the Bible: ‘I loved Jacob, but I hated Esau. ’"
    },
    {
      "verse": "14",
      "text": "Because of this, someone might say that God is not fair. No! We should never say that!"
    },
    {
      "verse": "15",
      "text": "Think about this. God said to Moses, ‘I will be kind to whoever I choose to be kind to. I will feel sorry for whoever I choose to feel sorry for. ’"
    },
    {
      "verse": "16",
      "text": "So then, it is God who decides these things. It is not because of what people want. It is not because of what people do. It is because God chooses to be kind."
    },
    {
      "verse": "17",
      "text": "The Bible tells us what God said to Pharaoh: ‘This is why I caused you to be king of Egypt. My purpose was to show how powerful I am. As a result, people everywhere would know that I am great. ’"
    },
    {
      "verse": "18",
      "text": "So we see this: God is kind to some people and he forgives them. But he causes some people, like Pharaoh, to turn against him. He chooses what he will do with each person."
    },
    {
      "verse": "19",
      "text": "One of you may say to me, ‘God always does what he wants to do. Nobody can change what God makes them do. So God should not say that people have done wrong things. ’"
    },
    {
      "verse": "20",
      "text": "But you are only human. You have no authority to speak against God like that. God has made you. A pot cannot speak against the person who made it! It cannot ask him, ‘Why did you make me like this? ’"
    },
    {
      "verse": "21",
      "text": "Somebody who makes pots can choose to make any kind of pot. He can use the same piece of clay to make two different pots. One of the pots may be for special parties. The other pot is for dirty things."
    },
    {
      "verse": "22",
      "text": "What does that teach us about God? Some people are like pots that are ready for God to destroy. God is angry with people like that. He is ready to show his power against them. But he has chosen to wait patiently. He keeps his anger for later. ‘I will say to people who were not my people, “Now you are my people. ” I will say to people that I did not love, “I love you. ” ’"
    },
    {
      "verse": "23",
      "text": "Other people are like valuable pots that God has chosen to make. God wants to be kind to people like that. He wants to use them to show people how great he is. He has prepared them to be with him for a special party in heaven."
    },
    {
      "verse": "24",
      "text": "We are those people! God has chosen us to be his people. It is not only Jews that he has chosen. He has also chosen Gentiles."
    },
    {
      "verse": "25",
      "text": "God says this in the book of Hosea:‘I will say to people who were not my people, “Now you are my people. ”I will say to people that I did not love, “I love you. ” ’"
    },
    {
      "verse": "26",
      "text": "‘God had said to them, “You are not my people. ”In the same place where he said that, people will now call them “Children of God, who lives for ever. ” ’ “You are not my people. ” In the same place where he said that, people will now call them “Children of God, who lives for ever. ” ’"
    },
    {
      "verse": "27",
      "text": "Also, Isaiah, God's prophet, said this about Israel's people:‘There are so many of Israel's people, nobody can count them. They are as many as the bits of sand on the shore of the sea. But God will save only a few of them. ‘There are so many of Israel's people, nobody can count them. They are as many as the bits of sand on the shore of the sea. But God will save only a few of them."
    },
    {
      "verse": "28",
      "text": "The Lord God will finish his work quickly. He has warned his people what he will do. And he will punish them completely. ’ He has warned his people what he will do. And he will punish them completely. ’"
    },
    {
      "verse": "29",
      "text": "Isaiah had already said this:‘The Lord of great power has let some of our children live. If he had not done that, no descendants would remain. We would have become like the people in Sodom and Gomorrah. ’ ‘The Lord of great power has let some of our children live. If he had not done that, no descendants would remain. We would have become like the people in Sodom and Gomorrah. ’"
    },
    {
      "verse": "30",
      "text": "So, we must think about what all this means. The Gentiles were not trying to become right with God. But some of them have now become right with him. God has accepted them as right, because they have believed in Jesus Christ. ‘Look, I am putting a special stone in Zion. That stone will cause people to fall to the ground. It is a rock that will make them fall down. But anyone who believes in him will never be disappointed. ’"
    },
    {
      "verse": "31",
      "text": "But Israel's people tried to find a law that would make them right with God. But they failed to become right with God."
    },
    {
      "verse": "32",
      "text": "They failed because they refused to believe in Christ. Instead, they were trying to do certain things so that God would accept them. Because of that they fell to the ground. Their feet hit the stone which causes people to fall."
    },
    {
      "verse": "33",
      "text": "It says this in the Bible:‘Look, I am putting a special stone in Zion. That stone will cause people to fall to the ground. It is a rock that will make them fall down. But anyone who believes in him will never be disappointed. ’"
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "My Christian friends, I want God to save Israel's people. I want that very much. I pray to God that he will save them."
    },
    {
      "verse": "2",
      "text": "I can say this about them: They really want to serve God well. But they do not understand the right way to do this."
    },
    {
      "verse": "3",
      "text": "They have not understood the way that God accepts people. Instead, they tried to make their own way to become right with God. They refused to accept God's way that would make them right with him."
    },
    {
      "verse": "4",
      "text": "God gave his Law to Israel's people for a purpose. But Christ has finished that purpose. So now, every person who believes in Christ becomes right with God."
    },
    {
      "verse": "5",
      "text": "Moses wrote about how God's Law could help people to be right with God. He said, ‘If a person obeys the rules in God's Law, then he will live by them. ’"
    },
    {
      "verse": "6",
      "text": "But the Bible speaks also about another way. It shows how to become right with God because you trust him. It says: ‘Do not say to yourself, “Someone will have to go up into heaven. ” ’ (That means: ‘Someone will have to bring Christ down from up there. ’)"
    },
    {
      "verse": "7",
      "text": "‘Do not say to yourself either, “Someone will have to go down into the world below. ” ’ (That means: ‘Someone will have to bring Christ up from the place where dead people are. ’)"
    },
    {
      "verse": "8",
      "text": "But the Bible says: ‘God's message is near you. You can talk about it, and you can think about it. ’ That is the same message that we are teaching to people. We tell people to believe in Jesus Christ."
    },
    {
      "verse": "9",
      "text": "The message is this: You must say clearly that Jesus is the Lord. Also, you must believe deep inside yourself that God raised him to life again after his death. Then God will save you. ‘Everyone who believes in him will not be disappointed. ’"
    },
    {
      "verse": "10",
      "text": "God accepts people as right with him when they believe like that, deep inside themselves. And when people say clearly that Jesus is Lord, God saves them."
    },
    {
      "verse": "11",
      "text": "It says in the Bible:‘Everyone who believes in him will not be disappointed. ’"
    },
    {
      "verse": "12",
      "text": "It says ‘everyone’. There is no difference between Jews and Gentiles. There is the same Lord for all of them. He helps everyone who asks him with many good things."
    },
    {
      "verse": "13",
      "text": "As it says in the Bible: ‘The Lord God will save everyone who asks him for help. ’"
    },
    {
      "verse": "14",
      "text": "But people will never ask Christ to help them if they have not believed in him. And they will never believe in him if they have not heard about him. And they will not hear about him unless somebody tells God's message to them."
    },
    {
      "verse": "15",
      "text": "And nobody can go to tell God's message to people unless God sends them. This is written in the Bible: ‘When people arrive to tell us good news, we say “welcome! ” ’"
    },
    {
      "verse": "16",
      "text": "But not every person who hears the good news obeys its message. Isaiah said this: ‘Lord God, it seems that nobody has believed our message. ’"
    },
    {
      "verse": "17",
      "text": "So then, people must hear the message before they can trust God. And people hear that message when someone tells them about Christ."
    },
    {
      "verse": "18",
      "text": "Let me ask you this: ‘Did Israel's people hear that message? ’ They certainly did! The Bible says:‘People have spoken God's message everywhere. People have heard his message in every part of the world. ’ ‘People have spoken God's message everywhere. People have heard his message in every part of the world. ’"
    },
    {
      "verse": "19",
      "text": "So I ask this too: ‘When Israel's people heard God's message, did they understand it? ’ First, think about what Moses wrote. God said to Israel's people:‘I will make you jealous because of people who are not my people. I will make you angry because of people who know nothing about me. ’ ‘I will make you jealous because of people who are not my people. I will make you angry because of people who know nothing about me. ’"
    },
    {
      "verse": "20",
      "text": "Also, this is what Isaiah said very bravely:‘God says: Those people who were not looking for me have found me. I showed myself to people who were not even asking about me. ’ ‘God says: Those people who were not looking for me have found me. I showed myself to people who were not even asking about me. ’"
    },
    {
      "verse": "21",
      "text": "But Isaiah says this about Israel's people:‘God says: For a very long time, I have been asking my people to return to me. But they refused to obey me. They turned against me. ’"
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "So I ask this: ‘Has God turned away from his people? ’ No, certainly, he has not done that! I myself belong to Israel's people. I am a descendant of Abraham and I belong to Benjamin's tribe."
    },
    {
      "verse": "2",
      "text": "God chose who would be his people from the beginning. He has not turned against them now. Remember what the Bible tells us about Elijah. He wanted God to punish Israel's people. Elijah said:"
    },
    {
      "verse": "3",
      "text": "‘Lord God, they have killed your prophets. They have destroyed the altars where people offered sacrifices to you. I am the only person alive who still serves you. And they are trying to kill me. ’"
    },
    {
      "verse": "4",
      "text": "This was God's answer to Elijah: ‘There are still 7, 000 men that I have kept for myself. Those men have not worshipped the false god Baal. ’"
    },
    {
      "verse": "5",
      "text": "It is the same at this time too. There is a small number of Israel's people that God has chosen to trust him. He has chosen them because he is very kind."
    },
    {
      "verse": "6",
      "text": "This shows that God has not chosen them because of any good things that they have done. If that was true, we could not say that God was really being kind to them. It would not be his gift."
    },
    {
      "verse": "7",
      "text": "So we can say this: Israel's people did not all find what they were looking for. Only those people that God had chosen received it. But the other people of Israel became unable to understand God's message. ‘God caused them to be like people who are sleeping. Even until this day, their eyes cannot really see, and their ears cannot really hear. ’"
    },
    {
      "verse": "8",
      "text": "It says this in the Bible:‘God caused them to be like people who are sleeping. Even until this day, their eyes cannot really see, and their ears cannot really hear. ’"
    },
    {
      "verse": "9",
      "text": "King David says this:‘They enjoy eating lots of good food together. I pray that God will catch them while they are eating! I want those good things to lead them into trouble. I want God to punish them because of what they have done. ‘They enjoy eating lots of good food together. I pray that God will catch them while they are eating! I want those good things to lead them into trouble. I want God to punish them because of what they have done."
    },
    {
      "verse": "10",
      "text": "I want their eyes to become dark so that they cannot see. I want their bodies always to be in pain, like slaves. ’ I want their bodies always to be in pain, like slaves. ’"
    },
    {
      "verse": "11",
      "text": "So now I ask this: ‘When Israel's people failed to accept Jesus as God's Messiah, did they make themselves separate from God for ever? ’ No, certainly that is not true! Because of their mistake, God is now saving Gentiles. God is doing that so that Israel's people would become jealous."
    },
    {
      "verse": "12",
      "text": "Because of their mistake, God has done good things for everyone in the world. Israel's people failed to receive what God wanted to give them. As a result, the Gentiles have received very many good things from God. That was the good result when Israel's people failed. So, when the complete number of Israel's people do turn to God, the result will be even better!"
    },
    {
      "verse": "13",
      "text": "Now I am speaking to you who are Gentiles. God has sent me to be his apostle to the Gentiles. I thank him that he has given this important work to me."
    },
    {
      "verse": "14",
      "text": "I hope that my work among you Gentiles will cause my own people to be jealous. As a result, some of them may turn to God, so that he saves them."
    },
    {
      "verse": "15",
      "text": "When God turned away from Israel's people, he then accepted other people in the world as his friends. So, when God does accept Israel's people, the result will be even better! It will be like dead people who have become alive again!"
    },
    {
      "verse": "16",
      "text": "If you offer the first piece of bread to God, then all the bread will belong to God. If the roots of a tree belong to God, then the branches will also be his."
    },
    {
      "verse": "17",
      "text": "Israel's people are like an olive tree that a farmer has planted. But God has broken off some of that tree's branches. Then he has taken a branch from a wild olive tree. He has put that wild branch into the farmer's tree, to become part of that tree. You Gentiles are like the wild branch. Now you receive food from the root of the farmer's tree, to make you strong."
    },
    {
      "verse": "18",
      "text": "Israel's people are like the branches that God broke off. But you must not think that you are better than those branches. Remember that you are still only a branch. You do not make the root strong. No, it is the root that holds you up and makes you strong."
    },
    {
      "verse": "19",
      "text": "You might say, ‘God broke off the branches so that I could become part of the tree. ’"
    },
    {
      "verse": "20",
      "text": "That is true. God broke them off because they did not believe in Christ. God has accepted you as part of the tree because you do believe in Christ. So do not become proud. Instead, be afraid."
    },
    {
      "verse": "21",
      "text": "God broke off the proper branches and he did not let them stay in the tree. So, if you no longer trust him, he will not let you stay either."
    },
    {
      "verse": "22",
      "text": "So you should think about what God is like. He is kind, but he also punishes people. He has punished Israel's people, because they turned away from him. He has been kind to you. But you must continue to accept his kind gift. If you do not do that, he will break you off from his tree as well."
    },
    {
      "verse": "23",
      "text": "God is able to accept Israel's people back again. If they come to believe in Christ, God will put them back as part of the tree. He is able to make them become branches of the tree again."
    },
    {
      "verse": "24",
      "text": "God cut you like branches from a wild olive tree. Then he put you into the farmer's olive tree so that you became part of it. He could do that even though that was not your own tree before. So God will be able to do that for Israel's people. He can easily put them back into their own tree, that they were part of before."
    },
    {
      "verse": "25",
      "text": "My Christian friends, I want to help you to understand about Israel's people. It is a secret that God has shown to us. If you really understand it, you will not be proud that you are so clever. Many of Israel's people have refused to believe in Christ. They will continue to refuse him until the complete number of Gentiles have believed. ‘The one who rescues will come from Zion. He will turn Jacob's people away from their sins."
    },
    {
      "verse": "26",
      "text": "When that has happened, God will save all Israel's people. This is written in the Bible:‘The one who rescues will come from Zion. He will turn Jacob's people away from their sins."
    },
    {
      "verse": "27",
      "text": "And I will make this agreement with them. I will forgive them for their sins. ’ I will forgive them for their sins. ’"
    },
    {
      "verse": "28",
      "text": "Israel's people have become God's enemies, because they have refused to believe the good news about Christ. This has happened to help you Gentiles. But God still loves Israel's people, because he has chosen them as his own people. That is what he promised to their ancestors."
    },
    {
      "verse": "29",
      "text": "God's thoughts about his people cannot change. He has blessed them with gifts and he has chosen them to belong to him."
    },
    {
      "verse": "30",
      "text": "In past times, you Gentiles did not obey God. But now God has been very kind to you, because Israel's people refused to obey him."
    },
    {
      "verse": "31",
      "text": "They do not obey God now. As a result God has been very kind to you. That has happened so that God may now be very kind to them too."
    },
    {
      "verse": "32",
      "text": "God says that everyone is guilty because they do not obey him. He says that so that he can be kind and he can forgive everyone."
    },
    {
      "verse": "33",
      "text": "Yes! God is very great! He has everything! He knows and he understands all things! Nobody can completely understand the things that he decides. Nobody can explain the ways in which he works. ‘Nobody knows the thoughts of the Lord God. Nobody is able to tell him what he should do. ’"
    },
    {
      "verse": "34",
      "text": "The Bible says this:‘Nobody knows the thoughts of the Lord God. Nobody is able to tell him what he should do. ’"
    },
    {
      "verse": "35",
      "text": "‘Nobody has ever given anything to God, so that God had a debt to pay back to them. ’ so that God had a debt to pay back to them. ’"
    },
    {
      "verse": "36",
      "text": "It is God who made all things. He also causes all things to continue. And all things are there to show how great he is. We praise him! He is great for ever! Amen. This is true!"
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "My Christian friends, God has been very kind to us. Because of that, I really want you to serve God with your whole life. Offer your bodies to him like a sacrifice that continues to live. Serve him with everything that you have and that will please him. That is the true way to worship God."
    },
    {
      "verse": "2",
      "text": "Do not become like the people who belong to this world. But let God completely change the way that you think, so that you live differently. Then you will understand what God wants you to do. You will know what is good. You will know what pleases God. You will know what is completely right."
    },
    {
      "verse": "3",
      "text": "God has been kind to me so that I can serve him. Because of that, I say this to every one of you: Do not think that you are better than you really are. Instead, think about yourself carefully. Decide how much God has helped you to trust him. Then you will know how to serve him well."
    },
    {
      "verse": "4",
      "text": "Each part of our body works in a different way. But all the parts belong to our one body."
    },
    {
      "verse": "5",
      "text": "In the same way, we are many people, but we all belong to Christ, like one body. We also belong to each other, like the different parts of one body belong to each other."
    },
    {
      "verse": "6",
      "text": "God has been kind to us. He has given to each of us different gifts so that we can serve him. God helps some people to speak his messages clearly. Those people should trust God to tell them what to say."
    },
    {
      "verse": "7",
      "text": "God helps some people to serve others. They should do that well. God helps some people to be able to teach others. Those people should teach well."
    },
    {
      "verse": "8",
      "text": "If God has helped you to make others strong, then you should do that. If God has helped you to share your things with others, do that seriously. If God has helped you to be a leader, do that carefully. If God has helped you to be kind to others, do that happily."
    },
    {
      "verse": "9",
      "text": "Really love other people, not like a hypocrite. Hate anything that is bad. Continue to do things that are good."
    },
    {
      "verse": "10",
      "text": "Love each other truly like brothers and sisters. Be really happy to respect other Christians."
    },
    {
      "verse": "11",
      "text": "Do not be lazy, but always work hard. Serve the Lord well because you enjoy it."
    },
    {
      "verse": "12",
      "text": "Be happy, because you can trust God to do what he says. Be patient when you have troubles. Always continue to pray."
    },
    {
      "verse": "13",
      "text": "If any of God's people need anything, then help them with what you have. Always be happy to let people stay in your home."
    },
    {
      "verse": "14",
      "text": "Ask God to bless people who cause trouble for you. Yes, ask him to be kind to them. Do not ask him to do bad things to them."
    },
    {
      "verse": "15",
      "text": "If you are with someone who is happy, you should also be happy. If you are with someone who is sad, you should also be sad."
    },
    {
      "verse": "16",
      "text": "Always try to agree and to be friends with each other. Do not be proud. Be friends with people who are not important. Do not think that you know everything."
    },
    {
      "verse": "17",
      "text": "If someone has done bad things against you, do not do bad things back to them. Try to live in a good way so that people will respect you. They will see that you do good things."
    },
    {
      "verse": "18",
      "text": "If it is possible, try always to be friends with other people."
    },
    {
      "verse": "19",
      "text": "My friends, if someone has done bad things to you, do not try to punish them yourselves. Instead, let God be angry and punish them. This is what is written in the Bible:‘The Lord God says, “When people do something wrong, I am the one who will punish them. I will pay them back. ” ’ ‘The Lord God says, “When people do something wrong, I am the one who will punish them. I will pay them back. ” ’"
    },
    {
      "verse": "20",
      "text": "But the Bible also says this:‘If your enemy is hungry, feed him. If he is thirsty, give him something to drink. If you help your enemy, he will become ashamed. He will be sorry because of what he did to you. ’ ‘If your enemy is hungry, feed him. If he is thirsty, give him something to drink. If you help your enemy, he will become ashamed. He will be sorry because of what he did to you. ’"
    },
    {
      "verse": "21",
      "text": "Do not let evil things win against you! Instead, do good things. Then you will win against the evil things that people do."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "Everyone must obey the government officers. It is God who gives the authority to rule. The people who rule have received their authority from God."
    },
    {
      "verse": "2",
      "text": "So anyone who refuses to obey that authority is refusing to obey God. That person will receive the proper punishment."
    },
    {
      "verse": "3",
      "text": "People who do good things do not need to be afraid of the rulers. Only people who do bad things should be afraid of the rulers. Do you want to live and not be afraid of the rulers? Then you must do good things and they will respect you."
    },
    {
      "verse": "4",
      "text": "Rulers are God's servants. They help you to do good things. But if you do bad things, then you should be afraid of them. They really do have authority to punish people. On God's behalf they punish people who do bad things."
    },
    {
      "verse": "5",
      "text": "So you must obey the people who have authority to rule. You must obey them not only so that they do not punish you. You must obey them because it is right to obey them. And you yourselves know that this is right."
    },
    {
      "verse": "6",
      "text": "This is also the reason why you pay taxes to the government. You should pay them, because the officers are God's servants. They are doing the work that God has given to them."
    },
    {
      "verse": "7",
      "text": "So you must give to each person what you ought to give them. Pay taxes to the people who receive taxes. Do that for every kind of tax. Respect those people that you should respect. Praise people that you should praise."
    },
    {
      "verse": "8",
      "text": "Always pay your debts to people. The only debt that you should have is to love each other. Anyone who loves other people has obeyed God's Law completely."
    },
    {
      "verse": "9",
      "text": "The rules in God's Law say this: ‘Do not have sex with anyone who is not your own wife or your own husband. Do not kill anyone. Do not rob anyone. Do not want things that belong to other people. ’ All these rules, and all the other rules in God's Law, are all included in one rule. That one rule is: ‘Love other people as much as you love yourself. ’"
    },
    {
      "verse": "10",
      "text": "If you love other people, you will never do anything bad to them. So anyone who loves other people has obeyed God's Law completely."
    },
    {
      "verse": "11",
      "text": "Live in that way, because you know what is happening in this time now. It is time that you should stop sleeping. It is now time to wake up. The time when God will save us completely is near. That time is nearer now than when we first believed in him."
    },
    {
      "verse": "12",
      "text": "The night has nearly finished and the day is almost here. So we must stop doing the bad things that belong to the dark. Instead, we must take weapons like soldiers who are ready to fight in the light."
    },
    {
      "verse": "13",
      "text": "We should live in a good way, because we live in the light of day. We should not go to wild parties. We must not be drunks. We must not have sex with anyone who is not our own wife or husband. We must not do wrong things with our bodies. We must not quarrel. We must not be jealous of other people."
    },
    {
      "verse": "14",
      "text": "Instead, you must live with the Lord Jesus Christ as your guide. Do not even think about the bad things that you may want to do to make yourself happy."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "It is difficult for some Christians to trust God completely about everything. You should accept people like that as your friends. Do not argue with them about what they think is right or wrong."
    },
    {
      "verse": "2",
      "text": "Some people believe that they may eat all kinds of food. But other people are not so sure, so they eat only vegetables."
    },
    {
      "verse": "3",
      "text": "People who eat anything must not think that they are better than people who eat only vegetables. Also, people who eat only vegetables must not judge other people who eat anything. They are not doing anything wrong, because God himself has accepted them."
    },
    {
      "verse": "4",
      "text": "God is the master of all believers and they are his servants. You do not have authority to judge someone else's servant. The servant's own master will decide if he has done well or he has done something wrong. And he will serve his master well, because the Lord is able to help him to do that."
    },
    {
      "verse": "5",
      "text": "Some people think that certain days are special and more important than other days. Other people think that all days are the same. Each person should decide what seems right to him."
    },
    {
      "verse": "6",
      "text": "A person who makes a certain day special does that so that he can respect the Lord. A person who eats all kinds of food does that so that he can respect the Lord. He thanks God for the food that he eats. A person who refuses to eat certain foods also does that so that he can respect the Lord. And he also thanks God."
    },
    {
      "verse": "7",
      "text": "None of us lives only to please ourselves. And we do not die to please ourselves."
    },
    {
      "verse": "8",
      "text": "While we live, we want to please the Lord. And when we die, we want that to please the Lord too. So, while we live, or if we die, we continue to belong to the Lord."
    },
    {
      "verse": "9",
      "text": "Christ died and then he became alive again. That happened so that he could be the Lord of all people, those who have died and those who are still alive."
    },
    {
      "verse": "10",
      "text": "So then, if you eat only vegetables, you must not judge other believers. Also, if you eat anything, you must not think that you are better than other believers. Remember that all of us will have to stand in front of God. He will decide whether we have done what is right or wrong. ‘The Lord God says, “As surely as I live, this will certainly happen: Everyone will go down on their knees in front of me. Everyone will praise me that I am God. ” ’"
    },
    {
      "verse": "11",
      "text": "This is written in the Bible:‘The Lord God says, “As surely as I live, this will certainly happen: Everyone will go down on their knees in front of me. Everyone will praise me that I am God. ” ’"
    },
    {
      "verse": "12",
      "text": "So each of us will have to explain to God about the things that we have done."
    },
    {
      "verse": "13",
      "text": "So we must no longer judge other believers. Instead, you must decide never to bring trouble to another believer. Do not cause them to do something wrong."
    },
    {
      "verse": "14",
      "text": "As for me, I am sure that we may eat any kind of food. God does not think that any food is unclean. The Lord Jesus has shown me that that is true. But someone else may believe that it is wrong to eat certain food. For that person, it would be wrong to eat that kind of food."
    },
    {
      "verse": "15",
      "text": "You should not cause another believer to be sad because of what you eat. If you do make him sad, then you are not really loving him. Remember that Christ died on behalf of that person. So do not let your food make him turn away from God."
    },
    {
      "verse": "16",
      "text": "You may think that something is good. But still you should not do it, if other people will say that it is bad."
    },
    {
      "verse": "17",
      "text": "We belong to God's people and he is our King. The things that we eat and drink are not really important to him. This is important: We should do what is right. We should have peace in our minds. And we should be truly happy. God's Holy Spirit helps us to live like that."
    },
    {
      "verse": "18",
      "text": "If anyone serves Christ in that way, they will make God happy. And other people will respect them."
    },
    {
      "verse": "19",
      "text": "So then, we should try to live in a way that brings peace. We should try to help each other so that we become stronger as God's people."
    },
    {
      "verse": "20",
      "text": "Do not bring trouble to someone because of the food that you eat. Do not destroy what God has done in the life of another believer. God lets us eat all kinds of food. But do not eat anything that will cause another believer to do something wrong."
    },
    {
      "verse": "21",
      "text": "It is good not to do anything that might cause another believer to do something wrong. That includes if you eat meat or if you drink wine."
    },
    {
      "verse": "22",
      "text": "What you believe about these things should be a secret between yourself and God. You should do what you have decided is right for you. Do not feel guilty about what you eat. Then God will bless you."
    },
    {
      "verse": "23",
      "text": "But someone else may not be sure whether it is right to eat certain kinds of food. If that person does eat that kind of food, then he shows that he is guilty. He has not trusted God that it is right for him to do that. Whatever things we do, we must trust God about them. If we do not trust God that something is right, then it is a sin."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "Some of us trust God with strong faith. We must help those believers whose faith is weaker. We must be patient with them. We should not just do things that will make us happy ourselves."
    },
    {
      "verse": "2",
      "text": "Instead, each of us should do things that will make other believers happy. We should help them to trust God more strongly."
    },
    {
      "verse": "3",
      "text": "Even Christ did not just do things that would make himself happy. It is written in the Bible that he said this: ‘People have insulted you, God. In that way they have also insulted me. ’"
    },
    {
      "verse": "4",
      "text": "Everything that people wrote in the Bible in past times is there to teach us something. Those words help us to be patient and strong. As a result, we can trust God to do what he has promised."
    },
    {
      "verse": "5",
      "text": "It is God himself who helps us to be patient and strong. So I pray that he will help you to agree with each other and to be friends. That is how Christ Jesus wants you to live."
    },
    {
      "verse": "6",
      "text": "As a result, all of you will praise God together with the same thoughts. You will all agree that God, the Father of our Lord Jesus Christ, is very great."
    },
    {
      "verse": "7",
      "text": "Christ has accepted you, so you must accept each other. In that way you will be praising God. ‘I will tell the Gentiles about you, God. I will praise you with songs, to show how great you are. ’"
    },
    {
      "verse": "8",
      "text": "Remember this: Christ became a servant of the Jews so that they could understand God's true message. He showed them that God has now done what he promised to their ancestors."
    },
    {
      "verse": "9",
      "text": "The Gentiles also praise God because he has been kind to them. This is written in the Bible:‘I will tell the Gentiles about you, God. I will praise you with songs, to show how great you are. ’"
    },
    {
      "verse": "10",
      "text": "It says also in the Bible:‘Be very happy, you Gentiles! Praise God together with his people. ’ ‘Be very happy, you Gentiles! Praise God together with his people. ’"
    },
    {
      "verse": "11",
      "text": "It also says this:‘Say how great the Lord is, all you Gentiles. All people, from every country, should say how great he is. ’ ‘Say how great the Lord is, all you Gentiles. All people, from every country, should say how great he is. ’"
    },
    {
      "verse": "12",
      "text": "God's prophet Isaiah says this:‘The root of Jesse will arrive. He will come to rule the Gentiles. The Gentiles will trust him to save them. ’ ‘The root of Jesse will arrive. He will come to rule the Gentiles. The Gentiles will trust him to save them. ’"
    },
    {
      "verse": "13",
      "text": "God is the one who causes us to hope for good things. I pray that God will bless you very much. I pray that he will cause you to be happy and to have peace in your minds. He will do this because you believe in him. As a result, God's Holy Spirit will make you strong with his power, so that you hope even more certainly."
    },
    {
      "verse": "14",
      "text": "My Christian friends, I myself am completely sure that you are always good. You know everything about God's message, so that you are able to teach one another what is right."
    },
    {
      "verse": "15",
      "text": "I know that is true, but I still needed to write this letter to you. I have written to you strongly, so that you would remember certain things. Because God is kind, he has chosen me to serve him in this way."
    },
    {
      "verse": "16",
      "text": "I am a servant of Christ Jesus among the Gentiles. I tell people God's good news. I work like a priest so that God will accept the Gentiles. I offer them to God. The Holy Spirit has made them clean and so God accepts them."
    },
    {
      "verse": "17",
      "text": "So I can be proud about my work. I can serve God well because I belong to Christ Jesus."
    },
    {
      "verse": "18",
      "text": "But I will only speak about the work that Christ has made me able to do. I have lived among the Gentiles and I have spoken God's message to them. They have obeyed God as a result of Christ's work through me."
    },
    {
      "verse": "19",
      "text": "God's Holy Spirit used his power to do many miracles. He caused many great and powerful things to happen. As a result, I have told the whole good news about Christ to many people. I have told it while I travelled all the way from Jerusalem to Illyricum."
    },
    {
      "verse": "20",
      "text": "I want to go to places where nobody has ever told people about Christ before. I want to tell the good news to people in those places. That is what I have always wanted to do. I do not want to work in a place where someone else has already started to teach God's message. ‘Those people that nobody ever told them about him will now see. Those people who have never heard about him will now understand. ’"
    },
    {
      "verse": "21",
      "text": "This is written in the Bible about God's Messiah:‘Those people that nobody ever told them about him will now see. Those people who have never heard about him will now understand. ’"
    },
    {
      "verse": "22",
      "text": "That is why, many times, I have not had a chance to visit you."
    },
    {
      "verse": "23",
      "text": "For many years I have been waiting for the chance to come. But now I have finished my work in these places here."
    },
    {
      "verse": "24",
      "text": "So I hope to visit you while I am travelling to Spain. I will stay with you in Rome for a short time. I will really enjoy having some time together with you there. Then you can help me to continue my journey."
    },
    {
      "verse": "25",
      "text": "But now, I am ready to go to Jerusalem to help God's people there."
    },
    {
      "verse": "26",
      "text": "Some of them are poor, and the Christians in Macedonia and Achaia wanted to help them. So they got some money to send to those people."
    },
    {
      "verse": "27",
      "text": "The Christians in Macedonia and Achaia were happy to share what they had. But really, they have a duty to help the Jewish Christians in Jerusalem. It is the Jews who shared good things from God to help the Gentiles in their spirits. So now the Gentiles ought to help the Jewish Christians with things that they need for their bodies."
    },
    {
      "verse": "28",
      "text": "So I must take their gift safely to the Christians in Jerusalem. When I have finished that job, I will come to visit you. Then I will continue my journey to Spain."
    },
    {
      "verse": "29",
      "text": "When I visit you, I know that Christ will bless us very much while we are together."
    },
    {
      "verse": "30",
      "text": "My Christian friends, please pray for me as I do this difficult work. Together we belong to our Lord Jesus Christ. God's Spirit has given us love for each other. So I ask you to help me and to pray with me."
    },
    {
      "verse": "31",
      "text": "Pray that God will keep me safe from those people in Judea who have refused to believe in Jesus. Pray also that God's people at Jerusalem will happily accept the gift that I am taking to them."
    },
    {
      "verse": "32",
      "text": "If God agrees, I will then be able to come to you, and we will be happy together. I will enjoy having some rest while I stay there with you."
    },
    {
      "verse": "33",
      "text": "I pray that God will give you peace in your minds. I pray that he will be with all of you and help you. Amen."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "I want you to know that our Christian friend Phoebe is a good person. She is a servant of the church at Cenchrea."
    },
    {
      "verse": "2",
      "text": "Please be kind to her when she comes to you, because you belong to the Lord. Help her in the way that God's people ought to help one another. Give to her the things that she needs. She has worked to help me as well as many other people."
    },
    {
      "verse": "3",
      "text": "Say ‘hello’ on my behalf to Priscilla and Aquila. They have worked together with me as servants of Christ Jesus. Say ‘hello’ to my very good friend Epenetus. He was the first person in the region of Asia who believed in Christ."
    },
    {
      "verse": "4",
      "text": "They were even ready to die so that they could help me. So I have a good reason to thank them. All the groups of Gentile believers also have a good reason to thank them."
    },
    {
      "verse": "5",
      "text": "Also say ‘hello’ for me to the group of believers who meet in Priscilla and Aquila's house. Say ‘hello’ to my very good friend Epenetus. He was the first person in the region of Asia who believed in Christ."
    },
    {
      "verse": "6",
      "text": "Say ‘hello’ to Mary, who has worked very much on your behalf."
    },
    {
      "verse": "7",
      "text": "Say ‘hello’ to my relatives Andronicus and Junia, who were in prison with me. The apostles know them well and respect them. They became believers in Christ before I did."
    },
    {
      "verse": "8",
      "text": "Say ‘hello’ to Ampliatus on my behalf. He is my very good friend in the Lord's family."
    },
    {
      "verse": "9",
      "text": "Say ‘hello’ to Urbanus, who works with us to serve Christ. Also say ‘hello’ to my good friend Stachys."
    },
    {
      "verse": "10",
      "text": "Say ‘hello’ to Apelles. He has shown that he trusts Christ very well. Say ‘hello’ to those people who belong to Aristobulus's family."
    },
    {
      "verse": "11",
      "text": "Say ‘hello’ to my relative Herodion. Say ‘hello’ to those people in Narcissus's family who belong to the Lord."
    },
    {
      "verse": "12",
      "text": "Say ‘hello’ to Tryphena and Tryphosa. They work hard to serve the Lord. Say ‘hello’ to my good friend Persis. She has worked very hard to serve the Lord."
    },
    {
      "verse": "13",
      "text": "Say ‘hello’ to Rufus. He is a special servant of the Lord. Say ‘hello’ also to his mother, who has been kind to me, like a mother."
    },
    {
      "verse": "14",
      "text": "Say ‘hello’ to Asyncritus, Phlegon, Hermes, Patrobas and Hermas. Say ‘hello’ also to all our Christian friends who are there with them."
    },
    {
      "verse": "15",
      "text": "Say ‘hello’ to Philologus and Julia, to Nereus and his sister, and to Olympas. Say ‘hello’ also to all God's people who are there with them."
    },
    {
      "verse": "16",
      "text": "When you meet, kiss each other as Christian brothers and sisters. The people of all the Christian churches here say ‘hello’ to you."
    },
    {
      "verse": "17",
      "text": "My Christian friends, I want to tell you something important. Be very careful about people who teach wrong things. They teach things that are different from God's true message that you learned. Those people cause you to quarrel with each other. They cause people to turn away from God. You must stay away from them."
    },
    {
      "verse": "18",
      "text": "People who are like that are not servants of our Lord Christ. Instead, they are doing the things which please themselves. They speak words that seem very nice, but they deceive people who easily accept a false message."
    },
    {
      "verse": "19",
      "text": "Everyone knows that you obey God well. So I am very happy because of you. But I want you to understand clearly what things are good. And I want you to stay away from the things that are bad."
    },
    {
      "verse": "20",
      "text": "God gives us peace in our minds. He will quickly help you to win against the power of Satan. I pray that our Lord Jesus will continue to be kind to you."
    },
    {
      "verse": "21",
      "text": "Timothy, who is working together with me, says ‘hello’ to you. My relatives Lucius, Jason and Sosipater, also say ‘hello’ to you."
    },
    {
      "verse": "22",
      "text": "I, Tertius, have written down this letter for Paul. I also belong to the Lord and I say ‘hello’ to you."
    },
    {
      "verse": "23",
      "text": "Gaius also says ‘hello’ to you. I, Paul, am staying in his house. The group of Christians here also meet together in his house. Erastus also says ‘hello’ to you. He is an officer who takes care of the city's money. Our Christian friend Quartus says ‘hello’ to you too. ["
    },
    {
      "verse": "24",
      "text": "I pray that our Lord Jesus Christ will continue to be very kind to all of you. ]"
    },
    {
      "verse": "25",
      "text": "We praise God because he is great! He is able to make you strong in your spirits! That is the good news that I teach. That good news is the message about Jesus Christ that God has kept secret since long ago. But now he has shown this message to us."
    },
    {
      "verse": "26",
      "text": "God's prophets already wrote that this good news would come. God, who lives for ever, has commanded us to tell it to people. He wants people from all nations to know this message. Then they can believe in God and obey him."
    },
    {
      "verse": "27",
      "text": "Yes, we praise God! Only he is completely wise. We praise him for ever, because of Jesus Christ! This is true. Amen."
    }
  ]
};