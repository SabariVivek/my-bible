module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "Paul and Timothy write this letter to you. We are servants of Christ Jesus. We are writing to you, God's own people who live in Philippi. You belong to God because you are united with Christ Jesus. We are writing to all of you. This includes the leaders and the deacons in the church there. We are writing to you, God's own people who live in Philippi. You belong to God because you are united with Christ Jesus. We are writing to all of you. This includes the leaders and the deacons in the church there."
    },
    {
      "verse": "2",
      "text": "We pray that God our Father and the Lord Jesus Christ will continue to help you. We pray that they will give you peace in your minds."
    },
    {
      "verse": "3",
      "text": "Every time that I think about you, I thank my God because of you."
    },
    {
      "verse": "4",
      "text": "I am always praying for you. Every time that I pray for you, I feel very happy."
    },
    {
      "verse": "5",
      "text": "I am happy because together we tell people the good news about Christ. You have always helped me with that work, since the first day that you yourselves heard the good news."
    },
    {
      "verse": "6",
      "text": "I know that God has begun to do good things in you. And I am sure that he will continue to work in you. Then, on the day when Jesus Christ returns, his work in you will be finished."
    },
    {
      "verse": "7",
      "text": "It is right for me to feel like this about all of you, because I love you very much. God has been very kind to all of us. Because you know that, you have continued to help me. You have helped me while I have been here in this prison. You also helped me when I was free and I could teach the good news. I explained to people why the good news is God's true message. Together, we have known how kind God is."
    },
    {
      "verse": "8",
      "text": "God knows that I very much want to be with all of you. I love you very much, just like Christ Jesus himself loves you."
    },
    {
      "verse": "9",
      "text": "This is what I pray for you. I pray that you will continue to love each other more and more. I pray that you will know God better and better. I pray that you will understand all those things that are true."
    },
    {
      "verse": "10",
      "text": "Then you will be able to choose what is best in the way that you live. Then, on the day when Christ returns, you will be completely clean. You will not be guilty of any bad thing."
    },
    {
      "verse": "11",
      "text": "Because of the work that Jesus Christ has done in you, you will be right with God. And your lives will be full of good things. As a result, people will praise God and they will say that he is very great."
    },
    {
      "verse": "12",
      "text": "My friends, I want you to know this. The trouble that has happened to me has helped more people to know about God's good news."
    },
    {
      "verse": "13",
      "text": "I am in a prison because I am Christ's servant. The soldiers in the king's house and all the people here know that."
    },
    {
      "verse": "14",
      "text": "Also, because I am in a prison, most of the other believers here trust the Lord even more. The Lord has made them brave, so that they are not afraid to speak God's message to people."
    },
    {
      "verse": "15",
      "text": "It is true that some of these Christians are jealous of me. They want to show that they are better than me. That is why they tell people the message about Christ. But other Christians speak about Christ because they want to help me."
    },
    {
      "verse": "16",
      "text": "They tell people about him because they love me. They know that God has put me here in this prison. And he wants me to show people that the good news is true."
    },
    {
      "verse": "17",
      "text": "Those other people speak about Christ because they want to seem important. They do not really want to help people. They just want to cause trouble for me while I am here in this prison."
    },
    {
      "verse": "18",
      "text": "But it does not matter to me! All of them are telling people about Christ. That is the most important thing. Whether they speak because of wrong reasons or because of right reasons, they are speaking the message about Christ! Because of that, I am happy. Yes, I will continue to be happy."
    },
    {
      "verse": "19",
      "text": "You are praying for me and Jesus Christ's Spirit is helping me. So I know that what has happened to me will have a good result. Yes, God will rescue me."
    },
    {
      "verse": "20",
      "text": "I never want to do anything that will cause me to be ashamed. I hope very much that I will never do that. I want to be brave now, as I always have been. In the way that I live, I want to show that Christ is very great. I want to do that if I continue to live. And I want to do that if I die."
    },
    {
      "verse": "21",
      "text": "Christ is everything that I live for. If I die, that will be even better for me."
    },
    {
      "verse": "22",
      "text": "But if I continue to live, I will be able to do more good things to help people. I do not know whether it would be better to live or to die. I do not know which to choose."
    },
    {
      "verse": "23",
      "text": "Both of them seem very good to me. I want to leave this world so that I can be with Christ. That is a much better thing."
    },
    {
      "verse": "24",
      "text": "But you people need me to continue to live here in this world."
    },
    {
      "verse": "25",
      "text": "Yes, I am sure that you need me. For that reason, I know that I will continue to live among you. Then I will be able to help you to trust Christ even more. And that will make you even happier."
    },
    {
      "verse": "26",
      "text": "Then, when I am there with you again, you will have an even better reason to thank Christ Jesus."
    },
    {
      "verse": "27",
      "text": "The most important thing is that you continue to live in a good way. Live in the way that the good news about Christ teaches. I want to know that you agree together about the good news. And that you work together to show others that the good news is true. Whether I come to visit you or not, I want to know that you all help one another like that."
    },
    {
      "verse": "28",
      "text": "I want to know that you are not afraid of the people who speak against you. If you are brave, that will be a sign from God. It will show your enemies that they will lose and you will win. God will punish them, but he will save you."
    },
    {
      "verse": "29",
      "text": "God is helping you to serve Christ well. That means that you believe in Christ. But it also means that you receive trouble and pain on his behalf. Both of those are gifts from God."
    },
    {
      "verse": "30",
      "text": "You are receiving the same kinds of trouble that I myself receive. You saw that when I was with you. Now you hear that it is still happening to me."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "You belong to Christ, and he makes you brave. His love makes you strong. You are able to help one another because his Spirit is in you. You can be kind to each other, and you can forgive each other."
    },
    {
      "verse": "2",
      "text": "Because of that, this is how you can make me completely happy: In your mind, think about things in the same way as one another. Love one another completely. In your spirit, agree with one another. And work together for the same purpose."
    },
    {
      "verse": "3",
      "text": "In the way that you live, do not just try to help yourself. Do not be proud. Instead, respect other people. Think about other people as more important than yourself."
    },
    {
      "verse": "4",
      "text": "Do not think only about the things that you want to do for yourself. Each of you should think also about how you can help other people."
    },
    {
      "verse": "5",
      "text": "You should think about things in the same way that Christ Jesus thought:"
    },
    {
      "verse": "6",
      "text": "Christ had the same nature as God. He was completely equal with God. But he did not try to keep hold of that. He was completely equal with God. But he did not try to keep hold of that."
    },
    {
      "verse": "7",
      "text": "Instead, he chose to leave heaven. He took for himself the nature of a slave. He became like a human. He took for himself the nature of a slave. He became like a human."
    },
    {
      "verse": "8",
      "text": "And when he lived as a man, he made himself even less important. He obeyed God completely, so that he died. He even died on a cross! he made himself even less important. He obeyed God completely, so that he died. He even died on a cross!"
    },
    {
      "verse": "9",
      "text": "Because of that, God then raised Jesus Christ to the most important place. God gave him the name that is greater than every other name. God gave him the name that is greater than every other name."
    },
    {
      "verse": "10",
      "text": "As a result, when people hear Jesus' name, they must worship him. Everyone will have to go down on their knees in front of him. That includes everything that is in heaven, everything on the earth and everything under the earth. Everyone will have to go down on their knees in front of him. That includes everything that is in heaven, everything on the earth and everything under the earth."
    },
    {
      "verse": "11",
      "text": "Everyone will have to agree that Jesus Christ is Lord. When they say that aloud, they will show that God the Father is very great. When they say that aloud, they will show that God the Father is very great."
    },
    {
      "verse": "12",
      "text": "So, my friends, you must continue to obey God. When I was with you, you always obeyed. Now that I am not with you, that is even more important. God has saved you. You must always live in a way which shows that is true. Respect God and obey him. Remember that he is great and powerful."
    },
    {
      "verse": "13",
      "text": "It is God himself who is working in you. Now you want to obey him, and he makes you strong to do that. When you obey him, that makes him very happy."
    },
    {
      "verse": "14",
      "text": "Whatever you are doing, do not complain. And do not argue."
    },
    {
      "verse": "15",
      "text": "Then you will not be guilty of anything that is wrong. You will be clean inside yourselves. You will be living in a completely good way, as God's children should. In this world, you are living among bad people who have turned away from what is good. But you must bring light into this dark place, like stars that shine in the night."
    },
    {
      "verse": "16",
      "text": "Tell people the true message that can give them life with God. Then I will know that my work among you had good results. Because of that, I will be very happy on the day when Christ returns."
    },
    {
      "verse": "17",
      "text": "You believe in Christ, and you are his servants. That is like you are offering yourselves as a sacrifice to God. Perhaps I will soon have to die. Then my blood would be like drink that I am pouring on your sacrifice, to please God. So, if I have to die now, I will be happy. And we should all be happy together."
    },
    {
      "verse": "18",
      "text": "Yes, it is right that you should be happy, and I will also be happy with you."
    },
    {
      "verse": "19",
      "text": "I want to send Timothy to come to you soon. I hope that the Lord Jesus will let me do that. Then, when Timothy returns to me, he can tell me news about you. And that will make me happy."
    },
    {
      "verse": "20",
      "text": "Timothy really loves you, as I do. There is nobody else here with me like him."
    },
    {
      "verse": "21",
      "text": "Everyone else thinks only about themselves. They have no interest in the things that are important to Jesus Christ."
    },
    {
      "verse": "22",
      "text": "But you know what Timothy is like. He has worked with me like a son works to help his father. Together we have taught people God's good news."
    },
    {
      "verse": "23",
      "text": "That is why I hope to send him to you soon. But first, I want to know what will happen to me here."
    },
    {
      "verse": "24",
      "text": "The Lordhas helped me to hope that I will soon come to you myself."
    },
    {
      "verse": "25",
      "text": "Whatever happens, I think I must send Epaphroditus to come back to you. He is our true Christian brother. He has worked with me to serve God together. We have worked hard, like soldiers. When I needed help, you sent him to me. He has helped me on your behalf."
    },
    {
      "verse": "26",
      "text": "Now he wants very much to see all of you again. He became very sad, because you heard the message that he was ill."
    },
    {
      "verse": "27",
      "text": "Certainly, he was very ill, and he almost died. But God was kind to him. And God was kind to me too. If Epaphroditus had died, I would have become even more sad."
    },
    {
      "verse": "28",
      "text": "So I want even more to send him back to you. Then you can be really happy, and I will not feel sad any more."
    },
    {
      "verse": "29",
      "text": "Receive Epaphroditus well when he comes, and be happy. Like you, he belongs to the Lord's people. You should respect people like him and be kind to them."
    },
    {
      "verse": "30",
      "text": "He nearly died because he was working to serve Christ. He came to help me, because you could not help me yourselves. He was even ready to die so that he could do that on your behalf."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "My Christian friends, there are a few more things that I want to say. You belong to the Lord, so be happy! It is no trouble for me to write the same things to you again. And it will help to keep you safe."
    },
    {
      "verse": "2",
      "text": "Be very careful! Some people are teaching bad things. They say that you must cut your bodies. They are like dangerous dogs. Do not believe them!"
    },
    {
      "verse": "3",
      "text": "But we are truly God's people. And it is not because someone has circumcised us. It is God's own Spirit that leads us to worship God. We thank God because of what Christ Jesus has done for us. We know that it is not human ideas that can save us."
    },
    {
      "verse": "4",
      "text": "For myself, I could have trusted those human ideas. Perhaps somebody may think that they could trust in those things to save them. Then I would have an even better reason to trust in them."
    },
    {
      "verse": "5",
      "text": "I belong to Israel's people, to Benjamin's tribe. I am a true Jew. They circumcised me when I was eight days old. I was a Pharisee, and I obeyed the Jewish rules very carefully."
    },
    {
      "verse": "6",
      "text": "I tried very much to please God. So I caused a lot of trouble and pain for the Christians. I obeyed the rules of God's Law, and nobody could say that I did anything wrong."
    },
    {
      "verse": "7",
      "text": "All those ideas seemed very important to me then. But now they are worth nothing to me, because I trust in Christ."
    },
    {
      "verse": "8",
      "text": "Yes, now that I know Christ Jesus as my Lord, that is the most valuable thing. Nothing else is important at all. I have thrown everything else away, so that I can serve Christ. All those other things are like dirt to me. I think about them like that, so that I can have Christ."
    },
    {
      "verse": "9",
      "text": "I want to be united with him. Because I believe in Christ, God accepts me as right with him. I know that I cannot become right in any other way, even if I obey all of God's Law. When I trust in Christ, God accepts me as right because of my faith."
    },
    {
      "verse": "10",
      "text": "Yes, I want to know Christ better and better. I want to know the power which God showed when Christ rose from death. I want to have the same kind of troubles that he did. I want to obey God like he did in his death."
    },
    {
      "verse": "11",
      "text": "Then I hope that I also will become alive again after death."
    },
    {
      "verse": "12",
      "text": "I am not saying that I have already reached that place in my life. I have not yet completely become the person that God wants me to be. But I am trying very hard to reach that place. That was Christ's purpose when he first made me his own."
    },
    {
      "verse": "13",
      "text": "My Christian friends, I do not think that I have reached that place yet. But this is what I do: I do not think about past things that have already happened. Instead, I try hard to reach the things that are in front of me."
    },
    {
      "verse": "14",
      "text": "I am like a runner who wants to reach the end of the race. I run straight towards that place, so that I can win God's gift. Because I belong to Christ Jesus, God has called me to live with him in heaven. That is God's gift to me at the end of the race."
    },
    {
      "verse": "15",
      "text": "All of us should agree to live like that, if we properly understand God's message. If you think differently about these things, God will show you clearly what is right."
    },
    {
      "verse": "16",
      "text": "But we should continue to live in the way that we already know is right."
    },
    {
      "verse": "17",
      "text": "My Christian friends, you should try to live in the way that I do. Carefully watch other people who live like that. We have shown you what is right."
    },
    {
      "verse": "18",
      "text": "Many people live in a way that shows they do not agree with God's message. I have told you about these people many times before. And now I am crying when I tell you about them. I am very sad, because they speak against Christ's death on the cross."
    },
    {
      "verse": "19",
      "text": "In the end, God will destroy them. Their stomach is what they worship. They are proud of things that should make them ashamed. Their thoughts are full of things that belong to this world."
    },
    {
      "verse": "20",
      "text": "But as for us, the home where we belong is in heaven. We are waiting for the Lord Jesus Christ to come from there. He is the one who will come from heaven and save us."
    },
    {
      "verse": "21",
      "text": "He will change these weak bodies that we have now on this earth. He will make them become strong and beautiful, like his own body that he has in heaven. Christ will use his great power to do this. That is the power that he uses to rule over everything."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "My dear Christian friends, I love you very much. I want very much to see you again. You make me very happy. You show that my work among you had good results. Please continue to live in a way that pleases the Lord. This is what I have taught you to do."
    },
    {
      "verse": "2",
      "text": "I say this to Euodia and to Syntyche: ‘You belong to the Lord, so please agree with each other. Stop arguing. ’"
    },
    {
      "verse": "3",
      "text": "I ask you too, my true friend, please help these two women to agree together. They have worked with me to tell people the good news. They have worked very hard to help me. They worked together with Clement, and with the other people who helped me in the work. All those workers' names are written in God's book of life."
    },
    {
      "verse": "4",
      "text": "Always be happy because you belong to the Lord. I will say that again, ‘Be happy! ’"
    },
    {
      "verse": "5",
      "text": "Be kind and patient in a way that everyone can see. Remember that the Lord is near."
    },
    {
      "verse": "6",
      "text": "Do not worry about anything. Instead, pray to God about everything. Ask him to help you with the things that you need. And thank him for his help."
    },
    {
      "verse": "7",
      "text": "If you do that, God will give you peace in your minds. That peace is so great that nobody can completely understand it. You will not worry or be afraid, because you belong to Christ Jesus."
    },
    {
      "verse": "8",
      "text": "Now my friends, I want to say this to you. Fill your minds with thoughts about good things. Think about things that are true, clean, right and lovely. Always think about things which people know are very good."
    },
    {
      "verse": "9",
      "text": "Remember what I have taught you. Remember the message that you heard from me. Remember what you saw when I lived among you. You also must do those same things. God is the one who gives us peace in our minds. He will be with you."
    },
    {
      "verse": "10",
      "text": "I am very happy that you want to help me again. I praise the Lord for that. I know that you wanted to help me before. But you have not had a chance to do anything until now."
    },
    {
      "verse": "11",
      "text": "When I say that, it is not because I need anything. I have learned to be happy, whatever things may happen to me."
    },
    {
      "verse": "12",
      "text": "I know what it is like to need things. I also know what it is like to have more than enough. I have learned this secret. I know how to be happy whatever happens. I can be happy when I have enough food to eat, and also when I am hungry. I can be happy when I have plenty of things, and also when I have nothing."
    },
    {
      "verse": "13",
      "text": "I can do all these things because Christ makes me strong."
    },
    {
      "verse": "14",
      "text": "But certainly, you have been very kind to me. You have helped me now, when I am in trouble."
    },
    {
      "verse": "15",
      "text": "Also, you Christians in Philippi know that you already helped me earlier. That was the time when I started to tell people God's good news. When I left Macedonia, you were the only group of Christians who helped me. We were able to help one another, and no other group of Christians did that for me."
    },
    {
      "verse": "16",
      "text": "Even when I was at Thessalonica, you helped me. More than once, you sent gifts to me because I needed things."
    },
    {
      "verse": "17",
      "text": "It is not your gifts themselves that I want. But I want you to do good things so that God will bless you in return."
    },
    {
      "verse": "18",
      "text": "Epaphroditus has brought the gifts that you sent to me. I have received those gifts, so that I no longer need anything. You have sent me more than enough. Your gifts are like a sacrifice with a nice smell that you have offered to God. God accepts that kind of sacrifice. It makes him very happy."
    },
    {
      "verse": "19",
      "text": "My Lord God in heaven has plenty of good and valuable things. Because you belong to Christ Jesus, God will give to you everything that you need."
    },
    {
      "verse": "20",
      "text": "Our Father God is very great! It is right that everyone should praise him always and for ever! Amen. This is true."
    },
    {
      "verse": "21",
      "text": "Say ‘hello’ on my behalf to all of God's people there who belong to Christ Jesus. The believers who are here with me say ‘hello’ to you."
    },
    {
      "verse": "22",
      "text": "All God's people here say ‘hello’ to you. The Christians who live in the king's house say a special ‘hello’ to you."
    },
    {
      "verse": "23",
      "text": "We pray that the Lord Jesus Christ will continue to be kind to you, so that your spirits are strong."
    }
  ]
};