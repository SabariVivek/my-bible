module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter is from me, James. I am a servant of God and the Lord Jesus Christ. I am writing to the 12 tribes of God's people who live in many different parts of the world. I say ‘hello’ to all of you. tribes of God's people who live in many different parts of the world. I say ‘hello’ to all of you."
    },
    {
      "verse": "2",
      "text": "My Christian friends, remember to be happy, even when many kinds of trouble happen to you. Troubles can help you."
    },
    {
      "verse": "3",
      "text": "God wants to see if you really trust him. Your faith in God will become stronger as a result of these troubles."
    },
    {
      "verse": "4",
      "text": "So you should continue to trust God all the time. Then you will become stronger as a believer. You will become completely how you should be. You will not need anything more."
    },
    {
      "verse": "5",
      "text": "But maybe you need to know how to be wise. Then ask God to help you. He is ready to give everyone what they need. And he never says that it is wrong to ask. So God will help you to be wise."
    },
    {
      "verse": "6",
      "text": "But when you ask God for something, you must trust him completely. Do not have other ideas in your mind. People who are not sure that God will help them are like the waves in the sea. The wind blows the water one way and then it blows the water another way."
    },
    {
      "verse": "9",
      "text": "The believers in your group who are poor should be happy. Why? Because God says that they are valuable to him."
    },
    {
      "verse": "10",
      "text": "And the believers who are rich should also be happy. Why? Because God has shown them that they are not so great. Rich people should remember that they will die, like a wild flower quickly dies."
    },
    {
      "verse": "11",
      "text": "When the sun rises, its heat causes plants to become dry. Their flowers fall to the ground. They are no longer beautiful. In the same way, rich people will die when they are busy in their work. Then they will have nothing."
    },
    {
      "verse": "12",
      "text": "Some people continue to trust God even when troubles happen. God will bless those people, if they show that they really trust him. He will give them the gift which is life with him. He has promised to give this gift to all people who love him."
    },
    {
      "verse": "13",
      "text": "When troubles happen to you, you may want to do something bad. But do not say, ‘God is causing me to do wrong things. ’ Nothing can make God do anything bad. And God does not try to make anyone do a wrong thing."
    },
    {
      "verse": "14",
      "text": "It is our own thoughts that make us do bad things. When we want to do something wrong, our thoughts lead us in a bad way."
    },
    {
      "verse": "15",
      "text": "We may agree to do what our bad thoughts tell us to do. When we do that, it becomes a sin. Then, we may not stop doing those bad things. If we continue to live like that, the result of our sins is death."
    },
    {
      "verse": "16",
      "text": "My Christian friends, do not make a mistake."
    },
    {
      "verse": "17",
      "text": "Remember that every good gift comes to us from God. He only does what will help us. He is our Father in heaven. He made everything in the sky that gives us light. Those things do not give us the same light all the time. They change, but God does not change."
    },
    {
      "verse": "18",
      "text": "He chose to make us his children. He used his true message to do that. Because of that, we are like the first special gift that belongs to him from among everything that he has made."
    },
    {
      "verse": "19",
      "text": "Understand this, my Christian friends: We must all be careful to listen. We should not be too quick to speak. We should not get angry quickly."
    },
    {
      "verse": "20",
      "text": "God wants us to do what is right. But when someone is angry, they do not do those right things."
    },
    {
      "verse": "21",
      "text": "So stop doing disgusting things. Stay away from the wicked things that are all around you. God has put his message deep inside you, and it can save you. So be careful to accept that message."
    },
    {
      "verse": "22",
      "text": "But be careful to do what God says in his message. Do not only listen to it. Do not make that mistake!"
    },
    {
      "verse": "23",
      "text": "You must obey God's message. Do not be like a man who quickly looks at his face in a mirror."
    },
    {
      "verse": "24",
      "text": "That man looks at himself, but then he goes away. He immediately forgets what he is really like."
    },
    {
      "verse": "25",
      "text": "So do not just listen to God's message and then forget it. It is a completely good message that makes people free. Look at it carefully and keep it in your mind. Do what it tells you to do. God will bless anyone who lives in that way."
    },
    {
      "verse": "26",
      "text": "Maybe some of you think that you are serving God well. But if you also say bad things about people, you do not serve God well at all. You are doing something bad even when you think you are doing good things."
    },
    {
      "verse": "27",
      "text": "If you want to serve God in a completely good way, do things like this: Help children who have no parents and women who are widows. Help them in their troubles. If you serve God our Father like that, he will be pleased with you. Do not let the bad people in this world make you bad too."
    },
    {
      "verse": "7",
      "text": "A person who is like that never knows what to do. He has many ideas in his mind."
    },
    {
      "verse": "8",
      "text": "He should not think that he will receive anything from the Lord."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "My Christian friends, you must be kind to everyone. You trust the Lord Jesus Christ, who is great in heaven. So do not think that anyone is more valuable than any other person."
    },
    {
      "verse": "2",
      "text": "When you are meeting together as believers, maybe two men will come to join with you. One of them is wearing beautiful clothes, and he has gold rings on his hands. The other man is poor, and he is wearing old clothes that are dirty."
    },
    {
      "verse": "3",
      "text": "You are kind to the man who is wearing beautiful clothes. You say to him, ‘Please sit here in this good place. ’ But you say to the poor man, ‘Go and stand over there. ’ Or you may say to him, ‘Sit on the floor near my feet. ’"
    },
    {
      "verse": "4",
      "text": "If you do that, you are thinking bad thoughts. You have decided that one person among you is better than another person. You must not do that."
    },
    {
      "verse": "5",
      "text": "My Christian friends, listen to me. God has chosen to bless people who are poor in this world. He has helped them to trust him. So really they are rich. God will give to them a place in his kingdom. He has promised to do that for all people who love him."
    },
    {
      "verse": "6",
      "text": "But you have not been kind to people who are poor. You have caused them to feel ashamed. Who causes you to have troubles? It is the rich people! They are the people who want the judges to punish you."
    },
    {
      "verse": "7",
      "text": "It is the rich people who say bad things against the good name of Jesus Christ. And you are called Christians because you belong to him."
    },
    {
      "verse": "8",
      "text": "But the message of God's kingdom is this: ‘Love other people as much as you love yourself. ’ That is what the Bible says. If you really do that, you do well."
    },
    {
      "verse": "9",
      "text": "But if you are kind to some people and you are not kind to others, then you are doing a bad thing. God's Law shows that you are wrong."
    },
    {
      "verse": "10",
      "text": "Even if you fail to obey only one rule in God's Law, it means that you are guilty. It is the same as if you fail to obey all God's Law."
    },
    {
      "verse": "11",
      "text": "For example, God has said in his Law, ‘You must not have sex with anyone who is not your husband or your wife. ’ But God has also said, ‘Do not kill another person. ’ Perhaps you do not have sex in a wrong way like that. But if you then murder someone, God's Law shows that you are still wrong."
    },
    {
      "verse": "12",
      "text": "Remember that God will judge you one day. When he does that, he will use a law which makes us free. So remember this in everything that you say and in everything that you do."
    },
    {
      "verse": "13",
      "text": "God will not forgive anyone who has not forgiven other people. But God is kind! He judges us, but even more than that, he forgives us!"
    },
    {
      "verse": "14",
      "text": "My Christian brothers, you say that you believe in God. Then you must show this in the things that you do. If not, your faith will not help you. It will not save you."
    },
    {
      "verse": "15",
      "text": "For example, maybe a believer does not have enough clothes to wear or enough food to eat."
    },
    {
      "verse": "16",
      "text": "Then one of you may say to them, ‘Go with God's peace! I pray that you will be warm. I pray that you will eat well. ’ But if you do not give to them what they need, that does not help them at all."
    },
    {
      "verse": "17",
      "text": "How we believe in God is also like that. If our faith does not lead us to do good things, then it is not worth anything. It is dead!"
    },
    {
      "verse": "18",
      "text": "Someone may say, ‘You believe in God, but I do good things to help people. ’ Then I would say, ‘You cannot show me that you believe in God if you do not do good things. I do good things, and that shows that I really believe in God. ’"
    },
    {
      "verse": "19",
      "text": "You believe that there is only one God. That is good! But even the demons believe that! And it makes them very afraid."
    },
    {
      "verse": "20",
      "text": "You fool! If someone's faith does not lead them to do good things, it is not worth anything. You should know that!"
    },
    {
      "verse": "21",
      "text": "Think about our ancestor Abraham. He offered his son Isaac on the altar as a gift to God. Because he did that good thing, God accepted him as right with himself."
    },
    {
      "verse": "22",
      "text": "Abraham believed in God, and he did what God asked him to do. So you can see that both of these were necessary. When he did this good thing, he showed that he believed in God completely."
    },
    {
      "verse": "23",
      "text": "The Bible tells us what happened. It says, ‘Abraham believed God. As a result, God accepted Abraham as right with him. ’ God also called Abraham his friend."
    },
    {
      "verse": "24",
      "text": "So you see how God accepts someone as right with himself. That person must not only believe in God. He must also do good things to show that he has faith."
    },
    {
      "verse": "25",
      "text": "It was the same with Rahab, long ago. She was a prostitute. She helped some of God's people who came to her house. She kept them safe from their enemies and she sent them away again by a different road. Because she did those good things, God accepted her as right with himself."
    },
    {
      "verse": "26",
      "text": "If our bodies have no spirit, they are dead. In the same way, if our faith does not lead us to do good things, it is dead."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "My Christian friends, not many of you should become teachers. We people who teach God's message must be very careful. When God judges everybody, he will demand more from us than from other people."
    },
    {
      "verse": "2",
      "text": "We all make many mistakes. So, if someone never says anything that is bad, that person is completely good. It shows that he has authority over his whole body."
    },
    {
      "verse": "3",
      "text": "For example, think about how we make a horse go the right way. We put a small bit of metal in its mouth so that we can turn it. Then we can cause the horse's whole body to go where we want it to go."
    },
    {
      "verse": "4",
      "text": "Also, think about ships that sail on the sea. They are very large. Strong winds push them with great power. But we fix a piece of wood at the back of the ship. With this small piece of wood, the master can cause the ship to go anywhere that he wants it to go."
    },
    {
      "verse": "5",
      "text": "In the same way, our tongue is a very small part of our body. But it speaks as if it is very great. Think about this. A very small fire can cause even a big forest to burn completely."
    },
    {
      "verse": "6",
      "text": "A person's tongue is like a fire. It has the power of everything in the world that is wrong. It is a small part of the body but it can spoil the whole person. Like a fire, it can destroy all of a person's life. It is a fire that comes from the fire of hell itself."
    },
    {
      "verse": "7",
      "text": "Remember this: People can cause all kinds of things to do what they want them to do. They have done this with wild animals, birds, snakes and things that live in the sea."
    },
    {
      "verse": "8",
      "text": "But no person can rule his tongue. It continues to say bad things. It is like a bad poison that can cause death."
    },
    {
      "verse": "9",
      "text": "We use our tongue to praise the Lord God who is our Father. But then we use it to curse other people. That is wrong, because God made those people to be like himself."
    },
    {
      "verse": "10",
      "text": "This shows that we use the same mouth to praise and also to curse. My Christian friends, we should not do this."
    },
    {
      "verse": "11",
      "text": "Salty water and sweet water never come from the same spring."
    },
    {
      "verse": "12",
      "text": "A fig tree cannot give olives, my friends. A vine for grapes cannot give figs. And a salty spring cannot give sweet water."
    },
    {
      "verse": "13",
      "text": "Do some of you think that you are wise? Do you think that you are clever? If so, show that you are wise by the way that you live. Be kind to other people. Do things that are good. That is what it means to be wise."
    },
    {
      "verse": "14",
      "text": "But if you live in a bad way, do not think that you are wise. Are you jealous of other people so that you hate them? Do you want to make yourself important? If you live like that, do not say that you are great and wise. You are not saying what is true."
    },
    {
      "verse": "15",
      "text": "You are not being wise in the way that God wants you to be wise. Instead, you are thinking like people who do not know God. Your thoughts do not come from God's Spirit. They come from demons."
    },
    {
      "verse": "16",
      "text": "If you are jealous of other people and you want to make yourself important, that will cause trouble. People will argue and fight against one another. They will do all kinds of bad things."
    },
    {
      "verse": "17",
      "text": "But if God makes you really wise, you will live in a completely good way. That is the most important thing. Also, you will live in a way that brings peace. You will be kind to other people so that they become your friends. You will listen to them and not argue. You will forgive them and do many good things to help them. You will not choose between people. And you will not be a hypocrite."
    },
    {
      "verse": "18",
      "text": "Those who bring peace to other people help them to live together in peace. As a result, people choose to do what is right and good."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "You fight and quarrel among yourselves. Do you know why that happens? It is because of the troubles in your thoughts. You want to do bad things that you think will make you happy."
    },
    {
      "verse": "2",
      "text": "You want to have something for yourself, but you do not get what you want. You even kill other people. You try to take things that are not yours. But you cannot get them. So you fight and you quarrel with each other. But you do not have these things because you do not ask God for them."
    },
    {
      "verse": "3",
      "text": "Even when you do ask God, you do not receive anything. That is because you ask for the wrong reason. You just want to use these things to make yourselves happy."
    },
    {
      "verse": "4",
      "text": "You are turning away from God, like a woman who is not faithful to her husband. You choose to be friends with people who are against God. So you yourselves become enemies of God. You should know that!"
    },
    {
      "verse": "5",
      "text": "The Bible says, ‘God has caused his Spirit to live in us. He wants very much to keep us for himself. ’ Do you think that is not true?"
    },
    {
      "verse": "6",
      "text": "But God will be very kind to us and he will help us. That is why the Bible says, ‘God is against those people who think that they are important. But he is kind to people who do not feel important. ’"
    },
    {
      "verse": "7",
      "text": "So obey God's authority. Be strong against the Devil and he will run away from you."
    },
    {
      "verse": "8",
      "text": "Come near to God and he will come near to you. Be clean in the way that you live. Stop doing wrong things. Make your minds clean. You cannot love sin and love God at the same time."
    },
    {
      "verse": "9",
      "text": "Be sorry about your sins and weep. Stop laughing and instead be sad. Do not be happy but be very upset."
    },
    {
      "verse": "10",
      "text": "Be humble in front of the Lord God. Then he will lift you up to a good place."
    },
    {
      "verse": "11",
      "text": "My Christian friends, do not say bad things against each other. If you speak against another believer, you are really speaking against God's Law. If you judge another believer, then you are judging the law too. When you do that, you are not obeying the Law. You are giving yourself authority to decide what the Law says."
    },
    {
      "verse": "12",
      "text": "God is the one who gave his Law to people. Only he has the authority to judge whether people have done what is right. Only he can decide to save people or to destroy them. So you must not judge your friends. You do not have that authority."
    },
    {
      "verse": "13",
      "text": "Some of you say, ‘Today or tomorrow we will go to a certain city. We will stay there for a year. We will buy and sell things, and we will become rich. ’ If you say things like that, listen to me."
    },
    {
      "verse": "14",
      "text": "You do not know what will happen tomorrow. Your life is like a cloud which appears for a short time and then it quickly goes away."
    },
    {
      "verse": "15",
      "text": "So what you ought to say is, ‘If the Lord agrees and we are still alive, then we will do this or that. ’"
    },
    {
      "verse": "16",
      "text": "But instead, you talk about what you have decided to do. You speak as if you have the power to make it happen. It is wrong to speak like that."
    },
    {
      "verse": "17",
      "text": "So you know the right thing that you ought to do. But if you know that and you do not do the right thing, then you have done a wrong thing."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Now, listen to me, you rich people. Weep and cry aloud, because many troubles will soon happen to you."
    },
    {
      "verse": "2",
      "text": "Your money no longer has any value. Insects have eaten your beautiful clothes and they have spoiled them."
    },
    {
      "verse": "3",
      "text": "You have stored silver and gold coins to spend for yourselves. But dirt has spoiled those coins. That dirt will show that you are guilty. It will become like fire that is burning your bodies. In the last days of this world you have stored all this money for yourselves."
    },
    {
      "verse": "4",
      "text": "But you have not paid the workers in your fields the money that you should have paid them. You have cheated them. Now they are shouting against you. The Lord of great power has heard them when they cry to him for help."
    },
    {
      "verse": "5",
      "text": "During your life here on this earth, you have had all that you wanted. You have lived like kings. You have eaten as much food as you want. So now you are like fat animals that are ready for men to kill."
    },
    {
      "verse": "6",
      "text": "You say that a righteous person is guilty. You have even killed him and he could not stop you."
    },
    {
      "verse": "7",
      "text": "So, my Christian friends, be patient until the Lord Jesus returns. Think about how a farmer is patient. He waits for the ground to give him valuable food to eat. He waits patiently for the rain to come in the autumn and in the spring."
    },
    {
      "verse": "8",
      "text": "You also must be patient, because the Lord will return soon. Be strong as you continue to trust him."
    },
    {
      "verse": "9",
      "text": "My Christian friends, do not complain against each other. If you do, God will punish you. So be careful! He is the Judge and he is ready now to judge people."
    },
    {
      "verse": "10",
      "text": "Think about how God's prophets were also patient. They spoke messages on behalf of the Lord. Many troubles happened to them but they were patient. So, my Christian friends, you should copy their example."
    },
    {
      "verse": "11",
      "text": "We know that God blessed people who were like that. They continued to trust God when trouble happened to them. You have heard about Job. He waited patiently for God to help him in his troubles. You know how the Lord helped him in the end. Because of that, we see that the Lord God is very kind and he helps us."
    },
    {
      "verse": "12",
      "text": "Here is another important thing to remember, my Christian friends. When you want to make a strong promise, never use extra words. Do not say, ‘I promise by heaven, ’ or ‘I promise by the earth. ’ Do not use any extra words like that. When you say ‘yes, ’ that should be enough. When you say ‘no, ’ that should also be enough. If you say more than that, God will say that you are guilty."
    },
    {
      "verse": "13",
      "text": "Is anyone among you in trouble? Then they should pray to God about it. Or, is anyone feeling happy? They should praise God with songs."
    },
    {
      "verse": "14",
      "text": "Is anyone ill? They should ask the leaders of the church to come and to pray for them. The leaders should put some olive oil on the sick person. They should pray for him with the authority of the Lord Jesus."
    },
    {
      "verse": "15",
      "text": "If they pray in that way and they trust that God will answer them, the sick person will become well again. The Lord will cause him to become well. And God will forgive him if he has done any wrong things."
    },
    {
      "verse": "16",
      "text": "So you should tell each other about any wrong things that you have done. Then you will be able to pray for each other, so that God makes you well again. When a good person prays to God, God does powerful things."
    },
    {
      "verse": "17",
      "text": "For example, God's prophet Elijah was an ordinary person, as we are. He prayed to God that it would not rain. He continued to pray and it did not rain on the land for three years and six months."
    },
    {
      "verse": "18",
      "text": "After that time, he prayed to God to send rain again. After that, rain came down from the sky. The seeds that were in the ground began to grow and give food for people to eat."
    },
    {
      "verse": "19",
      "text": "My Christian friends, if anyone among you turns away from God's true message, you should help him. Try to bring him back to God."
    },
    {
      "verse": "20",
      "text": "Understand this: if you turn a person back from their bad ways, you will save them from death. And God will forgive that person for his many sins."
    }
  ]
};