module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter is from me, Paul. I am an apostle of Christ Jesus. God, our Saviour, is the one who commanded that I should be an apostle. So did Christ Jesus, the one that we trust to help us."
    },
    {
      "verse": "2",
      "text": "I am writing to you, Timothy. I told you the message about Jesus and you believed in him. So you are like my own child. I pray that God the Father and Christ Jesus our Lord will continue to help you and be kind to you. I pray that they will give you peace in your mind. I pray that God the Father and Christ Jesus our Lord will continue to help you and be kind to you. I pray that they will give you peace in your mind."
    },
    {
      "verse": "3",
      "text": "When I was going to Macedonia, I asked you to stay in Ephesus. Please continue to stay there. Certain people in Ephesus are teaching wrong things about God. You must tell them to stop doing that."
    },
    {
      "verse": "4",
      "text": "Tell people not to listen to false stories. They should not always be studying long lists of their families' names from years ago. Those things do not help people. They only cause them to argue. Instead, they need to understand God's purpose for us. To do that, people must trust him."
    },
    {
      "verse": "5",
      "text": "We need to teach people to love one another with pure thoughts. They need to be sure in their minds that they are living in a good way. They need to trust God completely."
    },
    {
      "verse": "6",
      "text": "But certain people have failed to live in that way. They would rather talk about things that do not help anyone."
    },
    {
      "verse": "7",
      "text": "They want to be teachers of God's laws. They speak very strongly, but they do not really understand what they are talking about."
    },
    {
      "verse": "8",
      "text": "We know that God's laws are good, if people use them properly."
    },
    {
      "verse": "9",
      "text": "We also know that God did not make those laws for people who already live in a good way. He made them for people like this, to show them what is right: people who refuse to obey any laws; people who do not want anyone to rule them; people who turn away from God; people who do bad things; people who do not respect God's holy things; people who kill their father or their mother; people who murder;"
    },
    {
      "verse": "10",
      "text": "people who have sex in a wrong way; men who have sex with other men; people who catch other people to sell them; people who tell lies; people who do not speak the truth in court; people who do any wrong things that are against God's true message."
    },
    {
      "verse": "11",
      "text": "That true message is the good news that comes from our great God. We praise him for it. He has chosen me to tell this good news to people."
    },
    {
      "verse": "12",
      "text": "I thank Christ Jesus our Lord, who has made me strong to serve him. He decided to trust me and he chose me to work on his behalf."
    },
    {
      "verse": "13",
      "text": "Before he chose me, I said bad things about him. I caused great trouble for his people. I was a cruel man, but God was very kind to me. He forgave me because I did not know what I was doing. That was because I did not believe in Jesus."
    },
    {
      "verse": "14",
      "text": "Our Lord continued to be very good and kind to me. He caused me to believe in Christ Jesus and to love him."
    },
    {
      "verse": "15",
      "text": "Here is a true message that everyone should believe: ‘Christ Jesus came into the world to save people who do wrong things. ’ I am the worst person like that!"
    },
    {
      "verse": "16",
      "text": "But God was kind to me. Christ Jesus showed that he was completely patient with me, the worst person. That was an example to those people who would later believe in him. They would believe and receive life for ever with God."
    },
    {
      "verse": "17",
      "text": "Praise God, the King who rules for ever! He can never die. He lives where we cannot see him. He is the only God. So praise him and say how great he is! That is true always and for ever! Amen! This is true."
    },
    {
      "verse": "18",
      "text": "Timothy, you are like my own child. So now I am telling you to serve God well. Remember the words from God that people spoke about you, when you became a servant of God. Those words will help you to be strong, like a soldier who fights well."
    },
    {
      "verse": "19",
      "text": "You must continue to trust God. Always do what you know to be right. Some people have refused to do what is right, even when they know what they should do. As a result, they no longer believe God's true message."
    },
    {
      "verse": "20",
      "text": "Hymenaeus and Alexander are people like that. I have given them to Satan so that he may punish them. Then they will learn not to say bad things against God any more."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "So then, this is what I want to ask you first. Please pray for all people. Ask God to supply what they need. Ask God to help them. Thank God for what he does for everyone."
    },
    {
      "verse": "2",
      "text": "Pray in that way for kings and for all rulers and people who have authority. Pray for God to help them, so that we may live our lives without trouble or danger. Then we can live in a good way that respects God and other people."
    },
    {
      "verse": "3",
      "text": "It is good that we should pray like that. It makes God, our Saviour, happy."
    },
    {
      "verse": "4",
      "text": "He wants to save all people. He wants everyone to know his message about what is true."
    },
    {
      "verse": "5",
      "text": "There is only one God. There is also only one person who brings God and people together. That person is Christ Jesus, who became a man himself."
    },
    {
      "verse": "6",
      "text": "He died as a sacrifice on behalf of all people, to pay the debt of their sins. He died at the proper time for God to show his purpose clearly."
    },
    {
      "verse": "7",
      "text": "God chose me as his apostle, to tell this same message to people. I am telling you what is true. I am not telling lies! Yes, he sent me to teach his true message to the Gentiles, so that they would believe in him."
    },
    {
      "verse": "8",
      "text": "So then, in every place where you meet together, I want the men to pray. The men who lift up their hands and pray must be those who live good lives. They must not be people who are angry or who quarrel with others."
    },
    {
      "verse": "9",
      "text": "I also want the women to dress themselves properly in a way that is right. They should not bring shame on themselves. What makes a woman beautiful? It is not the special way that she prepares her hair. It is not the gold things or jewels that she wears. It is not her expensive clothes."
    },
    {
      "verse": "10",
      "text": "Christian women should not dress themselves like that. Instead, their lives should show that they do good things. They say that they want to please God, so that is the proper way for them to live."
    },
    {
      "verse": "11",
      "text": "When you meet together, a woman should learn quietly. She must respect the leaders who teach in the church."
    },
    {
      "verse": "12",
      "text": "I do not let a woman teach men. I do not let a woman have authority over men. Instead, she should listen quietly."
    },
    {
      "verse": "13",
      "text": "I say this because God made Adam first. Then he made Eve."
    },
    {
      "verse": "14",
      "text": "It was Eve, not Adam, who believed the lies that Satan told her. Because she believed Satan completely, she did what God had said was wrong."
    },
    {
      "verse": "15",
      "text": "But even as women give birth to children, God will save them. They must continue to trust God and to love other people. They must live in a way that shows they belong to God. They must think carefully about how they live. Then God will save them."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "These words are true: ‘If you want to become a leader of God's people, it is an important work that you want to do. ’"
    },
    {
      "verse": "2",
      "text": "For that reason, a leader of the church must live a life that everyone knows is good. He must be the husband of one wife. He must think seriously about how he lives and he must control himself well. He must be someone that people respect. He must be happy to have visitors in his home. He must be a good teacher."
    },
    {
      "verse": "3",
      "text": "He should not drink too much wine. He must not get angry quickly or quarrel with people. Instead he should be kind to people. He must not want lots of money."
    },
    {
      "verse": "4",
      "text": "He must take care of his own family. His children must obey him and respect him."
    },
    {
      "verse": "5",
      "text": "A man must know how to take care of his own family. If he cannot do that, he will not be able to take care of God's people in the church."
    },
    {
      "verse": "6",
      "text": "A leader of the church must not be someone who has believed in Christ for only a short time. Someone like that might boast that he is great and important. Then he would receive punishment, as the Devil did."
    },
    {
      "verse": "7",
      "text": "Also, people outside the church should agree that the leader is a good person. Then nobody can say anything bad against him. And so, he will not come under the Devil's power."
    },
    {
      "verse": "8",
      "text": "In the same way, deacons must live good lives, so that people respect them. They must not be hypocrites. They must not drink too much wine. They must not want to get a lot of money for themselves."
    },
    {
      "verse": "9",
      "text": "They must completely believe the true message that God has shown us about Christ. They must be sure in their minds about it."
    },
    {
      "verse": "10",
      "text": "Before anyone becomes a deacon, you must first test their character. If they are good enough, then let them serve God as deacons."
    },
    {
      "verse": "11",
      "text": "Deacons' wives must live good lives, so that people respect them. They must not say bad things against people. They must think carefully about how they live. People should know that they are honest in everything they do."
    },
    {
      "verse": "12",
      "text": "A deacon must be the husband of one wife. He must take care of his children and everyone who lives in his house."
    },
    {
      "verse": "13",
      "text": "If a deacon serves God's people well, then people will respect him as a good person. He will become strong to tell people about his faith in Christ Jesus."
    },
    {
      "verse": "14",
      "text": "I hope to come to visit you soon. But anyway, I want to write these things to you now."
    },
    {
      "verse": "15",
      "text": "Then, even if I cannot come to you soon, you will know how people in God's family should live. That family is the church of God, who lives for ever. God's family, the church, teaches God's true message and keeps it safe."
    },
    {
      "verse": "16",
      "text": "Yes, the message that God has shown us about Jesus Christ is very great. We all agree to this: God showed him to us as a man. God's Spirit showed that he always did what was right. Angels saw him. People taught his message in many countries of the world. People in the world believed in him. God took him up to be with himself in heaven."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "God's Spirit tells us clearly that, in later times, some people will stop believing the message about Jesus Christ. Instead, they will listen to bad spirits who want people to believe wrong things. They will listen to the message that comes from demons."
    },
    {
      "verse": "2",
      "text": "The people who teach those false things are hypocrites. They no longer understand that what they teach is wrong."
    },
    {
      "verse": "3",
      "text": "They say that it is wrong for anyone to marry. They tell people not to eat certain kinds of food. But God made those foods for people to eat! We should understand God's true message and trust him. Then we will receive the food that he has given us and we will thank him for it."
    },
    {
      "verse": "4",
      "text": "Everything that God has made is good. So we should not refuse anything that he has made. Instead, we should receive it and thank God for it."
    },
    {
      "verse": "5",
      "text": "God has said that it is good. We should pray that he will bless it. Because of that, it becomes good and clean for us to eat."
    },
    {
      "verse": "6",
      "text": "You must explain these things to the believers and teach them God's true message. If you do that, you will be a good servant of Christ Jesus. Continue to study the message about Jesus that you have already learned. That will help you to be strong."
    },
    {
      "verse": "7",
      "text": "But you must refuse to listen to false stories. Stories like that are not from God and only silly people believe them. Instead, learn to live well in a way that makes God happy."
    },
    {
      "verse": "8",
      "text": "People say this: ‘If a person works to make his body strong and healthy, that will help him a little. But if a person works to live in a way that makes God happy, that will help him much more. It will help that person in his life now on earth. It will also help him in his future life with God in heaven. ’"
    },
    {
      "verse": "9",
      "text": "We know that those words are true. Everyone should agree with them."
    },
    {
      "verse": "10",
      "text": "So that is why we work to serve God well. We continue to work, even when we have trouble. We do this because we believe that God will help us. He is the one who lives for ever and who saves all people. Certainly, he saves those who are believers."
    },
    {
      "verse": "11",
      "text": "Teach people to do these things."
    },
    {
      "verse": "12",
      "text": "You are still a young man, but everyone should respect you as the leader in the church. Show the believers how they should live. Be a good example to them in these ways: what you say, what you do, how you love people, how you trust God, and how you do only what is right."
    },
    {
      "verse": "13",
      "text": "Until I come, be careful to read the Bible aloud to people. Teach them to understand and to obey the message about Christ."
    },
    {
      "verse": "14",
      "text": "Remember the gift that God's Holy Spirit has given to you. You received that gift when the group of church leaders put their hands on you. They spoke messages from God about how you would serve him. So do not stop using that gift from God."
    },
    {
      "verse": "15",
      "text": "Be careful to do all these things well. Then everyone will see that you are serving God better and better."
    },
    {
      "verse": "16",
      "text": "Think carefully about how you live, and about the message that you teach. Continue to teach God's true message. Then God will save not only you, but also those people who listen to you."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Do not speak strongly to an older man and tell him what he must do. Instead, ask him in a kind way, as you would speak to your father. Speak to younger men as you would speak to your brothers."
    },
    {
      "verse": "2",
      "text": "Speak to older women as you would speak to your mother. Speak to younger women as you would speak to your sisters. Always respect them properly."
    },
    {
      "verse": "3",
      "text": "Respect those widows in the church who are really alone."
    },
    {
      "verse": "4",
      "text": "If a widow has children or grandchildren, then they should take care of her. The children must help their parents or grandparents because they belong to the same family. Their parents helped them, so they need to give them something in return. The children need to learn that important lesson. It is what God's message teaches them to do and it makes God happy."
    },
    {
      "verse": "5",
      "text": "Some widows are really alone and they have nobody to take care of them. A widow like that trusts God that he will help her. As a result, she prays a lot, at night and during the day, and she asks God to help her."
    },
    {
      "verse": "6",
      "text": "But some widows only want to enjoy themselves. For a widow like that, her spirit is already dead, even while she is still alive."
    },
    {
      "verse": "7",
      "text": "Teach everyone clearly to do these things. Then nobody can say that the believers are doing anything wrong."
    },
    {
      "verse": "8",
      "text": "Every believer must take care of his own family. Certainly, he must do that for the people who live with him in his home. If anyone does not do that, it shows that he has refused God's true message. That person is worse than someone who does not believe in Christ."
    },
    {
      "verse": "9",
      "text": "If you want to put a widow's name on the list of widows, this is what she must be like. She must be more than 60 years old. She must have been the wife of one husband."
    },
    {
      "verse": "10",
      "text": "People should know that she has done good things. For example, she must have been a good mother to her children. She must have received visitors into her home. She must have helped God's people as their servant. She must have taken care of people who had problems. She must have continued to do all kinds of good things like that."
    },
    {
      "verse": "11",
      "text": "But do not put the names of younger widows on the list. They may decide to marry again, because they strongly want to have sex. Then they will no longer choose to serve Christ."
    },
    {
      "verse": "12",
      "text": "As a result, they will stop doing what they had earlier promised to do for the church. That will make them guilty."
    },
    {
      "verse": "13",
      "text": "Young widows may learn to be lazy. They may go around from house to house. Not only do they become lazy, but they talk too much about silly things. They talk wrongly about other people and what they are doing. They say things that they ought not to say."
    },
    {
      "verse": "14",
      "text": "So I think that widows who are still young women should marry again. Then they can have children and they can take care of their own homes. If they live well like that, the enemy of God's people will not have a chance to say bad things against us."
    },
    {
      "verse": "15",
      "text": "Some of the younger widows have already turned away from Christ, so that they can obey Satan."
    },
    {
      "verse": "16",
      "text": "A woman who believes in Christ should take care of any widows in her own family. Then the church will not have to do that work. Instead, the church will be able to help those widows who are really alone."
    },
    {
      "verse": "17",
      "text": "Everyone should respect leaders of the believers who lead the church well. The church should also pay them properly for their work. That is certainly true for leaders who teach God's people and speak God's message to them."
    },
    {
      "verse": "18",
      "text": "The Bible says: ‘Do not tie shut the mouth of a bull while it walks on your wheat seeds. ’ The Bible also says: ‘You must pay a worker what his work is worth. ’"
    },
    {
      "verse": "19",
      "text": "Somebody may tell you that a leader of the believers has done something wrong. But do not accept that as true, unless two or three people say the same thing."
    },
    {
      "verse": "20",
      "text": "If a leader is really guilty and continues to do wrong things, you must warn him. Do that when everyone in the church is there. They will hear what you say, and they will be afraid to do wrong things themselves."
    },
    {
      "verse": "21",
      "text": "I say this to you very strongly: Obey what I am telling you to do. Remember that God himself and Christ Jesus, together with their special angels, are all watching what you do. Do not quickly decide if someone has done right or wrong. Be fair and judge everyone in the same way."
    },
    {
      "verse": "22",
      "text": "Do not hurry to put your hands on anyone to choose him as a leader of the church. Perhaps that man has done something wrong. Then people might think that you agree with his sins. You yourself must always be careful to do what is right and good."
    },
    {
      "verse": "23",
      "text": "I know that you often become ill. So do not drink only water, but drink a little wine. This will help your stomach to keep well."
    },
    {
      "verse": "24",
      "text": "Some people do wrong things that everyone can see clearly. When someone judges those people, everyone already knows that they are guilty. So everybody already knows that it is right to punish those people. But for other people, nobody knows about their sins until later."
    },
    {
      "verse": "25",
      "text": "It is the same with the good things that people do. Many good things are clear for everyone to see. And even the good things that people do secretly will not remain a secret for ever."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "All slaves should know that it is right to respect their masters. Then other people will not insult God's name or the message that we teach. Teach these things and tell people to obey them."
    },
    {
      "verse": "2",
      "text": "Slaves who have masters who are also believers must continue to respect them. As believers, the slave and his master are like brothers together. But that slave must not refuse to obey his master because of that. Instead, he should work even better for his master. He should do that because he loves his master as a believer. Teach these things and tell people to obey them."
    },
    {
      "verse": "3",
      "text": "Some people teach a false message that is different. Their message does not agree with the true message that our Lord Jesus Christ taught. They do not teach people to live in a way that pleases God."
    },
    {
      "verse": "4",
      "text": "People like that think that they are very clever. But they do not really understand anything. They like to argue about things which are not important. They like to quarrel about words. As a result, people become jealous of one another, and they become angry with each other. They insult other people and they think bad things about them."
    },
    {
      "verse": "5",
      "text": "Their minds have become confused and they argue all the time. They refuse to believe God's true message. They think that they will become rich if they say that they are serving God."
    },
    {
      "verse": "6",
      "text": "What makes our life really rich? We should serve God in a way that pleases him and be happy with the things that we have."
    },
    {
      "verse": "7",
      "text": "When we were born, we brought nothing with us into this world. When we die, we cannot take anything with us out of the world."
    },
    {
      "verse": "8",
      "text": "So, if we have enough food and clothes, we should be happy with that."
    },
    {
      "verse": "9",
      "text": "But some people want to have lots of money. This causes them to do wrong things. They cannot get free from their bad ways, like an animal in a trap. They want many things for themselves. Their foolish thoughts hurt them and finally destroy their lives."
    },
    {
      "verse": "10",
      "text": "When people like to have lots of money, it causes all kinds of bad things to happen. Some people have stopped believing the message about Christ because they want to get more money. As a result, they have caused themselves to become sad with many troubles."
    },
    {
      "verse": "11",
      "text": "But you, Timothy, are a servant of God. So keep away from all bad things like that. Instead, always try to do what is right. Serve God in a way that pleases him. Choose to trust God and to love other people. Continue to be strong when you have trouble. Be kind to people."
    },
    {
      "verse": "12",
      "text": "Continue to believe God's true message. Be like someone who fights well to keep it safe. God has chosen you to live with him for ever. You stood in front of many people and said clearly that you believed in Jesus Christ. So live in a way that shows that you belong to him."
    },
    {
      "verse": "13",
      "text": "Christ Jesus himself spoke God's true message clearly when he stood in front of Pontius Pilate. I now say this to you, in front of God who causes all things to be alive, and in front of Jesus."
    },
    {
      "verse": "14",
      "text": "You must obey the commands that you have received. Obey them completely without any mistake until our Lord Jesus Christ returns."
    },
    {
      "verse": "15",
      "text": "God will cause Christ to appear at the proper time. God is great, and he alone rules with all authority. He is the greatest King and the most powerful Lord."
    },
    {
      "verse": "16",
      "text": "God alone lives for ever. He lives in very bright light that nobody can come near. Nobody has ever seen God. Nobody is able to see him. So we praise him! He will rule for ever with great authority! Amen! This is true."
    },
    {
      "verse": "17",
      "text": "Warn those people who are rich with many things that belong to this world. Tell them not to think that they are more important than other people. They must not think that their money will keep them safe. They could easily lose all of it. Instead, they should trust God. He gives us many things, so that we can enjoy all of them."
    },
    {
      "verse": "18",
      "text": "Tell those rich people to do many good things to help other people. They should be very kind to other people and share their things with them."
    },
    {
      "verse": "19",
      "text": "In that way they will store valuable things for themselves in heaven. These things will be a strong help for them in the future. As a result, they will have true life with God."
    },
    {
      "verse": "20",
      "text": "Timothy, God has given you his true message to tell people. You must keep that message safe. Do not listen to people who say a lot of silly things that are not important to God. Those people think that they have special knowledge. But their ideas are against God's true message. I pray that God will continue to be very kind to all of you."
    },
    {
      "verse": "21",
      "text": "Some people have believed those wrong ideas and now they no longer trust God. I pray that God will continue to be very kind to all of you."
    }
  ]
};