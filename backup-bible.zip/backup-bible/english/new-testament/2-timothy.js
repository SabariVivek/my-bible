module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter is from me, Paul. God chose me to be an apostle of Christ Jesus. God sent me to tell people about the true life that he has promised us. We receive this life when we belong to Christ Jesus."
    },
    {
      "verse": "2",
      "text": "I am writing to you, Timothy. You are like my own child, and I love you very much. I pray that God the Father and Christ Jesus our Lord will continue to help you and be kind to you. I pray that they will give you peace in your mind. I pray that God the Father and Christ Jesus our Lord will continue to help you and be kind to you. I pray that they will give you peace in your mind."
    },
    {
      "verse": "3",
      "text": "Like my ancestors, I serve God in a good way, that I know is right. When I pray to God, at night and during the day, I always remember to pray for you. And I thank God for you."
    },
    {
      "verse": "4",
      "text": "I remember how you wept when I said ‘goodbye’ to you. I want to see you again very much, so that I may be completely happy."
    },
    {
      "verse": "5",
      "text": "I remember how you really believe in Christ. Your grandmother, Lois, and your mother, Eunice, already believed in Christ before you did. Now I am sure that you yourself also really trust him."
    },
    {
      "verse": "6",
      "text": "For that reason, I want you to remember the gift that God gave you when I put my hands on you. Use that gift more and more to serve God well."
    },
    {
      "verse": "7",
      "text": "Be strong, because God has given us his Spirit. And his Spirit does not cause us to be afraid. Instead, his Spirit causes us to be powerful to serve God. He helps us to love God and other people. And he helps us to control ourselves properly."
    },
    {
      "verse": "8",
      "text": "So do not be ashamed of the message about our Lord that we tell people. And do not be ashamed of me because I am in a prison. I am a prisoner because I serve Christ. You must understand that you will have trouble because you tell people the good news about Jesus Christ. So be ready to have the same kind of trouble as I have. Let God make you strong when you have trouble."
    },
    {
      "verse": "9",
      "text": "God is the one who has saved us. He has chosen us to serve him with good, clean lives. He did not save us because of any good things that we have done. He chose to do it because he is very kind. He decided to do that before time began, because of what Christ Jesus would do for us."
    },
    {
      "verse": "10",
      "text": "Now Christ Jesus has come to save us, and we have seen how kind God is. Christ has destroyed death's power over us. We have heard the good news that he brought to us. So now we understand about life with God for ever."
    },
    {
      "verse": "11",
      "text": "That is the same good news that God has chosen me to tell to people. He has sent me as his apostle to teach his message to people."
    },
    {
      "verse": "12",
      "text": "That is why I have these troubles. But I am not ashamed to be in prison. I have believed in Christ and I know him well. I know that I can trust him to keep his message safe. God has given me the authority to speak that message to people at this time. Christ has the power to keep it safe until that great day when he comes back."
    },
    {
      "verse": "13",
      "text": "You have heard me tell you about God's true message. Let those words be an example to you, so that you also teach what is true. Do this because you belong to Christ Jesus. Continue to trust him and to love his people."
    },
    {
      "verse": "14",
      "text": "God has given you his good message to keep safe. God's Holy Spirit, who lives in us, will help you to keep it safe."
    },
    {
      "verse": "15",
      "text": "You know that almost all the believers in Asia region have turned against me. They include Phygelus and Hermogenes."
    },
    {
      "verse": "16",
      "text": "But Onesiphorus has stayed to help me. I pray that the Lord will be kind to his family. He often came to help me not to be sad. I am in prison, but he was not ashamed to help me."
    },
    {
      "verse": "17",
      "text": "When he came here to Rome, he looked carefully for me until he found me."
    },
    {
      "verse": "18",
      "text": "I pray that the Lord will be kind to Onesiphorus on that great day when he judges people. You know very well how much Onesiphorus helped me in Ephesus."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Timothy, you are like my own child. Let God make you strong. He is kind, so trust him to help you, because you belong to Christ Jesus."
    },
    {
      "verse": "2",
      "text": "You have heard the message that I have taught. Many other people also heard it and they agree that it is true. Now you must tell the same message to other people who will be able to teach it to even more people. They should be people that you can trust as honest people and who can teach well."
    },
    {
      "verse": "3",
      "text": "Be patient through the troubles that we Christians have. Be brave and strong, like a good soldier for Christ Jesus."
    },
    {
      "verse": "4",
      "text": "Any soldier who fights in a war does not become busy with other things. He only wants to fight well to make his captain happy."
    },
    {
      "verse": "5",
      "text": "It is the same with an athlete who runs a race. He cannot win the race unless he obeys the rules."
    },
    {
      "verse": "6",
      "text": "A farmer works hard to grow plants for food. So he should be the first person to receive some of that food."
    },
    {
      "verse": "7",
      "text": "Think carefully about what I am saying to you. The Lord will help you to understand all these things."
    },
    {
      "verse": "8",
      "text": "Jesus Christ is a descendant of King David. God caused him to become alive again after his death. Remember that! These facts are part of the good news that I tell people."
    },
    {
      "verse": "9",
      "text": "And I have many troubles because I tell that good news to people. They have even put me in a prison, like someone who has done something bad. But nobody can keep God's message in a prison!"
    },
    {
      "verse": "10",
      "text": "So I continue to be patient and brave during all these troubles. I do that so that I can help the people that God has chosen to belong to him. I want God to save them too, because of what Christ Jesus has done for them. As a result, they will live with God for ever, in the beautiful place where he lives."
    },
    {
      "verse": "11",
      "text": "We all know that this is true:‘If we have died with Christ in this world, we will also live with him in the future world. ‘If we have died with Christ in this world, we will also live with him in the future world."
    },
    {
      "verse": "12",
      "text": "If we continue to be strong during troubles here, we will also rule with him there in heaven. But if we say that we do not know Christ, he will also say that he does not know us. we will also rule with him there in heaven. But if we say that we do not know Christ, he will also say that he does not know us."
    },
    {
      "verse": "13",
      "text": "Even if we no longer trust him, he will still be someone that people can trust. He will always remain true to his nature. ’ he will still be someone that people can trust. He will always remain true to his nature. ’"
    },
    {
      "verse": "14",
      "text": "Continue to tell these things to God's people there, so that they remember them. Use God's authority and warn them not to quarrel about words. To quarrel about little things does not help anyone. Instead, it destroys those people who listen."
    },
    {
      "verse": "15",
      "text": "Always try very much to serve God in a way that makes him happy. Then he will accept you as a good worker that he can trust. You must teach God's true message correctly. Then you will have no reason to be ashamed of your work."
    },
    {
      "verse": "16",
      "text": "But stay away from people who talk about silly things that are not important to God. A message like that causes people to live more and more in a way that does not please God."
    },
    {
      "verse": "17",
      "text": "It causes people to become sick in their spirits. More and more people become sick as a result. Hymenaeus and Philetus are two of the people who teach that kind of false message."
    },
    {
      "verse": "18",
      "text": "They no longer teach God's true message. They say that God will not raise dead people any more, because he has already given life to dead people. In this way they have confused the minds of some people, so that they no longer believe in Christ."
    },
    {
      "verse": "19",
      "text": "But the group of true believers remains strong, like the foundation under a building. God has written his message there. It says, ‘The Lord knows who his own people are. ’ It also says, ‘Everyone who says that he belongs to the Lord must stop doing bad things. ’"
    },
    {
      "verse": "20",
      "text": "In a big house, there are different kinds of dishes. There are some dishes that people have made from gold or from silver. They see those dishes as valuable things. There are also dishes that people have made from wood or from clay. Those dishes are not special things and they may get dirty."
    },
    {
      "verse": "21",
      "text": "It is like that with people who serve God as their Master. People who keep themselves clean from those bad things will be like valuable dishes. Their master can use them for a special purpose. They will be ready for him to use them for every kind of good work."
    },
    {
      "verse": "22",
      "text": "Be careful not to do the kind of bad things that young people often want to do. Instead, always try to do what is right and fair. Continue to trust God. Love other people and live in peace with them. Join with people who are clean inside and who pray to the Lord."
    },
    {
      "verse": "23",
      "text": "Do not join with people who want to argue about silly things that do not mean anything. You know that silly things like that only cause people to quarrel."
    },
    {
      "verse": "24",
      "text": "As the Lord's servant, you must not quarrel. Instead, you must be kind to everyone. You must be able to teach them well. And you must be patient when people cause you to have trouble."
    },
    {
      "verse": "25",
      "text": "When people speak against God's true message, teach them carefully. Help them to understand what is right. Maybe God will change how they think so that they believe the true message."
    },
    {
      "verse": "26",
      "text": "Their minds will start to think clearly. It is the Devil who has made them believe wrong things. He has made them do what he wants. Now they can get free from his power."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "Let me tell you this. During the last days of this world, there will be times of great trouble."
    },
    {
      "verse": "2",
      "text": "People will love only themselves, and they will want lots of money for themselves. They will be proud and they will say how great they are. They will insult other people. They will not obey their parents. They will not thank anyone who helps them. They will not respect anything that is good."
    },
    {
      "verse": "3",
      "text": "They will not be kind to other people, but they will like to quarrel. They will tell lies to hurt other people. They will be unable to control themselves properly. They will be cruel and they will hate anything that is good."
    },
    {
      "verse": "4",
      "text": "People will turn against their friends. They will do foolish things. They will boast that they are very important. They will not love God, but instead they will only want to enjoy themselves."
    },
    {
      "verse": "5",
      "text": "Those people will seem to be serving God. But really they refuse to accept God's power to help them. You must stay away from people like that."
    },
    {
      "verse": "6",
      "text": "Among those people, there are some men who find a way into people's homes. They get power over silly women who feel very guilty about their sins. Those women want to do wrong things and they cannot stop themselves."
    },
    {
      "verse": "7",
      "text": "They are always trying to learn new things, but they can never really understand God's true message."
    },
    {
      "verse": "8",
      "text": "These are people who speak against God's true message, in the same way that Jannes and Jambres spoke against Moses. Their minds have become confused. The way that they serve God is false."
    },
    {
      "verse": "9",
      "text": "But they will not continue to do many more bad things. Everyone will see clearly that they are fools. That is what happened to Jannes and Jambres."
    },
    {
      "verse": "10",
      "text": "But you, Timothy, have heard my message and you know it well. You also know the way in which I have lived. You know my purpose in life. You know how I trust God. You know how patient I have been. You know my love for God and for other people. You know that I have been strong during troubles."
    },
    {
      "verse": "11",
      "text": "You also know what happened to me in the cities called Antioch, Iconium and Lystra. People caused me to have a lot of trouble and pain in those places. But I was patient and brave in those bad troubles! And the Lord kept me safe in all those dangerous times."
    },
    {
      "verse": "12",
      "text": "It is not only me. Every Christian who wants to live in a way that pleases God will have trouble from other people."
    },
    {
      "verse": "13",
      "text": "Bad people like that will become even worse. Some of them will teach a false message and people will believe their lies. Those false teachers even believe their own lies!"
    },
    {
      "verse": "14",
      "text": "But you must continue to believe the things that you have learned. You know that those things are true. You know the teachers who taught you those things."
    },
    {
      "verse": "15",
      "text": "Even when you were a child, you already knew the message of the Bible. The Bible has taught you how you can be truly wise. You understand that God saves you because you believe in Christ Jesus."
    },
    {
      "verse": "16",
      "text": "Everything that is written in the Bible comes from God's Spirit. It helps us in many ways. The Bible teaches us what is true. It warns us when we are doing wrong things. It shows us what is right. It teaches us how to live good lives."
    },
    {
      "verse": "17",
      "text": "As a result, people who want to serve God can know how to live properly. They will be people who are ready to do all kinds of good things."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Timothy, I tell you this seriously, as God and Christ Jesus see everything that we do. When Christ Jesus comes to rule as king, he will judge everyone. He will judge the people who are alive and also those who have already died. When he appears, he will decide what should happen to them all. So I tell you this now:"
    },
    {
      "verse": "2",
      "text": "Tell God's message to people. Always be ready to speak God's message clearly to people, whether they want to listen to you or not. Warn people when they are doing something wrong. Tell them to stop doing wrong things, and explain to them what they ought to do. But be very patient while you teach them what is true."
    },
    {
      "verse": "3",
      "text": "Do this, because a time will come when people will not listen to God's true message. Instead, they will want to hear all kinds of new messages that will make them happy. So they will find many teachers for themselves who will tell them what they want to hear."
    },
    {
      "verse": "4",
      "text": "People will refuse to listen to God's true message. Instead, they will want to listen to silly stories that are false."
    },
    {
      "verse": "5",
      "text": "But you yourself must continue to think seriously and clearly. Be patient and brave when troubles come. Continue to tell the good news about Christ to people. Do all the work that God has given you to do as his servant."
    },
    {
      "verse": "6",
      "text": "As for me, it is nearly time for me to die. My death will be like a drink offering that they pour out to God. My life as God's servant will end."
    },
    {
      "verse": "7",
      "text": "I have worked to serve Christ well. I have finished everything that God wanted me to do. I am like a runner who has run to the end of the race. I have continued to believe God's true message."
    },
    {
      "verse": "8",
      "text": "So now a gift is waiting for me. The Lord will make me completely right with him. That will be like a crown which the Lord will give me on that great day when he judges people. He is the judge who is fair and right. He will not only give that gift to me. He will give it to all those people who love him. They will be happy to see him when he comes again."
    },
    {
      "verse": "9",
      "text": "Timothy, please come to see me as soon as you can."
    },
    {
      "verse": "10",
      "text": "Demas has left me and he has gone to Thessalonica city. He wanted to enjoy the things of this world too much. Crescens has gone to Galatia region. Titus has gone to Dalmatia region."
    },
    {
      "verse": "11",
      "text": "Only Luke is with me now. Bring Mark with you when you come. He can help me very much with the work for God."
    },
    {
      "verse": "12",
      "text": "I have sent Tychicus to Ephesus."
    },
    {
      "verse": "13",
      "text": "I left a coat with Carpus in Troas. Bring it when you come. Also bring the books for me. If you cannot bring all of them, then be sure to bring my special papers."
    },
    {
      "verse": "14",
      "text": "Alexander, the man who makes things from metal, caused a lot of trouble for me. The Lord will punish him because of the wrong things that he did."
    },
    {
      "verse": "15",
      "text": "You must also be careful that he does not cause trouble for you. He argued very strongly against our message."
    },
    {
      "verse": "16",
      "text": "I had to explain to a judge that I had not done anything wrong. The first time I did that, nobody helped me. All my friends stayed away. I pray that God will forgive them for that."
    },
    {
      "verse": "17",
      "text": "But the Lord was there to help me. He made me strong so that I could tell his message clearly. Gentile people from many countries could hear what I said. So the Lord saved me from the danger of death."
    },
    {
      "verse": "18",
      "text": "The Lord will continue to save me from every bad thing. And he will bring me safely to heaven, where he rules. He is great and we should praise him for ever! Amen! This is true!"
    },
    {
      "verse": "19",
      "text": "Say ‘hello’ for me to Priscilla and Aquila, and to the family of Onesiphorus."
    },
    {
      "verse": "20",
      "text": "Erastus remained at Corinth city. I left Trophimus at Miletus city because he was ill."
    },
    {
      "verse": "21",
      "text": "Please try to come before the winter. Eubulus, Pudens, Linus and Claudia say ‘hello’ to you. All the other believers here also say ‘hello’."
    },
    {
      "verse": "22",
      "text": "I pray that the Lord will continue to make you strong in your spirit. I pray that he will be kind to all of you."
    }
  ]
};