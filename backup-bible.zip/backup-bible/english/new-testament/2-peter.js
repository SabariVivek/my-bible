module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter is from me, Simon Peter. I am Jesus Christ's servant and his apostle. I am writing to you people who believe in Jesus Christ, as we do. That is a valuable gift that God has given to us all. He has done this because Jesus is completely good and right. Jesus is the one who saves us. He is the God that we serve. I am writing to you people who believe in Jesus Christ, as we do. That is a valuable gift that God has given to us all. He has done this because Jesus is completely good and right. Jesus is the one who saves us. He is the God that we serve."
    },
    {
      "verse": "2",
      "text": "I pray that God will help you and give you peace in your minds more and more. You will grow as believers because you know God and you know Jesus, our Lord."
    },
    {
      "verse": "3",
      "text": "God is very powerful because he is God. He has used that power to help us. He has given us everything that we need to live in a good way. We can do things that make God happy. This is possible because now we know him. God has chosen us to be his people because he is very great and very good."
    },
    {
      "verse": "4",
      "text": "Because of this, God has promised that he will do very great and valuable things for us. As a result, you can do what is right, like God does. The people who belong to this world want to do bad things. Those bad things make them become worse and worse. But God gives you the power to be free from all that."
    },
    {
      "verse": "5",
      "text": "God has done all this to help you. So now that you believe in Christ, you must grow as believers. Try very much to do always what is good. Then you should grow to know God more and more."
    },
    {
      "verse": "6",
      "text": "Then you should learn to control yourselves properly. That is not all. You should also learn to be patient and brave. And you should live in a way that pleases God."
    },
    {
      "verse": "7",
      "text": "You should not only please God, but you should be kind to other believers. You should not only love other believers, but you must also love all people."
    },
    {
      "verse": "8",
      "text": "You should continue to grow as believers in all these ways. Then it will show that you really know our Lord Jesus Christ. People will see that your life has good results."
    },
    {
      "verse": "9",
      "text": "But some people do not live in these good ways. They do not think that these things are important. They are like blind people. They cannot really see anything properly. They have forgotten that God has made them clean from all the sins that they did in past times."
    },
    {
      "verse": "10",
      "text": "So, my friends, try very much to live in a way that pleases God. God has chosen you to be his own people. Show that you really do belong to him! If you do these things, you will never turn away from God."
    },
    {
      "verse": "11",
      "text": "Then God will bring you safely into the kingdom of our Lord Jesus Christ that continues for ever. Jesus Christ is our Saviour and God will be happy to welcome you into his kingdom."
    },
    {
      "verse": "12",
      "text": "You already know these things. You know that they are completely true. But because they are important, I will continue to tell you about them again and again."
    },
    {
      "verse": "13",
      "text": "While I am still alive on this earth I will continue to make sure that you remember them. I think that it is right for me to do that."
    },
    {
      "verse": "14",
      "text": "I know that I will die soon. Our Lord Jesus Christ has shown me that clearly."
    },
    {
      "verse": "15",
      "text": "After I am no longer with you, I want you still to remember what I have told you. So I will make sure that you have something to help you not to forget."
    },
    {
      "verse": "16",
      "text": "We told you that our Lord Jesus Christ is powerful. We also told you that he will return to earth again. We were not telling you false stories that came from people's clever ideas. Instead, we were telling you what we ourselves had seen. We ourselves saw that the Lord Jesus is very great."
    },
    {
      "verse": "19",
      "text": "As well as that, we have the prophets' messages from long ago. They also show us very clearly that these things are true. The prophets' words are like a light that shines in a dark place. That light continues to shine in the dark until the dawn comes. So you need to think about those messages carefully. Then the morning star will rise and it will bring light deep inside you."
    },
    {
      "verse": "20",
      "text": "It is very important that you should understand this: The prophets' messages in the Bible did not come from their own ideas. That never happens."
    },
    {
      "verse": "21",
      "text": "None of the prophets' messages came because any person wanted to say something. Instead, God's Holy Spirit caused people to speak words that came from God."
    },
    {
      "verse": "17",
      "text": "We were with him on the holy mountain when his Father God spoke to him. God gave honour to his Son, Jesus, and he said that Jesus is great. We ourselves heard God's voice speak to Jesus from heaven above where God rules with power."
    },
    {
      "verse": "18",
      "text": "He said: ‘This is my Son and I love him. He makes me very happy. ’."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Many years ago, there were false prophets among God's people. They did not speak God's true messages. In the same way, there will also be false teachers among you. They will come among you and they will teach you things that are not true. Their wrong ideas will deceive people. Those false teachers will even speak against the Master, who paid the price for their sins. As a result, they will bring trouble on themselves that quickly destroys them."
    },
    {
      "verse": "2",
      "text": "Many people will believe these false teachers. They will live in a bad way, like the false teachers. As a result, other people will say bad things against God's true way to live."
    },
    {
      "verse": "3",
      "text": "The false teachers want you to give them money. So they will teach things that are not true. A long time ago, God already decided that he must punish them. God is ready to do that now. Certainly, he will soon destroy them."
    },
    {
      "verse": "4",
      "text": "God even punished the angels who refused to obey him. He threw them down into the deep hole of hell. He tied them up and he kept them in that completely dark place. They will remain there until the day when God will judge them."
    },
    {
      "verse": "5",
      "text": "Also, a long time ago, God punished all the bad people who lived in the world. He sent water to cover over all the earth. All the people who had turned away from him drowned in the water. But God kept Noah safe. Noah had told people God's message that they should do right things. So God saved Noah, and seven other people, from the water."
    },
    {
      "verse": "6",
      "text": "Later, God punished the people who lived in the cities of Sodom and Gomorrah. Because they did bad things, God decided to destroy them. He burned those cities completely, so that only ashes remained. When God did that, he showed what will happen to all people who refuse to obey him."
    },
    {
      "verse": "7",
      "text": "But God saved Lot from danger. Lot was a good man. He was very sad because the people in Sodom did not obey God's laws. They lived in a very bad way."
    },
    {
      "verse": "8",
      "text": "Lot lived among those bad people. Every day, he saw the bad things that they did. Every day, he heard the bad things that they said. As a result, Lot had much trouble in his mind, because he was a good man."
    },
    {
      "verse": "9",
      "text": "We know that the Lord God has done all these things in past times. He knows how to save people who respect him from their troubles. But he will continue to punish the people who refuse to obey him. He will keep them until the day when he will judge them."
    },
    {
      "verse": "10",
      "text": "God will certainly punish those people who want bad things for themselves. They do the wrong things that their bodies want to do. They do not want to obey anyone's authority. These false teachers are not afraid of what other people think about them. They think that they themselves are very important. They are not afraid to say many bad things against the great angels in heaven."
    },
    {
      "verse": "11",
      "text": "The angels are more powerful than the false teachers are. But even these angels will not say bad things against them when the Lord is present."
    },
    {
      "verse": "12",
      "text": "But these false teachers speak against things that they do not understand. They are like wild animals. Their minds cannot think properly. They only do what their nature causes them to do. Wild animals are born so that people can catch them and kill them. In the same way, God will destroy the false teachers."
    },
    {
      "verse": "13",
      "text": "They have caused other people to have much trouble. In return, God will cause them to have trouble. They just do things which will make their bodies happy. They have wild parties, even during the day. They eat and drink too much when they eat meals with you. They enjoy all these bad ways to be happy. As a result, people think bad things about you as well. They cause people to be ashamed about you. So they are like dirty marks that spoil something which is clean."
    },
    {
      "verse": "14",
      "text": "All the time, they are looking for women who will have sex with them. They never stop doing wicked things. They teach people who have weak minds to believe wrong things. They just want more and more things to make themselves happy. God will certainly punish these people, because they are so bad."
    },
    {
      "verse": "15",
      "text": "These false teachers have left the way which is good and right. Like Balaam, Beor's son, they have gone the wrong way. Balaam wanted money so much that he did wrong things to get it."
    },
    {
      "verse": "16",
      "text": "But a donkey told him that he was not obeying God. We know that donkeys cannot talk. But that donkey spoke with a human voice. It stopped the prophet Balaam from doing more crazy things."
    },
    {
      "verse": "17",
      "text": "These false teachers promise good things that will never happen. They are like a dry well that has no water. They are like clouds in a storm which the wind blows away so that no rain comes. God will certainly send them to the darkest place in hell. He has kept that place ready for them."
    },
    {
      "verse": "18",
      "text": "The messages that these teachers speak seem very important. But their words really mean nothing. In that way, they lead people away from God. Some people have not been believers for very long. They have only just become free from the wrong things that people do. But the false teachers tell these people to do bad things that will make them happy."
    },
    {
      "verse": "19",
      "text": "The false teachers tell these believers to do whatever they want to do. They promise that this will make them really free. But the false teachers themselves are not free. Instead, they are like slaves. They cannot stop doing the bad things that will destroy them. We know that if something has power over a person, then that person is its slave."
    },
    {
      "verse": "20",
      "text": "People like that learned about our Lord Jesus Christ, who saves us. As a result, they had stopped doing the bad things that belong to this world. They had become free from the power of those things. But now they have started to do those bad things again. Those things have power over them and they cannot stop doing them. So now, these false teachers are worse than they were at the beginning, before they believed in the Lord Jesus."
    },
    {
      "verse": "21",
      "text": "It would have been better for them if they had never known God's good way. But they did understand about the right things that God wants us to do. And then they turned away from that way of life. They stopped obeying God's good rules, that people had taught them."
    },
    {
      "verse": "22",
      "text": "You know these true proverbs: ‘After a dog has been sick, it returns to eat it again. ’ Also: ‘After you wash a pig, it will quickly roll in the dirt again. ’ These words describe how the false teachers live."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "My friends, this is the second letter that I have written to you. I have written both these letters to help you to understand some things. You already know these things. I want you to think about them in a good way."
    },
    {
      "verse": "2",
      "text": "I want you to remember the messages from God that his own prophets spoke a long time ago. Also, I want you to remember what our Lord Jesus told you to do. He is the one who saves us. He sent us, his apostles, to teach you his message."
    },
    {
      "verse": "3",
      "text": "The first thing that you should understand is this. In the last days of this world, some people will laugh at you because you believe in God. These people will do whatever bad things they want to do."
    },
    {
      "verse": "4",
      "text": "They will say: ‘Christ promised that he would return to this world. But he has not returned! Our ancestors have already died, but since God made the world in the beginning, nothing has changed. ’"
    },
    {
      "verse": "5",
      "text": "These people choose to forget things that they really know. A long time ago, God spoke his word and he made the sky and the earth. He caused land to come up through water. He made the land to be separate from the water."
    },
    {
      "verse": "6",
      "text": "Also, God used water to destroy that same world long ago. He spoke his word and he covered the land with water."
    },
    {
      "verse": "7",
      "text": "But God has also spoken his word to say what will happen to the world in a future time. The sky and the earth that we see now will continue for a time. But God is keeping them until the day when he will destroy them with fire. On that day he will judge all people. He will destroy the people who have turned away from him."
    },
    {
      "verse": "8",
      "text": "My friends, here is one thing that you must remember. In the Lord God's mind, one day and 1, 000 years are the same. For him, 1, 000 years is like a single day."
    },
    {
      "verse": "9",
      "text": "The Lord is not being slow to do what he has promised to do. Some people may think that he is being slow to do it. But he is being patient with you. He does not want to destroy anyone. He wants all people to turn away from the wrong things that they do."
    },
    {
      "verse": "10",
      "text": "The great day of the Lord will suddenly happen. That will surprise people, like when someone comes to rob them. There will be a very loud noise in the sky. The whole sky will go away. Fire will burn the whole universe and it will destroy everything. The earth and everything that people have made will then become clear."
    },
    {
      "verse": "11",
      "text": "Certainly, God will destroy everything in this way one day. So think about how you should live now. You should be the kind of people that God is happy about. You should show that you belong to God."
    },
    {
      "verse": "12",
      "text": "Yes, you should continue to obey God while you are waiting for Christ to return. God has chosen that day. Try to live in a way that will make that day come soon. On that day, fire will burn the whole sky. The sky will no longer be there. Heat will destroy the universe."
    },
    {
      "verse": "13",
      "text": "But God has promised to make a new sky and a new earth. That is what we are waiting for. That will be a home for everything that is good and right."
    },
    {
      "verse": "14",
      "text": "So, my friends, live in a good way, because you are waiting for these things to happen. Try very much to do what makes God happy. Then, when you meet God, he will see that you are clean. He will see that there is no trouble in your minds."
    },
    {
      "verse": "15",
      "text": "Remember that our Lord wants to save people from their sins. That is why he is now waiting patiently for people to turn to him before he will return. Paul has also written to you about these things. He is our friend that we love like a brother. God helped him to understand these things."
    },
    {
      "verse": "16",
      "text": "He wrote about them in all his letters. Some things that he has written are difficult for people to understand. Some people have weak minds and they are not sure about what they believe. They explain Paul's teaching in a way that deceives people. They also explain other things in the Bible wrongly. As a result, those people will destroy themselves and God will punish them."
    },
    {
      "verse": "17",
      "text": "My friends, you already know about these false teachers. So be very careful that you do not believe those bad people. Do not let them lead you away from God. You know what is true, so do not leave that safe place."
    },
    {
      "verse": "18",
      "text": "Instead, you must grow as believers in our Lord Jesus Christ, who saves us. Continue to know him better and better. He will be kind to you and he will help you more and more. We praise him as he deserves! He is great now and he will be great for ever!"
    }
  ]
};