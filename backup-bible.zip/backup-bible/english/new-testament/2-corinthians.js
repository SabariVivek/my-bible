module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter is from me, Paul. God chose me to be an apostle of Christ Jesus. Our Christian friend Timothy is here with me as I write. I am sending this letter to you, the people of the church in Corinth city. I am sending it also to all of God's people who live in other places in Achaia. I am sending this letter to you, the people of the church in Corinth city. I am sending it also to all of God's people who live in other places in Achaia."
    },
    {
      "verse": "2",
      "text": "I pray that God, our Father, and the Lord Jesus Christ will continue to help you. I pray that they will give you peace in your minds."
    },
    {
      "verse": "3",
      "text": "We thank God, the Father of our Lord Jesus Christ, because he is so good to us. As our Father, he is very kind to us. He is our God who comforts us in every way."
    },
    {
      "verse": "4",
      "text": "Whenever we have trouble, he comforts us. Because of that, we ourselves can comfort other people. When they have any kind of trouble, we can comfort them, in the same way that God has comforted us."
    },
    {
      "verse": "5",
      "text": "Christ himself received much pain, and God comforted him. As Christ's servants, we also receive the same kind of pain. But, God also comforts us very much, because we belong to Christ."
    },
    {
      "verse": "6",
      "text": "So, when we receive trouble, the result is that we can comfort you. And then also, God saves you. When God comforts us, that helps us to comfort you too. As a result, when you receive the same kinds of trouble that we receive, you learn to be patient and strong."
    },
    {
      "verse": "7",
      "text": "So we continue to be sure that you will remain strong. You receive many troubles, as we do too. But we know that God will also comfort you, as he comforts us."
    },
    {
      "verse": "8",
      "text": "Our Christian friends, we want you to know about the trouble that we had in Asia. Those troubles were very painful. We ourselves were not strong enough to continue. We even thought that we would die."
    },
    {
      "verse": "9",
      "text": "We ourselves thought that we would certainly die. We knew that we could not trust our own strength. We had to trust God. He is the one who causes dead people to rise up to new life. So we could trust him to make us strong."
    },
    {
      "verse": "10",
      "text": "We nearly died, but God saved us from that great danger. We know that we can continue to trust him. He will save us from any future danger."
    },
    {
      "verse": "11",
      "text": "We also know that you continue to help us as you pray for us. As many people pray for us, they will thank God when he answers their prayers. They will see that God is very kind to us, and they will thank him."
    },
    {
      "verse": "12",
      "text": "We can be proud of how we have lived in this world. We have been careful to be honest and good with everyone. And we have been like that with you even more. We are sure in our own minds that this is true. We have not tried to be clever in a human way. But we have lived in the way that God has helped us to live."
    },
    {
      "verse": "13",
      "text": "We are writing to you only about things that you yourselves can read and understand. And I hope that you will understand completely one day."
    },
    {
      "verse": "14",
      "text": "You do not understand us completely yet. But I hope that you will understand completely on the day when our Lord Jesus returns. Then you can be proud of us in the same way that we will be proud of you."
    },
    {
      "verse": "17",
      "text": "I did not decide this in a careless way. I really wanted to do it. I do not decide to do things only to please myself, like someone who does not know God. I do not say ‘Yes, ’ and then I immediately say ‘No’."
    },
    {
      "verse": "18",
      "text": "God always does what he says he will do. In the same way, my promise to you was not both ‘Yes’ and ‘No’."
    },
    {
      "verse": "19",
      "text": "Silas, Timothy and I told you the message about God's Son, Jesus Christ. Christ is not someone who changes his message between ‘Yes’ and ‘No’. Instead, he always says ‘Yes, ’ and he does what he says."
    },
    {
      "verse": "20",
      "text": "Christ says ‘Yes’ to all of God's promises, so that they become true. So when we pray, we say ‘Yes, amen! , ’ because we know that Christ has done it. And when we do that, we are saying that God is great."
    },
    {
      "verse": "21",
      "text": "It is God that causes us to continue to trust Christ. He does that for us and for you, because we belong to Christ. God has chosen us to serve him."
    },
    {
      "verse": "22",
      "text": "He has also put his mark on us, to show that we belong to him. He has given his Spirit to us, to live in us. Because of that, we know that we will receive all the good things that God has promised."
    },
    {
      "verse": "23",
      "text": "God will show that what I say is true! He knows my thoughts. Why did I decide not to come back to Corinth at this time? I did not come because I did not want to be angry with you."
    },
    {
      "verse": "24",
      "text": "We are not trying to tell you what you must believe, like masters would do. You are already strong in your spirits because you trust God. So we want to help you to be really happy."
    },
    {
      "verse": "15",
      "text": "So, because I was sure that you trusted me, I wanted to visit you twice. Then I could bring God's help to you twice. I decided to visit you first on my way to Macedonia."
    },
    {
      "verse": "16",
      "text": "Then I would visit you again on my way back from Macedonia. After that, you could help to send me on my journey to Judea."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Because of that, I decided not to visit you again at that time. I did not want to make you sad."
    },
    {
      "verse": "2",
      "text": "You are the only people who can make me happy. So, if I make you sad, there will be nobody to make me happy."
    },
    {
      "verse": "3",
      "text": "That is why I did not visit you. I wrote that letter to you instead. You are the people who should make me happy. I did not want you to make me sad when I visited you. I felt sure about all of you. I knew that, if I was happy, then all of you would be happy too."
    },
    {
      "verse": "4",
      "text": "When I wrote that letter, I was very sad and upset. I cried a lot. I did not want to make you sad. Instead, I wanted you to know that I love you very much."
    },
    {
      "verse": "5",
      "text": "Someone among you has done things that have made other people sad. That person has made me sad. But really he has made all of you much more sad than me. I do not want to say more about this than is necessary."
    },
    {
      "verse": "6",
      "text": "Most of you have agreed to punish him. That should be enough."
    },
    {
      "verse": "7",
      "text": "Now, you should forgive him. You should comfort him. If you do not do that, he may become too sad. He may not be able to think properly."
    },
    {
      "verse": "8",
      "text": "So I tell you this: Please show him that you really do love him."
    },
    {
      "verse": "9",
      "text": "When I wrote that letter to you, I wanted to know what you would do. I wanted to see if you would do everything that I told you."
    },
    {
      "verse": "10",
      "text": "When you forgive anyone, I also forgive that person. Whatever bad thing somebody has done, I have Christ's authority to forgive them. And I do it to help you."
    },
    {
      "verse": "11",
      "text": "We do not want Satan to win against us. He is very clever. We know how he likes to cause us to have trouble."
    },
    {
      "verse": "12",
      "text": "I went to Troas city to tell people the good news about Christ. When I arrived there, I discovered that the Lord had already prepared people to listen."
    },
    {
      "verse": "13",
      "text": "But I was not happy in my thoughts because I could not find my friend Titus there. So I said ‘goodbye’ to those people and I travelled on to Macedonia."
    },
    {
      "verse": "14",
      "text": "But I thank God! He has won against sin, because of what Christ has done. Christ is our leader and we show that he is the winner. We also help people to know about Christ. That knowledge is like a lovely smell that comes to people everywhere."
    },
    {
      "verse": "15",
      "text": "When we tell people about Christ, we are like a lovely smell that rises up to God. We are like that among the people that God is saving. We are also like that among the people who are dying because they are far from God."
    },
    {
      "verse": "16",
      "text": "For the people who are dying, we are like a bad smell that brings a message of death. But for the people that God is saving, we are like a lovely smell that brings a message of new life. Nobody is really good enough to tell such an important message!"
    },
    {
      "verse": "17",
      "text": "Some people even tell God's message because they want to get a lot of money for themselves. But we are not like them. No, God himself has sent us to do this work. And he sees what we are doing. So we are honest and we speak God's message clearly, as Christ's servants should do."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "We do not need any more to show that our work is good. Some people need to have letters from other people to say that they do good work. We do not need to show you letters like that. Nor do we need you to write a letter like that for us."
    },
    {
      "verse": "2",
      "text": "You yourselves show that we have done good work. You are like a letter that is written on our lives. Everybody can read that letter and they can understand it."
    },
    {
      "verse": "3",
      "text": "It is clear that you are a like a letter that Christ himself has written. We are the people who brought God's message to you. Now people see what God has done in your lives. That is like a letter that they read. But it is not a letter written on paper with ink. It is the Spirit of the living God who wrote it. He did not write it on pieces of stone. Instead, he wrote it deep inside you."
    },
    {
      "verse": "4",
      "text": "We know that these things are true. Because of what Christ has done, we trust God to help us."
    },
    {
      "verse": "5",
      "text": "We know that we cannot do this work by ourselves. We never think that. But God makes us able to do it."
    },
    {
      "verse": "6",
      "text": "God has made us his servants. So we are able to tell people the message of his new agreement. This new agreement is not about rules. Rules tell people what they must do and they bring death. But God's new agreement comes from his Spirit. And the Spirit brings new life to us, not death."
    },
    {
      "verse": "7",
      "text": "Moses wrote the words of the old agreement on pieces of stone. It showed how great and powerful God was. Moses' face shone brightly after God spoke to him. It did not stay bright, but the Israelite people still could not look at Moses' face. The old agreement that brought death was powerful."
    },
    {
      "verse": "8",
      "text": "So the new agreement, which comes from God's Spirit, will show the power of God even more."
    },
    {
      "verse": "9",
      "text": "The old agreement showed people that they were guilty. God's new agreement makes people right with him. So surely the new agreement shows God's power even more than the old one did!"
    },
    {
      "verse": "10",
      "text": "The old agreement was great and powerful at one time. But now God's new agreement has come in its place. The great power of the new agreement shows that the old agreement is no longer powerful."
    },
    {
      "verse": "11",
      "text": "The old agreement was powerful, but it came to an end. God's new agreement will continue always. So it surely shows the power of God even more!"
    },
    {
      "verse": "12",
      "text": "So, because we know all this, we speak God's message bravely."
    },
    {
      "verse": "13",
      "text": "We are not like Moses. His face did not continue to be bright with the light from God. So he covered his face with a cloth. He did not want the Israelite people to see that the light was coming to an end."
    },
    {
      "verse": "14",
      "text": "But those Israelite people could not think properly. Even today, they still do not understand the message of God's old agreement. When they read it, they are like people who have a cloth that covers their minds. It continues like that unless they believe in Christ. Then Christ removes the cloth so that they understand."
    },
    {
      "verse": "15",
      "text": "Even today, when the Israelite people read Moses' books, a cloth still covers their minds."
    },
    {
      "verse": "16",
      "text": "But when a person turns to trust the Lord, then God takes the cloth away."
    },
    {
      "verse": "17",
      "text": "The Lord is the same as the Spirit. And when the Lord's Spirit is with anyone, that person is free."
    },
    {
      "verse": "18",
      "text": "We show the power of the Lord to other people. It is like God has removed a cloth from over our faces. He is changing us so that we become more and more like him. We show how great God is more and more clearly. It is the Lord who does all this, by the work of his Spirit."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "God has given us this work to speak his message. Because he has been so kind to us, we are not afraid to continue."
    },
    {
      "verse": "2",
      "text": "We refuse to do anything secretly that we might be ashamed of. We do not tell lies. We do not change God's message to deceive people. No. We tell God's true message clearly. God himself sees that we teach people in an honest way. Everyone should understand that we only do what is right."
    },
    {
      "verse": "3",
      "text": "Some people may not understand the good news that we speak. They are only the people who are losing their lives with God."
    },
    {
      "verse": "4",
      "text": "Those people do not accept God's good news. The god of this world has confused their minds. They cannot see the light that the good news brings. That message teaches about the great power of Christ, who shows us exactly what God is like."
    },
    {
      "verse": "5",
      "text": "We do not speak a message about ourselves. We tell people that Jesus Christ is our Lord. Because we belong to Jesus, we have become your servants, not your masters."
    },
    {
      "verse": "6",
      "text": "God is the one who said, ‘Let light shine in the dark. ’ And he is the one who has caused his light to shine deep inside us. Because of that, we know how great and powerful God is. We see that his power shines brightly in Christ's face."
    },
    {
      "verse": "7",
      "text": "God has given to us the gift to speak his message. But we ourselves are very weak. It is like we are keeping his valuable gift in clay pots. So it is clear that the great power of God's message comes from God himself. It does not come from us."
    },
    {
      "verse": "8",
      "text": "We receive trouble all the time, but that does not stop us. We do not always know what to do, but we are not afraid to continue."
    },
    {
      "verse": "9",
      "text": "We have many enemies, but we always have friends. People hurt us, but they never destroy us."
    },
    {
      "verse": "10",
      "text": "As we serve Jesus, we know that we may die as he died. Because of that, our lives show that we live because he is alive."
    },
    {
      "verse": "11",
      "text": "Yes, as we live our lives, death is always very near, because we serve Jesus. As a result, people can see in our weak, human bodies that Jesus is alive."
    },
    {
      "verse": "12",
      "text": "So death is near to us, even as we live. But as a result, we are bringing God's life to you."
    },
    {
      "verse": "13",
      "text": "This is written in the Bible: ‘I believed in God, and so I spoke. ’ We also have the same kind of faith in God. So we also speak God's message, because we believe in him."
    },
    {
      "verse": "14",
      "text": "God raised up the Lord Jesus, to become alive again after his death. Because we belong to Jesus, we know that God will also raise us up after we die. Together with you, God will take us to be where he is."
    },
    {
      "verse": "15",
      "text": "In everything that we do, we want to help you. As a result, more and more people are seeing how kind God is. So people are thanking God more and more. And that shows how great God is."
    },
    {
      "verse": "16",
      "text": "That is why we are not afraid to continue our work. Yes, our bodies are getting older and weaker. But our spirits are becoming stronger every day!"
    },
    {
      "verse": "17",
      "text": "We have these little troubles that continue for a short time. But as a result, we will receive the great things that God has prepared for us. Those great things are much more important than our little troubles. And God's great things will continue for ever!"
    },
    {
      "verse": "18",
      "text": "So we do not look at the things that we can see in this world. Instead, we look at the things that people cannot see. The things that we can see are only here for a short time. But the things that we cannot see will continue for ever."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Our bodies are like a tent that we live in here on earth. One day, that home will come to an end. But we know that God will give us a new home. It is not a house that a human builder has built. God has built it for us in heaven and we will live there for ever."
    },
    {
      "verse": "2",
      "text": "Now, while we are in our body here on earth, we cry inside ourselves. We want to go and live in our house that is in heaven."
    },
    {
      "verse": "3",
      "text": "That will be like new clothes that we put on. When we go to live there, we will not be without clothes and ashamed."
    },
    {
      "verse": "4",
      "text": "While we still live in our bodies here on earth, we cry inside ourselves. Many difficult things happen to us. We do not really want to take off our old body. But we do want to put on our new body, like new clothes. When that happens, we will no longer need our old body which had to die. Instead we will have a new body that will live for ever."
    },
    {
      "verse": "5",
      "text": "God is the one who has prepared us to have a new life in heaven one day. He has given his Spirit to be with us now. Because of that, we know that we will receive all God's good things one day."
    },
    {
      "verse": "6",
      "text": "Because God's Spirit is with us, we continue to be brave. While we still live here on earth, we know that we are not yet at home with the Lord."
    },
    {
      "verse": "7",
      "text": "As we live here, we have to trust God. We do not yet see the things that belong to heaven."
    },
    {
      "verse": "8",
      "text": "We are brave because we trust God. We would like to go away from our body here on earth. Then we would go to be at home with the Lord. And that would be better!"
    },
    {
      "verse": "9",
      "text": "But all the time we want to please the Lord. We want to do that while we are still at home in our body here on earth. We also want to please him when we go away from these bodies."
    },
    {
      "verse": "10",
      "text": "Because all of us must go and stand in front of Christ as our judge. He will decide about the things that we have done during our lives here on earth. Whether we have done good things or bad things, we will receive what is right for us."
    },
    {
      "verse": "11",
      "text": "We know that the Lord will judge us, so we are careful to obey him. Because of that, we tell God's message to people. We want them to believe in God. And God himself knows that we try to do what is right. I hope that you know that also, when you think about it."
    },
    {
      "verse": "12",
      "text": "We are not trying again to make you think that our work is good. But we do want to give you the chance to be proud of us. Then you will be able to show the false teachers that they are wrong. They are proud about what they look like on the outside. They do not think about what they are really like inside themselves."
    },
    {
      "verse": "13",
      "text": "To some people, we may seem to be crazy. That is because we want to serve God. But if we seem to be wise, that is to help you."
    },
    {
      "verse": "14",
      "text": "Whatever we do, we do it because Christ loves us. We know that one man, Christ, died on behalf of all people. So we also know that all of us died with him."
    },
    {
      "verse": "15",
      "text": "He died on behalf of all people. So, while we live, we no longer live to please ourselves. Instead, we live to please Christ. He is the one that died on our behalf. He is the one that God raised up, to live again."
    },
    {
      "verse": "16",
      "text": "So that changes how we think about people. We no longer use human ideas to think what they are like. At one time, we thought about Christ as humans think. But now we think about him very differently!"
    },
    {
      "verse": "17",
      "text": "When anyone belongs to Christ, they become a new person. Their old way of life has gone. Their new life has begun!"
    },
    {
      "verse": "18",
      "text": "All this is what God does for us. Because of what Christ has done, God has brought us back to himself, as his friends. Now he wants us to bring other people to be his friends too. That is the job that he has given to us."
    },
    {
      "verse": "19",
      "text": "God's message is this: By Christ's death, God was bringing people of the world back to himself, as his friends. He would no longer keep their sins in his thoughts. This is the message that God wants us to tell people."
    },
    {
      "verse": "20",
      "text": "So we speak to people on behalf of Christ. It is like this: When we speak, God himself is speaking to you. On behalf of Christ, we say to you, ‘Please come back to God, as his friends! ’"
    },
    {
      "verse": "21",
      "text": "Christ never did any wrong thing, but God punished him as if he had. He died as punishment for our sins. As a result, we become right with God when we belong to Christ. We become right, because he is right."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "So, as we work together with God, we tell you to be careful. Remember that God has been very kind and he has forgiven you. Do not waste that! ‘I listened to your prayer at the right time for me to help you. I helped you on the right day for me to save you. ’ Listen! The right time is now! The day for God to save you is now!"
    },
    {
      "verse": "2",
      "text": "In the Bible God says:‘I listened to your prayer at the right time for me to help you. I helped you on the right day for me to save you. ’Listen! The right time is now! The day for God to save you is now!"
    },
    {
      "verse": "3",
      "text": "We do not want anyone to think bad things about our work. So we do nothing that might cause trouble for anyone."
    },
    {
      "verse": "4",
      "text": "Instead, in everything that we do, we want to show that we are God's servants. When people want to hurt us, we are patient and brave. We have many troubles. We become sad and upset."
    },
    {
      "verse": "5",
      "text": "Sometimes people hit us. They put us in prison. They attack us. But we work hard. We cannot always sleep at night. We are often hungry."
    },
    {
      "verse": "6",
      "text": "We serve God honestly and with clean thoughts. We know what is true. We are patient and kind. God's Holy Spirit helps us. We love people in an honest way."
    },
    {
      "verse": "7",
      "text": "We speak a true message. God's power gives us strength. We do what is right, so we fight like soldiers on God's behalf. It is like we have God's weapons in both hands!"
    },
    {
      "verse": "8",
      "text": "Sometimes people respect us as important. Sometimes they think that we are worth nothing. People may insult us, or they may praise us. We only say true things, but some people still think that we deceive others."
    },
    {
      "verse": "9",
      "text": "Some people do not want to know us. Other people accept us as God's servants. It seems like we are dying, but look! We are still alive! People punish us, but they do not kill us."
    },
    {
      "verse": "10",
      "text": "We seem to be sad, but really we are always happy. We seem to be poor, but we make many people rich. We seem to have nothing, but really we have everything."
    },
    {
      "verse": "11",
      "text": "Our friends at Corinth, we have spoken to you very honestly. We have shown you how much we love you."
    },
    {
      "verse": "12",
      "text": "We have done nothing to stop you from being our friends. But you have not really wanted to become our friends."
    },
    {
      "verse": "13",
      "text": "I am speaking to you as I would speak to my own children. Be fair to us! Accept us as your friends, just as we have accepted you."
    },
    {
      "verse": "14",
      "text": "Do not become united with people who do not believe in Christ. God has made you right with himself. Right and wrong cannot work together. Light and dark cannot join together. ‘I will make my home with them and I will live among them. I will be their God and they will be my people. ’"
    },
    {
      "verse": "15",
      "text": "Christ will never agree with the Devil. People who believe in Christ are completely different from people who do not believe."
    },
    {
      "verse": "16",
      "text": "Idols do not belong in God's house. Remember that we believers are the house of the God who lives for ever. This is what God has said:‘I will make my home with them and I will live among them. I will be their God and they will be my people. ’"
    },
    {
      "verse": "17",
      "text": "And so, the Lord says:‘Come out from among them and be separate. Do not touch anything that is disgusting. Then I will accept you. ’ ‘Come out from among them and be separate. Do not touch anything that is disgusting. Then I will accept you. ’"
    },
    {
      "verse": "18",
      "text": "He also says:‘I will be a Father to you. You will be my sons and my daughters. That is what the Almighty Lord God says. ’"
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "So, my friends, God has promised these things to us. So we must keep ourselves clean from everything that makes our bodies or our spirits unclean. We must respect and obey God. Then we will become more and more like him."
    },
    {
      "verse": "2",
      "text": "Be friends with us. We have done nothing wrong to any of you. We have not hurt anyone. We have not cheated anyone."
    },
    {
      "verse": "3",
      "text": "I am not saying this to make you feel ashamed. As I have told you before, you are our special friends. We will continue to love you, whether we live together or we die together."
    },
    {
      "verse": "4",
      "text": "I know you and I trust you. I am proud of you. You have helped me to be strong. So, even when we have many troubles, I am still very happy."
    },
    {
      "verse": "5",
      "text": "When we arrived in Macedonia, our bodies did not rest at all. We had many kinds of trouble. All round us, people quarrelled with us. Inside us, we were afraid."
    },
    {
      "verse": "6",
      "text": "But when people feel upset, God helps them to be strong. And God made us happy when Titus arrived."
    },
    {
      "verse": "7",
      "text": "God comforted us not only because Titus came to us. He comforted us also by what Titus told us about you. He said that you had helped him to be strong. He told us that you want to see me. He told us that you are very sad about what happened. He told us also that you are ready to help me. Because of what Titus told us about you, I was very happy."
    },
    {
      "verse": "8",
      "text": "But even if I made you sad by my letter, I am not sorry about that. At one time, I was sorry that I had written it. I saw that my letter had made you sad. But you were sad only for a short time."
    },
    {
      "verse": "9",
      "text": "So now I am happy, but not because my letter made you sad. No, I am happy because it made you turn away from wrong things. You became sad as God wanted you to be sad. So, when the letter made you sad, we did not really hurt you."
    },
    {
      "verse": "10",
      "text": "People need to become sad in the way that God wants. When they are sad like that, it causes them to turn away from wrong things. Then God saves them from their sins. They will never be sorry about that! But when people become sad in the way that the world wants, it does not help them. They do not turn to God and they die in their spirits."
    },
    {
      "verse": "11",
      "text": "You became sad in the way that God wanted. And see what good results that has brought! It has made you work hard to do good things. You want to show people that you do what is right. You are angry against sin. You want to obey God. You want to make things right again. You want to please God. You want to punish anyone who does wrong things. In all these ways, you have shown that you are right. You have done everything that was necessary in this matter."
    },
    {
      "verse": "12",
      "text": "So why did I write that letter to you? It was not because of the person who did the wrong thing. Nor was it to help the person that he hurt. No. I wrote the letter to show you something about yourselves. I wanted God to show you that you do really love us and you respect us."
    },
    {
      "verse": "13",
      "text": "That is how God has comforted us. It was not only us that God comforted. When Titus came, we were very happy to see how happy he was too. He was happy because all of you had taken care of him."
    },
    {
      "verse": "14",
      "text": "I had told Titus that I was very proud of you. When he came to you, you showed that I was right about you. We have always spoken only true things to you. And when we said good things about you to Titus, you showed that those things were also true."
    },
    {
      "verse": "15",
      "text": "Now, when Titus thinks about you, he loves you even more. He remembers that you were ready to obey him. You respected his authority and you received him into your homes."
    },
    {
      "verse": "16",
      "text": "So now I am very happy because I trust you to do what is right."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "My Christian friends, let me tell you about the believers in the churches in Macedonia. God has been very kind to them."
    },
    {
      "verse": "2",
      "text": "They have had bad troubles, but they continued to be very happy. As a result, they gave a lot of money to other people. They themselves are very poor, but they still helped other people a lot."
    },
    {
      "verse": "3",
      "text": "Let me tell you this. They gave as much money as they were able to give. Then they gave even more than that! They gave it because they wanted to."
    },
    {
      "verse": "4",
      "text": "They wanted the chance to help God's people. That would make them happy. So they asked us many times to help them to do this."
    },
    {
      "verse": "5",
      "text": "They did more than we had even hoped for! First, they gave themselves to the Lord. Then they also gave themselves to us. They did that because God wanted them to do it."
    },
    {
      "verse": "6",
      "text": "Because of that, we asked Titus to continue to help you. He is the person who helped you to start giving money. So he will help you to finish this good work."
    },
    {
      "verse": "7",
      "text": "You have so much of everything! You trust God very well. You speak well. You know everything. You want to do many good things. You love us even more than we love you! So also do the best that you can as you give money to help others."
    },
    {
      "verse": "8",
      "text": "I am not telling you that you must do this. I have told you how much other believers want to give their money. In that way, I want to see if you really love other people who need your help."
    },
    {
      "verse": "9",
      "text": "You know that our Lord Jesus Christ is very kind. He was rich, but he made himself poor to help you. So then, because he became poor, you could become rich."
    },
    {
      "verse": "10",
      "text": "This is what I think you should do. Last year, you were the first people to give money. You really wanted to do that. So the best thing for you is to finish what you started to do."
    },
    {
      "verse": "11",
      "text": "Now finish the work. When you started, you wanted very much to do it. Now you should want just as much to finish it. You should give what you are able to give."
    },
    {
      "verse": "12",
      "text": "If you really want to give, then God will accept your gift. God does not want you to give more than you are able to give. He will be happy about what you can give."
    },
    {
      "verse": "13",
      "text": "My purpose is not to bring trouble to you. You should not have pain while other people have plenty. Instead, both you and they should have enough. ‘The person who picked up a lot did not have too much. And the person who picked up a small amount also had enough. ’"
    },
    {
      "verse": "14",
      "text": "At this time, you yourselves have plenty. So you are able to give to those people who do not have enough. One day, things may change. They may have plenty, and you may not have enough. Then they can give money to help you. In that way, you will all have enough when you need it."
    },
    {
      "verse": "15",
      "text": "It says this in the Bible:‘The person who picked up a lot did not have too much. And the person who picked up a small amount also had enough. ’"
    },
    {
      "verse": "16",
      "text": "Titus wants to help you just as much as we do. We thank God that he has made Titus ready to do that."
    },
    {
      "verse": "17",
      "text": "He was very happy when we asked him to come to you. He himself already wanted to help you. So he really decided to visit you for himself."
    },
    {
      "verse": "18",
      "text": "We are sending another man with Titus. He is also a believer. The Christians in all the other churches praise this man. They say that he works hard to tell people the good news about Christ."
    },
    {
      "verse": "19",
      "text": "Those Christians in the other churches have also chosen this man to travel with us. They want him to help us when we take this gift. Our work will show that the Lord is great. It will also show that we are ready to help."
    },
    {
      "verse": "20",
      "text": "We want to be very careful about this large gift of money. That is why the other believer will come with us. We do not want anyone to say that we have done something wrong."
    },
    {
      "verse": "21",
      "text": "Our purpose is to do only what is right. We want the Lord to see that, and people must see it as well."
    },
    {
      "verse": "22",
      "text": "We will also send another believer along with the other men. This man has always shown us that we can trust him. He has wanted to help in many different ways. Now that he is very sure about you, he wants to help even more."
    },
    {
      "verse": "23",
      "text": "As for Titus himself, he works along with me, to help you. The other believers are coming on behalf of the churches that sent them. They want to show that Christ is great."
    },
    {
      "verse": "24",
      "text": "So show these men that you love them. Then all the churches will be sure about you. They will know that we were right to be proud of you."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "I do not need to write to you about the money that you want to send to God's people in Jerusalem."
    },
    {
      "verse": "2",
      "text": "I know that you want to help very much. I have told the believers in Macedonia how good you are. I tell them that you believers in Achaia have been ready to give your money since last year. Because you are so ready to help, most of them now also want to help."
    },
    {
      "verse": "3",
      "text": "But I do not want the way that I have praised you not to be true. So I am sending these men, our Christian friends, to come to you. I want to be sure that you will be ready to give your money. That is what I have told people about you."
    },
    {
      "verse": "4",
      "text": "Perhaps some believers from Macedonia might come with me. If you are not ready when we come, we would be ashamed. We would be ashamed because we trusted you. And I think that you would be ashamed as well!"
    },
    {
      "verse": "5",
      "text": "So I decided to tell these men to visit you before I come myself. They will help you to prepare the gift that you promised. Then it will be ready when I arrive. Everyone will know that you really wanted to give this gift. Nobody has made you give it."
    },
    {
      "verse": "6",
      "text": "Remember this: If a farmer plants only a few seeds, he will not get much as a result. But if he plants plenty of seeds, he will get a big harvest."
    },
    {
      "verse": "7",
      "text": "Each of you should think carefully and then decide how much you can give. Then you will not be sad to give that money. Nobody has made you give it. God loves someone who is happy to give help to other people."
    },
    {
      "verse": "8",
      "text": "Since God loves you, he is able to give you more than you need. You will always have every good thing that you need for yourselves. And you will have enough to do many good things to help other people. ‘He has shared his things with many poor people. God will always remember how kind that person has been. ’"
    },
    {
      "verse": "9",
      "text": "The Bible says this about someone who helps other people:‘He has shared his things with many poor people. God will always remember how kind that person has been. ’"
    },
    {
      "verse": "10",
      "text": "It is God who supplies seeds for the farmer to plant. It is God who supplies bread for food. God will help you in the same way. He will give you plenty of things so that you can help other people. You will be like a farmer who plants many seeds. And God will cause those seeds to grow. There will be many good results from the help that you give to other people. That will be like a great harvest."
    },
    {
      "verse": "11",
      "text": "God will make you rich with many good things. As a result, you will always be able to give plenty to other people. Many people will thank God because of your gifts that we take to them."
    },
    {
      "verse": "12",
      "text": "This good work that you are doing is helping God's people. It is helping to supply what they need. And it is not only doing that. It is also causing many people to thank God very much."
    },
    {
      "verse": "13",
      "text": "Your gift of money will show people that you really want to help. People will say that God is great. They will see that you want to obey God. They will see that you are happy to give to them, and to everyone else. They will see that you really believe the good news about Christ, as you say you do."
    },
    {
      "verse": "14",
      "text": "They will want to thank you. They will pray to God for you. They will do that because they see how very kind God has been to you."
    },
    {
      "verse": "15",
      "text": "Yes, we should all thank God for his very great gift. That gift is too great to describe it with words!"
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "I, Paul, need to ask you something. Perhaps you think that I am only humble when I am present there with you. You think that I only speak strongly to you when I am far away! Now I am away from you. But I am still humble and kind, like Christ is."
    },
    {
      "verse": "2",
      "text": "So please listen to what I am asking you. Some people among you think that we live like people who belong to this world. When I come to visit you, I am sure that I will be brave enough to speak against those people. But I do not want to have to speak strongly like that against all of you."
    },
    {
      "verse": "3",
      "text": "It is true that we live in this world as humans. But we do not use our human ideas to fight against what is wrong."
    },
    {
      "verse": "4",
      "text": "It is like we are fighting in a war, but we do not use human weapons. Instead we use God's weapons. Those weapons are powerful enough to destroy the enemy's strong places. We use those weapons to destroy people's wrong ideas."
    },
    {
      "verse": "5",
      "text": "People may speak proud ideas that stop other people from knowing God. We show that those ideas are completely wrong. We change the way that people think, so that they want to obey Christ."
    },
    {
      "verse": "6",
      "text": "You must show that you are ready to obey completely. Then we will be ready to punish anyone who refuses to obey in any way."
    },
    {
      "verse": "7",
      "text": "Take a careful look at what is happening among you. If anyone is sure that he belongs to Christ, he should remember this: We also belong to Christ, just as he does."
    },
    {
      "verse": "8",
      "text": "You may think that I am too proud of my authority. But it is the Lord who has given that authority to us apostles. We have that authority so that we can help you become stronger as believers. We do not have it so that we can destroy you! So I am not ashamed to be proud of this."
    },
    {
      "verse": "9",
      "text": "When I write letters to you, I am not trying to frighten you. Please do not think that."
    },
    {
      "verse": "10",
      "text": "Some people say: ‘Paul's letters are powerful and they say strong things. But when he himself is here with us, he seems to be weak. And the words that he speaks have no value. ’"
    },
    {
      "verse": "11",
      "text": "Anyone who says things like that should understand this: There is no difference between what we write and what we do. When we come to you, we will do what we have written in our letters."
    },
    {
      "verse": "12",
      "text": "Some people praise themselves. They say how clever they are. But we could never do that. We could not even try to be like those people. But they do not understand anything. They decide among themselves how good they are. They look at one another to see if they are better or worse."
    },
    {
      "verse": "13",
      "text": "As for us, we will only be proud of the work that God has given us to do. We will not be proud of anything more than that. And that includes our work among you."
    },
    {
      "verse": "14",
      "text": "We were the first people to come as far as Corinth and tell you the good news about Christ. That was part of the work that God has given to us to do. So it is right for us to tell you how proud we are."
    },
    {
      "verse": "15",
      "text": "We do not praise ourselves for the work that other people have done. That would not be right. But we hope that you will continue to believe more and more strongly. In that way our work among you will become even greater. But it will still be the work that God has given to us, and no more than that. ‘If you want to be proud about something, be proud of what the Lord has done. ’"
    },
    {
      "verse": "16",
      "text": "Then we want to tell God's good news to people in places beyond where you are. Those are not places where God has sent other people to work. Then we will not be praising ourselves for the work that anyone else has done."
    },
    {
      "verse": "17",
      "text": "The Bible says this:‘If you want to be proud about something, be proud of what the Lord has done. ’"
    },
    {
      "verse": "18",
      "text": "Who is really good? It is not the person who praises himself. It is the person that the Lord says is a good person."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "Please be patient with me! I am speaking like a fool. I know that you are being patient with me already!"
    },
    {
      "verse": "2",
      "text": "God wants to keep you for himself. And that is what I want too. I have brought you to Christ, like a pure bride who marries one husband. I want you to be pure and to belong only to him."
    },
    {
      "verse": "3",
      "text": "Remember how the snake deceived Eve. Because he was clever, she believed his lies. I am afraid that the same thing might happen to you. False teachers may make you believe wrong things. Then you will no longer love Christ in a pure and honest way."
    },
    {
      "verse": "4",
      "text": "You are ready to listen to any false teachers who come to you. They might tell you about a different Jesus from the Jesus that we told you about. They might want you to receive a different spirit from the Spirit that you received from us. They might tell you a different kind of good news from the message that you heard from us. You seem to accept all this!"
    },
    {
      "verse": "5",
      "text": "Those teachers call themselves very special apostles. But I think that I am as special as they are!"
    },
    {
      "verse": "6",
      "text": "Perhaps I do not speak as well as they speak. But I do know what I am speaking about. We have always made this very clear to you in everything that we do."
    },
    {
      "verse": "7",
      "text": "When I told you God's good news, I never asked you to pay me anything. I made myself less important so that you could be more important. I do not think that I was wrong to do that."
    },
    {
      "verse": "8",
      "text": "Believers in other churches gave money to me so that I could serve you. It is like I was robbing them so that I could help you."
    },
    {
      "verse": "9",
      "text": "When I was there with you, I never made you help me. Even when I needed something, I did not cause trouble to anyone. Instead, the believers who came from Macedonia gave me everything that I needed. I was very careful never to cause you to have trouble. And I will continue to be careful like that."
    },
    {
      "verse": "10",
      "text": "The message that I speak about Christ is true. So I will continue to be proud of how I lived among you. Nobody in the whole region of Achaia can stop me doing that."
    },
    {
      "verse": "11",
      "text": "You must not think that I say this because I do not love you. God himself knows that I love you."
    },
    {
      "verse": "12",
      "text": "Yes, I will continue to work among you in the way that I am already doing. I will not take any pay from you. Then there will be no chance for those other teachers to be proud about themselves. They will not be able to say that they work in the same way that we do."
    },
    {
      "verse": "13",
      "text": "Those people are false apostles. They do not work in an honest way. They try to make people think that Christ has sent them as his apostles."
    },
    {
      "verse": "14",
      "text": "That should not surprise you! Even Satan can change himself to look like an angel who belongs to the light."
    },
    {
      "verse": "15",
      "text": "So do not be surprised when Satan's servants do the same thing. They can also seem to be serving God. They may seem to be doing good things, but really what they do is bad. So God will punish them in the end."
    },
    {
      "verse": "16",
      "text": "I say this again: nobody should think that I am a fool. But even if you do think that, still listen to me. Give me a chance to praise myself a little, as a fool would do."
    },
    {
      "verse": "17",
      "text": "When I say good things about myself like this, it is not how the Lord would talk. No, these are the words of a fool."
    },
    {
      "verse": "18",
      "text": "But many other people are using human ideas to praise themselves. So I will also do that."
    },
    {
      "verse": "19",
      "text": "You think that you are very wise! So you are happy to listen to fools."
    },
    {
      "verse": "20",
      "text": "You accept people who make you like their slaves. You accept people who cheat you, or take things from you. You accept people who are proud of themselves. Even if someone hits you in your face, you still accept him."
    },
    {
      "verse": "21",
      "text": "But we were not brave enough to do things like that to you. Should I be ashamed of that? But other people are brave enough to praise themselves. So I will also be proud of the same things. (Now I am talking like a fool! )"
    },
    {
      "verse": "22",
      "text": "Are they proud that they are Hebrew people? So am I. Do they belong to Israel's people? So do I. Are they descendants of Abraham's family? So am I."
    },
    {
      "verse": "23",
      "text": "Are they Christ's servants? I serve him even better than they do! (Now I am speaking like a crazy person. ) I work much more than they have worked. I have been in prison more often than they have. People have hit me with whips very many times. I have nearly died many times."
    },
    {
      "verse": "24",
      "text": "At five different times, the Jewish leaders punished me with whips. Each time they hit me 39 times."
    },
    {
      "verse": "25",
      "text": "Three times the Romans punished me with sticks. People threw stones at me to kill me once. Three times I have been on ships that broke in the sea. Once I was in the sea for a night and a day."
    },
    {
      "verse": "26",
      "text": "I have travelled on many journeys. I have been in danger from rivers and also from robbers. I have been in danger from my own people and also from Gentiles. I have been in danger in cities and also in the wilderness. I have been in danger on the sea. I have been in danger from false believers."
    },
    {
      "verse": "27",
      "text": "I have worked very hard, and I have been in pain. Many times I have not slept. I have often been hungry and thirsty. Many times I have had no food. I have often been cold and without enough clothes."
    },
    {
      "verse": "28",
      "text": "All these troubles have happened to me. But also, every day I have trouble in my mind. I worry about the believers in all the churches."
    },
    {
      "verse": "29",
      "text": "When one of these believers is weak, then I feel weak too. When something causes one of them to do something wrong, then I am very upset."
    },
    {
      "verse": "30",
      "text": "If I must be proud about myself, I will only be proud of things that show my weakness."
    },
    {
      "verse": "31",
      "text": "I am not telling lies. God, the Father of the Lord Jesus, knows that. He is the one that we should praise for ever."
    },
    {
      "verse": "32",
      "text": "When I was in Damascus, the ruler of that city sent soldiers to catch me. He was under the authority of King Aretas. The soldiers were watching carefully outside the city."
    },
    {
      "verse": "33",
      "text": "But my friends put me in a basket on the end of a rope. They sent me out through a window in the city wall and they let me drop to the ground. That is how I got away from the ruler of the city."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "I must continue to praise myself. It will not really help you, but I will tell you anyway. The Lord has shown me special things, like in a dream."
    },
    {
      "verse": "2",
      "text": "I know a certain man who belongs to Christ. 14 years ago, God quickly took this man up to the third heaven. Perhaps this man was still in his body. Perhaps he had gone away from his body. I do not know. Only God knows."
    },
    {
      "verse": "5",
      "text": "I will say proud things about a man like that. But I will not be proud of anything good about myself. I will only be proud of things that show my weakness."
    },
    {
      "verse": "6",
      "text": "If I did want to praise myself, that would not make me a fool. No, because I would be saying true things. But I will not say good things about myself. I want everyone to think properly about me. People should look at how I live. They should think about what I say. That is enough for them to decide about me."
    },
    {
      "verse": "7",
      "text": "Yes, God did show me many things that were very special. But he did not want me to be proud because of that. So he gave me a pain in my body, like a sharp thorn. Satan uses that pain to give me much trouble. It is like Satan's angel that he sends to hurt me. That certainly stops me from being proud of myself!"
    },
    {
      "verse": "8",
      "text": "I asked the Lord three times to take this pain away from me."
    },
    {
      "verse": "9",
      "text": "But he said to me, ‘I will be kind to you and I will help you. That will be enough for you. When you are weak, I will show that I am completely powerful to help you. ’So I am happy to be proud about my weakness. Then I know that Christ's power will be with me."
    },
    {
      "verse": "10",
      "text": "That is why I am happy even when I am weak. People may insult me. They may bring me trouble. They may want to hurt me. I may have many kinds of trouble. But I am still happy because I am serving Christ. Yes, whenever I am weak, then I am strong."
    },
    {
      "verse": "11",
      "text": "I am speaking like a proud fool, but you have made me do it. You yourselves should be saying good things about me. I may not be important. But I am as good as those very special apostles."
    },
    {
      "verse": "12",
      "text": "When I was there with you, I showed that I was a true apostle. I worked patiently among you. I did many miracles and great things that showed God's power."
    },
    {
      "verse": "13",
      "text": "I worked among you in the same way as I did with the other churches. You were never less important to me than they are. The only difference is that I did not ask you to help me with money. So perhaps I should ask you to forgive me for that!"
    },
    {
      "verse": "14",
      "text": "Listen to me! This is the third time that I am ready to visit you. I will not ask you to give anything to me. I do not want any of your things. Instead, I want you yourselves. You are like my children. Children should not have to supply what their parents need. It is parents who should supply what their children need."
    },
    {
      "verse": "15",
      "text": "So I will be happy to give everything that I have to you. I will be happy to give myself too, because I want to help you. Perhaps I love you too much! But that should not mean that you will love me less than you should."
    },
    {
      "verse": "16",
      "text": "I did not give you trouble. You surely know that. But some of you say that I deceived you. You think that I was clever and I got money from you."
    },
    {
      "verse": "17",
      "text": "That is not true! When I sent people to you, they never cheated you on my behalf."
    },
    {
      "verse": "18",
      "text": "I asked Titus to come and visit you, and I sent another Christian friend with him. But Titus certainly did not deceive you to get anything from you. Both he and I have always been completely honest with you. We both think in the same way."
    },
    {
      "verse": "19",
      "text": "What are you thinking when you read all this? Do you think that we want to show you how good we are? No, we are speaking as people who belong to Christ. God knows us. Everything that we do is to help you. We love you and we want to make you stronger as believers."
    },
    {
      "verse": "20",
      "text": "When I come there to visit you, I hope you will be living in a good way. But I am afraid that I will not see what I want to see. Then you will see that I am different from what you want me to be! I am afraid that you may be quarrelling. You may be jealous of each other. You may be very angry with each other. Some of you may just want to please yourselves. You may be insulting one another, or telling lies about one another. You may be proud of how good you are. You may be causing trouble for one another. Yes, I am afraid that all those things may be happening among you."
    },
    {
      "verse": "21",
      "text": "I am afraid that I may be very sad when I come back to you. My God may cause me to feel ashamed about you. Some of you may still be doing bad and disgusting things. You may be having sex with people that you are not married to, or in other wrong ways. Those are the bad things that many of you did at one time. If you have not turned away from those bad things, that will make me weep."
    },
    {
      "verse": "3",
      "text": "I know that God took this man up to paradise. I do not know whether this man was still in his body or not. Only God knows. When this man was in heaven, he heard about secret things."
    },
    {
      "verse": "4",
      "text": "Those are things that no words can describe. God will not let any person speak about those things. They are too special."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "This is the third time that I will be coming to visit you. Remember this: ‘There must be two or three people to say certainly that another person has done something wrong. Two or three people must agree what has happened. ’"
    },
    {
      "verse": "2",
      "text": "I have already warned those people who did wrong things before. I did that when I was with you on my second visit. Now I am warning them again, while I am away from you. So, when I come to you the next time, nobody will go free. I will punish those people and all the others who have done wrong things."
    },
    {
      "verse": "3",
      "text": "That will tell you what you want to know about me. You will surely know that I speak with the authority of Christ himself. Christ is not weak when he works in you. He shows his power among you."
    },
    {
      "verse": "4",
      "text": "People killed Christ on the cross as a weak person. But he now lives by God's power. We are also weak as we serve Christ, like he was weak. But we live, because he now lives. So, when we come to you, we will show God's power among you."
    },
    {
      "verse": "5",
      "text": "Think carefully about how you are living. Are you really believing the message about Christ? I hope you know that Jesus Christ is in you. You ought to know that, unless you have completely failed."
    },
    {
      "verse": "6",
      "text": "I hope that you will know that we ourselves have not failed. We do belong to Christ, as you do."
    },
    {
      "verse": "7",
      "text": "Now we pray to God that you will not do any wrong things. We do not pray this to show that God has accepted us as good. We pray like that because we want you to do what is right. We want that, even if we ourselves seem to have failed."
    },
    {
      "verse": "8",
      "text": "We can only work to show what is true. We cannot do anything against what is true."
    },
    {
      "verse": "9",
      "text": "We are happy when we seem to be weak, if you become strong as a result. We pray that you will become completely as you should be."
    },
    {
      "verse": "10",
      "text": "That is why I am writing these things to you now, while I am away from you. Then, when I arrive, I will not need to be angry with you. I will not have to use my authority to punish you. The Lord gave that authority to me to help you to become stronger as believers. He did not give it to me so that I could destroy you."
    },
    {
      "verse": "11",
      "text": "Now I say ‘goodbye’ to you, my Christian friends. Do only what is right. Let my message make you strong. Agree with each other. Live together in peace. I pray that God will be with you. He is the one who loves us and gives us peace in our minds."
    },
    {
      "verse": "12",
      "text": "When you meet, kiss each other as Christian brothers and sisters."
    },
    {
      "verse": "13",
      "text": "All God's people here say ‘hello’ to you."
    },
    {
      "verse": "14",
      "text": "I pray that the Lord Jesus Christ will continue to be very kind to you all. I pray that God's love will be with you. And I pray that the Holy Spirit will help you to serve each other as friends."
    }
  ]
};