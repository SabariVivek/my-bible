module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "We have an important message to tell you. We want to tell you about the person who was already there before the beginning of the world. We have heard him speak. We have seen him with our own eyes. We watched him and we touched him. He is the Word that gives us life with God."
    },
    {
      "verse": "2",
      "text": "He showed himself clearly when he lived on this earth. From long ago he was together with God the Father, and he lives for ever. We saw him and we are telling you what is true. He is the one who has shown himself to us."
    },
    {
      "verse": "3",
      "text": "We also want you to share this new life with us. We share this life with God the Father and Jesus Christ his Son. That is why we are telling you about everything that we have seen and heard."
    },
    {
      "verse": "4",
      "text": "We are writing to you so that together we all may be completely happy."
    },
    {
      "verse": "5",
      "text": "We are telling you the good news that Jesus Christ told to us. This is the message: God is completely good and clean. He is like light. There is nothing dark about him."
    },
    {
      "verse": "6",
      "text": "Do you say that you share in the life that God gives? If you say that, but if you still live in the dark, you are telling a lie. You are not living in God's true way."
    },
    {
      "verse": "7",
      "text": "But when we live in a right way, it is like living in the light. God is always in the light. So, if we live in the light, we share together in the life which God gives. And when Jesus, the Son of God, died on the cross, he saved us from all our sins. The blood of his sacrifice makes us clean."
    },
    {
      "verse": "8",
      "text": "If we say that we never do any wrong thing, we are deceiving ourselves. Even though we may think it is true, it is a lie."
    },
    {
      "verse": "9",
      "text": "Instead, we should agree that we have done wrong things and tell that to God. Then God will forgive us for our sins. He always does what he has promised to do. He always does what is right. He will forgive us and he will make us clean again, whatever bad things we may have done."
    },
    {
      "verse": "10",
      "text": "God says that all people have done wrong things. So, if we say that we have not done any wrong thing, we are saying that God tells lies. It shows that we have not accepted his message at all."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "I am writing this letter to you, my friends who are like my little children. I am writing to you because I do not want you to do wrong things. But if anyone among you does something wrong, there is someone who will speak to God on our behalf. That person is Jesus Christ, who always does only what is right. He will ask our Father God to forgive you."
    },
    {
      "verse": "2",
      "text": "Jesus died as a sacrifice to take the punishment for our sin. Then God could forgive us. Jesus did that not only for us. He did it for all people in the world, so that God could forgive them for their sins."
    },
    {
      "verse": "3",
      "text": "This is how we can be sure that we know God: If we obey God's commands, we know that we belong to him."
    },
    {
      "verse": "4",
      "text": "Someone may say, ‘I belong to God. ’ But if he does not obey God's commands, that person is telling a lie. He is not living in the way that God's true message teaches us."
    },
    {
      "verse": "5",
      "text": "But anyone who obeys God's message shows that he really loves God completely. So this is how we know that we belong to God."
    },
    {
      "verse": "6",
      "text": "If we say that we are living in God's true way, then we must live in the way that Jesus lived."
    },
    {
      "verse": "7",
      "text": "My friends, I am telling you to love one another. When I write this to you, I am not giving you a new rule. It is an old rule that you have had for a long time. We gave it to you when you began to obey Christ. It is the same message that you have already heard."
    },
    {
      "verse": "8",
      "text": "But there is something new about it. This rule has become true in the way that Christ lived. Now it has also become true in your lives. God's true message has brought light to shine in your lives. You no longer live in the dark where you do bad things."
    },
    {
      "verse": "9",
      "text": "A person may say that he is living in the light. But if that person hates another believer, then he is telling a lie. He is still living in the dark."
    },
    {
      "verse": "10",
      "text": "Anyone who loves other believers shows that he is living in the light. There is nothing that will make him turn away from God."
    },
    {
      "verse": "11",
      "text": "But if someone hates other believers, he is still living in a bad way. He is like someone who is walking in the dark. He cannot see where he is going. He is like a blind person. He cannot understand God's true message."
    },
    {
      "verse": "12",
      "text": "My little children, I am writing to you because God has forgiven your sins. He has done this because of Christ."
    },
    {
      "verse": "13",
      "text": "You who are older, like fathers, I am writing to you because you know Christ. He has always been there, since before the world began. You who are young men, I am writing to you because you have won against Satan. You who are young men, I am writing to you because you have won against Satan."
    },
    {
      "verse": "14",
      "text": "Yes, my children, I have written to you because you know God, our Father. Fathers, I have written to you because you know Christ. He was already there before the world began. Young men, I have written to you because you are strong. You continue to obey God's message, and you have won against Satan. Fathers, I have written to you because you know Christ. He was already there before the world began. Young men, I have written to you because you are strong. You continue to obey God's message, and you have won against Satan."
    },
    {
      "verse": "15",
      "text": "Do not live like people who do not know God. Do not love the wrong things that belong to this world. If anyone loves those things, it shows that they do not love God, their Father."
    },
    {
      "verse": "16",
      "text": "What are the wrong things that belong to this world? People want to do bad things to make themselves happy. People want to have things that they see, even bad things. People want to show other people how rich they are. These ideas do not come from God, our Father. They are the thoughts of people who belong to the world."
    },
    {
      "verse": "17",
      "text": "One day, those people and the things that they want will not be there any longer. But those who continue to do what God wants will live for ever."
    },
    {
      "verse": "18",
      "text": "My children, the world will soon end. You have heard that the enemy of Christ will appear. You can see that many enemies of Christ have already appeared. This shows us that the world will end soon."
    },
    {
      "verse": "19",
      "text": "These people used to be in our group of believers. But they left us. They never really belonged to our group. If they had been true believers, they would have remained with us. When they left us, it showed clearly that none of them really belonged to us."
    },
    {
      "verse": "20",
      "text": "But Christ, the Holy One, has given you the Holy Spirit. As a result, you all know what is true."
    },
    {
      "verse": "21",
      "text": "That is why I am writing to you. It is not because you do not yet know God's true message. I am writing to you because you do know that true message. And you can be sure that there are no lies in it."
    },
    {
      "verse": "22",
      "text": "Who is the one who tells the worst lies? It is anyone who says that Jesus is not the Messiah. A person like that is the enemy of Christ. He is speaking against God, the Father, and against Jesus, his Son."
    },
    {
      "verse": "23",
      "text": "Anyone who says that Jesus is not God's Son does not belong to the Father. But anyone who accepts Jesus as the Son of God also belongs to the Father."
    },
    {
      "verse": "24",
      "text": "As for you, always remember the true message that you heard at the beginning. If you continue to believe that message, you will continue to live with the Son and with the Father."
    },
    {
      "verse": "25",
      "text": "That is the real life that continues for ever. And that is what God has promised to give to us."
    },
    {
      "verse": "26",
      "text": "Some people are trying to lead you away from God's true message. I am writing these things to you so that you know about these people."
    },
    {
      "verse": "27",
      "text": "But Christ has given the Holy Spirit to you, and he continues to help you. So you do not need people to teach you what is true. The Holy Spirit himself teaches you everything about God's message. He helps you to know what is true. He does not tell you any lies. So you must remember what he has taught you. Continue to live together with Christ."
    },
    {
      "verse": "28",
      "text": "Yes, my children, continue to live with Christ. Then we will not be ashamed when he returns to this world. We will not be afraid to meet him."
    },
    {
      "verse": "29",
      "text": "You know that Christ only does what is right. So you should know this: Everyone who continues to do what is right has become a child of God."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "Think about how much God the Father loves us. He calls us his children! God loves us so much that we really have become his children. The people who belong to this world do not understand who God is. Because of that, they do not understand who we are."
    },
    {
      "verse": "2",
      "text": "My friends, we are already children of God. We do not yet know clearly what we will become. But we do know this: when Christ returns to this world, we will become like him. We will be like him because we will see him as he really is."
    },
    {
      "verse": "3",
      "text": "Christ is completely good. So all of us who hope to see him then must keep ourselves clean from sin."
    },
    {
      "verse": "4",
      "text": "If a person continues to do wrong things, he is choosing not to obey God's rules. Sin is when we do not obey God's rules."
    },
    {
      "verse": "5",
      "text": "You know that Jesus came into the world so that he might take away our sins. He himself is completely clean from sin."
    },
    {
      "verse": "6",
      "text": "Anyone who lives together with Christ does not continue to do wrong things. If anyone continues to do wrong things, that person has not understood who Christ is. He does not know Christ."
    },
    {
      "verse": "7",
      "text": "My little children, do not let anyone deceive you about sin. It is people who live in a good way that God accepts as right. In the same way, Jesus did only what is good and right."
    },
    {
      "verse": "8",
      "text": "People who continue to do wrong things show that they belong to the Devil. The Devil has always been doing wrong things from the beginning. This is why the Son of God came to the world. He came to destroy everything that the Devil has done."
    },
    {
      "verse": "9",
      "text": "Everybody who is a child of God does not continue to do wrong things. This is because God has given them a new life. He has caused them to become his children. So they cannot continue to do wrong things."
    },
    {
      "verse": "10",
      "text": "In this way, we can see clearly who are God's children and who are the Devil's children. Anyone who does not live in a way that is good and right does not belong to God. People like that do not love other believers."
    },
    {
      "verse": "11",
      "text": "Yes, we must love one another. That is the message which you have heard from the beginning."
    },
    {
      "verse": "12",
      "text": "We should not be like Cain. He belonged to Satan and he even killed his brother, Abel. Why did he do that? Cain did bad things and he killed Abel because Abel did things that were right."
    },
    {
      "verse": "13",
      "text": "So, my Christian friends, do not be surprised when people who belong to this world hate you."
    },
    {
      "verse": "14",
      "text": "We know that we now have new life with God. Death no longer has power over us. We know this because we love our Christian friends. But anyone who does not love other believers is still under the power of death."
    },
    {
      "verse": "15",
      "text": "Anyone who hates other believers is like someone who murders other people. You know that a person like that does not have true life with God."
    },
    {
      "verse": "16",
      "text": "This is how we know what true love is: Jesus Christ gave his own life on the cross. He died on our behalf. So we too ought to give our lives for other believers."
    },
    {
      "verse": "17",
      "text": "When another believer has trouble, we need to be kind to him. Maybe you have all the things that you need to live. If you see another believer who needs things like that, you should help him. If you refuse to be kind to him, it shows that you do not belong to God. You do not love people in the way that God loves them."
    },
    {
      "verse": "18",
      "text": "My little children, we should not show love for each other only by what we say. We should also show true love by the things that we do."
    },
    {
      "verse": "19",
      "text": "Then we will know that we truly belong to God. We will be obeying God's true message. As a result, our thoughts will not make us ashamed to come to God."
    },
    {
      "verse": "20",
      "text": "Even if our thoughts tell us that we have done something wrong, we still will not be afraid of God. We can trust God more than we trust our thoughts. He already knows everything about us."
    },
    {
      "verse": "21",
      "text": "My friends, if our thoughts do not tell us that we are guilty, we will not be afraid to come to God."
    },
    {
      "verse": "22",
      "text": "We can pray to God and we can ask him to help us. He will give us what we ask him for. That is because we obey his commands and we do the things that please him."
    },
    {
      "verse": "23",
      "text": "This is God's command to us: we must believe that Jesus Christ is his Son. And we must love each other, as Jesus commanded us."
    },
    {
      "verse": "24",
      "text": "Anyone who obeys God's commands lives together with God. God also lives in him. How do we know that God lives in us? It is because of his Holy Spirit that he has given to us."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "My friends, do not believe everyone who says that they speak God's message. There are many false prophets who are travelling around everywhere. They say that they have a message from God's Spirit, but the message comes from a false spirit. So check each message carefully to see if it is really from God."
    },
    {
      "verse": "2",
      "text": "How do you know whether a person has God's Spirit in him? He must agree that Jesus is God's Messiah who was born as a human baby. If someone says that, then he has God's Spirit."
    },
    {
      "verse": "3",
      "text": "But if someone does not agree to say that about Jesus, he does not have God's Spirit. That person has a spirit that comes from the enemy of Christ. You have heard that this enemy of Christ would come among us. Now this spirit is already here in the world."
    },
    {
      "verse": "4",
      "text": "My little children, you belong to God. You have won against those people with a false message. You have been able to do that because God's Holy Spirit is in you. He is more powerful than the spirit that belongs to this world. So that is how we know if someone's message comes from God's Spirit or not. God's Spirit brings us a true message, but false spirits tell lies."
    },
    {
      "verse": "5",
      "text": "Those false prophets belong to this world. Their message comes from the ideas of people of this world. So the people of this world believe what they teach."
    },
    {
      "verse": "6",
      "text": "But we belong to God. Everyone who knows God believes our message. But anyone who does not belong to God does not believe it. So that is how we know if someone's message comes from God's Spirit or not. God's Spirit brings us a true message, but false spirits tell lies."
    },
    {
      "verse": "7",
      "text": "My friends, we should all love each other. It is God who makes us able to love other people. Everyone who loves other people has become a child of God. That person knows God."
    },
    {
      "verse": "8",
      "text": "Anyone who does not love other people does not know God. We know this because God's own nature is love."
    },
    {
      "verse": "9",
      "text": "This is how God showed that he loves us: He sent his only Son to come and live in the world. He did that so that we could have true life with God because of his Son."
    },
    {
      "verse": "10",
      "text": "This shows what love is: It is not that we have loved God, but that he loved us. He loved us so much that he sent his Son to save us from sin. He sent Jesus to die as a sacrifice, to take the punishment for our sins."
    },
    {
      "verse": "11",
      "text": "My friends, this shows how much God has loved us. So we should also love one another."
    },
    {
      "verse": "12",
      "text": "Nobody has ever seen God. But, if we love each other, it shows that God lives in us. As a result, we can love people completely, in the same way that God loves us."
    },
    {
      "verse": "13",
      "text": "God has given us his Holy Spirit to live in us. Because of this, we know that we live together with God. And we know that he lives with us."
    },
    {
      "verse": "14",
      "text": "God the Father sent his Son to come into the world. God sent him to save the people of the world from their sins. We apostles have seen that this is true. So now we are telling people about it."
    },
    {
      "verse": "15",
      "text": "If anyone says clearly that Jesus is the Son of God, God lives in that person. And that person lives together with God."
    },
    {
      "verse": "16",
      "text": "So we know the kind of love that God has for us. We believe that God has put that love in us. God's nature is love. So, if someone continues to love other people, he is living together with God. And God lives in him."
    },
    {
      "verse": "17",
      "text": "That is how we are able to love other people completely. Then, we will not be afraid on the day when God will judge all people. We can be sure that God will not punish us. We know this because we have lived in this world in the way that Jesus lived."
    },
    {
      "verse": "18",
      "text": "If we really love God, we will not be afraid of him. We cannot love him completely and also be afraid. We would only be afraid of God if we thought that he would punish us. So, if someone is afraid that God will punish them, it shows that they do not completely know God's love."
    },
    {
      "verse": "19",
      "text": "We are able to love God and other people because God loved us first."
    },
    {
      "verse": "20",
      "text": "Someone may say, ‘I love God. ’ But if he says that and he hates another Christian, he is telling a lie. He sees other believers but he does not love them. So he surely cannot love God that he has not seen."
    },
    {
      "verse": "21",
      "text": "This is the command that God has given us. He has told us that anyone who loves him should love other Christians too."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Everyone who believes that Jesus is God's Messiah has become a child of God. And if we love God, our Father, we will love his other children too."
    },
    {
      "verse": "2",
      "text": "How do we know that we love God's children? We know it when we love God and we do what he tells us to do."
    },
    {
      "verse": "3",
      "text": "Because, if we really love God, we will obey his commands. And those commands are not difficult for us to obey."
    },
    {
      "verse": "4",
      "text": "Because we have become God's children, we can live in a good way. We can refuse to live like people who belong to this world. We are able to win against the wrong ways of this world because we trust Jesus Christ."
    },
    {
      "verse": "5",
      "text": "It is only people who believe that Jesus is the Son of God who can do that. Only they can win against the wrong ways of this world."
    },
    {
      "verse": "6",
      "text": "Jesus Christ is the man that God sent into the world. John baptized Jesus in water. When Jesus died, his blood poured out. God showed that Jesus is his Son with the water and with the blood. It was not only with the water of Jesus' baptism. It was also with the blood of his death. God's Holy Spirit also shows us that Jesus is God's Son. The Holy Spirit always says what is true."
    },
    {
      "verse": "7",
      "text": "So there are three things that show us clearly that Jesus came from God."
    },
    {
      "verse": "8",
      "text": "Those things are the Holy Spirit, the water of Jesus' baptism and the blood of his death on the cross. These all show us the same thing, that Jesus came from God."
    },
    {
      "verse": "9",
      "text": "We believe people who tell us about things that they know. So we can believe even more what God says. He has told us what is true about his Son. So we should believe his message."
    },
    {
      "verse": "10",
      "text": "Anyone who believes in Jesus, the Son of God, will know that what God says is true. But anyone who does not believe God is saying that God tells lies. He does not believe the message that God has told us clearly about his Son."
    },
    {
      "verse": "11",
      "text": "This is what God has told us: God has given us life with him that never ends. We receive this life when we believe in his Son, Jesus."
    },
    {
      "verse": "12",
      "text": "So whoever belongs to the Son has this true life. But anyone who does not belong to the Son of God does not have this true life."
    },
    {
      "verse": "13",
      "text": "I have written these things to you who believe that Jesus is the Son of God. I want you to know that you have true life with God for ever."
    },
    {
      "verse": "14",
      "text": "Also, we can trust God to help us when we turn to him. We know that he will hear us. When we ask for anything that he wants us to have, he listens to us."
    },
    {
      "verse": "15",
      "text": "Since we know that, we also know that God will give to us the things that we ask for. It is like we have already received those things from him."
    },
    {
      "verse": "16",
      "text": "If you see that another Christian is doing something bad, this is what you should do. If it is a sin that does not cause death, pray that God will help him. Then God will help that person to live for ever with him. That is for a sin which does not cause death. But there is a sin that causes death. If another Christian does that, I am not saying that you should pray for God to help that person."
    },
    {
      "verse": "17",
      "text": "Any wrong thing that a person does is sin. But not all sins cause death."
    },
    {
      "verse": "18",
      "text": "Nobody who has become a child of God continues to do wrong things. Instead, the Son of God keeps him safe. Satan cannot do anything against a child of God."
    },
    {
      "verse": "19",
      "text": "We know that we belong to God. We know that Satan rules all the people who belong to this world."
    },
    {
      "verse": "20",
      "text": "We also know that the Son of God has come into the world. He has helped us to understand what is true. As a result, we know the only true God. We live together with this true God, because we belong to his Son, Jesus Christ. He is the true God. He is the one who gives us life with God for ever."
    },
    {
      "verse": "21",
      "text": "My little children, be careful to keep away from idols."
    }
  ]
};