module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This is the start of the good news about Jesus Christ. He is the Son of God. ‘Listen! I will send someone to prepare a way for you. He will tell people my message."
    },
    {
      "verse": "2",
      "text": "The prophet Isaiah wrote this message from God in his book:‘Listen! I will send someone to prepare a way for you. He will tell people my message."
    },
    {
      "verse": "3",
      "text": "His voice will shout in the wilderness:“The Lord will come soon, so prepare a way for him. Make the paths straight for him. ” ’ “The Lord will come soon, so prepare a way for him. Make the paths straight for him. ” ’"
    },
    {
      "verse": "4",
      "text": "So John went to a place in the wilderness. He baptized people and he spoke a message from God. He said to people, ‘You have done many wrong things. You must turn away from them and change how you live. Then God will forgive you and I will baptize you. ’"
    },
    {
      "verse": "5",
      "text": "Many people who lived in Jerusalem and in the country of Judea went to listen to John. The people told God about all the wrong things that they had done. Then John baptized them in the Jordan River."
    },
    {
      "verse": "6",
      "text": "John wore clothes made from the hair of a camel. He also wore a belt made from leather. His usual food was locusts and honey from the wilderness."
    },
    {
      "verse": "7",
      "text": "John said to the people, ‘Another person will come soon. He is much greater than I am. I am not good enough even to undo his shoes for him."
    },
    {
      "verse": "8",
      "text": "I have baptized you with water. But this man will baptize you with the Holy Spirit. ’"
    },
    {
      "verse": "9",
      "text": "Soon after this, Jesus came from the town of Nazareth in Galilee. John baptized him in the Jordan River."
    },
    {
      "verse": "10",
      "text": "While Jesus was coming up out of the water, he saw the skies open. The Holy Spirit came down like a dove and he stayed on Jesus."
    },
    {
      "verse": "11",
      "text": "A voice spoke from heaven: ‘You are my Son and I love you. You make me very happy. ’"
    },
    {
      "verse": "12",
      "text": "Immediately, the Holy Spirit sent Jesus out into the wilderness."
    },
    {
      "verse": "13",
      "text": "days. During this time, Satan tried to cause him to do wrong things. There were wild animals with Jesus in the wilderness. God's angels took care of him."
    },
    {
      "verse": "14",
      "text": "Later, John was in prison. At that time, Jesus went to Galilee. He told people the good news about God."
    },
    {
      "verse": "15",
      "text": "Jesus said, ‘Now is the time when the kingdom of God has come very near. You have done many wrong things. Turn away from them and change the way that you live. Believe God's good news. ’"
    },
    {
      "verse": "16",
      "text": "One day, Jesus was walking along the shore of Lake Galilee. He saw two brothers called Simon and Andrew. Their job was to catch fish. They were throwing their nets into the lake to catch fish."
    },
    {
      "verse": "17",
      "text": "Jesus said to them, ‘Come with me and be my disciples. Then I will teach you how to catch people, instead of fish. ’"
    },
    {
      "verse": "18",
      "text": "Simon and Andrew immediately put down their nets and they went with Jesus."
    },
    {
      "verse": "19",
      "text": "Jesus continued to walk along the shore. Soon he saw two more men who were brothers. They were called James and John. They were the sons of Zebedee. They were in their boat and they were mending their nets."
    },
    {
      "verse": "20",
      "text": "Immediately, Jesus asked them to come with him. They left their father and his workers in the boat, and they went with Jesus to be his disciples."
    },
    {
      "verse": "21",
      "text": "Then Jesus and those disciples went into a town called Capernaum. On the next Jewish day of rest, Jesus went into the Jews' meeting place. He began to teach the people there."
    },
    {
      "verse": "22",
      "text": "The people were very surprised at the things that Jesus taught them. When he taught them, he showed his authority. That was not like the way that the teachers of God's Law taught people."
    },
    {
      "verse": "23",
      "text": "In the meeting place, there was a man who had a bad spirit. The bad spirit caused the man to shout."
    },
    {
      "verse": "24",
      "text": "He said, ‘Jesus from Nazareth, leave us alone! Do not kill us! I know who you are. You are the Holy One and God has sent you. ’"
    },
    {
      "verse": "25",
      "text": "Jesus said to the bad spirit, ‘Be quiet! Come out of the man! ’"
    },
    {
      "verse": "26",
      "text": "The bad spirit caused the man to shake and to fall down. It shouted loudly and then it came out of the man."
    },
    {
      "verse": "27",
      "text": "All the people were very surprised and they said to each other, ‘This is very strange. This man Jesus is teaching us something new and he speaks with authority. He can tell bad spirits what they must do. Then they do it. ’"
    },
    {
      "verse": "28",
      "text": "Immediately, people began to hear the news about Jesus. Everywhere in Galilee, people were talking about him."
    },
    {
      "verse": "29",
      "text": "Then Jesus left the meeting place. He took James and John with him to the home of Simon and Andrew."
    },
    {
      "verse": "30",
      "text": "The mother of Simon's wife was ill in bed. Her body was very hot. Immediately, Simon and Andrew told Jesus about her."
    },
    {
      "verse": "31",
      "text": "So Jesus went to her and he held her hand. Then he helped her to sit up and she was well again. Immediately she prepared food for her visitors."
    },
    {
      "verse": "34",
      "text": "Jesus caused many sick people to become well. They had many different kinds of illness. He also caused many bad spirits to leave people. The spirits knew who he was. So Jesus did not let them speak."
    },
    {
      "verse": "35",
      "text": "Jesus got up very early the next morning, while it was still dark. He went to a place where he could be alone. He prayed there."
    },
    {
      "verse": "36",
      "text": "Simon and the other disciples went to look for him."
    },
    {
      "verse": "37",
      "text": "When they found him, they said, ‘Everyone is looking for you. ’"
    },
    {
      "verse": "38",
      "text": "Jesus replied, ‘We should go to other towns near here. Then I can teach the people there too. That is the reason why I came here. ’"
    },
    {
      "verse": "39",
      "text": "So Jesus travelled everywhere in Galilee. He taught the people in the Jewish meeting places. He caused bad spirits to come out of people."
    },
    {
      "verse": "40",
      "text": "One day, a man who had a disease of the skin came to Jesus. He went down on his knees in front of Jesus. The man said. ‘If you want, you can make me well. Please do it. ’"
    },
    {
      "verse": "41",
      "text": "Jesus felt very sorry for the man. He put out his hand towards the man and he touched him. ‘I do want to help you, ’ Jesus said, ‘Be clean again! ’"
    },
    {
      "verse": "42",
      "text": "Immediately, the disease left the man."
    },
    {
      "verse": "43",
      "text": "Jesus sent the man away immediately and he spoke to the man with strong words."
    },
    {
      "verse": "44",
      "text": "He said, ‘Listen to me. Do not tell anyone about this. Instead, go and show yourself to the priest. Take him a gift for God. Moses' law tells you what you should give when you are clean again after this kind of disease. This will show everyone that you are now well again. ’"
    },
    {
      "verse": "45",
      "text": "But instead, the man went away and he talked to everybody. He told them what had happened to him. Because he did this, it became too difficult for Jesus to go into the towns. Everybody knew him. So Jesus stayed in places in the wilderness. People came from all the places around there to see him."
    },
    {
      "verse": "32",
      "text": "That evening, when the sun had gone down, people in the town came to Jesus. They brought to him everyone who was ill."
    },
    {
      "verse": "33",
      "text": "And they brought people with bad spirits in them. All these people were standing together near the door of the house."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Several days after that, Jesus returned to Capernaum. People heard the news that he had come back to his home."
    },
    {
      "verse": "2",
      "text": "Many people came into the house. The house was so full that there was no room, even outside the door. Jesus was teaching people about the good news."
    },
    {
      "verse": "3",
      "text": "Four men came. They were carrying another man on a mat. That man could not move his legs."
    },
    {
      "verse": "4",
      "text": "They could not reach Jesus because of the crowd. So they made a hole in the roof above the place where Jesus was. They helped the man to go down through the hole. He was still lying on his mat."
    },
    {
      "verse": "5",
      "text": "Jesus saw the man and his friends. He knew that they believed in him. So he said to the man who could not walk, ‘My friend, I forgive you for your sins. ’"
    },
    {
      "verse": "6",
      "text": "But some teachers of God's Law were sitting there. They thought about the words that Jesus had spoken to the man."
    },
    {
      "verse": "7",
      "text": "They thought, ‘This man Jesus should not have said that. He is speaking as if he is God. Only God can forgive people for their sins. ’"
    },
    {
      "verse": "8",
      "text": "Immediately, Jesus knew in his spirit what the teachers were thinking. He said to them, ‘You should not think these things."
    },
    {
      "verse": "9",
      "text": "I said to this man who cannot walk, “I forgive you for your sins. ” Instead, I could have said to him, “Stand up! Pick up your mat and walk. ” Which of those is easier for me to say?"
    },
    {
      "verse": "10",
      "text": "But I want you to know this. I, the Son of Man, have authority on earth to forgive people for their sins. ’ Then he said to the man who could not walk,"
    },
    {
      "verse": "11",
      "text": "‘I am saying to you, stand up! Pick up your mat and go home. ’"
    },
    {
      "verse": "12",
      "text": "Immediately, the man stood up. He picked up his mat and he walked out of the house. Everyone watched him do this. The people were very surprised. They praised God and they said, ‘God is great. We have never seen anything like this before. ’"
    },
    {
      "verse": "13",
      "text": "Jesus went to the shore of Lake Galilee again. A large crowd came to him, and he taught them."
    },
    {
      "verse": "14",
      "text": "While Jesus was walking along, he saw a man called Levi. Levi was the son of Alphaeus. His job was to take taxes from people. He was sitting in his office. Jesus said to him, ‘Come with me and be my disciple. ’ Levi stood up and he went with Jesus."
    },
    {
      "verse": "15",
      "text": "Then Jesus went to eat a meal at Levi's house. Many people followed Jesus and they ate there with him and with his disciples. Many of these were bad people and also men who took taxes."
    },
    {
      "verse": "16",
      "text": "Some teachers of God's Law who were Pharisees saw what was happening. They said to Jesus' disciples, ‘He is eating with bad people and men who take taxes. That is not right. ’"
    },
    {
      "verse": "17",
      "text": "Jesus heard what these people were saying. He said to them, ‘People who are well do not need a doctor. It is people who are ill that need a doctor. Some people think that they always obey God. I did not come to help people like that. Some people know that they have done wrong things. I am asking those people to come to me for help. ’"
    },
    {
      "verse": "18",
      "text": "At this time, the disciples of John the Baptist and the disciples of the Pharisees were fasting. Some people came to Jesus and they asked him this question: ‘The disciples of John and the disciples of the Pharisees often fast for a time. So why do your disciples never do that? ’"
    },
    {
      "verse": "19",
      "text": "Jesus answered them, ‘When a man marries, his friends cannot refuse to eat. They cannot fast while he is with them."
    },
    {
      "verse": "20",
      "text": "But there will be a time when people will take the man away from his friends. At that time his friends will fast. ’"
    },
    {
      "verse": "21",
      "text": "Then Jesus said, ‘Nobody uses a piece of new cloth to mend an old coat. If he does, the new cloth will cause the old cloth to tear again. It will make a bigger hole than before."
    },
    {
      "verse": "22",
      "text": "And nobody pours new wine into old wineskins. If he does that, the new wine will tear the old wineskins. He will lose the wine and the wineskins will spoil. Instead, you must put new wine into new wineskins. ’"
    },
    {
      "verse": "23",
      "text": "On one Jewish day of rest, Jesus and his disciples were walking through some fields where wheat was growing. While they were walking along, his disciples picked some grains of wheat."
    },
    {
      "verse": "24",
      "text": "Some Pharisees said to Jesus, ‘Look at what your disciples are doing. They should not do that on our day of rest. It is against God's Law. ’"
    },
    {
      "verse": "25",
      "text": "Jesus replied, ‘You have certainly read about what David did one day. He and the men who were with him were very hungry. They needed food to eat."
    },
    {
      "verse": "26",
      "text": "David went into the temple. He ate the special bread that was there. He gave some of it to his men to eat as well. This happened during the time that Abiathar was the leader of the priests. It is against God's Law for anyone except the priests to eat that special bread. ’"
    },
    {
      "verse": "27",
      "text": "Then Jesus said to the Pharisees, ‘God wanted to help people. So he made a day for them when they should rest. He did not make people so that they could keep laws about the day of rest."
    },
    {
      "verse": "28",
      "text": "So you should know that the Son of Man has authority over the laws about the day of rest. ’"
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "Another time, Jesus went into the Jewish meeting place. A man was there. His hand was very small and weak, so he could not use it."
    },
    {
      "verse": "2",
      "text": "Some Pharisees were watching Jesus carefully. They wanted to find a reason to say that Jesus was doing wrong things. It was the Jewish day of rest. So the Pharisees watched Jesus to see if he would make the man well on this day."
    },
    {
      "verse": "3",
      "text": "Jesus said to the man, ‘Stand here in front of everyone. ’"
    },
    {
      "verse": "4",
      "text": "Then Jesus said to the Pharisees, ‘Is it right for us to do good things on our day of rest? Or should we do bad things? Should we save a person's life? Or should we kill people? ’Nobody said anything. Nobody said anything."
    },
    {
      "verse": "5",
      "text": "Jesus looked round at everybody. He felt angry with them. He also felt sad because they did not want to learn. Then he said to the man, ‘Lift up your hand. ’ The man lifted his hand and it became well. He could use it again."
    },
    {
      "verse": "6",
      "text": "The Pharisees left the meeting place immediately. They went to meet with some other people who were friends with the ruler, Herod. The Pharisees talked with them about how they could kill Jesus."
    },
    {
      "verse": "7",
      "text": "Jesus left that place and he went away to Lake Galilee with his disciples. A large crowd of people from Galilee followed them."
    },
    {
      "verse": "8",
      "text": "Many people also came to him from Judea, from Jerusalem and from a region of Israel called Idumea. They also came from places on the other side of the Jordan River, and from the towns called Tyre and Sidon. Many people had heard about the things that Jesus was doing. That is why all these people came to him."
    },
    {
      "verse": "9",
      "text": "The crowd was very large. So Jesus asked his disciples to prepare a small boat for him. They did this so that the people would not push against him."
    },
    {
      "verse": "10",
      "text": "Sick people were pushing to the front, because they were trying to touch him. They knew that he had made many people well."
    },
    {
      "verse": "11",
      "text": "Often, a person with a bad spirit saw Jesus. Then, the spirit caused the person to fall down on the ground in front of Jesus. The spirit caused that person to shout out, ‘You are the Son of God. ’"
    },
    {
      "verse": "12",
      "text": "Jesus often had to say to the bad spirits, ‘You must not tell anyone who I am. ’"
    },
    {
      "verse": "13",
      "text": "Jesus went up a mountain. He chose some men and he asked them to go there with him. So they met together with him there."
    },
    {
      "verse": "14",
      "text": "men. He called them his apostles. He wanted them to be with him. And he would send them to teach people about God."
    },
    {
      "verse": "15",
      "text": "He gave these men authority to cause bad spirits to leave people."
    },
    {
      "verse": "16",
      "text": "apostles: Simon, (Jesus called him Peter)."
    },
    {
      "verse": "17",
      "text": "James and John who were the sons of Zebedee. Jesus called them ‘Boanerges’. It means ‘men who are like thunder’."
    },
    {
      "verse": "18",
      "text": "Andrew, Philip, Bartholomew, Matthew, Thomas, James, who was the son of Alphaeus, Thaddaeus, Simon the Zealot"
    },
    {
      "verse": "19",
      "text": "and Judas Iscariot, who later gave Jesus to his enemies."
    },
    {
      "verse": "20",
      "text": "Then Jesus went into a house. A crowd of people came together there again. There were so many people that Jesus and his disciples were not even able to eat."
    },
    {
      "verse": "21",
      "text": "People told his family what was happening. So they went to take him away with them. They thought that Jesus was crazy."
    },
    {
      "verse": "22",
      "text": "Some teachers of God's Law came from Jerusalem. They said, ‘Jesus has a bad spirit called Beelzebul in him. That is Satan, the one who rules all the bad spirits. This man can send bad spirits out of people because Satan gives him authority. ’"
    },
    {
      "verse": "23",
      "text": "So Jesus spoke to the teachers of God's Law. He said, ‘Come here and listen to me. ’ He used stories to explain to them, ‘Satan would not fight against himself!"
    },
    {
      "verse": "24",
      "text": "If armies in the same country start to fight each other, then they will destroy their own country."
    },
    {
      "verse": "25",
      "text": "And if the people in one family start to fight against each other, they will destroy their own family."
    },
    {
      "verse": "26",
      "text": "So Satan would not attack himself. If he did that, he would destroy his own power. That would be the end of him."
    },
    {
      "verse": "27",
      "text": "Nobody can easily go into the house of a strong man to rob him. To do that, he must first tie up the strong man. Then he can take away all that man's valuable things."
    },
    {
      "verse": "28",
      "text": "I tell you this: God can forgive all the wrong things that people do. He can also forgive people who say bad things against him."
    },
    {
      "verse": "29",
      "text": "But God will never forgive people who say bad things against the Holy Spirit. Those people will always be guilty of a terrible sin. ’"
    },
    {
      "verse": "30",
      "text": "Jesus said that to the teachers of God's Law, because they had said, ‘Jesus has a bad spirit in him. ’"
    },
    {
      "verse": "31",
      "text": "Then, Jesus' mother and his brothers arrived and they stood outside the house. They sent someone into the house with a message. They wanted Jesus to come out to speak to them."
    },
    {
      "verse": "32",
      "text": "A crowd of people was sitting around Jesus. Somebody said to him, ‘Look! Your mother and brothers are outside. They are looking for you. ’"
    },
    {
      "verse": "33",
      "text": "Jesus replied, ‘I will tell you who my mother and brothers really are. ’"
    },
    {
      "verse": "34",
      "text": "Then he looked at the people who were sitting around him. He said, ‘Look! Here are my mother and my brothers!"
    },
    {
      "verse": "35",
      "text": "My brothers and sisters and my mother are the people who do what God wants. ’"
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Again, Jesus began to teach people near the edge of Lake Galilee. A large crowd came together to listen to him. So he went and sat in a boat that was on the water. The crowd of people stayed on the shore."
    },
    {
      "verse": "2",
      "text": "Jesus used stories to teach them many things. He said to them,"
    },
    {
      "verse": "3",
      "text": "‘Listen to me! A farmer went out to plant seeds in his field."
    },
    {
      "verse": "4",
      "text": "While he was throwing the seeds, some of them fell on the path. The birds came and they ate those seeds."
    },
    {
      "verse": "5",
      "text": "Other seeds fell on ground which had many rocks. There was not much soil in that place. The seeds quickly began to grow, because the soil was not deep."
    },
    {
      "verse": "6",
      "text": "But when the sun rose, it burned the young plants. They soon died because they had not grown down well into the soil."
    },
    {
      "verse": "7",
      "text": "Other seeds fell among thorn bushes. Those bushes grew up with the young plants. They stopped the seeds from growing into strong plants. So the plants could not make any new seeds."
    },
    {
      "verse": "8",
      "text": "But some seeds fell on good soil. Good strong plants grew from these seeds. Some plants made 30 new seeds. Some plants made 60 new seeds. And some plants made 100 new seeds. ’"
    },
    {
      "verse": "9",
      "text": "Then Jesus said, ‘You have ears, so listen well to what I say! ’"
    },
    {
      "verse": "10",
      "text": "When Jesus was alone, the 12 apostles and other people who were there asked him about the stories. “They are always looking but they do not see clearly. They are always listening but they do not understand. ” If they did understand, they would turn to God. Then God would forgive them. ’"
    },
    {
      "verse": "11",
      "text": "Jesus replied, ‘God has let you understand how he rules in the lives of his people. But these other people only listen to stories."
    },
    {
      "verse": "12",
      "text": "This is so that:“They are always looking but they do not see clearly. They are always listening but they do not understand. ”If they did understand, they would turn to God. Then God would forgive them. ’"
    },
    {
      "verse": "13",
      "text": "Then Jesus answered the people who had asked him about the story. ‘You should understand this story. If you do not understand it, you will not understand any of my stories."
    },
    {
      "verse": "14",
      "text": "The seeds are like the message from God. The farmer is like a person who tells people about that message."
    },
    {
      "verse": "15",
      "text": "Some seeds fell on the path. That is like some people who listen to the message. But then Satan comes and he quickly takes the message away from their minds."
    },
    {
      "verse": "16",
      "text": "Some of the seeds fell on soil with rocks in it. This is also like some people who hear God's message. These people are happy to believe it for a time."
    },
    {
      "verse": "17",
      "text": "But they are like plants that have not grown down well into the soil. So they only believe for a short time. They may have problems. Or because they obey God's message, other people may do bad things to them. When that happens, these people soon stop believing."
    },
    {
      "verse": "18",
      "text": "Some seeds fell among thorn bushes. This is like some other people who hear God's message."
    },
    {
      "verse": "19",
      "text": "But they have many troubles in their minds. They think that more money and other valuable things will make them happy. So they do not let God's message change them. They are like plants that do not grow well and make new seeds."
    },
    {
      "verse": "20",
      "text": "But some seeds fell on good soil. This is like other people who listen to the message from God. They understand the message and they believe it. These people are like good plants that grow well. From one seed, some good plants make 30 new seeds. Other good plants make 60 new seeds, and some good plants make 100 new seeds. ’"
    },
    {
      "verse": "21",
      "text": "Then Jesus said to his disciples, ‘Nobody brings a lamp into a house and puts it under a pot or under a bed. You do not do that. You put it up on a high place."
    },
    {
      "verse": "22",
      "text": "God hides some things now. But there will be a time when people will see them. God keeps some things secret now. But there will be a time when people will understand those things. ’"
    },
    {
      "verse": "23",
      "text": "Then Jesus said, ‘You have ears, so listen well to what I say. ’"
    },
    {
      "verse": "24",
      "text": "Jesus then said, ‘Think carefully about the things that you hear. God will give to you in the same way that you give to other people. And you will receive even more."
    },
    {
      "verse": "25",
      "text": "A person who has received some things will receive more things. Some other people have nothing. They will lose even the little bit that they do have. ’"
    },
    {
      "verse": "26",
      "text": "Then Jesus said, ‘I will tell you a story about the kingdom of God. It is like this: A man throws seeds in his field."
    },
    {
      "verse": "27",
      "text": "Then he sleeps each night and he wakes up each day. The seeds start to grow into plants. They continue to grow. The man does not know how this happens."
    },
    {
      "verse": "28",
      "text": "The soil causes the plants to grow. The leaves of the plant grow first. Then the flowers appear. Then the plant makes new seeds."
    },
    {
      "verse": "29",
      "text": "When the new seeds have completely grown, the man will cut down the plants. It is time for him to take the seeds to use for food. ’"
    },
    {
      "verse": "30",
      "text": "Jesus said, ‘I will tell you another story about the kingdom of God. This story shows what the kingdom of God is like."
    },
    {
      "verse": "31",
      "text": "It is like this: A man takes a seed of the plant called mustard. He plants it in the soil. It is smaller than any other seed that people plant in the soil."
    },
    {
      "verse": "32",
      "text": "But when it starts to grow, it becomes bigger than the largest bush. It will have big branches. Then the birds will come and they will live there. They will build their nests in the shade of the branches. ’"
    },
    {
      "verse": "33",
      "text": "Jesus taught God's message to the people. He used many stories like these. He told the people as much as they could understand."
    },
    {
      "verse": "34",
      "text": "He always used stories to teach the people. Then he explained everything to his own disciples when he was alone with them."
    },
    {
      "verse": "35",
      "text": "On that same day, in the evening, Jesus said to his disciples, ‘We should go across the lake to the other side. ’"
    },
    {
      "verse": "36",
      "text": "So they went and left the crowd behind. Jesus was already in the boat. So the disciples took him across the lake. Some other boats also went with them."
    },
    {
      "verse": "37",
      "text": "Then a strong wind began to blow across the lake. Water began to go into the boat and fill it. Soon the boat was almost going under the water."
    },
    {
      "verse": "38",
      "text": "Jesus was in a comfortable place at the back of the boat. He was sleeping. The disciples woke him. They said to him, ‘Teacher, we will die here in the water! Please do something! ’"
    },
    {
      "verse": "39",
      "text": "Jesus woke up and he spoke strongly to the wind and to the water. ‘Be quiet! ’ he said. ‘Stop! ’ Then the wind stopped and the water became quiet again."
    },
    {
      "verse": "40",
      "text": "Jesus said to his disciples, ‘You should not be afraid like that. You should trust me. ’"
    },
    {
      "verse": "41",
      "text": "But the disciples became very afraid. They said to each other, ‘Who is this man? Even the wind and the water obey him. ’"
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Jesus and his disciples came to the other side of the lake. They came to a place where the Gerasene people lived."
    },
    {
      "verse": "5",
      "text": "The man often walked in the place where the dead people were and on the hills. Every day and every night, he screamed and he used stones to cut himself."
    },
    {
      "verse": "6",
      "text": "He saw Jesus a long way away and he ran to meet him. He went down on his knees in front of Jesus."
    },
    {
      "verse": "7",
      "text": "He screamed loudly, ‘Jesus, you are the Son of the Most High God! What are you doing here? Please, promise God that you will not hurt me. ’"
    },
    {
      "verse": "8",
      "text": "He said that because Jesus had already said to the bad spirit, ‘Come out of this man. ’"
    },
    {
      "verse": "9",
      "text": "Then Jesus asked the man, ‘What is your name? ’The man replied, ‘My name is Army because there are so many bad spirits in me. ’ The man replied, ‘My name is Army because there are so many bad spirits in me. ’"
    },
    {
      "verse": "10",
      "text": "He said to Jesus many times, ‘Please do not send these bad spirits away from this place. ’"
    },
    {
      "verse": "11",
      "text": "A large group of pigs was eating on the hill."
    },
    {
      "verse": "12",
      "text": "The bad spirits said, ‘Jesus, send us to the pigs. Let us go into them. ’"
    },
    {
      "verse": "13",
      "text": "Jesus let them do this. So the bad spirits came out of the man and they went into the pigs. There were about 2, 000 pigs. They rushed together down the hill into the lake. All the pigs died there in the water."
    },
    {
      "verse": "14",
      "text": "The men who were taking care of these pigs ran away. They told the people in the town and in the villages what had happened. Then those people came to see the place for themselves."
    },
    {
      "verse": "15",
      "text": "They came to Jesus. They saw the man that the army of bad spirits had ruled. He was now sitting there quietly. He was wearing clothes and his mind was well again. When the people saw this, they were afraid."
    },
    {
      "verse": "16",
      "text": "The people who had seen this told other people what had happened to the man. They also explained what happened to the pigs."
    },
    {
      "verse": "17",
      "text": "Then the people who lived there said to Jesus, ‘Please go away. Leave this place. ’"
    },
    {
      "verse": "18",
      "text": "Jesus got back into the boat. The man that the bad spirits had ruled spoke to him. He told Jesus that he wanted to go with him."
    },
    {
      "verse": "19",
      "text": "But Jesus did not let him do this. Jesus said to him, ‘Go to your home and to your friends. Tell them what the Lord has done for you. Tell them how he has been kind to you. ’"
    },
    {
      "verse": "20",
      "text": "So the man went away. He began to speak to many people in the region called ‘The ten cities’. He told them about the great things that Jesus had done for him. All the people were very surprised."
    },
    {
      "verse": "21",
      "text": "Jesus returned to the other side of the lake in the boat. While he was by the lake, a large crowd came to him."
    },
    {
      "verse": "22",
      "text": "A man called Jairus came to Jesus. He was a leader at the Jewish meeting place. When he saw Jesus, he went down on his knees in front of him."
    },
    {
      "verse": "23",
      "text": "He said, ‘My little daughter is very ill and she will die very soon. Please come to my house and put your hands on her. Then she will be well and she will live. ’"
    },
    {
      "verse": "24",
      "text": "So Jesus went with Jairus. A large crowd followed Jesus. The people were pushing against him."
    },
    {
      "verse": "25",
      "text": "years."
    },
    {
      "verse": "26",
      "text": "She had paid many doctors to help her to become well. But they could not do anything. Now she had spent all her money. She had not become well. Instead, she was now worse."
    },
    {
      "verse": "27",
      "text": "People had told her about Jesus. So she came in the crowd behind him and she touched his coat."
    },
    {
      "verse": "28",
      "text": "She said, ‘Even if I can only touch his clothes, I will become well again. ’"
    },
    {
      "verse": "29",
      "text": "As soon as she touched Jesus' coat, the blood stopped. She felt in her body that her illness was better. She knew that she was well again."
    },
    {
      "verse": "30",
      "text": "Jesus knew immediately that something powerful had gone out from him. So he turned around in the crowd and he asked, ‘Who touched my clothes? ’"
    },
    {
      "verse": "31",
      "text": "His disciples replied, ‘You can see that the crowd is pushing against you. So you cannot ask who touched you! ’"
    },
    {
      "verse": "32",
      "text": "But Jesus looked around him. He wanted to see who had touched him."
    },
    {
      "verse": "33",
      "text": "The woman knew what had happened to her. She felt very afraid. But she came to Jesus, and she went down on her knees in front of him. Then she told him everything that had happened to her."
    },
    {
      "verse": "34",
      "text": "Jesus said to her, ‘Young woman, you are now well again because you believed in me. Have peace in your mind. Go now and have no more pain. ’"
    },
    {
      "verse": "35",
      "text": "While Jesus was still speaking, some men arrived from the house of Jairus. He was the leader at the Jews' meeting place. The men said to Jairus, ‘Your daughter is dead. Do not ask any longer for the teacher to come. ’"
    },
    {
      "verse": "36",
      "text": "Jesus heard what the men said to Jairus. But Jesus said to him, ‘Do not be afraid. Instead, believe. ’"
    },
    {
      "verse": "37",
      "text": "Jesus took only Peter, James and James's brother, John, with him. He would not let anyone else go with him."
    },
    {
      "verse": "38",
      "text": "Then they came to Jairus's house. Jesus saw that there were many people there. They were crying and they were making a loud noise."
    },
    {
      "verse": "39",
      "text": "Jesus went into the house and he said to the people, ‘You should not be weeping and making a noise. The child is not dead. She is asleep. ’"
    },
    {
      "verse": "40",
      "text": "The people laughed at Jesus when he said that. Then Jesus sent them all out of the house. He went into the place where the child was lying. The child's father and mother went with him. He also took Peter, James and John with him."
    },
    {
      "verse": "41",
      "text": "Then Jesus held the girl's hand. He said to her, ‘Talitha koum. ’ This means, ‘Little girl, I say to you, stand up! ’"
    },
    {
      "verse": "42",
      "text": "The girl stood up immediately and she walked about. She was 12 years old. The people there were very surprised."
    },
    {
      "verse": "43",
      "text": "Jesus said to them, ‘You must not tell anyone what has happened here. Now give the girl something to eat. ’"
    },
    {
      "verse": "2",
      "text": "Jesus got out of the boat. Immediately, a man with a bad spirit in him came to him. This man lived outside, among some graves."
    },
    {
      "verse": "3",
      "text": "He was very strong and nobody could hold him. People often put chains around his ankles to hold him."
    },
    {
      "verse": "4",
      "text": "They wanted to keep him in a safe place. But he broke the chains that held him."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "Jesus left that place. He went to his own town. His disciples went with him."
    },
    {
      "verse": "2",
      "text": "When it was the Jewish day of rest, Jesus went to their meeting place. He began to teach the people who were there. Many of them were surprised about the things that he was saying to them. They said to each other, ‘How did this man learn all these things? How did he become so wise? How does he do all these powerful things?"
    },
    {
      "verse": "3",
      "text": "We know he is an ordinary man. He is the carpenter. He is the son of Mary and the brother of James, Joses, Simon and Judas. His sisters live here in the town among us. Isn't that true? ’ So the people there turned against Jesus."
    },
    {
      "verse": "4",
      "text": "Then Jesus said to them, ‘If a man is a prophet from God, people everywhere will respect him. But the people in his own town will not accept him. Even his own people and his own family will not respect him. ’"
    },
    {
      "verse": "5",
      "text": "Jesus could not do any powerful miracles in his own town. But he did put his hands on a few sick people and he made them well. Then he went to visit the other villages that were near there. He was teaching the people who lived in those villages."
    },
    {
      "verse": "6",
      "text": "Jesus was very surprised because the people there would not believe in him. Then he went to visit the other villages that were near there. He was teaching the people who lived in those villages."
    },
    {
      "verse": "7",
      "text": "apostles to come to him. He started to send them out to tell God's message to people. He sent them out two by two and he gave them authority over bad spirits."
    },
    {
      "verse": "8",
      "text": "Jesus told the disciples, ‘Only take a stick for the journey, nothing else. Do not take any bread or a bag. Do not take any money in your pockets."
    },
    {
      "verse": "9",
      "text": "Wear shoes but do not take extra clothes."
    },
    {
      "verse": "10",
      "text": "In each town, stay at the first house that you go into. Continue to stay there until you leave that town."
    },
    {
      "verse": "11",
      "text": "Perhaps you might go to a town where the people do not accept you. They will not listen to you. So you should leave that town. Clean that town's dirt off your feet. Then it will be clear that they have done something wrong. ’"
    },
    {
      "verse": "12",
      "text": "apostles went out. They told people that they must change the way that they live. They must stop doing wrong things."
    },
    {
      "verse": "13",
      "text": "The disciples caused many bad spirits to come out of people. They also put olive oil on many sick people, and the sick people became well."
    },
    {
      "verse": "14",
      "text": "People were talking about Jesus. King Herod heard about what was happening. Some people were saying that Jesus was really John the Baptist. They said that John had died, but he had become alive again. ‘That is why this man can do these very powerful things, ’ they said."
    },
    {
      "verse": "15",
      "text": "Other people said, ‘This man is Elijah. ’ And other people said, ‘He is a prophet. He is like one of God's prophets who lived a long time ago. ’"
    },
    {
      "verse": "16",
      "text": "But when someone told Herod, he said, ‘This man is surely John. I sent a soldier to cut off his head. But he has become alive again! ’"
    },
    {
      "verse": "17",
      "text": "Herod himself had sent his soldiers to take hold of John. He had said to his soldiers, ‘Tie his hands and feet and put him in prison. ’ Herod had done that because of his wife, Herodias. She had been the wife of Herod's brother, Philip. But Herod had married her."
    },
    {
      "verse": "18",
      "text": "John had said to him, ‘Herodias is your brother's wife. It is not right for you to have her as your wife. ’"
    },
    {
      "verse": "19",
      "text": "So Herodias was angry with John. She wanted to kill him. But she could not do that,"
    },
    {
      "verse": "20",
      "text": "because Herod was afraid of John. Herod knew that John was a good man and a servant of God. So Herod kept John safe. Herod liked to listen to the things that John said. But he did not know what to think about those things."
    },
    {
      "verse": "21",
      "text": "One day, Herodias had her chance. It was Herod's birthday and he asked many people to come to a special meal. Important men and officers came. The rulers from Galilee were also there."
    },
    {
      "verse": "22",
      "text": "The daughter of Herodias came in and she danced. Herod and his visitors were very happy when they saw her dance. King Herod said to the girl, ‘Ask me for anything that you want. I will give it to you. ’"
    },
    {
      "verse": "23",
      "text": "He made a strong promise, ‘I will give you anything that you ask me to give to you. I will even give you half of everything that I rule over. ’"
    },
    {
      "verse": "24",
      "text": "The girl went out and she said to her mother, ‘What should I ask him for? ’ Her mother replied, ‘Ask for the head of John the Baptist. ’"
    },
    {
      "verse": "25",
      "text": "The girl went quickly to Herod and she said to him, ‘I want the head of John the Baptist. Put it on a plate! Do it now! ’"
    },
    {
      "verse": "26",
      "text": "Then Herod felt very sad. Because he had made a special promise, he did not want to refuse her. All his visitors had heard him."
    },
    {
      "verse": "27",
      "text": "So immediately, the king sent a soldier to go to John. The king told the soldier that he must bring John's head. So the soldier went to the prison and he cut off John's head there."
    },
    {
      "verse": "28",
      "text": "Then he brought it back on a plate. He gave it to the girl, and she gave it to her mother."
    },
    {
      "verse": "29",
      "text": "People told John's disciples about what had happened. So they went to the prison. They took away John's body and they buried it."
    },
    {
      "verse": "30",
      "text": "The apostles all came to Jesus. They told him about all the things that they had done. And they told him what they had taught."
    },
    {
      "verse": "31",
      "text": "Many people were coming to Jesus and then going away. Jesus and his disciples were too busy even to eat. So Jesus said to them, ‘Come with me to a place where there are no other people. We should be alone together. Then we can rest for a short time. ’"
    },
    {
      "verse": "32",
      "text": "So they left all the people behind. They went away in a boat together to a quiet place."
    },
    {
      "verse": "33",
      "text": "But many people saw that they were leaving the town. Those people recognized them. So they ran out from all the towns around there. They went on land and reached the place before Jesus and the disciples."
    },
    {
      "verse": "34",
      "text": "Jesus got out of the boat and he saw a large crowd. He felt sorry for them. He thought to himself, ‘These people are like sheep that have nobody to take care of them. ’ So he began to teach them many things."
    },
    {
      "verse": "35",
      "text": "When it was almost evening time, Jesus' disciples came and said to him, ‘We are in a place where there are no houses. Soon it will be dark."
    },
    {
      "verse": "36",
      "text": "The people do not have anything to eat. So send them away now. Tell them to go to the farms and villages that are near here. Then they can buy some food for themselves to eat. ’"
    },
    {
      "verse": "37",
      "text": "‘You should give them some food to eat, ’ Jesus replied. But the disciples said, ‘We cannot go to buy bread for all these people. A man must work for eight months to get the 200 coins that we would need for that. We cannot get enough food to give to these people. ’ But the disciples said, ‘We cannot go to buy bread for all these people. A man must work for eight months to get the 200 coins that we would need for that. We cannot get enough food to give to these people. ’"
    },
    {
      "verse": "38",
      "text": "Jesus asked them, ‘How many loaves of bread do you have? Go and see. ’ When they had looked, they told Jesus, ‘We have five loaves and two fish. ’"
    },
    {
      "verse": "39",
      "text": "Then Jesus told all the people to sit down on the green grass. He wanted them to sit in large groups."
    },
    {
      "verse": "40",
      "text": "So the people sat down in groups. Each group had 50 or 100 people in it."
    },
    {
      "verse": "41",
      "text": "Then Jesus took the five loaves of bread and the two fish. He looked up to heaven and he thanked God for the food. Then he broke the bread into pieces. He gave the pieces of bread to the disciples, and they gave the bread to the people. Jesus also broke the two fish into pieces for all the people."
    },
    {
      "verse": "42",
      "text": "Everyone ate and they all had enough food. They were not hungry any more."
    },
    {
      "verse": "43",
      "text": "Jesus' disciples then picked up all the bits of food that people had not eaten. They filled 12 baskets with little bits of bread and fish."
    },
    {
      "verse": "44",
      "text": "There were 5, 000 men in the crowd that ate the food there."
    },
    {
      "verse": "45",
      "text": "Immediately after this, Jesus said to his disciples, ‘Get into the boat and sail across the lake to Bethsaida. ’ Jesus said that he would first send the crowd away. Then he would also leave."
    },
    {
      "verse": "46",
      "text": "So he said ‘goodbye’ to the crowd. Then he went up on a mountain to pray."
    },
    {
      "verse": "47",
      "text": "That evening, the boat with the disciples in it was in the middle of the lake. Jesus was still alone on the land."
    },
    {
      "verse": "48",
      "text": "But he could see his disciples. They were trying to make the boat move along. But it was very difficult for them because the wind was blowing in the opposite direction. Then, when it was nearly dawn, Jesus walked on the water towards his disciples. He seemed to be going on past them."
    },
    {
      "verse": "49",
      "text": "But they saw that he was walking on the water. They thought, ‘It is a spirit. ’ And they screamed out."
    },
    {
      "verse": "50",
      "text": "They all saw him and they were very afraid. But immediately, Jesus said to them, ‘Be brave. It is I. Do not be afraid. ’"
    },
    {
      "verse": "51",
      "text": "Then Jesus got into the boat to be with them. The strong wind stopped. The disciples were completely surprised about what had happened."
    },
    {
      "verse": "52",
      "text": "They did not understand what Jesus had done with the loaves of bread. They were not ready to learn."
    },
    {
      "verse": "53",
      "text": "They sailed across the lake. They reached the shore at Gennesaret and they tied the boat there."
    },
    {
      "verse": "54",
      "text": "When they got out of the boat, the people recognized Jesus immediately."
    },
    {
      "verse": "55",
      "text": "They went to tell everyone who lived in places near there. They brought sick people to Jesus. They carried those people to him on mats. Whenever they knew where Jesus was, they brought sick people to him there."
    },
    {
      "verse": "56",
      "text": "Jesus went to villages, towns and farms. Everywhere that he went, they brought sick people to the market places. The sick people asked Jesus for help. They wanted to touch even the edge of his coat. Every sick person who touched him became well."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "A group of Pharisees and some teachers of God's Law came from Jerusalem to talk with Jesus."
    },
    {
      "verse": "2",
      "text": "They had been watching Jesus' disciples. Some of the disciples did not wash their hands before they ate a meal. That is to say, they did not wash them in the right way."
    },
    {
      "verse": "3",
      "text": "(The Pharisees and all the Jews do not eat food until they have washed their hands carefully. They do this because of what their leaders taught them."
    },
    {
      "verse": "4",
      "text": "When they come from the market place, they always wash themselves carefully. Unless they do this, they do not eat anything. Their leaders also gave them rules about how they should wash cups, pots and metal bowls. )"
    },
    {
      "verse": "5",
      "text": "The Pharisees and the teachers of God's Law said to Jesus, ‘Your disciples do not obey the things that our leaders taught many years ago. Your disciples have not washed their hands in the right way. They are eating their food with unclean hands. That is not right. ’"
    },
    {
      "verse": "6",
      "text": "Jesus said to them, ‘You are hypocrites! What God's prophet Isaiah wrote about you long ago is true: God says, “These people say good things about me, but they do not really want to obey me. God says, “These people say good things about me, but they do not really want to obey me."
    },
    {
      "verse": "7",
      "text": "They say that I am great. But what they say has no purpose. They teach their own rules, which I did not give to them. ” ’ But what they say has no purpose. They teach their own rules, which I did not give to them. ” ’"
    },
    {
      "verse": "8",
      "text": "Jesus then said, ‘You have stopped obeying God. Instead you obey the ideas that men teach. ’"
    },
    {
      "verse": "9",
      "text": "He said to them, ‘You refuse to obey God's rules, because then you can keep your own ideas!"
    },
    {
      "verse": "10",
      "text": "For example, Moses wrote, “You must love your father and your mother. You must obey them. ” He also said, “You must kill anyone who curses his father or his mother. ”"
    },
    {
      "verse": "11",
      "text": "But you teach that a person may say to his father or to his mother, “I would have given gifts to help you. But I cannot do that, because I have given them to God instead. ”"
    },
    {
      "verse": "12",
      "text": "If he says that, you let him do nothing to help his father or his mother."
    },
    {
      "verse": "13",
      "text": "This shows that you have not obeyed what God says is right. Instead, you have obeyed the ideas that you received from your leaders many years ago. And you do many other things like that. ’"
    },
    {
      "verse": "14",
      "text": "Jesus asked the crowd of people to come to him again. He said to them, ‘Listen to me, all of you, so that you can understand these things."
    },
    {
      "verse": "15",
      "text": "People do not become unclean because of things that go into their bodies from outside. They become unclean because of the things that come out from their minds."
    },
    {
      "verse": "16",
      "text": "[You have heard my words. So do what I say. ’]"
    },
    {
      "verse": "17",
      "text": "Jesus left the crowd of people and he went into a house. Then his disciples asked him to explain what he had taught."
    },
    {
      "verse": "18",
      "text": "Jesus said, ‘I am surprised that you too do not understand what I am saying. You should understand that food will not make people unclean. Food goes into people's bodies from outside. When Jesus said this, he was teaching that all foods are clean."
    },
    {
      "verse": "19",
      "text": "But food does not go into people's minds. It goes into their stomachs and then it passes out of their bodies. ’When Jesus said this, he was teaching that all foods are clean."
    },
    {
      "verse": "20",
      "text": "Jesus then said, ‘People become unclean because of what comes out from them, not because of what goes in."
    },
    {
      "verse": "21",
      "text": "Evil thoughts come out from people's minds. As a result they do wrong things. They have sex in wrong ways. They rob people. They murder people."
    },
    {
      "verse": "22",
      "text": "They have sex with another man's wife. They are greedy. They are cruel to other people. They deceive people. They live like wild animals. They are jealous of other people. They say bad things about other people. They are proud and foolish."
    },
    {
      "verse": "23",
      "text": "All these wrong things begin inside people's minds and then they come out. That is what makes them unclean. ’"
    },
    {
      "verse": "24",
      "text": "Jesus left that place. He went away to the region around Tyre. He went into a house. He did not want anyone to know that he was there. But it was not possible to keep this a secret."
    },
    {
      "verse": "25",
      "text": "Immediately, a certain woman heard that he was there. This woman had a daughter who had a bad spirit in her. The woman came to Jesus and she went down on her knees by his feet."
    },
    {
      "verse": "26",
      "text": "She was not a Jew. Her family was from Phoenicia in the country of Syria. She asked Jesus to make the bad spirit go out of her daughter."
    },
    {
      "verse": "27",
      "text": "Jesus said to the woman, ‘First, the children must eat all that they want. It is not right to take food from the children and then throw it to the dogs. ’"
    },
    {
      "verse": "28",
      "text": "The woman replied, ‘Yes, sir. That is true. But small pieces of food drop while the children eat. And the dogs under the table eat those pieces. ’"
    },
    {
      "verse": "29",
      "text": "‘That is a good answer, ’ Jesus replied. ‘Now the bad spirit has left your daughter. You may go. ’"
    },
    {
      "verse": "30",
      "text": "The woman went to her home. She saw her child, who was lying on the bed. The bad spirit had left the girl."
    },
    {
      "verse": "31",
      "text": "Then Jesus went away from Tyre. He travelled through the city of Sidon. Then he went towards Lake Galilee. He was in the region called ‘The ten cities’."
    },
    {
      "verse": "32",
      "text": "Some people brought a man to Jesus. This man could not hear anything and he could not speak clearly. The people asked Jesus to put his hand on the man."
    },
    {
      "verse": "33",
      "text": "Jesus led the man away from the crowd. He put his fingers into the man's ears. Then he spat on his hands and touched the man's tongue."
    },
    {
      "verse": "34",
      "text": "Jesus looked up towards heaven. He cried with a low, sad sound. Then he said to the man, ‘Ephphatha! ’ That means, ‘Become open! ’"
    },
    {
      "verse": "35",
      "text": "When Jesus said this, the man started to hear. Also, his tongue was able to move properly so that he could speak clearly."
    },
    {
      "verse": "36",
      "text": "Jesus told the people that they must not tell anyone about this. But every time Jesus asked them not to say anything, they spoke even more about it."
    },
    {
      "verse": "37",
      "text": "The people were very surprised about everything that Jesus did. They said, ‘Jesus has done everything well. If people cannot hear, Jesus makes them able to hear. If people cannot speak, Jesus makes them able to speak. ’"
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "At that time, another large crowd had come to hear Jesus. The people had nothing to eat. Jesus asked his disciples to come to him. He said to them,"
    },
    {
      "verse": "2",
      "text": "‘I feel sorry for this crowd. They have been here with me now for three days and they do not have any food."
    },
    {
      "verse": "3",
      "text": "I do not want to send them back to their homes while they are hungry. They might fall down during their journey because they are weak. Some of them have travelled a long way to come here. ’"
    },
    {
      "verse": "4",
      "text": "The disciples replied, ‘This place is far from any houses. We cannot get enough bread to feed all these people. ’"
    },
    {
      "verse": "5",
      "text": "‘How many loaves of bread do you have? ’ Jesus asked. ‘We have seven loaves, ’ they replied."
    },
    {
      "verse": "6",
      "text": "Jesus told the crowd that they should sit down on the ground. Then he took the seven loaves in his hands and he thanked God for them. Then he broke the bread and he gave the pieces to his disciples. The disciples gave the bread to the people."
    },
    {
      "verse": "7",
      "text": "The disciples also had a few small fish, so Jesus thanked God for these. Then he told his disciples to give the fish to the people too."
    },
    {
      "verse": "8",
      "text": "The people ate, and they all had enough food. After the people had eaten, there were still lots of small pieces of food. Jesus' disciples filled seven baskets with these pieces."
    },
    {
      "verse": "9",
      "text": "About 4, 000 people were there and ate the food. Then Jesus sent the people away."
    },
    {
      "verse": "10",
      "text": "Immediately, he got into the boat with his disciples. They all returned to the part of the country called Dalmanutha."
    },
    {
      "verse": "11",
      "text": "Some Pharisees came to Jesus. They began to argue with him. They wanted to see him do something powerful. That would show them that God had really sent him."
    },
    {
      "verse": "12",
      "text": "Jesus cried with a low, sad sound. He said, ‘People who are alive today want God to show them something powerful. But I tell you this: God will not do the powerful thing for them that they want. ’"
    },
    {
      "verse": "13",
      "text": "Then Jesus left those Pharisees. He got back into the boat to go to the other side of the lake."
    },
    {
      "verse": "14",
      "text": "Jesus' disciples had forgotten to take bread with them. They only had one loaf in the boat."
    },
    {
      "verse": "15",
      "text": "Jesus said to them, ‘Be careful. Do not accept the yeast of the Pharisees or the yeast of Herod. ’"
    },
    {
      "verse": "16",
      "text": "The disciples began to say to each other, ‘Jesus is saying that because we do not have any bread. ’"
    },
    {
      "verse": "17",
      "text": "Jesus knew what they were talking about. So he said to them, ‘You should not be arguing about the bread. You still do not understand my teaching. You seem unable to learn. ‘There were 12 baskets, ’ they replied."
    },
    {
      "verse": "18",
      "text": "You are like people who have eyes but they cannot see with them. You are like people who have ears but they cannot hear with them."
    },
    {
      "verse": "19",
      "text": "Remember that I used five loaves of bread to feed 5, 000 men. How many baskets did you fill with pieces of food that were left? ’‘There were 12 baskets, ’ they replied."
    },
    {
      "verse": "20",
      "text": "Jesus asked them, ‘I also used seven loaves to feed 4, 000 people. That time, how many baskets did you fill with pieces of food? ’‘There were seven baskets, ’ they replied. ‘There were seven baskets, ’ they replied."
    },
    {
      "verse": "21",
      "text": "‘You really should understand about me now, ’ he said to them."
    },
    {
      "verse": "22",
      "text": "Jesus and his disciples came to a village called Bethsaida. Some people led a blind man to Jesus. They asked Jesus to touch the man."
    },
    {
      "verse": "23",
      "text": "Jesus took the blind man's hand and he led the man out of the village. Jesus put water from his own mouth on the man's eyes. And he put his hands on the man. ‘Can you see anything? ’ Jesus asked."
    },
    {
      "verse": "24",
      "text": "The man looked up. He said, ‘I can see people. But they look like trees that are walking about. ’"
    },
    {
      "verse": "25",
      "text": "So Jesus put his hands on the man's eyes again. The man looked carefully and then his eyes were completely well. Now he could see everything clearly."
    },
    {
      "verse": "26",
      "text": "Jesus told the man that he must go back to his home. Jesus said, ‘Do not even go into the village. ’"
    },
    {
      "verse": "27",
      "text": "Then Jesus and his disciples went to visit some villages. They were near to the town of Caesarea Philippi. On the way, Jesus asked his disciples, ‘When people talk about me, who do they say that I am? ’"
    },
    {
      "verse": "28",
      "text": "They replied, ‘Some people say that you are John the Baptist. Other people say that you are Elijah. And some other people say that you are one of God's prophets. ’"
    },
    {
      "verse": "29",
      "text": "Jesus asked them, ‘But what do you think? Who do you say that I am? ’Peter answered him, ‘You are the Messiah. ’ Peter answered him, ‘You are the Messiah. ’"
    },
    {
      "verse": "30",
      "text": "Then Jesus warned his disciples that they must not tell anyone about him."
    },
    {
      "verse": "31",
      "text": "Then Jesus began to teach his disciples about the things that must happen to the Son of Man. He would have to suffer in many ways. The important Jews, the leaders of the priests and the teachers of God's Law would turn against him. People would kill him. But after three days, he would become alive again."
    },
    {
      "verse": "32",
      "text": "What Jesus said was very clear. Then Peter took Jesus away from the other disciples. Peter began to tell Jesus that he must not say things like that."
    },
    {
      "verse": "33",
      "text": "Jesus turned round and he looked at his disciples. He said that Peter was not saying good things. He said to Peter, ‘Satan, go away from me! Your thoughts do not come from God. Instead, you are thinking like men think. ’"
    },
    {
      "verse": "34",
      "text": "Then Jesus asked the crowd and his disciples to come to him. He said to them, ‘A person who wants to come with me must not think about himself. He must decide that his own life is not important. He must be like someone who carries his own cross to go and die. Then he may come with me as my disciple."
    },
    {
      "verse": "35",
      "text": "Whoever wants to keep his own life safe will lose it. But whoever gives his life to serve me and God's good news will have true life."
    },
    {
      "verse": "36",
      "text": "A person may get everything in the whole world for himself. But if he loses his life, it will not be any good for him."
    },
    {
      "verse": "37",
      "text": "There is nothing that a person can give to get back his life."
    },
    {
      "verse": "38",
      "text": "People who are living today do not obey God. They are very bad. But you must not be ashamed of me or of my words. If you are, then the Son of Man will be ashamed of you. One day he will return and God's holy angels will be with him. He will have the bright glory of his Father. He will be ashamed of you on that day if you are ashamed of him now. ’"
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "Jesus then said to them, ‘I tell you this: Some people who are standing here will see God begin to rule in his kingdom with great power. They will see that before they die. ’"
    },
    {
      "verse": "2",
      "text": "Six days after that, Jesus asked Peter, James and John to go with him. Jesus led them up a high mountain, where they were alone together. Peter, James and John saw Jesus change in front of them."
    },
    {
      "verse": "3",
      "text": "His clothes became very white; they were shining. They were a brighter white than anyone on earth could wash them."
    },
    {
      "verse": "4",
      "text": "Then Elijah and Moses appeared in front of the three disciples. Elijah and Moses were talking with Jesus."
    },
    {
      "verse": "5",
      "text": "So Peter said to Jesus, ‘Teacher, it is good that we are here. Please let us build three huts. One hut will be for you. One hut will be for Moses. And one hut will be for Elijah. ’"
    },
    {
      "verse": "6",
      "text": "Peter did not really know what to say. That was because the three disciples were very afraid."
    },
    {
      "verse": "7",
      "text": "Then a cloud appeared and it covered them all. A voice spoke from the cloud and it said, ‘This is my Son, and I love him. Listen to him. ’"
    },
    {
      "verse": "8",
      "text": "At that moment, the three disciples looked around. They saw that nobody else was there now. Only Jesus was there with them."
    },
    {
      "verse": "9",
      "text": "While they were walking down the mountain, Jesus said to the three disciples, ‘You must not tell anyone now about the things that you have just seen. One day the Son of Man will become alive again after his death. Then you can tell people about these things. ’"
    },
    {
      "verse": "10",
      "text": "The three disciples kept these words secret. But they talked together about the words, ‘become alive again after his death’. They asked each other, ‘What does this mean? ’"
    },
    {
      "verse": "11",
      "text": "Then the three disciples asked Jesus, ‘Why do the teachers of God's Law say that God's prophet Elijah must return first, before the Messiah comes? ’"
    },
    {
      "verse": "12",
      "text": "Jesus said to them, ‘Elijah does come first. He makes everything ready. But what is written in the Bible about the Son of Man? It says that people will cause him to suffer a lot. They will think that he is nothing."
    },
    {
      "verse": "13",
      "text": "But I tell you that Elijah has already come. People did to him everything that they wanted to do. The Bible already showed that those things would happen to him. ’"
    },
    {
      "verse": "14",
      "text": "They reached the place where the other disciples were. They saw that there was a large crowd there with them. Some teachers of God's Law were arguing with the disciples."
    },
    {
      "verse": "15",
      "text": "The people in the crowd saw Jesus and immediately they were very surprised. They ran to say ‘hello’ to Jesus."
    },
    {
      "verse": "16",
      "text": "Jesus asked his disciples, ‘What are you arguing about with the teachers of God's Law? ’"
    },
    {
      "verse": "17",
      "text": "A man in the crowd answered. He said to Jesus, ‘Teacher, I brought my son to you. He is not able to speak because he has a bad spirit."
    },
    {
      "verse": "18",
      "text": "When the bad spirit takes hold of him, it throws him to the ground. Water comes out of his mouth and he bites his teeth together. Then his body stops moving. I asked your disciples to send the spirit out of him. But they were not able to do it. ’"
    },
    {
      "verse": "19",
      "text": "Jesus replied, ‘You people today still do not believe in God. I have been with you for a long time and still you do not believe. It is difficult for me to be patient with you. Bring the boy to me. ’"
    },
    {
      "verse": "20",
      "text": "So the people brought the boy to Jesus. When the bad spirit saw Jesus, it immediately caused the boy's body to shake strongly. The boy fell onto the ground and he rolled about. Water was coming from his mouth."
    },
    {
      "verse": "21",
      "text": "Jesus asked the boy's father, ‘How long has he been like this? ’‘He has been like this since he was a small boy, ’ the father replied."
    },
    {
      "verse": "22",
      "text": "‘Often the spirit has caused him to fall into the fire or into water. It is trying to kill him. Please be kind to us. If you can do anything, help us! ’"
    },
    {
      "verse": "23",
      "text": "Jesus said to the father, ‘You should not say, “If you can do anything. ” Everything is possible for those people who believe. ’"
    },
    {
      "verse": "24",
      "text": "Immediately, the boy's father shouted, ‘Oh! I believe! Help me to believe more! ’"
    },
    {
      "verse": "25",
      "text": "Jesus saw that the crowd of people was quickly becoming bigger. So he told the bad spirit to stop. Jesus said to it, ‘Spirit, I am telling you that you must leave this boy. He cannot hear or speak because of you. I tell you to come out of him! You must never go into him again. ’"
    },
    {
      "verse": "26",
      "text": "The spirit screamed. It caused the boy's body to shake many times. Then it came out of him. The boy seemed to be dead, so many people said, ‘He is dead. ’"
    },
    {
      "verse": "27",
      "text": "But Jesus held the boy's hand and he helped the boy to stand up."
    },
    {
      "verse": "28",
      "text": "Jesus went into a house and the disciples were alone with him. Then they asked him, ‘Why could we not cause the bad spirit to leave the boy? ’"
    },
    {
      "verse": "29",
      "text": "Jesus said to them, ‘You must pray. This kind of spirit will not leave a person unless you pray. ’"
    },
    {
      "verse": "30",
      "text": "Jesus and his disciples left that place. They passed through Galilee. Jesus did not want anyone to know where he was."
    },
    {
      "verse": "31",
      "text": "That was because he was teaching his disciples. He told them, ‘Soon, they will give the Son of Man to powerful people. They will take him away and they will kill him. But three days after that, he will become alive again. ’"
    },
    {
      "verse": "32",
      "text": "The disciples did not understand what Jesus had said. But they were afraid to ask him."
    },
    {
      "verse": "33",
      "text": "Jesus and his disciples arrived at Capernaum. When they were in the house, Jesus asked them, ‘What were you arguing about on the way? ’"
    },
    {
      "verse": "34",
      "text": "But they did not say anything. They did not want to tell Jesus why they were arguing. On the way, they had argued about who was the most important disciple."
    },
    {
      "verse": "35",
      "text": "Jesus sat down. He told the 12 apostles to come to him. Then he said to them, ‘If you want to be the leader, make yourself less important than everyone else. You must become the servant of everyone. ’"
    },
    {
      "verse": "36",
      "text": "Then Jesus brought a child to stand in the middle of them all. He took hold of the child and he said to the disciples,"
    },
    {
      "verse": "37",
      "text": "‘If someone accepts a child like this because of me, then that person also accepts me. If he accepts me, then he is not only accepting me. He is also accepting my Father God, who sent me. ’"
    },
    {
      "verse": "38",
      "text": "John said to Jesus, ‘Teacher, we saw a man who was causing bad spirits to go out of people. He was using your authority to do it. But he is not in our group. So we told him that he must not do it. ’"
    },
    {
      "verse": "39",
      "text": "‘Do not tell him to stop, ’ Jesus said. ‘That man is using my authority to do powerful things. Someone who does that cannot immediately say anything bad about me."
    },
    {
      "verse": "40",
      "text": "If someone is not against us, he is working to help us."
    },
    {
      "verse": "41",
      "text": "Somebody may give you a cup of water because you are a servant of the Messiah. I tell you this: God will bless that person and he will never lose God's help."
    },
    {
      "verse": "42",
      "text": "A person who believes in me may not seem important. But you should never make that person do wrong things. Do not do that! It would be better if someone tied a big stone around your neck and then he threw you into the sea!"
    },
    {
      "verse": "47",
      "text": "If your eye causes you to do wrong things, then you should remove it. Then you will only have one eye, but you can go into the kingdom of God. It will be much worse if you keep both your eyes and God throws you into hell."
    },
    {
      "verse": "48",
      "text": "“In hell, the worms do not die, and the fire never goes out. ” and the fire never goes out. ”"
    },
    {
      "verse": "49",
      "text": "God will put fire on everybody, as people put salt on food."
    },
    {
      "verse": "50",
      "text": "Salt is good. But if your salt is not salty any more, you cannot make it salty again. You should be like good salt and love each other. Do not cause trouble among yourselves. ’"
    },
    {
      "verse": "43",
      "text": "If your hand causes you to do wrong things, you should cut it off. You will only have one hand, but you can have God's true life."
    },
    {
      "verse": "44",
      "text": "It will be much worse for you if you keep both your hands and go to hell. There, the fire always burns and never stops."
    },
    {
      "verse": "45",
      "text": "If your foot causes you to do wrong things, you should cut it off. You will only have one foot, but you can have God's true life."
    },
    {
      "verse": "46",
      "text": "It will be much worse if you keep your two feet and go to hell."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "Then Jesus left that place and he went to Judea. He went across to the east side of the Jordan River. Crowds of people came to him again. So he taught them, as he usually did."
    },
    {
      "verse": "2",
      "text": "Some Pharisees came to Jesus. They wanted to find out how he would answer their question. They asked him, ‘Can a man send his wife away, so that she is no longer his wife? Is it right for him to do that? ’"
    },
    {
      "verse": "3",
      "text": "Jesus replied with a question: ‘What did Moses say was right for you? ’"
    },
    {
      "verse": "4",
      "text": "The Pharisees said, ‘Moses said that a man could write a letter to say that he and his wife are no longer married. Then the man can send the woman away. ’"
    },
    {
      "verse": "5",
      "text": "Jesus said to them, ‘You did not want to obey God. That is why Moses made this rule for you."
    },
    {
      "verse": "6",
      "text": "But at the start, when God made the world, he made people male and female."
    },
    {
      "verse": "7",
      "text": "That is the reason that a man leaves his father and his mother. Then God joins him and his wife together."
    },
    {
      "verse": "8",
      "text": "The man and the woman become like one body. They are not two separate people any longer. They have come together as one person."
    },
    {
      "verse": "9",
      "text": "God has put them together to be husband and wife. So nobody should cause them to be separate. ’"
    },
    {
      "verse": "10",
      "text": "When Jesus went into the house, the disciples asked him about these things again."
    },
    {
      "verse": "11",
      "text": "So Jesus said to them, ‘A man must not send his wife away and then marry another woman. If he does that, he has not been faithful to his wife. It is the same as if he had sex with another man's wife."
    },
    {
      "verse": "12",
      "text": "In the same way, a woman must not leave her husband and then marry another man. She also has done a wrong thing. It is the same as if she had sex with another woman's husband. ’"
    },
    {
      "verse": "13",
      "text": "People were bringing little children to Jesus. They wanted him to put his hands on each child's head. The disciples told the people that they should not do that."
    },
    {
      "verse": "14",
      "text": "But when Jesus saw this, he was angry. He said to them, ‘Do not stop the children. Let them come to me. People must become like these children so that God can rule their lives. That is what the kingdom of God is like."
    },
    {
      "verse": "15",
      "text": "I tell you this: A person must become like a little child for God to rule in his life. If he does not become like a child, he will not come into the kingdom of God. ’"
    },
    {
      "verse": "16",
      "text": "Then Jesus took hold of the children. He put his hands on each of them and he asked God to bless them."
    },
    {
      "verse": "17",
      "text": "While Jesus was starting on his journey, a man ran to him. He went down on his knees in front of Jesus. He said to Jesus, ‘Good teacher, what must I do so that I can live with God for ever? ’"
    },
    {
      "verse": "18",
      "text": "Jesus said to him, ‘Why do you say that I am good? Only God is good. Nobody else. “Do not kill anyone. Do not have sex with anyone who is not your wife. Do not rob anyone. Do not say things that are not true about people. Do not take things that are not yours. Love your father and your mother, and obey them. ” ’"
    },
    {
      "verse": "19",
      "text": "You know God's rules:“Do not kill anyone. Do not have sex with anyone who is not your wife. Do not rob anyone. Do not say things that are not true about people. Do not take things that are not yours. Love your father and your mother, and obey them. ” ’"
    },
    {
      "verse": "20",
      "text": "‘Teacher, ’ the man replied, ‘I have obeyed all these laws since I was a young man. ’"
    },
    {
      "verse": "21",
      "text": "Jesus looked at the man and Jesus loved him. Jesus said to him, ‘There is still just one thing that you must do. Go now. Sell everything that you have. Then give the money to poor people. If you do that, you will have many valuable things in heaven. Then come back and be my disciple. ’"
    },
    {
      "verse": "22",
      "text": "When the man heard that, his face became sad. He was a very rich man. Because of that, he went away and he was very sad."
    },
    {
      "verse": "23",
      "text": "Jesus looked round and he said to his disciples, ‘It is very difficult for rich people to let God rule in their lives. ’"
    },
    {
      "verse": "24",
      "text": "They were very surprised about Jesus' words. Jesus spoke again to them: ‘My friends, it is very difficult for anyone to let God rule in their life."
    },
    {
      "verse": "25",
      "text": "The hole in a needle is very small. A camel cannot go through it! But it is even more difficult than that for a rich person to let God rule in their life. ’"
    },
    {
      "verse": "26",
      "text": "Then Jesus' disciples were even more surprised. They said to each other, ‘So perhaps God will not save anyone! ’"
    },
    {
      "verse": "27",
      "text": "Jesus looked at them and he replied, ‘For people, it really is impossible. But God can do it. God can do everything. ’"
    },
    {
      "verse": "28",
      "text": "Peter said to Jesus, ‘Look! We have left everything that we had. Now we are your disciples. ’"
    },
    {
      "verse": "29",
      "text": "Jesus said, ‘I tell you this: Some people have left their homes. Or they may have left their brothers or sisters. Or they may have left their mother or their father. Or they may have left their children or their fields. They have done that because of me. And they have done it because of God's good news."
    },
    {
      "verse": "30",
      "text": "Now, in this world, God will give those people many more things than they have left behind, even 100 times more! Yes, they will receive houses and brothers and sisters. They will receive mothers and children and fields. As well as all this, people will be against them. But in the future world, they will live for ever with God."
    },
    {
      "verse": "31",
      "text": "But many people who are very important now will not be important then. And people who are not important now will become very important then. ’"
    },
    {
      "verse": "32",
      "text": "Jesus and his disciples were walking along the road towards Jerusalem. Jesus was walking in front of them all. The disciples were very upset. Other people who were following behind them were afraid. Jesus again took his 12 apostles away from the other people. He began to tell them what would happen to him soon."
    },
    {
      "verse": "33",
      "text": "‘Listen! ’ he said to them. ‘We are going to Jerusalem. There, someone will give the Son of Man to the leaders of the priests and to the teachers of God's Law. These Jewish leaders will decide that he must die. Then they will put him under the power of people who are not Jews."
    },
    {
      "verse": "34",
      "text": "Those people will laugh at him. They will spit at him. They will hit him with whips. Then they will kill him. But after three days, he will become alive again. ’"
    },
    {
      "verse": "35",
      "text": "James and John, who were Zebedee's sons, came to Jesus. ‘Teacher, ’ they said, ‘we want to ask you for something. Please do it for us. ’"
    },
    {
      "verse": "36",
      "text": "‘What do you want me to do for you? ’ Jesus asked them."
    },
    {
      "verse": "37",
      "text": "They said to him, ‘When you are king, we want to rule with you. One of us will sit at your right side and the other one at your left side. ’"
    },
    {
      "verse": "38",
      "text": "Jesus said to them, ‘You do not understand what you are asking for. I will have much pain and trouble. Are you ready to have the same pain? Are you ready to die in the way that I will die? ’"
    },
    {
      "verse": "39",
      "text": "James and John replied, ‘Yes, we can do all that. ’Jesus said to them, ‘Yes, that is true. You will have pain like mine. And people will want to kill you like me."
    },
    {
      "verse": "40",
      "text": "But I cannot promise that you will sit at my right side or at my left side. God has chosen the people who will sit there. He has prepared the places for those people. ’"
    },
    {
      "verse": "41",
      "text": "When the other ten disciples heard about this, they were angry with James and John."
    },
    {
      "verse": "42",
      "text": "But Jesus told the disciples to come to him. He said to them, ‘You know the things that rulers of other countries do. They show that they have much power over their people. The leaders of those countries use great authority over their people."
    },
    {
      "verse": "43",
      "text": "But you should not be like that. Instead, the person who wants to be great among you must become like your servant."
    },
    {
      "verse": "44",
      "text": "Anyone who wants to be the most important person among you must work hard for you all."
    },
    {
      "verse": "45",
      "text": "Even the Son of Man came to earth to be a servant to other people. He did not come here to have servants who must work for him. No, he came to die so that many people can be free. ’"
    },
    {
      "verse": "46",
      "text": "Then Jesus and his disciples arrived in Jericho. When they were leaving the city again, a large crowd of people followed them. A blind man was sitting by the side of the road. He was asking people to give him money. His name was Bartimaeus and he was the son of Timaeus."
    },
    {
      "verse": "47",
      "text": "Somebody told Bartimaeus that Jesus from Nazareth was walking past him. So he began to shout. He said, ‘Jesus, Son of David! Please be kind to me and help me! ’"
    },
    {
      "verse": "48",
      "text": "Many people were angry with Bartimaeus. They told him that he should be quiet. But he shouted even louder than before, ‘Son of David! Please help me! ’"
    },
    {
      "verse": "49",
      "text": "Jesus stopped. He said to the people, ‘Tell the man to come here. ’ So the people said to the blind man, ‘Be brave! Stand up. Jesus is asking you to go to him. ’"
    },
    {
      "verse": "50",
      "text": "So Bartimaeus threw away his coat. He jumped up and he came to Jesus."
    },
    {
      "verse": "51",
      "text": "Then Jesus said to Bartimaeus, ‘What do you want me to do for you? ’The blind man said to Jesus, ‘Teacher, I want to see again. ’ The blind man said to Jesus, ‘Teacher, I want to see again. ’"
    },
    {
      "verse": "52",
      "text": "‘Go, ’ Jesus said to him. ‘You are well now, because you believed in me. ’ Immediately, Bartimaeus could see again. He followed Jesus along the road."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "Jesus and his disciples were coming near to Jerusalem. They were almost at the villages called Bethphage and Bethany. They were on the Mount of Olives. Then Jesus sent two of his disciples to go further."
    },
    {
      "verse": "2",
      "text": "He said to them, ‘Go into the village that is in front of you. When you arrive there, you will immediately see a young donkey. Someone has tied it there. Nobody has ever yet ridden on it. Undo the rope and bring the donkey here to me."
    },
    {
      "verse": "3",
      "text": "Someone may ask you, “Why are you doing this? ” Then say, “The Master needs the donkey. He will send it back here soon. ” ’"
    },
    {
      "verse": "4",
      "text": "So the two disciples went into the village. They found the young donkey in the street. Someone had tied it outside, by a door. So the disciples undid the rope."
    },
    {
      "verse": "5",
      "text": "Some people were standing there. They asked the two disciples, ‘What are you doing? Why are you undoing the donkey's rope? ’"
    },
    {
      "verse": "6",
      "text": "The disciples answered them. They repeated what Jesus had told them to say. The people then let them take the donkey away."
    },
    {
      "verse": "7",
      "text": "The two disciples brought the young donkey to Jesus. They put their coats on its back and Jesus sat on it."
    },
    {
      "verse": "8",
      "text": "Many people then put their coats down on the road. Other people cut branches down from trees in the fields. They put the branches down on the road as well."
    },
    {
      "verse": "9",
      "text": "Many people went in front of Jesus, and other people followed him. All of them were shouting, ‘We praise God! May the Lord God bless the king who comes with his authority! ‘We praise God! May the Lord God bless the king who comes with his authority!"
    },
    {
      "verse": "10",
      "text": "Great will be the kingdom of King David, our ancestor! We praise God above! ’ We praise God above! ’"
    },
    {
      "verse": "11",
      "text": "Jesus went into Jerusalem and went to the temple. He looked at everything there. It was late in the day, so he then went out of the city to Bethany. The 12 apostles went with him."
    },
    {
      "verse": "12",
      "text": "On the next day, they left Bethany. Jesus was hungry."
    },
    {
      "verse": "13",
      "text": "He saw a fig tree which was a long way away. There were leaves on it. So he went to see if it had fruit on it. When he reached it, he found nothing except leaves. That was because it was not the right season for it to have fruit."
    },
    {
      "verse": "14",
      "text": "So Jesus said to the tree, ‘Nobody will ever eat your fruit again. ’ And his disciples heard what he said."
    },
    {
      "verse": "15",
      "text": "When they arrived back in Jerusalem, Jesus went into the yard of the temple. People were buying and selling things there. Jesus began to make them all leave that place. Some men were changing coins there for people. He pushed over their tables. And he pushed over the seats of the men who sold birds."
    },
    {
      "verse": "16",
      "text": "Jesus would not let anyone carry things through that place."
    },
    {
      "verse": "17",
      "text": "While he was teaching the people, Jesus said, ‘The Bible says, “God's house will be a place where people from all countries pray. ” But you have changed it into a place where robbers meet. ’"
    },
    {
      "verse": "18",
      "text": "The leaders of the priests and the teachers of God's Law heard this. And they thought about how they could kill Jesus. They were afraid of him. That was because all the crowd were listening to him. And the things that he taught caused the crowd to be very surprised."
    },
    {
      "verse": "19",
      "text": "When it was evening, Jesus and his disciples went out of the city again."
    },
    {
      "verse": "20",
      "text": "The next morning, Jesus and his disciples passed the fig tree. They saw that it was completely dead."
    },
    {
      "verse": "21",
      "text": "Peter remembered what Jesus had said. So he said to Jesus, ‘Teacher, look at that fig tree. You said that it should die, and it has died. ’"
    },
    {
      "verse": "22",
      "text": "So Jesus said to them, ‘You must believe in God."
    },
    {
      "verse": "23",
      "text": "I tell you this: A person could say to this mountain, “Move and throw yourself into the sea. ” Then it will happen like he says. But he must not let other ideas come into his mind. He must really believe that those things will happen. If he does believe it, God will do those things for him."
    },
    {
      "verse": "24",
      "text": "So I tell you this. When you pray to ask God for anything, believe in him. Believe that you have received that thing. Then you will have whatever you have asked for."
    },
    {
      "verse": "25",
      "text": "But when you stand up to pray, first you must forgive other people. If anyone has done something bad against you, forgive that person."
    },
    {
      "verse": "26",
      "text": "If you do forgive them, your Father in heaven will forgive you. God will forgive you for the bad things that you have done. ’"
    },
    {
      "verse": "27",
      "text": "Jesus and his disciples arrived again in Jerusalem. Jesus was walking about in the yard at the temple. The leaders of the priests, the teachers of God's Law and the important Jews came to him."
    },
    {
      "verse": "28",
      "text": "They asked him, ‘What authority do you have to do these things? Who gave you the authority to do them? ’"
    },
    {
      "verse": "29",
      "text": "Jesus replied, ‘I will ask you one question and you should answer me. If you do that, then I will answer your question. I will tell you what authority I have to do these things."
    },
    {
      "verse": "30",
      "text": "John baptized people. Did God give him authority to do this? Or did men tell him to do it? Now, tell me your answer. ’"
    },
    {
      "verse": "31",
      "text": "Then the Jewish leaders talked to each other. They said, ‘We could say that God gave John his authority. But, if we say that, Jesus will say to us, “Then you should have believed John. ”"
    },
    {
      "verse": "32",
      "text": "But we do not want to say that only men gave John his authority. ’ The Jewish leaders were afraid of the crowd. All the people thought that John really was a prophet from God."
    },
    {
      "verse": "33",
      "text": "So the Jewish leaders answered Jesus: ‘We do not know who gave John his authority. ’So Jesus said to them, ‘You will not answer my question. So I will not tell you what authority I have to do these things. ’"
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "Then Jesus began to speak again to the important Jews. He told them stories. He said, ‘There was a man who made a garden. He planted vines to grow grapes there. He built a wall around the garden. He dug a hole in the ground where he could make the grapes into wine. He also built a tall building to watch over the garden. He found some farmers who would work in the garden for him. Then he went away to another country."
    },
    {
      "verse": "2",
      "text": "At the time for the harvest, the man sent a servant to speak to the farmers. He wanted them to give him some fruit from the garden."
    },
    {
      "verse": "3",
      "text": "But the farmers took hold of the servant and they hit him with sticks. They sent him away with nothing."
    },
    {
      "verse": "4",
      "text": "So the man sent another servant to the farmers. They also hit this servant on the head, and they did other bad things to him."
    },
    {
      "verse": "5",
      "text": "The man then sent another servant, but the farmers killed this servant. He sent many other servants to them. The farmers hit some of these servants with sticks and they killed other servants."
    },
    {
      "verse": "6",
      "text": "The man had only one person that he could still send. This was his own son. The man loved him very much. So, last of all, he sent his son to the farmers. He thought, “The farmers will surely respect my son. ”"
    },
    {
      "verse": "7",
      "text": "But those farmers said to each other, “This is the son of our master. The garden will belong to him when his father dies. We should kill the son and then the garden will be ours. ”"
    },
    {
      "verse": "8",
      "text": "So the farmers took the son and they killed him. Then they threw his dead body out of the garden. ’"
    },
    {
      "verse": "9",
      "text": "Jesus then asked, ‘What will the master of the garden do then? I tell you, he will come and he will kill those farmers. Then he will give the garden to other people to take care of it. “The builders refused to use a certain stone. They thought that it had no value. But now that stone has become the most important stone at the corner of the building."
    },
    {
      "verse": "10",
      "text": "I am sure that you have read these words in the Bible:“The builders refused to use a certain stone. They thought that it had no value. But now that stone has become the most important stone at the corner of the building."
    },
    {
      "verse": "11",
      "text": "The Lord God did this. And we can see that he did something great. ” ’ And we can see that he did something great. ” ’"
    },
    {
      "verse": "12",
      "text": "The Jewish leaders knew that Jesus had told this story about them. They were the bad farmers in the story. So they wanted to take hold of Jesus. But they were afraid of the crowd. So they left him and they went away."
    },
    {
      "verse": "13",
      "text": "Then the leaders sent some Pharisees to Jesus. They also sent some men who were friends of King Herod. They tried to use Jesus' words to cause trouble for him."
    },
    {
      "verse": "14",
      "text": "These men came to Jesus and they said, ‘Teacher, we know that you only say true things. It does not matter to you what other people think. If someone is important, you do not change your answers to make them happy. You really do teach us what God wants us to do. Tell us, should we pay our taxes to the Roman ruler, Caesar? Is it right to give that money to him, or not? ’"
    },
    {
      "verse": "15",
      "text": "Jesus knew that those men were not honest. So he said, ‘You just ask that question to cause trouble for me. Now, bring me a coin. I want to see it. ’ They replied, ‘It is Caesar's picture and Caesar's name. ’"
    },
    {
      "verse": "16",
      "text": "So they brought a coin to him. Jesus asked them, ‘Whose picture is on this coin? Whose name is on it? ’They replied, ‘It is Caesar's picture and Caesar's name. ’"
    },
    {
      "verse": "17",
      "text": "Jesus then said to them, ‘So you should give to Caesar the things that belong to him. And give to God the things that belong to God. ’They were very surprised at his answer. They were very surprised at his answer."
    },
    {
      "verse": "18",
      "text": "Also, some Sadducees came to Jesus. Sadducees do not believe that anyone becomes alive again after they die. They wanted to ask Jesus a question."
    },
    {
      "verse": "19",
      "text": "‘Teacher, ’ they said to him, ‘Moses wrote these things for us in the Bible: If a man dies without children, his brother must marry the man's wife. Then their children will be called the children of the brother who died."
    },
    {
      "verse": "20",
      "text": "But once there were seven brothers. The oldest brother married a woman. But he died before they had any children."
    },
    {
      "verse": "21",
      "text": "So the second brother married her. He also died without children. Then the third brother married this woman."
    },
    {
      "verse": "22",
      "text": "And the same thing happened to all seven brothers. They all died but they had no children. After all this, the woman also died."
    },
    {
      "verse": "23",
      "text": "You teach that at some time dead people will become alive again. On that day, whose wife will that woman be? She had married all seven of those brothers. ’"
    },
    {
      "verse": "24",
      "text": "Jesus said to the Sadducees, ‘You are very wrong. This is because you do not know the Bible. And you do not know how powerful God is."
    },
    {
      "verse": "25",
      "text": "All people who have died will become alive again one day. But then men and women will not marry. They will not have husbands or wives. Instead, they will be like the angels in heaven."
    },
    {
      "verse": "26",
      "text": "But God does make dead people alive again! You have read what Moses wrote about the bush in the wilderness. There, God said to Moses, “I am the God of Abraham. I am the God of Isaac. And I am the God of Jacob. ”"
    },
    {
      "verse": "27",
      "text": "God is not the God of people who are dead. He is the God of people who are alive. So you see, you are very wrong. ’"
    },
    {
      "verse": "28",
      "text": "One of the teachers of God's Law came near to the group of people. He heard Jesus speaking with the leaders. The teacher knew that Jesus had answered them well. So then the teacher asked Jesus, ‘Which rule is the most important among God's Laws? ’"
    },
    {
      "verse": "29",
      "text": "Jesus replied, ‘This rule is the most important rule: “Listen, Israel's people! The Lord alone is our God. There is no other Lord."
    },
    {
      "verse": "30",
      "text": "Love the Lord, your God completely. Love him with all your mind and with all your strength. Love him in everything that you think and you do. ”"
    },
    {
      "verse": "31",
      "text": "The second most important rule is this: “You should love other people as much as you love yourself. ” No other rules are as important as these two. ’"
    },
    {
      "verse": "32",
      "text": "The teacher of God's Law said to Jesus, ‘Teacher, you have answered well. You are right to say that the Lord is the only God. And there is no other God except him."
    },
    {
      "verse": "33",
      "text": "We must love him completely, with all our mind and with all our strength. We must also love other people as much as we love ourselves. This is more important than all the gifts or animals that we could offer to God. ’"
    },
    {
      "verse": "34",
      "text": "Jesus heard that the man had answered well. So Jesus said to him, ‘You are almost ready for God to rule in your life. ’ After that, everybody was afraid to ask Jesus any more questions."
    },
    {
      "verse": "35",
      "text": "Jesus was teaching people in the yard at the temple. He said, ‘The teachers of God's Law say that the Messiah is King David's son. What do you think about that? “The Lord God said to my Lord: Sit at my right side until I win against your enemies. The you will be able to put your feet on them. ”"
    },
    {
      "verse": "36",
      "text": "The Holy Spirit helped David himself to say:“The Lord God said to my Lord: Sit at my right side until I win against your enemies. The you will be able to put your feet on them. ”"
    },
    {
      "verse": "37",
      "text": "In these words, David himself calls the Messiah his Lord. So can you really say that the Messiah is David's son? ’The large crowd liked to listen to the things that Jesus was saying. It made them happy. The large crowd liked to listen to the things that Jesus was saying. It made them happy."
    },
    {
      "verse": "38",
      "text": "As Jesus was teaching the people, he said, ‘Be careful not to do the same as the teachers of God's Law. They want people to think that they are important. So they walk about in beautiful long clothes. They like people to praise them in the market place."
    },
    {
      "verse": "39",
      "text": "They want to sit in the best seats in the meeting places. They choose the most important places at special meals."
    },
    {
      "verse": "40",
      "text": "But these men take things away from women after their husbands have died, even their houses. Then they pray for a long time so that other people will praise them. Because they do these things, God will punish those men much more than other people. ’"
    },
    {
      "verse": "41",
      "text": "Many people were giving their gifts for the temple. There was a box for money there. People threw their coins into it. Jesus sat near the box and he watched them. Many rich people put a lot of money into the box."
    },
    {
      "verse": "42",
      "text": "But then a woman came there. Her husband had died and she was very poor. She put two small coins that had only a little value into the box."
    },
    {
      "verse": "43",
      "text": "Jesus asked his disciples to come to him. He said to them, ‘I tell you this: This poor woman has put a better gift into the box than all the other people have put in there."
    },
    {
      "verse": "44",
      "text": "All those rich people have plenty of money. They only put a small part of that into the box. But this woman has almost nothing. She put in all the money that she had. That was all the money that she needed to live. ’"
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "Then Jesus left the temple. While he was leaving, one of his disciples said to him, ‘Teacher, look at these great buildings! The stones in the walls of God's House are really great! ’"
    },
    {
      "verse": "2",
      "text": "Jesus said to him, ‘Yes, look at all these large buildings! But I tell you, enemies will completely destroy them. Not even one stone will remain on top of another stone. ’"
    },
    {
      "verse": "3",
      "text": "After that, Jesus was sitting on the Mount of Olives. He could look across the valley at the temple. Peter, James, John and Andrew went together to talk with him. The crowd was not there."
    },
    {
      "verse": "4",
      "text": "They said to Jesus, ‘Please tell us when all these things will happen. What will show us that they will soon happen? ’"
    },
    {
      "verse": "5",
      "text": "Jesus began to say to them, ‘Be careful! Some people will tell you things that are not true. Do not believe those people."
    },
    {
      "verse": "6",
      "text": "Many people will say that they have come on my behalf. They will say, “I am the Messiah! ” and they will deceive many people."
    },
    {
      "verse": "7",
      "text": "You will hear about wars. And there will be reports about wars in other places. Do not be afraid. Those things must happen, but that is not yet the end of everything."
    },
    {
      "verse": "8",
      "text": "People in one country will attack the people in another country. Kings and their armies will fight against other kings and their armies. The ground will shake in many different places. In some places, people will be hungry, with no food. Those things are like the first pains that a mother has before her baby is born."
    },
    {
      "verse": "9",
      "text": "So be careful! People will be against you. They will take you to stand in front of their leaders. They will punish you with whips in their meeting places. They will take you to stand in front of kings and rulers. This will happen because you are my disciples. You will tell them the good news about me."
    },
    {
      "verse": "10",
      "text": "Yes, you must first tell the good news about me to people in every country."
    },
    {
      "verse": "11",
      "text": "When people take you to their leaders to show that you have done bad things, do not be afraid. Do not worry about what you should say. You should say the words that God gives you at that time. You will not be speaking your own words. Those words will come from the Holy Spirit."
    },
    {
      "verse": "12",
      "text": "At that time, a man will let people kill his own brother. A father will let people kill his own child. Children will be against their parents. They will even ask people to kill their parents."
    },
    {
      "verse": "13",
      "text": "All people will hate you because you are my disciples. But God will save the person who remains strong until the end."
    },
    {
      "verse": "14",
      "text": "There will be a time when you will see in the temple a disgusting thing that causes trouble. You will see it in a place where it should not be. (When you read this, you must understand what it means. ) At that time, people in Judea must run away to the hills to hide."
    },
    {
      "verse": "15",
      "text": "A person who is on the roof of his house must not go down into the house. He must not stop to get anything from his home."
    },
    {
      "verse": "16",
      "text": "A person who is outside in his field must not go back to his home. He must not return even to fetch his coat."
    },
    {
      "verse": "17",
      "text": "That will be a bad time for women who are soon to have a baby. It will also be a bad time for those women who have little babies."
    },
    {
      "verse": "18",
      "text": "You must pray to God that this time of trouble will not happen in winter."
    },
    {
      "verse": "19",
      "text": "Very bad troubles will happen to people at that time and cause them a lot of pain. Nothing as bad has ever happened before, since God created the world. Nothing as bad will ever happen again."
    },
    {
      "verse": "20",
      "text": "The Lord God will cause those days of very bad trouble to come to an end. If he did not do that, there would be nobody still alive. But God will cause those days to be not too many. He will do that to help the people that he has chosen."
    },
    {
      "verse": "21",
      "text": "At that time, someone may say to you, “Look, here is the Messiah! ” Or they may say, “Look, he is there! ” If they say that, do not believe them."
    },
    {
      "verse": "22",
      "text": "Some people will even say, “I am the Messiah. ” Other people will say, “I am a prophet from God. ” But their words will be false. They will do strange and powerful things for people to see. If possible, they would even deceive the people that God has chosen."
    },
    {
      "verse": "23",
      "text": "So watch out! I have told you about all these things before they happen."
    },
    {
      "verse": "24",
      "text": "Then, after all these bad things have happened, the sun will become dark. The moon will not shine any more."
    },
    {
      "verse": "25",
      "text": "Stars will fall out of the sky. And the powerful things in the sky will shake."
    },
    {
      "verse": "26",
      "text": "Then people will see the Son of Man. He will come in the clouds. He will have great power and bright glory."
    },
    {
      "verse": "27",
      "text": "Then he will send his angels. They will go in every direction, to every part of the earth and to every part of the sky. They will bring together all the people that God has chosen."
    },
    {
      "verse": "28",
      "text": "Here is a lesson for you to learn about the fig tree. When the new branches on the tree start to grow, the leaves appear. Then you know that the summer will begin soon."
    },
    {
      "verse": "29",
      "text": "In the same way, you will see these strange things happening. Then you will know that the Son of Man will come very soon. He will be like someone at the door who is ready to come in."
    },
    {
      "verse": "30",
      "text": "I tell you this: The people who are alive now will not all die until all these things happen."
    },
    {
      "verse": "31",
      "text": "One day, the earth and the sky will have an end. But my words will be there for ever."
    },
    {
      "verse": "32",
      "text": "Nobody knows the day or the hour when all these things will happen. Only God the Father knows when they will happen. The angels who are in heaven do not know. Even the Son does not know."
    },
    {
      "verse": "33",
      "text": "Watch carefully! Keep awake! You do not know the time when all these things will happen."
    },
    {
      "verse": "34",
      "text": "It is like when a man begins a journey. Before the master leaves his house, he gives authority to his servants. He tells each servant about the work that he should do. Then he tells the servant at the door to watch for his master's return."
    },
    {
      "verse": "35",
      "text": "So you must watch carefully. You do not know when the master of the house will come back. He might arrive in the evening, or in the middle of the night. Or he might arrive early in the morning, or just before the sun rises."
    },
    {
      "verse": "36",
      "text": "When he arrives, he may surprise you. He may even find you asleep!"
    },
    {
      "verse": "37",
      "text": "I am saying this to you. I am also saying this to everyone else. Always be ready! ’"
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "It was now two days before the Passover festival. It was the time when Jews eat flat bread which has no yeast in it. The leaders of the priests and the teachers of God's Law wanted to kill Jesus. But they wanted to take hold of him secretly. So they tried to decide how they could do that."
    },
    {
      "verse": "2",
      "text": "They said to each other, ‘We do not want to do it during the festival. If we do that, the people will be angry. Then they may fight against us. ’"
    },
    {
      "verse": "3",
      "text": "Then Jesus went to Bethany, and he visited Simon at his house. At one time, Simon had had a bad disease of the skin. While Jesus was eating a meal there, a woman came into the house. She brought a small stone jar that contained expensive oil with a very nice smell. They used nard to make it. The woman broke the jar to open it. Then she poured the oil over Jesus' head."
    },
    {
      "verse": "4",
      "text": "But some people became angry. They said to each other, ‘This woman should not have wasted the oil."
    },
    {
      "verse": "5",
      "text": "She could have sold it and she could have given the money to poor people. She could have sold it for more than 300 coins. A man would have to work for a year to get that much money. ’ So they spoke angrily to the woman."
    },
    {
      "verse": "6",
      "text": "But Jesus said, ‘Do not speak to her like that! Do not cause trouble for her. She has done a good thing to me."
    },
    {
      "verse": "7",
      "text": "You will always have poor people with you. You can help them at any time that you want. But you will not always have me with you."
    },
    {
      "verse": "8",
      "text": "This woman did what she was able to do. She poured oil over my body. So now, my body will be ready for people to bury me."
    },
    {
      "verse": "9",
      "text": "I tell you this: Everywhere in the world, people will speak about God's good news. At the same time, they will also tell people about the good thing that this woman has done. And so they will remember her. ’"
    },
    {
      "verse": "10",
      "text": "Then Judas Iscariot went to the leaders of the priests. He said that he would help them to catch Jesus. (Judas was one of Jesus' 12 apostles. )"
    },
    {
      "verse": "11",
      "text": "The leaders of the priests were very happy about this. They promised to give Judas some money. Then Judas waited for the right moment to help them to take hold of Jesus."
    },
    {
      "verse": "12",
      "text": "The first day of the festival when the Jews eat flat bread arrived. On this day, each family kills a young sheep for the Passover meal. Jesus' disciples said to him, ‘We will go to prepare the Passover meal for you. Where do you want us to do that? ’"
    },
    {
      "verse": "13",
      "text": "So Jesus sent two disciples to prepare the meal. ‘Go into the city, ’ he said to them. ‘A man, who is carrying a jar of water, will meet you. Follow him."
    },
    {
      "verse": "14",
      "text": "He will go to a house. You must say to the master of that house, “The Teacher sends this message to you: ‘Where is the room for visitors? I will eat the Passover meal there with my disciples. ’ ”"
    },
    {
      "verse": "15",
      "text": "Then the man will show you a large room upstairs. The room will have in it all the things that you will need. You should prepare the Passover meal for us there. ’"
    },
    {
      "verse": "16",
      "text": "Then the two disciples left and they went into the city. They found everything as Jesus had told them. So they prepared the Passover meal there."
    },
    {
      "verse": "17",
      "text": "When it was evening, Jesus arrived with the 12 apostles."
    },
    {
      "verse": "18",
      "text": "While they were eating the meal, Jesus said, ‘I tell you this: One of you will help the Jewish leaders to take hold of me. It is someone who is eating this meal with me. ’"
    },
    {
      "verse": "19",
      "text": "The disciples became very sad. Each one of them said to Jesus, ‘Surely you do not mean me, do you? ’"
    },
    {
      "verse": "20",
      "text": "Jesus said to them, ‘It is one of you 12 apostles. That man is eating from the same dish as I am."
    },
    {
      "verse": "21",
      "text": "The Son of Man must die in the way that the Bible says. But it will be very bad for the man who gives me to my enemies. It would have been better for that man if he had not been born. ’"
    },
    {
      "verse": "22",
      "text": "While Jesus and his disciples were eating, he took a loaf of bread. He thanked God for it. Then he broke the bread into pieces. He gave some of it to each of his disciples. ‘Take this bread and eat it, ’ he said to them. ‘This is my body. ’"
    },
    {
      "verse": "23",
      "text": "Then Jesus took a cup. He thanked God for the wine in the cup. Then he gave the cup to them and they all drank from it."
    },
    {
      "verse": "24",
      "text": "Jesus said to them, ‘This is my blood that shows God's promise. When I die, my blood will pour out of my body. In that way God will save many people. That is the promise that God makes because of my death."
    },
    {
      "verse": "25",
      "text": "I tell you this: I will not drink wine again until God rules in his kingdom. Then it will be new wine. ’"
    },
    {
      "verse": "26",
      "text": "Then Jesus and his disciples sang a song to praise God. Then they went out to the Mount of Olives."
    },
    {
      "verse": "27",
      "text": "Then Jesus said to the disciples, ‘All of you will turn away from me. It will happen as the Bible says: God says, “I will kill the shepherd who leads the sheep. Then the sheep will run away in different directions. ” ’ God says, “I will kill the shepherd who leads the sheep. Then the sheep will run away in different directions. ” ’"
    },
    {
      "verse": "28",
      "text": "Jesus then said, ‘But after that happens, I will become alive again. Then I will go to Galilee, and you will meet me there. ’"
    },
    {
      "verse": "29",
      "text": "Peter said to Jesus, ‘Even if everyone else runs away, I will not leave you. ’"
    },
    {
      "verse": "30",
      "text": "Jesus replied, ‘I tell you this: Even tonight, you will say that you do not know me. You will say that three times before the cockerel sings for the second time in the morning. ’"
    },
    {
      "verse": "31",
      "text": "But Peter said very strongly, ‘I will die with you if I need to. But I will never say that I do not know you. ’ All the other disciples said the same thing."
    },
    {
      "verse": "32",
      "text": "Then they arrived at a garden called Gethsemane. Jesus said to his disciples, ‘Sit here while I pray. ’"
    },
    {
      "verse": "33",
      "text": "Jesus took Peter, James and John with him. He started to feel very sad and upset."
    },
    {
      "verse": "34",
      "text": "He said to them, ‘I am very sad. I feel as if I could die because I feel so sad. Wait here and stay awake. ’"
    },
    {
      "verse": "35",
      "text": "Jesus went a short way beyond them. He went down on the ground. He prayed that, if possible, God would save him from this time of trouble."
    },
    {
      "verse": "36",
      "text": "He said, ‘Abba, my Father, you can do all things. Please take this great pain away from me. But I do not ask you to do what I want. Do what you want to do. ’"
    },
    {
      "verse": "37",
      "text": "Jesus returned to his three disciples. Now they were sleeping. He said to Peter, ‘Simon, you are asleep! You could not stay awake for even one hour!"
    },
    {
      "verse": "38",
      "text": "You must keep awake and you must pray. Then you will not want to do something wrong. You really want to do the right thing, but your body is weak. ’"
    },
    {
      "verse": "39",
      "text": "Jesus went away again and he prayed in the same words."
    },
    {
      "verse": "40",
      "text": "Then Jesus returned again to Peter, James and John. He saw that they were sleeping. They could not keep their eyes open. They did not know what to say to him."
    },
    {
      "verse": "41",
      "text": "Then Jesus returned a third time to the disciples. He said to them, ‘You should not still be sleeping and resting. That is enough! The moment has arrived. Look! Someone will now give me, the Son of Man, to my enemies."
    },
    {
      "verse": "42",
      "text": "Stand up, we will go now. Look! The man who will give me to my enemies is here. ’"
    },
    {
      "verse": "43",
      "text": "Jesus was still speaking when, immediately, Judas arrived. He was one of Jesus' 12 apostles. A crowd came with him. They were carrying swords and heavy sticks. The leaders of the priests, the teachers of God's Law and the important Jews had sent these men."
    },
    {
      "verse": "44",
      "text": "Before this, Judas had told these men, ‘I will kiss one of the men. You must take hold of that man. Lead him away and do not let him go. ’"
    },
    {
      "verse": "45",
      "text": "When they arrived, Judas went immediately to Jesus. ‘Teacher, ’ he said to Jesus. Then he kissed Jesus in a friendly way."
    },
    {
      "verse": "46",
      "text": "So the men took hold of Jesus to lead him away."
    },
    {
      "verse": "47",
      "text": "But a certain man who was standing there took hold of his sword. He hit the servant of the leader of the priests with it and he cut off the servant's ear."
    },
    {
      "verse": "48",
      "text": "Then Jesus spoke to the crowd. He said, ‘You have come out here with swords and heavy sticks to take hold of me. Do you really think that I am leading people to fight against our country's rulers?"
    },
    {
      "verse": "49",
      "text": "No! I was with you every day when I was teaching people in the yard of the temple. You did not try to take hold of me then. But this must happen in the way that the Bible says it would happen. ’"
    },
    {
      "verse": "50",
      "text": "Then all Jesus' disciples left him and they ran away."
    },
    {
      "verse": "51",
      "text": "A certain young man was following Jesus. He was wearing only one piece of linen cloth to cover himself. The men tried to take hold of this young man."
    },
    {
      "verse": "52",
      "text": "But the young man left the piece of cloth behind and he ran away. So when he ran away, he was not wearing anything."
    },
    {
      "verse": "53",
      "text": "The men took Jesus to the house of the most important priest. All the leaders of the priests met together there with the important Jews and with the teachers of God's Law."
    },
    {
      "verse": "54",
      "text": "Peter followed Jesus into the yard of Caiaphas's house. But he did not go near Jesus. He sat down in the yard with the guards and he made himself warm by the fire."
    },
    {
      "verse": "55",
      "text": "The leaders of the priests and all the Jewish leaders wanted to punish Jesus with death. So they tried to find some people who would say things against Jesus. But they did not find anyone who could help them."
    },
    {
      "verse": "56",
      "text": "Many people said things against Jesus that were not true. But they did not agree with each other in what they said."
    },
    {
      "verse": "57",
      "text": "Then some men stood up and they said something false against Jesus."
    },
    {
      "verse": "58",
      "text": "They said, ‘We heard Jesus say, “I will destroy the temple, which men have built. In three days I will build another House for God. It will not be people who build this new house. ” ’"
    },
    {
      "verse": "59",
      "text": "Even then, these people who were speaking against Jesus did not say the same thing."
    },
    {
      "verse": "60",
      "text": "Then Caiaphas stood up in front of everyone. He said to Jesus, ‘You must reply now to what these men have said against you. Are the things that they are saying true? ’ So again, Caiaphas asked Jesus, ‘Are you the Messiah? Are you the Son of God? ’"
    },
    {
      "verse": "61",
      "text": "But Jesus did not reply. He did not say anything. So again, Caiaphas asked Jesus, ‘Are you the Messiah? Are you the Son of God? ’"
    },
    {
      "verse": "62",
      "text": "‘I am, ’ Jesus replied. ‘And you will all see the Son of Man. He will be sitting in the most important place at the right side of the Most Powerful God. You will see him coming to earth. He will be riding on the clouds in the sky. ’"
    },
    {
      "verse": "63",
      "text": "Then Caiaphas tore his clothes to show that he was angry. ‘We do not need anyone else to speak against Jesus, ’ he said. Everyone agreed that Jesus deserved to die."
    },
    {
      "verse": "64",
      "text": "‘You have heard the bad words that he has spoken against God. Do you think that he is guilty? ’Everyone agreed that Jesus deserved to die."
    },
    {
      "verse": "65",
      "text": "Then some of the men began to spit on Jesus. They covered his eyes with a cloth and they hit him many times with their fists. They said, ‘Show us that you are a prophet! Tell us who hit you! ’ Then the guards took hold of Jesus and they beat him."
    },
    {
      "verse": "66",
      "text": "Peter was still sitting outside in the yard. One of the young women who was a servant of the most important priest came there. She looked at him and she said, ‘You also were a friend of Jesus, the man from Nazareth. ’"
    },
    {
      "verse": "67",
      "text": "She saw Peter, who was making himself warm by the fire. She looked at him and she said, ‘You also were a friend of Jesus, the man from Nazareth. ’"
    },
    {
      "verse": "68",
      "text": "Peter replied, ‘That is not true! I do not even know what you are talking about! ’ Then Peter went out to the gate of the yard. At that moment a cockerel sang."
    },
    {
      "verse": "69",
      "text": "The young woman watched him, and again she said to the other people there, ‘He is one of the men who were friends of Jesus. ’ After a little time, the other people who were standing there said to Peter, ‘We know you are from Galilee. So we are sure that you are one of those men. ’"
    },
    {
      "verse": "70",
      "text": "But Peter again said that it was not true. After a little time, the other people who were standing there said to Peter, ‘We know you are from Galilee. So we are sure that you are one of those men. ’"
    },
    {
      "verse": "71",
      "text": "Then Peter began to speak very strongly to them. He said, ‘I do not know this man that you are talking about. God will surely punish me if this is not true! ’ When Peter thought about this, he wept very much."
    },
    {
      "verse": "72",
      "text": "Immediately a cockerel sang loudly for a second time. Then Peter remembered what Jesus had said to him: ‘You will say three times that you do not know me. You will do it before the cockerel sings for the second time. ’When Peter thought about this, he wept very much."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "Very early the next morning, all the Jewish leaders met together. The leaders of the priests met with the leaders, the teachers of God's Law, and the other important Jews. They decided what they would do. They tied Jesus' hands and feet and they took him to Pilate's house. They put him under Pilate's authority."
    },
    {
      "verse": "2",
      "text": "Pilate asked Jesus, ‘Are you the king of the Jews? ’Jesus replied, ‘You have said it. ’ Jesus replied, ‘You have said it. ’"
    },
    {
      "verse": "3",
      "text": "Then the leaders of the priests told Pilate that Jesus had done many bad things."
    },
    {
      "verse": "4",
      "text": "So Pilate asked him again, ‘What is your answer? You should say something! Listen! They are saying that you have done many bad things. ’"
    },
    {
      "verse": "5",
      "text": "But Jesus still did not reply to what the men were saying against him. Pilate was very surprised about that."
    },
    {
      "verse": "6",
      "text": "During the Passover festival each year, Pilate let one person go free out of the prison. The people had to ask him for the person that they wanted."
    },
    {
      "verse": "7",
      "text": "A man called Barabbas was in the prison at that time. He and some other men had fought against the Roman rulers. And they had killed someone when they were fighting."
    },
    {
      "verse": "8",
      "text": "The crowd came to Pilate. They asked him to do what he usually did at this time."
    },
    {
      "verse": "9",
      "text": "Pilate asked the people, ‘Do you want me to let the king of the Jews go free? ’"
    },
    {
      "verse": "10",
      "text": "Pilate knew why the leaders of the priests had brought Jesus to him. They were jealous because people liked Jesus so much."
    },
    {
      "verse": "11",
      "text": "But the leaders of the priests talked strongly to the people. They said, ‘Ask Pilate to let Barabbas go free instead of Jesus. ’"
    },
    {
      "verse": "12",
      "text": "Pilate asked the crowd again, ‘So what should I do to Jesus? He is the man that you call “the king of the Jews”. ’"
    },
    {
      "verse": "13",
      "text": "The people shouted back to Pilate: ‘Kill him on a cross! ’"
    },
    {
      "verse": "14",
      "text": "‘Why should I kill him? ’ Pilate asked. ‘What bad things has he done? ’But the people shouted even louder, ‘Kill him on a cross! ’ But the people shouted even louder, ‘Kill him on a cross! ’"
    },
    {
      "verse": "15",
      "text": "Pilate decided to do what the crowd wanted. So he let Barabbas go free. He said to his soldiers, ‘Hit Jesus many times with a whip. Then take him and fix him on a cross to die. ’"
    },
    {
      "verse": "16",
      "text": "So the soldiers took Jesus to the yard at the ruler's house. They told all the soldiers in their group to come there."
    },
    {
      "verse": "17",
      "text": "Then they put a dark red coat on Jesus. They used some branches with thorns to make a crown for him. They put it on his head."
    },
    {
      "verse": "18",
      "text": "Then the soldiers began to laugh at Jesus. They said, ‘Hello, King of the Jews, you are great! ’"
    },
    {
      "verse": "19",
      "text": "They took a stick and they hit him on the head with it many times. They spat on him. Then they went down on their knees in front of him. They told him how great he was."
    },
    {
      "verse": "20",
      "text": "When they had stopped laughing at him, they took the dark red coat off him. They put his own clothes back on him. Then they took him away to the place where they would kill him on a cross."
    },
    {
      "verse": "21",
      "text": "When the soldiers were taking Jesus out to that place, a man called Simon was there. He was coming in from outside the city. He was from the city of Cyrene, and he was the father of Alexander and Rufus. The soldiers told Simon that he must carry Jesus' cross."
    },
    {
      "verse": "22",
      "text": "The soldiers took Jesus to a place that is called Golgotha. (Golgotha means ‘the place of a skull’. )"
    },
    {
      "verse": "23",
      "text": "They tried to give Jesus some wine to drink. They had mixed some medicine called myrrh into the wine. But Jesus would not drink it."
    },
    {
      "verse": "24",
      "text": "Then the soldiers fixed Jesus onto the cross. They took his clothes for themselves. They played a game to decide which soldier would receive each of his clothes."
    },
    {
      "verse": "25",
      "text": "It was about nine o'clock in the morning when the soldiers fixed Jesus to the cross."
    },
    {
      "verse": "26",
      "text": "They put a notice there to show the reason why they were killing him. It said, ‘The King of the Jews’."
    },
    {
      "verse": "27",
      "text": "They also put two robbers on crosses near to Jesus. One robber was on Jesus' right side. The other robber was on his left side."
    },
    {
      "verse": "28",
      "text": "[The Bible says that this would happen. It says, ‘People thought of him as someone who did not obey God's Law. ’]"
    },
    {
      "verse": "29",
      "text": "The people who walked near there insulted Jesus. They laughed at him and they said, ‘Oh! You said that you would destroy the temple. And you said that in three days you would build it again."
    },
    {
      "verse": "30",
      "text": "If you can really do that, save yourself. Come down from the cross! ’"
    },
    {
      "verse": "31",
      "text": "The leaders of the priests and the teachers of God's Law laughed at him. They said to each other, ‘This man saved other people, did he? But he cannot save his own life!"
    },
    {
      "verse": "32",
      "text": "If he is the Messiah, the king of Israel, he should come down from the cross now. Then we would see it and we would believe in him. ’ The two men who were on the crosses next to Jesus also insulted him."
    },
    {
      "verse": "33",
      "text": "At midday, the whole country became dark for three hours."
    },
    {
      "verse": "34",
      "text": "At three o'clock in the afternoon, Jesus shouted loudly, ‘Eloi, Eloi, lema sabachthani? ’ That means, ‘My God, my God, why have you left me alone? ’"
    },
    {
      "verse": "35",
      "text": "Some people who were standing near there heard him. They said to each other, ‘Look! He is shouting to Elijah. ’"
    },
    {
      "verse": "36",
      "text": "One man ran to get a piece of cloth. He poured cheap wine on it, and he put it on the end of a stick. Then he lifted it up to Jesus so that he could drink the wine from it. The man said, ‘Wait! Now we will see if Elijah comes to take him down from the cross. ’"
    },
    {
      "verse": "37",
      "text": "Then Jesus shouted loudly, and after that he died."
    },
    {
      "verse": "38",
      "text": "And the curtain inside the temple completely tore into two parts from the top down to the bottom."
    },
    {
      "verse": "39",
      "text": "The captain of the soldiers was standing there in front of Jesus. He saw how Jesus died. ‘It must be true! ’ he said. ‘This man really was the Son of God. ’"
    },
    {
      "verse": "40",
      "text": "Some women were also there. They were watching these events from a long way away. Mary from Magdala was one of the women. Mary the mother of the younger James and Joses was also there. Salome was there too."
    },
    {
      "verse": "41",
      "text": "These women had travelled with Jesus when he was in Galilee and they had helped him. Many other women were also there near the cross. They had come to Jerusalem with Jesus."
    },
    {
      "verse": "42",
      "text": "It was Friday and the Jews were preparing for their day of rest on the Sabbath."
    },
    {
      "verse": "43",
      "text": "That evening, a man called Joseph went to see Pilate. Joseph was from a town called Arimathea. He was a good man and he was one of the group of important Jewish leaders. He was waiting for the time when God would start to rule his people in his kingdom. Joseph bravely asked Pilate for the dead body of Jesus to bury it."
    },
    {
      "verse": "44",
      "text": "Pilate was surprised that Jesus had already died. He asked the captain of the soldiers to come to him. He asked him if Jesus had already died."
    },
    {
      "verse": "45",
      "text": "The captain told Pilate that Jesus was already dead. So then Pilate let Joseph go and take Jesus' dead body."
    },
    {
      "verse": "46",
      "text": "Joseph bought a piece of linen cloth. He took Jesus' body down from the cross and he put the cloth around it. Then he put the body in a large hole in a rock. People had made that hole to put dead bodies in. After this, Joseph rolled a big stone across the front of the hole to shut it."
    },
    {
      "verse": "47",
      "text": "Mary from Magdala and Mary the mother of Joses were watching. They saw where Joseph had put Jesus' dead body."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "After the day of rest had finished, the women bought some spices. They wanted to mix these with some oil to put on Jesus' body. These women were Mary from Magdala, Salome, and Mary the mother of James."
    },
    {
      "verse": "2",
      "text": "They went out at dawn on the first day of the week, Sunday. They went to the hole in the rock where Joseph had put Jesus' dead body."
    },
    {
      "verse": "3",
      "text": "The women asked each other, ‘Who will roll away the heavy stone for us? It closes the hole in the rock where they put Jesus' dead body. ’"
    },
    {
      "verse": "4",
      "text": "Then they looked and they saw the stone. It was a very big stone. But someone had already rolled it away from the hole."
    },
    {
      "verse": "5",
      "text": "When the women went into the hole in the rock, they saw a young man there. He was sitting in there on the right side and he wore bright white clothes. The women were very afraid."
    },
    {
      "verse": "6",
      "text": "The young man said to them, ‘Do not be afraid. You are looking for Jesus from Nazareth. The soldiers killed him on a cross, but he has become alive again. He is not here. Look! You can see the place where the men put him."
    },
    {
      "verse": "7",
      "text": "But now you must go to tell his disciples and Peter about this. Tell them, “Jesus is going to Galilee and you must also go there. You will see him there, just as he told you it would happen. ” ’"
    },
    {
      "verse": "8",
      "text": "Then the women went out of the hole in the rock, and they ran away from that place. They were very upset and they had trouble in their minds. Because they were afraid, they did not say anything to anyone."
    },
    {
      "verse": "9",
      "text": "[Jesus became alive again early on the first day of the week. He appeared first to Mary from Magdala. Jesus had caused seven bad spirits to leave her."
    },
    {
      "verse": "10",
      "text": "She went to the people who had been with Jesus. They were all very sad and they were crying. Mary spoke to them."
    },
    {
      "verse": "11",
      "text": "She told them that Jesus was alive. And she told them that she had seen him. But they did not believe it."
    },
    {
      "verse": "12",
      "text": "After these things had happened, Jesus appeared to two other disciples. They were walking away from Jerusalem to their village. It seemed to them that Jesus was different."
    },
    {
      "verse": "13",
      "text": "Those two disciples went and told all the other disciples. But the other disciples did not believe them."
    },
    {
      "verse": "14",
      "text": "After that, Jesus appeared to the 11 apostles while they were eating. He told them that they were wrong not to believe. They should have been ready to believe. People had seen that he was now alive again. But the disciples had not believed them."
    },
    {
      "verse": "15",
      "text": "Then Jesus said to them, ‘Go to all people everywhere in the world. Tell God's good news to everyone."
    },
    {
      "verse": "16",
      "text": "If a person believes in me, then you should baptize that person. And God will save that person. But if a person does not believe, God will judge that person to be guilty."
    },
    {
      "verse": "17",
      "text": "These miracles will happen when people believe in me. On my behalf, they will send bad spirits out of people. They will speak new languages."
    },
    {
      "verse": "18",
      "text": "If they pick up a snake, it will not hurt them. If they drink poison, it will not hurt them. They will put their hands on ill people, and God will make those people well. ’"
    },
    {
      "verse": "19",
      "text": "So, after the Lord Jesus had spoken to the disciples, God took him up into heaven. There he sat down at the right side of God."
    },
    {
      "verse": "20",
      "text": "The disciples went out everywhere. They told people God's good news. The Lord worked with them. He did powerful things to show that the message which they spoke was true. ]"
    }
  ]
};