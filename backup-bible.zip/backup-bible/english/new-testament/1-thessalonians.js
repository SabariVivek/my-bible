module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter is from Paul, Silas and Timothy. We are writing to the people of the church in Thessalonica. You belong to God the Father and to the Lord Jesus Christ. We pray that God will continue to help you. We pray that he will give you peace in your minds. We are writing to the people of the church in Thessalonica. You belong to God the Father and to the Lord Jesus Christ. We pray that God will continue to help you. We pray that he will give you peace in your minds."
    },
    {
      "verse": "2",
      "text": "We always thank God for all of you. Every time that we pray, we pray for you."
    },
    {
      "verse": "3",
      "text": "As we pray to our Father God, we remember how you live. You do good things because you believe in Christ. You work hard to help other people because you love them and you love God. You are also strong and patient because you hope strongly in our Lord Jesus Christ."
    },
    {
      "verse": "4",
      "text": "Our Christian friends, God loves you. We know that he has chosen you to belong to him."
    },
    {
      "verse": "5",
      "text": "When we told you God's good news, it was not only words that we spoke to you. God helped us with his power and with the Holy Spirit. As a result, you were sure that our message was true. You also know that we lived among you in a good way. We had come to help you."
    },
    {
      "verse": "6",
      "text": "In your lives also, you copied our example and the example of the Lord Jesus. When you believed our message, people caused you to have a lot of trouble. But God's Holy Spirit helped you to be very happy."
    },
    {
      "verse": "7",
      "text": "As a result, you became an example to all the believers in Macedonia and in Achaia."
    },
    {
      "verse": "8",
      "text": "Because of you, people in many places have clearly heard the message about the Lord. It is not only the people in Macedonia and in Achaia who have heard it. People everywhere now know how you trust God. So, as we travel to different places, we do not need to tell people anything."
    },
    {
      "verse": "9",
      "text": "Those people themselves speak about how you accepted us. They tell us how you stopped worshipping false gods. They know that you now serve the true God who always lives."
    },
    {
      "verse": "10",
      "text": "They also tell us that you are waiting patiently for God's Son to return from heaven. God raised him up after his death on the cross. He is Jesus. He saves us from God's punishment that will come one day."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Our Christian friends, you yourselves know that our visit to you had good results."
    },
    {
      "verse": "2",
      "text": "You know what happened to us before we came to you. The people at Philippi had done bad things to us. They had caused us to have trouble. When we came to you, our God helped us to be brave. We were not afraid to tell you his good news. Many people tried to stop us, but we told you God's message."
    },
    {
      "verse": "3",
      "text": "When we tell people to obey God's message, we are not saying anything that is not true. We do not have a wrong purpose. We are not trying to deceive anyone."
    },
    {
      "verse": "4",
      "text": "Instead, we say what God wants us to say. He has chosen us to tell his good news to people. So we do not do it to make people happy. We do it to make God happy. He is the one who knows what we are really like."
    },
    {
      "verse": "5",
      "text": "When we came to you, we spoke what was true. We did not just say nice things to make you feel good. You yourselves know that. We did not try to make you give things to us. We never had a secret purpose like that. God knows that this is true."
    },
    {
      "verse": "6",
      "text": "We did not want anyone to say that we are great people. We did not want you to do that, or anyone else."
    },
    {
      "verse": "7",
      "text": "We could have used our authority over you, because we are Christ's apostles. But instead, we chose to be kind to you and to help you. We took care of you, like a mother takes care of her little children."
    },
    {
      "verse": "8",
      "text": "We loved you very much, so we wanted to tell you God's good news. We wanted to share our lives with you too."
    },
    {
      "verse": "9",
      "text": "Our Christian friends, remember how we worked so hard to help you. We worked during the day and even during the night. We did not want to cause any problems for you. So we taught you God's good news and we did not ask you to give us anything in return."
    },
    {
      "verse": "10",
      "text": "You know that we lived in a good way when we were with you. God also knows that. We were completely honest with you believers. Nobody could say that we did anything wrong."
    },
    {
      "verse": "11",
      "text": "You know that we helped you, like a father helps his own children."
    },
    {
      "verse": "12",
      "text": "We taught you clearly what is true. We helped you to be strong as believers. God has chosen you to be his own people. You belong to his great kingdom, where he rules. So we told you to live in a way that pleases him."
    },
    {
      "verse": "13",
      "text": "There is another reason why we always continue to thank God for you. When we told God's message to you, you knew that it was not human ideas. You accepted it as God's own message, and that is what it certainly is. You continue to grow as believers because of God's message that you heard."
    },
    {
      "verse": "14",
      "text": "Our Christian friends, you have received the same kind of trouble that the people in the churches of Judea received. People in your own country have caused you to have trouble and pain. The same thing happened to the people in Judea who believed in Christ Jesus. They received trouble from their own Jewish people."
    },
    {
      "verse": "15",
      "text": "People like that even killed the Lord Jesus. They killed God's prophets, too. They also did bad things against us, so that we had to leave their towns. They make God become angry. They are enemies of all people,"
    },
    {
      "verse": "16",
      "text": "because they try to stop us speaking to Gentiles. They do not want God to save anyone from another nation. In this way, they continue to do more and more bad things. When their sins become too many, God has to stop them. He has become so angry that he has punished them completely."
    },
    {
      "verse": "17",
      "text": "Our friends, we have had to go away from you for a short time. But we have not stopped thinking about you. We have wanted more and more to come to see you again."
    },
    {
      "verse": "18",
      "text": "Yes, we really wanted to return to you. Certainly, I, Paul, tried again and again to come to you, but Satan stopped us."
    },
    {
      "verse": "19",
      "text": "You are the people that make us very happy! We know that you will continue to trust God. So, when our Lord Jesus returns, we will be proud of you. You will be like a crown that he gives us when we stand in front of him."
    },
    {
      "verse": "20",
      "text": "You show the great results of our work. Yes, it is because of you that we are very happy."
    }
  ],
  "3": [
    {
      "verse": "3",
      "text": "You are receiving many troubles. We did not want anyone among you to turn away from Christ because of that. You already know that we who are believers must receive troubles like that."
    },
    {
      "verse": "4",
      "text": "Even when we were there with you, we told you that troubles would come. We told you before the troubles came and now it has really happened. You know that it is true."
    },
    {
      "verse": "5",
      "text": "That is why I had to send Timothy to come to you. I could not wait to hear news about you any longer. I wanted to know whether you still trusted Christ. I was afraid that Satan had deceived you. If he had made you turn away from Christ, our work among you would have had no results."
    },
    {
      "verse": "6",
      "text": "But now Timothy has come back to us. And he has told us good news about you. He has told us that you continue to trust Christ and you love one another. He says that you always think about us in a good way. You want very much to meet us again, as we also want to meet you."
    },
    {
      "verse": "7",
      "text": "So we have become happy again because of you, our Christian friends. We continue to suffer and we have much trouble. But we are happy because you continue to trust Christ."
    },
    {
      "verse": "8",
      "text": "Yes, we are like people who have become alive again. We know that you are strong as you trust the Lord."
    },
    {
      "verse": "9",
      "text": "We thank God very much for you! You make us very happy when we talk to God about you."
    },
    {
      "verse": "10",
      "text": "We pray very much for you, during the day and during the night. We ask God to give us the chance to visit you again. We want to help you to understand the things that you still need to know. Then you will be able to trust Christ even more."
    },
    {
      "verse": "11",
      "text": "We pray that our Father God himself and our Lord Jesus will prepare the way for us. Then we will come to visit you."
    },
    {
      "verse": "12",
      "text": "We pray that the Lord will cause you to love people more and more. We love you very much. We pray that you will love each other and all people, as we love you."
    },
    {
      "verse": "13",
      "text": "Then God will cause you to become strong inside yourselves. You will live in a completely good way. One day our Lord Jesus will come back with all the people who belong to him. Then you will stand in front of God, our Father. He will say that you are not guilty of anything that is wrong."
    },
    {
      "verse": "1",
      "text": "After a long time, we could not be patient any longer. So we decided to send our friend Timothy to come to visit you. We ourselves would stay here in Athens."
    },
    {
      "verse": "2",
      "text": "Timothy serves God with us here. He tells people the good news about Christ. We sent him to you so that he could help you to trust Christ more and more."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Christian friends, there are a few more things that we need to say. We have already taught you how to live in a way that pleases God. And we know that you are living in that way. Now we ask you to continue to live like that even more. On behalf of the Lord Jesus, we seriously ask you to do this."
    },
    {
      "verse": "2",
      "text": "You surely remember what we taught you with the authority of the Lord Jesus."
    },
    {
      "verse": "3",
      "text": "This is how God wants you to live: As his own people, he wants you to be completely good. So you must not have sex in a way that is wrong."
    },
    {
      "verse": "4",
      "text": "Each of you men must learn to rule his own body properly. Then you will do only what is pure and right."
    },
    {
      "verse": "5",
      "text": "People who do not know God strongly want to have sex in a wrong way. They cannot control themselves. You must not be like those people."
    },
    {
      "verse": "6",
      "text": "No man among you should ever have sex with the wife of a Christian friend. That would be the same as if you robbed him. It would be a bad thing to do against him. Remember that the Lord will punish everyone who does things like that. We have already told you that. We warned you very seriously about it."
    },
    {
      "verse": "7",
      "text": "God has chosen us to belong to him. He does not want us to do disgusting things. As his people, he wants us to be holy."
    },
    {
      "verse": "8",
      "text": "So do not refuse to accept what I am saying. If you do, it is not just a person that you refuse to obey. You are refusing to obey God. And God is the one who has given his Holy Spirit to you."
    },
    {
      "verse": "9",
      "text": "But I do not need to write to you about how you should love other believers. God himself has taught you how to love each other."
    },
    {
      "verse": "10",
      "text": "Certainly, you love all the believers in all the region of Macedonia. And now we ask you, as our Christian friends, ‘Please love each other more and more. ’"
    },
    {
      "verse": "11",
      "text": "Try very much to live at peace with other people. Work hard at your own job. We have already told you that you must do these things."
    },
    {
      "verse": "12",
      "text": "If you live in this way, other people who are not believers will respect you. Also, you will not have to ask anyone else to give you the things that you need."
    },
    {
      "verse": "13",
      "text": "Our Christian friends, we want you to understand properly about your friends who have died. Then you will not continue to be sad about them. People who do not hope for any life after death are sad when their friends die. But you should not be upset like those other people."
    },
    {
      "verse": "14",
      "text": "We believe that Jesus died and he rose again after death. So we also believe that people who have died as Christians will rise again. When God brings Jesus back, he will take the Christians to go with Jesus."
    },
    {
      "verse": "15",
      "text": "We are telling you the message that the Lord has given to us. This is what will happen when the Lord returns. Those of us who are still alive will not go to meet the Lord first. We will not go before those people who have already died."
    },
    {
      "verse": "16",
      "text": "On that day, the Lord himself will come down from heaven. He will shout with authority. People will hear the voice of the leader of God's angels. They will hear the sound of God's trumpet. Then those people who have died as Christians will become alive again. They will be the first people to rise up."
    },
    {
      "verse": "17",
      "text": "After that, those of us who are still alive will join together with them. God will suddenly take us up into the clouds. In that way, we will all meet the Lord in the sky. So we will all be with the Lord for ever."
    },
    {
      "verse": "18",
      "text": "Because this message is true, tell it to each other. Help one another to be strong, not sad."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Friends, we do not need to write anything to you about the dates and times when these things will happen."
    },
    {
      "verse": "2",
      "text": "You know very well about how the great day of the Lord will happen. That day will surprise people very much, like when a robber comes in the night."
    },
    {
      "verse": "3",
      "text": "At that time, people will be saying, ‘We are safe and there is no trouble for us. ’ But then, when they are not ready for it, great punishment will suddenly happen to them. It will be impossible for them to run away. Pain will suddenly come to them, like a woman who is giving birth to a baby."
    },
    {
      "verse": "4",
      "text": "But you, our Christian friends, know about these things. You are not like people who live in the dark. So when the great day of the Lord happens, it should not suddenly surprise you, like a robber might surprise you."
    },
    {
      "verse": "5",
      "text": "All of you are people who belong to the light and to the day. We who are believers do not belong to the night or to the dark."
    },
    {
      "verse": "6",
      "text": "So we must watch carefully. We should be like people who stay awake. We should not be like other people who are sleeping."
    },
    {
      "verse": "7",
      "text": "It is at night that people sleep. It is at night that people become drunk."
    },
    {
      "verse": "8",
      "text": "But we belong to the day, not to the night. So we should think clearly. We must prepare ourselves like a soldier who puts on his armour. We must continue to trust God and to love him. That will be like a metal shirt that keeps our body safe. We must also continue to hope that God will save us. That will be like a strong hat that keeps our head safe."
    },
    {
      "verse": "9",
      "text": "God did not choose us as his people so that he could be angry with us. He chose us so that he could save us because of what our Lord Jesus Christ has done."
    },
    {
      "verse": "10",
      "text": "Jesus died on our behalf so that we can live together with him. It does not matter whether we are alive or dead when he returns. We will all go to live with him."
    },
    {
      "verse": "11",
      "text": "Because of that, you should help each other to become stronger as believers. I know that you are already doing that."
    },
    {
      "verse": "12",
      "text": "Our friends, we ask you to respect your leaders who work hard among you. They lead you and they teach you what is right on the Lord's behalf."
    },
    {
      "verse": "13",
      "text": "Show them how valuable they are to you. And love them very much because of the work that they do. Live at peace among yourselves."
    },
    {
      "verse": "14",
      "text": "Friends, you must warn lazy people that they should work. If people are afraid, help them to be brave. If people are weak, take care of them. Be patient with everyone."
    },
    {
      "verse": "15",
      "text": "If someone does something bad against you, do not do anything bad against them in return. Never do that. Instead, always try to do good things that will help one other and help everyone else."
    },
    {
      "verse": "16",
      "text": "Always be happy."
    },
    {
      "verse": "17",
      "text": "Pray at all times."
    },
    {
      "verse": "18",
      "text": "Whatever may happen to you, continue to thank God. God wants you to do that, because you belong to Christ Jesus."
    },
    {
      "verse": "19",
      "text": "Do not stop the work of God's Spirit."
    },
    {
      "verse": "20",
      "text": "When people speak messages on God's behalf, do not refuse to listen."
    },
    {
      "verse": "21",
      "text": "Instead, think carefully about everything, to see if it is true. Remember to obey anything that is good."
    },
    {
      "verse": "22",
      "text": "But keep away from any kind of bad thing."
    },
    {
      "verse": "23",
      "text": "I pray that God will help you to be completely good, as his people should be. He is the one who gives us peace in our minds. I pray that he will take care of you in every way, in your spirit, in your soul and in your body. Then you will not be guilty of anything that is bad, when our Lord Jesus Christ returns."
    },
    {
      "verse": "24",
      "text": "God has chosen you to be his people. We can trust him to do what he has promised to do. So he will do all this for you."
    },
    {
      "verse": "25",
      "text": "Our Christian friends, please pray for us."
    },
    {
      "verse": "26",
      "text": "Say ‘hello’ to all the believers on our behalf, and kiss them as Christian brothers and sisters."
    },
    {
      "verse": "27",
      "text": "I tell you very seriously on the Lord's behalf, please read this letter to all the believers there."
    },
    {
      "verse": "28",
      "text": "I pray that our Lord Jesus Christ will continue to be very kind to you."
    }
  ]
};