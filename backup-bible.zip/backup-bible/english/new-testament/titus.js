module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter is from me, Paul. I am God's servant and an apostle of Jesus Christ. God has sent me to help the people that he has chosen. I teach them to understand his true message and to trust him. As a result they will live in a way that pleases God."
    },
    {
      "verse": "2",
      "text": "They will also be sure that they will live with God for ever. Before the world began, God promised that his people would have life with him. And God never tells lies."
    },
    {
      "verse": "3",
      "text": "God is the one who saves us. Now, at the proper time, he has made his message clear. He has given his message to me so that I can tell it to people. That is what he has told me to do."
    },
    {
      "verse": "4",
      "text": "I am writing to you, Titus. I told you the message about Jesus and now we both believe in him. So you are like my own child. I pray that God, the Father, and Christ Jesus, our Saviour, will continue to help you. I pray that they will give you peace in your mind. I pray that God, the Father, and Christ Jesus, our Saviour, will continue to help you. I pray that they will give you peace in your mind."
    },
    {
      "verse": "5",
      "text": "I left you in Crete so that you could finish certain things. You should make right some things that were wrong. And you should choose leaders of the believers in every town, as I told you."
    },
    {
      "verse": "6",
      "text": "This is what a leader in the church must be like. Nobody should have a reason to say that he has done something wrong. He must be the husband of only one wife. He must have children who respect him. Nobody should say that they enjoy bad things or that they do not obey their parents."
    },
    {
      "verse": "7",
      "text": "A leader in the church serves the believers on God's behalf. Because of that, nobody should have a reason to say that the leader has done anything wrong. A leader must not be proud. He must not become angry easily. He should not like to drink too much wine. He must not be someone who likes to fight. He must not want to get a lot of money for himself."
    },
    {
      "verse": "8",
      "text": "Instead, he must be happy to have visitors in his home. He must want to do good things. He must be careful in how he lives. He must do what is right. He must want to serve God well. He must control himself well."
    },
    {
      "verse": "9",
      "text": "A leader in the church must continue to believe the true message very well. That is the message which we have taught. Then he will be able to teach people what is true and right. He will also show that people who speak against the true message are wrong."
    },
    {
      "verse": "10",
      "text": "I say this because there are many people who refuse to obey their leaders. They speak about useless things and they deceive people. Many of them want the believers to obey all the Jewish rules."
    },
    {
      "verse": "11",
      "text": "You must stop those people from teaching false things like that. They are causing whole families to believe their lies. They teach things that they should not teach. They deceive people because they want people to give them money."
    },
    {
      "verse": "12",
      "text": "Many years ago, there was a certain man who lived on Crete. The people there called him their prophet. Even he said, ‘People who live on Crete are always telling lies and doing wicked things. They are lazy and they eat too much food. ’"
    },
    {
      "verse": "13",
      "text": "What that man said is true. So you must warn the people there. Help them to believe the true message about Jesus more and more."
    },
    {
      "verse": "14",
      "text": "They must not listen to Jewish stories that are not true, or to human rules. Those things are the ideas of people who refuse to obey God's true message."
    },
    {
      "verse": "15",
      "text": "If someone is clean and good inside, everything is clean and good for them to enjoy. But if someone is not a believer and has an unclean mind, nothing is clean or good for that person. Their minds no longer think properly. They no longer feel guilty when they do something wrong."
    },
    {
      "verse": "16",
      "text": "People like that say that they know God. But they do disgusting things. This shows that they do not know him. They are completely bad. They refuse to obey God. They are not able to do anything good."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "But as for you, Titus, you must teach people to do what is right. Teach them only the things that belong to God's true message."
    },
    {
      "verse": "2",
      "text": "Tell the older men to control themselves properly. They must think carefully about how they live, so that people respect them. They must continue to believe in Christ. They must continue to love other people. They must continue to be patient and strong."
    },
    {
      "verse": "3",
      "text": "Also, tell the older women to live in a good way. Their lives must show that they respect God. They must not say bad things about other people. They must not be drunks. They must teach what is good."
    },
    {
      "verse": "4",
      "text": "In this way, they can teach the young women how they should live. As a result, the young women will love their husbands and their children."
    },
    {
      "verse": "5",
      "text": "The young women will control themselves well and be pure in how they live. They will be good housewives who are kind to other people. They will respect their husbands. If they live in a good way like that, nobody will be able to say bad things about God's message."
    },
    {
      "verse": "6",
      "text": "As for the young men, tell them also to control themselves wisely in how they live."
    },
    {
      "verse": "7",
      "text": "You yourself must always do good things too. In that way, you will show the young men how they should live. When you teach the believers, be honest and serious."
    },
    {
      "verse": "8",
      "text": "Teach a message that is correct, so that nobody can say anything against it. Then our enemies will be ashamed, because they cannot say anything bad about us."
    },
    {
      "verse": "9",
      "text": "As for slaves, tell them to obey their masters always. They must not argue with their masters. Instead, they should work well to please their masters."
    },
    {
      "verse": "10",
      "text": "Slaves must not take things that belong to their masters. Their masters must be able to trust them completely. Then people will respect the message that we teach about God, our Saviour."
    },
    {
      "verse": "11",
      "text": "God has shown us clearly how very kind he is. He has come to save all people."
    },
    {
      "verse": "12",
      "text": "Because God is kind, he teaches us to stop living in a bad way. We no longer do the bad things that do not make God happy. We turn away from the bad things that belong to this world. God teaches us to control ourselves wisely while we live in this world. He teaches us to do what is right. He teaches us to please him in the way that we live."
    },
    {
      "verse": "13",
      "text": "Remember this: We are waiting for Jesus Christ to return to this world. When he comes, that will make us very happy. Everyone will see how great Jesus Christ is. He is our great God. He is the one who saves us from our sins."
    },
    {
      "verse": "14",
      "text": "He gave himself as a sacrifice on our behalf. He did that to make us free from every kind of bad thing. As a result, we can be completely good and clean inside ourselves. We can become his own special people, who want to do good things."
    },
    {
      "verse": "15",
      "text": "You must teach these things to the believers. Help them to live in a good way. Warn them when they do wrong things. Use all the authority that you have as a leader in the church. Make sure that everyone respects you properly."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "Tell the believers there to respect the government and those who have authority. They must remember to obey their rulers. They must always be ready to help other people."
    },
    {
      "verse": "2",
      "text": "They must not say bad things about anyone. They must not quarrel with people. Instead, they should be kind and polite to everyone."
    },
    {
      "verse": "3",
      "text": "Before we believed in Christ, we ourselves were fools too. We did not obey God. We believed a false message. We wanted to do many kinds of bad things to make us happy. We could not stop doing them. Every day we did evil things. We were jealous of other people. People hated us, and we hated each other."
    },
    {
      "verse": "4",
      "text": "But then God, our Saviour, showed clearly that he is very kind. He showed that he loves all people."
    },
    {
      "verse": "5",
      "text": "God did not save us because of any good things that we ourselves had done. He saved us because he chose to forgive us. God has washed us so that we are clean inside. We have been born again, so that we live a new life. God's Holy Spirit has done this for us."
    },
    {
      "verse": "6",
      "text": "Jesus Christ died as a sacrifice to save us. So now God has poured his Holy Spirit into us, to fill us."
    },
    {
      "verse": "7",
      "text": "Because God is very kind, he has accepted us as right with himself. As a result, we know that we will receive the good things that God has prepared for us. We know that we will live with God for ever."
    },
    {
      "verse": "8",
      "text": "That message is certainly true. So you must teach people the things that I have said in this letter. Make sure that they understand them well. Then the people who have believed in God will be careful to do good things. Good things like that will help everyone."
    },
    {
      "verse": "9",
      "text": "But stay away from people who argue about silly things. They study long lists of their families' names from years ago. Refuse to quarrel with people like that. Refuse to argue about the rules in God's Law. All those kinds of things have no value and they do not help anyone."
    },
    {
      "verse": "10",
      "text": "If someone teaches a false message that causes trouble, warn him. If you warn him twice and he still does not stop, stay away from him."
    },
    {
      "verse": "11",
      "text": "You know that a person like that has chosen not to believe the true message. He knows that he is doing a bad thing, but he continues to do it."
    },
    {
      "verse": "12",
      "text": "I will send either Artemas or Tychicus to you. After one of them has arrived, please come to meet me in Nicopolis. Come as quickly as you can. I have decided that I will stay in Nicopolis during the winter."
    },
    {
      "verse": "13",
      "text": "Please help Zenas, the lawyer, and Apollos as much as you can. Make sure that they have everything that they need for their journey."
    },
    {
      "verse": "14",
      "text": "Our Christian friends there must learn to do good things. They should supply things to people who need help. That will show that their lives are really useful."
    },
    {
      "verse": "15",
      "text": "Everyone who is here with me says ‘hello’ to you. Please say ‘hello’ on our behalf to the believers there who love us. I pray that God will continue to be very kind to all of you."
    }
  ]
};