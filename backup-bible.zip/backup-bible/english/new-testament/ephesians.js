module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter is from me, Paul. God chose me to be an apostle of Christ Jesus. I am writing to you, God's own people who live in Ephesus. You are those who continue to believe in Christ Jesus, and so you belong to him. I am writing to you, God's own people who live in Ephesus. You are those who continue to believe in Christ Jesus, and so you belong to him."
    },
    {
      "verse": "2",
      "text": "I pray that God, our Father, and the Lord Jesus Christ will continue to help you. I pray that they will give you peace in your minds."
    },
    {
      "verse": "3",
      "text": "We praise the God and Father of our Lord Jesus Christ. He has blessed us in very many ways. Because we belong to Christ, we enjoy all the good things that come from heaven. God blesses our spirits with those good things."
    },
    {
      "verse": "4",
      "text": "Before God made the world, he chose us to be his people because of Christ. He chose us so that we would please him. Because we belong to Christ, God accepts us as completely good. This shows how much he loves us."
    },
    {
      "verse": "5",
      "text": "Long ago, he already decided to accept us into his family as his children, because of Jesus Christ. He chose us to belong to him because it made him very happy."
    },
    {
      "verse": "6",
      "text": "As a result, we praise him, because he is great and he has been so kind to us. He has given us so much because of his Son, whom he loves very much."
    },
    {
      "verse": "7",
      "text": "When Christ died as a sacrifice on the cross, he paid the price to make us free. Because of Christ's death on our behalf, God has forgiven our sins. God is so very kind that he has done all this for us!"
    },
    {
      "verse": "8",
      "text": "Even more than that, God has shown how wise he is. He understands what we need."
    },
    {
      "verse": "9",
      "text": "He has let us know his great purpose, which had been a secret before. That plan would make him very happy. It would be possible because of Christ."
    },
    {
      "verse": "10",
      "text": "God will make that plan happen when the time is completely right. At that time, he will bring everything together so that Christ rules all of them. That includes the things that are in heaven, and the things that are on earth."
    },
    {
      "verse": "11",
      "text": "God is able to make all things happen just like he decides. He chose us to be his own people, because we are united with Christ. In the beginning, God had already decided that this was his purpose."
    },
    {
      "verse": "12",
      "text": "We were the first people to trust in Christ, God's special Messiah. God wanted us to show how great he is. He wanted people to praise him because of us."
    },
    {
      "verse": "13",
      "text": "You believers in Ephesus also heard God's true message. You heard the good news about how God saves you. When you believed in Christ, God gave his Holy Spirit to you. He had promised to do that, to show that you belong to him."
    },
    {
      "verse": "14",
      "text": "God has put his Holy Spirit inside us now. As a result, we know that one day we will receive all the good things that God has promised. At that time we will be completely free, because we belong to God. So we praise God and we say that he is great!"
    },
    {
      "verse": "15",
      "text": "People have told me that you continue to trust in the Lord Jesus. They have told me that you love all God's people. Because I have heard these good things about you,"
    },
    {
      "verse": "16",
      "text": "I am always thanking God because of you. Whenever I pray to God, I always ask him to help you."
    },
    {
      "verse": "17",
      "text": "God is very great! He is the Father of our Lord Jesus Christ. I pray that his Holy Spirit will make you wise. I pray that his Holy Spirit will help you to understand what God is like. Then you will know God better and better."
    },
    {
      "verse": "18",
      "text": "I pray that God will bring light into your minds. Then you will understand about the many good things that he has prepared for you. You know that you will receive those things because he has chosen you to be his people. God has prepared very valuable things for you in heaven."
    },
    {
      "verse": "19",
      "text": "You will also know how very powerful God is. He uses that power to help us now, as we trust in Christ. God's power is greater than anything we could ever know."
    },
    {
      "verse": "20",
      "text": "He used that power to raise Christ, so that he became alive again after his death. Then he gave Christ a place to sit at his right side in heaven."
    },
    {
      "verse": "21",
      "text": "There, Christ rules over every other ruler and leader. He rules over everything else that has authority. He is greater than any power which people respect. That is true for the rulers of this world now, and also the rulers of the world that will come."
    },
    {
      "verse": "22",
      "text": "God has put all things under Christ's authority. He has made Christ the ruler over all things. He has done this to help his people, the church."
    },
    {
      "verse": "23",
      "text": "The church is like Christ's body and he is its head. Christ fills all things everywhere and he causes the church to become complete."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Remember how you lived before. You did wrong things and bad things. As a result, you were dead in your spirits."
    },
    {
      "verse": "2",
      "text": "You lived in a bad way, like the people who belong to this world. You were obeying Satan, who rules the powerful spirits in the air. Those spirits are working now in everyone who refuses to obey God."
    },
    {
      "verse": "3",
      "text": "At one time, all of us lived like those people. We did whatever bad things our bodies wanted to do. If our thoughts made us want to do something, we did it. Because we were like that, God was angry with us. He should have punished us, just like everyone else."
    },
    {
      "verse": "4",
      "text": "But God is very good and kind! He loved us very much."
    },
    {
      "verse": "5",
      "text": "Because of our sins, we were dead in our spirits. But God gave us a new life, because we are united with Christ. Yes, God has saved you because he is so kind."
    },
    {
      "verse": "6",
      "text": "Also, God raised us up with Christ, so that we now sit with Christ in heaven. God has done this for us because we are united with Christ Jesus."
    },
    {
      "verse": "7",
      "text": "He wanted to show, for all future time, how very kind he is. He has helped us so much because of what Christ Jesus has done."
    },
    {
      "verse": "8",
      "text": "When you believed in Jesus, God saved you because he is very kind. You could not save yourselves, but that is God's gift to you."
    },
    {
      "verse": "9",
      "text": "He has not saved you as a result of any good things that you have done. So nobody has any reason to be proud about it."
    },
    {
      "verse": "10",
      "text": "It is God who has worked in us to make us what we are. He has given us a new life because we are united with Christ Jesus. He saved us so that now we can do good things in our lives. Those are good things that he has already prepared for us to do."
    },
    {
      "verse": "11",
      "text": "So you who were born as Gentiles should remember what you were like before. Jews insulted you because nobody has circumcised you. They themselves are proud that men have circumcised them as God's people."
    },
    {
      "verse": "12",
      "text": "At that time, you did not know about Christ, God's special Messiah. You did not belong to the nation of Israel's people. You did not know about the good things that God had promised to his people. You were living in this world with nothing good to hope for. You were living without God's help."
    },
    {
      "verse": "13",
      "text": "You were far away from God. But now, God has brought you near to himself, because you belong to Christ Jesus. That is possible because of Christ's death on the cross as a sacrifice."
    },
    {
      "verse": "14",
      "text": "It is Christ himself who has brought peace between Jews and Gentiles. He has brought those two groups together, to be one group. He has destroyed the things that made them separate. As a result, they are no longer enemies."
    },
    {
      "verse": "15",
      "text": "When his body died on the cross, Christ took away the power of the Jewish laws and rules. In that way, he made the two groups join together as one new group of people. As a result, he caused them to have peace."
    },
    {
      "verse": "16",
      "text": "As a single group, Christ brought Jews and Gentiles back to God. He stopped them from hating each other. He did this by his death on the cross."
    },
    {
      "verse": "17",
      "text": "When Christ came, he told people God's good news about peace. He told that message to you Gentiles, who were far away from God. He also told it to us Jews, who were near to God."
    },
    {
      "verse": "18",
      "text": "Now we all have received the same Holy Spirit, because of what Christ has done for us. As a result, we can all come near to God the Father."
    },
    {
      "verse": "19",
      "text": "So now, you Gentiles are not strangers among God's people any more. You belong to the group of God's people that he rules. You belong to God's family, as all God's people do."
    },
    {
      "verse": "20",
      "text": "You are like a house that God is building for himself. God's apostles and his prophets are like the foundation under the house. Jesus Christ is like the most important stone in the house."
    },
    {
      "verse": "21",
      "text": "He makes the whole building stand together strongly. In that way, all God's people together become like a special house that belongs to the Lord."
    },
    {
      "verse": "22",
      "text": "Because you belong to Christ, God is building you all together to become his house. That is where God lives by his Spirit."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "That is why I pray for you. I, Paul, am in prison because I serve Christ Jesus. He has sent me to help you Gentiles."
    },
    {
      "verse": "2",
      "text": "You must have heard that God has chosen me to do that. He has been very kind to give me this work to help you."
    },
    {
      "verse": "3",
      "text": "God has clearly shown to me his true purpose. That was a secret before, but God has helped me to know it. I have written a few words about this already."
    },
    {
      "verse": "4",
      "text": "When you read those words, you will be able to understand. I have come to know God's true message about Christ."
    },
    {
      "verse": "5",
      "text": "God did not tell this secret message to the people who lived before us. But now the Holy Spirit has shown it to God's apostles and prophets."
    },
    {
      "verse": "6",
      "text": "This is the message of God's good news: Gentiles, as well as Jews, may receive the good things that God has prepared for his children. We may all belong to the same group of God's people, like we are his body. Everyone who is united with Christ Jesus receives the good things that God has promised."
    },
    {
      "verse": "7",
      "text": "I tell that good news to other people, because God chose me to serve him in that way. That was God's gift to me, because he is so kind. God uses his great power to help me in that work."
    },
    {
      "verse": "8",
      "text": "I am the least important of all God's people. But God has given this special work to me because he is so kind. He has sent me to tell his good news to the Gentiles. Then they know about the many valuable things that Christ has prepared for us."
    },
    {
      "verse": "9",
      "text": "I help everyone to know how God makes his purpose happen. God himself created all things, and he has hidden this secret during past times."
    },
    {
      "verse": "10",
      "text": "But now God wants the people of his church to show everyone how wise he is in every way. He wants the spiritual rulers and everything that has authority in the heavens to know this."
    },
    {
      "verse": "11",
      "text": "This had always been God's purpose, from the beginning of all things. And it was our Lord Christ Jesus who made it happen."
    },
    {
      "verse": "12",
      "text": "Because we are united with Christ, we can come near to God. We are not afraid to do that. We can be sure that God will accept us, because we trust in Christ."
    },
    {
      "verse": "13",
      "text": "So do not become weak or afraid. I am now suffering so that I can help you. So you should be strong, so that God will bless you."
    },
    {
      "verse": "14",
      "text": "Yes, that is why I pray for you. I go down on my knees to pray to God, our Father."
    },
    {
      "verse": "15",
      "text": "Every family, those in heaven and those on earth, receives its true name from him."
    },
    {
      "verse": "16",
      "text": "I pray that God will cause you to be strong in your spirits. God has great and valuable things in heaven to help you. I pray that God's Spirit will help you with God's own power."
    },
    {
      "verse": "17",
      "text": "I pray that Christ will make his home in you, as you believe in him. Then you will know God's love very well. You will be like trees that have roots which go down deep into God's love. That will make you strong."
    },
    {
      "verse": "18",
      "text": "Then you will understand, with all God's people, how much Christ loves us. That love is very wide and long and high and deep!"
    },
    {
      "verse": "19",
      "text": "Christ's love for us is so great that nobody can ever completely know it. As you understand this more and more, God's own nature will completely fill you."
    },
    {
      "verse": "20",
      "text": "We praise God, who causes his power to work in us. In that way, he is able to do much more than we could ever ask for. He can do much more than we could even think about."
    },
    {
      "verse": "21",
      "text": "We want all God's people to know that God is great! Everyone who belongs to his church and who trusts in Christ Jesus should praise him! We should praise him always and for ever. Amen. That is true!"
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Because I serve the Lord, I am here in prison. I really want you to live as God's own people should live. God has called you to come to him. He has chosen you to be his own people."
    },
    {
      "verse": "2",
      "text": "Do not think that you are better than other people. Always be kind and patient with each other. Love one another, so that you do not quickly become angry with each other."
    },
    {
      "verse": "3",
      "text": "Do your best to let God's Spirit keep you united. You belong together so live in peace with each other."
    },
    {
      "verse": "4",
      "text": "As God's people, you are like one body. There is one Spirit that gives you life. God has chosen you to be his own people. So you all expect to receive the same great things from God."
    },
    {
      "verse": "5",
      "text": "There is one Lord. There is one true message that we must believe. There is one baptism."
    },
    {
      "verse": "6",
      "text": "There is one God, who is the Father of all of us. He has authority over all of us. He works through all of us. He is in all of us."
    },
    {
      "verse": "7",
      "text": "But God has been kind to all of us. Each of us has received a special gift, just as Christ has decided to give us. ‘When he went up to the highest place, he led many prisoners with him. Then he gave gifts to his people. ’"
    },
    {
      "verse": "8",
      "text": "This is what it says about him:‘When he went up to the highest place, he led many prisoners with him. Then he gave gifts to his people. ’"
    },
    {
      "verse": "9",
      "text": "It says: ‘He went up. ’ That must mean that Christ had also come down. He came down to a lower place, the earth."
    },
    {
      "verse": "10",
      "text": "So the man who came down is also the man who went up, high above all the heavens. He did that so that he would fill everything everywhere."
    },
    {
      "verse": "11",
      "text": "It was Christ who chose to give different gifts to his people. He chose some to be apostles. He chose some to speak messages from God. He chose some to tell God's good news to many people. He chose some to take care of his people, and to teach them."
    },
    {
      "verse": "12",
      "text": "He gave all these gifts to help God's people to serve him in different ways. As a result, the church, which is like Christ's body, would become strong."
    },
    {
      "verse": "13",
      "text": "In that way, all of us will become united, like one person. We will all believe in Jesus as the Son of God. We will all know him. We will become like a man who has grown up well. We will be completely as God wants us to be, just like Christ himself."
    },
    {
      "verse": "14",
      "text": "So then we will not be like children any more. Our minds will not become confused by strange ideas. We will not change what we believe, from one thing to another. Some people teach things that are not true. They do clever things to deceive people. But we will not agree with their false message."
    },
    {
      "verse": "15",
      "text": "Instead, we will love each other and we will speak God's true message. As a result, we will become more and more like Christ in every way. He is the head of his body, which is the church."
    },
    {
      "verse": "16",
      "text": "As its head, he helps the whole body to grow well. Each part joins with the other parts so that the whole body becomes strong. As each separate part does its proper work, we love each other more and more."
    },
    {
      "verse": "17",
      "text": "So I say this to you. I am sure that I have the Lord's authority to say it. You must not live any longer like the Gentile people who do not know God. They do whatever their silly ideas teach them to do."
    },
    {
      "verse": "18",
      "text": "They cannot understand God's true message because their minds are in the dark. They have not accepted the life that God gives. They have decided that they do not want to know about God. They do not even try to understand."
    },
    {
      "verse": "19",
      "text": "They do not feel ashamed when they do all kinds of disgusting things. They do more and more bad things just to please themselves."
    },
    {
      "verse": "20",
      "text": "But when you learned about Christ, you did not learn to do things like that!"
    },
    {
      "verse": "21",
      "text": "I am sure that you have heard about him properly. People taught you the true message that comes from Jesus."
    },
    {
      "verse": "22",
      "text": "They taught you to change the way that you live. You must put away the nature that you had before. That old nature deceived you. As a result, you wanted to do things that would destroy you."
    },
    {
      "verse": "23",
      "text": "Instead, let God's Spirit make you think in a new way."
    },
    {
      "verse": "24",
      "text": "Take up the new nature that God has prepared for you. That nature is like God's own nature. Then you will live in a truly good way that pleases God."
    },
    {
      "verse": "25",
      "text": "So you must stop telling lies. Each of you must say only true things to one another. Remember that all of us belong to one another, like parts of the same body."
    },
    {
      "verse": "26",
      "text": "When you are angry, do not do anything bad as a result. Once the day comes to an end, do not continue to be angry."
    },
    {
      "verse": "27",
      "text": "Do not give the Devil a chance to hurt you like that."
    },
    {
      "verse": "28",
      "text": "Any of you who robbed people before must now stop taking things. Instead, you should work hard with your own hands. Then you will be able to share what you have with people who are poor."
    },
    {
      "verse": "29",
      "text": "Do not say bad things that hurt or insult people. Instead, say only good things that will help people. Your words should help people to become strong when they hear them."
    },
    {
      "verse": "30",
      "text": "Do not do anything that will make God's Holy Spirit sad. God gave his Holy Spirit to you to show that you belong to him. As a result you know that God will make you completely free one day."
    },
    {
      "verse": "31",
      "text": "Do not be jealous of other people. Do not become angry or shout at them. Do not quarrel with other people or insult them. Do not do anything or say anything that will hurt other people."
    },
    {
      "verse": "32",
      "text": "Instead, help one another and be kind to each other. Forgive one another. Remember that God has forgiven you because of what Christ has done."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "You are God's children and he loves you very much. So you must try to be like him."
    },
    {
      "verse": "2",
      "text": "Show that you love other people. Remember how much Christ loved us. He gave himself as a sacrifice on our behalf. He offered himself in a way that pleased God, like a sacrifice with a lovely smell."
    },
    {
      "verse": "3",
      "text": "So, as God's people, you must never have sex with anyone that you are not married to. Do not do any kind of disgusting thing like that. Do not want many things for yourselves, just to make you happy. That is not how God's people should live."
    },
    {
      "verse": "4",
      "text": "Do not speak in a way which uses dirty words. Do not talk about silly things, like fools do. It is not right for God's people to talk like that. Instead, you should speak in a way which shows that you are thanking God."
    },
    {
      "verse": "5",
      "text": "You can be sure about this: If anyone has sex in a wrong way, that person does not belong to God's people. Nobody who does any kind of disgusting thing belongs to God's people. People who want many things just to please themselves are like people who worship an idol. They also do not belong to God's people. Nobody like that belongs to the kingdom where Christ and God rule. They will not receive the good things that God has prepared for his people."
    },
    {
      "verse": "6",
      "text": "Do not let anyone have a chance to deceive you with a false message about those kinds of bad things. God will certainly punish people who do not obey him. ‘Wake up, you people who are asleep! Rise up from among the dead people! Then Christ will shine his light on you. ’"
    },
    {
      "verse": "7",
      "text": "So keep away from those kinds of people."
    },
    {
      "verse": "8",
      "text": "Once your minds were completely in the dark. But now you belong to the Lord. As a result, you have become full of light. So now you must live as people who belong to the light."
    },
    {
      "verse": "9",
      "text": "The light helps you to live in a way that is good, right and true."
    },
    {
      "verse": "10",
      "text": "You should learn more and more to do the things that please the Lord."
    },
    {
      "verse": "11",
      "text": "People whose minds are in the dark do things that have no good purpose. Keep away from wrong things like that. Instead, show how bad those things really are."
    },
    {
      "verse": "12",
      "text": "People like that should be ashamed of the things that they do secretly. Those things are too bad for us even to talk about."
    },
    {
      "verse": "13",
      "text": "But when God's light shines on something, people can see clearly its true nature."
    },
    {
      "verse": "14",
      "text": "Everything that becomes clear to see is in the light. That is why it says:‘Wake up, you people who are asleep! Rise up from among the dead people! Then Christ will shine his light on you. ’"
    },
    {
      "verse": "15",
      "text": "So you must be very careful how you live. Live like people who are wise. Do not live like fools."
    },
    {
      "verse": "16",
      "text": "Many bad things are happening in these days. So, whenever you have a chance to do something good, do as much as you can."
    },
    {
      "verse": "17",
      "text": "Do not live like fools. But instead, understand what the Lord wants you to do."
    },
    {
      "verse": "18",
      "text": "Do not drink too much wine so that you become drunk. That will destroy your life. Instead, let God's Spirit fill you."
    },
    {
      "verse": "19",
      "text": "He will help you to speak to each other with all kinds of spiritual songs. Sing psalms from the Bible, and Christian songs. Praise the Lord with songs from inside yourselves."
    },
    {
      "verse": "20",
      "text": "And always thank God, the Father, for everything, by our Lord Jesus Christ's name."
    },
    {
      "verse": "21",
      "text": "Serve one another to show that you respect Christ as your master."
    },
    {
      "verse": "22",
      "text": "Wives, obey your own husbands, as you obey the Lord."
    },
    {
      "verse": "23",
      "text": "A husband has authority over his wife, in the same way that Christ has authority over the church. The church is like Christ's body. As its head, he saves her."
    },
    {
      "verse": "24",
      "text": "As the church serves Christ as its master, so wives should serve their husbands in everything."
    },
    {
      "verse": "25",
      "text": "Husbands, love your wives, as Christ loved the church. He even agreed to die on its behalf."
    },
    {
      "verse": "26",
      "text": "He did that to make us completely clean, as the people of God. It was like he washed us with water, as he brought God's message to us."
    },
    {
      "verse": "27",
      "text": "Christ himself did this to bring us to himself as a beautiful group of his people. His church would belong to him completely. It would be pure, without anything bad to spoil it."
    },
    {
      "verse": "28",
      "text": "So husbands should love their wives, just as they love their own bodies. A man who loves his wife shows that he loves himself."
    },
    {
      "verse": "29",
      "text": "There is nobody who hates his own body. Everyone feeds his body and he takes care of it. In the same way, the church is like Christ's body that he takes care of."
    },
    {
      "verse": "30",
      "text": "We are like the parts of Christ's body."
    },
    {
      "verse": "31",
      "text": "The Bible says this: ‘When a man marries, he leaves his father and his mother. Instead, God joins the man and his wife together. The two people become like one body. ’"
    },
    {
      "verse": "32",
      "text": "This is God's secret and it is difficult to understand. But I am saying that it teaches us about Christ and the church."
    },
    {
      "verse": "33",
      "text": "But each one of you husbands should understand this: love your own wife as you love yourself. And every wife among you must respect her husband."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "You who are children, obey your parents. Because you belong to the Lord, that is the right thing to do."
    },
    {
      "verse": "2",
      "text": "God's Law says: ‘Always respect your father and your mother. ’ That is the first rule of God's Law that also has a promise."
    },
    {
      "verse": "3",
      "text": "The promise is this: ‘As a result, you will be happy and you will live for a long time on the earth. ’"
    },
    {
      "verse": "4",
      "text": "Fathers, do not do things that make your children angry. Instead, teach them carefully as they grow up. Help them to understand the message of the Lord, and help them to obey it."
    },
    {
      "verse": "5",
      "text": "You who are slaves, obey your human masters. Respect them and be afraid of them. Work well to help them, as if you were working for Christ as your master."
    },
    {
      "verse": "6",
      "text": "Do not do good work only when they can see you. Some people only work to make other people like them. Instead, work well all the time, as slaves who serve Christ. Work in the way that God wants you to work."
    },
    {
      "verse": "7",
      "text": "Be happy to obey your human masters. Remember that you are serving the Lord himself, not just other people."
    },
    {
      "verse": "8",
      "text": "You know that anyone who does some good thing will receive a good gift from the Lord. This will happen whether that person is a slave or a free person."
    },
    {
      "verse": "9",
      "text": "You who are masters, be good to your slaves in the same way. Do not frighten them with punishment. Remember that both you and your slaves have the same Master in heaven. And he is always fair when he judges people, whoever they are."
    },
    {
      "verse": "10",
      "text": "At the end of my letter, I want to say this to you: Be united with the Lord, so that you are strong. Then his great power will help you."
    },
    {
      "verse": "11",
      "text": "Use all the help that God gives to us. Then you can be like a soldier who fights against the Devil. You must put on the whole armour that God gives to us. The Devil attacks us in clever ways, and we need to be strong."
    },
    {
      "verse": "12",
      "text": "We are not fighting against human enemies. Instead, we are fighting against the rulers and the powerful spirits that have authority over this dark world. We are fighting against the bad spirits who live in the heavens."
    },
    {
      "verse": "13",
      "text": "Because of that, take all the help that God gives, like it is your armour. Then, when the bad time comes, you will be able to stand strongly. You will not fall. After you have finished everything, you will still be standing strongly in your place."
    },
    {
      "verse": "14",
      "text": "So you must stand strongly. This is God's armour that you must wear: God's true message will be like a belt that you tie round your body. Always do what is right. That will be like a metal shirt that you wear to keep your body safe."
    },
    {
      "verse": "15",
      "text": "Be prepared to tell people the good news about peace with God. That will be like shoes on your feet."
    },
    {
      "verse": "16",
      "text": "As well as all that, have faith to trust God. That will be like a shield that you hold in front of you. It will stop the Devil from hurting you with his arrows that burn with fire."
    },
    {
      "verse": "17",
      "text": "Remember that God has saved you from your sins. That will be like a strong hat that keeps your head safe. Also, use God's message to help you. That will be like a sword that God's Spirit puts in your hand."
    },
    {
      "verse": "18",
      "text": "As you stand strongly like that, always pray for God's help. Pray about everything as God's Spirit helps you to pray. For this purpose, watch carefully all the time. Also, continue to pray for all God's people everywhere."
    },
    {
      "verse": "19",
      "text": "Please pray for me, too. Pray that God will give me the right message to speak. Pray that I will not be afraid to tell people about God's good news. Pray that I can explain God's secret to them."
    },
    {
      "verse": "20",
      "text": "God has sent me to tell people the good news on his behalf. And that is why I am now in prison. So pray that I will speak God's message bravely, as I ought to speak it."
    },
    {
      "verse": "21",
      "text": "My Christian friend, Tychicus, will tell you all the news about me. He works hard as the Lord's servant. He will tell you about what is happening here. Then you will know what I am doing and how I am."
    },
    {
      "verse": "22",
      "text": "That is the reason why I am sending him to you. I want him to tell you what is happening to us here, so that you will feel stronger."
    },
    {
      "verse": "23",
      "text": "I pray that God, the Father, and our Lord Jesus Christ will be good to you who are believers. I pray that you will have peace in your minds. I pray that you will love one another, as you continue to trust Christ."
    },
    {
      "verse": "24",
      "text": "I pray that God will be very kind to everyone who continues to love our Lord Jesus Christ."
    }
  ]
};