module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter is from me, Paul. I am an apostle of Jesus Christ. It is not any group of people or any one person that has given that authority to me. It is Jesus Christ himself who has chosen me to serve him. And God our Father, who raised Jesus to become alive again after his death, has also sent me. I am writing to you, the people of the churches that are in Galatia."
    },
    {
      "verse": "2",
      "text": "All the believers who are here say ‘hello’ to you. We all send this letter to you. I am writing to you, the people of the churches that are in Galatia."
    },
    {
      "verse": "3",
      "text": "I pray that God, our Father, and the Lord Jesus Christ will continue to help you. I pray that they will give you peace in your minds."
    },
    {
      "verse": "4",
      "text": "Jesus offered himself as a sacrifice because of all the wrong things that we have done. He did that to save us from all the bad things of this world in which we live now. This is what God, our Father, wanted him to do."
    },
    {
      "verse": "5",
      "text": "God is great and we should praise him for ever. Amen. This is true."
    },
    {
      "verse": "6",
      "text": "I am very surprised that you are turning away so soon from God. He is the one who chose you to come to him. He did that because Christ is very kind to you. But now you want to accept a different message which some people call good news."
    },
    {
      "verse": "7",
      "text": "But really, there is no other message from God which is good news. Some people are confusing you. They are trying to change the good news about Christ and make it something different."
    },
    {
      "verse": "8",
      "text": "Nobody should ever teach a message that is different from the good news that we taught you. Neither we ourselves, nor even an angel from heaven, should ever teach a different message. If anyone does that, I pray that God would curse him."
    },
    {
      "verse": "9",
      "text": "We have already said this, but now I will say it again. Do not accept any message that is different from the message that we taught you. If anyone teaches a different message, I pray that God will curse him very strongly."
    },
    {
      "verse": "10",
      "text": "When I say these things, I am not trying to please people. No, it is God that I want to please. If I only wanted to make people happy, then I would not be a servant of Christ."
    },
    {
      "verse": "11",
      "text": "The good news that I tell people did not come from any person on earth. I want you to know that, my friends."
    },
    {
      "verse": "12",
      "text": "Nobody on earth gave it to me. Nobody taught it to me. No, it was Jesus Christ himself who showed it to me clearly."
    },
    {
      "verse": "13",
      "text": "You know about the things that I did before, when I obeyed the Jewish rules. I caused very much trouble against God's church. I tried to destroy those people completely."
    },
    {
      "verse": "14",
      "text": "I obeyed the Jewish rules better than many other Jews who were my friends. I tried very much to obey the ideas that our Jewish ancestors taught."
    },
    {
      "verse": "15",
      "text": "But God had chosen me to serve him even before I was born. He chose me to be his servant because he is very kind."
    },
    {
      "verse": "16",
      "text": "He decided to show his Son clearly to me, so that I could tell the Gentiles about him. When God chose me to do that, I did not talk about it with any person."
    },
    {
      "verse": "17",
      "text": "Nor did I go to Jerusalem to see Christ's apostles there. Those men were already his apostles before I was. But I did not go to talk to them. Instead, I went immediately to the region of Arabia. Later, I went back to the city of Damascus."
    },
    {
      "verse": "18",
      "text": "Then, three years later, I did go to Jerusalem. I stayed there with Christ's apostle Peter for 15 days, so that he could teach me."
    },
    {
      "verse": "19",
      "text": "I did not see any other apostles, except James, who is the Lord's brother."
    },
    {
      "verse": "20",
      "text": "God knows that what I am writing to you is completely true!"
    },
    {
      "verse": "21",
      "text": "Later, I went to different places in Syria and Cilicia."
    },
    {
      "verse": "22",
      "text": "The Christians in the churches in Judea had never met me."
    },
    {
      "verse": "23",
      "text": "They had only heard people say this about me: ‘This man caused bad trouble against us Christians before. He tried to destroy God's message about Jesus. But now he himself is telling people the good news about Jesus, so that they believe. ’"
    },
    {
      "verse": "24",
      "text": "When the believers in Judea heard that, they praised God because of me."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "years later, I went to Jerusalem again. This time I went with Barnabas, and I also took Titus with me."
    },
    {
      "verse": "2",
      "text": "I went there because God had shown me that I should go. I talked to the Christian leaders there. I explained to them the good news that I teach to the Gentiles. But I talked only to those men who seemed to be the leaders. I wanted to be sure that they agreed with the message that I taught. I did not want my work, both in past times and now, to be worth nothing."
    },
    {
      "verse": "3",
      "text": "Titus was with me then. He is a Greek person and nobody had circumcised him. But the leaders in Jerusalem did not say that we must circumcise him."
    },
    {
      "verse": "4",
      "text": "But some men did want us to obey all the Jewish rules. Those men came secretly among our group. They said that they were believers, but they were not really true believers. They wanted to see how we lived as believers. They wanted to know how Christ Jesus has made us free from the Jewish rules. They wanted to make us slaves to those rules."
    },
    {
      "verse": "5",
      "text": "But we did not allow them to do this to us. They wanted to spoil the true good news that you have believed. We kept the good news safe for you."
    },
    {
      "verse": "6",
      "text": "The church leaders in Jerusalem did not argue with me. (They were the people who seemed to be the leaders. It does not matter to me whether they were really important people or not. God does not respect some people more than others. ) Those leaders did not tell me to change the message that I teach."
    },
    {
      "verse": "7",
      "text": "Instead they saw that God had given a special job to me. God wanted me to tell the good news about Christ to the Gentiles. In the same way, he had told Peter to tell the good news to the Jews."
    },
    {
      "verse": "8",
      "text": "God gave Peter the authority to be his apostle to the Jews. God also gave me the authority to be his apostle to the Gentiles."
    },
    {
      "verse": "9",
      "text": "James, Peter and John understood that God had given this special job to me. They are the leaders that the church in Jerusalem respects. And they were happy to accept Barnabas and me as their friends. They agreed that we should teach God's message to the Gentiles. They themselves would continue to teach the Jews."
    },
    {
      "verse": "10",
      "text": "They only asked us to do this: We should remember to help the poor people among their group. That is something that I myself wanted very much to do."
    },
    {
      "verse": "11",
      "text": "But later, when Peter came to Antioch, I spoke against him. I told him clearly that he had done something wrong."
    },
    {
      "verse": "12",
      "text": "When he first arrived in Antioch, Peter had been eating meals with the Gentile believers there. Then James sent some Jewish believers from Jerusalem to Antioch. After those men had arrived, Peter started to keep himself separate from the Gentiles. He stopped eating meals with them. He was afraid of those Jews who wanted to circumcise the Gentile believers."
    },
    {
      "verse": "13",
      "text": "The other Jewish believers in Antioch also did what Peter did. They became hypocrites like him. Even Barnabas agreed and he copied their example."
    },
    {
      "verse": "14",
      "text": "But I could see that they were wrong to do this. They were not living in a way that agrees with God's true message. So I spoke to Peter in front of all of them. I said to him, ‘You were born as a Jew, but you have been living like a Gentile. As a believer, you no longer obey all the Jewish rules. So you should not try to make Gentile believers obey those Jewish rules. ’"
    },
    {
      "verse": "15",
      "text": "We were born as Jewish people. We are not Gentiles who have never obeyed God's rules."
    },
    {
      "verse": "16",
      "text": "But we know that we do not become right with God because we obey his Law. A person only becomes right with God when they believe in Jesus Christ. And we, as Jewish believers, have believed in Christ Jesus. We have become right with God because we trust in what Christ has done. It is not because we obey God's Law that he accepts us. Nobody becomes right with God only because they obey the rules in God's Law."
    },
    {
      "verse": "17",
      "text": "So then, we Jews become right with God when we believe in Christ. That means that we no longer obey all the Jewish rules. But that does not mean that Christ causes us to do wrong things. Certainly, it does not mean that!"
    },
    {
      "verse": "18",
      "text": "Instead, I would really be doing something wrong if I tried to obey all those rules again. I would be building again something that I had destroyed. That would really be against God's Law."
    },
    {
      "verse": "19",
      "text": "But God's Law showed me that I could never obey all its rules. So I became like a dead person, free from the authority of those rules. That means that I can now live to please God."
    },
    {
      "verse": "20",
      "text": "Christ died on the cross on my behalf. It is like I died there with him. So I do not live my own life any more. Instead, Christ lives in me. The life that I live now in my body, I live because I trust what he has done for me. He has loved me so much that he died on my behalf."
    },
    {
      "verse": "21",
      "text": "So I do not refuse to accept the kind gift of God. If the rules of God's Law could make me right with him, then Christ would have died for no reason!"
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "You Christians in Galatia are like fools! Someone has taught you to believe crazy ideas! I taught you clearly that Jesus Christ died on the cross as a sacrifice on our behalf. You understood that."
    },
    {
      "verse": "2",
      "text": "So think about this: When you received God's Spirit, was it because you had obeyed the rules of God's Law? No! You received God's Spirit because you heard the message about Christ and you believed it."
    },
    {
      "verse": "3",
      "text": "Do not think like fools! You first became believers by the help of God's Spirit. So do not try now to continue by your own human power. That will never get you to the end!"
    },
    {
      "verse": "4",
      "text": "You have had many troubles as believers. I want those troubles to help you. Surely they could not be without any good purpose."
    },
    {
      "verse": "5",
      "text": "God gives to you the gift of his Spirit. He also does powerful miracles among you. But he does not do these things because you obey the rules of his Law. No, he does them because you believed the message about Christ which you heard."
    },
    {
      "verse": "6",
      "text": "Think about our Jewish ancestor Abraham. We know this: ‘Abraham believed God. As a result, God accepted Abraham as right with him’."
    },
    {
      "verse": "7",
      "text": "So you should understand who Abraham's children really are. It is those people who trust God."
    },
    {
      "verse": "8",
      "text": "The Bible already said what would happen at a future time. It said that God would make the Gentiles right with himself, if they believed in him. God showed this good news to Abraham a long time before it happened. He said to Abraham, ‘I will bless people from all countries because of you. ’"
    },
    {
      "verse": "9",
      "text": "So then, God did not bless only Abraham when he trusted God. God also blesses all people who trust him like Abraham did."
    },
    {
      "verse": "10",
      "text": "But some people try to obey all the rules of God's Law. They think that they will become right with God if they do this very well. But God will speak against people like that and he will punish them. It is written in the Bible: ‘God will punish everyone who does not always obey all the rules in his Law completely. ’"
    },
    {
      "verse": "11",
      "text": "We know that the Law can not cause anyone to become right with God. That is clear because the Bible says, ‘The person that God has accepted as right will live because they trust him. ’"
    },
    {
      "verse": "12",
      "text": "But the Law does not tell people to trust God. It tells people about all the things that they must do. The Bible says, ‘The person who obeys all the rules in God's Law completely will live’."
    },
    {
      "verse": "13",
      "text": "So God's Law shows that it is right for God to punish us. But Christ took that punishment away from us, because God punished him instead of us. It says in the Bible: ‘When people hang someone on a tree to kill him, it shows that God has cursed that person. ’"
    },
    {
      "verse": "14",
      "text": "Christ died in that way so that God would bless the Gentiles in the way that he blessed Abraham. Also, if we believe in Christ, we can then receive God's Spirit that he promised."
    },
    {
      "verse": "15",
      "text": "My Christian friends, I will use an example from our lives. Two people may make an agreement together and they both agree to it properly. If they do that, nobody else can change that agreement. They cannot take away its authority."
    },
    {
      "verse": "16",
      "text": "In the same way, God promised to bless Abraham and Abraham's descendant. The Bible does not say ‘descendants’. It does not speak about ‘many people’. No, God promised to bless Abraham's descendant. He speaks about one person, and that person is Christ."
    },
    {
      "verse": "17",
      "text": "What I mean is this: God made an agreement with Abraham. He promised to bless him. Then, 430 years later, God gave his Law to Moses for the Jewish people. But that Law could not take away the authority of God's agreement with Abraham. It could not stop what God had already promised."
    },
    {
      "verse": "18",
      "text": "God has promised to give good things to his children. But that does not happen as a result of God's Law. If that were true, then we would not receive God's good things as a result of his promise. But God gave those good things to Abraham as a gift, because he had promised to bless Abraham."
    },
    {
      "verse": "19",
      "text": "So we could ask: Why did God give his Law to his people after his promise to Abraham? He gave his Law to show them which things are wrong. It would have authority until Abraham's special descendant would come. That was the descendant that God had promised to bless. God used angels to give his Law to his people. It was Moses who received the Law from God, and Moses then took it to God's people."
    },
    {
      "verse": "20",
      "text": "But God himself gave his promise to Abraham. It was not necessary to have somebody in between, like Moses."
    },
    {
      "verse": "21",
      "text": "So should we say that God's Law works against God's promises? No, certainly that is not true! It is not possible for the rules of any law to give us life with God. If that could happen, then God would have accepted us as right if we obeyed those rules."
    },
    {
      "verse": "22",
      "text": "But the Bible says that sin has power over everyone. People can not get free. This means that we can only receive what God has promised when we trust Jesus Christ. God gives his promise to those who believe."
    },
    {
      "verse": "23",
      "text": "But before God showed us the way of faith, the Law had authority over us. God's Law kept us safe, until God showed us that we must believe in Christ."
    },
    {
      "verse": "24",
      "text": "In that way, God's Law was like our guide. It kept us safe until Christ came. Then God could accept us as right because we trusted Christ."
    },
    {
      "verse": "25",
      "text": "But now that the way of faith in Christ has come, we do not need God's Law to keep us safe any longer."
    },
    {
      "verse": "26",
      "text": "All of you are God's children because you believe in Christ Jesus."
    },
    {
      "verse": "27",
      "text": "They baptized you as believers in Christ. That means that you have put on Christ, like someone who puts on new clothes."
    },
    {
      "verse": "28",
      "text": "It does not matter whether you are a Jew or a Gentile. It does not matter whether you are a slave or a free person. It does not matter whether you are a man or a woman. You all belong together because you all belong to Christ Jesus."
    },
    {
      "verse": "29",
      "text": "And if you belong to Christ, then you are descendants of Abraham. Because of that, you will receive all the good things that God promised to Abraham."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "I will say it like this. Think about a son who will one day receive what belongs to his father. While he is still a child, he is like a slave in the family. That is true, even though all his father's things really belong to him."
    },
    {
      "verse": "2",
      "text": "He has to wait until the time that his father has decided. Until then, the son has to obey his teachers and the guides who take care of him."
    },
    {
      "verse": "3",
      "text": "In the same way, we were children like that in God's family. We were slaves to the bad spirits that rule this world."
    },
    {
      "verse": "4",
      "text": "But when the time that God had decided arrived, he sent his Son into the world. A human mother gave birth to him. He was born a Jew, under the authority of God's Law."
    },
    {
      "verse": "5",
      "text": "In that way, he made us free from the authority of the Law. Before that, we were like slaves under the Law. But God's Son paid our debt, so that God would accept us as his true children."
    },
    {
      "verse": "6",
      "text": "Because we are his children, God has sent his Son's Spirit to live inside us. His Spirit causes us to call God, ‘Father, my Father’."
    },
    {
      "verse": "7",
      "text": "So you are not slaves any more, but you are God's children. And because of that, you will receive all the good things that God has promised."
    },
    {
      "verse": "8",
      "text": "Before, when you did not know God, you served false gods. They were not gods at all, but you were their slaves."
    },
    {
      "verse": "9",
      "text": "But now you do know God. Or really, I should say that God knows you. So you must not turn back to serve those weak spirits that rule this world. Why do you want to obey their useless rules and become their slaves again?"
    },
    {
      "verse": "10",
      "text": "You say that certain days, or months, or seasons, or years are special. That is how you want to please God."
    },
    {
      "verse": "11",
      "text": "I am afraid about you. I worked very much to help you. I do not want my work to have no results."
    },
    {
      "verse": "12",
      "text": "My Christian friends, please become like me! I ask you to do this, because when I was with you, I became like you. You did not then do anything wrong to me."
    },
    {
      "verse": "13",
      "text": "You must remember that I first came to you because I was ill. That was when I first told God's good news to you."
    },
    {
      "verse": "14",
      "text": "I caused trouble for you because I was ill. But you did not insult me. You did not tell me to go away. But you were kind to me. You took care of me as if I were an angel from God, or even Christ Jesus himself."
    },
    {
      "verse": "15",
      "text": "But now you do not seem to be happy with me any more. I can say that you would have pulled out your own eyes to help me. You would have given them to me, if that had been possible."
    },
    {
      "verse": "16",
      "text": "But now I seem to have become your enemy! Is that because I am telling you God's true message?"
    },
    {
      "verse": "17",
      "text": "Those false teachers try very much to please you. But they do not really want what is good for you. They want to make you turn away from me. Then you will only want to listen to them."
    },
    {
      "verse": "18",
      "text": "It is good for someone to try to please other people if they really want to help them. That is true all the time, not only when I am there with you."
    },
    {
      "verse": "19",
      "text": "My children, I feel like a mother who is giving birth to you again. I will continue to feel that kind of pain until you become more completely like Christ."
    },
    {
      "verse": "20",
      "text": "I want very much to be there with you now. Then I would know better how to speak to you. As it is, I do not know what to think about you."
    },
    {
      "verse": "21",
      "text": "I say this to you people who want God's Law to have authority over you. Think carefully about what that Law really says."
    },
    {
      "verse": "22",
      "text": "The Bible says that Abraham had two sons. The mother of one of them was a slave. The mother of the other son was a free woman."
    },
    {
      "verse": "23",
      "text": "Hagar was a slave. Her son was born as a result of what Abraham himself decided. But Abraham's wife, Sarah, gave birth to the other son. That son was born as a result of what God had promised to Abraham."
    },
    {
      "verse": "24",
      "text": "These two women are like pictures of two agreements that God made with his people. Hagar is like the agreement that God made on Sinai mountain. That agreement causes people to become slaves."
    },
    {
      "verse": "25",
      "text": "Hagar is like a picture of Sinai mountain in Arabia. Also, she is like the city of Jerusalem here on earth now, because that city and its people are slaves under the authority of God's Law."
    },
    {
      "verse": "26",
      "text": "But Abraham's wife, Sarah, is a picture of the new Jerusalem that is above. Sarah was a free person, not a slave, and she is like our mother. ‘Be happy, you woman who could not have any children! You have never known the pain of a child's birth. But now shout loudly because you are so happy! Yes, be happy, because the lonely woman now has more children than the woman who has a husband. ’"
    },
    {
      "verse": "27",
      "text": "It says in the Bible:‘Be happy, you woman who could not have any children! You have never known the pain of a child's birth. But now shout loudly because you are so happy! Yes, be happy, because the lonely woman now has more childrenthan the woman who has a husband. ’"
    },
    {
      "verse": "28",
      "text": "You, my Christian friends, are like Sarah's son, Isaac. Like him, you became God's children as a result of God's promise."
    },
    {
      "verse": "29",
      "text": "Isaac was born because of God's Spirit. The son who was born in the human way gave much trouble to Isaac at that time. You who are believers receive the same kind of trouble now."
    },
    {
      "verse": "30",
      "text": "But this is what it says in the Bible: ‘Send away the woman who is a slave and her son. That woman's son will never receive anything from his father. The son of the free woman will receive all those good things. ’"
    },
    {
      "verse": "31",
      "text": "So then, my Christian friends, we are not children of the woman who is a slave. No, we are children of the free woman."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Christ has made us free so that we can be really free! So be strong and do not turn back. Do not let yourselves become slaves to the Jewish rules again."
    },
    {
      "verse": "2",
      "text": "Listen carefully! I, Paul, tell you this. If you agree that someone should circumcise you, then Christ will be worth nothing to you."
    },
    {
      "verse": "3",
      "text": "I will say it very clearly. Every man who lets someone circumcise him must then obey all the Jewish rules."
    },
    {
      "verse": "4",
      "text": "I say this to you people who try to obey the rules of God's Law. If you think that God will accept you as right because you do that, you have turned away from Christ. You no longer agree to accept God's kind gift."
    },
    {
      "verse": "5",
      "text": "But if we trust what Christ has done for us, God's Spirit helps us to wait. We are sure that God will accept us as right with him."
    },
    {
      "verse": "6",
      "text": "We belong to Christ Jesus. So it does not matter whether anyone has circumcised us or not. The only thing that matters is that we believe in Christ. As a result we will love others in the way that we live."
    },
    {
      "verse": "7",
      "text": "Like good runners, you were doing very well! You should not have let anyone turn you away from God's true message."
    },
    {
      "verse": "8",
      "text": "It is not God who has caused you to change what you believe. No! God is the one who has chosen you to serve him."
    },
    {
      "verse": "9",
      "text": "People say this: ‘Only a small amount of yeast in the flour will cause a loaf of bread to grow big. ’"
    },
    {
      "verse": "10",
      "text": "But I feel sure about you, because we belong to the Lord. I know that you will agree with what I say about this. But as for the man who is confusing you, God will punish him. It does not matter who he is, God will punish him."
    },
    {
      "verse": "11",
      "text": "My Christian friends, do you think that I still teach that someone must circumcise believers? If I really taught that, then I would not still receive trouble from people. What I teach about Christ's death on the cross would not cause anyone to become angry."
    },
    {
      "verse": "12",
      "text": "Those people who are causing trouble and want to circumcise you should cut their own bodies! Yes, that is what they should do!"
    },
    {
      "verse": "13",
      "text": "My Christian friends, God has chosen you to serve him as free people. But you are still weak and human. So you are not free to do anything that you might want to do. Instead, you must serve one another, because you love each other."
    },
    {
      "verse": "14",
      "text": "One rule brings together all the rules in God's Law. That one rule says: ‘Love other people as much as you love yourself. ’"
    },
    {
      "verse": "15",
      "text": "So you must not live like wild animals. Wild animals fight and they eat each other. If you live like that, be very careful! You may destroy one another completely."
    },
    {
      "verse": "16",
      "text": "So this is what I say: Let God's Spirit show you how to live in a good way. Then you will not do the wrong things that you may want to do, as people who are weak and human."
    },
    {
      "verse": "17",
      "text": "The things that you want to do as a weak person are opposite to the things that God's Spirit wants. The things that God's Spirit wants are the opposite of what we want as weak people. Our own thoughts fight against what God's Spirit wants us to do. As a result, you are not free to do the things that you really want to do."
    },
    {
      "verse": "18",
      "text": "But if God's Spirit leads you, then the rules of God's Law have no authority over you."
    },
    {
      "verse": "19",
      "text": "Everyone knows the kinds of bad things that weak people want to do. They have sex with people that they are not married to. They do things that are bad and disgusting."
    },
    {
      "verse": "20",
      "text": "They worship idols. They do magic to hurt people. They become enemies and they fight one another. They are jealous of other people. They become very angry. They want to please themselves and to be important. They cause trouble. They make people belong to different groups."
    },
    {
      "verse": "21",
      "text": "They want things that belong to other people. They are drunks. They have wild parties. And they like to do many other bad things like those. So I warn you again, as I have already warned you before. People who continue to do any of those bad things will not receive good things from God. God has prepared those good things for the people who belong to his kingdom."
    },
    {
      "verse": "22",
      "text": "But God's Spirit causes us to live in a different way. We love other people. We are happy and we have peace in our minds. We are patient, kind and good. People can trust us to do what is right."
    },
    {
      "verse": "23",
      "text": "We respect other people and we rule ourselves properly. God's Spirit helps us to live in that way. There is no law that says these things are wrong."
    },
    {
      "verse": "24",
      "text": "We belong to Christ. As a result, we no longer obey our wrong human thoughts. We stop doing the bad things that our thoughts want us to do. It is like we have killed those thoughts on the cross."
    },
    {
      "verse": "25",
      "text": "Now it is God's Spirit that gives us life. So we must let God's Spirit lead us in how we live."
    },
    {
      "verse": "26",
      "text": "We must not become proud. We must not be jealous of each other, so that we cause trouble to one another."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "My friends, if you see that someone among you is doing a wrong thing, you must warn that person. Those of you who have help from God's Spirit should tell that person how to live in a good way. But you must be patient and respect him. Be very careful yourselves, so that you do not also want to do wrong things."
    },
    {
      "verse": "2",
      "text": "When anyone among you has troubles, you must help each other. If you do that, you will be obeying Christ's rule."
    },
    {
      "verse": "3",
      "text": "You must not think that you are too important to help other people. If you are not really so important, you are thinking a false thought."
    },
    {
      "verse": "4",
      "text": "Everyone should think carefully about the things that they themselves do. If those things are good, that is a reason to be proud. A person like that does not need to think about whether he is better than anyone else."
    },
    {
      "verse": "5",
      "text": "Each person must live in a way that they know is right for them."
    },
    {
      "verse": "6",
      "text": "Everyone who is learning about God's message from a teacher should help his teacher. The student should share all the good things that he has with his teacher."
    },
    {
      "verse": "7",
      "text": "Nobody can hide the things that he does from God. Do not think a false thought like that! It is like a farmer who plants seeds in his field. The same kind of crops will grow as the seeds which he plants. That will be his harvest."
    },
    {
      "verse": "8",
      "text": "A person may do things only to make himself happy. That person's harvest will be God's punishment and death. Or a person may do the things that God's Spirit wants. That person will receive a harvest from God's Spirit. The harvest will be life with God for ever."
    },
    {
      "verse": "9",
      "text": "We must continue to do things that are good and we should not get tired. If we do not feel weak and stop doing good things, then we will receive a good harvest at the proper time."
    },
    {
      "verse": "10",
      "text": "Because of all that, we must help everyone when we have the chance. Certainly we must do good things to help our friends who believe in Christ, as we do."
    },
    {
      "verse": "11",
      "text": "Now I am writing these last words to you myself. You can see how large the letters are, when I write them with my own hand!"
    },
    {
      "verse": "12",
      "text": "Do not agree with those people who want to make you obey the Jewish rules. They say that you must let someone circumcise you. They want other people to think that they are important. They do not want to receive any trouble from others. They are afraid to teach that Christ's death on the cross is enough to save us."
    },
    {
      "verse": "13",
      "text": "Even those men that someone has circumcised do not obey all the Jewish rules. They want to circumcise you only to make themselves seem important. They want to show that they have authority over your bodies."
    },
    {
      "verse": "14",
      "text": "But I do not want to say any great things about myself. The only thing that makes me great is our Lord Jesus Christ's death on the cross. Because of Christ's sacrifice on the cross, it is like I have also died. The things that belong to this world have become dead to me, and I have become dead to them."
    },
    {
      "verse": "15",
      "text": "It does not matter whether anyone has circumcised you or not. What matters is that God has made you a new person."
    },
    {
      "verse": "16",
      "text": "I pray that God will bless everyone who lives by that rule. I pray that God will give them peace in their minds and that he will be kind to them. I pray this for all who belong to God's true people."
    },
    {
      "verse": "17",
      "text": "I want to receive no more trouble from anyone after this. The marks on my body show that I am Jesus' servant."
    },
    {
      "verse": "18",
      "text": "My Christian friends, I pray that our Lord Jesus Christ will continue to be very kind to you. I pray that he will help you in your spirits. Amen. This is true!"
    }
  ]
};