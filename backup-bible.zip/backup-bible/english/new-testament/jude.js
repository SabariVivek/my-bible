module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter is from me, Jude. I am Jesus Christ's servant and I am James's brother. I am writing to you people that God, the Father, loves. God has chosen you to be his own people. He is keeping you safe until the time when Jesus Christ returns."
    },
    {
      "verse": "2",
      "text": "I pray that God will be kind to you and that he will give you peace in your minds more and more. I want you to know more and more how much God loves you."
    },
    {
      "verse": "3",
      "text": "My friends, I wanted very much to write to you about how God has saved us from sin. That is what he has done for you and for us. But instead of that, I now know that I must write to you about something else. I must tell you to be strong and brave. You must do everything that you can to keep God's true message safe. God has given this message to his special people and his message will never change. Do not let anyone teach you a different message."
    },
    {
      "verse": "4",
      "text": "I say this because certain bad people have secretly come among you. They have turned away from God. They are trying to change God's true message. They teach that we can do any evil things that we want to do. They say that God will be kind and he will forgive us for all those things. They do not accept the authority of Jesus Christ, who is our only Master and our Lord. God will certainly punish those wicked people. A long time ago God said that he would punish people like them."
    },
    {
      "verse": "5",
      "text": "Remember that the Lord brought Israel's people out of Egypt where they had been slaves. But later he destroyed all those same people who did not trust him. I want you to remember these important things. You should already know all about them, but you must never forget them."
    },
    {
      "verse": "6",
      "text": "Also remember that some angels refused to obey God. They took more authority for themselves than God had given them. They left their own proper place with God in heaven. So God has tied them up as prisoners for ever in a completely dark place. He will keep them there until that great day when he will judge everyone."
    },
    {
      "verse": "7",
      "text": "Also, remember what happened to the cities called Sodom and Gomorrah, and the other cities that were near them. Like those bad angels, the people who lived in those places were also doing evil things. They were having sex with people who were not their husbands or their wives. They liked to have sex in other ways that are not right. God destroyed their cities. He has punished them with fire that never stops burning. That is an example of what will happen to wicked people like them."
    },
    {
      "verse": "8",
      "text": "These false teachers who have come among you do the same kind of bad things. Their dreams deceive them so that they use their bodies to do disgusting things. They refuse to obey God's authority. They insult God's powerful angels."
    },
    {
      "verse": "9",
      "text": "Even the leader of God's angels, Michael, did not speak bad words like that against the Devil. Long ago, Michael argued with the Devil about who should have Moses' dead body. But even when the Devil said bad words against God, Michael himself did not speak against the Devil. He did not think that he should do that. Instead, Michael said, ‘The Lord himself will show that you are wrong. ’"
    },
    {
      "verse": "10",
      "text": "But these false teachers speak bad things against anything that they do not understand. They are like animals that cannot think properly. They just do the things that their nature causes them to do. Those are the things that are destroying them."
    },
    {
      "verse": "11",
      "text": "It will be terrible for them! They have lived in the way that Cain lived. They have made the same mistake that Balaam made, because they wanted to get money for themselves. Like Korah, they have refused to obey God. So God will destroy them."
    },
    {
      "verse": "12",
      "text": "When you eat special meals together as believers, those false teachers meet with you. But they are dangerous! They will stop you showing your love for one another. They come only because they want to eat too much. They do not respect God or other people. They only think about themselves and they are not ashamed. They are like clouds that you think will bring rain. But the wind blows those clouds along and there is no rain. They are like trees that have no fruit, even at the time for harvest. People pull trees like that out of the ground. They are completely dead and can give no fruit."
    },
    {
      "verse": "13",
      "text": "Those false teachers are like water in the sea that the wind blows during a storm. The dirt that comes to the top of the water is like the disgusting things that those people do. They are like stars that have moved away from their proper places in the sky. God has prepared a completely dark place for them. God will keep them there for ever."
    },
    {
      "verse": "14",
      "text": "Long ago, Enoch also spoke about those false teachers. Enoch belonged to the seventh family that was born, starting with Adam. He said, ‘Look, the Lord will come with many thousands of his own angels."
    },
    {
      "verse": "15",
      "text": "He will judge all people. He will punish everyone who lives in a way that does not please him. He will punish them because of all the wicked things that they have done. He will punish them because of all the bad words that they have spoken against him. ’"
    },
    {
      "verse": "16",
      "text": "Those people are always complaining. They like to accuse other people. They do any bad things that will make themselves happy. They speak great things about themselves, to show how important they are. They praise other people only so that they can get something good for themselves."
    },
    {
      "verse": "17",
      "text": "But as for you, my friends, remember the message that the apostles of our Lord Jesus Christ have taught you. They spoke about what would happen in future times."
    },
    {
      "verse": "18",
      "text": "They said to you, ‘In the last days of this world, some people will laugh at God's message. They will say that it is silly to obey God. Instead, they will do the bad things that they want to do. Those things do not please God. ’"
    },
    {
      "verse": "19",
      "text": "It is people like this who cause you to argue with one another, so that you belong to separate groups. Their thoughts belong to this world. They do not have God's Spirit in them."
    },
    {
      "verse": "20",
      "text": "But you, my friends, have believed the message that comes from God himself. So you must help one another to trust God more and more. Pray to God with the help of the Holy Spirit."
    },
    {
      "verse": "21",
      "text": "Continue to live in a way that shows God's love. As you wait for our Lord Jesus Christ to come, remember that he is very kind. Because of that, you will have life with God for ever."
    },
    {
      "verse": "22",
      "text": "Help those people who do not know whether to trust God. Be kind to them."
    },
    {
      "verse": "23",
      "text": "Some people are in great danger. You must save them from the fire of God's punishment. Also be kind to people who have done wicked and disgusting things. But be careful! Do not let their sins make you bad too."
    },
    {
      "verse": "24",
      "text": "God is able to keep you safe so that you continue to trust him. One day you will stand in front of him and you will be very happy. God will bring you to that place and you will be completely good. You will be able to stand near to God, who shines with beautiful light."
    },
    {
      "verse": "25",
      "text": "He is the only God. He is the one who saves us because of our Lord Jesus Christ. So we praise him! We say that he is very great! He rules with power and authority. This has always been true. It is true now, and it will be true for ever. Amen!"
    }
  ]
};