module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "Jesus did many things when he was living on earth. He also taught people many things. I told you about all these things in the first book that I wrote for you, Theophilus."
    },
    {
      "verse": "2",
      "text": "Those are the things that Jesus did before God took him up into heaven. Jesus had chosen some men to be his apostles. With the power of the Holy Spirit he told them what they must do."
    },
    {
      "verse": "3",
      "text": "After Jesus died on the cross, he became alive again. During the 40 days after that, he showed himself many times to his apostles. He showed himself in different ways. Then they could be really sure that he was alive again. During this time, Jesus spoke to his apostles about the kingdom of God."
    },
    {
      "verse": "4",
      "text": "One time, when Jesus and his apostles were together, he said to them, ‘Do not leave Jerusalem yet. You must wait there until you receive my Father's gift. My Father promised to give it to you. I have already told you about it."
    },
    {
      "verse": "5",
      "text": "John baptized people with water, but after a few days God will baptize you with the Holy Spirit. ’"
    },
    {
      "verse": "6",
      "text": "While Jesus' apostles were together with him, they asked him, ‘Lord, at this time will you now give the kingdom back to us, the people of Israel? ’"
    },
    {
      "verse": "7",
      "text": "Jesus replied, ‘My Father decides when things will happen in the world. You do not need to know the day or the time when this will happen."
    },
    {
      "verse": "8",
      "text": "But the Holy Spirit will come to you, and he will give you power. The Holy Spirit will make your spirit strong. Then you will tell other people everywhere in the world about me. You will do that in Jerusalem, in Judea, in Samaria and in places far away. ’"
    },
    {
      "verse": "9",
      "text": "When Jesus had finished speaking to his apostles, God took him up to heaven. The apostles watched Jesus while he went up. Then a cloud hid him and they could not see him any more."
    },
    {
      "verse": "10",
      "text": "The apostles were still looking carefully up into the sky when suddenly two men appeared. They were wearing white clothes and they stood near the apostles."
    },
    {
      "verse": "11",
      "text": "The men said to the apostles, ‘You men from Galilee, you should not still be standing here and looking up into the sky. God has taken Jesus into heaven. You saw the way that Jesus went up to heaven. One day, he himself will return in the same way. ’"
    },
    {
      "verse": "12",
      "text": "Then the apostles left the Mount of Olives. They returned to Jerusalem. This was a walk of about 1 kilometre."
    },
    {
      "verse": "13",
      "text": "When the apostles arrived back in Jerusalem, they went to their room. The room where they were staying was upstairs. Those apostles were Peter, John, James and Andrew; Philip and Thomas; Bartholomew and Matthew; also James the son of Alphaeus, Simon the Zealot, and Judas, the son of James."
    },
    {
      "verse": "14",
      "text": "All these apostles often met together to pray. Mary who was Jesus' mother, other women and Jesus' brothers also met with them."
    },
    {
      "verse": "15",
      "text": "One day, about 120 people who believed in Jesus were meeting together. Peter stood up and he said to them,"
    },
    {
      "verse": "16",
      "text": "‘My friends, long ago, the Holy Spirit gave King David a message to speak from God. He spoke about the things that Judas would do. Judas was the one who showed the soldiers how to catch Jesus. These things had to happen in the way that David wrote in the Bible long ago."
    },
    {
      "verse": "17",
      "text": "Judas belonged to our group of disciples. Jesus chose him to work together with us. ’"
    },
    {
      "verse": "18",
      "text": "Judas received some money for the bad thing that he did. He bought a field with that money. But he fell down in that field and he died. His body broke open and the inside parts of his body poured out."
    },
    {
      "verse": "19",
      "text": "All the people who lived in Jerusalem heard about his death. So they called that field ‘Akeldama’ in their own language. ‘Akeldama’ means ‘The Field of Blood’."
    },
    {
      "verse": "20",
      "text": "Peter then said, ‘This is what King David wrote in the book of Psalms:“Let the house that he lived in become empty, so that nobody lives in it. ”David also wrote:“Let somebody else do the job which he did. ” ’ “Let the house that he lived in become empty, so that nobody lives in it. ” David also wrote: “Let somebody else do the job which he did. ” ’"
    },
    {
      "verse": "21",
      "text": "Peter then said, ‘Because of this, we must choose another man instead of Judas. That man must have been one of our group all the time that the Lord Jesus was with us."
    },
    {
      "verse": "22",
      "text": "That is, from the time when John was baptizing people until the time when Jesus went up to heaven. He must be someone who saw Jesus become alive again after he died, as we did. ’"
    },
    {
      "verse": "23",
      "text": "So the apostles agreed the names of two men. One of them was Joseph. People also called him Barsabbas and sometimes people called him Justus. The other man was called Matthias."
    },
    {
      "verse": "24",
      "text": "Then the whole group prayed, ‘Lord, you know what everybody is really like. Please show us which man you have chosen."
    },
    {
      "verse": "25",
      "text": "Which of these two men do you want to be an apostle instead of Judas? Judas left his work as an apostle. He has now gone to the place where he belongs. ’"
    },
    {
      "verse": "26",
      "text": "Then the group used lots to choose the name of one man. It happened that they chose Matthias. So Matthias now became the 12th apostle, together with the other 11 men."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Then the day of the Pentecost festival arrived. All the believers were meeting together in one place."
    },
    {
      "verse": "2",
      "text": "Suddenly, as they were sitting together, they heard a noise. The noise came from the sky and it filled the whole house. It was like the sound of a strong wind."
    },
    {
      "verse": "3",
      "text": "Then they saw something that looked like many small fires. The separate fires moved and went to sit on each person there."
    },
    {
      "verse": "4",
      "text": "All the believers became full with the Holy Spirit. They began to speak in languages that they had not learned. They spoke whatever language the Holy Spirit helped them to speak."
    },
    {
      "verse": "5",
      "text": "At that time, Jews who came from many different countries in the world were staying in Jerusalem. They were Jews who carefully obeyed God's Law."
    },
    {
      "verse": "6",
      "text": "When these Jews heard the noise, a large crowd of them came together in that place. As the believers spoke, each person in the crowd could hear the message in their own language. This confused them."
    },
    {
      "verse": "7",
      "text": "They were very surprised and they said to each other, ‘These men who are speaking our languages are all from Galilee."
    },
    {
      "verse": "8",
      "text": "But each of us can hear them speak in the language of our own home country. How can this happen?"
    },
    {
      "verse": "9",
      "text": "Some of us are from Parthia, Media and Elam. Some of us live in Mesopotamia, Judea, and Cappadocia. Some of us are from Pontus and Asia."
    },
    {
      "verse": "10",
      "text": "Some of us are from Phrygia and Pamphylia. Some of us are from Egypt. Some of us are from the country of Libya, near the town of Cyrene. Some of us have come from Rome to visit Jerusalem."
    },
    {
      "verse": "11",
      "text": "Some of us were born as Jews. Others of us are Gentiles who now obey God as the Jews do. Some of us are from Crete and some of us are from Arabia. But we all hear these people speaking in our own languages. They are speaking about all the great things that God has done. ’"
    },
    {
      "verse": "12",
      "text": "All the people were very surprised. They did not understand what was happening. ‘What does all this mean? ’ they asked each other."
    },
    {
      "verse": "13",
      "text": "But some other people laughed at the disciples. They said, ‘These people have drunk too much wine! ’"
    },
    {
      "verse": "14",
      "text": "apostles and he stood up with them. He began to speak to the crowd with a loud voice. He said, ‘You people who are Jews like us, listen carefully to me. All of you who live here in Jerusalem, you also listen to me. I will explain to you everything that is happening."
    },
    {
      "verse": "15",
      "text": "Some of you think that my friends here are drunk. But they are not drunk, because it is only nine o'clock in the morning."
    },
    {
      "verse": "16",
      "text": "No, something different is happening here. Long ago, the prophet Joel spoke God's message about all this. This is what he said:"
    },
    {
      "verse": "17",
      "text": "God says “This is what I will do in the last days. I will give my Spirit to all people. Your sons and daughters will speak my message to people. Your young men will see visions in their minds. And your old men will see things in their dreams. I will give my Spirit to all people. Your sons and daughters will speak my message to people. Your young men will see visions in their minds. And your old men will see things in their dreams."
    },
    {
      "verse": "18",
      "text": "At that time, I will give my Spirit to all my servants, both men and women. Then they will speak my message to people. both men and women. Then they will speak my message to people."
    },
    {
      "verse": "19",
      "text": "I will cause special things to appear in the sky. I will cause special things to appear on the earth too. Those things will show how great I am. There will be blood, fire and thick dark smoke. I will cause special things to appear on the earth too. Those things will show how great I am. There will be blood, fire and thick dark smoke."
    },
    {
      "verse": "20",
      "text": "The sun will become dark to people. The moon will become dark red like the colour of blood. These things will happen before the great day of the Lord arrives. That will be a wonderful day! The moon will become dark red like the colour of blood. These things will happen before the great day of the Lord arrives. That will be a wonderful day!"
    },
    {
      "verse": "21",
      "text": "The Lord will save everyone who asks him to help them. ” ’"
    },
    {
      "verse": "22",
      "text": "Peter then said, ‘People of Israel, listen to what I am saying! Jesus, the man from Nazareth, came with God's authority to do his work. God did many powerful and special things through him. These miracles showed you clearly that God had sent him. You know about all this. These things happened here, and you saw them. “I saw the Lord near me all the time. He is next to me, on my right side, so nothing will cause me trouble."
    },
    {
      "verse": "23",
      "text": "God knew that Jesus' enemies would give him to you. God had decided that this should happen. You let people who do not obey God's Law fix him to the cross. In that way you killed him."
    },
    {
      "verse": "24",
      "text": "But after his death, God caused him to become alive again. God saved Jesus from the power of death. It was impossible for death to keep hold of him."
    },
    {
      "verse": "25",
      "text": "A long time ago, King David spoke about the Messiah in this way:“I saw the Lord near me all the time. He is next to me, on my right side, so nothing will cause me trouble."
    },
    {
      "verse": "26",
      "text": "Because of this, I am very happy, and I will praise you, God. I am human and one day I will die, but I know that you will help me while I live. and I will praise you, God. I am human and one day I will die, but I know that you will help me while I live."
    },
    {
      "verse": "27",
      "text": "When I die, you will not leave me in Hades, the place for dead people. You will not let anything destroy the body of your Holy One. You will not let anything destroy the body of your Holy One."
    },
    {
      "verse": "28",
      "text": "You have shown me the paths that lead to life with you. I will be completely happy because you will be with me for ever. ” ’ I will be completely happy because you will be with me for ever. ” ’"
    },
    {
      "verse": "29",
      "text": "Peter then said, ‘Friends, people of Israel, I must speak clearly to you about our ancestor, King David. He died and people buried his body in the ground. You can still see the place where people buried him. “The Lord God said to my Lord: Sit at my right side until I beat your enemies completely."
    },
    {
      "verse": "30",
      "text": "He was a prophet. He knew what God had promised to do for him. He knew that one of his descendants would be king of God's people one day."
    },
    {
      "verse": "31",
      "text": "David understood what God would do in a future time. He did not speak about himself, but he spoke about the Messiah. He said that God would cause this man to become alive again after his death. God would not let him remain in Hades, the place for dead people. Nothing would destroy his body."
    },
    {
      "verse": "32",
      "text": "This man that David talked about is Jesus. After his death, God caused him to become alive again. We ourselves saw this happen. All of us saw it."
    },
    {
      "verse": "33",
      "text": "God took Jesus back up to heaven. He caused Jesus to sit at his right side, the place of great honour. Jesus received the Holy Spirit from his Father God, so that he could give the Spirit to us. This is what God had promised to do. God has poured his Holy Spirit on us. Now you are seeing and hearing the result of this."
    },
    {
      "verse": "34",
      "text": "King David himself did not go up into heaven like Jesus did. But David said:“The Lord God said to my Lord: Sit at my right side until I beat your enemies completely."
    },
    {
      "verse": "35",
      "text": "Then you will be able to put your feet on them. ”"
    },
    {
      "verse": "36",
      "text": "So all you people of Israel must be sure to know this: It is this same Jesus that God has chosen to be the Messiah. God has made him to be our Lord. But you fixed him to a cross and you killed him. ’"
    },
    {
      "verse": "37",
      "text": "The people heard what Peter said to them. They were very upset. So they said to Peter and the other apostles, ‘Friends, tell us what we should do. ’"
    },
    {
      "verse": "38",
      "text": "Peter said to them, ‘Each of you must stop doing wrong things. You must change how you live. If you believe in Jesus Christ, then we will baptize you. God will forgive you for the wrong things that you have done. Then you will receive the Holy Spirit, who is God's gift to you."
    },
    {
      "verse": "39",
      "text": "God has promised to do all this for you and your children. He has also promised this to people who live far away in other places. The Lord our God will do it for all the people that he has called to come to him. ’"
    },
    {
      "verse": "40",
      "text": "Peter also told them many other things. He continued to speak strongly to them. He told them to be careful and he said, ‘People who are alive today do not do what is right. Save yourselves from the punishment that God will send on them. ’"
    },
    {
      "verse": "41",
      "text": "Many of the people who listened to Peter believed his message. So the apostles baptized those people. About three thousand people who now believed in Jesus joined the group that same day."
    },
    {
      "verse": "42",
      "text": "These new believers listened carefully to what the apostles taught them. They joined with everyone else in the group. They prayed together and they ate meals together."
    },
    {
      "verse": "43",
      "text": "The apostles did many miracles which showed that the power of God was with them. As a result, all the people were very surprised and afraid."
    },
    {
      "verse": "44",
      "text": "All the believers continued to meet together often. They shared all their things with each other."
    },
    {
      "verse": "45",
      "text": "They sold some of their own things. Then they gave that money to any believers who needed it."
    },
    {
      "verse": "46",
      "text": "The whole group of believers met together every day in the yard of the temple. They shared their food and they ate meals together in each other's homes. They were very happy and they were honest with each other."
    },
    {
      "verse": "47",
      "text": "All the time, they praised God. All the other people thought that the believers were good people. Every day, the Lord saved more people so that the group of believers grew bigger."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "One day, Peter and John went to the temple in Jerusalem. It was three o'clock in the afternoon. This was the time that everyone went there to pray."
    },
    {
      "verse": "2",
      "text": "There was a man who could not walk. He had never been able to walk. Every day, his friends put him at the gate of the temple. It was called the Beautiful Gate. As people were going in through the gate, the man asked them for money. His friends were carrying him there when Peter and John arrived."
    },
    {
      "verse": "3",
      "text": "The man saw Peter and John as they were coming through the gate. So he asked them to give him some money."
    },
    {
      "verse": "4",
      "text": "Peter looked carefully at the man and so did John. Peter said to him, ‘Look at us! ’"
    },
    {
      "verse": "5",
      "text": "So the man looked at Peter and John. He thought that they would give him some money."
    },
    {
      "verse": "6",
      "text": "Then Peter said to the man, ‘I do not have any money. But I do have something else that I will give to you. Jesus Christ from Nazareth gave me authority to do this. So now I tell you to walk! ’"
    },
    {
      "verse": "7",
      "text": "Peter held the man's right hand and he helped him to stand up. Immediately the man's feet and ankles became strong."
    },
    {
      "verse": "8",
      "text": "The man jumped up and he stood on his feet. Then he began to walk about. He went into the temple with Peter and John. He was walking and jumping and he was praising God."
    },
    {
      "verse": "9",
      "text": "A large crowd of people were there. They saw the man walking. They heard him praising God."
    },
    {
      "verse": "10",
      "text": "‘Look! ’ they said. ‘We know this man. He usually sits at the Beautiful Gate of the temple and he asks people for money. What has happened to him? ’ They were all very surprised."
    },
    {
      "verse": "11",
      "text": "The man was still holding Peter and John as they went into the yard of the temple. All the people were very surprised about what they saw. So they ran to Peter and John at the place called Solomon's porch."
    },
    {
      "verse": "12",
      "text": "Peter saw all the people who had come together. So he said to them, ‘People of Israel, you should not be so surprised about what you have seen. You should not look at us as if we ourselves are powerful. It is not because we obey God that we could cause this man to walk again."
    },
    {
      "verse": "13",
      "text": "It happened because of Jesus, who was the special servant of God. That is the God of Abraham, Isaac, Jacob and our other ancestors who lived long ago. God has raised his servant Jesus up to a place of honour. You helped the rulers to take hold of Jesus. The Roman ruler Pilate had decided to let Jesus go free. But you turned against Jesus."
    },
    {
      "verse": "14",
      "text": "Jesus was God's Holy One who always did what was right. But you did not accept him. You told Pilate to let another man go free instead of Jesus. That man was in prison because he had killed people."
    },
    {
      "verse": "15",
      "text": "But Jesus is the person who leads people to true life. When you refused him, it meant that you killed him. But God made him alive again and raised him up from death. We ourselves saw him alive after he had died and we are telling you about it."
    },
    {
      "verse": "16",
      "text": "It is the power of Jesus that has made this man completely well again. We believe in him. We know that he has authority. You know this man. You saw that he had weak legs. Jesus has caused this man's legs to become strong. You can all see for yourselves what has happened. Yes, he is now well because we havetrusted Jesus and his power."
    },
    {
      "verse": "17",
      "text": "Friends, when you did all this to Jesus, you did not really know what you were doing. Your leaders also did not understand."
    },
    {
      "verse": "18",
      "text": "Jesus was God's Messiah. A long time ago, many of God's prophets spoke about him. They spoke God's message about what would happen to the Messiah. They said that he would suffer. God has now caused these things to happen."
    },
    {
      "verse": "19",
      "text": "So you must stop doing wrong things. Change how you live and turn to God. Then God will forgive you for all the wrong things that you have done."
    },
    {
      "verse": "20",
      "text": "The Lord God will help you. Times will come when he will cause your spirit to be strong. He has already chosen Jesus as the one to help you. He is God's Messiah, and God will send him back to you again."
    },
    {
      "verse": "21",
      "text": "Jesus must stay in heaven until the day that God will cause everything to become new again. Long ago God gave his prophets a message about this, and they told that message to people."
    },
    {
      "verse": "22",
      "text": "For example, Moses said this about the Messiah a long time ago: “The Lord your God will send you a prophet. He will be one of your own people. He will speak God's message as I have done. You must obey everything that he says to you."
    },
    {
      "verse": "23",
      "text": "God will punish anyone who does not obey that prophet. He will no longer be one of God's people and God will destroy him. ” ’"
    },
    {
      "verse": "24",
      "text": "Peter then said, ‘All of God's prophets spoke about what is happening in these days. Samuel was one of them, and all the prophets who came later also spoke the same message."
    },
    {
      "verse": "25",
      "text": "You are the people who receive that message from God today. The promise that God made to bless our ancestors is the same promise that he makes to you. God said to our ancestor Abraham, “Through your descendants, I will bless all the people on the earth. ”"
    },
    {
      "verse": "26",
      "text": "God chose Jesus to be his special servant. God sent him to you first. He wants to help you, so that you stop doing bad things. That is how he will bless you. ’"
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Peter and John were still speaking to the crowd in the yard of the temple. Then some priests, the leader of the police in the temple and some Sadducees came to them."
    },
    {
      "verse": "2",
      "text": "They were angry because of the things that Peter and John were teaching the people there. They were teaching that Jesus had become alive again after his death. The Jewish leaders did not agree that dead people could become alive again."
    },
    {
      "verse": "3",
      "text": "So they took hold of Peter and John. They put them in prison, because by then it was evening time. They put them in the prison until the next day."
    },
    {
      "verse": "4",
      "text": "But many of the people who had heard Peter's message believed what he said. There were now about 5, 000 men who believed in Jesus."
    },
    {
      "verse": "5",
      "text": "The next day, the Jewish rulers and other important Jews met together in Jerusalem. The teachers of God's Law met together with them."
    },
    {
      "verse": "6",
      "text": "They met with Annas who was the most important priest. Caiaphas, John and Alexander were also there. Other men from the family of the most important priest were with them too."
    },
    {
      "verse": "7",
      "text": "The Jewish leaders made Peter and John stand in front of them. They began to ask them questions. They said, ‘How did you cause that man's legs to become strong? Who gave you the power and the authority to do it? ’"
    },
    {
      "verse": "8",
      "text": "Then Peter became full with the Holy Spirit and he said to them, ‘All you men are rulers of the people and important Jews. “The builders refused to use a certain stone. They thought that it had no value. But now that stone has become the most important stone at the corner of the building. ” ’"
    },
    {
      "verse": "9",
      "text": "Today you are asking us questions about the good thing that we did for this man. Before that, he could not walk. You are asking us how we caused his legs to become strong."
    },
    {
      "verse": "10",
      "text": "Now I need to tell you and all the people of Israel what is true. Then you will know how this happened. This man is standing here in front of you and he is well. His legs are strong because of Jesus Christ of Nazareth and his authority. You fixed Jesus to a cross so that he died. But after that, God caused him to become alive again."
    },
    {
      "verse": "11",
      "text": "The Bible says this about him:“The builders refused to use a certain stone. They thought that it had no value. But now that stone has become the most important stone at the corner of the building. ” ’"
    },
    {
      "verse": "12",
      "text": "Then Peter said, ‘Only Jesus can save people. There has never been another person in the world that could do this. God has not given any other man the authority to save us. ’"
    },
    {
      "verse": "13",
      "text": "The Jewish leaders saw that Peter and John were not afraid of them. They also knew that they were not special people. They had not been to any school. So the leaders were very surprised about how Peter and John spoke. They understood that Peter and John had been friends with Jesus."
    },
    {
      "verse": "14",
      "text": "The man who was now well stood in front of the Jewish leaders. They could see that his legs had become strong again. So they could not say anything against Peter and John."
    },
    {
      "verse": "15",
      "text": "They told Peter and John to go out of the room where the leaders were meeting. Then they talked together to decide what they should do."
    },
    {
      "verse": "16",
      "text": "‘What should we do with these men? ’ they said. ‘Everyone who lives in Jerusalem knows about this miracle. They know that Peter and John did a great thing for that man. So we cannot say that they did not do it."
    },
    {
      "verse": "17",
      "text": "But we do not want any more people to know what has happened. So we must say to these men, “You must stop using the name of Jesus. You must stop teaching people about him. ” ’"
    },
    {
      "verse": "18",
      "text": "Then the Jewish leaders told Peter and John to come back into the room. They said to them, ‘You must not use the authority of Jesus to teach people any more. You must not speak about him. ’"
    },
    {
      "verse": "19",
      "text": "Then Peter and John replied to the leaders, ‘What do you think God wants us to do? Should we obey you? Or should we obey God? You decide!"
    },
    {
      "verse": "20",
      "text": "We know what is right. We must continue to speak about these things. We must tell people about the things that we have seen and heard. ’"
    },
    {
      "verse": "21",
      "text": "The Jewish leaders were angry. They told Peter and John that they must obey them. Then they let Peter and John go free. All the people there were praising God because of the miracle. So the leaders could not decide how to punish Peter and John."
    },
    {
      "verse": "22",
      "text": "years old."
    },
    {
      "verse": "23",
      "text": "After the Jewish leaders let them go free, Peter and John went back to the group of believers. They told them what the leaders of the priests and the important Jews had said. “People of other nations were very angry. They made plans to do useless things. Why did they do that?"
    },
    {
      "verse": "24",
      "text": "The believers listened to what Peter and John told them. Then they all prayed together. They said to God, ‘You are the Lord who rules over everything. You made the sky, the earth and the sea. You also made everything that is in them."
    },
    {
      "verse": "25",
      "text": "Our ancestor, King David, was your servant. You sent your Holy Spirit to him so that he spoke your message. You said through him, “People of other nations were very angry. They made plans to do useless things. Why did they do that?"
    },
    {
      "verse": "26",
      "text": "The kings and rulers of the world met together. They decided to fight against the Lord Godand against his Messiah. ” They decided to fight against the Lord God and against his Messiah. ”"
    },
    {
      "verse": "27",
      "text": "Lord God, it has now happened like that. Herod and Pontius Pilate have met together here in Jerusalem. They met with Israelite people and with people of other nations. Together they made plans to kill your holy servant, Jesus. He is the one that you chose to be your Messiah."
    },
    {
      "verse": "28",
      "text": "But you are powerful. These men did only what you said would happen. You had already decided on these events."
    },
    {
      "verse": "29",
      "text": "Lord God, you know that the Jewish leaders want to punish Peter and John. We are your servants. Please help us not to be afraid. Help us to speak your message to people without fear."
    },
    {
      "verse": "30",
      "text": "Show people that you are strong. Cause sick people to become well. Do other powerful things to show that you are God. It is the authority of your holy servant Jesus that will make these things happen. ’"
    },
    {
      "verse": "31",
      "text": "The believers finished praying. The house where they were meeting together shook. God filled them all with his Holy Spirit. That made them very brave and they spoke God's message clearly to people."
    },
    {
      "verse": "32",
      "text": "All the believers agreed completely with each other about how they should live. They wanted to help each other. Nobody kept anything only for themselves. They let the other believers use it."
    },
    {
      "verse": "33",
      "text": "The apostles continued to teach about the Lord Jesus. They spoke with great power. They told people, ‘After Jesus died, God caused him to live again. We saw that happen. ’ God was very kind to all the believers and he helped them in many ways."
    },
    {
      "verse": "34",
      "text": "Everyone had as much as they needed. Some believers had land or houses, which belonged to them. They sold those things and then they took the money to the apostles."
    },
    {
      "verse": "35",
      "text": "Then the apostles gave the money to any of the believers who needed it."
    },
    {
      "verse": "36",
      "text": "One of the believers was called Joseph. He was from the family of Levi. He was from the island called Cyprus. The apostles called him Barnabas because he liked to help people."
    },
    {
      "verse": "37",
      "text": "Joseph sold a field that belonged to him. He took the money from this and he gave it to the apostles. He wanted them to use the money to help other believers."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "But there was a man called Ananias among the group of believers. His wife was called Sapphira. Together they sold one of their fields."
    },
    {
      "verse": "2",
      "text": "Ananias gave part of the money that he received to the apostles. But he kept part of the money for himself. Sapphira knew all about what Ananias had done."
    },
    {
      "verse": "3",
      "text": "Peter said to Ananias, ‘Ananias, Satan wanted you to tell a lie and you have obeyed him. You have told a lie to the Holy Spirit. That is a bad thing to do! You sold your field, but you did not give us all the money. You kept part of it for yourselves."
    },
    {
      "verse": "4",
      "text": "Before you sold the field, it belonged to you. And after you sold the field, the money was yours. You could choose what to do with it. But you chose to do a very bad thing. You did not only tell a lie to us men. You have told a lie to God. ’"
    },
    {
      "verse": "5",
      "text": "As soon as he heard Peter say this, Ananias fell down and he died. When people heard what had happened, they were all very afraid."
    },
    {
      "verse": "6",
      "text": "Some young men came into the room. They put cloths around Ananias's dead body and they carried it outside. Then they buried it."
    },
    {
      "verse": "7",
      "text": "About three hours later, Ananias's wife, Sapphira, came into the room. She did not know what had happened to her husband."
    },
    {
      "verse": "8",
      "text": "Peter asked Sapphira, ‘Was this all the money that you and your husband received for your field? ’ ‘Yes, ’ Sapphira answered. ‘That was all the money that we received. ’"
    },
    {
      "verse": "9",
      "text": "Peter said to her, ‘It was wrong for you and your husband to do this bad thing. You agreed together to tell a lie to the Holy Spirit of the Lord God. Listen! The men who have just buried your husband are at the door again now. They will carry your body out too. ’"
    },
    {
      "verse": "10",
      "text": "Immediately, Sapphira fell down in front of Peter and she died. Then the young men came into the room. They saw that Sapphira was dead. So they carried her outside and they buried her body next to her husband."
    },
    {
      "verse": "11",
      "text": "The whole group of believers, and many other people, heard about what had happened to Ananias and Sapphira. They were all very afraid."
    },
    {
      "verse": "12",
      "text": "At that time, the apostles were doing many miracles that showed God's power among the people. All the believers often met together in the yard of the temple in a place called Solomon's porch."
    },
    {
      "verse": "13",
      "text": "The other people were afraid to meet with the group of believers. But people respected the believers very much."
    },
    {
      "verse": "14",
      "text": "More and more people became believers and they joined the group. So now many men and women believed in the Lord Jesus."
    },
    {
      "verse": "15",
      "text": "As a result, people carried their sick friends into the streets and put them on beds and mats. They hoped that Peter would pass that way and make their sick friends well again. They just wanted Peter's shadow to touch them."
    },
    {
      "verse": "16",
      "text": "Many people also came into Jerusalem from the small towns near the city. They brought their sick friends with them. Some of those sick people had bad spirits that gave them trouble. God caused all these sick people to become well again."
    },
    {
      "verse": "17",
      "text": "People liked the apostles very much. So the most important priest and his friends who belonged to the Sadducees' group were very jealous."
    },
    {
      "verse": "18",
      "text": "These important men took hold of the apostles and they put them in the city's prison."
    },
    {
      "verse": "19",
      "text": "But during the night, one of the Lord God's angels came and he opened the prison gates. He led the apostles out of the prison."
    },
    {
      "verse": "20",
      "text": "The angel said to them, ‘Go and stand in the yard of the temple. Tell the people everything about this new life that God gives. ’"
    },
    {
      "verse": "21",
      "text": "The apostles did what the angel told them to do. At dawn they went into the yard of the temple. They began to teach the people there. Then the most important priest and his friends arrived. They told the group of Jewish leaders to meet with them. All the most important people in Israel were in that group. Then they sent their police to the prison to bring the apostles to the meeting place."
    },
    {
      "verse": "22",
      "text": "But when the police arrived at the prison, they did not find the apostles there. So the police returned to the Jewish leaders and they told them the news."
    },
    {
      "verse": "23",
      "text": "They said, ‘We arrived at the prison. We saw that the soldiers had locked the gates. They were standing at the gates and they were watching carefully. But when we opened the gates of the prison, we did not find anyone there! ’"
    },
    {
      "verse": "24",
      "text": "The leader of the police of the temple and the leaders of the priests heard the news. They could not understand what had happened. They were afraid of what might happen next."
    },
    {
      "verse": "25",
      "text": "Then a man came to the leaders. He said to them, ‘Listen! Those men that you put in the prison are now standing in the yard of the temple. They are teaching the people there. ’"
    },
    {
      "verse": "26",
      "text": "So the leader of the police took his men with him to find the apostles. They took hold of the apostles to take them back to the Jewish leaders. But they did not hurt them because they were afraid of the people. They thought that the people might be angry. They might throw stones at them to kill them."
    },
    {
      "verse": "27",
      "text": "The police brought the apostles into the meeting room. They made them stand in front of the group of Jewish leaders. The most important priest said to the apostles,"
    },
    {
      "verse": "28",
      "text": "‘We told you that you must not teach people any more with the authority of Jesus. But now look at what you have done! Now people everywhere in Jerusalem have heard your teaching. You also want people to think that we are guilty for the death of Jesus. ’"
    },
    {
      "verse": "29",
      "text": "Peter and the other apostles answered, ‘We must obey God rather than obey people."
    },
    {
      "verse": "30",
      "text": "You fixed Jesus to a cross so that he died. But then the God of our ancestors caused him to become alive again."
    },
    {
      "verse": "31",
      "text": "God raised Jesus and he put him in the most important place at his right side. Jesus is now the one who leads us and the one who saves us. He has made a way for the people of Israel to turn back to God. He wants us to stop doing wrong things. Then God will forgive us for our sins."
    },
    {
      "verse": "32",
      "text": "We tell people about what happened to Jesus. We ourselves saw these things. Now God has given his Holy Spirit to people who obey him. The Holy Spirit also shows that these things are true. ’"
    },
    {
      "verse": "33",
      "text": "The group of Jewish leaders heard what the apostles said to them. They were so angry that they wanted to kill the apostles."
    },
    {
      "verse": "34",
      "text": "But one man did not agree. He was called Gamaliel and he was a Pharisee, a teacher of the Law. All the people agreed that he was a good man. Gamaliel stood up in front of the group of Jewish leaders. He told the police to take the apostles out of the room."
    },
    {
      "verse": "35",
      "text": "When they had gone, Gamaliel spoke to the group of leaders: ‘Men of Israel! Think carefully about what you want to do to these men."
    },
    {
      "verse": "36",
      "text": "Remember what happened to Theudas a few years ago. That man told everyone, “I am a very important leader. ” As a result, about 400 men joined his group. But then somebody killed him, and all his men went away. Nobody heard any more about them."
    },
    {
      "verse": "37",
      "text": "Later, Judas from Galilee appeared at the time when the Romans were making a list of everyone's names. Many people also came to help him fight against the Romans. But somebody killed him. His men also ran away and nothing more happened."
    },
    {
      "verse": "38",
      "text": "Now think about what is happening with these men. I tell you it would be better to leave them alone. Let them go free. If their message only comes from human ideas, all their work will fail."
    },
    {
      "verse": "39",
      "text": "But perhaps what they are doing really does come from God himself. If that is true, then you cannot stop them. You might even find that you are fighting against God! ’"
    },
    {
      "verse": "40",
      "text": "The Jewish leaders agreed with Gamaliel. They told the apostles to come back into the room. They told the police to hit them with whips. Then they said to the apostles, ‘You must not use the authority of Jesus to teach the people. ’ After that, they let the apostles go free."
    },
    {
      "verse": "41",
      "text": "The apostles went away from the meeting of the Jewish leaders. They were very happy because they thought to themselves, ‘These leaders have done bad things to us because we obey Jesus. That shows that God accepts us as his people. ’"
    },
    {
      "verse": "42",
      "text": "Every day the apostles continued to teach people about Jesus. They spoke in people's homes and in the yard of the temple. All the time, they told people the good news that Jesus is God's Messiah."
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "At that time, more and more people became disciples of Jesus. Among the believers, some were Jews who spoke the Greek language. Others were Jews who spoke the Aramaic language. The Jews who spoke Greek had a problem with the other Jews. They said, ‘The widows in our group do not receive the right help. Each day, when you give out the food and money, our widows receive less than they should get. ’"
    },
    {
      "verse": "2",
      "text": "apostles heard about the problem. They told all the believers to meet together with them. The apostles said, ‘Our work is to teach people God's message about Jesus. We do not have time to give out the food and money to people as well."
    },
    {
      "verse": "3",
      "text": "So, friends, please choose seven men from among you. You must know that each of them is full of the Holy Spirit. They must also be very wise. We will ask these seven men to do this work for us."
    },
    {
      "verse": "4",
      "text": "Then we will have more time to pray. We will also have more time to teach people God's message. ’"
    },
    {
      "verse": "5",
      "text": "The whole group of believers was happy with the apostles' words. So first they chose a man called Stephen. Stephen believed strongly in God and he was full of the Holy Spirit. The believers also chose six other men: Philip, Prochorus, Nicanor, Timon, Parmenas and Nicolas. Nicolas was from Antioch. He was not born as a Jew, but he had joined the Jews later."
    },
    {
      "verse": "6",
      "text": "The group of believers put these seven men in front of the apostles. The apostles prayed for each man and they put their hands on them. They gave them authority to do this special work."
    },
    {
      "verse": "7",
      "text": "So more and more people heard the message from God. The number of people in Jerusalem who believed in Jesus grew more and more. Many of the Jewish priests also believed the message about Jesus."
    },
    {
      "verse": "8",
      "text": "God helped Stephen in many special ways. God's power was with him. He did many miracles among the people which showed that God was with him."
    },
    {
      "verse": "9",
      "text": "But some men spoke against Stephen. They did not agree with what he taught people. These men were from one of the Jewish meeting places in Jerusalem. People called them, ‘The Group of Free Men’. These men were Jews from the cities called Cyrene and Alexandria. Some of them were from towns in Cilicia and Asia. They began to argue with Stephen."
    },
    {
      "verse": "10",
      "text": "But the Holy Spirit helped Stephen to be very wise when he spoke. So these men could not say that he was wrong."
    },
    {
      "verse": "11",
      "text": "Then those men secretly gave money to some bad men. They told them to say to the Jewish leaders, ‘We heard this man, Stephen, say bad things against Moses and against God. ’"
    },
    {
      "verse": "12",
      "text": "This made the people become angry against Stephen. The important Jews and the teachers of God's Law also became very angry. So they took hold of Stephen. They took him to stand in front of the group of Jewish leaders."
    },
    {
      "verse": "13",
      "text": "Then they brought in some men to say bad things about Stephen. The things that these men said were not true. They said about Stephen, ‘This man is always saying bad things about the temple. He says bad things against God's Law."
    },
    {
      "verse": "14",
      "text": "We also heard him talk about Jesus, the man who comes from Nazareth. He said that Jesus will destroy this place. He also said that Jesus will change the way that Moses taught us to live. ’"
    },
    {
      "verse": "15",
      "text": "All the Jewish leaders who sat there in the meeting looked carefully at Stephen. They saw that his face was very bright, like the face of an angel."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "The most important priest said to Stephen, ‘These men are saying things against you. Are these things true? ’"
    },
    {
      "verse": "2",
      "text": "Stephen said, ‘Men of Israel, my friends and leaders. Listen to what I say. Our great God appeared to our ancestor, Abraham, when he was still living in Mesopotamia. This happened before he went to Haran."
    },
    {
      "verse": "3",
      "text": "God said to Abraham, “Leave your own country and your own family and go to a different country. I will show you where that will be. ”"
    },
    {
      "verse": "4",
      "text": "So Abraham left his country where the Chaldean people lived. He went to Haran and he stayed there. While he was there, his father died. Then God said to him, “Leave this place. ” God then sent him to live in Canaan. This is where we are living now."
    },
    {
      "verse": "5",
      "text": "At that time, God did not give Abraham any part of Canaan for his own family. He did not give Abraham even a very small piece of ground. But God made a promise to Abraham. He said, “This land will become your own country. It will also be your descendants' country. ” When God said this to him, Abraham did not yet have any children."
    },
    {
      "verse": "6",
      "text": "This is what God said to him: “Your descendants will live in a foreign country for 400 years. The people in that country will cause your descendants to be their slaves. They will be very cruel to them."
    },
    {
      "verse": "7",
      "text": "But I will punish those people who cause your descendants to work as slaves for them. After I have done that, your descendants will leave that country. They will come to this place and worship me here. ” That is what God said to Abraham."
    },
    {
      "verse": "8",
      "text": "Then God made an covenant with Abraham that his descendants would be his special people. God said, “You must circumcise all your baby boys. ”Later, Abraham became the father of Isaac. Abraham circumcised Isaac when he was eight days old. Then Isaac became the father of Jacob. Jacob himself had 12 sons. These sons became the 12 ancestors of the families of Israel. Later, Abraham became the father of Isaac. Abraham circumcised Isaac when he was eight days old. Then Isaac became the father of Jacob. Jacob himself had 12 sons. These sons became the 12 ancestors of the families of Israel."
    },
    {
      "verse": "9",
      "text": "One of Jacob's sons was called Joseph. Jacob was more kind to Joseph than to his other sons. For this reason, Joseph's brothers did not like him. So one day they took Joseph and they sold him as a slave. The men that bought Joseph took him to Egypt. There he became the slave of an important man. All this time, God took care of Joseph."
    },
    {
      "verse": "10",
      "text": "God saved him from all his troubles and he helped him to live in a wise way. Because of that, Pharaoh, the king of Egypt, liked Joseph. He saw that Joseph was very wise. So Pharaoh gave Joseph authority to rule Egypt and everyone in the king's own house."
    },
    {
      "verse": "11",
      "text": "Then there was a famine everywhere in Egypt and in Canaan. Everyone was very hungry and they suffered a lot. Our ancestors also had no food to eat."
    },
    {
      "verse": "12",
      "text": "Jacob heard news that Pharaoh had stored a lot of wheat in Egypt. So he sent his sons there to buy food from Pharaoh. This was the first time that they went to Egypt."
    },
    {
      "verse": "13",
      "text": "Later, Jacob sent his sons back to Egypt for a second time. This time, Joseph told his brothers who he really was. As a result, Pharaoh came to know about Joseph's family."
    },
    {
      "verse": "14",
      "text": "After this, Joseph sent a message to his father, that he should also come to Egypt with his whole family. At that time, there were 75 people in Jacob's family."
    },
    {
      "verse": "15",
      "text": "So Jacob went to Egypt with all his family. Jacob and his 12 sons, our ancestors, lived there until they died."
    },
    {
      "verse": "16",
      "text": "When the people of Israel left Egypt, they carried with them the dead bodies of Joseph and his family. They took them back to Shechem and they buried them in a hole for dead people there. Abraham had bought that ground in Shechem from the family of a man called Hamor. He had paid Hamor the right money for it. ’"
    },
    {
      "verse": "17",
      "text": "Stephen then said, ‘After many years, the time arrived for God to make his promise to Abraham become true. By this time, Jacob's family who still lived in Egypt had become very many."
    },
    {
      "verse": "18",
      "text": "Now, a different king ruled Egypt. This new king did not know anything about Joseph and what he had done."
    },
    {
      "verse": "19",
      "text": "He was very cruel to our ancestors and he caused them to suffer. When new babies were born, he said that our people must put them out of their homes. He said that because he wanted the babies to die."
    },
    {
      "verse": "20",
      "text": "It was at this time that Moses was born. He was a very beautiful baby. His parents took care of him for three months in their own home."
    },
    {
      "verse": "21",
      "text": "Then they had to put him outside. But Pharaoh's daughter found him and she took him to her home. She took care of him as if he was her own son."
    },
    {
      "verse": "22",
      "text": "Moses had teachers who taught him all the wise things that the Egyptians knew. He learned how to speak well. He could also do powerful things."
    },
    {
      "verse": "23",
      "text": "years old, he went to see his own people, the people of Israel."
    },
    {
      "verse": "24",
      "text": "He saw that an Egyptian man was being cruel to one of the Israelite men. So he went to help the Israelite man. He killed the Egyptian man to punish him."
    },
    {
      "verse": "25",
      "text": "Moses thought that his own people would understand him. They would know that God was using him to save them. They would no longer be slaves to work for the Egyptians. But his people did not understand all this."
    },
    {
      "verse": "26",
      "text": "On the next day, Moses saw two Israelite men. They were fighting each other. He tried to make them become friends. He said to them, “Listen to me, men. You are both in the family of Israel. You should not hurt each other. ”"
    },
    {
      "verse": "27",
      "text": "The man who was being cruel to the other man pushed Moses away. He said to Moses, “You have no authority to rule us. You are not our judge."
    },
    {
      "verse": "28",
      "text": "I know that yesterday you killed an Egyptian man. So do you want to kill me too? ”"
    },
    {
      "verse": "29",
      "text": "When Moses heard this, he decided to run away. He went to the land of Midian and he lived there. He married a wife and they had two sons."
    },
    {
      "verse": "30",
      "text": "years. Then, one day, he was in the wilderness near Sinai mountain. He saw a bush there that was burning. An angel appeared to him in the fire."
    },
    {
      "verse": "31",
      "text": "Moses was very surprised by what he saw. He went near to the bush so that he could see it better. Then he heard the Lord God speak to him from the bush."
    },
    {
      "verse": "32",
      "text": "God said, “I am the God of your ancestors. I am the God of Abraham, Isaac and Jacob. ” Moses was very frightened. He was too afraid to look at the bush any more."
    },
    {
      "verse": "33",
      "text": "Then the Lord God said to Moses, “Remove your shoes from your feet, because you are standing in a very special place. This is my own place."
    },
    {
      "verse": "34",
      "text": "I have seen that the Egyptians are being cruel to my people. My people are crying with pain and I have heard them. Now I have come down to save them. So come here and listen to me. I will send you back to Egypt. ” ’"
    },
    {
      "verse": "35",
      "text": "Then Stephen said, ‘Moses is the man that the people of Israel would not accept. They had said to him, “You have no authority to rule us. You are not our judge. ” But God did send Moses to rule them. God himself sent Moses to save them from the Egyptians. God spoke to Moses through the angel that appeared to him in the bush."
    },
    {
      "verse": "36",
      "text": "So it was Moses who led the people of Israel out of Egypt. He did some powerful things before the people left Egypt. This showed that God was with him. He did more miracles at the Red Sea. Then he led the people through the wilderness for 40 years. He also did more miracles there."
    },
    {
      "verse": "37",
      "text": "It was Moses who said to the people of Israel, “God will send you a prophet. He will be one of your own people. He will speak God's message as I have done. ”"
    },
    {
      "verse": "38",
      "text": "This is the same Moses who was leader of our people in the wilderness. He was there with our ancestors when the angel spoke to him on Sinai mountain. He received the message from God to give to us. Those words from God bring life to us."
    },
    {
      "verse": "39",
      "text": "But our ancestors would not obey Moses. They did not accept him as their leader. They wanted to go back to Egypt."
    },
    {
      "verse": "40",
      "text": "So the people said to Aaron, “Please make us some gods that we can carry in front of us. Yes, that man Moses brought us out of Egypt. But now we do not know what has happened to him. ”"
    },
    {
      "verse": "41",
      "text": "It was then that the people made something that would be an idol for them. They made it from gold with the shape of a young bull. They killed some animals and they burned them as a gift for their idol. The people then had a big meal together because they were very happy. They thought that they had made something that was very good."
    },
    {
      "verse": "42",
      "text": "But God turned away from his people. He let them do what they wanted to do. He let them worship the stars in the sky. One of God's prophets wrote about this long ago:“God said, ‘People of Israel, listen! When you were in the wilderness for 40 years, you brought sacrifices and gifts to me. But you did not really worship me when you did that. One of God's prophets wrote about this long ago: “God said, ‘People of Israel, listen! years, you brought sacrifices and gifts to me. But you did not really worship me when you did that."
    },
    {
      "verse": "43",
      "text": "No. You carried with you the idol of the god called Molech. You also carried an idol with the shape of a star, to be like your god, Rephan. These were the idols which you worshipped in the wilderness. So now I will send you away from your own country. You will go to live in places beyond Babylon. ’ ” You also carried an idol with the shape of a star, to be like your god, Rephan. These were the idols which you worshipped in the wilderness. So now I will send you away from your own country. You will go to live in places beyond Babylon. ’ ”"
    },
    {
      "verse": "44",
      "text": "When our ancestors were in the wilderness, they carried a special tent with them. It showed that God was there with them and that is where they worshipped him. God showed Moses how he should make that tent. The people made it in the way that God had said."
    },
    {
      "verse": "45",
      "text": "Later, our ancestors received that special tent for themselves. They brought it with them when they came with Joshua to live in this land. They took the land from the people who were living here. God chased out those people so that our ancestors could live there. The tent remained in this place until David became the king of Israel."
    },
    {
      "verse": "46",
      "text": "God was happy with King David and he helped him very much. So David said to God, “May I build a special house where you can live among your people, the descendants of Jacob? ”"
    },
    {
      "verse": "47",
      "text": "But it was David's son, Solomon, who built a house for God."
    },
    {
      "verse": "48",
      "text": "But we know that God does not live in a house that people have made. He is the powerful God who is over all. God's prophet Isaiah spoke these words:"
    },
    {
      "verse": "49",
      "text": "The Lord God says, “Heaven is the seat where I sit to rule. The earth is the place where I put my feet. You could not build a house for me where I could live. You could not make a place for me to rest there. “Heaven is the seat where I sit to rule. The earth is the place where I put my feet. You could not build a house for me where I could live. You could not make a place for me to rest there."
    },
    {
      "verse": "50",
      "text": "I am the one who has made all these things myself. ” ’"
    },
    {
      "verse": "51",
      "text": "Then Stephen said, ‘You people do not want to obey God! You do not want to listen to God's true message. You are the same as your ancestors. Like them, you always fight against what the Holy Spirit says."
    },
    {
      "verse": "52",
      "text": "Your ancestors did bad things to every prophet that God sent to them. They even killed the prophets who told them about the Righteous Man that God would send. Now you have given that Man to his enemies. You have made them kill him."
    },
    {
      "verse": "53",
      "text": "You are the people who received God's Law. God caused his angels to give that Law to your ancestors. But you have not obeyed it. ’"
    },
    {
      "verse": "54",
      "text": "The group of Jewish leaders listened to Stephen. What he said made them very angry. They bit their teeth together because they were so angry."
    },
    {
      "verse": "55",
      "text": "But the Holy Spirit filled Stephen. He looked up to heaven and he saw the bright light of God's glory. He also saw Jesus, who was standing at the right side of God."
    },
    {
      "verse": "56",
      "text": "Stephen said, ‘Look! I can see into heaven itself. It is open! I can see the Son of Man and he is standing at the right side of God! ’"
    },
    {
      "verse": "57",
      "text": "When the Jewish leaders heard this, they put their hands over their ears. Then they shouted very loudly at Stephen and they all ran towards him."
    },
    {
      "verse": "58",
      "text": "They took hold of Stephen and they pulled him out of the city. They removed their coats. They gave them to a young man to keep them safe. This young man was called Saul. Then they began to throw stones at Stephen to kill him."
    },
    {
      "verse": "59",
      "text": "While the men were throwing stones at him, Stephen prayed, ‘Lord Jesus, please receive my spirit as I die. ’"
    },
    {
      "verse": "60",
      "text": "Then he fell down on his knees. He shouted, ‘Lord, please forgive these men. Do not punish them because they are doing this to me. ’ After Stephen had said this, he died."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Saul was standing there while the Jewish leaders killed Stephen. He agreed with what they did. On the same day that Stephen died, the group of believers who lived in Jerusalem began to have great trouble. People did bad things to them. All the believers left Jerusalem and went to other places in Judea and Samaria. Only Jesus' 12 apostles stayed in Jerusalem. On the same day that Stephen died, the group of believers who lived in Jerusalem began to have great trouble. People did bad things to them. All the believers left Jerusalem and went to other places in Judea and Samaria. Only Jesus' 12 apostles stayed in Jerusalem."
    },
    {
      "verse": "2",
      "text": "Some good men who loved God buried Stephen's dead body. They were very sad and they cried with loud voices."
    },
    {
      "verse": "3",
      "text": "But Saul brought great trouble to the believers. He wanted to destroy their whole group. So he went to all their houses. He took hold of the believers and he put them into prison. He did that to both men and women."
    },
    {
      "verse": "4",
      "text": "The believers who had left Jerusalem went to many different towns. In each place, they told the people the message about Jesus."
    },
    {
      "verse": "5",
      "text": "One of them who was called Philip went to a city in Samaria. There he told the people the message about Jesus Christ, God's Messiah."
    },
    {
      "verse": "6",
      "text": "Crowds of people came together to hear Philip speak. They saw him do many miracles which showed that God was with him. So they listened carefully to his message."
    },
    {
      "verse": "7",
      "text": "Many people there had bad spirits, which were living in them. Philip sent the bad spirits out of those people. As the spirits came out, they shouted loudly. Some other people had weak arms or legs, and some people could not walk well. Philip caused many of them to become well again."
    },
    {
      "verse": "8",
      "text": "As a result, the people in that city were very happy."
    },
    {
      "verse": "9",
      "text": "A man called Simon lived in that city. For a long time, he had used magic to do great things. All the people who lived in Samaria were very surprised at what he did. Simon told everyone that he was a very important person."
    },
    {
      "verse": "10",
      "text": "All the people in the city watched Simon carefully. This included the people who were important and all the other people too. Everyone said, ‘This man has great power that comes from God. ’"
    },
    {
      "verse": "11",
      "text": "Simon had used his magic for a long time and he had surprised them all very much. Because of that, they listened to him carefully."
    },
    {
      "verse": "12",
      "text": "But then Philip told them the good news about the kingdom of God. He told them the message about God's Messiah, Jesus. Many men and women believed Philip's message, so he baptized them."
    },
    {
      "verse": "13",
      "text": "Simon also believed and Philip baptized him too. After this, Simon stayed near to Philip. He was very surprised at the powerful miracles which Philip did."
    },
    {
      "verse": "14",
      "text": "The apostles who were in Jerusalem heard about all this. They heard that many people in Samaria had believed God's word. So they sent Peter and John to Samaria."
    },
    {
      "verse": "15",
      "text": "When these two apostles arrived in Samaria, they prayed for the people who now believed in Jesus. They asked God to give the new believers the Holy Spirit."
    },
    {
      "verse": "16",
      "text": "The Holy Spirit had not yet come to any of these people. When Philip had baptized them, he had just used the name of the Lord Jesus."
    },
    {
      "verse": "17",
      "text": "So Peter and John put their hands on the head of each believer, and they each received the Holy Spirit."
    },
    {
      "verse": "18",
      "text": "Simon saw that God gave the Holy Spirit to people when the apostles put their hands on them. So he said to Peter and John, ‘Here is some money for you."
    },
    {
      "verse": "19",
      "text": "Please give me this same power. I want to put my hands on other people, so that they will receive the Holy Spirit. ’"
    },
    {
      "verse": "20",
      "text": "Peter answered Simon, ‘I pray that God will destroy you and your money! You think that you can buy this gift with your money! It is very wrong for you to think that. It is God who gives that gift."
    },
    {
      "verse": "21",
      "text": "You cannot do the work which we are doing. God knows that you are not thinking the right things."
    },
    {
      "verse": "22",
      "text": "You must turn away from those very bad thoughts. Turn to the Lord and pray that he will forgive you. Then perhaps he will forgive you for these bad thoughts."
    },
    {
      "verse": "23",
      "text": "You are very upset because you are jealous. I can see that sin rules your life. ’"
    },
    {
      "verse": "24",
      "text": "Then Simon said to Peter and John, ‘Please, pray to the Lord God for me. Then none of these bad things that you have spoken about will happen to me. ’"
    },
    {
      "verse": "25",
      "text": "Peter and John told the people about the Lord Jesus and they spoke God's message to them. Then they returned to Jerusalem. On their way, they went through many villages in Samaria and they told the people the good news about Jesus."
    },
    {
      "verse": "26",
      "text": "Then an angel of the Lord God came to Philip. He said, ‘Philip, go south to the road between Jerusalem and Gaza which goes through the wilderness. ’"
    },
    {
      "verse": "27",
      "text": "So Philip started on his journey. While he was going along this road, he met an important officer from Ethiopia. This man had authority over the queen of Ethiopia's money. The queen was called Candace. The officer was travelling home from Jerusalem. He had been there to worship God."
    },
    {
      "verse": "28",
      "text": "Now the man was travelling home again in his chariot. He was reading something from the book that God's prophet Isaiah wrote."
    },
    {
      "verse": "29",
      "text": "The Holy Spirit said to Philip, ‘Go to that chariot and walk beside it. ��"
    },
    {
      "verse": "30",
      "text": "So Philip ran to the cart as it went along. The officer was reading aloud from the prophet Isaiah's book and Philip heard him. So Philip asked the man, ‘Do you understand the things that you are reading about? ’"
    },
    {
      "verse": "31",
      "text": "The man answered, ‘I cannot understand it. I need someone to explain it to me. ’ Then he said to Philip, ‘Come up here and sit with me in the cart. ’"
    },
    {
      "verse": "32",
      "text": "The officer was reading these words from the book of Isaiah:‘He was like a sheep that people were leading away to kill. He was like a lamb when they are cutting off its wool, but it makes no noise. In the same way, he did not say anything. ‘He was like a sheep that people were leading away to kill. He was like a lamb when they are cutting off its wool, but it makes no noise. In the same way, he did not say anything."
    },
    {
      "verse": "33",
      "text": "People did not respect him at all. They refused to judge him in a fair way. Nobody can say anything about his descendants, because his life on earth came to an end. ’ They refused to judge him in a fair way. Nobody can say anything about his descendants, because his life on earth came to an end. ’"
    },
    {
      "verse": "34",
      "text": "The officer said to Philip, ‘Please tell me who the prophet Isaiah wrote about. Was he writing about himself or about another person? ’"
    },
    {
      "verse": "35",
      "text": "Then Philip explained to the man the words that Isaiah had written. Then he went on to tell him the good news about Jesus."
    },
    {
      "verse": "36",
      "text": "As they were travelling along the road, they came to a place with some water. The man said to Philip, ‘Look! There is some water here. Please will you baptize me? Is there anything to stop you? ’["
    },
    {
      "verse": "37",
      "text": "Philip said to him, ‘I can baptize you if you really believe in Jesus. ’ The man said to Philip, ‘I do believe that Jesus Christ is the Son of God. ’]"
    },
    {
      "verse": "38",
      "text": "The officer said to the man who was driving the chariot, ‘Stop the chariot! ’ Then he went down with Philip into the water, and Philip baptized him."
    },
    {
      "verse": "39",
      "text": "They both came up out of the water again. Immediately the Lord's Holy Spirit took Philip away from that place. The officer did not see Philip again. He continued his journey and he was very happy."
    },
    {
      "verse": "40",
      "text": "Philip saw that he was now in Azotus. From there, he visited many towns and he told people the good news about Jesus. He did this as he went all the way to Caesarea."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "All this time, Saul was still speaking strongly against the disciples of the Lord Jesus. He wanted to kill all the believers. So he went to see the most important priest in Jerusalem."
    },
    {
      "verse": "2",
      "text": "Saul asked him, ‘Please will you write some letters for me? Then I can give one of these letters to the leader of each Jewish group in Damascus. That will give me authority to take hold of any believers that I find there. ’Saul wanted to find anyone who agreed with the Way of the Lord Jesus. Then he would tie them and bring them back to Jerusalem, whether they were men or they were women."
    },
    {
      "verse": "3",
      "text": "He travelled towards Damascus. He was very near the city when a bright light suddenly appeared. The light came from the sky, and it shone all around him."
    },
    {
      "verse": "4",
      "text": "Saul fell down onto the ground. He heard a voice which said to him, ‘Saul, Saul, why do you fight against me? ’"
    },
    {
      "verse": "5",
      "text": "Saul asked, ‘Lord, who are you? ’ He said, ‘I am Jesus. And you are fighting against me."
    },
    {
      "verse": "6",
      "text": "Now you must get up and go into the city. Someone there will tell you what you must do. ’"
    },
    {
      "verse": "7",
      "text": "The men who were travelling with Saul stood still. They could not say anything. They could hear that someone was speaking. But they could not see anyone."
    },
    {
      "verse": "8",
      "text": "Saul stood up. He opened his eyes, but he could not see anything. So the men who were with Saul held his hand. They led him into Damascus."
    },
    {
      "verse": "9",
      "text": "For three days, Saul could not see anything. During that time, he did not eat any food or drink anything."
    },
    {
      "verse": "10",
      "text": "There was a believer who lived in Damascus. His name was Ananias. God gave him a message in a vision. The Lord Jesus said to him, ‘Ananias! ’ Ananias answered, ‘Lord, I am here. ’"
    },
    {
      "verse": "11",
      "text": "Jesus said to Ananias, ‘Prepare yourself and go to Straight Street. A man called Judas lives on that street. Go to his house. When you get there, ask for a man from Tarsus who is called Saul. He is praying to God."
    },
    {
      "verse": "12",
      "text": "He has had a message from God in a vision. In his vision, he saw a man who is called Ananias come to him. He saw you put your hands on him so that he could see again. ’"
    },
    {
      "verse": "13",
      "text": "Ananias replied, ‘Lord, many people have told me about this man. He has done very bad things to your own people, the believers in Jerusalem."
    },
    {
      "verse": "14",
      "text": "Now he has come here to Damascus, and he has brought letters with him from the leaders of the priests. They have given him authority, so that he will take hold of everyone who believes in you. He will tie them and put them in prison. ’"
    },
    {
      "verse": "15",
      "text": "But the Lord said to Ananias, ‘Go now to Saul! I have chosen him to work for me. He will go to those who are not Jews and to their rulers. He will tell them about me. He will also tell the people of Israel about me."
    },
    {
      "verse": "16",
      "text": "I myself will tell him about the many troubles that he will have. He will have much pain on my behalf. ’"
    },
    {
      "verse": "17",
      "text": "So Ananias went to Judas's house and he went inside. He put his hands on Saul and he said to him, ‘Brother Saul, the Lord Jesus himself has sent me here to you. It was Jesus that you saw on the road when you were coming here to Damascus. He has sent me to you so that you will be able to see again. God will also fill you with his Holy Spirit. ’"
    },
    {
      "verse": "18",
      "text": "When Ananias said that, immediately something like bits of fish skin fell from Saul's eyes. Then Saul could see again. So he stood up and Ananias baptized him."
    },
    {
      "verse": "19",
      "text": "Then Saul ate some food and he became strong again. Saul stayed with the believers in Damascus for a few days."
    },
    {
      "verse": "20",
      "text": "He immediately went to the Jewish meeting places and he taught people about Jesus. He told them that Jesus is the Son of God."
    },
    {
      "verse": "21",
      "text": "All the people who heard what Saul said were very surprised. They said to each other, ‘This is the same man who caused much pain to the believers in Jerusalem. We are sure it is him! Now he has come here to Damascus to take hold of the believers and take them away to Jerusalem. He wants to make them stand in front of the leaders of the priests. ’"
    },
    {
      "verse": "22",
      "text": "But Saul became even more powerful when he taught the people. He showed very clearly that Jesus is God's Messiah. So the Jews who lived there in Damascus could not answer him."
    },
    {
      "verse": "23",
      "text": "After many days, the Jews met together. They decided that they would kill Saul."
    },
    {
      "verse": "24",
      "text": "But someone told Saul about this. The Jews carefully watched the gates of the city all day and all night. They wanted to catch Saul and to kill him."
    },
    {
      "verse": "25",
      "text": "But one night, Saul's friends helped him to leave the city secretly. They put him in a basket. Then they put him through a hole in the city wall. Then they let the basket go slowly down to the ground outside the city."
    },
    {
      "verse": "26",
      "text": "Saul returned to Jerusalem. He wanted to join the group of believers there. But they were all afraid of him. They did not believe that he had really become a disciple of Jesus."
    },
    {
      "verse": "27",
      "text": "But one of the believers who was called Barnabas helped Saul. He took Saul to meet the apostles. Barnabas then explained to the apostles what had happened to Saul. Barnabas said to them, ‘Saul saw the Lord when he was on his way to Damascus. The Lord spoke to him there. Then, while Saul was in Damascus, he bravely told people the message about Jesus. ’"
    },
    {
      "verse": "28",
      "text": "After that, Saul stayed with the apostles. He went everywhere in Jerusalem and he bravely taught people the message about the Lord Jesus."
    },
    {
      "verse": "29",
      "text": "Saul also talked with the Jews who spoke the Greek language. He argued with them about Jesus. As a result, they wanted to kill him."
    },
    {
      "verse": "30",
      "text": "The other believers heard about this. So they took Saul away to Caesarea. From there, they sent him to Tarsus."
    },
    {
      "verse": "31",
      "text": "By this time there were believers everywhere in Judea, Galilee and Samaria. For some time they had no troubles. The Holy Spirit helped them to become strong. So more people became believers, and they obeyed God in everything that they did."
    },
    {
      "verse": "32",
      "text": "Peter often travelled to many different places. One day he travelled to Lydda, and he went to see the believers there."
    },
    {
      "verse": "33",
      "text": "In Lydda, he met a man called Aeneas. Aeneas could not move his arms or his legs. He lay on his mat all the time. He had been on his mat for eight years."
    },
    {
      "verse": "34",
      "text": "Peter said to Aeneas, ‘Jesus Christ now makes you well again! So stand up and put away your mat. ’ Immediately Aeneas stood up."
    },
    {
      "verse": "35",
      "text": "Many people who lived in Lydda and Sharon saw Aeneas. They saw that he was now well and they believed in the Lord Jesus."
    },
    {
      "verse": "36",
      "text": "There was a woman called Tabitha who lived in Joppa. She was a believer. In the Greek language, her name was Dorcas, which means ‘deer’. She was always doing good things to help people. She gave poor people the things that they needed."
    },
    {
      "verse": "37",
      "text": "Dorcas became very ill and then she died. Women washed her body and they put it in a room upstairs."
    },
    {
      "verse": "38",
      "text": "Joppa was not very far from Lydda. The believers in Joppa heard that Peter was in Lydda. So they sent two men to go and to tell him, ‘Please hurry and come to Joppa. ’"
    },
    {
      "verse": "39",
      "text": "Peter then returned to Joppa with the two men. When he arrived at Dorcas's house, some women took him upstairs. Many widows were there and they were crying. They all stood there, near to Peter. They showed him the shirts and coats that Dorcas had made while she was still with them."
    },
    {
      "verse": "40",
      "text": "Peter sent all these women out of the room. He went down on his knees and he prayed to God. Then he turned his head towards the dead woman and he said, ‘Tabitha, stand up! ’ She opened her eyes. When she saw Peter, she sat up."
    },
    {
      "verse": "41",
      "text": "Peter held her hand and he helped her to stand up. Then he told the widows and all the believers to come into the room. He showed them that Dorcas was alive again."
    },
    {
      "verse": "42",
      "text": "People everywhere in Joppa heard what had happened. As a result, many more people believed in the Lord Jesus."
    },
    {
      "verse": "43",
      "text": "Peter stayed in Joppa for many days. He stayed with a man called Simon, who was a tanner."
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "There was a man who lived in Caesarea and his name was Cornelius. He was an officer in the Roman army. His group of soldiers was called ‘The Group from Italy’."
    },
    {
      "verse": "2",
      "text": "Cornelius was a good man. He and all his family served God faithfully. Cornelius prayed to God every day. He also gave money to help poor Jewish people."
    },
    {
      "verse": "3",
      "text": "One afternoon, at about three o'clock, Cornelius had a vision. He clearly saw one of God's angels. The angel came in and said to him, ‘Cornelius! ’"
    },
    {
      "verse": "4",
      "text": "Cornelius looked at the angel and he was afraid. He asked, ‘Master, why have you come to me? ’The angel answered, ‘God has heard your prayers. He knows about all the money that you give to poor people. This has pleased him. Now God is answering your prayers."
    },
    {
      "verse": "5",
      "text": "You must send some men to Joppa. They will find a man who is staying there. He is called Simon Peter. Your men must tell him to come here to Caesarea."
    },
    {
      "verse": "6",
      "text": "He is staying at the house of Simon the tanner. His house is near the sea. ’"
    },
    {
      "verse": "7",
      "text": "Then the angel who spoke to Cornelius went away. Cornelius told two of his servants and a soldier of his group to come to him. The soldier was one of those who served Cornelius. He was a good man who obeyed God."
    },
    {
      "verse": "8",
      "text": "Cornelius explained to these three men what the angel had said to him. Then he sent them to Joppa."
    },
    {
      "verse": "9",
      "text": "The next day, at about noon, Cornelius's men were coming near to Joppa. At this time, Peter went up on the roof of the house to pray to God."
    },
    {
      "verse": "10",
      "text": "He became hungry and he wanted to eat some food. While someone was preparing a meal for him, Peter had a special dream."
    },
    {
      "verse": "11",
      "text": "In a vision, he saw heaven open above him. Then he saw something like a large piece of cloth. Somebody held it at each of its four corners and let it come down to the ground."
    },
    {
      "verse": "12",
      "text": "Inside the cloth there were many different kinds of animals with four legs. There were also wild birds and snakes."
    },
    {
      "verse": "13",
      "text": "Then Peter heard a voice that said to him, ‘Peter, stand up and kill some of these animals. Then you can cook them and eat the meat. ’"
    },
    {
      "verse": "14",
      "text": "Peter answered, ‘No, Lord, I would certainly not do that. I have never eaten an animal that our Law says is unclean. ’"
    },
    {
      "verse": "15",
      "text": "Then, for the second time, the voice said to Peter, ‘God has made these animals good for people to eat. So you must not say that it is not right to eat them. ’"
    },
    {
      "verse": "16",
      "text": "All this happened three times. After that, the cloth immediately went back up into heaven."
    },
    {
      "verse": "17",
      "text": "Just then, Cornelius's men arrived there in Joppa. They found Simon's house. When they stopped at the gate of the house, Peter was still thinking about his dream and what it meant."
    },
    {
      "verse": "18",
      "text": "The men shouted out, ‘Is a man called Simon Peter staying here? ’"
    },
    {
      "verse": "19",
      "text": "While Peter was still thinking about his dream, the Holy Spirit said to him, ‘Simon, three men have arrived and they are looking for you."
    },
    {
      "verse": "20",
      "text": "Get up and go downstairs to meet them. I have sent these men to come to you. So you should go with them. Do not be afraid. ’"
    },
    {
      "verse": "21",
      "text": "Peter went downstairs and he said to the men, ‘I am the person that you are looking for. Why have you come here? ’"
    },
    {
      "verse": "22",
      "text": "The men answered him, ‘The Roman officer who is called Cornelius has sent us to you. He is a good man and he obeys God's Law. All the Jewish people respect him. An angel from God told him to send us to you with a message. Then we should bring you to Cornelius's house so that he could hear what you have to say. ’"
    },
    {
      "verse": "23",
      "text": "Then Peter said to the men, ‘Please come into the house and stay here with us tonight. ’The next day, Peter left Joppa to go to Caesarea with Cornelius's men. Some believers who lived in Joppa travelled with them."
    },
    {
      "verse": "24",
      "text": "The next day, Peter arrived in Caesarea. Cornelius was ready to meet Peter and the other men. He told his family and his special friends to come to his house. They were all waiting to meet Peter."
    },
    {
      "verse": "25",
      "text": "When Peter arrived at the house, Cornelius went out to meet him. He went down on his knees in front of Peter to worship him."
    },
    {
      "verse": "26",
      "text": "But Peter lifted Cornelius up from the ground and he said to him, ‘Stand up. I am only a man, like you are. ’"
    },
    {
      "verse": "27",
      "text": "Peter continued to talk to Cornelius and they went into the house. Peter saw that many people had come together there in the house."
    },
    {
      "verse": "28",
      "text": "He said to them, ‘You all know that we Jews do not become friends with Gentiles. Our Jewish laws do not let us visit the homes of Gentiles. But God has now shown me something different. I should not say about anyone that God will not accept them."
    },
    {
      "verse": "29",
      "text": "So when you asked me to come here, I was happy to come. I knew that it was right. So tell me now. Why did you ask me to come? ’"
    },
    {
      "verse": "30",
      "text": "Then Cornelius said, ‘Three days ago, I was in my house at this time of the day. It was three o'clock in the afternoon and I was praying to God. Suddenly, a man appeared and he stood in front of me. He was wearing bright clothes that shone."
    },
    {
      "verse": "31",
      "text": "The man said to me, “Cornelius, you have prayed to God and you have often given money to poor people. Now God wants to answer you."
    },
    {
      "verse": "32",
      "text": "So send some men to Joppa to fetch a man who is called Simon Peter. He is staying there at the house of Simon the tanner. His house is near the sea. ”"
    },
    {
      "verse": "33",
      "text": "So I sent some men immediately to bring you here. Thank you that you agreed to come. Now we are all here together, and God is with us. We are ready to listen to your message. Please tell us everything that the Lord God has told you to say. ’"
    },
    {
      "verse": "34",
      "text": "Then Peter said to them, ‘Now I understand that God accepts all people in the same way. God has shown me that this is true."
    },
    {
      "verse": "35",
      "text": "God accepts all people who worship him and who do the right things. It is not important to God which nation a person belongs to."
    },
    {
      "verse": "36",
      "text": "This is the message that God has sent to the people of Israel. He told us the good news about Jesus Christ, who is the Lord of all people. Because of Jesus, we can now come near to God again."
    },
    {
      "verse": "37",
      "text": "You know about the important things that have happened everywhere in Judea. These things began in Galilee after John spoke God's message to the people. He baptized those people who believed in God."
    },
    {
      "verse": "38",
      "text": "You know that God chose Jesus to do special work for him. He gave Jesus his Holy Spirit and helped him to do powerful things. Jesus came from the town of Nazareth. He travelled to many places and he did good things. The Devil had power over some people. But Jesus caused all those people to become well again. He could do those powerful things because God was with him."
    },
    {
      "verse": "39",
      "text": "We saw everything that Jesus did in Jerusalem and in all Judea. The leaders in Jerusalem fixed Jesus to a cross and they killed him."
    },
    {
      "verse": "40",
      "text": "But then, three days after that, God caused Jesus to become alive again. God caused him to appear to us."
    },
    {
      "verse": "41",
      "text": "Not all the people saw him. God chose us to be Jesus' apostles and we saw him. Now we are telling people about all these things. We ate and we drank with Jesus after he became alive again."
    },
    {
      "verse": "42",
      "text": "At that time, Jesus said to us, “Go and tell people the message about me. Tell them that God has given me authority to judge all people. I will judge those who are now alive. And I will judge those who have died. ” ’"
    },
    {
      "verse": "43",
      "text": "Then Peter said, ‘All of God's prophets spoke about Jesus as God's Messiah. They said that God would forgive everyone who believes in him. He would forgive them for their sins because of what Jesus, the Messiah, would do. ’"
    },
    {
      "verse": "44",
      "text": "While Peter was still speaking, the Holy Spirit came down on all the people who were listening to his message."
    },
    {
      "verse": "45",
      "text": "The Jewish believers who had come from Joppa with Peter were very surprised. They saw that God had now freely given his Holy Spirit to Gentiles."
    },
    {
      "verse": "46",
      "text": "They heard the new believers speaking in strange languages. They were also praising God. Then Peter said,"
    },
    {
      "verse": "47",
      "text": "‘God has clearly given his Holy Spirit to these people, in the same way that he gave him to us. So we should now baptize them with water. You surely agree that this is the right thing to do. ’"
    },
    {
      "verse": "48",
      "text": "So Peter told the Jewish believers to baptize the new believers. They spoke the name of Jesus Christ when they baptized them. After that, Cornelius asked Peter to stay with them for a few days."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "The apostles and the other believers in Judea heard that Gentiles had also believed the message from God."
    },
    {
      "verse": "2",
      "text": "Peter then returned from Caesarea and he arrived in Jerusalem. Some of the Jews there who were believers spoke against him. These Jews thought that all believers should be circumcised."
    },
    {
      "verse": "3",
      "text": "So they said to Peter, ‘You stayed in the house of men who were not circumcised. You even ate meals with them! ’"
    },
    {
      "verse": "4",
      "text": "Peter then began to explain everything that had happened. He said to them,"
    },
    {
      "verse": "5",
      "text": "‘I was staying in a house in the city of Joppa. One day, when I was praying, I had a special dream. In this vision, I saw something that came down from heaven. It was like a large piece of cloth. Somebody held it at each of its four corners and let it come down to the ground next to me."
    },
    {
      "verse": "6",
      "text": "I looked carefully at it. I saw that there were farm animals with four legs inside the cloth. There were also wild animals, snakes, and birds in it."
    },
    {
      "verse": "7",
      "text": "Then I heard a voice that said to me, “Peter, stand up and kill some of these animals. Then you can cook them and eat the meat. ”"
    },
    {
      "verse": "8",
      "text": "But I answered, “No, Lord, I would certainly not do that. I have never eaten an animal that our Law says is unclean. ”"
    },
    {
      "verse": "9",
      "text": "Then the voice spoke to me from heaven again. It said, “God has made these animals good for people to eat. So you must not say that it is not right to eat them. ”"
    },
    {
      "verse": "10",
      "text": "All this happened three times. After that, the cloth went back up into heaven again."
    },
    {
      "verse": "11",
      "text": "At that moment, three men from Caesarea arrived at the house where I was staying. Someone had sent these men to find me."
    },
    {
      "verse": "12",
      "text": "The Holy Spirit told me that I should go with them. He said that I should not be afraid. These six believers from Joppa also went with me to Caesarea. We all went into Cornelius's house."
    },
    {
      "verse": "13",
      "text": "Then Cornelius told us what had happened to him. He had seen an angel who appeared in his house and said to him, “Send some men to Joppa to fetch a man who is called Simon Peter."
    },
    {
      "verse": "14",
      "text": "He will come and speak to you. His message will tell you how God will save you and everyone else in your house. ”"
    },
    {
      "verse": "15",
      "text": "When I started to speak to Cornelius and his family, the Holy Spirit came down on them. It happened in the same way that he first came down on us at the beginning."
    },
    {
      "verse": "16",
      "text": "Then I remembered what the Lord Jesus had said to us: “John baptized people with water, but God will baptize you with his Holy Spirit. ”"
    },
    {
      "verse": "17",
      "text": "So we see that God gave these Gentiles his gift of the Holy Spirit. This is the same gift that he gave to us Jews who have believed in the Lord Jesus Christ. So I could never try to stop God. ’"
    },
    {
      "verse": "18",
      "text": "The Jewish believers heard what Peter said. They could not say anything more against him. Instead, they praised God and they said, ‘We now see that God has also let Gentiles have life with him. He will accept them if they stop doing bad things and turn to him. ’"
    },
    {
      "verse": "19",
      "text": "After the Jewish leaders had killed Stephen, the believers had a lot of trouble. The believers left Jerusalem and they went to many different places. Some of them went away as far as Phoenicia, Cyprus and Antioch. They told God's message to people in these places. But they only told the message to Jews."
    },
    {
      "verse": "20",
      "text": "Some of the believers were people who came from Cyprus and Cyrene. These men went to Antioch. There they told God's message to Gentiles, as well as to Jews. They told everyone the good news about the Lord Jesus."
    },
    {
      "verse": "21",
      "text": "The Lord God helped these men with his power. Very many people believed their message and they trusted in the Lord Jesus."
    },
    {
      "verse": "22",
      "text": "The believers in Jerusalem heard about what had happened in Antioch. So they decided to send Barnabas there."
    },
    {
      "verse": "23",
      "text": "Barnabas arrived in Antioch. He saw how God had been kind to the people there and helped them. Barnabas was happy about this. So he said to the new believers, ‘Continue to trust the Lord Jesus completely. ’"
    },
    {
      "verse": "24",
      "text": "Barnabas was a good man. The power of God's Holy Spirit was with him. He trusted God completely. Many people in Antioch believed in Jesus and joined the group of believers."
    },
    {
      "verse": "25",
      "text": "Then Barnabas went to Tarsus to look for Saul."
    },
    {
      "verse": "26",
      "text": "When Barnabas found him, he brought him back to Antioch. For one whole year, Barnabas and Saul met together with the group of believers there. They taught very many of them about Jesus. Antioch was the first place where the believers were called Christians."
    },
    {
      "verse": "27",
      "text": "During this time, some prophets travelled from Jerusalem to Antioch."
    },
    {
      "verse": "28",
      "text": "One of these men was called Agabus. The Holy Spirit gave him a message from God. He stood up and he said to the people there, ‘Soon people will be very hungry all over the world because there will be no food. ’ (That happened when Claudius ruled the Roman world. )"
    },
    {
      "verse": "29",
      "text": "The believers in Antioch wanted to help the other believers who lived in Judea. Each of them decided how much of their own money they could give."
    },
    {
      "verse": "30",
      "text": "Then they gave the money to Barnabas and Saul. Barnabas and Saul took this gift to the leaders of the believers in Jerusalem."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "At that time, King Herod took hold of some of the group of believers in Jerusalem. He wanted to cause them to suffer."
    },
    {
      "verse": "2",
      "text": "He sent his soldiers to cut off James's head. James was John's brother."
    },
    {
      "verse": "3",
      "text": "King Herod saw that the Jews were happy because he had killed James. So he sent his soldiers to take hold of Peter too. This happened during the Festival of Flat Bread."
    },
    {
      "verse": "4",
      "text": "After the soldiers caught Peter, they put him in prison. While he was in prison, four different groups of soldiers guarded him. There were four soldiers in each group. Herod wanted to judge Peter in front of everybody. After the Passover festival had finished, he would bring Peter out of the prison to do this."
    },
    {
      "verse": "5",
      "text": "So Herod kept Peter in prison. But during that time, the group of believers prayed that God would help Peter."
    },
    {
      "verse": "6",
      "text": "It was the night before King Herod wanted to bring Peter out of the prison and judge him. The soldiers had tied Peter to themselves with chains. So Peter was sleeping between two soldiers. Some other soldiers were guarding the doors of the prison."
    },
    {
      "verse": "7",
      "text": "Then, an angel from the Lord God suddenly appeared in the prison. A bright light shone in the room where Peter was sleeping. The angel touched Peter's shoulder so that Peter woke up. He said to Peter, ‘Hurry! Stand up! ’ Immediately the chains fell off Peter's hands."
    },
    {
      "verse": "8",
      "text": "Then the angel said to him, ‘Put on your clothes and your shoes. ’ Peter did what the angel told him to do. Then the angel said, ‘Now put on your coat and follow me. ’"
    },
    {
      "verse": "9",
      "text": "So Peter followed the angel out of the prison. He was not sure that all these things were really happening to him. He thought that he might be dreaming."
    },
    {
      "verse": "10",
      "text": "Peter and the angel walked past the first group of soldiers in the prison. Then they walked past the second group of soldiers. After that, they came to the big metal gate in the wall of the prison. The city was outside this gate. The gate opened by itself in front of them. So Peter and the angel went out of the prison through the gate. They walked together along one street and then, suddenly, the angel went away."
    },
    {
      "verse": "11",
      "text": "Then Peter understood what had happened. He said to himself, ‘Now I know that these things really have happened to me. The Lord God sent one of his angels to rescue me from Herod's power. The Jewish leaders wanted Herod to cause me to suffer. But God has saved me from those bad things. ’"
    },
    {
      "verse": "12",
      "text": "When Peter realized what God had done for him, he went to Mary's house. She was the mother of John Mark. Many people were meeting together in her house. They were praying to God."
    },
    {
      "verse": "13",
      "text": "Peter knocked on the outside door of the house. A servant girl called Rhoda came to the door."
    },
    {
      "verse": "14",
      "text": "She recognized Peter's voice and she was very happy. But she did not open the door. Instead, she ran back into the house and she said to all the people there, ‘Peter is standing outside the door! ’"
    },
    {
      "verse": "15",
      "text": "The people in the house said to her, ‘You are crazy. ’ But she told them again that Peter really was there. So then they said, ‘It is not him, but it is his angel. ’"
    },
    {
      "verse": "16",
      "text": "While all this was happening, Peter was still knocking at the door. Then someone went and opened the door. They were all very surprised when they saw him there."
    },
    {
      "verse": "17",
      "text": "Peter raised his hand towards them so that they would all be quiet. Then he explained to them how the Lord God had brought him out of the prison. He said to them, ‘Tell James and all the other believers what has happened to me. ’ Then he left the house and he went away to another place."
    },
    {
      "verse": "18",
      "text": "When morning arrived, there was a lot of trouble at the prison. The soldiers did not understand what had happened to Peter. After this happened, Herod left Judea. He went to Caesarea and he stayed there for some time."
    },
    {
      "verse": "19",
      "text": "When Herod knew about it, he said to the soldiers, ‘Go and look for Peter! ’ But they could not find him anywhere. Herod then asked the soldiers who guarded the prison some questions. They could not explain what had happened. So Herod commanded other soldiers to cut off their heads. After this happened, Herod left Judea. He went to Caesarea and he stayed there for some time."
    },
    {
      "verse": "20",
      "text": "At that time, King Herod was angry with the people who lived in Tyre and Sidon. A group of men from these cities went together to speak to Herod about the problem. A man called Blastus was an important servant in King Herod's house. The group of men said to Blastus, ‘Please help us when we speak to King Herod. ’ Then they went and they said to Herod, ‘Please stop being angry with our people. We want to be friends again. ’ They said this because they needed to buy food in King Herod's country."
    },
    {
      "verse": "21",
      "text": "Herod decided on which day he would meet with them. He put on his beautiful clothes and he sat in his special seat as king. Then he spoke his message to all the people."
    },
    {
      "verse": "22",
      "text": "When he spoke, the people shouted, ‘This is not a man who is speaking to us. This is the voice of a god! ’"
    },
    {
      "verse": "23",
      "text": "Herod let the people praise him, instead of God. So, immediately, an angel of the Lord God caused him to become very ill. Worms ate his body and later he died."
    },
    {
      "verse": "24",
      "text": "Everywhere that the believers went, they told people God's message. People heard the message in more and more places and many of them believed in Jesus."
    },
    {
      "verse": "25",
      "text": "Barnabas and Saul had gone to Jerusalem to help the believers there. They finished their work and then they returned to Antioch. They took John Mark with them."
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "There were some prophets among the group of believers in Antioch. They taught the other believers more about Jesus. Barnabas and Simeon were two of these men. (People also called Simeon ‘Niger’. ) There was Lucius who had lived in Cyrene. There was also Manaen who had lived together with the ruler Herod when they were children. And there was Saul."
    },
    {
      "verse": "2",
      "text": "One day, the believers were meeting together. They were praising the Lord God and they were praying. They also fasted for a time. During that time, the Holy Spirit said to them, ‘I have chosen Barnabas and Saul to do a special work for me. Let them go now and do it. ’"
    },
    {
      "verse": "3",
      "text": "The believers continued to pray and to fast. Then the leaders put their hands on Barnabas and Saul and they prayed for them. They sent them away to start this new work."
    },
    {
      "verse": "4",
      "text": "The Holy Spirit sent Barnabas and Saul away from Antioch. They travelled to the town of Seleucia, which is near the coast. From there they travelled on a ship to an island called Cyprus."
    },
    {
      "verse": "5",
      "text": "They arrived at a town called Salamis. There they went into the Jewish meeting places and they told the people God's message about Jesus. John Mark went with Barnabas and Saul to help them with their work."
    },
    {
      "verse": "6",
      "text": "They travelled across the whole island and they arrived at a town called Paphos. There they met a man called Bar-Jesus. He was a Jew. He used magic to do surprising things. He said that he was a prophet from God. But his messages were not true."
    },
    {
      "verse": "7",
      "text": "The ruler of Cyprus was called Sergius Paulus. Bar-Jesus was his friend. Sergius Paulus understood things well. So he asked Barnabas and Saul to come to him. He wanted them to tell him God's message."
    },
    {
      "verse": "8",
      "text": "Bar-Jesus was also called Elymas. That was his name in the Greek language. He did not like what Barnabas and Saul were saying. He did not want Sergius Paulus to believe in Jesus. So he tried to stop him."
    },
    {
      "verse": "9",
      "text": "Then God filled Saul with the power of his Holy Spirit. (Saul was also now called Paul. ) Paul looked straight at Elymas and he said,"
    },
    {
      "verse": "10",
      "text": "‘You are a servant of the Devil! You are against everything that is right. Your mind is full of lies and other bad things. You try to change the true message of the Lord and make it into lies. You must stop doing that!"
    },
    {
      "verse": "11",
      "text": "The Lord will now punish you. You will become blind for a time. You will not even see the light of the sun. ’When Paul said that, immediately something like a dark cloud covered Elymas's eyes. He could not find his own way. He needed someone to lead him by the hand."
    },
    {
      "verse": "12",
      "text": "Sergius Paulus saw what had happened to Elymas. He was very surprised about the things that Barnabas and Paul taught him about the Lord Jesus. And so he believed in Jesus."
    },
    {
      "verse": "13",
      "text": "Paul and the two other men got in a ship and they sailed away from Paphos. They arrived at a town called Perga, which is in the region called Pamphylia. John Mark left them there and he returned to Jerusalem."
    },
    {
      "verse": "14",
      "text": "Paul and Barnabas left Perga, and they went to a town called Antioch in Pisidia. On the Jewish day of rest, they went into the meeting place and they sat down."
    },
    {
      "verse": "15",
      "text": "Someone read aloud some words from the Bible. They read from God's Law and from the messages of God's prophets. After this, the leaders of the Jewish meeting place passed a note to Paul and Barnabas. The note said, ‘Friends, do you have a message that will help the people? If you do, please speak now. ’"
    },
    {
      "verse": "16",
      "text": "So Paul stood up. He raised his hand towards the people so that they would listen to him. Then he said to them, ‘Some of you are Jews, like us. Some of you are Gentiles who now worship our God. All of you, listen carefully to me."
    },
    {
      "verse": "17",
      "text": "The God of the people of Israel chose our ancestors to be his people. While they lived in Egypt, God caused his people to become a very large group. They lived as foreign people in Egypt. But God used his great power to bring them out from that country."
    },
    {
      "verse": "18",
      "text": "The people of Israel did not obey God. But God took care of them in the wilderness for 40 years."
    },
    {
      "verse": "19",
      "text": "He destroyed seven nations of people who lived in the land of Canaan. God gave their land to his own people so that they could live there."
    },
    {
      "verse": "20",
      "text": "years. After this, God gave to his people leaders who were called judges. They ruled Israel until the time when God's prophet Samuel was alive."
    },
    {
      "verse": "21",
      "text": "Then the people of Israel asked Samuel to choose a king for them. So God gave Saul to them as their king. Saul was the son of Kish and he was from the tribe of Benjamin. He ruled Israel for 40 years."
    },
    {
      "verse": "22",
      "text": "Then God removed Saul as king. He caused David to be their king instead. God said this about David: “I have watched David, the son of Jesse. He does things that make me happy. I know that he will do everything that I want. ”"
    },
    {
      "verse": "23",
      "text": "God promised to send to the people of Israel someone who would save us. Jesus is the man that God sent to save us. He is a descendant of King David."
    },
    {
      "verse": "24",
      "text": "Before Jesus began his work in this world, John spoke a message to all the people of Israel. He told people to stop doing wrong things and to turn to God. Then he would baptize them."
    },
    {
      "verse": "25",
      "text": "When John had almost finished his work, he said to the people, “Perhaps you think that I am the special man that God will send. I am not that man. But listen! That man will come soon. I am not good enough even to undo his shoes for him. ” ’"
    },
    {
      "verse": "26",
      "text": "Paul then said, ‘I speak to all you people here. Some of you, like us, have Abraham as your ancestor. Some of you are Gentiles who now worship our God. God has sent this message to all of us. It tells us how he will save us."
    },
    {
      "verse": "27",
      "text": "The people who were living in Jerusalem, and their leaders, did not understand about Jesus. They did not know that he was God's special man. Every Jewish day of rest, someone reads aloud the messages of God's prophets. But the people in Jerusalem did not understand. Instead, they said that Jesus had done bad things. They said that he should die. In that way, they caused the message of the prophets to become true."
    },
    {
      "verse": "28",
      "text": "The Jewish leaders could not find any reason to kill Jesus for what he had done. But they continued to say to Pilate, “Your soldiers must kill him. ”"
    },
    {
      "verse": "29",
      "text": "When the soldiers did that, it happened just like the prophets had written about him long ago. After that, some of Jesus' disciples took him down from the cross where he had died. They took his body and they buried it."
    },
    {
      "verse": "30",
      "text": "But after Jesus died, God caused him to become alive again."
    },
    {
      "verse": "31",
      "text": "For many days after this, Jesus appeared to his disciples. The people who had earlier travelled with him from Galilee to Jerusalem saw him. They are now telling the people of Israel all about it."
    },
    {
      "verse": "32",
      "text": "So we have come here to tell you this good news. God promised our ancestors that he would do these great things for his people. “You are my Son. Today, I have become your Father. ”"
    },
    {
      "verse": "33",
      "text": "Now he has done these things for us who are alive today. He has raised up Jesus to live again. We can read about this in the second Psalm. God says, “You are my Son. Today, I have become your Father. ”"
    },
    {
      "verse": "34",
      "text": "God caused Jesus to live again so that nothing would destroy his body. He will not die again. This is what God said to our ancestors:“I will surely help you with good things, just like I promised to King David. ” “I will surely help you with good things, just like I promised to King David. ”"
    },
    {
      "verse": "35",
      "text": "God also says this in another Psalm:“Your servant who loves you will not remain dead. You will not let anything destroy the body of your Holy One. ” “Your servant who loves you will not remain dead. You will not let anything destroy the body of your Holy One. ”"
    },
    {
      "verse": "36",
      "text": "While David was alive, he served God as God wanted him to do. Then he died and men buried him next to his ancestors. So worms destroyed David's body."
    },
    {
      "verse": "37",
      "text": "But as for Jesus, God caused him to become alive again. He did not die again and nothing destroyed his body."
    },
    {
      "verse": "38",
      "text": "My friends, I want all of you to know this. God forgives us for the bad things that we have done. He does this because of what Jesus did. That is my message to you."
    },
    {
      "verse": "39",
      "text": "God can cause anyone to become right with him. If you believe in Jesus, God will make you free from your sins. God's Law that he gave to Moses cannot do this for you. That Law cannot make you free, even if you obey all of it."
    },
    {
      "verse": "40",
      "text": "Be careful then! Remember what God's prophets spoke about long ago. Do not let that happen to you. This is what one of them wrote:"
    },
    {
      "verse": "41",
      "text": "“Listen to me, you people who laugh at God! You will be surprised at the great things that I do. And then you will die. I am working now, while you are still alive. But still you will not believe what is true. Even if someone explains everything to you, you will never believe. ” ’ You will be surprised at the great things that I do. And then you will die. I am working now, while you are still alive. But still you will not believe what is true. Even if someone explains everything to you, you will never believe. ” ’"
    },
    {
      "verse": "42",
      "text": "After Paul spoke this message, he and Barnabas were leaving the meeting place. The people there said to them, ‘Please return on our next day of rest. Then you can tell us more about what you have already told us. ’"
    },
    {
      "verse": "43",
      "text": "When the meeting finished, many people followed Paul and Barnabas. Some of them were Jews. Others were Gentiles who now worshipped God. Paul and Barnabas said to them, ‘God has been very kind to you. You should continue to trust him. ’"
    },
    {
      "verse": "44",
      "text": "On the next Jewish day of rest, almost everyone in the town came together to hear the Lord God's message."
    },
    {
      "verse": "45",
      "text": "But when some Jews saw the crowds of people, they became angry. They were very jealous because the people listened to Paul and Barnabas. They said that Paul was teaching wrong things. They also said bad things against him."
    },
    {
      "verse": "46",
      "text": "But Paul and Barnabas were not afraid of them. They said to them, ‘It was right that we first tell you who are Jews the message from God. But now you say that God's message is not true. You have shown that you do not deserve true life with God. So we will leave you now. We will go and tell this message to the Gentiles."
    },
    {
      "verse": "47",
      "text": "The Lord God has also told us to do this. He said:“I have chosen you to be like a light to the Gentiles. You must go to people everywhere in the world. You must tell them how God wants to save them. ” ’ “I have chosen you to be like a light to the Gentiles. You must go to people everywhere in the world. You must tell them how God wants to save them. ” ’"
    },
    {
      "verse": "48",
      "text": "When the Gentiles there heard this, they were very happy. They thanked God for the message about the Lord Jesus. Many people believed in Jesus. They were the people that God had chosen to have true life with him."
    },
    {
      "verse": "49",
      "text": "Many people in that part of the country heard the message about the Lord Jesus."
    },
    {
      "verse": "50",
      "text": "But the Jewish leaders spoke to the important men in the city. They also spoke to some rich women who worshipped God. The Jewish leaders told them bad things about Paul and Barnabas. So these important people started to speak against Paul and Barnabas. They caused Paul and Barnabas to leave that region."
    },
    {
      "verse": "51",
      "text": "So Paul and Barnabas cleaned the dirt of that place off their feet. This showed that the people in that town had done a bad thing. Paul and Barnabas then travelled to a town called Iconium."
    },
    {
      "verse": "52",
      "text": "The believers in Antioch continued to be very happy. The Holy Spirit completely filled them."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "When Paul and Barnabas arrived in Iconium, they did the same as they had done before. They went to the Jewish meeting place and they spoke God's message there. They spoke very clearly, so that many Jews and Gentiles believed in Jesus."
    },
    {
      "verse": "2",
      "text": "But some of the Jews refused to believe God's message. They told the Gentiles that they too should not believe it. The Jews put bad thoughts into the minds of the Gentiles so that they became angry against the believers."
    },
    {
      "verse": "3",
      "text": "So Paul and Barnabas stayed in Iconium for a long time. They were not afraid to tell people the message about the Lord Jesus. The Lord gave them power to do miracles. These showed the people that God was with Paul and Barnabas and that their message was true. They taught that God saves people because he is very kind."
    },
    {
      "verse": "4",
      "text": "The people in the city did not agree with each other. Some of them believed the message from the apostles, Paul and Barnabas. But some people agreed with the Jews who did not believe their message."
    },
    {
      "verse": "5",
      "text": "Some of the Jews and the Gentiles met with their leaders. They decided to do bad things to Paul and Barnabas. They wanted to throw stones at them and kill them."
    },
    {
      "verse": "6",
      "text": "Paul and Barnabas heard that these people wanted to hurt them. So they left Iconium quickly and they went to Lystra and Derbe, and other places near there. These cities were in the region called Lycaonia."
    },
    {
      "verse": "7",
      "text": "In all these places, they continued to tell people the good news about Jesus."
    },
    {
      "verse": "8",
      "text": "There was a man who lived in Lystra. His feet had been weak since he was born. So he had never been able to walk."
    },
    {
      "verse": "9",
      "text": "While Paul was speaking God's message, this man listened to him. Paul looked at him carefully. He could see that the man believed in Jesus. The man believed that God could make him well."
    },
    {
      "verse": "10",
      "text": "So Paul said to him loudly, ‘Stand up on your feet! ’ Immediately the man jumped up and he began to walk about."
    },
    {
      "verse": "11",
      "text": "The crowd saw what Paul had done. They began to shout in their own language that the people of Lycaonia spoke. ‘The gods have become like men and they have come down from the sky to us, ’ they said."
    },
    {
      "verse": "12",
      "text": "They called Barnabas ‘Zeus’. They called Paul ‘Hermes’, because he was the one who spoke the message to the people."
    },
    {
      "verse": "13",
      "text": "The temple of Zeus was very near to the town. The priest who worked there brought bulls and flowers to the town gate. Many people had come together in that place. The priest and the crowd wanted to kill the animals as sacrifices to Paul and Barnabas."
    },
    {
      "verse": "14",
      "text": "Paul and Barnabas heard what the people wanted to do. So they tore their own clothes to show that they were very upset. They ran into the middle of the crowd,"
    },
    {
      "verse": "15",
      "text": "and they shouted, ‘Stop! You people should not do this. We are only men like you. We are not gods. We came here to tell you some good news about the great God. You must stop worshipping these gods who are really nothing. Instead worship the God who lives. He made the sky, the earth and the sea. He also made everything that is in them."
    },
    {
      "verse": "16",
      "text": "In past times, God let people everywhere do what they wanted to do."
    },
    {
      "verse": "17",
      "text": "But God has showed everybody very clearly what he is like. He has showed you that he is kind. He causes the rain to fall from the sky. He causes the plants to give you food at the right time each year. He gives you plenty of food to eat. In these ways he makes you very happy. ’"
    },
    {
      "verse": "18",
      "text": "Even when Paul had said all this, the people still wanted to offer sacrifices to him and Barnabas. Finally Paul and Barnabas were able to stop them."
    },
    {
      "verse": "19",
      "text": "Then some Jews arrived there in Lystra. They had travelled from Antioch and from Iconium. They talked to the people, so that they turned against Paul. Then these Jews threw stones at Paul to kill him. They pulled his body to outside the town. They thought that he was dead."
    },
    {
      "verse": "20",
      "text": "But some believers came out from the town and they stood around Paul. Then Paul stood up! He went back with them into the town. The next day, Paul and Barnabas left Lystra and they went to Derbe."
    },
    {
      "verse": "21",
      "text": "While they were there, they told people the good news about Jesus. Many people in Derbe became believers. After that, Paul and Barnabas returned to Lystra. From there they went back to Iconium. Then they returned to Antioch in the region of Pisidia."
    },
    {
      "verse": "22",
      "text": "In all these towns, they taught the believers to be strong. They said to them, ‘Continue to trust in the Lord Jesus! All believers will have trouble at different times. That will continue to happen in our lives. But one day we will go into the kingdom of God where he rules. ’"
    },
    {
      "verse": "23",
      "text": "Paul and Barnabas chose leaders for each group of believers in these places. They fasted and they prayed to God for some time about this. They asked the Lord Jesus to help these leaders who trusted in him."
    },
    {
      "verse": "24",
      "text": "Then Paul and Barnabas travelled through Pisidia. They arrived in Pamphylia."
    },
    {
      "verse": "25",
      "text": "They spoke God's message to the people in Perga. Then they went down to the coast, to the town of Attalia."
    },
    {
      "verse": "26",
      "text": "From there they went in a ship back to Antioch. That was the place where the believers had chosen them to do God's work. They had asked God to help Paul and Barnabas in this work. Now Paul and Barnabas had finished this work and they had returned home."
    },
    {
      "verse": "27",
      "text": "When they arrived, they sent a message to the group of believers in Antioch. When all the believers had come together, Paul and Barnabas told them about their journey. They told the believers about everything that God had helped them to do. They said, ‘God has made it possible now for Gentiles to believe in Jesus. ’"
    },
    {
      "verse": "28",
      "text": "Paul and Barnabas stayed there with the believers in Antioch for a long time."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "Some men arrived in Antioch from Judea. They began to teach the believers there who were not Jews. They said to them, ‘God cannot save you unless someone circumcises you. This is in the Law that God gave to Moses. ’"
    },
    {
      "verse": "2",
      "text": "Paul and Barnabas did not agree with these men. They argued strongly against them. As a result, the believers in Antioch decided what to do. They chose Paul, Barnabas and some of the other believers to go to Jerusalem. They should go to meet with the apostles and the other leaders of the believers. The leaders should decide who was right in this quarrel."
    },
    {
      "verse": "3",
      "text": "The group of believers at Antioch sent Paul, Barnabas and the other men on their way. They travelled through Phoenicia and Samaria. They spoke to the believers in those places. They told them, ‘Gentiles are also turning to God and they are believing in Jesus. ’ The believers were all very happy to hear this news."
    },
    {
      "verse": "4",
      "text": "When Paul, Barnabas and the other men arrived in Jerusalem, they met with the believers there. The apostles, the other leaders and the whole group of believers were happy to see them. Paul and Barnabas told them about everything that God had helped them to do."
    },
    {
      "verse": "5",
      "text": "Some Jewish believers were there who also belonged to the Pharisees' group. They stood up and they said, ‘We must circumcise Gentiles when they become believers. We must tell them to obey all the Law that God gave to Moses. ’"
    },
    {
      "verse": "6",
      "text": "So the apostles and the other leaders of the believers met to talk about this problem."
    },
    {
      "verse": "7",
      "text": "After they had all talked about this problem for a long time, Peter stood up to speak. He said, ‘My friends, you know that, a long time ago, God chose me from among all you leaders. He wanted me to teach Gentiles the good news about Jesus. God wanted them to hear his message and to believe in Jesus."
    },
    {
      "verse": "8",
      "text": "God knows what people truly believe. He showed clearly that he accepts Gentile believers as his people. He gave his Holy Spirit to them in the same way that he did for us."
    },
    {
      "verse": "9",
      "text": "He made no difference between them and us. When they believed in Jesus, he saved them. He made them clean inside."
    },
    {
      "verse": "10",
      "text": "So do not say that God has done a wrong thing. God has shown us that he accepts Gentiles when they believe in Jesus. If you make the Gentile believers obey the Law of Moses, that is like a heavy weight on their necks. Even we Jews and our ancestors could not carry that heavy weight."
    },
    {
      "verse": "11",
      "text": "God saves us who are Jews when we believe in Jesus. It is not because we obey the Law of Moses. It is because the Lord Jesus is kind to us. God saves Gentiles in the same way, when they believe in Jesus. ’"
    },
    {
      "verse": "12",
      "text": "After Peter said this everybody in the group was quiet. Then Barnabas and Paul spoke to them. They said, ‘God helped us to do great miracles among the Gentiles. These showed that God was with us. ’"
    },
    {
      "verse": "13",
      "text": "When they had finished their report, James spoke to the group. He said, ‘Listen to me, my friends."
    },
    {
      "verse": "14",
      "text": "Simon Peter has just described to us what happened first with the Gentile believers. He explained how God chose some of them to belong to him as his own people."
    },
    {
      "verse": "15",
      "text": "The message of God's prophets agrees completely with this. They wrote long ago:"
    },
    {
      "verse": "16",
      "text": "The Lord God said, “Later I will return. At that time I will make David's kingdom strong again. It has become like a house that has fallen down, but I will build it again so that it is strong. “Later I will return. At that time I will make David's kingdom strong again. It has become like a house that has fallen down, but I will build it again so that it is strong."
    },
    {
      "verse": "17",
      "text": "Then many other people will want to know me, the Lord God. Those are the Gentiles that I have chosen to belong to me. I, the Lord God, say this, and I will make these things happen. Those are the Gentiles that I have chosen to belong to me. I, the Lord God, say this, and I will make these things happen."
    },
    {
      "verse": "18",
      "text": "Long ago I caused people to know all these things. ” ’"
    },
    {
      "verse": "19",
      "text": "James then said, ‘So this is what I have decided about this problem. Many Gentiles are now turning to God as believers. We should not make it difficult for them."
    },
    {
      "verse": "20",
      "text": "Instead of that, we should write a letter to tell them how to live as believers. We should say to them, “Do not eat any food which people have given to their idols. That food has become unclean. Do not have sex with anyone that you are not married to. If people have strangled an animal to kill it, do not eat its meat. Do not eat anything that still has blood in it. ”"
    },
    {
      "verse": "21",
      "text": "These rules are important, because people have known the Law of Moses for a very long time. On every Jewish day of rest, someone teaches us about the Law in our Jewish meeting places in every city. ’"
    },
    {
      "verse": "22",
      "text": "The whole group of believers agreed with what James said. So the apostles and the other leaders decided to choose some men from among the group of believers. These men would go to Antioch with Paul and Barnabas. They chose Silas and Judas, who was also called Barsabbas. The believers all respected these men as leaders."
    },
    {
      "verse": "23",
      "text": "This is the letter that they sent with those men:‘We, the apostles and leaders of the believers here say “hello” to you, our friends who also believe in Jesus. We say “hello” to all of you Gentile believers who live in Antioch, Syria and Cilicia. ‘We, the apostles and leaders of the believers here say “hello” to you, our friends who also believe in Jesus. We say “hello” to all of you Gentile believers who live in Antioch, Syria and Cilicia."
    },
    {
      "verse": "24",
      "text": "We have heard that some men from our group have confused your thoughts. These men came to you and they taught you without our authority. The things that they said were not right and they have upset you."
    },
    {
      "verse": "25",
      "text": "So now we have all met together. We have agreed what to do about this problem. We have chosen some men to bring this message to you. They will travel with our good friends, Barnabas and Paul."
    },
    {
      "verse": "26",
      "text": "These two men have worked as servants of the Lord Jesus Christ. Because of that, they have almost lost their lives."
    },
    {
      "verse": "27",
      "text": "So we are also sending Judas and Silas to you. They will tell you the same things that we have written in this letter."
    },
    {
      "verse": "28",
      "text": "The Holy Spirit has shown us what we should do. We also think that this is the right thing to do. We do not want to put a heavy weight on you. So these are the only rules that we want you to obey:"
    },
    {
      "verse": "29",
      "text": "Do not eat any food that people have given to their idols. Do not eat anything that still has blood in it. If people have strangled an animal to kill it, do not eat its meat. Do not have sex with anyone that you are not married to. If you obey these rules, you will do well. Goodbye. ’"
    },
    {
      "verse": "30",
      "text": "So the believers in Jerusalem sent these four men to go to Antioch. When they arrived there, they told the group of believers to meet together. When they all met, Silas and Judas gave them the letter."
    },
    {
      "verse": "31",
      "text": "When the believers in Antioch read the letter, they were very happy. They said, ‘This message will help us very much. ’"
    },
    {
      "verse": "32",
      "text": "Judas and Silas were both prophets. They spoke a message from God to the believers there. They spoke for a long time to help the believers and to make them strong."
    },
    {
      "verse": "33",
      "text": "Judas and Silas remained in Antioch for some time. Then the group of believers sent them back to Jerusalem. The believers prayed that God would help them and take care of them."
    },
    {
      "verse": "34",
      "text": "[But Silas decided to stay there. ]"
    },
    {
      "verse": "35",
      "text": "Paul and Barnabas remained in Antioch for a longer time. Together with many other believers, they taught the people, and they spoke the message about the Lord Jesus."
    },
    {
      "verse": "36",
      "text": "After some time, Paul said to Barnabas, ‘We should go back to the towns where we already spoke the message about the Lord Jesus. Then we can visit the believers in all those places. We can see if they are doing well. ’"
    },
    {
      "verse": "37",
      "text": "Barnabas agreed and he wanted to take John Mark with them."
    },
    {
      "verse": "38",
      "text": "But Paul did not think that this was right. He said to Barnabas, ‘John Mark did not remain with us until we had finished our work. He left us when we were in Pamphylia. ’"
    },
    {
      "verse": "39",
      "text": "Paul and Barnabas argued strongly about this. They could not agree, so they went in different directions. Barnabas took John Mark with him and they sailed to Cyprus."
    },
    {
      "verse": "40",
      "text": "Paul chose Silas to go with him. The believers in Antioch asked the Lord God to take care of Paul and Silas."
    },
    {
      "verse": "41",
      "text": "They travelled through Syria and Cilicia. Paul taught the believers in those regions. He helped them to be strong and to trust Jesus."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "Paul travelled to Derbe and then he arrived in Lystra. A man called Timothy lived in Lystra. He was a believer. His mother was a Jew who had become a believer in Jesus. But Timothy's father was a Gentile who came from Greece."
    },
    {
      "verse": "2",
      "text": "All the believers in Lystra and Iconium said good things about Timothy."
    },
    {
      "verse": "3",
      "text": "Paul wanted Timothy to travel with him to different places. All the Jews in that region knew that Timothy's father was a Gentile. So Paul circumcised Timothy, so that the Jews would accept him."
    },
    {
      "verse": "4",
      "text": "Paul, Silas and Timothy travelled through many towns. In each place, they told the believers the things that the apostles and the other leaders in Jerusalem had decided. They told the believers to obey those rules."
    },
    {
      "verse": "5",
      "text": "In this way, the groups of believers in those towns became stronger. They trusted Jesus more. More and more people joined the groups of believers every day."
    },
    {
      "verse": "6",
      "text": "Paul and his friends wanted to go to the region of Asia to speak God's message. But the Holy Spirit stopped them from doing this. So they travelled through the regions of Phrygia and Galatia."
    },
    {
      "verse": "7",
      "text": "Then they arrived at the edge of the region of Mysia. They wanted to go from there into the region of Bithynia. But the Holy Spirit of Jesus stopped them from going there too."
    },
    {
      "verse": "8",
      "text": "So they went quickly through Mysia and they arrived at the city of Troas, on the coast."
    },
    {
      "verse": "9",
      "text": "During that night, Paul had a vision. In the vision, he saw a man from the region called Macedonia. The man stood there and he said to Paul, ‘Please, please come across the sea to Macedonia and help us. ’"
    },
    {
      "verse": "10",
      "text": "After Paul's vision, we immediately prepared ourselves for the journey to Macedonia. We decided that God was telling us to go there. He wanted us to tell the people there the good news about Jesus."
    },
    {
      "verse": "11",
      "text": "We got in a ship at Troas and we sailed across the sea. We went across to an island called Samothrace. The next day, we continued our journey to a port called Neapolis."
    },
    {
      "verse": "12",
      "text": "We then travelled across the land to Philippi, the most important city in the region of Macedonia. The Romans ruled Philippi and many Roman people lived there. We stayed there for a few days."
    },
    {
      "verse": "13",
      "text": "On the Jewish day of rest, we went out of the city gate. We went down to the edge of the river. We thought that the Jews might have a special meeting place there. We thought that they would meet there to pray. We found a group of women who were meeting there. So we sat down and we talked to them."
    },
    {
      "verse": "14",
      "text": "One of the women who listened to us was called Lydia. She was from the city of Thyatira. She bought and sold expensive dark red cloth. She was a Gentile woman who now worshipped God. The Lord helped her to understand Paul's message. So she believed the things that he said."
    },
    {
      "verse": "15",
      "text": "Then Paul and Silas baptized Lydia and the other people who lived in her house. After this, Lydia asked us to go to her house. She said to us, ‘If you think that I really believe in the Lord Jesus, then please stay in my house. ’ We agreed to go and to stay there."
    },
    {
      "verse": "16",
      "text": "One day, we were going to the place where people prayed to God. On the way there, we met a slave girl. A bad spirit was living inside her. This spirit told her what would happen soon. People gave her masters a lot of money when she told them about these future things."
    },
    {
      "verse": "17",
      "text": "She followed Paul and all of us. She was shouting, ‘These men are servants of the powerful God who is over all! They are telling you how God can save you! ’"
    },
    {
      "verse": "18",
      "text": "The slave girl continued to do this for many days. After some time, Paul became angry. So he turned round and he said to the bad spirit, ‘I am using the authority of Jesus Christ! I command you to leave this woman! ’ When Paul said that, the spirit left her immediately."
    },
    {
      "verse": "19",
      "text": "Her masters now knew that the girl could not get money for them any more. So they took hold of Paul and Silas and they pulled them to the market place of the city. They took them to stand in front of the leaders of the city."
    },
    {
      "verse": "20",
      "text": "They asked the important officers to judge them. They said, ‘These men are Jews. They are causing much trouble in our city."
    },
    {
      "verse": "21",
      "text": "They are teaching people to obey strange ideas. We are Roman people. We cannot agree with these laws. They are not right for us to do. ’"
    },
    {
      "verse": "22",
      "text": "A lot of people quickly came together there. They started to attack Paul and Silas. So the important officers said to their soldiers, ‘Tear the clothes off Paul and Silas. Then hit them with sticks! ’"
    },
    {
      "verse": "23",
      "text": "The soldiers hit Paul and Silas many times. Then they took hold of them and they pushed them into the prison. The officers said to the prison guard, ‘Lock the prison door carefully so that these men cannot get free. ’"
    },
    {
      "verse": "24",
      "text": "The prison guard did what he had been told to do. He put Paul and Silas in a room in the middle of the prison. He put their feet between big heavy pieces of wood so that they could not move their legs."
    },
    {
      "verse": "25",
      "text": "At midnight, Paul and Silas were praying. They were also singing songs to praise God. The other people in the prison were listening to them."
    },
    {
      "verse": "26",
      "text": "The ground under the prison suddenly shook strongly. Immediately, all the prison doors opened. The chains that held the people in the prison all fell off."
    },
    {
      "verse": "27",
      "text": "The prison guard woke up. He saw that the prison doors were open. He thought that all the people in the prison had become free. He decided that he should kill himself. So he pulled out his sword."
    },
    {
      "verse": "28",
      "text": "Paul shouted very loudly to him, ‘Do not hurt yourself! We are all still in here! ’"
    },
    {
      "verse": "29",
      "text": "The guard said, ‘Bring me some lights. ’ Then he ran to the prison room where Paul and Silas were. He was very frightened. He went down on his knees in front of them."
    },
    {
      "verse": "30",
      "text": "Then he led Paul and Silas out of the prison. He said to them, ‘Masters, what must I do so that God will save me? Tell me! ’"
    },
    {
      "verse": "31",
      "text": "Paul and Silas said to him, ‘Believe in the Lord Jesus and then God will save you. He will save you and the people who live in your house, if they believe too. ’"
    },
    {
      "verse": "32",
      "text": "Then Paul and Silas went to the guard's house. They spoke God's message about the Lord Jesus to him and to all the people in his house."
    },
    {
      "verse": "33",
      "text": "In the middle of the night, the man took care of them. He washed their bodies where the soldiers had hurt them. Immediately after this, Paul and Silas baptized the man and his whole family."
    },
    {
      "verse": "34",
      "text": "The man gave them some food to eat in his house. The guard and all his family were very happy because now they believed in God."
    },
    {
      "verse": "35",
      "text": "The next morning, the important officers sent their police to the prison with a message for the guard. They told him, ‘Let those men go free. ’"
    },
    {
      "verse": "36",
      "text": "The guard went to Paul and he told him, ‘The city officers have sent a message to me. They said, “Let Paul and Silas go free. ” So now you can leave the prison. Nobody will hurt you any more. ’"
    },
    {
      "verse": "37",
      "text": "But Paul spoke to the police who had brought the message. He said, ‘The city officers did not find that we had done anything wrong. But they commanded their soldiers to hit us with sticks in front of everybody. We are citizens of Rome but they still did this to us. They even put us into prison. Now they want us to leave the prison and go away. They want to send us away secretly. We will not agree! The Roman officers must come here to the prison themselves. Then they must lead us out for everyone to see. ’"
    },
    {
      "verse": "38",
      "text": "The police returned to the city officers. They told them what Paul had said. The officers now understood that Paul and Silas were citizens of Rome. This made them very afraid."
    },
    {
      "verse": "39",
      "text": "So they went to see Paul and Silas in the prison. They told Paul and Silas that they were very sorry. Then they led Paul and Silas out of the prison. They asked them to leave the city."
    },
    {
      "verse": "40",
      "text": "After Paul and Silas left the prison, they went to Lydia's house. There they met the other believers. They spoke to the believers to make them strong. Then Paul and Silas left Philippi."
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "Paul and his friends continued their journey. They went through the two towns called Amphipolis and Apollonia. Then they arrived in the city of Thessalonica. There was a Jewish meeting place there."
    },
    {
      "verse": "2",
      "text": "Paul went to the meeting place, as he usually did on a Jewish day of rest. On three rest days, he spoke God's message to the people there. He read from the Bible and he explained what it meant."
    },
    {
      "verse": "3",
      "text": "He told the people what was true about God's Messiah. He used the Bible to show them clearly that the Messiah had to suffer and die. He also showed them that the Messiah had to become alive again. Paul said to them, ‘I have been telling you about Jesus. He is the Messiah that God has sent to us. ’"
    },
    {
      "verse": "4",
      "text": "Some of the Jews believed Paul's message. They joined the group with Paul and Silas. A large number of Greek people who now worshipped God also joined this group. Many important women in the city also believed and they joined the group."
    },
    {
      "verse": "5",
      "text": "Some other Jews in the city were jealous of Paul and Silas, because people believed their message. So they went to the city's market place and they found some bad men there. These men often caused trouble in the city. Now the Jews brought these men to come together with them in an angry crowd. This crowd made a lot of noise and trouble in the streets of the city. They went to Jason's house and they broke down his door. They wanted to find Paul and Silas. They wanted to bring them out of the house to the crowd."
    },
    {
      "verse": "6",
      "text": "But they did not find Paul and Silas there. So they took hold of Jason and some other believers. They pulled them out of the house. They made them go and stand in front of the important officers of the city. They shouted, ‘These men have caused much trouble everywhere. Now they have come to our city."
    },
    {
      "verse": "7",
      "text": "Jason has let them stay in his house. They speak against the laws that Caesar has given to us. They say that there is another king. This other king is called Jesus. ’"
    },
    {
      "verse": "8",
      "text": "The whole crowd of people and the important officers heard this report about Paul and Silas. They became very angry and upset."
    },
    {
      "verse": "9",
      "text": "The officers decided how much money Jason and the other believers should pay to go free. When they received it, they allowed them to go."
    },
    {
      "verse": "10",
      "text": "As soon as it became dark, the believers in Thessalonica sent Paul and Silas away to Berea. When they arrived in that town, they went to the Jewish meeting place."
    },
    {
      "verse": "11",
      "text": "The Jewish people in Berea were better than the people in Thessalonica. They were happy to listen carefully to Paul. Every day they also studied the Bible. They wanted to know if Paul's message was true."
    },
    {
      "verse": "12",
      "text": "Many of the Jewish people in Berea believed the good news about Jesus. Many Greek men and some important Greek women also believed in Jesus."
    },
    {
      "verse": "13",
      "text": "But the Jews in Thessalonica heard news about what Paul was doing in Berea. They heard that he was telling people God's message about Jesus. So some of them went to Berea. They said bad things against Paul to the people there. As a result, a large crowd became angry with Paul."
    },
    {
      "verse": "14",
      "text": "Immediately, the believers in Berea sent Paul away to go to the coast. But Silas and Timothy stayed in Berea."
    },
    {
      "verse": "15",
      "text": "When Paul left Berea, some men went with him. They went with him as far as the city of Athens. Before these men returned to Berea, Paul gave them a message for Silas and Timothy. He said, ‘Please come quickly and meet me here in Athens. ’"
    },
    {
      "verse": "16",
      "text": "While Paul was waiting in Athens for Silas and Timothy, he walked around. He saw that the people in the city had many idols. When Paul saw this, he became very upset."
    },
    {
      "verse": "17",
      "text": "So he went to the Jewish meeting place and he talked with the Jews. He also talked there with those Gentiles who now worshipped God. Every day he also went to the market place in the city and he talked with the people there."
    },
    {
      "verse": "18",
      "text": "There were some teachers there who liked to talk about the things that people should believe. Some of them were called Epicureans and some were called Stoics. After they talked to Paul, some of them said to each other, ‘Who is this silly man? He knows nothing and he talks too much! ’ But some of these teachers said, ‘We think that he is talking about strange gods. ’ They said this because Paul was telling people the good news about Jesus. He was also talking about the time when God will cause dead people to live again."
    },
    {
      "verse": "19",
      "text": "So these men asked Paul to go with them to Areopagus hill. They wanted him to speak to the city's important officers who met there."
    },
    {
      "verse": "20",
      "text": "The officers said, ‘These strange ideas that you are teaching surprise us. Please explain to us what these ideas mean. ’"
    },
    {
      "verse": "21",
      "text": "(The people of Athens liked to talk about new ideas. So did the foreign people who lived there. They all wanted to hear new things and to talk about them. They seemed to do this all the time. )"
    },
    {
      "verse": "22",
      "text": "So Paul stood up in front of the important officers of the city. He said to them, ‘People of Athens. I see that you have many gods."
    },
    {
      "verse": "23",
      "text": "I have walked in the streets of your city. I see that you have built many special places where you worship your gods. I saw one altar with a notice on it. The notice said, “To the god that we do not know. ” This shows that you want to worship a god that you do not know. Now I will tell you clearly about who this God is."
    },
    {
      "verse": "24",
      "text": "The true God made the earth and everything that is in it. He rules everything in the earth and in heaven. He does not live in any buildings that people have made for him."
    },
    {
      "verse": "25",
      "text": "People make things to give to God. But God does not need anything like that. It is God himself who causes everyone to live. He gives them everything that they need."
    },
    {
      "verse": "26",
      "text": "God first made one man. From that one man he made all the different groups of people. He caused them to live in different places all over the world. He decided where each group of people should live. He also decided how long they should live in each place."
    },
    {
      "verse": "27",
      "text": "God did all this so that people would want to know him. They would look carefully for him and perhaps they would find him. Really, God is near to each of us."
    },
    {
      "verse": "28",
      "text": "Someone said this: “Because God gives us life, we are alive. Because of him, we can move about. Because of him we can be who we are. ” One of your writers has also said, “We too are God's children. ”"
    },
    {
      "verse": "29",
      "text": "So, because we are God's children, we should not think that he is a thing like an idol. Clever people use gold or silver or stone to make images of gods. But God is not like these things that people choose to make for themselves."
    },
    {
      "verse": "30",
      "text": "In past times people did not know the true things about God. Because of this, God did not punish them. But now God tells people everywhere, “Stop doing bad things and turn to me! ”"
    },
    {
      "verse": "31",
      "text": "God has already chosen one special day. On that day he will judge everyone in the world in a completely right way. He has chosen a man who will do this for him. He has shown clearly to everyone who that man is. He showed it like this: People killed that man. But God caused him to live again. ’"
    },
    {
      "verse": "32",
      "text": "Paul had said, ‘God caused that man to live again. ’ When the people heard this, some of them laughed at him. But other people said to Paul, ‘We want you to tell us more about this on another day. ’"
    },
    {
      "verse": "33",
      "text": "So then Paul left the meeting of the important officers of the city."
    },
    {
      "verse": "34",
      "text": "Some of the people who had heard Paul's message joined his group. They believed the good news about Jesus. One of these believers was a man called Dionysius. He belonged to the group of important officers. A woman called Damaris also became a believer. Several other people also believed Paul's message about Jesus."
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "After Paul had spoken to the important officers of Athens, he left the city. He went from there to the city of Corinth."
    },
    {
      "verse": "2",
      "text": "In Corinth, he met a man called Aquila. Aquila was a Jew. He had been born in the region of Pontus. At that time, Caesar Claudius had said that all Jews must leave Rome. So Aquila had left Italy and he had just arrived in Corinth with his wife Priscilla. Paul went to visit them."
    },
    {
      "verse": "3",
      "text": "They knew how to make tents which they could sell to people. Paul also made tents, so he stayed with them and he worked with them."
    },
    {
      "verse": "4",
      "text": "Every Jewish day of rest, Paul taught both Jews and Greek people in the Jewish meeting place. He wanted them all to believe the good news about Jesus."
    },
    {
      "verse": "5",
      "text": "Then Silas and Timothy arrived there from the country called Macedonia. After that, the only work that Paul did was to teach people God's message. He told the Jews clearly that Jesus is God's Messiah."
    },
    {
      "verse": "6",
      "text": "The Jews did not agree with Paul and they insulted him. So he shook the dirt off his clothes at them. He said to them, ‘If God punishes you, then you have caused it to happen. It will not be because of me. Now I will go to the Gentiles and I will teach them God's message. ’"
    },
    {
      "verse": "7",
      "text": "So Paul did not speak in the Jewish meeting place any more. Instead, he went to the house of Titius Justus, which was next to the meeting place. Justus was a Gentile who now worshipped God."
    },
    {
      "verse": "8",
      "text": "A man called Crispus was the leader of the Jewish meeting place there. He, and everyone else who lived in his house, believed in the Lord Jesus. Many other people in Corinth heard Paul's message and they believed in Jesus. When they became believers, someone baptized them."
    },
    {
      "verse": "9",
      "text": "But one night, the Lord appeared to Paul in a vision. He said, ‘Do not be afraid of those people who are against you. Continue to speak my message to the people here. Do not stop speaking to them."
    },
    {
      "verse": "10",
      "text": "I am here with you. Nobody will hurt you. There are many people in this city who will believe in me. ’"
    },
    {
      "verse": "11",
      "text": "months and he taught the people God's message about Jesus."
    },
    {
      "verse": "12",
      "text": "Gallio then became the Roman ruler of the region called Achaia. At this time the Jewish leaders in Corinth decided together to speak against Paul. So they took hold of him and they brought him to Gallio. They wanted Gallio to judge Paul."
    },
    {
      "verse": "13",
      "text": "The Jewish leaders said to Gallio, ‘This man is teaching people to worship God in a wrong way. The things that he teaches are against our Jewish law. ’"
    },
    {
      "verse": "14",
      "text": "Paul was ready to speak, but Gallio spoke first to the Jews. He said, ‘If this man had done a very bad thing, then I would judge him. It would be right for me to listen to you."
    },
    {
      "verse": "15",
      "text": "But you are arguing about words and names and your own Jewish law. So you yourselves must decide what to do about it. I will not be a judge to decide about these things. ’"
    },
    {
      "verse": "16",
      "text": "Then Gallio told his soldiers to take the Jewish leaders away."
    },
    {
      "verse": "17",
      "text": "Then the whole crowd of people took hold of a man called Sosthenes. He was the leader of the Jewish meeting place there. The crowd hit him with sticks in front of Gallio. But Gallio did nothing to stop them. He did not think it was important."
    },
    {
      "verse": "18",
      "text": "Paul remained in Corinth with the believers for many days. Then he left them. Priscilla and Aquila also went with him. They went to the port called Cenchrea. They got on a ship there to sail to Syria. Before they left, someone cut off all the hair on Paul's head. This showed that he had made a promise to God."
    },
    {
      "verse": "19",
      "text": "They all arrived in the city of Ephesus. Paul left Priscilla and Aquila, and he went into the Jewish meeting room. There he talked about God's message with the Jews."
    },
    {
      "verse": "20",
      "text": "Some of them asked Paul to remain in Ephesus with them for a longer time. But he did not agree to stay."
    },
    {
      "verse": "21",
      "text": "Before he left, he said to them, ‘If God wants me to come back, I will return to you. ’ Then Paul got in a ship and he sailed from Ephesus to Caesarea."
    },
    {
      "verse": "22",
      "text": "After Paul arrived in Caesarea, he went to Jerusalem. He said, ‘hello’ to the group of believers there. Then he travelled to Antioch in Syria."
    },
    {
      "verse": "23",
      "text": "He stayed in Antioch for some time. Then he left there and he travelled through the regions called Galatia and Phrygia. He spoke to all the believers in these places. He helped them to trust God and to be strong."
    },
    {
      "verse": "24",
      "text": "A certain Jewish man called Apollos arrived in Ephesus. He had been born in Alexandria, and he could teach people very well. He knew a lot about God's message in the Bible."
    },
    {
      "verse": "25",
      "text": "Someone had taught him the good news about the Lord Jesus. He liked to speak a lot to people about Jesus. The things that he taught were true. But he only knew part of God's message. He only knew the things that John taught about baptism."
    },
    {
      "verse": "26",
      "text": "Apollos went to the Jewish meeting place and he taught the people there. He was not afraid to speak God's message to them. Priscilla and Aquila heard what Apollos was teaching the people. So they said to him, ‘Please come with us to our home. ’ Then they explained to Apollos the whole of God's message about Jesus. Then he could understand better."
    },
    {
      "verse": "27",
      "text": "Later, Apollos decided to go to the region called Achaia. The believers in Ephesus agreed that he should do that. They wrote a letter for him to give to the believers in Achaia. They wrote, ‘When Apollos arrives, please accept him. ’ God had been very kind to the believers in Achaia, so that they believed in Jesus. When Apollos came to them, he helped them very much."
    },
    {
      "verse": "28",
      "text": "Some of the Jews there spoke against Apollos's message. But he argued strongly against them so that everyone could hear. He explained to them what God had said in the Bible. He showed them clearly that Jesus is God's Messiah."
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "While Apollos was in Corinth, Paul travelled through the region of Asia. He arrived in Ephesus and he found some believers there. The believers answered, ‘We did not even know that there is a Holy Spirit. ’"
    },
    {
      "verse": "2",
      "text": "Paul asked them, ‘When you believed the message about Jesus, did you receive God's Holy Spirit? ’The believers answered, ‘We did not even know that there is a Holy Spirit. ’"
    },
    {
      "verse": "3",
      "text": "So Paul asked them, ‘When someone baptized you, what kind of baptism was that? ’‘We received the baptism that John spoke about, ’ they answered. ‘We received the baptism that John spoke about, ’ they answered."
    },
    {
      "verse": "4",
      "text": "Then Paul said, ‘John baptized people who knew that they had done wrong things. They wanted to stop doing these things. But John also said to the people, “You must believe in the man who will come soon. ” This person is Jesus. ’"
    },
    {
      "verse": "5",
      "text": "When the believers in Ephesus understood this, Paul baptized them. This showed that they now believed in the Lord Jesus."
    },
    {
      "verse": "6",
      "text": "Then Paul put his hands on each believer's head. When he did this, the Holy Spirit came down on them. They spoke in different languages and they spoke messages from God."
    },
    {
      "verse": "7",
      "text": "men there."
    },
    {
      "verse": "8",
      "text": "For three months, Paul went to the Jewish meeting place in Ephesus on their day of rest. He was not afraid to speak to the people there. He talked strongly with them about the kingdom of God."
    },
    {
      "verse": "9",
      "text": "But some of them did not accept what Paul said. They refused to believe the message about Jesus. Some of them said bad things against the Way of the Lord Jesus and many people in the group heard this. So Paul stopped speaking to people in that meeting place. He left there and he took with him the other believers. Every day he talked with people in another place. It was a large room, where a man called Tyrannus usually taught people."
    },
    {
      "verse": "10",
      "text": "Paul taught the people there for two years. During that time, all the people who lived in Asia region heard the message about the Lord Jesus. This included Jews and Gentiles."
    },
    {
      "verse": "11",
      "text": "God was helping Paul to do special miracles."
    },
    {
      "verse": "12",
      "text": "Because of this, people were taking pieces of cloth and clothes that Paul gave to them. Paul had used these things, and people took them to those who were ill. After they touched these cloths, the sick people would become well again. Bad spirits also left them."
    },
    {
      "verse": "13",
      "text": "There were some Jewish men who travelled about to different places. They caused bad spirits to leave people. Some of them wanted to use the name of the Lord Jesus when they did this. These Jews said to the bad spirits, ‘We tell you to come out of these people. We say this with the authority of Jesus, the man that Paul teaches people about. ’"
    },
    {
      "verse": "14",
      "text": "Sceva was a leader of the Jewish priests in that place. He had seven sons who were telling bad spirits to come out of people. They used the name of Jesus when they did this."
    },
    {
      "verse": "15",
      "text": "But one day the bad spirit in a man said to them, ‘I know who Jesus is. I also know about Paul. But I do not know who you are. ’"
    },
    {
      "verse": "16",
      "text": "The man who had the bad spirit in him then jumped up. He fought with the seven sons and he was too strong for them. He hurt them badly and he tore their clothes off. So the sons ran away from the man's house. Their bodies were bleeding and they wore no clothes."
    },
    {
      "verse": "17",
      "text": "All the Jews and Gentiles who lived in Ephesus heard about this. They became very afraid. Now they respected the name of the Lord Jesus very much. They knew that he was very powerful."
    },
    {
      "verse": "18",
      "text": "Many of the believers agreed that they had done wicked things. They told other believers about this."
    },
    {
      "verse": "19",
      "text": "Some of them had used magic to do powerful things. These people brought all their special books and they burned them in a fire. Everybody saw what they did. The books had cost a lot of money. The value of all the books was 50, 000 silver coins."
    },
    {
      "verse": "20",
      "text": "As a result of this, more and more people heard the good news about the Lord Jesus. The message was powerful and people's lives changed."
    },
    {
      "verse": "21",
      "text": "After these things happened, Paul decided that he should go to Jerusalem. But first he wanted to visit the believers in Macedonia and Greece. He said, ‘After I have been to Jerusalem, I must also go to Rome. ’"
    },
    {
      "verse": "22",
      "text": "At that time, Timothy and Erastus were helping Paul with his work. Paul sent them to Macedonia while he stayed longer in Asia region."
    },
    {
      "verse": "23",
      "text": "Soon after that, there was bad trouble in Ephesus. Some people began to speak strongly against the Way of the Lord Jesus."
    },
    {
      "verse": "24",
      "text": "In Ephesus there was a man called Demetrius. He used silver to make beautiful things. He made models that looked like the temple of Artemis. He paid a lot of money to people who did this work for him."
    },
    {
      "verse": "25",
      "text": "So he told all his workers to meet with him. He also asked other workers to come, who did the same kind of work. He said to all these men, ‘Men, you know that our work has caused us to become rich."
    },
    {
      "verse": "26",
      "text": "Also, you can see what this man Paul is doing. You have heard his message. Many people here in Ephesus, and in nearly all the places in Asia region, believe what he says. Paul teaches people this: “Anything that men have made is not really a god. ”"
    },
    {
      "verse": "27",
      "text": "If people continue to believe Paul's message, it will be very bad for us. People will say bad things against our work. The house of our god Artemis will not be important any more. People will even think that Artemis herself is not a great god. As it is now, people in all of Asia region and everywhere else worship her. We do not want that to change. ’"
    },
    {
      "verse": "28",
      "text": "When the workers heard Demetrius, they became very angry. They all shouted, ‘Our god Artemis of Ephesus is very great! ’"
    },
    {
      "verse": "29",
      "text": "More and more people in the whole city began to shout. There was trouble everywhere. Gaius and Aristarchus had been travelling with Paul. They had come with him from Macedonia. Some people from the crowd took hold of Gaius and Aristarchus. They pulled them quickly to the big public meeting place in the middle of the city."
    },
    {
      "verse": "30",
      "text": "Paul himself wanted to go there. He wanted to speak to the crowd. But the other believers would not let him do that."
    },
    {
      "verse": "31",
      "text": "Some Roman officers in that region were Paul's friends. They also sent a message to him. They said to him, ‘Please, do not go to the meeting place. ’"
    },
    {
      "verse": "32",
      "text": "The crowd of people in the meeting place continued to shout loudly. Some people were shouting one thing and other people were shouting something different. Not many of the people even knew why they had all met together."
    },
    {
      "verse": "33",
      "text": "There was a Jewish man called Alexander in the crowd. The Jews pushed him to the front of the crowd. He raised his hands towards the people, so that they would be quiet. He wanted to explain to them that he and his Jewish friends had not caused the trouble."
    },
    {
      "verse": "34",
      "text": "But the crowd knew that Alexander was a Jew. So they continued to shout the same words for about two hours. All together they shouted, ‘Our god Artemis of Ephesus is very great! ’"
    },
    {
      "verse": "35",
      "text": "After two hours, an important officer of the city caused the crowd to be quiet. He said, ‘People of Ephesus! Everybody knows about our god Artemis who has her temple here in Ephesus. People come here to worship her. Her special stone that fell from the sky is also here in Ephesus. We take care of all her things. Everybody knows that!"
    },
    {
      "verse": "36",
      "text": "Nobody can say that this is not true. So be careful! Do not quickly do anything that is silly."
    },
    {
      "verse": "37",
      "text": "You have brought Gaius and Aristarchus here to the city officers' meeting place. But what bad thing have they done? They have not robbed the house of Artemis. They have not said bad things against her."
    },
    {
      "verse": "38",
      "text": "Perhaps Demetrius and his workers think that someone has done a bad thing to them. If they think that, they should let a judge decide. There are officers for the government who will do this. If someone has done a wrong thing, people should tell a judge."
    },
    {
      "verse": "39",
      "text": "So, if you want to argue about these problems any more, do it properly. Go to the place where the judges meet."
    },
    {
      "verse": "40",
      "text": "Today, there is a crowd of people who are shouting and fighting. The Roman rulers may hear about what has happened. They will say that we have done bad things. We could not explain to them the reason why there is all this trouble. ’"
    },
    {
      "verse": "41",
      "text": "When the officer had said all this, he said to the crowd, ‘All of you should go home now. ’"
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "After that, the trouble in Ephesus finished. Then Paul asked the believers to meet together with him. He spoke to them to help them. He told them to be strong and to trust God. Then he said ‘goodbye’ to them. After that he left them and he travelled on to Macedonia."
    },
    {
      "verse": "2",
      "text": "He visited many places in that region. He spoke to the believers in each place. He helped them to be strong. After that, he arrived in Greece."
    },
    {
      "verse": "3",
      "text": "Paul stayed in Greece for three months. One day, he was preparing to travel to Syria by ship. But then he heard news that some Jews wanted to kill him on the journey. So he decided to travel through Macedonia and return to Jerusalem."
    },
    {
      "verse": "4",
      "text": "These are the men who went with Paul: Sopater, the son of Pyrrhus, from Berea; Aristarchus and Secundus from Thessalonica; Gaius from Derbe; Timothy; Tychicus and Trophimus from Asia region."
    },
    {
      "verse": "5",
      "text": "These men had all left by ship before we did. When they arrived in Troas, they waited for us there."
    },
    {
      "verse": "6",
      "text": "As for us, we sailed by ship from Philippi, after the festival when the Jews eat flat bread. After five days we arrived in Troas. We met the other men there and we all stayed there for seven days. After five days we arrived in Troas. We met the other men there and we all stayed there for seven days."
    },
    {
      "verse": "7",
      "text": "On the Sunday evening, we met together with the believers. We broke bread into pieces and we shared it with each other. Paul spoke to the believers for a long time, until midnight. This was because he wanted to leave Troas the next day."
    },
    {
      "verse": "8",
      "text": "Many lamps were burning in the upstairs room where we met together."
    },
    {
      "verse": "9",
      "text": "A young man called Eutychus was at the meeting. He was sitting on the edge of a window. When Paul had talked for a long time, Eutychus started to sleep. When he was really sleeping, he fell out of the window. He dropped down a long way to the ground. Some of the believers lifted him up, but he was dead."
    },
    {
      "verse": "10",
      "text": "So Paul went down the stairs to them all. He lay on top of the young man and held him with his arms. Then Paul said to them all, ‘Do not be afraid. He is still alive. ’"
    },
    {
      "verse": "11",
      "text": "Paul went back upstairs. He shared bread with the believers and he ate more food. Paul talked to them for a long time, until the sun rose in the morning. Then he left Troas."
    },
    {
      "verse": "12",
      "text": "The other believers took Eutychus to his home. They were very happy because he was alive."
    },
    {
      "verse": "13",
      "text": "Paul decided to travel to Assos across the land. But we got on a ship and we sailed to Assos. We agreed with Paul that we would wait for him there."
    },
    {
      "verse": "14",
      "text": "When he met us at Assos, he came on the ship with us. Then we all sailed to Mitylene."
    },
    {
      "verse": "15",
      "text": "We sailed from there and we arrived the next day at the coast near Chios. The day after that, we came to Samos. The next day, we arrived at Miletus."
    },
    {
      "verse": "16",
      "text": "Paul had decided to leave quickly from there. He did not want to visit Ephesus, because he did not want to remain in Asia for a long time. Instead, he wanted to travel to Jerusalem quickly. He wanted to arrive there before the day of the Pentecost festival."
    },
    {
      "verse": "17",
      "text": "When we were in Miletus, Paul sent someone to Ephesus with a message. This message was for the leaders of the believers in Ephesus. Paul asked them to come to Miletus to meet him there."
    },
    {
      "verse": "18",
      "text": "When they arrived, Paul said to them, ‘You yourselves know about everything that I did here in Asia. You saw how I lived from the first day that I arrived in this region. I was with you for the whole time."
    },
    {
      "verse": "19",
      "text": "I did not say that I was an important man. Instead, I worked as a servant of the Lord Jesus. I often was sad because of trouble that came to me. Some Jewish people spoke against my message. They wanted to hurt me."
    },
    {
      "verse": "20",
      "text": "But I have not been afraid to teach God's message. I have taught you everything that would help you. I have done this outside for everyone to hear. I have also taught you in your own homes."
    },
    {
      "verse": "21",
      "text": "I have taught the same things both to Jewish people and to Gentiles. I have said clearly to them all, “You must stop doing wrong things. Change the way that you live and turn to God. Believe in our Lord Jesus. ”"
    },
    {
      "verse": "22",
      "text": "Now I am going to Jerusalem. God's Holy Spirit has shown me that I must go there. I do not know what will happen to me there."
    },
    {
      "verse": "23",
      "text": "But I do know that much trouble will come to me. The Holy Spirit has told me about that. He said to me, “People will put you in prison and they will hurt you. ”"
    },
    {
      "verse": "24",
      "text": "But even if people kill me, this is not important to me. The Lord Jesus gave me some work to do. It is important that I finish his work. I must tell people the good news about how kind and good God is."
    },
    {
      "verse": "25",
      "text": "I have lived among you and I have taught you all about the kingdom of God. But now I know that none of you will see me again."
    },
    {
      "verse": "26",
      "text": "So I want to say this clearly to you today. If any of you have not believed in Jesus, it is not because of me."
    },
    {
      "verse": "27",
      "text": "I have told you everything that God wants you to know."
    },
    {
      "verse": "28",
      "text": "You who are leaders should be careful about how you live. Also take care of the group of people that the Holy Spirit has chosen you to lead. Keep them safe like shepherds who take care of their sheep. All the believers belong to God because his Son, Jesus, died for them. He bought them with his blood which poured out on the cross."
    },
    {
      "verse": "29",
      "text": "I know that trouble will come to you after I leave. Bad people will come to teach you. They will cause trouble for the believers, like dangerous wild animals that attack sheep."
    },
    {
      "verse": "30",
      "text": "Even men from your own group of believers will teach things that are not true. They want to deceive other believers, so that they leave you and join with them."
    },
    {
      "verse": "31",
      "text": "So be very careful! For three years I taught you, in the day and in the night. I warned you to be careful, so that I even cried about it."
    },
    {
      "verse": "32",
      "text": "Now I ask God to keep you safe. I brought God's message to you, which tells us how kind he is. That message will cause you to be strong. As a result, God will give to you all the good things that he has for his own special people."
    },
    {
      "verse": "33",
      "text": "When I stayed among you, I did not ask you to give me money or clothes."
    },
    {
      "verse": "34",
      "text": "You yourselves know that I worked with my hands. I did that to get money. Then my friends and I could have the things that we needed."
    },
    {
      "verse": "35",
      "text": "In this way I have shown you how you should live. You should work well so that you may help sick or weak people. You should remember what Jesus himself said: “It may make you happy when you receive things. But it makes you more happy when you give things to someone. ” ’"
    },
    {
      "verse": "36",
      "text": "Then Paul finished speaking. He went down on his knees together with the leaders of the believers. He prayed with them all. After that, they walked with Paul to the ship."
    },
    {
      "verse": "37",
      "text": "They all cried a lot, because Paul wanted to leave them. They hugged him and they kissed him to say ‘goodbye’."
    },
    {
      "verse": "38",
      "text": "They were very sad because Paul had said, ‘I will never see you again. ’After that, they walked with Paul to the ship."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "We said ‘goodbye’ to the leaders of the believers from Ephesus. Then we went on a ship straight across the sea, and we arrived at Cos. The next day, we continued on our journey to Rhodes. From there we went to the town of Patara."
    },
    {
      "verse": "2",
      "text": "At Patara, we found a ship that was going to Phoenicia. So we got onto the ship and we sailed across the sea."
    },
    {
      "verse": "3",
      "text": "After travelling for some time, we could see the island called Cyprus. We went south of Cyprus, and we continued as far as Syria. We arrived on the coast at the city of Tyre and we got off the ship. The ship would remain in Tyre for some days, because people had to remove the things off the ship."
    },
    {
      "verse": "4",
      "text": "We found some believers in the city. So we stayed with them for a week. The Holy Spirit showed these believers that trouble would come to Paul in Jerusalem. So they said to him, ‘Paul, you should not to go to Jerusalem. ’"
    },
    {
      "verse": "5",
      "text": "After a week with the believers in Tyre, it was time for us to leave them. All the believers, together with their wives and their children, went with us out of the city. At the beach, we all went down on our knees and we prayed together."
    },
    {
      "verse": "6",
      "text": "Then we said ‘goodbye’ to each other and the believers returned to their homes in the city. We went and we got on the ship again, together with Paul."
    },
    {
      "verse": "7",
      "text": "We continued our journey across the sea. We sailed from Tyre to Ptolemais. There, we met some believers and we stayed with them for one day."
    },
    {
      "verse": "8",
      "text": "The next day, we left Ptolemais and we sailed to Caesarea. We stayed there with Philip. He was someone who taught people the good news about Jesus. He was one of the seven men that the believers had chosen in Jerusalem."
    },
    {
      "verse": "9",
      "text": "He had four daughters who were not married. They spoke messages from God."
    },
    {
      "verse": "10",
      "text": "We stayed with Philip in Caesarea for a few days. Then a man called Agabus arrived in the city from Judea. He was a prophet and he spoke messages from God."
    },
    {
      "verse": "11",
      "text": "Agabus came to where we were. He took Paul's belt and he tied it around his own feet and hands. He said, ‘Listen to this message from the Holy Spirit. “The Jewish leaders in Jerusalem will take hold of the man who has this belt. They will tie his hands and his feet. Then they will give him to the Gentiles to be their prisoner. ” ’"
    },
    {
      "verse": "12",
      "text": "When we heard Agabus's message, we all said many times to Paul, ‘Please do not go to Jerusalem. ’"
    },
    {
      "verse": "13",
      "text": "But Paul answered, ‘Stop crying like this! You are making me very sad! I am ready for men in Jerusalem to take hold of me. They may tie me up, and I may even die there. I am ready for all this because I believe in the Lord Jesus. ’"
    },
    {
      "verse": "14",
      "text": "We could not cause Paul to think in a different way. So we stopped saying to him, ‘You should not go to Jerusalem. ’ Instead we said to him, ‘We want the Lord God to do what he wants. ’"
    },
    {
      "verse": "15",
      "text": "We stayed in Caesarea for a few days. Then we prepared ourselves to travel across land. We left there to go to Jerusalem."
    },
    {
      "verse": "16",
      "text": "Some of the believers from Caesarea also went with us. They took us to the house of a man called Mnason. We had decided to stay with him. His home town was on the island called Cyprus. He had been a believer for a long time."
    },
    {
      "verse": "17",
      "text": "When we arrived in Jerusalem, the believers there were very happy to welcome us."
    },
    {
      "verse": "18",
      "text": "The next day, we went with Paul to see James. The leaders of the believers were also there."
    },
    {
      "verse": "19",
      "text": "Paul said, ‘hello’ to them and then he told them everything about his work. God had helped him to do many good things for the Gentiles."
    },
    {
      "verse": "20",
      "text": "After the leaders had listened to Paul, they praised God. Then they said, ‘Brother Paul, you can see the problem. There are now many thousands of Jews who have believed in Jesus. But they also really want to obey the Law of Moses."
    },
    {
      "verse": "21",
      "text": "These Jews here have heard about what you teach Jewish people in other countries. They think that you say to them, “You do not need to obey the Law of Moses any longer. You do not need to circumcise your children. You do not need to live in the way that Jewish people usually live. ”"
    },
    {
      "verse": "22",
      "text": "We need to do something about this problem. These Jewish believers will certainly hear that you are in Jerusalem."
    },
    {
      "verse": "23",
      "text": "We will tell you what you must do. There are four Jewish men in our group who have made a promise to God."
    },
    {
      "verse": "24",
      "text": "You must go with these men to the temple. There, they will wash to make themselves clean in front of God. Join with them when they do that. Then pay the priest the money for their sacrifices. After that, the men can cut the hair off their heads. When you do that, everyone will understand about you. They will see what you have done. They will know that you yourself obey the Law of Moses. They will know that what they have heard about you is not true."
    },
    {
      "verse": "25",
      "text": "But it is different for the Gentiles who believe in Jesus. We have already sent a letter to them. We wrote, “Do not eat any food that people have given to their idols. Do not eat anything that still has blood in it. If people have strangled an animal to kill it, do not eat its meat. Do not have sex with anyone that you are not married to. ” ’"
    },
    {
      "verse": "26",
      "text": "So the next day, Paul went with the four men. He joined with them when they washed to make themselves clean in front of God. Then he went into the yard of the temple. He told the priest there when the four men would finish their promise to God. This would be after seven days. After that, each man would give an animal as a sacrifice to God."
    },
    {
      "verse": "27",
      "text": "At the end of those seven days, some Jews from Asia region saw Paul in the temple. They said some bad things against Paul to the crowd. So the people became angry and they took hold of Paul."
    },
    {
      "verse": "28",
      "text": "The Jews from Asia shouted, ‘People of Israel, come and help us! This is the man who goes everywhere and he teaches everyone bad things. He speaks against us, the people of Israel. He also speaks against the Law of Moses and against this temple. Now he has even brought some Gentiles into this temple. So now this special place is not clean in front of God any longer. ’"
    },
    {
      "verse": "29",
      "text": "(These men had earlier seen Paul in the city with a man called Trophimus. Trophimus was a Gentile who came from Ephesus. They thought that Paul had brought Trophimus into the temple. That is why they shouted bad things against Paul. )"
    },
    {
      "verse": "30",
      "text": "Many other people in the city heard about the trouble and they also became angry. They all ran from their homes to the temple and they took hold of Paul. Then they pulled him out of the temple and they closed the doors immediately."
    },
    {
      "verse": "31",
      "text": "The angry crowd was trying to kill Paul. But someone sent a message to the leader of the Roman soldiers. The message was, ‘People are fighting everywhere in the city. ’"
    },
    {
      "verse": "32",
      "text": "So the soldiers' leader quickly took some other officers and a large group of soldiers and they ran down to the crowd. The angry crowd of people saw the leader with his soldiers. So then they stopped hitting Paul."
    },
    {
      "verse": "33",
      "text": "The Roman soldiers' leader went to Paul and he took hold of him. He said to his men, ‘Tie two chains round the arms of this man. ’ Then he asked the people in the crowd, ‘Who is this man and what has he done? ’"
    },
    {
      "verse": "34",
      "text": "Some people in the crowd shouted one thing and other people shouted something different. There was so much noise that the leader of the soldiers was not sure about the true facts. He did not know what had really happened. So he said to his soldiers, ‘Take this man up into our strong building! ’"
    },
    {
      "verse": "35",
      "text": "The soldiers then led Paul as far as the steps of their building. Then they had to carry him because the crowd was so angry."
    },
    {
      "verse": "36",
      "text": "The crowd followed behind Paul and the soldiers. They were shouting, ‘Kill him! ’"
    },
    {
      "verse": "37",
      "text": "While the soldiers were leading Paul into their building, he asked their leader, ‘Please may I say something to you? ’The soldiers' leader replied, ‘Oh! Do you speak the Greek language?"
    },
    {
      "verse": "38",
      "text": "I thought that you must be that bad man who came from Egypt. He was the one who fought against our Roman government. Some time ago, he led 4, 000 of his own men out into the wilderness, with their weapons. ’"
    },
    {
      "verse": "39",
      "text": "Paul answered, ‘I am a Jew and I was born in Tarsus in the region called Cilicia. So you see, I am a man from an important city. Please, let me speak to this crowd. ’"
    },
    {
      "verse": "40",
      "text": "The leader of the soldiers said to Paul, ‘Yes, you may speak to the people. ’ So Paul stood still on the steps of the soldiers' building. He raised his hands towards them so that the people became quiet. Then he spoke to them in Aramaic, the Jewish people's own language."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "Paul said to the crowd, ‘Please, listen to me, you Jewish leaders and all you other people who are Jews like me. I want to explain to you what has happened here. ’"
    },
    {
      "verse": "2",
      "text": "The crowd heard Paul speaking to them in their own Hebrew language. So they became really quiet. Paul continued to speak. He said,"
    },
    {
      "verse": "3",
      "text": "‘I am a Jew. I was born in Tarsus in the region of Cilicia. I lived here in Jerusalem when I was a boy. I studied God's Law for many years and Gamaliel was my teacher. I learned very well how to obey the laws of our ancestors. I tried to obey God as carefully as all of you do today."
    },
    {
      "verse": "4",
      "text": "I caused great trouble to the disciples of Jesus. I even wanted to kill them. I took hold of them and I put them in prison. I did that to both men and women."
    },
    {
      "verse": "5",
      "text": "The most important priest and all the group of Jewish leaders can tell you that this is true. They gave me letters for the Jewish leaders in Damascus. So I travelled to Damascus to take hold of the believers in that city. I wanted to tie them up and bring them back to Jerusalem. Then the leaders here could punish them. ’"
    },
    {
      "verse": "6",
      "text": "Paul continued to say, ‘As I was travelling, I came near to Damascus. About midday, a bright light from the sky suddenly shone round me."
    },
    {
      "verse": "7",
      "text": "I fell down to the ground. Then I heard a voice that said to me, “Saul, Saul, why do you fight against me? ”"
    },
    {
      "verse": "8",
      "text": "“Lord, who are you? ” I asked. He said to me, “I am Jesus from Nazareth. And you are fighting against me. ”"
    },
    {
      "verse": "9",
      "text": "The men who travelled with me saw the light. But they did not understand the voice that spoke to me."
    },
    {
      "verse": "10",
      "text": "I asked, “Lord, what must I do? ” He said to me, “Get up now and go into Damascus. When you arrive in the city, someone will come to you. He will tell you what God wants you to do. ”"
    },
    {
      "verse": "11",
      "text": "The bright light hurt my eyes so that I could not see. So the men who were with me held my hand. They led me into Damascus."
    },
    {
      "verse": "12",
      "text": "In Damascus, there was a man called Ananias. He worshipped God and he obeyed our Law. All the Jews in Damascus said good things about him."
    },
    {
      "verse": "13",
      "text": "Ananias came to see me. He stood near to me and he said, “Brother Saul, see again! ” Then immediately I could see again. I could look at him."
    },
    {
      "verse": "14",
      "text": "Then Ananias said to me, “The God that we worship and our ancestors worshipped has chosen you. He will tell you what he wants you to do. God has let you see his special servant, who is completely good. You have heard this servant's message to you."
    },
    {
      "verse": "15",
      "text": "You will tell people everywhere about the things that you have seen and heard. That is what God wants you to do."
    },
    {
      "verse": "16",
      "text": "So now you do not need to wait any longer. Stand up and I will baptize you. Believe in the Lord Jesus so that God will forgive you for your sins. ”"
    },
    {
      "verse": "17",
      "text": "So then I returned to Jerusalem. I went into the temple and I was praying there. I had a vision."
    },
    {
      "verse": "18",
      "text": "In the vision, I saw the Lord and he spoke to me. He said, “Hurry. Leave Jerusalem quickly. The people here will not believe what you say to them about me. ”"
    },
    {
      "verse": "19",
      "text": "I replied, “Lord, the people here know what I have been doing. They know that I wanted to take hold of all the people who believed in you. I went to all our Jewish meeting places to look for the believers. When I found them, I put them in prison and I hit them with sticks."
    },
    {
      "verse": "20",
      "text": "I myself was there when the people killed Stephen. He was your servant who told people your message. But I agreed that it was right to kill him. I even held the coats of the people while they killed him. ”"
    },
    {
      "verse": "21",
      "text": "But the Lord said to me, “Go! I will now send you a long way away. You must go to the Gentiles and tell them my message. ” ’"
    },
    {
      "verse": "22",
      "text": "The people listened carefully to Paul until he spoke about the Gentiles. Then they began to shout loudly, ‘Take him away! Kill him! It is not right that he should live any longer! ’"
    },
    {
      "verse": "23",
      "text": "While they were shouting this, they were taking off their coats. They also threw dirt from the ground up into the air."
    },
    {
      "verse": "24",
      "text": "The leader of the soldiers said to his men, ‘Take this man into our building. Then hit him with whips. We must find out what he has done. He must tell us why the Jews are shouting so loudly against him. ’"
    },
    {
      "verse": "25",
      "text": "So the soldiers tied Paul's arms and they were ready to hit him. But Paul spoke to the soldiers' officer who stood near to him. He said, ‘I am a citizen of Rome. So it is not right for you to hit me like that. No judge has agreed that I have done anything wrong. ’"
    },
    {
      "verse": "26",
      "text": "The officer heard what Paul said. So he went to the leader of the soldiers and he said, ‘That man is a citizen of Rome! Be careful what you do to him! ’"
    },
    {
      "verse": "27",
      "text": "So the soldiers' leader went to speak to Paul. He asked him, ‘Tell me. Are you really a citizen of Rome? ’Paul answered, ‘Yes, I am. ’ Paul answered, ‘Yes, I am. ’"
    },
    {
      "verse": "28",
      "text": "The soldiers' leader said, ‘I paid a lot of money to the government so that I could become a citizen of Rome. ’Paul replied, ‘But I was already a citizen of Rome when I was born. ’ Paul replied, ‘But I was already a citizen of Rome when I was born. ’"
    },
    {
      "verse": "29",
      "text": "Immediately, the men who wanted to hit Paul with whips moved away from him. The leader of the soldiers was also very afraid. He had tied chains around Paul's arms and legs. He knew that he should not have done that to a citizen of Rome."
    },
    {
      "verse": "30",
      "text": "The soldiers' leader wanted to find the reason why the Jews had said bad things against Paul. He wanted to know what was really true. So the next day, he told his soldiers to remove the chains from Paul. He sent a message to the most important priest and to all the group of Jewish leaders. He told them to meet together with him. Then he took Paul to their meeting. He made Paul stand in front of them."
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "Paul looked at the group of Jewish leaders and he said to them, ‘My Jewish friends, God knows that I have nothing to be ashamed about today. I have always respected God's Laws. ’"
    },
    {
      "verse": "2",
      "text": "The most important priest, who was called Ananias, heard Paul's words. He said to the men who were near Paul, ‘Hit that man on his mouth! ’"
    },
    {
      "verse": "3",
      "text": "Paul said to him, ‘God will certainly hit you! You are a hypocrite! You are sitting there and you are judging me. You are asking if I obey the Law of God. But you yourself do not obey the Law! You should not have said, “Hit that man! ” ’"
    },
    {
      "verse": "4",
      "text": "The men who were standing near Paul said to him, ‘You must not say bad things against our most important priest! ’"
    },
    {
      "verse": "5",
      "text": "Paul replied, ‘My brothers, I did not know that this man is the most important priest. Our Jewish law says, “Do not say bad things against the man who rules your people. ” So I should not have said anything bad against him. ’"
    },
    {
      "verse": "6",
      "text": "Then Paul saw that there were some Sadducees and also some Pharisees in the meeting. So he shouted out to the whole group of Jewish leaders, ‘My brothers, I am a Pharisee! My father was also a Pharisee. I believe that dead people will certainly rise and they will live again. That is the reason why you are judging me today. ’"
    },
    {
      "verse": "7",
      "text": "As soon as Paul said that, the Pharisees and Sadducees began to argue with each other. People in the group thought different things about Paul."
    },
    {
      "verse": "8",
      "text": "(The Sadducees do not believe that dead people will live again. They do not believe that there are angels or spirits. But the Pharisees believe in all these things. )"
    },
    {
      "verse": "9",
      "text": "The Sadducees and the Pharisees began to shout louder and louder against each other. There were some teachers of God's Law who were in the group of Pharisees. They stood up in the meeting and they said, ‘We do not believe that this man has done anything wrong. What he says may be true. A spirit or an angel may have spoken to him. ’"
    },
    {
      "verse": "10",
      "text": "The two groups argued more and more strongly. The leader of the soldiers thought that the people there might hurt Paul badly. So he said to his soldiers, ‘Go down into the group and take Paul away from them. Take him back with you into our strong building. ’"
    },
    {
      "verse": "11",
      "text": "The next night, the Lord Jesus came and he stood near Paul. He said to Paul, ‘Do not be afraid! You have told people here in Jerusalem about me. You must also do the same thing in Rome. ’"
    },
    {
      "verse": "12",
      "text": "The next morning, a group of Jews talked together about how they might kill Paul. They agreed to make a promise to God. They would not eat or drink anything until they had killed Paul."
    },
    {
      "verse": "13",
      "text": "men were in the group that decided this."
    },
    {
      "verse": "14",
      "text": "They went to the leaders of the priests and the important Jews. They said to them, ‘We have agreed together to make a serious promise to God. We will not eat anything until we have killed Paul."
    },
    {
      "verse": "15",
      "text": "So now we want you and the group of Jewish leaders to send a message to the leader of the Roman soldiers. Ask him, “Please bring Paul to the meeting of the Jewish leaders. We want to know more about the wrong things that he has done. ” That will be the message. But, we will wait for Paul and we will be ready to kill him. We will do this before he arrives here at the meeting. ’"
    },
    {
      "verse": "16",
      "text": "But the son of Paul's sister heard what the Jews had decided to do. He went into the soldiers' building and he told Paul about it."
    },
    {
      "verse": "17",
      "text": "So Paul asked one of the soldiers' officers to come to him. He said, ‘Please take this young man to your leader. He has something important to tell him. ’"
    },
    {
      "verse": "18",
      "text": "Then the officer led the young man to the soldiers' leader. He said to him, ‘Paul, who is here in the prison, spoke to me. He asked me to bring this young man to you. He has something to tell you. ’"
    },
    {
      "verse": "19",
      "text": "The leader of the soldiers held the young man's hand and he led him to another place. When they were alone, he asked the young man, ‘What do you want to tell me? ’"
    },
    {
      "verse": "20",
      "text": "The young man said, ‘Some Jewish men have agreed together to send a message to you. They will ask you to take Paul down to the meeting of the Jewish leaders tomorrow. They will say that they want to ask him more questions. But that is not true."
    },
    {
      "verse": "21",
      "text": "Do not agree to do what they want. There are more than 40 men who will be hiding somewhere. They are waiting for Paul. They have made a serious promise to God. They will not eat or drink anything until they have killed Paul. They are now ready to do this. They will be waiting to hear your answer. ’"
    },
    {
      "verse": "22",
      "text": "The leader of the soldiers said to him, ‘Do not tell anyone that you told me about this. ’ Then he sent the young man away."
    },
    {
      "verse": "23",
      "text": "Then the soldiers' leader told two of his officers to come to him. He said to them, ‘Tell 200 of our soldiers to prepare themselves. They must go to Caesarea at nine o'clock tonight. 70 soldiers who ride on horses must also go. There must also be another 200 soldiers with their weapons."
    },
    {
      "verse": "24",
      "text": "Take some horses for Paul to ride on. Take him to Felix the Roman ruler, and keep him safe on the journey. ’"
    },
    {
      "verse": "25",
      "text": "Then the soldiers' leader wrote a letter to Felix. He sent this message:"
    },
    {
      "verse": "26",
      "text": "‘I, Claudius Lysias, write this letter. I say “hello” to you, Felix, our great ruler."
    },
    {
      "verse": "27",
      "text": "I am sending this man to you. The Jews took hold of him and they wanted to kill him. I found out that he is a citizen of Rome. Because of that, I took my soldiers and I saved him from them."
    },
    {
      "verse": "28",
      "text": "The Jews said that he had done some wrong things. I wanted to know what was really true, so I took him to a meeting of their leaders."
    },
    {
      "verse": "29",
      "text": "The Jewish leaders said that he had not obeyed their own laws. But that was all. We could not put him in prison or kill him because of these things. That would not be right."
    },
    {
      "verse": "30",
      "text": "But a group of Jews decided to kill him. Someone told me about this, so I decided to send him to you immediately. I have told the Jewish leaders also to come to you in Caesarea. They can then tell you why they say that this man has done bad things. ’"
    },
    {
      "verse": "31",
      "text": "The soldiers did what their leader had told them to do. They took Paul out from the prison in their building. That night, they took him as far as Antipatris."
    },
    {
      "verse": "32",
      "text": "The next day, the soldiers who had walked returned to their building in Jerusalem. But the soldiers who rode horses continued to travel with Paul."
    },
    {
      "verse": "33",
      "text": "When they arrived in Caesarea, they gave the letter to Felix, the ruler. They also brought Paul to him. Felix then said to his soldiers, ‘Put this man in the prison in Herod's house. Guard him carefully! ’"
    },
    {
      "verse": "34",
      "text": "Felix read the letter and he asked Paul, ‘Which Roman region are you from? ’ Paul answered, ‘I am from Cilicia. ’"
    },
    {
      "verse": "35",
      "text": "Felix said, ‘When the Jews arrive, they will tell me about you. I will also listen to you. I will decide what is right. ’Felix then said to his soldiers, ‘Put this man in the prison in Herod's house. Guard him carefully! ’"
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "Five days after that, Ananias, the leader of the priests, went to Caesarea. Some important Jews went with him. A man called Tertullus also went with them. He was a lawyer. All these people went to meet with Felix, the ruler. They told Felix what Paul had done. Felix would judge who was right."
    },
    {
      "verse": "2",
      "text": "Felix told a soldier to bring Paul to the meeting. Then Tertullus began to speak against Paul. He said, ‘Sir, you have ruled us well for many years. Because of you, our country has had no wars for a long time. You have made new laws that are good for our country. You have thought well about how you should lead us."
    },
    {
      "verse": "3",
      "text": "Everywhere, the people are happy about what you have done. So we want to thank you very much for all these good things."
    },
    {
      "verse": "4",
      "text": "I do not want you to sit here for a long time. So I will speak for a short time about our problem. Please be kind to us and listen to me."
    },
    {
      "verse": "5",
      "text": "We know that this man brings trouble everywhere. Anywhere in the world that Jewish people live, he makes them angry. Then they all fight each other. He is the leader of a group called the Nazarenes. ’"
    },
    {
      "verse": "6",
      "text": "‘He also did bad things in the temple that are against our laws. So we took hold of him. [We wanted to judge him by what our own law says."
    },
    {
      "verse": "7",
      "text": "But Lysias, the leader of the soldiers, came to us. He attacked us and he took Paul away from us."
    },
    {
      "verse": "8",
      "text": "Then he told us to come and to speak to you about it. ] You should ask this man some questions about what he has done. You will find out that what we say against him is true. ’"
    },
    {
      "verse": "9",
      "text": "The other Jews that were there also spoke against Paul. They said, ‘All these things that Tertullus has said are true. ’"
    },
    {
      "verse": "10",
      "text": "Then Felix raised his hand towards Paul to show that he should speak. So Paul said to Felix, ‘I know that you have judged the people in this region for many years. So now I am happy to tell you everything."
    },
    {
      "verse": "11",
      "text": "days ago. You can check that that is true. I went there to worship God."
    },
    {
      "verse": "12",
      "text": "When the Jews saw me in the temple, I was not arguing with anyone. I was not causing trouble among Jewish people in their meeting places. Nor did I cause problems in any other places in Jerusalem."
    },
    {
      "verse": "13",
      "text": "They have said bad things against me. But they cannot show you that these things are true."
    },
    {
      "verse": "14",
      "text": "What I do agree is this: I worship the same God that our Jewish ancestors worshipped. But I do this in the Way that Jesus has taught us. These men say that this is not the right way. But I believe in all God's Law that Moses wrote for us. I also believe in the messages that God's prophets have written in the Bible."
    },
    {
      "verse": "15",
      "text": "I also trust God like these men do. Like them, I believe that people will become alive again after death. God will do this for all people, both good people and bad people."
    },
    {
      "verse": "16",
      "text": "Because of that, I always try to do what is right. I do not want to do anything bad against God or against other people."
    },
    {
      "verse": "17",
      "text": "I had not been to Jerusalem for several years. Now I returned there with a gift of some money. I brought it to give to poor people who are Jews, like me. I also wanted to offer sacrifices to God."
    },
    {
      "verse": "18",
      "text": "I was doing this in the yard of the temple when these men found me. I had obeyed all the rules to make myself clean in front of God. There was no crowd with me. Nobody was arguing or fighting because of me."
    },
    {
      "verse": "19",
      "text": "But there were some Jews there who had come from Asia. They are the people who caused the trouble. Maybe they have something bad to say against me. They themselves should come here to speak to you about it."
    },
    {
      "verse": "20",
      "text": "Or these men here should tell you what wrong thing I have done. I stood in front of the meeting of the Jewish leaders and they asked me questions."
    },
    {
      "verse": "21",
      "text": "When I stood there, I shouted, “I believe that dead people will rise and they will live again. That is the reason why you are judging me today. ” They may think that is a wrong thing that I did. ’"
    },
    {
      "verse": "22",
      "text": "Felix knew much about the Way of the Lord Jesus. He now said that the meeting had finished. He said to Paul, ‘Soon Lysias, the leader of the soldiers, will arrive here. Then I will decide what to do with you. ’"
    },
    {
      "verse": "23",
      "text": "He said to the officer who was holding Paul, ‘Continue to guard this man carefully. But his friends can come and see him. They can help him and they can bring things for him. ’"
    },
    {
      "verse": "24",
      "text": "After some days, Felix came with Drusilla, his Jewish wife. He told his soldiers to bring Paul to them. Paul talked to them, and they listened to everything that he said. Paul spoke about how people believed in Jesus, the Messiah."
    },
    {
      "verse": "25",
      "text": "Paul continued to speak for some time. He said, ‘People need to do what is right. They need to stop themselves doing wrong things. One day, God will judge people for how they have lived. ’While Paul talked about these things, Felix became afraid. He said to Paul, ‘You can leave us now. At some time I may want to listen to you again. Then I will ask you to come to me again. ’"
    },
    {
      "verse": "26",
      "text": "But Felix also hoped that Paul would give him some money. For that reason he often met with Paul and they talked together."
    },
    {
      "verse": "27",
      "text": "This happened for two years. Felix left Paul in the prison, because he wanted to make the Jewish leaders happy. Then Porcius Festus became the ruler instead of Felix."
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "Three days after Festus began to rule in Caesarea, he travelled from there to Jerusalem."
    },
    {
      "verse": "2",
      "text": "When he arrived there, the leaders of the priests and the Jewish leaders told him about Paul. They spoke bad things against Paul."
    },
    {
      "verse": "3",
      "text": "They said to Festus, ‘Please listen to us. We really want you to bring Paul here to Jerusalem. You can judge him here. Then we would be very happy. ’ They wanted to kill Paul while he was travelling to Jerusalem."
    },
    {
      "verse": "4",
      "text": "But Festus answered them, ‘Paul will remain in prison in Caesarea. I myself will return there soon."
    },
    {
      "verse": "5",
      "text": "So your leaders should go to Caesarea with me. If this man has done anything wrong, they can speak against him there. I will listen and I will judge. ’"
    },
    {
      "verse": "6",
      "text": "Festus stayed for another eight or ten days in Jerusalem. Then he returned to Caesarea. On the next day, he sat down on his special seat as judge. He said to his soldiers, ‘Bring Paul here! ’"
    },
    {
      "verse": "7",
      "text": "Some of the Jewish leaders had also come from Jerusalem. When Paul came into the room, they all stood round him. They began to speak to Festus against Paul. They said that he had done very many bad things. But they could not show Festus that these things were really true."
    },
    {
      "verse": "8",
      "text": "Then Paul spoke to show what was true. He said, ‘I have not done anything wrong against our Jewish laws or against the temple in Jerusalem. Also, I have not done anything wrong against your Roman ruler, Caesar. ’"
    },
    {
      "verse": "9",
      "text": "Festus wanted to make the Jewish leaders happy. So he asked Paul, ‘I would like to judge this problem in Jerusalem. Would you be happy to go there? Then I can decide if what these men are saying against you is true. ’"
    },
    {
      "verse": "10",
      "text": "Paul answered him, ‘I am already in the place where Caesar's officers judge people. This is the right place for you to judge me. I have never done anything wrong against the Jews. You yourself know very well that it is true."
    },
    {
      "verse": "11",
      "text": "Have I done something bad that you should kill me for it? If that is true, then I will agree to it. It is right that I should die. But these Jews are not speaking true words against me. Nobody should let them take hold of me. So now I ask you to send me to Caesar himself. I want him to be the judge. ’"
    },
    {
      "verse": "12",
      "text": "Festus talked to his officers about what Paul had said. Then he said to Paul, ‘You have asked to go to Caesar, for him to be your judge. So prepare yourself to go to Caesar! ’"
    },
    {
      "verse": "13",
      "text": "Several days after this, King Agrippa and Bernice came to Caesarea. They wanted to say ‘welcome’ to Festus as the new ruler."
    },
    {
      "verse": "14",
      "text": "They stayed in Caesarea for many days. While they were there, Festus explained to King Agrippa the problem about Paul. He said, ‘There is a man here that Felix left in prison."
    },
    {
      "verse": "15",
      "text": "When I went to Jerusalem, the important Jews and the leaders of their priests spoke to me about him. They said, “Paul has done some very bad things. You should judge him and he should die. ”"
    },
    {
      "verse": "16",
      "text": "I answered them, “You are saying that this man has done wrong things. He must first stand in front of you who are speaking against him. Then he can answer you, and I can judge who is right. That is what our Roman law says must happen. ”"
    },
    {
      "verse": "17",
      "text": "So when I came back here, the Jewish leaders and the leaders of their priests came with me. I did not wait for long. On the next day I sat down on my special seat as judge. I told my soldiers to bring this man to me."
    },
    {
      "verse": "18",
      "text": "The men who had spoken against him stood up. I thought they would say that Paul had done some very bad thing. But they did not say that."
    },
    {
      "verse": "19",
      "text": "Instead, they were arguing with Paul about what the Jews teach about God. They were arguing about a man who is called Jesus. Jesus had died. But Paul was saying that he is alive."
    },
    {
      "verse": "20",
      "text": "I did not know how I could judge all these problems. So I told Paul, “I want to take you to Jerusalem. Would you be happy to go there? Then I will listen to what these men are saying against you. I will judge there who is right. ”"
    },
    {
      "verse": "21",
      "text": "But Paul did not want to go to Jerusalem. He said to me, “Please keep me safe here in prison. Then send me to Caesar. He himself should decide what to do with me. ” So I said to my soldiers, “Guard Paul here until I send him to Caesar. ” ’"
    },
    {
      "verse": "22",
      "text": "Agrippa said to Festus, ‘I would like to hear this man myself. ’Festus replied, ‘You will hear him tomorrow. ’ Festus replied, ‘You will hear him tomorrow. ’"
    },
    {
      "verse": "23",
      "text": "The next day, King Agrippa and Bernice arrived in Caesarea's public meeting room. They wore beautiful clothes to show that they were great people. Some Roman soldiers' officers and important men in the city also arrived there. Festus said to his soldiers, ‘Bring Paul here to us! ’ So they brought Paul into the room."
    },
    {
      "verse": "24",
      "text": "Festus said, ‘King Agrippa, and everyone here today, listen to me! You see this man who is standing in front of you. Many Jews in Jerusalem, and also Jews here in Caesarea, have spoken to me about him. They say very loudly, “This man has done very bad things. He should not continue to live! ”"
    },
    {
      "verse": "25",
      "text": "But I could not find any reason to kill him. He has not done anything against our law. But he has asked for Caesar himself to judge him. So I have decided to send him to Rome."
    },
    {
      "verse": "26",
      "text": "But I do not know what to write about him to our ruler, Caesar. So I have brought him here to stand in front of all of you. I ask you, King Agrippa, to listen carefully to what Paul says. Then we can talk about the problem together. As a result, I will know what to write about him to Caesar."
    },
    {
      "verse": "27",
      "text": "I need to tell Caesar what wrong things this man has done. If I cannot do that, it would not be right to send him to Rome. ’"
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "King Agrippa said to Paul, ‘You may now say what you think about this problem. ’Paul raised his hand so that people would listen to him."
    },
    {
      "verse": "2",
      "text": "He said, ‘King Agrippa, I am happy that you are here. I ask you to listen to me today. These Jews say that I have done some bad things. I will explain to you what is really true about all these things."
    },
    {
      "verse": "3",
      "text": "You yourself know all about the Jews. You know about how we live. You also know the things that we argue about with each other. So please be patient and listen to me."
    },
    {
      "verse": "4",
      "text": "The Jewish people have known me since I was born. They all know how I have lived among them. They knew me in the region where I was born. When I came to Jerusalem, they also know how I lived there."
    },
    {
      "verse": "5",
      "text": "So they have known me for a long time. They could tell you that I always obeyed our Jewish laws. They know that I was a Pharisee. I carefully obeyed God's Law, as a Pharisee does. But maybe they do not want to tell you all that."
    },
    {
      "verse": "6",
      "text": "So what is the reason that I stand here today for you to judge me? It is because I believe in God's promise to our ancestors."
    },
    {
      "verse": "7",
      "text": "Israelite families. We all expect to receive what God has promised to us. That is why we Jews always worship God, in the day and in the night. Like these Jews here, I believe in God's great promise. But that is the reason that they speak against me."
    },
    {
      "verse": "8",
      "text": "Is it impossible for God to cause dead people to become alive again? You should surely believe me when I say that."
    },
    {
      "verse": "9",
      "text": "I myself wanted to work against Jesus, the man from Nazareth, and against his message."
    },
    {
      "verse": "10",
      "text": "That is what I was doing in Jerusalem. The leaders of the priests gave me authority to put many of the believers in prison. I agreed with our leaders when they said, “These people must die. ”"
    },
    {
      "verse": "11",
      "text": "I went to our Jewish meeting places to take hold of believers. I told my men to punish them. I tried to make the believers say bad things against God. I was very angry with them. So I even travelled to cities in other countries to punish them."
    },
    {
      "verse": "12",
      "text": "For that reason, one day I was travelling to Damascus. The leaders of the priests in Jerusalem had sent me there. They had given me authority to take hold of the believers there."
    },
    {
      "verse": "13",
      "text": "Listen to this, King Agrippa! I was travelling along the road at midday. Suddenly I saw a very bright light in the sky. It was much brighter than the sun. It shone all round me and also round the men who were with me."
    },
    {
      "verse": "14",
      "text": "All of us fell down to the ground. I heard a voice that spoke to me in my own language, Hebrew. He said “Saul, Saul, why do you fight against me? You are like an ox that kicks against its master's stick. So you are hurting yourself. ”"
    },
    {
      "verse": "15",
      "text": "“Lord, who are you? ” I asked. He replied, “I am Jesus. And you are fighting against me."
    },
    {
      "verse": "16",
      "text": "Now you must get up. Stand on your feet. I have chosen you to be my servant. That is why I have appeared to you today. You must tell other people about what you have seen. After that, I will show you other things that you must tell people."
    },
    {
      "verse": "17",
      "text": "I will send you to speak about me to Jews and to Gentiles. Some of them will want to hurt you. But I will keep you safe."
    },
    {
      "verse": "18",
      "text": "You will help them to understand what is really true. They are like people who live in the dark. Teach them what is true about me. Then they will be like people who live in the light. Now Satan has power over them. Lead them from there into God's kingdom. Then God will forgive them for the wrong things that they have done. Because they believe in me, God will accept them as his own people. ” ’"
    },
    {
      "verse": "19",
      "text": "‘So you should know this, King Agrippa. I obeyed the things that I heard from heaven that day."
    },
    {
      "verse": "20",
      "text": "First, I taught God's message to the Jews in Damascus. Then I also taught God's message to the Jews in Jerusalem and in all of Judea region. Later I also spoke to the Gentiles. I said to all of them, “You must stop doing wrong things. You must turn to God. You must do good things. That will show that you have really changed how you live. ”"
    },
    {
      "verse": "21",
      "text": "That is the reason that the Jews took hold of me in the yard of the temple. That is also the reason why they wanted to kill me."
    },
    {
      "verse": "22",
      "text": "But God has helped me every day, even until today. So now I stand here and I can tell you what is true. I say the same thing to people who are very important and to people who are not important. I am telling you the same things that Moses and God's other prophets wrote about. They also said that these things would happen."
    },
    {
      "verse": "23",
      "text": "They said that God's special Messiah would have much pain and he would die. But God would raise him up to be alive again. He would be the first dead person to become alive and not die again. In that way, he would show God's message and bring light to people. He would save both Jewish people and Gentiles. That is what the prophets and Moses wrote. And I say the same thing. ’"
    },
    {
      "verse": "24",
      "text": "While Paul was still speaking to Agrippa, Festus shouted at him, ‘Paul, your mind is confused! You have learned many things. But all these things are making you crazy. ’"
    },
    {
      "verse": "25",
      "text": "Paul said, ‘Festus, sir, I am not crazy. Everything that I have said is true. It is not difficult to understand."
    },
    {
      "verse": "26",
      "text": "King Agrippa knows about these things. He understands what I am talking about. None of these things happened in secret places. So I am sure that he has heard news about all this."
    },
    {
      "verse": "27",
      "text": "King Agrippa, do you believe what God's prophets taught? I know that you do believe them. ’"
    },
    {
      "verse": "28",
      "text": "Then Agrippa said to Paul, ‘Can you change what I believe in this short time? Should I become a Christian already? Is that what you think? ’"
    },
    {
      "verse": "29",
      "text": "Paul answered him, ‘It is not important if it takes a long time or a short time. I pray to God for you and for everyone who is listening to me today. I pray that you may all become like me. But I would not want you to become a prisoner like me! ’"
    },
    {
      "verse": "30",
      "text": "Then King Agrippa, the ruler Festus, and Bernice all got ready to leave. Everyone else there also stood up."
    },
    {
      "verse": "31",
      "text": "After they left the meeting room, they said to each other, ‘This man has not done anything bad. We should not kill him, or even hold him in prison. ’"
    },
    {
      "verse": "32",
      "text": "King Agrippa said to Festus, ‘We could have let this man go free from the prison. But he has asked that Caesar should judge him. So we cannot let him go free. ’"
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "Some time after that, Festus decided that we should sail to Italy. So he commanded a soldier called Julius to guard Paul and some other prisoners. Julius was an officer in the Roman army. He had authority over 100 soldiers in a group called ‘The Emperor Augustus Group’."
    },
    {
      "verse": "2",
      "text": "We went onto a ship that had come from Adramyttium. This ship was ready to leave. It would sail to the towns on the coast of Asia region. A man called Aristarchus also sailed with us. He came from a city in Macedonia called Thessalonica."
    },
    {
      "verse": "3",
      "text": "The next day after we left Caesarea, we arrived at Sidon. Julius was kind to Paul. He said, ‘Paul, you can go and visit your friends here. They can give you anything that you need. ’"
    },
    {
      "verse": "4",
      "text": "Then we sailed out across the sea again. But the wind was blowing against our ship. So we sailed round the island called Cyprus. We sailed on the side of the island where the wind was not strong."
    },
    {
      "verse": "5",
      "text": "When we were near to Cilicia and Pamphylia, we sailed straight across the sea. Then we arrived at Myra, in the region called Lycia."
    },
    {
      "verse": "6",
      "text": "The Roman officer found another ship there. It had sailed from Alexandria and it would sail to Italy. So the officer put us on this ship."
    },
    {
      "verse": "7",
      "text": "We sailed slowly for several days. It was difficult to sail, but after some time we arrived near the town of Cnidus. Because of the strong wind, we could not continue to sail in that direction. So we sailed along the side of the island called Crete, where the wind was not strong. We sailed past the point of land called Salmone."
    },
    {
      "verse": "8",
      "text": "It was still difficult to sail, so we sailed near to the coast. Then we arrived at a place called ‘Safe Port’. This port was near to the town of Lasea."
    },
    {
      "verse": "9",
      "text": "We remained there for many days. By then it had become dangerous to continue the journey. It was already after the Day of Atonement. So Paul spoke to the army officer and to the sailors."
    },
    {
      "verse": "10",
      "text": "He said, ‘Friends, I understand that now our journey will be dangerous. The ship may break in pieces. You may lose the things that the ship is carrying. All of us may even die. ’"
    },
    {
      "verse": "11",
      "text": "But the army officer did not believe what Paul said. Instead, he decided to do what the owner of the ship and the captain said."
    },
    {
      "verse": "12",
      "text": "This port was not a good place for a ship to remain during the winter. Most of the men on the ship wanted to continue the journey. They wanted to sail as far as Phoenix, if they could get there. They could stay there for the winter. Phoenix was a port on the island called Crete. It was open to the sea both to the south-west and to the north-west."
    },
    {
      "verse": "13",
      "text": "The wind began to blow from the south, but it was not strong. So the sailors thought, ‘Now we can do what we wanted to do. We can sail to Phoenix. ’ So they pulled up the ship's anchor and left the port. Then we sailed as near as we could to the coast of Crete."
    },
    {
      "verse": "14",
      "text": "But soon a very strong wind began to blow. This wind blew from the north-east and it blew strongly across the island."
    },
    {
      "verse": "15",
      "text": "The storm hit the ship very powerfully. It was not possible for the sailors to sail the ship straight into the wind. So they did not try to do that any more. Instead, they let the wind blow the ship along."
    },
    {
      "verse": "16",
      "text": "After that, we passed the south end of a small island called Cauda. Here we found a place where the wind did not blow so strongly. The sailors lifted the ship's small boat out of the water to make it safe."
    },
    {
      "verse": "17",
      "text": "They tied it on the ship with ropes. Then they tied some more ropes under the ship so that it would not break in pieces. The men were afraid of what might happen. There were some places along the coast of Libya where the water was not very deep. The ship might hit one of these places and then it might break. So they took the ship's largest sail down. Then they let the wind blow the ship along."
    },
    {
      "verse": "18",
      "text": "The strong storm continued to blow against the ship. The ship was carrying many things. So the next day, the sailors threw some of these things into the sea."
    },
    {
      "verse": "19",
      "text": "The day after that, they took hold of the sails and ropes and they threw them into the sea."
    },
    {
      "verse": "20",
      "text": "For many days, we did not see the sun or any stars. The storm continued to blow strongly. So then we thought, ‘It is not possible for us to remain alive. ’"
    },
    {
      "verse": "21",
      "text": "The men on the ship had not eaten any food for a long time. So Paul stood in front of them and he said, ‘Men, you should have listened to me! We should not have sailed away from Crete. If we had not left there, the ship and everything on it would still be safe."
    },
    {
      "verse": "22",
      "text": "Now I ask you, please be brave. The storm will completely destroy the ship, but not one of you will die."
    },
    {
      "verse": "23",
      "text": "Last night one of God's angels spoke to me. I am a servant of God and I belong to him. He sent his angel to come to me."
    },
    {
      "verse": "24",
      "text": "The angel said, “Paul, do not be afraid. You must go to Rome and Caesar will judge you there. Because of you, God will be kind to all the people on the ship with you. None of them will die. ”"
    },
    {
      "verse": "25",
      "text": "Because of the angel's message, I say to you, “Be brave, my friends! ” I trust God. I know that everything will happen in the way that the angel told me."
    },
    {
      "verse": "26",
      "text": "But the wind will blow the ship so that we hit an island. ���"
    },
    {
      "verse": "27",
      "text": "days and nights. The strong wind was blowing the ship across the Mediterranean Sea. About midnight, the sailors thought that we were near to the land."
    },
    {
      "verse": "28",
      "text": "So they used a rope to measure how deep the water was. They saw that the water was nearly 40 metres deep. A short time later they did this again. This time the water was only 30 metres deep."
    },
    {
      "verse": "29",
      "text": "The sailors were afraid that the ship would hit some rocks. So they dropped four anchors on ropes from the back of the ship into the sea. After that, they prayed that dawn would come soon."
    },
    {
      "verse": "30",
      "text": "Some of the sailors tried to leave the ship. They put the small boat into the sea. They tried to go away secretly. They said, ‘We are going to the front of the ship to put some more anchors down into the sea. ’ But that was not true."
    },
    {
      "verse": "31",
      "text": "Paul said to the army officer and to the soldiers, ‘These sailors must stay on the ship. If they do not stay, you will not be safe. You will die. ’"
    },
    {
      "verse": "32",
      "text": "So the soldiers cut the ropes that held the small boat to the ship. The small boat fell into the water and the wind blew it away."
    },
    {
      "verse": "33",
      "text": "Now it was almost dawn. Paul said to everyone, ‘Please eat some food. You have now waited for 14 days for the storm to stop. You did not know what would happen. You have not eaten anything during all that time."
    },
    {
      "verse": "34",
      "text": "You must eat some food now. Then you will be strong enough to stay alive. None of you will die. You will not even lose one hair from your head. ’"
    },
    {
      "verse": "35",
      "text": "After Paul said this, he took some bread in his hands. He stood in front of them all and he thanked God for the bread. Then he broke the bread into pieces and he began to eat it."
    },
    {
      "verse": "36",
      "text": "Everyone became less afraid and we all ate some food."
    },
    {
      "verse": "37",
      "text": "people on the ship."
    },
    {
      "verse": "38",
      "text": "After everyone had eaten enough, the sailors threw bags of wheat off the ship into the sea. Then the ship was not so heavy."
    },
    {
      "verse": "39",
      "text": "In the morning, the ship was near to some land, but the sailors did not recognize the place. They saw a place on the shore where there was a lot of sand. They wanted to drive the ship onto the sand."
    },
    {
      "verse": "40",
      "text": "So the sailors cut the ropes which had the anchors on them. They left the anchors there in the sea. They also removed the ropes which had tied the rudders. Then they raised the sail at the front of the ship. Now the wind could blow the ship straight towards the shore."
    },
    {
      "verse": "41",
      "text": "But there was a place in the sea where the water was not deep. The ship sailed onto the sand in this place and it stayed there. The front of the ship pushed into the sand and it could not move. The sea was very strong and it hit against the back of the ship. As a result, the back of the ship broke into pieces."
    },
    {
      "verse": "42",
      "text": "The soldiers decided to kill the prisoners that they were guarding. They did not want these men to swim to the land and escape. In this way all of us got safely out of the sea and we arrived on the land."
    },
    {
      "verse": "43",
      "text": "But the army officer wanted to save Paul. So he commanded the soldiers not to kill the men. Instead he said, ‘Everyone who can swim, jump into the water first. Then swim to the shore."
    },
    {
      "verse": "44",
      "text": "You other people must follow them. Hold on to pieces of wood, or pieces of the ship. ’In this way all of us got safely out of the sea and we arrived on the land."
    }
  ],
  "28": [
    {
      "verse": "1",
      "text": "So then we were on the shore and we were all safe. We discovered that the island was called Malta."
    },
    {
      "verse": "2",
      "text": "The people who lived on the island were very kind to us. Rain was falling and the weather was cold. So the people lit a fire and they helped all of us."
    },
    {
      "verse": "3",
      "text": "Paul picked up some small branches to put on the fire. When he did this, a dangerous snake came out from among the sticks. It had felt the heat from the fire. The snake bit Paul's hand and it held on to it."
    },
    {
      "verse": "4",
      "text": "The people who lived on the island saw the snake. They saw that it was hanging from Paul's hand. So they said to each other, ‘We know now that this man murdered someone. He did not die in the sea but now the snake will kill him. The god who punishes people for the bad things that they do will not let him live. ’"
    },
    {
      "verse": "5",
      "text": "Then Paul waved his hand about so that the snake fell off into the fire. The snake had not hurt Paul in any way."
    },
    {
      "verse": "6",
      "text": "So the people watched Paul carefully. They thought that his body would become very sick. They thought that he might die suddenly. They waited for a long time. But they did not see anything bad happen to Paul. So then they thought something different about Paul. They said, ‘This man is certainly a god! ’"
    },
    {
      "verse": "7",
      "text": "There was an important officer who ruled the island. He was called Publius. He had some fields near to the shore where we had made the fire. He was very kind to us. He asked us to stay in his house. We stayed there for three days."
    },
    {
      "verse": "8",
      "text": "Publius's father was lying in bed because he was ill. His body was hot and he was very sick. Paul went into his room to see him. Paul prayed for him and he put his hands on the man's head. As a result, the man became well again."
    },
    {
      "verse": "9",
      "text": "After Paul did this, the other sick people on the island came to him. He caused them also to become well again."
    },
    {
      "verse": "10",
      "text": "The people gave us many gifts. Later, we got ready to leave the island on another ship. They gave us the things that we needed for the journey."
    },
    {
      "verse": "11",
      "text": "When we left Malta, we had been there for three months. We got on a ship that was called ‘The Twin Gods’. It had come from Alexandria and it had stayed in Malta during the winter."
    },
    {
      "verse": "12",
      "text": "We sailed across the sea and we arrived at the city of Syracuse. We stayed there for three days."
    },
    {
      "verse": "13",
      "text": "We left Syracuse and we sailed to the city of Rhegium. The next day, the wind began to blow from the south, so we sailed more quickly. The day after that, we arrived at the town of Puteoli."
    },
    {
      "verse": "14",
      "text": "We found some believers there. They asked us to stay with them for one week. After this we travelled to Rome."
    },
    {
      "verse": "15",
      "text": "The believers in Rome had heard about us. So they came out of the city to meet us at ‘The Market of Appius’ and ‘The Three Hotels’. When Paul saw the believers, he thanked God for them. He was very happy that they had come to meet him."
    },
    {
      "verse": "16",
      "text": "When we arrived in Rome, the Roman officer said to Paul, ‘You may live in a house by yourself, but a soldier will guard you there. ’"
    },
    {
      "verse": "17",
      "text": "After three days, Paul asked the leaders of the Jews in Rome to meet with him. When they met together, Paul said to them, ‘Friends, I am a Jew as you are. I tell you that I have never done anything bad against our people. I have always obeyed the rules that our ancestors gave to us. But the Jewish leaders in Jerusalem took hold of me. They gave me to the Roman rulers so that they would judge me."
    },
    {
      "verse": "18",
      "text": "The Roman rulers asked me questions about what I had done. They discovered that I had not done anything wrong. There was no reason that they should kill me. So they wanted to let me go free."
    },
    {
      "verse": "19",
      "text": "But the Jewish leaders in Jerusalem did not agree with that. So then I asked the Roman rulers to send me here to Rome. I wanted Caesar himself to judge me. That was the only thing that I could do. I did not want to say anything bad against my own people."
    },
    {
      "verse": "20",
      "text": "That is why I want to talk with you now. I want to tell you why I am a prisoner here. It is because I believe in the one that God promised to send to us who are Jews. ’"
    },
    {
      "verse": "21",
      "text": "The Jewish leaders said to Paul, ‘We have not received any letters about you from Judea. Our Jewish friends who have come here from Judea have not told us this news. They have not said anything bad about you."
    },
    {
      "verse": "22",
      "text": "But we know that people everywhere are saying bad things about your new group. So we would like you to tell us your ideas. ’"
    },
    {
      "verse": "23",
      "text": "So the Jewish leaders in Rome chose a day to meet again with Paul. When that day arrived, a large number of Jews came to the house where Paul was staying. Paul talked to them from the morning until the evening. He explained his message about the kingdom of God. He showed them what Moses and the other prophets had written in the Bible. He tried to show them that Jesus was God's special Messiah."
    },
    {
      "verse": "24",
      "text": "Some of them believed that Paul's message was true. But other Jews who were there would not believe him."
    },
    {
      "verse": "25",
      "text": "They argued about it with each other. When they began to leave the house, Paul said, ‘The Holy Spirit spoke a true message to your ancestors. He gave this message to Isaiah, the prophet:"
    },
    {
      "verse": "26",
      "text": "“Go and say to this people, ‘You will listen and listen. But you will not understand. You will look and look. But you will not see anything. ’ ‘You will listen and listen. But you will not understand. You will look and look. But you will not see anything. ’"
    },
    {
      "verse": "27",
      "text": "These people do not really want to understand. They are like people who have shut their ears. They are like people who have shut their eyes. If they did want to look, then they would really see. If they did want to listen, then they would really hear. They would understand my message. They would turn back to me and they would obey me. Then I would forgive them and I would make them well. ” ’ They are like people who have shut their ears. They are like people who have shut their eyes. If they did want to look, then they would really see. If they did want to listen, then they would really hear. They would understand my message. They would turn back to me and they would obey me. Then I would forgive them and I would make them well. ” ’"
    },
    {
      "verse": "28",
      "text": "Paul then said to the Jews there, ‘You do not want to listen to God's message. But the Gentiles will listen! They will understand how God will save them. ’"
    },
    {
      "verse": "29",
      "text": "[After Paul had said this, the Jews left. They were still arguing with each other. ]"
    },
    {
      "verse": "30",
      "text": "Paul lived in a house in Rome for two years. He paid money to live in the house. Many people came to visit him there. He was very happy to see them all."
    },
    {
      "verse": "31",
      "text": "He told people clearly about the kingdom of God. He taught them about the Lord Jesus Christ. He was not afraid to speak strongly. Nobody tried to stop him."
    }
  ]
};