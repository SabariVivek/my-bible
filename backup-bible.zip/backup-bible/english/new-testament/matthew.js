module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This is a list of the ancestors of Jesus Christ. Jesus was from the family of King David. David was from the family of Abraham."
    },
    {
      "verse": "2",
      "text": "Abraham was the father of Isaac. Isaac was the father of Jacob. Jacob was the father of Judah and his brothers. Isaac was the father of Jacob. Jacob was the father of Judah and his brothers."
    },
    {
      "verse": "3",
      "text": "Judah was the father of Perez and Zerah. Tamar was their mother. Perez was the father of Hezron. Hezron was the father of Ram. Perez was the father of Hezron. Hezron was the father of Ram."
    },
    {
      "verse": "4",
      "text": "Ram was the father of Amminadab. Amminadab was the father of Nahshon. Nahshon was the father of Salmon. Amminadab was the father of Nahshon. Nahshon was the father of Salmon."
    },
    {
      "verse": "5",
      "text": "Salmon was the father of Boaz. Rahab was his mother. Boaz was the father of Obed. Ruth was his mother. Obed was the father of Jesse. Boaz was the father of Obed. Ruth was his mother. Obed was the father of Jesse."
    },
    {
      "verse": "6",
      "text": "Jesse was the father of King David. David was Solomon's father. Solomon's mother was the wife of Uriah. David was Solomon's father. Solomon's mother was the wife of Uriah."
    },
    {
      "verse": "7",
      "text": "Solomon was the father of Rehoboam. Rehoboam was the father of Abijah. Abijah was the father of Asa. Rehoboam was the father of Abijah. Abijah was the father of Asa."
    },
    {
      "verse": "8",
      "text": "Asa was the father of Jehoshaphat. Jehoshaphat was the father of Jehoram. Jehoram was the father of Uzziah. Jehoshaphat was the father of Jehoram. Jehoram was the father of Uzziah."
    },
    {
      "verse": "9",
      "text": "Uzziah was the father of Jotham. Jotham was the father of Ahaz. Ahaz was the father of Hezekiah. Jotham was the father of Ahaz. Ahaz was the father of Hezekiah."
    },
    {
      "verse": "10",
      "text": "Hezekiah was the father of Manasseh. Manasseh was the father of Amon. Amon was the father of Josiah. Manasseh was the father of Amon. Amon was the father of Josiah."
    },
    {
      "verse": "11",
      "text": "Josiah was the father of Jeconiah and his brothers. This was at the time when the Israelites' enemies took them away to Babylon. This was at the time when the Israelites' enemies took them away to Babylon."
    },
    {
      "verse": "12",
      "text": "Here is a list of Jesus' ancestors who lived after that time: Jeconiah was the father of Shealtiel. Shealtiel was the father of Zerubbabel. Jeconiah was the father of Shealtiel. Shealtiel was the father of Zerubbabel."
    },
    {
      "verse": "13",
      "text": "Zerubbabel was the father of Abiud. Abiud was the father of Eliakim. Eliakim was the father of Azor. Abiud was the father of Eliakim. Eliakim was the father of Azor."
    },
    {
      "verse": "14",
      "text": "Azor was the father of Zadok. Zadok was the father of Akim. Akim was the father of Eliud. Zadok was the father of Akim. Akim was the father of Eliud."
    },
    {
      "verse": "15",
      "text": "Eliud was the father of Eleazar. Eleazar was the father of Matthan. Matthan was the father of Jacob. Eleazar was the father of Matthan. Matthan was the father of Jacob."
    },
    {
      "verse": "16",
      "text": "Jacob was the father of Joseph. Joseph married Mary. Mary was the mother of Jesus. Jesus is the one who is called Christ, the Messiah. Joseph married Mary. Mary was the mother of Jesus. Jesus is the one who is called Christ, the Messiah."
    },
    {
      "verse": "17",
      "text": "So then, there were 14 generations from Abraham to David. There were another 14 generations from David to the time they took the Israelite people away to Babylon. Then there were 14 generations from that time until Jesus, the Messiah, was born."
    },
    {
      "verse": "18",
      "text": "This is how Jesus Christ was born. His mother's name was Mary. She had promised to marry a man called Joseph. Then she discovered that she was pregnant. This happened before they started to live together. It was the Holy Spirit that caused this to happen to her."
    },
    {
      "verse": "19",
      "text": "Joseph was a good man. He wanted to do what was right. He did not want her to become ashamed in front of people. So he decided to stop their marriage secretly."
    },
    {
      "verse": "20",
      "text": "He thought about what he should do. Then an angel came from the Lord God to see him. The angel came to Joseph while he was dreaming. The angel said, ‘Joseph, you who are from the family of King David, take Mary home as your wife. Do not be afraid to do that. The baby that is growing inside her is from the Holy Spirit."
    },
    {
      "verse": "21",
      "text": "Mary's baby will be a boy. He will save his people from their sins. Because of that, you must give him the name “Jesus”. ’"
    },
    {
      "verse": "22",
      "text": "The Lord God had given a message about this to one of his prophets long ago. Now that message would become true."
    },
    {
      "verse": "23",
      "text": "The prophet had said, ‘A young woman who has never had sex will have a baby boy. People will call her son Immanuel. ’ This name means ‘God is with us’."
    },
    {
      "verse": "24",
      "text": "Then Joseph woke up from his sleep. He did what God's angel had said to him. He married Mary and he took her to his home."
    },
    {
      "verse": "25",
      "text": "Joseph did not have sex with Mary until after the baby boy was born. He said that the boy's name should be Jesus."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Jesus was born in a town called Bethlehem, in Judea. King Herod ruled Judea at that time. After Jesus was born, some wise men came to Jerusalem from a country in the east."
    },
    {
      "verse": "2",
      "text": "When they arrived there, they asked people, ‘Where is the baby who has been born as the king of the Jews? We saw his special star when it first appeared in the sky. So now we have come here to worship him. ’"
    },
    {
      "verse": "3",
      "text": "When King Herod heard what the men said, he was very upset. All the people in Jerusalem were afraid too."
    },
    {
      "verse": "4",
      "text": "Then Herod asked all the leaders of the priests and the teachers of God's Law to meet with him. He asked them, ‘Where will God's Messiah be born? ’"
    },
    {
      "verse": "5",
      "text": "They replied, ‘The Messiah will be born in Bethlehem in Judea. This is what the prophet wrote about it:"
    },
    {
      "verse": "6",
      "text": "“People who live in Bethlehem, your town is a very important town in Judea. A person born in your town will become a leader of my people Israel. He will lead my people like a shepherd leads his sheep. ” ’ your town is a very important town in Judea. A person born in your town will become a leader of my people Israel. He will lead my people like a shepherd leads his sheep. ” ’"
    },
    {
      "verse": "7",
      "text": "Then Herod secretly told the wise men to come to meet with him. They told him the time that the star had appeared."
    },
    {
      "verse": "8",
      "text": "Herod sent the men to Bethlehem. He said to them, ‘Go and look everywhere for this child. When you find him, come back here and tell me where he is. Then I can also go and worship him. ’"
    },
    {
      "verse": "11",
      "text": "The men went into the house and they saw the child. He was with Mary, his mother. They went down on their knees in front of the child and they worshipped him. Then they opened their bags. They took out valuable gifts and they gave them to the child. The gifts were gold, incense called frankincense, and also myrrh."
    },
    {
      "verse": "12",
      "text": "After that, God said to them in a dream, ‘Do not go back to see Herod again. ’ So the men followed a different road to return to their own country."
    },
    {
      "verse": "13",
      "text": "After the men had gone away, Joseph had a dream. In the dream, he saw one of the Lord God's angels. The angel said to him, ‘Herod will look for the child, so that his soldiers can kill him. You must get up and take the child and his mother with you. Go immediately to Egypt. I will tell you when you can return again. You must remain there until then. ’"
    },
    {
      "verse": "14",
      "text": "So Joseph got up and he took the child and his mother with him. They started on the journey to Egypt that night."
    },
    {
      "verse": "15",
      "text": "They all remained in Egypt until Herod died. This happened so that the words of the prophet would become true. The Lord God had said by his prophet, ‘I have called my son to come out of Egypt. ’"
    },
    {
      "verse": "16",
      "text": "When the wise men did not return to Herod, he was very angry. He knew that they had deceived him. So he sent his men to Bethlehem. He said to them, ‘Kill all the baby boys in Bethlehem. Kill the boys who live near there too. Kill all the boys who are two years old or younger than that. ’ The wise men had told Herod how long ago they had first seen the special star. So he decided to kill the baby boys of that age."
    },
    {
      "verse": "17",
      "text": "In this way, these words that God's prophet Jeremiah spoke long ago became true:"
    },
    {
      "verse": "18",
      "text": "‘People heard a sad noise in Ramah. Someone is weeping with a loud voice. It is Rachel and she is weeping for her children. Nobody can help her to stop weeping, because her children are dead. ’ Someone is weeping with a loud voice. It is Rachel and she is weeping for her children. Nobody can help her to stop weeping, because her children are dead. ’"
    },
    {
      "verse": "19",
      "text": "After Herod died, Joseph had a dream in Egypt. In the dream he saw one of the Lord God's angels."
    },
    {
      "verse": "20",
      "text": "The angel said to Joseph, ‘Get up. The people who wanted to kill the child are dead. Take the child and his mother. You can now return with them to Israel. ’"
    },
    {
      "verse": "21",
      "text": "So Joseph got up. He took the child and his mother and they travelled to Israel."
    },
    {
      "verse": "22",
      "text": "But then Joseph heard that Herod's son, Archelaus, was now king of Judea instead of his father. So Joseph was afraid to go to Judea. In another dream God showed Joseph that he should go to Galilee instead."
    },
    {
      "verse": "23",
      "text": "So Joseph went there and he lived in a town called Nazareth. Long ago God's prophets had said about God's Messiah, ‘He will be called a person from Nazareth. ’ Now this had become true."
    },
    {
      "verse": "9",
      "text": "After the men had heard the king, they left to go to Bethlehem. They could see the same star that they had seen before. They were very happy when they saw the star."
    },
    {
      "verse": "10",
      "text": "It moved along in front of them. Then it stopped above the place where the child was staying."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "While Jesus still lived in Nazareth, a man called John the Baptist was speaking a message from God. He was doing this in the wilderness in Judea."
    },
    {
      "verse": "2",
      "text": "He told people, ‘You have done many wrong things. You must turn away from them and change how you live. Do this now, because the kingdom of heaven has come very near. ’"
    },
    {
      "verse": "3",
      "text": "God's prophet Isaiah spoke about this man John long ago. He said:‘Somebody's voice is shouting in the wilderness, “The Lord will come soon, so prepare a way for him to follow. Make the paths straight for him. ” ’ ‘Somebody's voice is shouting in the wilderness, “The Lord will come soon, so prepare a way for him to follow. Make the paths straight for him. ” ’"
    },
    {
      "verse": "4",
      "text": "John wore clothes made from the hair of a camel. He also wore a belt made from leather. His usual food was locusts and honey from the wilderness."
    },
    {
      "verse": "5",
      "text": "Many people went to listen to John. They lived in Jerusalem and all over the country called Judea and many other places near the Jordan River."
    },
    {
      "verse": "6",
      "text": "The people told God about all the wrong things that they had done. Then John baptized them in the Jordan River."
    },
    {
      "verse": "7",
      "text": "Many Pharisees and Sadducees came to John. They wanted John to baptize them. He said to them, ‘You are like dangerous snakes. God is angry. You are trying to run away from him. But he will soon punish people like you."
    },
    {
      "verse": "8",
      "text": "You have to show that you are sorry. Change how you live. Stop doing things that God does not like."
    },
    {
      "verse": "9",
      "text": "Do not say to yourselves, “We are in the family of Abraham. God will surely not punish us. ” Listen! God can take these stones and make children for Abraham out of them!"
    },
    {
      "verse": "10",
      "text": "You are like trees that have bad fruit. God has an axe ready to use. He will cut down every tree that does not make good fruit. He will throw those trees into the fire."
    },
    {
      "verse": "11",
      "text": "I baptize you with water. This shows that you want to change the way that you live. But another person will come soon. He is greater than I am. I am not good enough even to carry his shoes for him. This other person will baptize you with the Holy Spirit and with fire."
    },
    {
      "verse": "12",
      "text": "He is like a farmer that brings the wheat home from his field. He uses a special tool to throw the wheat up in the air. He does this to make the wheat seeds separate from what remains. Then he cleans his yard. He carefully stores all the seeds to keep them safe. But he burns everything else in a great fire that nobody can put out. ’"
    },
    {
      "verse": "13",
      "text": "Then Jesus went from Galilee to the Jordan River. He wanted John to baptize him."
    },
    {
      "verse": "14",
      "text": "But John tried to stop him. He said to Jesus, ‘I should ask you to baptize me. You should not ask me to baptize you. ’"
    },
    {
      "verse": "15",
      "text": "Jesus replied, ‘This time, do what I ask you to do. We must do everything correctly, as God wants it. ’ So John did what Jesus asked him to do."
    },
    {
      "verse": "16",
      "text": "When John baptized him, Jesus came up out of the water. At that moment, the skies opened. Jesus saw God's Spirit coming down. He came down like a dove and he stayed on Jesus."
    },
    {
      "verse": "17",
      "text": "Then a voice spoke from heaven, which said, ‘This man is my Son and I love him. He makes me very happy. ’"
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Then the Holy Spirit led Jesus into the wilderness. While he was there, the Devil came to him. He tried to cause Jesus to do wrong things."
    },
    {
      "verse": "2",
      "text": "days and 40 nights. At the end of this time, he was very hungry."
    },
    {
      "verse": "3",
      "text": "Then the Devil came to Jesus and said to him, ‘If you are the Son of God, speak to these stones. Tell them to become bread. ’"
    },
    {
      "verse": "4",
      "text": "But Jesus replied, ‘No! The Bible says that food alone cannot cause people to live. They need to hear every word that God speaks. That is what gives them true life. ’"
    },
    {
      "verse": "5",
      "text": "Then the Devil led Jesus to Jerusalem. He made him stand on the highest part of the temple. “God will tell his angels to keep you safe. They will hold you safely in their hands. They will not let you hurt your foot on a stone”. ’"
    },
    {
      "verse": "6",
      "text": "He said to Jesus, ‘If you are the Son of God, jump down from here to the ground. You know that the Bible says:“God will tell his angels to keep you safe. They will hold you safely in their hands. They will not let you hurt your foot on a stone”. ’"
    },
    {
      "verse": "7",
      "text": "Jesus replied, ‘No! The Bible also says, “Do not test the Lord God, to see if he will save you”. ’"
    },
    {
      "verse": "8",
      "text": "Then the Devil led Jesus up a very high mountain. He showed Jesus all the countries in the whole world. They were very great and beautiful."
    },
    {
      "verse": "9",
      "text": "The Devil said, ‘I will give you power over all these countries. Just go down on your knees in front of me. Worship me and I will give it all to you. ’"
    },
    {
      "verse": "10",
      "text": "Jesus then said to him, ‘Satan, go away from me! The Bible says, “Only worship your Lord God. He is the only one that you should obey”. ’"
    },
    {
      "verse": "11",
      "text": "Then the Devil left Jesus alone. Immediately angels came to Jesus and they took care of him."
    },
    {
      "verse": "12",
      "text": "Then Jesus heard that Herod had put John the Baptist in prison. So Jesus returned to Galilee."
    },
    {
      "verse": "13",
      "text": "But he did not stay in Nazareth. He went to live in Capernaum, which is a town on the shore of Lake Galilee. It was in the part of Israel called Zebulun and Naphtali."
    },
    {
      "verse": "14",
      "text": "This caused God's message to become true. Long ago God had said through his prophet Isaiah:"
    },
    {
      "verse": "15",
      "text": "‘I am speaking to you people who live in Zebulun and Naphtali. Your part of this country is on the way to Lake Galilee. It is across the Jordan River in the part of the country called Galilee. Some people who are not Jews live there. Your part of this country is on the way to Lake Galilee. It is across the Jordan River in the part of the country called Galilee. Some people who are not Jews live there."
    },
    {
      "verse": "16",
      "text": "They are like people who are living in the dark. They live in the shadow which death brings. God will send a light to shine on them. ’ They live in the shadow which death brings. God will send a light to shine on them. ’"
    },
    {
      "verse": "17",
      "text": "Then Jesus began to speak God's message to people. He said, ‘You have done many wrong things. You must turn away from them and change how you live. Do this now, because the kingdom of heaven has come very near. ’"
    },
    {
      "verse": "18",
      "text": "One day, Jesus was walking along the shore of Lake Galilee. He saw two men who were brothers. One man was called Simon, and he was also called Peter. His brother's name was Andrew. Their job was to catch fish. They were throwing their nets into the lake to catch fish."
    },
    {
      "verse": "19",
      "text": "Jesus said to them, ‘Come with me and be my disciples. Then I will teach you how to catch people, instead of fish. ’"
    },
    {
      "verse": "20",
      "text": "Simon and Andrew immediately put their nets down and they went with Jesus."
    },
    {
      "verse": "21",
      "text": "They continued to walk along the shore. Soon Jesus saw two more men who were brothers. They were called James and John. They were in their boat with their father, Zebedee. They were mending their nets. Jesus said to James and John, ‘Come with me. ’"
    },
    {
      "verse": "22",
      "text": "The brothers immediately left the boat and their father behind. They went with Jesus to be his disciples."
    },
    {
      "verse": "23",
      "text": "Jesus travelled everywhere in Galilee. He taught the people in the Jewish meeting places. He told them the good news about God's kingdom. He also caused sick people to become well again from all their different pains and illnesses."
    },
    {
      "verse": "24",
      "text": "More and more people in all parts of Syria heard about Jesus. So they brought all the sick people to see him. These people had many different illnesses, and some of them had strong pains. Bad spirits were living inside some of them. Some people could not control their bodies, and some people could not walk. Jesus caused all these people to become well again."
    },
    {
      "verse": "25",
      "text": "Because of this, large crowds of people followed him. They came from Galilee and from the region called ‘The ten cities’. Some of them came from Jerusalem, and other parts of Judea. And some came from the other side of the Jordan River."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Jesus saw that crowds of people were following him. So he went up a hill and he sat down there to teach them. His disciples came near to listen to him."
    },
    {
      "verse": "2",
      "text": "He began to teach them. This is what he said:"
    },
    {
      "verse": "3",
      "text": "‘Happy are the people who know that they need God very much. The kingdom of heaven belongs to people like that. The kingdom of heaven belongs to people like that."
    },
    {
      "verse": "4",
      "text": "Happy are the people who are sad now. God will come near to help them. God will come near to help them."
    },
    {
      "verse": "5",
      "text": "Happy are the people who are kind. The whole earth will belong to them. The whole earth will belong to them."
    },
    {
      "verse": "6",
      "text": "Happy are the people who want to obey God, as much as they want to eat food. God will give to them everything that they need. God will give to them everything that they need."
    },
    {
      "verse": "7",
      "text": "Happy are the people who help other people and who forgive them. God will forgive people like that. God will forgive people like that."
    },
    {
      "verse": "8",
      "text": "Happy are the people who have only good thoughts. They will come near to God and see him. They will come near to God and see him."
    },
    {
      "verse": "9",
      "text": "Happy are the people who bring people together to be friends. God will call them his children. God will call them his children."
    },
    {
      "verse": "10",
      "text": "Happy are the people who do what is right but other people hurt them because of it. The kingdom of heaven belongs to people like that. The kingdom of heaven belongs to people like that."
    },
    {
      "verse": "11",
      "text": "Yes, happy are you when people say bad things against you because you believe in me. Or they may hurt you. Or they may say things about you that are not true."
    },
    {
      "verse": "12",
      "text": "God is preparing many good things for you in heaven. So you should be very happy when people do these bad things to any of you. People did these same things to God's prophets who lived long ago. ’"
    },
    {
      "verse": "13",
      "text": "Jesus said, ‘You are like salt for all people to taste and use. Salt is good. But if it is not salty any more, you cannot make it salty again. People can no longer use it for anything. They just throw it away and they walk on it."
    },
    {
      "verse": "14",
      "text": "You are like a light for everybody in this world. If people build a city on a hill, then other people can see it easily."
    },
    {
      "verse": "15",
      "text": "Nobody lights a lamp and then puts it under a pot. He will put the lamp in a high place. Everybody who is in the house can then see the light from the lamp."
    },
    {
      "verse": "16",
      "text": "You must be sure that your light shines well. Then you will give light to other people. They will see all the good things that you do. Then they will praise God, who is your Father in heaven. ’"
    },
    {
      "verse": "17",
      "text": "Jesus said, ‘You should not think that I have come to destroy God's Law. Also, I have not come to destroy the messages that God's prophets wrote down. No, I have not come to destroy their words. I have come to make what they taught become true."
    },
    {
      "verse": "18",
      "text": "I tell you this: One day, even the earth and the sky will finish. But while they remain, God's Law will also remain. Nobody can remove even the smallest thing from it. The Law will remain until everything in it has happened."
    },
    {
      "verse": "19",
      "text": "A person may choose not to obey a rule in God's Law. He may think it is the least important rule. He may also teach other people to think like that. Then God will call him the least important person in the kingdom of heaven. But a person may choose to obey all the rules in God's Law. And he may teach other people to obey them too. Then God will call that person great in the kingdom of heaven."
    },
    {
      "verse": "20",
      "text": "I tell you this: You must always do what is right. You must live in a way that is better than the teachers of God's Law and the Pharisees. You will never come into the kingdom of heaven if you do not do better than them. ’"
    },
    {
      "verse": "21",
      "text": "Jesus then said, ‘You know the rule that God gave to your ancestors: “You must not kill anyone. Any person who does kill someone will stand in front of a judge. The judge will punish him because he has done a wrong thing. ”"
    },
    {
      "verse": "22",
      "text": "But what I now say to you is this: Anybody who is angry with his brother will have to stand in front of a judge. Or someone might call his brother by a bad name. Then he will have to stand in front of the Jewish leaders. They will judge him. But someone may say to his brother, “You are a fool. ” God will judge that person. God may punish him in the fires of hell."
    },
    {
      "verse": "23",
      "text": "Maybe you go to the temple to give your gift to God. You take it to the altar. But then you remember that your brother is angry with you."
    },
    {
      "verse": "24",
      "text": "You must leave your gift there in front of God's altar. First you must go and find your brother. Tell him that you are sorry. Then you can both become friends with each other again. After that, you can return to the altar and give your gift to God."
    },
    {
      "verse": "25",
      "text": "Also, somebody may say that you have done something wrong against him. He may take you to stand in front of the judge. You should quickly try to agree with this person. Decide with him how to make things right again. Do this even while you are going with him to the judge. If you do not do that, the judge may agree that you have done a wrong thing. Then he will give you to his officer. His officer will put you in prison."
    },
    {
      "verse": "26",
      "text": "I tell you this: You will remain in prison until you have paid all the money, even the last small coin. ’"
    },
    {
      "verse": "27",
      "text": "Jesus then said, ‘You know what God's rule says: “You must not have sex with anyone who is not your husband or your wife. ”"
    },
    {
      "verse": "28",
      "text": "But what I tell you is this: A man may look at a woman who is not his wife. And he may want to have sex with her. In his thoughts, he has had sex with her, so he has done a wrong thing."
    },
    {
      "verse": "29",
      "text": "If your right eye leads you to do wrong things, then you should take it out. You should throw it away. Yes, you will lose one eye. But it will be much worse if you keep your whole body and God throws you into hell."
    },
    {
      "verse": "30",
      "text": "Also, if your right hand leads you to do wrong things, then you should cut it off. You should throw it away. You will lose one hand. But it will be much worse if you keep your body in one piece and go to hell. ’"
    },
    {
      "verse": "31",
      "text": "‘God's Law also says: “Any man who wants to send his wife away must give her a letter. This letter must say that they are no longer married. ”"
    },
    {
      "verse": "32",
      "text": "But what I tell you is this: A man must not send his wife away except for one reason. He may only send her away if she has had sex with another man. If he sends her away for any other reason, he has done a wrong thing. It is like he has caused her to have sex with another man. Also, if a woman has left her husband, another man must not marry her. That is the same as if he had sex with another man's wife. ’"
    },
    {
      "verse": "33",
      "text": "‘You also know the rule that God gave to your ancestors: “If you make a promise to God, you must do what you have said. ”"
    },
    {
      "verse": "34",
      "text": "But what I tell you is this. Do not use any name to make a promise stronger. Do not use the words “by heaven” to make a promise stronger. Heaven is the place where God rules. Do not use the words “by the earth” to make a promise stronger. The earth is the place where God rests his feet."
    },
    {
      "verse": "35",
      "text": "Do not use the words “by Jerusalem” to make a promise stronger. Jerusalem is God's city. He is the great King who rules from there."
    },
    {
      "verse": "36",
      "text": "Do not use the words “by my head” to make a promise. You cannot make the colour of even one of your hairs black or white."
    },
    {
      "verse": "37",
      "text": "Instead, when you make a promise, you should say only “Yes, I will do it. ” Or you should say only “No, I will not do it. ” If you say anything more than this, what you say is bad. It comes from Satan. ’"
    },
    {
      "verse": "38",
      "text": "Jesus then said, ‘You also know that God's Law says: “If somebody destroys your eye, then you should destroy that person's eye. If somebody destroys your tooth, then you should destroy that person's tooth. ”"
    },
    {
      "verse": "39",
      "text": "But what I tell you is this. If somebody does something bad to you, do not do anything against him. Somebody may slap you on one side of your face. Then you should also let him slap the other side of your face."
    },
    {
      "verse": "40",
      "text": "Maybe somebody wants to take you to the judge. He says that you should give him your shirt. Give the man your shirt, and give him your coat too."
    },
    {
      "verse": "41",
      "text": "Or a soldier may tell you, “Carry my luggage for one kilometre. ” You should do that. Even agree to carry it for two kilometres."
    },
    {
      "verse": "42",
      "text": "When people ask you for something, you should give it to them. If they ask you to lend them something, then you should not refuse."
    },
    {
      "verse": "43",
      "text": "You have heard people say, “Love the people who are your friends. But hate those who want to hurt you. ”"
    },
    {
      "verse": "44",
      "text": "What I tell you is this: You should love the people who want to hurt you. If people want to give you pain, pray for them. Pray that God would help them."
    },
    {
      "verse": "45",
      "text": "If you live like this, you will show that you really are children of your Father above. God is kind to everyone. He causes the sun to shine on everyone, both good people and bad people. He also causes the rain to fall on everyone, people who obey him and people who do not obey him."
    },
    {
      "verse": "46",
      "text": "Do you only love people who love you? God will not give you good things just for doing that. Even the men who take taxes love their friends!"
    },
    {
      "verse": "47",
      "text": "If you are only kind to your friends, then you are not doing anything special. Even people who do not believe in God do that."
    },
    {
      "verse": "48",
      "text": "So you must be good in every way, as your Father above is good in every way. ’"
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "Jesus then said to them, ‘You should do good things to help people. But be careful! Do not do this so that other people see you. If you want other people to praise you, your Father in heaven will not praise you."
    },
    {
      "verse": "2",
      "text": "When you give something to a poor person, do not tell anyone about it. The hypocrites do this in their meeting places. They also do it in the busy streets of the town. They do this so that other people will praise them. I tell you this. They have already received their gift. God will not give them anything more."
    },
    {
      "verse": "3",
      "text": "So when you give something to a poor person, keep it a secret from other people. Do not tell anyone. Your left hand will not even know what your right hand does!"
    },
    {
      "verse": "4",
      "text": "Nobody else will know about the good thing that you have done. But God sees the things that you do secretly. In return, he will give you good things. ’"
    },
    {
      "verse": "5",
      "text": "‘Also, you must not pray in the way that the hypocrites pray. They like to stand and pray in their meeting places. They like to do it on the corners of the busy streets. Then many people will see them and they will praise them. I tell you this. They have already received their gift from people. God will not give them anything more."
    },
    {
      "verse": "6",
      "text": "But this is how you should pray. Go to a place in your house where you can be alone. You can shut the door and you can pray to God your Father. He is in that secret place. He sees what you do there. He will give you good things in return."
    },
    {
      "verse": "7",
      "text": "When you pray, do not say the same words many times. People who do not believe in God do that. They use many words that mean nothing. They think that when they pray like that, their gods will hear them."
    },
    {
      "verse": "8",
      "text": "Do not pray like they do. God your Father already knows what you need. He knows this even before you ask him."
    },
    {
      "verse": "9",
      "text": "So this is how you should pray:“God, our Father who is in heaven, we want people to give honour to you. “God, our Father who is in heaven, we want people to give honour to you."
    },
    {
      "verse": "10",
      "text": "We want the day when you rule everyone to come soon. We want everyone to obey you on earth, like everyone in heaven obeys you. We want everyone to obey you on earth, like everyone in heaven obeys you."
    },
    {
      "verse": "11",
      "text": "Please give us the food that we need today."
    },
    {
      "verse": "12",
      "text": "We have forgiven people who have done wrong things to us. In the same way, please forgive us for the wrong things that we have done. In the same way, please forgive us for the wrong things that we have done."
    },
    {
      "verse": "13",
      "text": "Do not let us agree to do wrong things. Keep us safe from Satan. ” ’ Keep us safe from Satan. ” ’"
    },
    {
      "verse": "14",
      "text": "Then Jesus said, ‘When other people do wrong things against you, you must forgive them. Then God, your Father in heaven, will also forgive you for the wrong things that you have done."
    },
    {
      "verse": "15",
      "text": "But if you do not forgive other people, then your Father will not forgive you. ’"
    },
    {
      "verse": "16",
      "text": "Jesus then said, ‘You may decide to fast for some time. But do not look sad so that people know you are doing a special thing. Hypocrites want people to see how good they are. They make their faces dirty. Then other people can see that they are fasting. I tell you this: people have praised them and that is the only gift that they will get."
    },
    {
      "verse": "17",
      "text": "But when you fast for some time, you should wash your face. Make your hair look nice."
    },
    {
      "verse": "18",
      "text": "Then other people will not know that you are doing a special thing. But God, your Father, will know. You do not see him but he sees what you do secretly. He will give you good things in return."
    },
    {
      "verse": "19",
      "text": "Do not want to have many valuable things here in the world. Insects or water can destroy those kinds of things. Or people may come into your house and they can rob you of those things."
    },
    {
      "verse": "20",
      "text": "Instead, you should want to have valuable things in heaven. Insects and water cannot destroy anything there. Men cannot rob you of your things there."
    },
    {
      "verse": "21",
      "text": "Then you will be thinking a lot about heaven, because that is where you keep your valuable things."
    },
    {
      "verse": "22",
      "text": "Your eyes are like lamps and your body is like a room. Make sure that your eyes are like a clean lamp, then your whole body will have light."
    },
    {
      "verse": "23",
      "text": "If your eyes are not good, then your whole body will be in the dark. If the light in you has become dark, you will be living in a very dark place. ’"
    },
    {
      "verse": "24",
      "text": "Jesus said, ‘Nobody can work as a slave for two masters at the same time. Maybe he will hate one of the masters, but he will love the other one. Or he will work well for one master, but he will think bad things about the other master. God and money are like different masters. You cannot work for both of them."
    },
    {
      "verse": "25",
      "text": "So I tell you this. You should not worry about how to stay alive. Do not worry about the food and drink that you need. Do not worry about the clothes that you need to wear. Your life is more important than the food that you eat. Your body is more important than your clothes."
    },
    {
      "verse": "26",
      "text": "Think about the wild birds. They do not plant seeds in the ground. They do not cut down plants to eat. They have no buildings to store food. But God, your Father in heaven, gives them food to eat. You are much more valuable than the birds."
    },
    {
      "verse": "27",
      "text": "Even if you always worry about your life, you cannot make it as much as one hour longer!"
    },
    {
      "verse": "28",
      "text": "You should not worry about your clothes. Think about how the wild flowers grow. They do not work or make clothes for themselves."
    },
    {
      "verse": "29",
      "text": "But I tell you this. Even one wild flower is more beautiful than King Solomon was. And King Solomon wore the most beautiful clothes."
    },
    {
      "verse": "30",
      "text": "It is God that gives beautiful clothes even to the grass. One day the grass is growing in the field, but the next day people will cut it and burn it. God will certainly take care of you, much more than he takes care of the grass. You should trust him more than you do!"
    },
    {
      "verse": "31",
      "text": "So do not worry about these things. Do not always say, “What will we eat? ”, or “What will we drink? ”, or “What will we wear? ”"
    },
    {
      "verse": "32",
      "text": "People who do not know God are always trying to get these things. But as for you, your Father in heaven knows that you need them."
    },
    {
      "verse": "33",
      "text": "Instead, always think about the things that are important in the kingdom of heaven. Always do what God shows you is right. Then he will also give you the things that you need each day."
    },
    {
      "verse": "34",
      "text": "So do not have trouble in your mind about what might happen tomorrow. Tomorrow will have its own problems. It is enough for you to be thinking each day about the problems of that day. ’"
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "Jesus then said, ‘Do not say to anyone, “You are a bad person. ” If you do that, God will say to you, “You are a bad person. ”"
    },
    {
      "verse": "2",
      "text": "God will think about you in the same way that you think about other people. He will use the same rules for you as you use for other people."
    },
    {
      "verse": "3",
      "text": "Perhaps you want to tell your friend about his little mistake. If you want to do that, first remember your own bigger mistakes."
    },
    {
      "verse": "4",
      "text": "You are like a person who has a big piece of wood in his eye. But then he says to his friend, “Let me take that little piece of dirt out of your eye for you. ”"
    },
    {
      "verse": "5",
      "text": "Do not be like that person. You think that you are better than your friend. But you are not. First, you must take the big piece of wood out of your own eye. After that, your eyes will see clearly. Then you can take the small piece of dirt out of your friend's eye."
    },
    {
      "verse": "6",
      "text": "Do not give special things that are for God to dogs. The dogs will turn round and attack you. Do not throw valuable things to pigs. The pigs will only stand on them and bury them in the dirt. ’"
    },
    {
      "verse": "7",
      "text": "Jesus said, ‘Go on asking God for what you need. Then God will give it to you. Go on looking for what you need. Then you will find it. Go on knocking at the door, and God will open it for you."
    },
    {
      "verse": "8",
      "text": "Everyone who asks for something will receive it. Everyone who looks for something will find it. God will open the door for everyone who knocks on it."
    },
    {
      "verse": "9",
      "text": "Some of you are fathers. If your son asks you for some bread, you would not give him a stone."
    },
    {
      "verse": "10",
      "text": "If he asks you for a fish, you would not give him a snake."
    },
    {
      "verse": "11",
      "text": "You may be bad, but even you know how to give good things to your children. Your Father in heaven knows much better than you do how to give good things to his children. He will give good things to everyone who asks him."
    },
    {
      "verse": "12",
      "text": "So do the good things for other people that you would want them to do for you. That is true in everything you do. That is what God's Law and the messages of God's prophets teach us. ’"
    },
    {
      "verse": "13",
      "text": "‘Go in through the narrow gate to get true life with God. There is a wide gate that is easy to go through. The wide path is easy to travel on. Many people find that wide gate, but it is the way to hell."
    },
    {
      "verse": "14",
      "text": "It is difficult to go through the small gate. And it is difficult to walk on the narrow road. But when you do go that way, you will get true life. Not many people find that narrow gate. ’"
    },
    {
      "verse": "15",
      "text": "‘Some people say that they are prophets from God. But their words are false. They seem to be like sheep that are not dangerous. But they are really like hungry wild dogs. What they teach will hurt you."
    },
    {
      "verse": "16",
      "text": "You will know these people by the way that they live. The things that they do are like their fruit. Grapes do not grow on thorn bushes. Figs do not grow on weeds."
    },
    {
      "verse": "17",
      "text": "Good fruit grows on a tree that is good. Bad fruit grows on a tree that is not good."
    },
    {
      "verse": "18",
      "text": "A good tree cannot make bad fruit. A bad tree cannot make good fruit."
    },
    {
      "verse": "19",
      "text": "A farmer will cut down any tree that does not make good fruit. He will burn it on a fire."
    },
    {
      "verse": "20",
      "text": "In the same way, look at the way people live. Then you will know what they are really like."
    },
    {
      "verse": "21",
      "text": "Some people say to me, “Master, Master! ” But not all of them will come into the kingdom of heaven. Only the people who obey God, my Father in heaven, will come in. They do what he wants them to do."
    },
    {
      "verse": "22",
      "text": "On the day when God judges people, many of them will say, “Master, Master! We used your authority and we spoke a message from you. We used your authority and we sent bad spirits out of people. We used your authority to do many powerful things. ”"
    },
    {
      "verse": "23",
      "text": "But I will say to these people, “I never knew you. You do not obey God. You are bad. So go away from me. ” ’"
    },
    {
      "verse": "24",
      "text": "Jesus then said, ‘Some people listen to my message and they obey it. Those people are like a wise man who built his house on rock."
    },
    {
      "verse": "25",
      "text": "Then a storm came with a lot of rain and wind. The rivers rose up high. Strong winds blew hard against that house. But the house did not fall down because the man had built it on rock."
    },
    {
      "verse": "26",
      "text": "Other people listen to my message but they do not obey it. Those people are like a fool who built his house on sand."
    },
    {
      "verse": "27",
      "text": "Then a storm came with a lot of rain and wind. The rivers rose up high. Strong winds blew hard against the house. That house fell down. The storm destroyed it completely. ’"
    },
    {
      "verse": "28",
      "text": "Jesus finished speaking. The crowds of people were very surprised at the things that he taught them."
    },
    {
      "verse": "29",
      "text": "When Jesus taught them, he showed that he had authority. That was not like the way that the teachers of God's Law taught people."
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "Jesus came down from the hill and a large crowd followed him."
    },
    {
      "verse": "2",
      "text": "A man with a bad disease of the skin came to meet him. He went down on his knees in front of Jesus and he said, ‘Sir, if you want, you can make me well again. Please do it. ’"
    },
    {
      "verse": "3",
      "text": "Jesus put out his hand towards him and he touched him. ‘I do want to help you. Be clean again, ’ Jesus said. Immediately, the man's skin was clean again."
    },
    {
      "verse": "4",
      "text": "Jesus said to the man, ‘Listen. You must not tell anyone about this. Instead, go and show yourself to the priest. Take a gift to him for God. Moses taught the people what gift to take to God after this kind of disease. This will show everyone that you are now well again. ’"
    },
    {
      "verse": "5",
      "text": "Jesus went into Capernaum. An officer in the Roman army came to meet him. He asked Jesus to help him."
    },
    {
      "verse": "6",
      "text": "‘Sir, ’ he said, ‘My servant is lying in bed at home. He cannot move his legs and he has a lot of pain. ’"
    },
    {
      "verse": "7",
      "text": "Jesus said to the officer, ‘I will go with you to your house and I will make your servant well again. ’"
    },
    {
      "verse": "8",
      "text": "But the officer answered, ‘Sir, I am not good enough for you to come into my house. Instead, just say that my servant will get better. I know that he will then be well again."
    },
    {
      "verse": "9",
      "text": "In my work, someone has authority over me. I also have authority over other soldiers. I say to one soldier, “Go! ” and he goes. I say to another one, “Come! ” and he comes. I say to my servant, “Do this! ” and he does it. ’"
    },
    {
      "verse": "10",
      "text": "Jesus heard what the officer said. He was very surprised. He spoke to the crowd that was following him. ‘I tell you this: I have never found anyone like this man in all of Israel. Nobody else believes in me as well as he does."
    },
    {
      "verse": "11",
      "text": "I tell you, many people will come from all over the world to take their place in the kingdom of heaven. There they will sit down to eat with Abraham, Isaac and Jacob."
    },
    {
      "verse": "12",
      "text": "But other people who think that God's kingdom belongs to them will not be there. God's angels will throw them into the dark places that are far away from God. There those people will weep very much. They will bite their teeth together. ’"
    },
    {
      "verse": "13",
      "text": "Then Jesus said to the officer, ‘Go home. You believed that I would make your servant well again. So I will do it for you. ’ At that moment, the servant did become well again."
    },
    {
      "verse": "14",
      "text": "Jesus went into Peter's house. There, he saw the mother of Peter's wife. She was lying in bed. She was ill and her body was very hot."
    },
    {
      "verse": "15",
      "text": "Jesus touched her hand and immediately she was well again. So she got up and she prepared food for Jesus."
    },
    {
      "verse": "16",
      "text": "That evening, people brought to Jesus many people who were ill. Many of them had bad spirits in them. Jesus spoke a word so that the bad spirits left them. He made everybody who was ill well again. ‘He took away everything that makes us weak. He carried away everything that makes us ill. ’"
    },
    {
      "verse": "17",
      "text": "Jesus did this so that the words of the prophet Isaiah would become true:‘He took away everything that makes us weak. He carried away everything that makes us ill. ’"
    },
    {
      "verse": "18",
      "text": "One day, Jesus saw a large crowd of people around him. So he told his disciples, ‘We should go across the lake to the other side. ’"
    },
    {
      "verse": "19",
      "text": "A teacher of God's Law came to Jesus and said to him, ‘Teacher, I will go with you everywhere that you go. ’"
    },
    {
      "verse": "20",
      "text": "Jesus replied, ‘Wild animals and birds have their own places to live. But I, the Son of Man, have no place of my own to lie down and rest. ’"
    },
    {
      "verse": "21",
      "text": "Another man who was one of Jesus' disciples said to him, ‘Sir, I want to come with you. But first, let me go home and bury my father. Then I will come with you. ’"
    },
    {
      "verse": "22",
      "text": "Jesus said to him, ‘No! You must come with me now. Let those people who are dead themselves bury their own dead people. ’"
    },
    {
      "verse": "23",
      "text": "Then Jesus got into a boat. His disciples also went with him."
    },
    {
      "verse": "24",
      "text": "Immediately a great storm began to blow across the lake. Water began to go into the boat and fill it. Jesus was sleeping."
    },
    {
      "verse": "25",
      "text": "The disciples went to him and they woke him. ‘Master, save us! ’ they said. ‘We will die here in the water! ’"
    },
    {
      "verse": "26",
      "text": "Jesus said to them, ‘You should not be so afraid. You should trust me more than you do! ’ Then he stood up and he spoke strongly to the wind and the water. ‘Stop! ’ he said. Then the wind and the water became quiet again."
    },
    {
      "verse": "27",
      "text": "The disciples were very surprised. They asked each other, ‘What kind of man is this? Even the wind and the water obey him! ’"
    },
    {
      "verse": "28",
      "text": "Jesus arrived at the other side of Lake Galilee. He came to a place where the Gadarene people lived. Two men who had bad spirits in them came to meet him. These men lived outside, among some graves. They were very strong and dangerous. People were too afraid to walk that way because of them."
    },
    {
      "verse": "29",
      "text": "When the two men saw Jesus, they immediately shouted at him, ‘You are the Son of God! What are you doing here? Have you come to punish us before the right time comes? ’"
    },
    {
      "verse": "30",
      "text": "A large group of pigs was eating there, not very far away."
    },
    {
      "verse": "31",
      "text": "The bad spirits said to Jesus, ‘If you make us leave these men, please send us to those pigs. Let us go into them. ’"
    },
    {
      "verse": "32",
      "text": "Jesus said to the bad spirits, ‘Go! ’ So the bad spirits came out of the men and they went into the pigs. All the pigs rushed together down the hill into the lake. They all died there in the water."
    },
    {
      "verse": "33",
      "text": "When this happened, the men who took care of the pigs ran away. They went into the town. They told people there everything that had happened to the men with the bad spirits in them."
    },
    {
      "verse": "34",
      "text": "So everybody came out of the town to meet Jesus. When they saw him, they said, ‘Please go away. Leave our part of the country. ’"
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "Then Jesus got back into the boat. He sailed across to the other side of the lake again. He went to Capernaum, the town where he was living."
    },
    {
      "verse": "2",
      "text": "Some men came to see Jesus there. They carried with them a man who could not walk or move his legs. He was lying on a mat. Jesus knew that they believed in him. He said to the man who could not walk, ‘Do not be afraid, my friend. I forgive you for the wrong things that you have done. ’"
    },
    {
      "verse": "3",
      "text": "Then some teachers of God's Law said to themselves: ‘This man is speaking as if he is God. That is not right. ’"
    },
    {
      "verse": "4",
      "text": "Jesus knew what the teachers were thinking. So he said to them, ‘You should not think these bad things in your minds."
    },
    {
      "verse": "5",
      "text": "I said to this man, “I forgive you for the wrong things that you have done. ” Instead, I could have said to him, “Stand up and walk. ” Which one is easier for me to say?"
    },
    {
      "verse": "6",
      "text": "But I want you to know this. I, the Son of Man, have authority on earth. I can forgive people for the wrong things that they have done. ’ Then he said to the man who could not walk, ‘Stand up. Pick up your mat and go home. ’"
    },
    {
      "verse": "7",
      "text": "So then the man stood up and he went home."
    },
    {
      "verse": "8",
      "text": "The crowds of people saw what had happened. They were very surprised and afraid. They saw that God had given so much authority to men. So they praised God and they said, ‘God is great! ’"
    },
    {
      "verse": "9",
      "text": "Jesus went away from that place. While he walked, he saw a man called Matthew. Matthew's job was to take taxes from people. He was sitting in his office. Jesus said to him, ‘Come with me and be my disciple. ’ So Matthew stood up and he went with Jesus."
    },
    {
      "verse": "10",
      "text": "Later, Jesus went to eat a meal in Matthew's house. Many bad people and men who took taxes also came to the house. They came to eat there with Jesus and his disciples."
    },
    {
      "verse": "11",
      "text": "Some Pharisees saw what was happening. They said to Jesus' disciples, ‘Your teacher is eating a meal with these bad people. That is not right. They are people who do not obey God, and some of them take taxes from people. ’"
    },
    {
      "verse": "12",
      "text": "Jesus heard what the Pharisees were saying. He said to them, ‘People who are well do not need a doctor. It is people who are ill that need a doctor."
    },
    {
      "verse": "13",
      "text": "Go and study what it says in the Bible. God says there, “I want people to be kind to each other. I do not want them only to offer sacrifices to me. ” Some people think that they always obey God. I did not come to help people like that. Some people know that they have done wrong things. I am asking those people to come to me for help. ’"
    },
    {
      "verse": "14",
      "text": "Then the disciples of John the Baptist came to Jesus. They said to him, ‘We often decide to fast for a time. The disciples of the Pharisees also do that. Why do your disciples never do that? ’"
    },
    {
      "verse": "15",
      "text": "Jesus answered them: ‘When a man marries, his friends cannot be sad. They cannot refuse to eat food while he is with them. But there will be a time when people will take the man away from his friends. At that time his friends will choose to fast. ’"
    },
    {
      "verse": "16",
      "text": "Then Jesus said, ‘Nobody uses a piece of new cloth to mend an old coat. If he does, the new cloth will cause the old cloth to tear again. It will make a bigger hole than before."
    },
    {
      "verse": "17",
      "text": "Nobody pours new wine into old wineskins. If he does that, the new wine will tear the old wineskins. He will lose the wine and the wineskins will spoil. Instead, you must put new wine into new wineskins. Then there will be nothing to spoil the wine or the wineskins. ’"
    },
    {
      "verse": "18",
      "text": "While Jesus was saying these things to the people, a leader at the Jewish meeting place came to him. The man went down on his knees in front of Jesus and said to him, ‘My daughter has just died. Come to my house. Put your hand on her and then she will live again. ’"
    },
    {
      "verse": "19",
      "text": "So Jesus went with the man. His disciples also went with them."
    },
    {
      "verse": "20",
      "text": "There was a sick woman in the crowd. She had been losing blood for 12 years. She came near to Jesus, behind him. She touched the edge of his coat."
    },
    {
      "verse": "21",
      "text": "The woman thought, ‘Even if I only touch his coat, I will become well again. ’"
    },
    {
      "verse": "22",
      "text": "Jesus turned round and he saw the woman. He said to her, ‘Young woman, do not be afraid. You are now well again because you believed in me. ’ And immediately the woman became well again."
    },
    {
      "verse": "23",
      "text": "Then Jesus arrived at the Jewish leader's house. Some people there were making sad music and the crowd was making a loud noise."
    },
    {
      "verse": "24",
      "text": "When Jesus saw this, he said to everybody in the house, ‘Go outside. This girl is not dead. She is only sleeping. ’ The people laughed at Jesus when he said that."
    },
    {
      "verse": "25",
      "text": "The family sent all the people out of the house. Jesus went inside and he held the girl's hand. Immediately she stood up."
    },
    {
      "verse": "26",
      "text": "People in all that part of the country heard about what had happened."
    },
    {
      "verse": "27",
      "text": "Jesus left the house. While he walked along, two blind men began to follow him. They were shouting out to him, ‘Son of David! Please be kind to us and help us! ’"
    },
    {
      "verse": "28",
      "text": "Jesus went into a house and the blind men came to him there. Jesus asked them, ‘Do you believe that I can make your eyes become well? ’ The men replied, ‘Yes, Master, we believe that you can do this. ’"
    },
    {
      "verse": "29",
      "text": "So Jesus touched the men's eyes. He said to them, ‘Because you believed in me, you will now see again. ’"
    },
    {
      "verse": "30",
      "text": "Then immediately the men could see again. Jesus said strongly to them, ‘You must not tell anyone about this. ’"
    },
    {
      "verse": "31",
      "text": "So the men went away. But they told everybody in that part of the country all about what Jesus had done for them."
    },
    {
      "verse": "32",
      "text": "While those two men were leaving, some people brought another man to Jesus. This man could not speak because of a bad spirit in him."
    },
    {
      "verse": "33",
      "text": "Jesus made the bad spirit go out of the man and leave him. Then the man began to speak again. Everybody there was very surprised. They said, ‘Nobody has seen anything like this happen in Israel before. ’"
    },
    {
      "verse": "34",
      "text": "But the Pharisees said, ‘This man can send bad spirits out of people because Satan gives him authority. Satan is the one who rules the bad spirits. ’"
    },
    {
      "verse": "35",
      "text": "Jesus went to visit all the towns and villages near there. He taught the people in the Jewish meeting places. He told them the good news about God's kingdom. He also caused sick people to become well again from all their different pains and illnesses."
    },
    {
      "verse": "36",
      "text": "When Jesus saw the crowds of people, he felt sorry for them. They had trouble in their minds. They had nobody to help them. Jesus thought, ‘These people are like sheep that have nobody to take care of them. ’"
    },
    {
      "verse": "37",
      "text": "Then Jesus said to his disciples, ‘Many people are ready to believe God's message. They are like crops in the fields at harvest time. But there are very few workers to bring in the crops."
    },
    {
      "verse": "38",
      "text": "So pray to God to send out workers. The field and the crops belong to him. ’"
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "One day, Jesus asked his 12 disciples to come to him. He gave them authority over bad spirits so that they could send the spirits out of people. They could also make sick people well again from every kind of illness."
    },
    {
      "verse": "2",
      "text": "apostles: The first apostle is Simon, who was also called Peter. Then Simon's brother, who was called Andrew. Also James and his brother John, who were Zebedee's sons. The first apostle is Simon, who was also called Peter. Then Simon's brother, who was called Andrew. Also James and his brother John, who were Zebedee's sons."
    },
    {
      "verse": "3",
      "text": "There were Philip and Bartholomew. There were Thomas and Matthew. (Matthew's job was to take taxes from people. )And James who was the son of Alphaeus, and Thaddaeus. There were Thomas and Matthew. (Matthew's job was to take taxes from people. ) And James who was the son of Alphaeus, and Thaddaeus."
    },
    {
      "verse": "4",
      "text": "There was also Simon the Zealot and Judas Iscariot, who later gave Jesus to his enemies."
    },
    {
      "verse": "5",
      "text": "disciples. Before they left, he said to them, ‘Do not go to any place where the people are Gentiles. And do not go to towns where only Samaritans live."
    },
    {
      "verse": "6",
      "text": "Instead, you must go to the people of Israel. They are like lost sheep with nobody to take care of them."
    },
    {
      "verse": "7",
      "text": "While you travel, you must tell people about the kingdom of heaven. You must tell them that it has now become near."
    },
    {
      "verse": "8",
      "text": "Make sick people well again. Cause dead people to become alive again. If people have a bad disease of the skin, make them well again. Send bad spirits out of people to leave them. God has been very kind to you, so you should be kind to other people. When you help people, do not ask them for money."
    },
    {
      "verse": "9",
      "text": "Do not take any money in your purses."
    },
    {
      "verse": "10",
      "text": "Do not take a bag with you, or extra clothes. Do not take extra shoes or a stick. You are working to help people. So people should give you what you need to live."
    },
    {
      "verse": "11",
      "text": "When you arrive in a town or a village, look for a good person there. Continue to stay in that person's house until you leave there."
    },
    {
      "verse": "12",
      "text": "When you go into the house, say to the people there, “We pray that you will be well. ”"
    },
    {
      "verse": "13",
      "text": "If the people of that house accept you, then everyone in the house will be well. But if they do not accept you, then take back your kind words."
    },
    {
      "verse": "14",
      "text": "Sometimes you will go to some house or town and the people will not accept you there. They will not listen to your message. Then you should leave. Clean the dirt of that place off your feet."
    },
    {
      "verse": "15",
      "text": "I tell you this: One day God will punish people like that. God will punish them even more than the people who lived in Sodom and Gomorrah long ago. ’"
    },
    {
      "verse": "16",
      "text": "Jesus then said to his disciples, ‘Listen well. I am sending you to people who will want to kill you. You will be like sheep among wild animals. You must watch carefully, like snakes do. But you must also be good and kind like doves."
    },
    {
      "verse": "17",
      "text": "Be careful! People will be against you. They will take you to stand in front of their leaders. They will punish you with whips in their meeting places."
    },
    {
      "verse": "18",
      "text": "They will take you to stand in front of kings and rulers. All this will happen because you are my disciples. You will tell all these important people and also the Gentiles the good news about me."
    },
    {
      "verse": "19",
      "text": "When they take you to stand in front of their leaders, do not be afraid. Do not worry about what you should say or how you should say it. At that time, God will give you the right words to speak."
    },
    {
      "verse": "20",
      "text": "You will not be speaking your own words. The Holy Spirit of your Father God will give you his own words to say."
    },
    {
      "verse": "21",
      "text": "At that time, a man will let people kill his own brother. A father will let people kill his own child. Children will be against their parents. They will even ask people to kill their parents."
    },
    {
      "verse": "22",
      "text": "All people will hate you because you are my disciples. But God will save the person who remains strong until the end."
    },
    {
      "verse": "23",
      "text": "If people in any town hurt you because of me, you should leave that town immediately. Go to another town. I tell you this: You will not have enough time to speak your message in all the towns of Israel. I, the Son of Man, will return before that can happen."
    },
    {
      "verse": "24",
      "text": "A student is not more important than his teacher is. A servant is not more important than his master is."
    },
    {
      "verse": "25",
      "text": "A student should be happy if he becomes like his teacher. A servant should be happy if he becomes like his master. People have called me, the master of the house, Beelzebul. You are like those people who live in my house. So do not be surprised when people call you even worse names than they call me."
    },
    {
      "verse": "26",
      "text": "So do not be afraid of these people. They hide the things that they do. But there will be a time when other people will see those things. Everyone will know all their secrets."
    },
    {
      "verse": "27",
      "text": "I tell you things secretly, like people do in the dark. But you must tell people these things clearly in the light of day. I have said things very quietly into your ears. But now you must shout those things loudly from the tops of the houses."
    },
    {
      "verse": "28",
      "text": "Do not be afraid of those people who can kill only your body. These people cannot kill your soul. No, it is God that you should be afraid of. He can kill your body, and then he can also destroy your soul in hell."
    },
    {
      "verse": "29",
      "text": "Think about this. People sell two birds for just one small coin. But God takes care of these little birds. Not one of them can fall to the ground unless God lets it happen."
    },
    {
      "verse": "30",
      "text": "God even knows how many hairs there are on your head."
    },
    {
      "verse": "31",
      "text": "So do not be afraid of those people who are against you. You are more valuable to God than many little birds."
    },
    {
      "verse": "32",
      "text": "You should say clearly to other people, “I believe in Jesus. ” If you do that, I will say to my Father in heaven, “This is someone who is my disciple. ”"
    },
    {
      "verse": "33",
      "text": "But if you say to other people, “I do not believe in Jesus, ” I will then say to my Father in heaven, “I do not know that person. He is not one of my disciples. ”"
    },
    {
      "verse": "34",
      "text": "I will tell you why I have come into the world. I did not come so that everyone would agree with each other. No, I came to put people against one another, to fight against each other."
    },
    {
      "verse": "35",
      "text": "A man will fight against his father. A daughter will fight against her mother. A woman will fight against her husband's mother. A daughter will fight against her mother. A woman will fight against her husband's mother."
    },
    {
      "verse": "36",
      "text": "A man's own family will fight against him."
    },
    {
      "verse": "37",
      "text": "Nobody should love his own father and mother more than he loves me. If he does, he cannot be my disciple. Nobody should love his own son or daughter more than he loves me. If he does, then he cannot be my disciple."
    },
    {
      "verse": "38",
      "text": "If you really want to be one of my disciples, you must be ready to die for me. Live like a person who carries his own cross to go and die."
    },
    {
      "verse": "39",
      "text": "Whoever wants to keep his life safe will lose it. But whoever gives his life to serve me will have true life. ’"
    },
    {
      "verse": "40",
      "text": "Jesus said to his disciples, ‘If anyone accepts you in his home, then he is also accepting me. And anyone who accepts me, also accepts my Father God, who sent me."
    },
    {
      "verse": "41",
      "text": "Somebody may accept a prophet into his home because the visitor is a prophet of God. God will bless that person like he blesses a prophet. Or he may accept a good man who obeys God, because the man is good. God will bless that person like he blesses the good man."
    },
    {
      "verse": "42",
      "text": "People may think that my disciples are unimportant. But God will bless anyone who gives even a drink of cold water to one of them. I tell you, that person will never lose God's help. ’"
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "disciples. After he had finished, he went away from that place. He went to the towns near there to teach his message to people."
    },
    {
      "verse": "2",
      "text": "At that time, John the Baptist was in prison. But people told him about all the things that Jesus the Messiah was doing. So John sent some of his own disciples to ask Jesus some questions."
    },
    {
      "verse": "3",
      "text": "They said to him, ‘John the Baptist wants to know this: Are you the special person that God has promised to send to us? If not, should we still look for someone else? ’"
    },
    {
      "verse": "4",
      "text": "Jesus replied, ‘Go back to John. Tell him what you have been hearing. Also, tell him what you have been seeing."
    },
    {
      "verse": "5",
      "text": "Blind people can now see again. People who could not walk can now walk again. People who had a bad disease of the skin are now well again. Deaf people can now hear again. People who had died now live again. Poor people are hearing God's good news."
    },
    {
      "verse": "6",
      "text": "If anyone believes in me and does not turn away, he will be really happy. ’"
    },
    {
      "verse": "7",
      "text": "John's disciples went away again. Jesus spoke to the crowd about John. He said to them, ‘You went out to the wilderness. What did you go there to see? Was it a tall piece of grass which the wind was blowing this way and that? No, you did not go to see that. “Listen! I will send someone to go in front of you. He will speak my message. He will prepare a way for you. ” ’"
    },
    {
      "verse": "8",
      "text": "Did you go to see a man who was wearing expensive clothes? No! People like that do not live in the wilderness. They live in kings' great houses."
    },
    {
      "verse": "9",
      "text": "So what did you go to see? Did you go to see a prophet sent by God? Yes! But I tell you, John was even more important than a prophet."
    },
    {
      "verse": "10",
      "text": "This is what someone wrote about him a long time ago in the Bible. God said:“Listen! I will send someone to go in front of you. He will speak my message. He will prepare a way for you. ” ’"
    },
    {
      "verse": "11",
      "text": "Jesus then said, ‘I tell you this: John the Baptist is greater than any person who has ever lived until now. But now, anyone who belongs in the kingdom of heaven is greater than John. Even the least important of them is greater than he is."
    },
    {
      "verse": "12",
      "text": "From the time that John the Baptist began to teach until now, the kingdom of heaven is becoming very strong. Strong people are trying very much to attack it."
    },
    {
      "verse": "13",
      "text": "All the prophets and the books of the Law spoke God's message until the time that John the Baptist came."
    },
    {
      "verse": "14",
      "text": "The prophets wrote about Elijah. They said he would come again, to prepare for the Messiah. They were writing about John, and you should believe their message."
    },
    {
      "verse": "15",
      "text": "You have ears, so listen well to what I say! ’"
    },
    {
      "verse": "16",
      "text": "Jesus said, ‘I will talk to you about the people who are alive today. They are like children who are sitting in the market place. They are playing games and they shout to other children,"
    },
    {
      "verse": "17",
      "text": "“We made happy music on a flute for you, but you did not dance. We sang a sad song but you did not cry. ” but you did not dance. We sang a sad song but you did not cry. ”"
    },
    {
      "verse": "18",
      "text": "People today are like those children. John the Baptist did not eat ordinary food. He never drank wine. So people say that he has a bad spirit in him."
    },
    {
      "verse": "19",
      "text": "Then I, the Son of Man, came. I eat meals with other people and I drink wine. So people say about me, “Look at him! He eats too much and he drinks too much. He is a friend of bad people and men who take taxes from people. ” God is wise. The good things that he does show that he is right. ’"
    },
    {
      "verse": "20",
      "text": "In some of the cities Jesus had done many powerful things. But some people in those cities did not want to stop doing wrong things. They did not want to change how they lived. So Jesus spoke against those people."
    },
    {
      "verse": "21",
      "text": "He said to them, ‘You people in Chorazin, it will be very bad for you! And it will be very bad for you, people in Bethsaida. I have done great and powerful things in your cities. If I had done such great things in Tyre and in Sidon, the people there would have changed how they lived. They would have shown they were sorry for their sins. They would have put on clothes made from goat's hair. They would also have put ashes on their heads."
    },
    {
      "verse": "22",
      "text": "Yes, when God judges everyone, he will punish the people from Tyre and Sidon. But he will punish much more you people from Chorazin and Bethsaida."
    },
    {
      "verse": "23",
      "text": "And what will happen to you people in Capernaum? You think that God will lift you up to heaven, do you? No! He will throw you down to Hades, the place for dead people. I did powerful things in your town. If I had done these powerful things in Sodom, it would still be there today."
    },
    {
      "verse": "24",
      "text": "I tell you this. When God judges everyone, he will punish the people from Sodom. But he will punish you people much more! ’"
    },
    {
      "verse": "25",
      "text": "At this moment, Jesus said, ‘Father, you rule over everything in heaven and on the earth! People who do not know many things can now understand your message. And so I thank you. But you have hidden these things from some other people. Those people think that they understand everything. They think that they are wise."
    },
    {
      "verse": "26",
      "text": "Yes, Father, this is how you wanted it to happen."
    },
    {
      "verse": "27",
      "text": "My Father has given me authority over all things. Only the Father really knows me, his Son. Only I really know my Father, because I am his Son. I also choose to tell some people about him. Then they also know him."
    },
    {
      "verse": "28",
      "text": "Come to me all of you who are tired. You are like people who have worked for a long time. You are like people who have carried heavy things. Come to me. If you do that, you will find a place to rest."
    },
    {
      "verse": "29",
      "text": "Do what I teach you to do. Listen to my message and learn from me what is true. I am very kind and I do not make myself important. I will help you. Then you will have peace in your mind."
    },
    {
      "verse": "30",
      "text": "I will not tell you to do things that are too difficult. I will not tell you to carry anything that is too heavy for you. ’"
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "On a Jewish day of rest, Jesus was walking through some fields where wheat was growing. His disciples were hungry. So they began to pick some of the grains of wheat. They began to eat them."
    },
    {
      "verse": "2",
      "text": "While the disciples were picking the grains, some Pharisees saw them. They said to Jesus, ‘Look at what your disciples are doing! It is against God's Law to do that on our day of rest. ’"
    },
    {
      "verse": "3",
      "text": "Jesus replied, ‘You have certainly read about what David did one day. He and the men who were with him were hungry."
    },
    {
      "verse": "4",
      "text": "David went into the temple. He ate the special bread that was there. He also gave some of it to his men to eat as well. But it is against God's Law for anyone except the priests to eat that special bread."
    },
    {
      "verse": "5",
      "text": "Also, you certainly know what God's Law says about the priests. They work in the temple, even on the day of rest. They have not obeyed the Law about the day of rest. But God's Law tells us that they have not done anything that is wrong."
    },
    {
      "verse": "6",
      "text": "But I tell you this. There is someone here now who has greater authority even than the temple."
    },
    {
      "verse": "7",
      "text": "You should understand what the Bible teaches. God says there, “I want people to be kind to each other. I do not just want them to offer sacrifices to me. ” If you had understood this, then you would not have said to me, “Your disciples are doing something wrong. ”"
    },
    {
      "verse": "8",
      "text": "The Son of Man has authority over the Law about the day of rest. ’"
    },
    {
      "verse": "9",
      "text": "Then Jesus left that place. He went into the Jewish meeting place."
    },
    {
      "verse": "10",
      "text": "A man was there. His hand was very small and weak, so he could not use it. Some Pharisees asked Jesus, ‘Is it right to make someone well again on our day of rest? ’ They wanted to find a reason to say that Jesus was doing wrong things."
    },
    {
      "verse": "11",
      "text": "Jesus said to them, ‘Maybe one of you has a sheep that falls into a deep hole on our day of rest. What will you do? You will take hold of it and you will lift it out of the hole."
    },
    {
      "verse": "12",
      "text": "You know that a man is much more valuable than a sheep. So it is right for us to do good things on our day of rest. ’"
    },
    {
      "verse": "13",
      "text": "Then Jesus said to the man with the weak hand, ‘Lift up your hand. ’ So the man lifted up his hand and it became well again. It was now as strong as his other hand."
    },
    {
      "verse": "14",
      "text": "Then the Pharisees went out from the meeting place. They began to talk to each other about how they could kill Jesus."
    },
    {
      "verse": "15",
      "text": "Jesus knew that the Pharisees wanted to kill him. So he went away from that place. A large crowd of people followed him. He made all the sick people become well again."
    },
    {
      "verse": "16",
      "text": "He said to these people, ‘You must not tell anyone about me. ’"
    },
    {
      "verse": "17",
      "text": "This happened so that what the prophet Isaiah had spoken long ago became true. Isaiah wrote what God said:"
    },
    {
      "verse": "18",
      "text": "‘Here is my servant. I have chosen him to serve me. I love him and he makes me very happy. I will give him the strength of my Spirit. He will tell all the nations that I will judge them fairly. I have chosen him to serve me. I love him and he makes me very happy. I will give him the strength of my Spirit. He will tell all the nations that I will judge them fairly."
    },
    {
      "verse": "19",
      "text": "He will not argue with people. He will not shout at them. People will not hear his loud voice in the streets. People will not hear his loud voice in the streets."
    },
    {
      "verse": "20",
      "text": "He will not hurt weak people. He will be kind to people who are not strong. He will do this until there is justice everywhere. He will be kind to people who are not strong. He will do this until there is justice everywhere."
    },
    {
      "verse": "21",
      "text": "All the nations will trust him to save them. ’"
    },
    {
      "verse": "22",
      "text": "After that, some people brought a man to Jesus. The man had a bad spirit in him. Because of this, he was blind and he could not speak. Jesus caused the man to become well again. The man could speak again and he could see."
    },
    {
      "verse": "23",
      "text": "When Jesus did this, all the people were very surprised. They asked each other, ‘Maybe this man is the Son of David that God will send to us. Could that be true? ’"
    },
    {
      "verse": "24",
      "text": "The Pharisees also heard about what had happened. They said, ‘This man can send bad spirits out of people only because Beelzebul gives him authority. That is Satan, the one who rules all the bad spirits. ’"
    },
    {
      "verse": "25",
      "text": "Jesus knew what the Pharisees were thinking. So he said to them, ‘If armies in a country fight each other, then they will destroy their own country. If people in one city or in one family fight each other, then they will destroy their own city or family."
    },
    {
      "verse": "26",
      "text": "So Satan would not try to destroy himself. If Satan fights against himself, that would be the end of his own kingdom."
    },
    {
      "verse": "27",
      "text": "Some of your disciples can also send bad spirits out of people. You would not say that it is Satan's power that helps them. So your own disciples show that you are wrong about this."
    },
    {
      "verse": "28",
      "text": "I do send bad spirits out of people. I use the authority of God's Holy Spirit to do this. This shows that God has come to rule among you."
    },
    {
      "verse": "29",
      "text": "Nobody can go easily into the house of a strong man to rob him. To do that, he must first tie up the strong man. Then he can take away all that man's valuable things."
    },
    {
      "verse": "30",
      "text": "If someone does not agree to help me, he is working against me. You should work with me to bring people to me for help. If you do not do that, you are really making people run away from me."
    },
    {
      "verse": "31",
      "text": "God is able to forgive all the wrong things that people do, and the bad things that they say against other people. But God will never forgive people who say bad things against the Holy Spirit."
    },
    {
      "verse": "32",
      "text": "God will forgive people who say bad things against me, the Son of Man. But God will never forgive people who say bad things against the Holy Spirit. ’ He will not forgive them now or ever."
    },
    {
      "verse": "33",
      "text": "Then Jesus said, ‘To have good fruit you must have a good tree. If you have a bad tree, then you will get bad fruit from it. You can know all about a tree by the kind of fruit that it makes."
    },
    {
      "verse": "34",
      "text": "You are like the children of dangerous snakes. You cannot say good things when your thoughts are bad. When you speak, your words show what is in your mind."
    },
    {
      "verse": "35",
      "text": "It is like things that you bring out of a room where you keep them. The good man says good things because he keeps good thoughts in his mind. The bad man says bad things because he keeps bad thoughts in his mind."
    },
    {
      "verse": "36",
      "text": "I tell you this: One day, God will judge everybody. On that day, he will ask you about every useless word that you have spoken."
    },
    {
      "verse": "37",
      "text": "God will think about the words that you have spoken. Then he will decide whether to let you go free or to punish you. ’"
    },
    {
      "verse": "38",
      "text": "Then some teachers of God's Law and some Pharisees said to Jesus, ‘Teacher, we want to see you do something powerful. This will show us that God has really sent you. ’"
    },
    {
      "verse": "39",
      "text": "Jesus replied, ‘The people who are alive today are very bad. They do not obey God, but they want God to show them something powerful. But God will not do this for them. They will only see the same powerful thing that God did for his prophet Jonah."
    },
    {
      "verse": "40",
      "text": "Jonah stayed inside a big fish for three days and three nights. In the same way, the Son of Man will remain in the ground for three days and three nights."
    },
    {
      "verse": "41",
      "text": "When God judges everyone, the people who lived in Nineveh will be there. They will stand up and they will speak against you. They will show that the people who are alive today are bad. When Jonah spoke to the people in Nineveh long ago, they stopped doing bad things. But look! There is someone here now who is greater than Jonah was."
    },
    {
      "verse": "42",
      "text": "Also, the Queen of Sheba travelled a long way to meet King Solomon. She wanted to hear his wise words. When God judges everyone, she will stand up. She will speak against you who are alive today. She will show that you are bad people. She listened to King Solomon. But look! There is someone here now who is greater than Solomon was. But you are not listening to me. ’"
    },
    {
      "verse": "43",
      "text": "Jesus then said, ‘When a bad spirit leaves a person, it travels through dry places. It looks for a new place to live. But maybe it does not find anywhere."
    },
    {
      "verse": "44",
      "text": "So it says to itself, “I will return to the place where I lived before. ” Then it goes back to that person. It finds that the place is empty. Everything there is now good and clean."
    },
    {
      "verse": "45",
      "text": "So the bad spirit goes out and it brings back seven other spirits. They are even worse than itself. They all go into the person and they live there. Now the person's life is even worse than it was before. The same thing will happen to you bad people who are alive today. ’"
    },
    {
      "verse": "46",
      "text": "While Jesus was still speaking to the crowd of people, his mother and his brothers arrived. They stood outside the house. They wanted to speak to Jesus."
    },
    {
      "verse": "47",
      "text": "Someone told him, ‘Look! Your mother and brothers are standing outside. They want to speak to you. ’"
    },
    {
      "verse": "48",
      "text": "Jesus replied, ‘I will tell you who my mother and my brothers really are. ’"
    },
    {
      "verse": "49",
      "text": "Then he pointed to his disciples. He said, ‘Look! Here are my mother and my brothers."
    },
    {
      "verse": "50",
      "text": "My brothers and sisters and my mother are those people who do what my Father in heaven wants. ’"
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "On that same day, Jesus left the house and he went to Lake Galilee. He sat down near the edge of the lake to teach people."
    },
    {
      "verse": "2",
      "text": "The crowd that came to listen to him was very large. So he went and sat in a boat that was on the water. The big crowd of people stood on the shore."
    },
    {
      "verse": "3",
      "text": "Jesus used stories to teach them many things. He said to them: ‘Listen to me! A farmer went out to plant seeds in his field."
    },
    {
      "verse": "4",
      "text": "While he was throwing the seeds, some of them fell on the path. The birds came and they ate those seeds."
    },
    {
      "verse": "5",
      "text": "Other seeds fell on ground which had rocks. There was not much soil in that place. The seeds quickly began to grow, because the soil was not deep."
    },
    {
      "verse": "6",
      "text": "But when the sun rose, it burned the young plants. They soon died because they had not grown down well into the soil."
    },
    {
      "verse": "7",
      "text": "Some other seeds fell among thorn bushes. Those bushes grew up with the young plants. They stopped the seeds from growing into strong plants."
    },
    {
      "verse": "8",
      "text": "But some seeds fell on good soil and strong plants grew from those seeds. Some plants made 100 new seeds. Some plants made 60 new seeds and some plants made 30 new seeds. ’"
    },
    {
      "verse": "9",
      "text": "Then Jesus said to the crowd, ‘You have ears, so listen well to what I say! ’"
    },
    {
      "verse": "10",
      "text": "Then Jesus' disciples came to him. They asked him, ‘Why do you use stories to speak to the crowd? ’"
    },
    {
      "verse": "11",
      "text": "Jesus replied, ‘God has let you know what these stories mean. You understand how God rules in the lives of his people. But these other people do not understand what the stories mean. These people look. But they do not really see clearly. They hear the words. But they do not really understand."
    },
    {
      "verse": "12",
      "text": "A person who has received some things will receive even more. He will have lots of good things. Some other people have nothing. Those people will lose even the little bit that they do have."
    },
    {
      "verse": "13",
      "text": "The reason I use stories to talk to other people is this: These people look. But they do not really see clearly. They hear the words. But they do not really understand."
    },
    {
      "verse": "14",
      "text": "Long ago, the prophet Isaiah spoke a message from God about those people. Now it has become true. God said:“You will listen and listen. But you will not understand. You will look and look. But you will not see anything. “You will listen and listen. But you will not understand. You will look and look. But you will not see anything."
    },
    {
      "verse": "15",
      "text": "These people do not really want to understand. They are like people who have shut their ears. They are like people who have shut their eyes. If they did want to look, then they would really see. If they did want to listen, then they would really hear. They would understand my message. They would turn back to obey me. Then I would forgive them and I would make them well. ” ’ They are like people who have shut their ears. They are like people who have shut their eyes. If they did want to look, then they would really see. If they did want to listen, then they would really hear. They would understand my message. They would turn back to obey me. Then I would forgive them and I would make them well. ” ’"
    },
    {
      "verse": "16",
      "text": "Then Jesus said to his disciples, ‘But as for you, be happy because God has helped you to see. He has helped you to hear and understand his message."
    },
    {
      "verse": "17",
      "text": "I tell you this: Many prophets and good people from a long time ago wanted to see these things. But they did not see the things that you are seeing. They wanted to hear the message that you are hearing. But they did not hear it. ’"
    },
    {
      "verse": "18",
      "text": "Jesus then said, ‘Listen to me now. I will tell you what this story about the farmer means."
    },
    {
      "verse": "19",
      "text": "Some people hear the message about God's kingdom but they do not understand it. Satan comes and he quickly takes the message away from their minds. The seeds that fell on the path show what those people are like."
    },
    {
      "verse": "20",
      "text": "Other seeds fell on soil with rocks in it. This is like some people who hear God's message. These people are happy to believe it for a time."
    },
    {
      "verse": "21",
      "text": "But they are like plants that have not grown down well into the soil. So they only believe for a short time. They may have problems. Or other people may do bad things to them, because they obey God's message. When that happens, these people soon stop believing."
    },
    {
      "verse": "22",
      "text": "Some seeds fell among thorn bushes. This is like people who hear the message from God. But they have many troubles in their minds. They want to get more money and more things. They think that this will make them happy. So they do not let God's message change them. They are like plants that do not grow well and make new seeds."
    },
    {
      "verse": "23",
      "text": "But some seeds fell on good soil. This is like other people who hear the message from God and they understand it. These people are like good plants that grow well. From one seed, some good plants make 100 new seeds. Other good plants make 60 new seeds, and some good plants make 30 new seeds. ’"
    },
    {
      "verse": "24",
      "text": "Then Jesus told the people another story. He said, ‘This is what the kingdom of heaven is like: A farmer planted some good wheat seeds into his field."
    },
    {
      "verse": "25",
      "text": "But one night, when everyone was sleeping, a bad person came to the farmer's field. He did not like the farmer. This bad person planted seeds from weeds among the good wheat seeds. Then the bad person went away again."
    },
    {
      "verse": "26",
      "text": "The good seeds grew and the plants began to make new seeds. But when this happened, the weeds also grew."
    },
    {
      "verse": "27",
      "text": "So the farmer's servants came to speak to him. “Master, you planted only good seeds in your field but now many weeds are also growing there. How did this happen? ” they asked him."
    },
    {
      "verse": "28",
      "text": "The farmer said to his servants, “A bad person who does not like me has done this. ”So the servants then asked the farmer, “Do you want us to go and pull up the weeds? ” So the servants then asked the farmer, “Do you want us to go and pull up the weeds? ”"
    },
    {
      "verse": "29",
      "text": "The farmer replied, “No, I do not want you to do that. If you pull up the weeds, you may also pull up some of the good wheat plants."
    },
    {
      "verse": "30",
      "text": "Let the good plants and the weeds grow up together. At harvest time, I will tell the workers to cut down the weeds first. Then they will tie them together and burn them. Then they will cut the wheat and bring it into my building. I will store it there. ” ’"
    },
    {
      "verse": "31",
      "text": "Jesus told the people another story. He said, ‘I will tell you again what the kingdom of heaven is like. It is like a very small seed of the plant called mustard. A man took this seed and he planted it in his field."
    },
    {
      "verse": "32",
      "text": "It is the smallest seed that there is. But when it starts to grow, it will become bigger than the largest bush. It will become a tree. The wild birds will come and they will build their nests among the branches of that tree. ’"
    },
    {
      "verse": "33",
      "text": "Jesus told the people another story. He said, ‘The kingdom of heaven is also like this. It is like how yeast works. A woman took the yeast and she mixed it into three large bowls of flour. Then the yeast went through all the flour so that it grew big. ’"
    },
    {
      "verse": "34",
      "text": "Jesus told the crowds of people all these things. But he only used stories to teach them. ‘I will use stories when I speak to them. And I will teach them secret things. People have never learned these things before, since the world began. ’"
    },
    {
      "verse": "35",
      "text": "So what God's prophet had said long ago now became true:‘I will use stories when I speak to them. And I will teach them secret things. People have never learned these things before, since the world began. ’"
    },
    {
      "verse": "36",
      "text": "Then Jesus told the crowds of people to go away. He went into the house where he was staying. His disciples also went into the house with him. They said to him, ‘Explain to us the story about the weeds that were growing in the field. ’"
    },
    {
      "verse": "37",
      "text": "Jesus replied, ‘The Son of Man is like the farmer who planted the good seed in the field."
    },
    {
      "verse": "38",
      "text": "The field is like the world. The good seeds are like the people who belong to God's kingdom. The weeds are like the people who belong to the Devil."
    },
    {
      "verse": "39",
      "text": "The Devil is the bad person who planted the weed seeds in the field. The time for harvest is like the end of time. God's angels are the workers who cut the plants down."
    },
    {
      "verse": "40",
      "text": "In the story, the workers cut down the weeds and they burned them in the fire. When this world comes to an end, it will happen like that."
    },
    {
      "verse": "41",
      "text": "The Son of Man will send his workers, who are his angels. They will remove from his kingdom everything that causes sin. They will take away everyone who does evil things."
    },
    {
      "verse": "42",
      "text": "The angels will throw those bad people into the great fire. There the people will cry and they will bite their teeth together."
    },
    {
      "verse": "43",
      "text": "The people who obeyed God will shine like the sun. They will be in the kingdom of their Father. You have ears, so listen well to what I say! ’"
    },
    {
      "verse": "44",
      "text": "‘I can tell you again what the kingdom of heaven is like, ’ Jesus said. ‘The kingdom of heaven is like some valuable things that a man buried in a field. Another man found it, but then he covered it over again with dirt. The second man was very happy and he went away. He sold everything that he had. Then he went and bought the field with the valuable things in it. ’"
    },
    {
      "verse": "45",
      "text": "‘I will tell you again what the kingdom of heaven is like, ’ Jesus said. ‘A trader looks for beautiful stones that he can buy."
    },
    {
      "verse": "46",
      "text": "One day he found a very valuable stone that someone wanted to sell. So he went away and he sold everything that he had. Then he went and he bought that very valuable stone. ’"
    },
    {
      "verse": "47",
      "text": "Jesus also said, ‘I can tell you again what the kingdom of heaven is like. Some men had nets to catch fish in. They threw their nets into the lake and they caught many different kinds of fish."
    },
    {
      "verse": "48",
      "text": "When the net was full of fish, the men pulled it up onto the shore. Then they sat down. Some of the fish were good to eat, and they put these fish into baskets. Some of the fish were not good to eat, and they threw these fish away."
    },
    {
      "verse": "49",
      "text": "This is what will happen when the world's time comes to an end. God will send his angels. They will put wicked people in one place. And they will put God's righteous people in a separate place."
    },
    {
      "verse": "50",
      "text": "The angels will throw the wicked people into the great fire. There those people will weep and they will bite their teeth together. ’"
    },
    {
      "verse": "51",
      "text": "Then Jesus asked his disciples, ‘Have you understood all these things? ’ They replied, ‘Yes, we have. ’"
    },
    {
      "verse": "52",
      "text": "Jesus said to them, ‘Some teachers of God's Law have now learned about the kingdom of heaven. These men are like the master of a house who takes things out of the room where he keeps them. Some of the valuable things he brings out are new and some of them are old. ’"
    },
    {
      "verse": "53",
      "text": "When Jesus had finished telling these stories, he went away from that place."
    },
    {
      "verse": "54",
      "text": "Jesus returned to his own town. He taught the Jewish people in their meeting room there. The people were very surprised about the things that he taught them. They said to each other, ‘We do not know how this man learned all these things. And we do not know how he does all these powerful things. Jesus said to them, ‘If a man is a prophet from God, people everywhere will say good things about him. But the people in his own town will not accept him. Even the people of his own house will not say good things about him. ’"
    },
    {
      "verse": "55",
      "text": "We know who he is. He is the son of the carpenter here. Mary is his mother. We also know his brothers, James, Joseph, Simon and Judas."
    },
    {
      "verse": "56",
      "text": "All his sisters also live here in the town among us. So then, where did he learn all these things? ’"
    },
    {
      "verse": "57",
      "text": "So the people there did not accept Jesus. Jesus said to them, ‘If a man is a prophet from God, people everywhere will say good things about him. But the people in his own town will not accept him. Even the people of his own house will not say good things about him. ’"
    },
    {
      "verse": "58",
      "text": "Jesus did not do many powerful things in that town because the people would not believe in him."
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "At that time, people told Herod about the things that Jesus was doing."
    },
    {
      "verse": "2",
      "text": "Herod said to his servants, ‘That man Jesus is really John the Baptist. John died but he has become alive again. That is the reason why this man can do these very powerful things. ’"
    },
    {
      "verse": "3",
      "text": "Before that, Herod had commanded his soldiers, ‘Take hold of John. Tie his hands and feet and put him in prison. ’ Herod had done this because of his wife Herodias. Before Herod married her, she was the wife of Herod's brother Philip."
    },
    {
      "verse": "4",
      "text": "John had said to Herod, ‘Herodias was your brother's wife. So it is not right for you to have her as your wife. ’"
    },
    {
      "verse": "5",
      "text": "Herod wanted to tell his soldiers that they must kill John. But the people thought that John was a prophet from God. So Herod was afraid to kill him."
    },
    {
      "verse": "6",
      "text": "One day, when it was Herod's birthday, he asked people to come to a special meal. The daughter of Herodias danced in front of him and his visitors. Her dance caused Herod to become very happy."
    },
    {
      "verse": "7",
      "text": "He said to the girl, ‘Ask me for anything that you want. I make a strong promise that I will give it to you. ’"
    },
    {
      "verse": "8",
      "text": "Herodias suggested to her daughter, ‘Ask Herod to give you John's head. ’ So the girl said to Herod, ‘Give me the head of John the Baptist on a plate. ’"
    },
    {
      "verse": "9",
      "text": "Then Herod felt sad. But he had made a special promise to the girl, and his visitors had heard him. So he sent his men to do what she had asked for."
    },
    {
      "verse": "10",
      "text": "He said to a soldier, ‘Go to the prison and cut off John's head. ’"
    },
    {
      "verse": "11",
      "text": "The soldier did this. Then he brought the head on a plate and he gave it to the girl. The girl took it and gave it to her mother."
    },
    {
      "verse": "12",
      "text": "After this, John's disciples went to the prison. They took away John's body and they buried it. Then they went and they told Jesus what had happened."
    },
    {
      "verse": "13",
      "text": "Jesus heard about what had happened to John. After that, he went away from that place. He sailed in a boat to a quiet place where he could be alone. But the crowd heard where Jesus had gone. So they left their towns and they went on land to the place where he was going."
    },
    {
      "verse": "14",
      "text": "Jesus got out of the boat. He saw a large crowd there on the shore. He felt sorry for them. There were sick people among them and he made them well again."
    },
    {
      "verse": "15",
      "text": "When it was almost evening, Jesus' disciples came to speak to him. They said to him, ‘We are in a place where there are no houses. It will soon be dark. Send the crowd away now, so that they can go to the villages near here. Then they can buy some food for themselves to eat. ’"
    },
    {
      "verse": "16",
      "text": "Jesus said to them, ‘The people do not need to go away. You should give them some food to eat. ’"
    },
    {
      "verse": "17",
      "text": "But the disciples said, ‘We only have five loaves of bread and two fish. ’"
    },
    {
      "verse": "18",
      "text": "‘Bring the bread and fish here to me, ’ Jesus said."
    },
    {
      "verse": "19",
      "text": "Then he said to the large crowd, ‘Sit down on the grass. ’ He took the five loaves of bread and the two fish. He looked up to heaven and he thanked God for the bread and the fish. Then he broke the bread into pieces. He gave the pieces of bread to his disciples, and they gave them to the crowd."
    },
    {
      "verse": "20",
      "text": "Then everybody ate. They all had enough food and they were not hungry any more. Then the disciples picked up all the bits of food that people had not eaten. They filled 12 baskets with little bits of bread and fish."
    },
    {
      "verse": "21",
      "text": "About 5, 000 men ate the bread and fish. Women and children also ate it with them."
    },
    {
      "verse": "22",
      "text": "Immediately after this, Jesus said to his disciples, ‘Get in the boat and sail across to the other side of the lake. ’ Jesus said that he would first send the crowd away. Then he would also leave."
    },
    {
      "verse": "23",
      "text": "So Jesus sent the crowd away. After they had gone, he went up on a mountain alone to pray. When it became dark, he was still there alone."
    },
    {
      "verse": "24",
      "text": "At this time the boat with the disciples in it was in the middle of the lake. It was a long way from the land. The wind was blowing against the boat and the water was hitting it."
    },
    {
      "verse": "25",
      "text": "Then, when it was nearly dawn, Jesus walked on the water towards his disciples."
    },
    {
      "verse": "26",
      "text": "The disciples saw him walking on the water. They were very frightened. ‘It is a spirit, ’ they said. They screamed loudly because they were afraid."
    },
    {
      "verse": "27",
      "text": "But immediately Jesus said to them. ‘Be brave! It is I. Do not be afraid. ’"
    },
    {
      "verse": "28",
      "text": "Peter replied, ‘Lord, is it really you? If it is you, say to me, “Come here! Walk to me on the water. ” ’"
    },
    {
      "verse": "29",
      "text": "Jesus said to him, ‘Come to me. ’So Peter got down out of the boat. He walked on the water and he came towards Jesus."
    },
    {
      "verse": "30",
      "text": "But then Peter saw that the wind was still blowing strongly. He became afraid and he began to go down into the water. He shouted to Jesus, ‘Lord, save me! ’"
    },
    {
      "verse": "31",
      "text": "Immediately, Jesus put out his hand and he took hold of Peter. He said to Peter, ‘You should trust me more than you do. Why did you not believe that I could help you? ’"
    },
    {
      "verse": "32",
      "text": "Jesus and Peter climbed up into the boat. Then the strong wind stopped."
    },
    {
      "verse": "33",
      "text": "The disciples who were in the boat went down on their knees. They praised Jesus and they said to him, ‘It is true. You are really the Son of God. ’"
    },
    {
      "verse": "34",
      "text": "They sailed across the lake and reached the shore at a place called Gennesaret."
    },
    {
      "verse": "35",
      "text": "The people who lived in that place recognized Jesus. So they went to tell everyone who lived in places near there. People brought all their sick friends to him."
    },
    {
      "verse": "36",
      "text": "The sick people asked Jesus for help. They wanted to touch only the edge of his coat. Every sick person who touched him became well again."
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "After that, a group of Pharisees and teachers of God's Law came from Jerusalem to talk to Jesus."
    },
    {
      "verse": "2",
      "text": "They said, ‘Our leaders in past times taught us the right way to do everything. But your disciples do not obey the things that our leaders taught us. They do not wash their hands in the right way before they eat a meal. Why is that? ’"
    },
    {
      "verse": "3",
      "text": "Jesus replied, ‘God tells us the right way to obey him. But you refuse. Instead, you like to keep your own ideas."
    },
    {
      "verse": "4",
      "text": "God's Law says: “You must love your father and mother and obey them. ” God also said, “A person should die if he says bad things against his father or against his mother. ”"
    },
    {
      "verse": "5",
      "text": "But you teach that a person may say to his father or to his mother, “I would have given gifts to help you. But I cannot do that because I have given them to God instead. ”"
    },
    {
      "verse": "6",
      "text": "Then, you let that person give nothing to his parents. He does not have to help them. This shows that you have not obeyed what God says is right. Instead, you have obeyed your own ideas."
    },
    {
      "verse": "7",
      "text": "You are hypocrites! What God's prophet Isaiah wrote about you long ago is true:"
    },
    {
      "verse": "8",
      "text": "God says, “These people say good things about me, but they do not really want to obey me. but they do not really want to obey me."
    },
    {
      "verse": "9",
      "text": "They say that I am great. But what they say has no purpose. They teach their own rules, which I did not give to them. ” ’ But what they say has no purpose. They teach their own rules, which I did not give to them. ” ’"
    },
    {
      "verse": "10",
      "text": "Jesus asked the crowd of people to come to him. He said to them, ‘Listen to me, so that you can understand my message."
    },
    {
      "verse": "11",
      "text": "It is not food that goes into people's mouths that makes them unclean. Instead, what comes out of people's mouths is important. It may show that what is inside them is unclean. ’"
    },
    {
      "verse": "12",
      "text": "Then Jesus' disciples went to him, and they said, ‘The Pharisees heard what you said. They did not agree with what you said. Do you know that? ’"
    },
    {
      "verse": "13",
      "text": "Jesus replied, ‘Those Pharisees are like plants that my Father God did not put in the ground. Like a farmer, he will completely pull all those plants out of the ground."
    },
    {
      "verse": "14",
      "text": "Do not listen to what the Pharisees say. They are blind, but they try to show people which way to go. A blind person cannot lead another blind person. If he does, then both of them will fall into a deep hole. ’"
    },
    {
      "verse": "15",
      "text": "Peter said to Jesus, ‘Explain to us what you mean. ’"
    },
    {
      "verse": "16",
      "text": "Jesus replied, ‘I am surprised that you still do not understand what I am saying."
    },
    {
      "verse": "17",
      "text": "You should understand that food first goes into people's mouths. Then it goes into their stomach, and then it passes out of their body."
    },
    {
      "verse": "18",
      "text": "The words that people speak come from their thoughts. It is what comes out of their mouths that makes them unclean."
    },
    {
      "verse": "19",
      "text": "Evil thoughts come out from people's minds. As a result, they do wrong things. They murder people. They have sex with another man's wife. They have sex in other wrong ways. They rob people. They tell lies about other people. They insult people."
    },
    {
      "verse": "20",
      "text": "It is these bad things that make people unclean. But if people eat food when they have not washed their hands in the right way, that will not make them unclean. ’"
    },
    {
      "verse": "21",
      "text": "Then, Jesus left that place. He went away to some places near to the cities called Tyre and Sidon."
    },
    {
      "verse": "22",
      "text": "A woman was living in this part of the country. She was one of the Canaanite people. She came to see Jesus. She was shouting with a loud voice, ‘Son of David, help me, sir! A bad spirit is living inside my daughter. It is giving her much pain. ’"
    },
    {
      "verse": "23",
      "text": "Jesus did not say anything to the woman. So his disciples came to him. They said, ‘Please, send this woman away. She is following us and she is making a lot of noise. ’"
    },
    {
      "verse": "24",
      "text": "Jesus replied to his disciples, ‘God has sent me to help only the people of Israel. They are like sheep that have lost their way. ’"
    },
    {
      "verse": "25",
      "text": "Then the woman came to Jesus and she went down on her knees in front of him. ‘Sir, please help me, ’ she said."
    },
    {
      "verse": "26",
      "text": "Jesus did answer the woman this time. He said, ‘It is not right to take food from the children and then throw it to the dogs. ’"
    },
    {
      "verse": "27",
      "text": "The woman replied to Jesus. ‘Yes sir, that is true. But even the dogs eat the small pieces of food that fall from their master's table. ’"
    },
    {
      "verse": "28",
      "text": "Jesus answered her, ‘Woman, you show clearly that you believe in God. God will do what you have asked. ’At that moment the woman's daughter became well again. At that moment the woman's daughter became well again."
    },
    {
      "verse": "29",
      "text": "Jesus travelled on from that place and he walked along the shore of Lake Galilee. He climbed up a hill and he sat down there."
    },
    {
      "verse": "30",
      "text": "Large crowds of people came to him and they brought sick people with them. Some of these sick people could not walk very well, and some of them were blind. Some of them could not use their arms or their legs. Some of them could not speak. There were many other sick people who had different illnesses. Their friends put the sick people in front of Jesus. And Jesus caused them all to become well again."
    },
    {
      "verse": "31",
      "text": "When the large crowd saw all this, they were very surprised. People who could not speak could now speak again. People who could not use their arms or their legs were now well again. Those people who could not walk very well could now walk again. Blind people could now see again. All the people praised God, and they said, ‘God of Israel, you are great. ’"
    },
    {
      "verse": "32",
      "text": "Then Jesus told his disciples to come to him. ‘I feel sorry for this crowd, ’ he said to them. ‘They have been here with me now for three days. They do not have any food. I do not want to send them away while they are hungry. They might fall down during their journey because they are weak. ’"
    },
    {
      "verse": "33",
      "text": "The disciples said to Jesus, ‘This place is a long way from any houses. We cannot get enough bread here to feed so many people. ’"
    },
    {
      "verse": "34",
      "text": "Jesus asked them, ‘How many loaves of bread do you have? ’They replied, ‘We have seven loaves and a few small fish. ’ They replied, ‘We have seven loaves and a few small fish. ’"
    },
    {
      "verse": "35",
      "text": "Jesus told the crowd that they should sit down on the ground."
    },
    {
      "verse": "36",
      "text": "Then he took the seven loaves and the fish in his hands and he thanked God for them. Then he broke the bread and the fish into pieces and he gave the food to his disciples. The disciples gave the food to the people."
    },
    {
      "verse": "37",
      "text": "All the people ate and they all had enough food. After the people had eaten, there were still lots of small pieces of food. Jesus' disciples filled seven baskets with these pieces."
    },
    {
      "verse": "38",
      "text": "There were 4, 000 men who ate the bread and fish. There were also women and children who ate."
    },
    {
      "verse": "39",
      "text": "Then Jesus sent the crowd of people away. After that, he got into the boat and sailed to the part of the country near Magadan."
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "Some Pharisees and Sadducees went to see Jesus. They wanted to test him to see what he would do. They asked him, ‘Do something powerful for us to see. Then we will believe that God has sent you. ’"
    },
    {
      "verse": "2",
      "text": "Jesus answered them, ‘Sometimes the sky is red in the evening. Then you say, “Tomorrow the weather will be good. ” Then Jesus went away and left them."
    },
    {
      "verse": "3",
      "text": "Sometimes in the morning the sky is red and there are dark clouds. Then you say, “Today there will be a storm. ” So you look at the sky and you know what the weather will be. But special things are happening now. And you do not understand what they mean."
    },
    {
      "verse": "4",
      "text": "The people who are alive today are very bad. They do not obey God. They want God to show them something powerful. But God will not do this for them. They will only see the same powerful thing that God did for Jonah. ’Then Jesus went away and left them."
    },
    {
      "verse": "5",
      "text": "Jesus and his disciples sailed over to the other side of the lake. His disciples forgot to take any bread with them."
    },
    {
      "verse": "6",
      "text": "Jesus said to them, ‘Be careful! Do not accept the yeast of the Pharisees and the Sadducees. ’"
    },
    {
      "verse": "7",
      "text": "The disciples began to talk to each other about this. ‘Jesus is saying this because we did not bring any bread with us, ’ they said."
    },
    {
      "verse": "8",
      "text": "Jesus knew what they were talking about. So he said to them, ‘You should not be arguing with each other about the bread. You should trust me more than you do."
    },
    {
      "verse": "9",
      "text": "You still do not understand. You should remember that I used five loaves of bread to feed 5, 000 men. Think about how many baskets you filled with pieces of food after the meal."
    },
    {
      "verse": "10",
      "text": "Also remember that I used seven loaves of bread to give food to 4, 000 men. And think about how many baskets you filled with pieces of food then."
    },
    {
      "verse": "11",
      "text": "I spoke to you about the yeast of the Pharisees and the Sadducees. I said that you must not accept it. You should understand now that I was not speaking about bread. ’"
    },
    {
      "verse": "12",
      "text": "Then the disciples understood what Jesus was talking about. They did not need to be careful about the yeast that they used in their bread. Instead, they must be careful about what the Pharisees and Sadducees were teaching. They must not accept it."
    },
    {
      "verse": "13",
      "text": "Jesus went into the part of the country near Caesarea Philippi. While he was there, he asked his disciples, ‘When people talk about the Son of Man, who do they say that he is? ’"
    },
    {
      "verse": "14",
      "text": "They replied, ‘Some people say that you are John the Baptist. Other people say that you are Elijah. And some other people say that you are Jeremiah, or another prophet of God. ’"
    },
    {
      "verse": "15",
      "text": "‘But what do you think? ’ Jesus asked them. ‘Who do you say that I am? ’"
    },
    {
      "verse": "16",
      "text": "Simon Peter answered him. ‘You are the Messiah. You are the Son of God, the God who lives for ever. ’"
    },
    {
      "verse": "17",
      "text": "Jesus said to Simon Peter, ‘Simon, son of Jonah, God has blessed you! No person on earth taught you that. God, my Father in heaven, has shown you this."
    },
    {
      "verse": "18",
      "text": "I tell you this. You are called Peter, which means a rock. And I will build my church on this rock. Not even the power of death will destroy my church."
    },
    {
      "verse": "19",
      "text": "I will give you the keys to the kingdom of heaven. You will tell people here on earth what is right for them to do. And you will tell them what is not right for them to do. God in heaven will give you this authority. He will agree with what you say. ’"
    },
    {
      "verse": "20",
      "text": "Then Jesus said strongly to his disciples, ‘Do not tell anyone that I am the Messiah. ’"
    },
    {
      "verse": "21",
      "text": "After this, Jesus began to explain everything to his disciples. He told them, ‘I must go to Jerusalem. There, I will suffer in many ways. The important Jews, the leaders of the priests, and the teachers of God's Law will hurt me. Then people will kill me. But three days later, God will cause me to become alive again. ’"
    },
    {
      "verse": "22",
      "text": "Then Peter took Jesus away from the other disciples. He began to tell Jesus that he must not say things like that. ‘No, Lord! God will never let this happen to you! ’ he said to Jesus."
    },
    {
      "verse": "23",
      "text": "Jesus turned round and said to Peter, ‘Satan, go away from me! I must obey God. But you are trying to stop me. Your thoughts do not come from God. Instead, you are thinking like men think. ’"
    },
    {
      "verse": "24",
      "text": "Then Jesus said to his disciples, ‘A person who wants to come with me must not think about himself. He must decide that his own life is not important. He must be like someone who carries his own cross to go and die. Then he may come with me as my disciple."
    },
    {
      "verse": "25",
      "text": "Whoever wants to keep his life safe will lose it. But whoever gives his life to serve me will have true life."
    },
    {
      "verse": "26",
      "text": "A person may get everything in the whole world for himself. But if he loses his life, it will not be any good for him. There is nothing that a person can give to get back his life."
    },
    {
      "verse": "27",
      "text": "I tell you all this because I, the Son of Man, will come back to this earth with God's angels. When I come, I will have the powerful beauty of my Father. I will see what each person has done on earth. Then I will pay them what is right."
    },
    {
      "verse": "28",
      "text": "I tell you this: When I, the Son of Man, come with power, some people who are standing here will see me at that time. Before they die, they will see me begin to rule in my kingdom. ’"
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "Six days after that, Jesus asked Peter and the two brothers, James and John, to go with him. Jesus led them up a high mountain by themselves."
    },
    {
      "verse": "2",
      "text": "Peter, James and John saw Jesus change in front of them. He became different to look at. His face was bright like the sun. His clothes became very white and they shone."
    },
    {
      "verse": "3",
      "text": "Then Moses and Elijah appeared in front of the three disciples. They were talking with Jesus."
    },
    {
      "verse": "4",
      "text": "Peter said to Jesus, ‘Lord, it is good that we are here. If you want, please let me build three huts. One hut will be for you. One hut will be for Moses and one hut will be for Elijah. ’"
    },
    {
      "verse": "5",
      "text": "While Peter was still speaking, a bright cloud appeared. It covered them all. A voice spoke from the cloud and it said, ‘This is my Son and I love him. He makes me very happy. Listen to him. ’"
    },
    {
      "verse": "6",
      "text": "The disciples heard the voice. They threw themselves down to the ground. They were very frightened."
    },
    {
      "verse": "7",
      "text": "But Jesus came to them and he touched them. ‘Stand up, ’ he said. ‘Do not be afraid. ’"
    },
    {
      "verse": "8",
      "text": "When they looked up, they could not see anyone else. Only Jesus was there with them."
    },
    {
      "verse": "9",
      "text": "While they were walking down the mountain, Jesus said to the three disciples, ‘You must not tell anyone now about the things that you have just seen. One day, the Son of Man will die and then he will become alive again. Then you can tell people about these things. ’"
    },
    {
      "verse": "10",
      "text": "Then the three disciples said to Jesus, ‘The teachers of God's Law say that God's prophet Elijah must return first, before the Messiah comes. Why do they say this? ’"
    },
    {
      "verse": "11",
      "text": "Jesus replied, ‘Yes, Elijah does come first. He gets everything ready."
    },
    {
      "verse": "12",
      "text": "But I tell you that Elijah has already come. People did not recognize him. They did to him all the things that they wanted to do. In the same way, they will also give me, the Son of Man, great pain. ’"
    },
    {
      "verse": "13",
      "text": "Then the disciples understood that he was really talking about John the Baptist."
    },
    {
      "verse": "14",
      "text": "Then Jesus, and the three disciples reached the place where the crowd was. A man came to Jesus. He went down on his knees in front of him."
    },
    {
      "verse": "15",
      "text": "He said to Jesus, ‘Please sir, be kind to my son. He cannot control his body. Sometimes he does not know what he is doing. Often he falls into the fire, or he falls into water."
    },
    {
      "verse": "16",
      "text": "I brought the boy to your disciples, but they could not make him well. ’"
    },
    {
      "verse": "17",
      "text": "Jesus replied, ‘You people today still do not believe in God. You have turned away from him. I have been with you for a long time and still you do not believe. It is difficult for me to be patient with you. ’ Then Jesus said to the man, ‘Bring the boy here to me. ’"
    },
    {
      "verse": "18",
      "text": "Jesus said to the bad spirit, ‘Stop! ’ Then the bad spirit left the boy and immediately he became well again."
    },
    {
      "verse": "19",
      "text": "When the disciples were alone with Jesus, they asked him, ‘Why could we not make the bad spirit leave the boy? ’"
    },
    {
      "verse": "20",
      "text": "Jesus replied, ‘You could not do it because you do not trust God very much. I tell you this: You may believe in God only a little bit, like a very small seed. Even then, you could say to this mountain, “Go away from this place and move to that other place. ” Then it will move. Nothing will be impossible for you to do. ’ ["
    },
    {
      "verse": "21",
      "text": "Jesus then said, ‘This kind of spirit will not leave a person unless you pray and you do not eat for a time. ’]"
    },
    {
      "verse": "22",
      "text": "When Jesus and his disciples all met together in Galilee, he said, ‘Soon they will deliver the Son of Man to powerful people."
    },
    {
      "verse": "23",
      "text": "They will kill him. But three days after that, he will become alive again. ’ When the disciples heard that, they were very sad."
    },
    {
      "verse": "24",
      "text": "After that, Jesus and his disciples arrived at Capernaum. Some men who received taxes for the temple went to talk to Peter. They asked him, ‘Does your teacher pay the tax for the temple? ’"
    },
    {
      "verse": "25",
      "text": "Peter answered them, ‘Yes, my teacher does pay the tax. ’Then Peter returned to the house where Jesus was staying. Before Peter could say anything, Jesus spoke to him first. He said, ‘Here is a question for you to answer, Simon. Who are the people who must pay taxes and money to the kings in this world? Do the rulers take taxes from their own people? Or do they take taxes from other people? ’ Then Peter returned to the house where Jesus was staying. Before Peter could say anything, Jesus spoke to him first. He said, ‘Here is a question for you to answer, Simon. Who are the people who must pay taxes and money to the kings in this world? Do the rulers take taxes from their own people? Or do they take taxes from other people? ’"
    },
    {
      "verse": "26",
      "text": "‘They take the taxes from other people, ’ Peter replied. Jesus said to him, ‘This means that people from the ruler's own country do not need to pay anything."
    },
    {
      "verse": "27",
      "text": "But we do not want to make these men who take the tax angry. So go to the lake and throw out a line to catch fish. Pull up the first fish that you catch on your line. Open the mouth of the fish and you will find a coin inside it. Take the coin and give it to those who receive taxes for the temple. This will be enough money for both my tax and yours. ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "Soon after this, the disciples came to Jesus and they asked him, ‘Who is the most important person in the kingdom of heaven? ’"
    },
    {
      "verse": "2",
      "text": "Jesus called a child to come to him. He made the child stand in the middle of them all."
    },
    {
      "verse": "3",
      "text": "He said, ‘I tell you this: You must change and become like little children. If not, you will never come into the kingdom of heaven."
    },
    {
      "verse": "4",
      "text": "This little child does not think that he is very important. You must also think as he does. Whoever does this will be the most important person in the kingdom of heaven."
    },
    {
      "verse": "5",
      "text": "If anyone accepts a child like this because of me, that person also accepts me. ’"
    },
    {
      "verse": "6",
      "text": "Jesus said, ‘A person who believes in me may not seem important. But you should never make that person do wrong things. Do not do that! It would be better for you if someone tied a big stone round your neck. Then you would sink deep down into the sea and die."
    },
    {
      "verse": "7",
      "text": "Some things in this world will cause people to do wrong things. You can be sure that bad things will happen. But it will be very bad for the person who makes these things happen."
    },
    {
      "verse": "8",
      "text": "If your hand or your foot causes you to do wrong things, you should cut it off. You should throw it away. It is better to have only one hand or one foot and to have God's true life. It will be much worse to keep both your hands and both your feet and still do wrong things. Then God will throw you into hell, where the fire always burns."
    },
    {
      "verse": "9",
      "text": "If your eye causes you to do wrong things, then you should take it out. You should throw it away. It is better to have only one of your eyes and to have God's true life. It will be much worse if you keep both your eyes but then God throws you into hell. There the fire always burns."
    },
    {
      "verse": "10",
      "text": "Be careful! Do not think that any of these little people are not important. I tell you this. They have angels who watch over them. Those angels are always standing in front of my Father in heaven."
    },
    {
      "verse": "11",
      "text": "[I, the Son of Man, came to look for those who are far away from God. ]"
    },
    {
      "verse": "12",
      "text": "sheep. He discovers that one of his sheep is not there with the others. What does he do? He leaves all his other sheep on the hills. He goes to look for the one lost sheep."
    },
    {
      "verse": "13",
      "text": "And I tell you this: If he finds that lost sheep, he will be very happy. All the other sheep are safe together. But they do not make him as happy as this one sheep does."
    },
    {
      "verse": "14",
      "text": "God, your Father in heaven, is like that shepherd. He does not want any of these little people to be lost, not even one of them. ’"
    },
    {
      "verse": "15",
      "text": "Jesus said, ‘If your Christian friend has done something wrong against you, you must go and speak to him. When you are alone with him, tell him what he has done that is wrong. He may agree with what you say. If he does, then you can call him your friend again."
    },
    {
      "verse": "16",
      "text": "But maybe he does not want to listen to you. Then take one or two other people with you to speak to him. They will then know what wrong things your friend has done. Remember what the Bible says: “There must be two or three people to say certainly that another person has done something wrong. Two or three people must agree what has happened. ”"
    },
    {
      "verse": "17",
      "text": "If your friend still will not agree that he has done something wrong, then go and tell the church leaders. If he does not agree with the leaders, stop being his friend. He is like somebody who refuses to obey God."
    },
    {
      "verse": "18",
      "text": "I tell you this: You will tell people here on earth what is right for them to do. And you will tell them what is not right for them to do. God in heaven will give you this authority. He will agree with what you say."
    },
    {
      "verse": "19",
      "text": "Two people may agree together to ask God for something. If they agree like that, then my Father in heaven will give them what they ask for."
    },
    {
      "verse": "20",
      "text": "Two or more people may meet together because they believe in me. If they do that, I will be there with them. ’"
    },
    {
      "verse": "21",
      "text": "Then Peter came to talk to Jesus. He asked, ‘Lord, if my friend does wrong things against me many times, how many times should I forgive him? Must I forgive him as many as seven times for the wrong things that he has done against me? ’"
    },
    {
      "verse": "22",
      "text": "Jesus replied, ‘I do not say only seven times. I say you should forgive him 77 times! ’"
    },
    {
      "verse": "23",
      "text": "Jesus then said, ‘I will tell you a story to show what the kingdom of heaven is like. A king wanted to check how much money his servants should give to him because of their debts."
    },
    {
      "verse": "24",
      "text": "So the king began to check. His men led a servant to him who had a big debt. He must pay back 10, 000 gold coins to the king."
    },
    {
      "verse": "25",
      "text": "The servant could not pay his big debt to the king. So the king said to his men, “Sell the servant and his wife and his children and all his things. Then I will keep the money to pay his debt. ”"
    },
    {
      "verse": "26",
      "text": "Then the servant went down on his knees in front of the king. He said to the king, “Please, please give me some more time, then I will pay you everything. ”"
    },
    {
      "verse": "27",
      "text": "The king felt sorry for his servant. He forgave him for all the debt and let him go free."
    },
    {
      "verse": "28",
      "text": "But then that same servant went away and he met another servant of the king. This other servant had to pay back a debt of 100 silver coins to the first servant. The first servant took hold of the neck of the other servant to hurt him. He said, “Give me the money that is mine. ”"
    },
    {
      "verse": "29",
      "text": "The other servant went down on his knees in front of the first servant. He said, “Please, please give me some more time, then I will give you the money. ”"
    },
    {
      "verse": "30",
      "text": "But the first servant would not agree. He put the other servant in prison until he could pay his debt to him."
    },
    {
      "verse": "31",
      "text": "The other servants of the king saw what had happened. They were very upset about it. So they went to see the king. They told him about everything that had happened."
    },
    {
      "verse": "32",
      "text": "When the king heard this, he told the first servant to come to him. “You are a very bad person, ” the king said to the servant. “I forgave you the whole of your big debt to me. I did this because you asked me very strongly."
    },
    {
      "verse": "33",
      "text": "I was kind to you. You should have been kind to that other servant in the same way. ”"
    },
    {
      "verse": "34",
      "text": "The king was very angry with the first servant. He told his men to put him in prison. They punished the servant there very much, until he could pay all his debt to the king. ’"
    },
    {
      "verse": "35",
      "text": "Then Jesus finished the story and he said, ‘You must forgive your friends completely. If you do not agree to forgive them, then my Father in heaven will do like that king did. He will not forgive you. ’"
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "When Jesus had finished saying all these things, he went away from Galilee. He went to the part of Judea that is on the other side of the Jordan River."
    },
    {
      "verse": "2",
      "text": "Large crowds followed Jesus there. He made the sick people well again."
    },
    {
      "verse": "3",
      "text": "Some Pharisees came to talk to Jesus. They wanted to see how he would answer their question. They asked, ‘Can a man send his wife away so that she is no longer his wife? Is it right for him to do that for any reason he chooses? ’"
    },
    {
      "verse": "4",
      "text": "Jesus replied, ‘You surely have read about this in the Bible. At the start, when God created the world, he made people male and female."
    },
    {
      "verse": "5",
      "text": "Because of this, a man leaves his father and his mother. God joins him and his wife together. The man and the woman become like one body."
    },
    {
      "verse": "6",
      "text": "They are not two separate people any longer. They have come together as one person. God has put them together to be husband and wife. So nobody should make them separate. ’"
    },
    {
      "verse": "7",
      "text": "Then the Pharisees said to Jesus, ‘Moses said that a man could write a letter to say that he and his wife are no longer married. Then the man can send the woman away. Why did Moses say this? ’"
    },
    {
      "verse": "8",
      "text": "Jesus answered them, ‘Moses said this because you people did not want to obey God. All these things were different at the start, when God made the world."
    },
    {
      "verse": "9",
      "text": "But now I say to you: A man must not send his wife away and marry another woman. If he does that, it is the same as if he had sex with another man's wife. A man may only send his wife away if she has had sex with another man. ’"
    },
    {
      "verse": "10",
      "text": "Jesus' disciples said to him, ‘You say that this is what it is like for a man and his wife. Then maybe it is better if people do not marry. ’"
    },
    {
      "verse": "11",
      "text": "Jesus replied, ‘Not everyone can agree with this idea. But God has helped some people to agree with it."
    },
    {
      "verse": "12",
      "text": "There are several different reasons why a person may not marry. Some men cannot have sex. They were born like that. Some other people cannot have sex because people did something to them. Some people choose not to have sex. They do not marry because then they can work better for God and his kingdom. Anyone who can agree with this idea should do it. ’"
    },
    {
      "verse": "13",
      "text": "Then some people brought their little children to Jesus. They wanted him to put his hands on each child's head. They wanted him to pray for them. But the disciples told the people that they should not do that."
    },
    {
      "verse": "14",
      "text": "Jesus said to them, ‘Do not stop the children. Let them come to me. People must become like these children so that God can rule their lives. That is what the kingdom of heaven is like. ’"
    },
    {
      "verse": "15",
      "text": "So Jesus put his hands on each of the children's heads and he prayed for them. After that, he went away from that place."
    },
    {
      "verse": "16",
      "text": "One day a man came to Jesus. ‘Teacher, ’ he asked. ‘What good thing must I do so that I can live with God for ever? ’"
    },
    {
      "verse": "17",
      "text": "Jesus replied, ‘Why do you ask me about a good thing? Only God is good. Nobody else. If you want to have real life, then you must obey God's laws. ’"
    },
    {
      "verse": "18",
      "text": "The man asked Jesus, ‘Which laws must I obey? ’So Jesus replied, ‘Do not kill anyone. Do not have sex with anyone who is not your wife. Do not rob anyone. Do not say things that are not true about people."
    },
    {
      "verse": "19",
      "text": "Love your father and your mother and obey them. Love other people as much as you love yourself. ’"
    },
    {
      "verse": "20",
      "text": "‘I have always obeyed these laws, ’ the young man replied. ‘What else must I do? ’"
    },
    {
      "verse": "21",
      "text": "Jesus said to him, ‘If you want to be completely good, then you must do this: You must sell everything that you have. Then give the money to poor people. If you do that, you will have many valuable things in heaven. Then come back and be my disciple. ’"
    },
    {
      "verse": "22",
      "text": "When the young man heard this, he went away. He was not happy. He was feeling sad because he was a very rich man."
    },
    {
      "verse": "23",
      "text": "Then Jesus said to his disciples, ‘What I say is true. It is very difficult for rich people to let God rule in their lives."
    },
    {
      "verse": "24",
      "text": "The hole in a needle is very small. A camel cannot go through it! But I tell you, it is even more difficult than that for a rich person to let God rule in their life. ’"
    },
    {
      "verse": "25",
      "text": "When the disciples heard this, they were even more surprised. They said, ‘So perhaps God will not save anyone! ’"
    },
    {
      "verse": "26",
      "text": "Jesus looked at them and he replied, ‘For people, it really is impossible. But God can do it. God can do everything. ’"
    },
    {
      "verse": "27",
      "text": "Peter said to Jesus, ‘Look! We have left everything that we had. Now we are your disciples. What will we receive because we have done this? ’"
    },
    {
      "verse": "28",
      "text": "Jesus said to his disciples, ‘I tell you this: One day God will cause all things to become new. I, the Son of Man, will sit on my great throne as King and I will rule that new world. You who are my disciples will also sit like kings on thrones. You will judge the people of the 12 tribes of Israel."
    },
    {
      "verse": "29",
      "text": "Some people have left their homes. Or they may have left their brothers or sisters. Or they may have left their mother or their father. Or they may have left their wife or their children or their fields. They have done that because of me. God will give those people many more things than they have left behind, even 100 times more! And after they die, they will live for ever with God."
    },
    {
      "verse": "30",
      "text": "But many people who are very important now will become the least important. And many people who are not important now will become very important then. ’"
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "Jesus said, ‘I will tell you a story to show what the kingdom of heaven is like. There was an important man who had a field where he grew grapes. He went out early in the morning. He wanted to find some people who would work in his field."
    },
    {
      "verse": "2",
      "text": "The master agreed with the workers that he would pay them one silver coin for a day's work. Then he sent them to work in the field."
    },
    {
      "verse": "3",
      "text": "The master went out again about three hours later. He saw some other men standing in the market place. They had no work to do."
    },
    {
      "verse": "4",
      "text": "So the master said to these men, “You also go and work in my field. I will pay you the right amount of money. ”"
    },
    {
      "verse": "5",
      "text": "So the workers went to the master's field and started to work. The master went out again at noon, and he went again three hours after that. Both times he sent men to his field to work."
    },
    {
      "verse": "6",
      "text": "Two hours later, at five o'clock, he went out again. He found more men who were standing there. And they had no work to do. The master asked them, “Why are you standing here all day and you are not working? ”"
    },
    {
      "verse": "7",
      "text": "The men said to the master, “Nobody has asked us to work for him. ”So the master said to them, “You also go now and work in my field. ” So the master said to them, “You also go now and work in my field. ”"
    },
    {
      "verse": "8",
      "text": "Then the evening came. The master of the field spoke to the man who had authority over the workers. He said to him, “Tell the workers to come here. Pay them their money. Begin with the workers who started to work at the end of the day. Finish with the workers who started first. ”"
    },
    {
      "verse": "9",
      "text": "The workers who had come to work at five o'clock in the evening received one silver coin each."
    },
    {
      "verse": "10",
      "text": "The workers who had come to work first thought that they would receive more than the other workers. But each of them also received one silver coin."
    },
    {
      "verse": "11",
      "text": "When they received their money, they were not happy. They told the master that he had not been fair to them."
    },
    {
      "verse": "12",
      "text": "They said to him, “Some of these other workers came last and only worked for one hour. But you have paid them the same money as you paid us. And we have worked all day in the hot sun. ”"
    },
    {
      "verse": "13",
      "text": "Then the master said to one of the workers, “My friend, I am being fair to you. You agreed to work for one day and to receive one silver coin."
    },
    {
      "verse": "14",
      "text": "Take your money and go home. I choose to give this last man the same amount of money as I gave to you."
    },
    {
      "verse": "15",
      "text": "It is my money. I can choose what to do with it. I want to be kind to people and give them more than we agreed. Does that make you upset? ” ’"
    },
    {
      "verse": "16",
      "text": "Jesus then said, ‘So, one day, those people who are not important now will become the most important. Those people who are very important now will become the least important. ’"
    },
    {
      "verse": "17",
      "text": "Jesus and his disciples were going towards Jerusalem. As they walked along, Jesus took his 12 disciples away from the other people where he could speak to them alone."
    },
    {
      "verse": "18",
      "text": "‘Listen! ’ he said to them. ‘We are going to Jerusalem. There, someone will deliver the Son of Man to the leaders of the priests and the teachers of God's Law. These Jewish leaders will decide that I must die."
    },
    {
      "verse": "19",
      "text": "Then they will take me and they will deliver me to people who are not Jews. They will laugh at me. They will hit me with whips. Then they will kill me on a cross. But after three days, I will become alive again. ’"
    },
    {
      "verse": "20",
      "text": "Then the mother of James and John took them to see Jesus. (Their father was Zebedee. ) She went down on her knees in front of Jesus. She asked him to do something good for her."
    },
    {
      "verse": "21",
      "text": "‘What do you want me to do? ’ Jesus asked her. She said, ‘One day, you will be king. Then I want my two sons to rule with you. One may sit at your right side and the other one at your left side. Please will you do this? ’ She said, ‘One day, you will be king. Then I want my two sons to rule with you. One may sit at your right side and the other one at your left side. Please will you do this? ’"
    },
    {
      "verse": "22",
      "text": "Jesus said to them, ‘You do not understand what you are asking for. I will have much pain and trouble. Are you ready to have the same pain? ’James and John replied, ‘Yes, we can do that. ’ James and John replied, ‘Yes, we can do that. ’"
    },
    {
      "verse": "23",
      "text": "Jesus said to them, ‘Yes, that is true. You will have pain and trouble like mine. But I cannot promise that you will sit at my right side or at my left side. My Father God has chosen the people who will sit there. He has prepared the places for those people. ’"
    },
    {
      "verse": "24",
      "text": "When the other ten disciples heard about this, they were angry with the two brothers."
    },
    {
      "verse": "25",
      "text": "disciples to come to him. He said to them, ‘You know the things that rulers of other countries do. They show that they have great power over their people. The leaders of those countries use great authority over their people."
    },
    {
      "verse": "26",
      "text": "But you should not be like that. The person who wants to be great among you must become your servant."
    },
    {
      "verse": "27",
      "text": "The person who wants to be the most important person among you must work hard for everyone else."
    },
    {
      "verse": "28",
      "text": "Even the Son of Man himself came to earth to be a servant to other people. He did not come here to have servants who must work for him. No, he came to die so that many people can be free. ’"
    },
    {
      "verse": "29",
      "text": "Later, Jesus and his disciples were leaving Jericho. A large crowd of people followed him."
    },
    {
      "verse": "30",
      "text": "Two men were sitting at the side of the road. They were blind. But they heard that Jesus was walking past them. So they shouted, ‘Master! Son of David! Please be kind to us and help us. ’"
    },
    {
      "verse": "31",
      "text": "The people who were in the crowd were angry with them. They told them that they should be quiet. But the men shouted even louder, ‘Master! Son of David! Please help us! ’"
    },
    {
      "verse": "32",
      "text": "Jesus stopped there. He asked the two men, ‘What do you want me to do for you? ’"
    },
    {
      "verse": "33",
      "text": "‘Sir, ’ the men replied, ‘we want to see again. ’"
    },
    {
      "verse": "34",
      "text": "Jesus felt sorry for the two men. He touched their eyes and immediately the men could see again. So they followed Jesus along the road."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "disciples were coming near to Jerusalem. They came to the village called Bethphage. They were on the Mount of Olives. Then Jesus sent two of his disciples to go further."
    },
    {
      "verse": "2",
      "text": "He said to them, ‘Go into the village that is in front of you. When you arrive there, you will immediately see a donkey tied there with her young donkey. Undo the ropes and bring both the donkeys here to me."
    },
    {
      "verse": "3",
      "text": "Someone may ask you, “What are you doing? ” Then say, “The Master needs them. He will send them back to you soon. ” ’"
    },
    {
      "verse": "4",
      "text": "A prophet had spoken a message from God about this long ago. Now it became true."
    },
    {
      "verse": "5",
      "text": "‘Say to the people in Jerusalem, “Look, your king is coming to you. He does not come like someone who thinks that he is important. He is riding on a donkey. Yes, he is riding on a young donkey. ” ’ “Look, your king is coming to you. He does not come like someone who thinks that he is important. He is riding on a donkey. Yes, he is riding on a young donkey. ” ’"
    },
    {
      "verse": "6",
      "text": "So the two disciples went to the village. They did everything that Jesus had told them to do."
    },
    {
      "verse": "7",
      "text": "They brought the donkey and the young donkey to Jesus. They put their coats on the backs of the donkeys. Then Jesus got up and sat on one of them."
    },
    {
      "verse": "8",
      "text": "Many people in the crowd put their coats down on the road. Other people cut branches down from trees. They put these branches down on the road."
    },
    {
      "verse": "9",
      "text": "Many crowds of people went in front of Jesus and other people followed him. All of them were shouting, ‘We praise the Son of David! May the Lord God bless the king who comes with his authority! We praise God in heaven above! ’ ‘We praise the Son of David! May the Lord God bless the king who comes with his authority! We praise God in heaven above! ’"
    },
    {
      "verse": "10",
      "text": "When Jesus went into Jerusalem, everybody in the city had trouble in their minds. They were asking each other, ‘Who is this man? ’"
    },
    {
      "verse": "11",
      "text": "The people in the crowd replied, ‘This is God's prophet, Jesus. He comes from Nazareth in Galilee. ’"
    },
    {
      "verse": "12",
      "text": "Jesus then went into the yard of the temple. People were buying and selling things there. Jesus made them all leave that place. He pushed over the tables of the men who changed coins. He also pushed over the seats of the men who sold birds."
    },
    {
      "verse": "13",
      "text": "Jesus spoke to them all. He said, ‘The Bible says, “God's house will be a place where people come together to pray. ” But you have changed it into a place where robbers meet. ’"
    },
    {
      "verse": "14",
      "text": "Blind people went to meet Jesus in the yard of the temple. People who could not walk very well also went there. Jesus caused them all to become well."
    },
    {
      "verse": "15",
      "text": "The leaders of the priests and teachers of God's Law saw all the powerful things that Jesus did. They also saw children in the yard of the temple who were shouting, ‘Welcome! We pray that God will be good to you, Son of David! ’ All these things caused the important Jews to become very angry."
    },
    {
      "verse": "16",
      "text": "They asked Jesus, ‘Can you hear what these children are saying? ’Jesus replied, ‘Yes, I can hear them. I am sure that you have read this in the Bible:“Lord God, babies and children praise you. You yourself have taught them to do that. ” ’ Jesus replied, ‘Yes, I can hear them. I am sure that you have read this in the Bible: “Lord God, babies and children praise you. You yourself have taught them to do that. ” ’"
    },
    {
      "verse": "17",
      "text": "Then Jesus left everyone and he went out of Jerusalem. He stayed that night in Bethany, a village near the city."
    },
    {
      "verse": "18",
      "text": "On the next day, early in the morning, Jesus left Bethany to return to Jerusalem. On the way there, he was hungry."
    },
    {
      "verse": "19",
      "text": "He saw a fig tree near to the road. He went to see if it had fruit on it. But there were only leaves on the tree, and no fruit. Jesus said to the tree, ‘No fruit will ever grow on you again! ’ Then, immediately, the tree became dry and it died."
    },
    {
      "verse": "20",
      "text": "The disciples saw it happen and they were very surprised. And they asked Jesus, ‘How did the tree die so quickly? ’"
    },
    {
      "verse": "21",
      "text": "Jesus said to them, ‘I tell you this: You must believe in God. You must not have other ideas in your mind. If you believe in God, then you could also do the same thing to this fig tree. You could even say to this mountain, “Move away and throw yourself into the sea! ” Then it would really happen."
    },
    {
      "verse": "22",
      "text": "So when you pray to ask God for something, believe in him. Then God will give you whatever you ask for. ’"
    },
    {
      "verse": "23",
      "text": "Then Jesus returned to the yard of the temple. While he was teaching the people there, the leaders of the priests and important Jews went to him. They asked him, ‘What authority do you have to do these things? Tell us. Who gave you the authority to do them? ’"
    },
    {
      "verse": "24",
      "text": "Jesus replied, ‘I also will ask you one question. If you tell me the answer, then I will answer your question. I will tell you what authority I have to do these things."
    },
    {
      "verse": "25",
      "text": "John baptized people. Did God give him the authority to do this? Or did men tell him to do it? ’ Then the Jewish leaders talked to each other about Jesus' question. They said, ‘We could say that God gave John his authority. But if we say that, Jesus will say to us, “Then you should have believed John. ”"
    },
    {
      "verse": "26",
      "text": "But we do not want to say that only men gave John his authority. All the people think that John was a prophet from God. We are afraid that the crowd might attack us. ’"
    },
    {
      "verse": "27",
      "text": "So the Jewish leaders answered Jesus: ‘We do not know who gave John his authority. ’Jesus said to them, ‘You will not answer my question. So I will not tell you what authority I have to do these things. ’ Jesus said to them, ‘You will not answer my question. So I will not tell you what authority I have to do these things. ’"
    },
    {
      "verse": "28",
      "text": "Jesus said to the Jewish leaders, ‘Tell me what you think about this story. A man had two sons. He went to the older son and said, “Son, go and work in my field today. ”"
    },
    {
      "verse": "29",
      "text": "The older son replied, “I do not want to go and work there today. ” But after he had said that, he did go and work in the field."
    },
    {
      "verse": "30",
      "text": "The man went to his other son and he said the same thing to him. The second son replied, “Yes, father, I will go. ” But then he did not go to work in the field."
    },
    {
      "verse": "31",
      "text": "Tell me, which of the man's sons did what his father wanted? ’The Jewish leaders replied, ‘The older son did what his father wanted. ’Jesus said to them, ‘I tell you this: The men who take taxes from people are going into the kingdom of God before you. It is the same with prostitutes. They also are going into the kingdom of God before you. The Jewish leaders replied, ‘The older son did what his father wanted. ’"
    },
    {
      "verse": "32",
      "text": "John the Baptist came to show you the right way to live. You did not believe him. But the men who take taxes did believe him. Prostitutes also believed him. Even after you saw this, you did not believe him. You did not change the way that you live. ’"
    },
    {
      "verse": "33",
      "text": "Then Jesus said again to the Jewish leaders, ‘Listen to another story that I will tell you. There was a man who had his own farm. He planted vines in a garden to grow grapes there. He built a wall around the garden. He dug a hole in the ground for a winepress to make wine. He also built a tall building to watch over the garden. The man then found some farmers to work in the garden for him. Then he went away to another country."
    },
    {
      "verse": "34",
      "text": "When it was nearly time for the harvest, the master sent his servants to speak to the farmers. He wanted them to give him the fruit that was his."
    },
    {
      "verse": "35",
      "text": "But the farmers took hold of the servants. They hit one of them with sticks. They killed another one. They threw stones at another servant and killed him."
    },
    {
      "verse": "36",
      "text": "So the master sent other servants to go to the farmers. He sent more servants than the first time. But the farmers did the same thing to those servants too."
    },
    {
      "verse": "37",
      "text": "After that, the master sent his own son to the farmers. He thought, “The farmers will surely respect my son. ”"
    },
    {
      "verse": "38",
      "text": "The farmers saw the master's son coming. They said to each other, “This is the master's own son. The garden will belong to him when his father dies. So we should kill the son and then the garden will be ours. ”"
    },
    {
      "verse": "39",
      "text": "Then the farmers took hold of the son. They threw him out of the garden and they killed him. ’"
    },
    {
      "verse": "40",
      "text": "Jesus then said, ‘One day, the master will return to his garden. What do you think he will do then to those farmers? ’"
    },
    {
      "verse": "41",
      "text": "The Jewish leaders said to Jesus, ‘The master will completely destroy those bad people. Then he will give the garden to other farmers to take care of it. Those new farmers will give the master the fruit that he should have at the time of harvest. ’"
    },
    {
      "verse": "42",
      "text": "Jesus said to them, ‘I am sure that you have read this in the Bible:“The builders refused to use a certain stone. They thought that it had no value. But now that stone has become the most important stone at the corner of the building. The Lord God did this. And we can see that he did something great. ” “The builders refused to use a certain stone. They thought that it had no value. But now that stone has become the most important stone at the corner of the building. The Lord God did this. And we can see that he did something great. ”"
    },
    {
      "verse": "43",
      "text": "I tell you this: Because you do not believe in me, God will take his kingdom away from you. He will give it to people who show that they obey him."
    },
    {
      "verse": "44",
      "text": "When a person falls onto that stone, it will break his body into pieces. When that stone falls on top of someone, it will destroy him completely. ’"
    },
    {
      "verse": "45",
      "text": "The leaders of the priests and the Pharisees heard what Jesus said in his stories. They knew that he was speaking against them."
    },
    {
      "verse": "46",
      "text": "They wanted to take hold of him and put him in prison. But they did not try to do it because they were afraid of the people. The people thought that Jesus was a prophet from God."
    }
  ],
  "22": [
    {
      "verse": "1",
      "text": "Jesus continued to teach the people with stories."
    },
    {
      "verse": "2",
      "text": "He said, ‘This is what the kingdom of heaven is like. A king prepared a special meal for his son's marriage."
    },
    {
      "verse": "3",
      "text": "He asked many people to come. When the meal was ready, he sent his servants out to tell those people to come. But they refused to come."
    },
    {
      "verse": "4",
      "text": "So the king then sent out other servants. He said to them, “Tell this message to all those people that I have asked to come. Tell them that the master says, ‘My servants have prepared the meal. They have killed my large oxen and some fat young cows to eat. Everything is ready. Now come to the marriage party! ’ ”"
    },
    {
      "verse": "5",
      "text": "But the people did not think that the king's message was important. They went away to do their own work. One man went to his farm and another man went to his business."
    },
    {
      "verse": "6",
      "text": "Other people took hold of the king's servants. They hurt them and then they killed them."
    },
    {
      "verse": "7",
      "text": "The king was very angry. He sent his soldiers to the city where those people lived. They killed the people who killed the king's servants. They destroyed their city with fire."
    },
    {
      "verse": "8",
      "text": "Then the king said to his other servants, “The meal for my son's marriage is ready. But the people that I had asked to come did not deserve to come."
    },
    {
      "verse": "9",
      "text": "So go out now to the town's streets where people meet together. Ask all the people that you find there to come to the marriage party. ”"
    },
    {
      "verse": "10",
      "text": "Then those servants went out into the streets. They brought to the king's house all the people that they met. Some were good people and some were bad people. Very many people came. The room for the marriage was full!"
    },
    {
      "verse": "11",
      "text": "Then the king came into the room to see all the people. He saw one man who was not wearing the right clothes for a marriage."
    },
    {
      "verse": "12",
      "text": "The king said to the man, “How did you come in here, my friend? You are not wearing the right clothes for a marriage. ” The man could not answer the king."
    },
    {
      "verse": "13",
      "text": "The king said to his servants, “Tie his hands and his feet. Take him and throw him into the dark place outside. There, people will cry and they will bite their teeth together. ”"
    },
    {
      "verse": "14",
      "text": "God asks many people to come to him. But he only chooses a few people to be there with him. ’"
    },
    {
      "verse": "15",
      "text": "After the Pharisees heard this, they thought about what they could do. They wanted to ask Jesus difficult questions. They wanted to make him say something wrong about the Roman ruler."
    },
    {
      "verse": "16",
      "text": "So the Pharisees sent their own disciples to Jesus. They also sent people who were friends of King Herod. They said to Jesus, ‘Teacher, we know that you only say true things. You teach us what God wants us to do. It does not matter to you what other people think. If someone is important, you do not change your answers to make them happy."
    },
    {
      "verse": "17",
      "text": "So tell us your answer to this question: Should we pay our taxes to the Roman ruler, Caesar? Is it right to give that money to him, or not? ’"
    },
    {
      "verse": "18",
      "text": "Jesus knew that these men wanted to do bad things to him. So he said to them, ‘You are asking that question to cause trouble for me. You are not being honest!"
    },
    {
      "verse": "19",
      "text": "Now, show me the coin that you use for the tax. ’ So they brought a coin to him."
    },
    {
      "verse": "20",
      "text": "Then Jesus asked them, ‘Whose picture is on this coin? Whose name is on it? ’"
    },
    {
      "verse": "21",
      "text": "They replied, ‘It is Caesar's picture and Caesar's name. ’Jesus said to them, ‘So you should give to Caesar the things that belong to Caesar. And give to God the things that belong to God. ’ Jesus said to them, ‘So you should give to Caesar the things that belong to Caesar. And give to God the things that belong to God. ’"
    },
    {
      "verse": "22",
      "text": "When they heard Jesus' answer, they were very surprised. So they left him and they went away."
    },
    {
      "verse": "23",
      "text": "On that day, some Sadducees also came to Jesus. Sadducees do not believe that anyone becomes alive again after they die. They wanted to ask Jesus a question."
    },
    {
      "verse": "24",
      "text": "‘Teacher, ’ they said to him, ‘Moses said in the Bible: A man may die and leave behind a wife but no children. Then that man's brother must marry the woman. Then their children will be called the children of the brother who died."
    },
    {
      "verse": "25",
      "text": "Once, there were seven brothers who lived here. The oldest brother married a woman. Then he died before they had any children. So the second brother married the woman."
    },
    {
      "verse": "26",
      "text": "But then he also died with no children. So a third brother married this woman. And the same thing happened to all the brothers down to the seventh brother. They all died before the woman had any children."
    },
    {
      "verse": "27",
      "text": "After all this, the woman also died."
    },
    {
      "verse": "28",
      "text": "You teach that one day dead people will become alive again. On that day, whose wife will that woman be? She had married all seven of those brothers. ’"
    },
    {
      "verse": "29",
      "text": "Jesus said to the Sadducees, ‘You are wrong. This is because you do not know the Bible. And you do not know how powerful God is."
    },
    {
      "verse": "30",
      "text": "One day, God will raise people up after they have died. They will become alive again. But then men and women will not marry. They will not have husbands or wives. Instead, they will be like the angels in heaven."
    },
    {
      "verse": "31",
      "text": "It is true that one day dead people will become alive again. You have read in the Bible about what God said to you:"
    },
    {
      "verse": "32",
      "text": "“I am the God of Abraham. I am the God of Isaac. And I am the God of Jacob. ” God is not the God of people who are dead. He is the God of people who are alive. ’"
    },
    {
      "verse": "33",
      "text": "The crowd heard this. They were very surprised about what Jesus was teaching."
    },
    {
      "verse": "34",
      "text": "The Pharisees heard that Jesus had said these things to the Sadducees. Now the Sadducees could not say anything more to him. So the Pharisees met together. They decided what they would say to Jesus."
    },
    {
      "verse": "35",
      "text": "One of the Pharisees had studied God's Law very well. He asked Jesus a question to see how he would answer."
    },
    {
      "verse": "36",
      "text": "He said, ‘Teacher, which of God's Laws is the most important rule for us to obey? ’"
    },
    {
      "verse": "37",
      "text": "Jesus replied to him, ‘You should love the Lord your God completely: Love him with all your mind. Love him with all that you are. Love him in all that you think."
    },
    {
      "verse": "38",
      "text": "This is the greatest rule and the most important of all God's Laws."
    },
    {
      "verse": "39",
      "text": "The second rule is also important, like the first one. You should love other people as much as you love yourself."
    },
    {
      "verse": "40",
      "text": "All God's Laws that Moses gave us come from these two rules. All the things that the prophets wrote also come from them. ’"
    },
    {
      "verse": "41",
      "text": "While the Pharisees met together with Jesus, he asked them, The Pharisees replied, ‘He will be King David's son. ’"
    },
    {
      "verse": "42",
      "text": "‘What do you think about the Messiah? Whose son is he? ’The Pharisees replied, ‘He will be King David's son. ’"
    },
    {
      "verse": "43",
      "text": "Jesus said to them, ‘So think about this: God's Holy Spirit helped King David to call the Messiah his Lord. David said, Sit at my right side until I win against your enemies. Then you will be able to put your feet on them. ”"
    },
    {
      "verse": "44",
      "text": "“The Lord said to my Lord: Sit at my right side until I win against your enemies. Then you will be able to put your feet on them. ”"
    },
    {
      "verse": "45",
      "text": "We know that King David calls the Messiah his Lord. So can you really say that the Messiah is David's son? ’"
    },
    {
      "verse": "46",
      "text": "Nobody could answer the question that Jesus asked. After this, everyone was afraid to ask Jesus any more questions."
    }
  ],
  "23": [
    {
      "verse": "1",
      "text": "After that, Jesus spoke to the crowds and to his disciples."
    },
    {
      "verse": "2",
      "text": "He said, ‘The teachers of God's Law and the Pharisees have authority to explain the Law of Moses."
    },
    {
      "verse": "3",
      "text": "So you must obey everything that they teach you. But you should not do the same things that they do. They tell you what the Law of Moses teaches. But then they themselves do not obey it."
    },
    {
      "verse": "4",
      "text": "The rules that they give you are difficult to obey. Their rules are like heavy luggage, which they make you carry. But they themselves will not help you to carry that luggage. They will not agree to use even one finger to help you."
    },
    {
      "verse": "5",
      "text": "The Pharisees do things only so that people will see them. They wear little boxes with words from the Bible in them, but they make them really big. They also make the tassels on their clothes very long."
    },
    {
      "verse": "6",
      "text": "They like to sit in the important places at special meals. They also choose to sit in the best seats in the meeting places."
    },
    {
      "verse": "7",
      "text": "They like people to praise them in the market place. They want people to call them “Teacher. ”"
    },
    {
      "verse": "8",
      "text": "You all belong to God's family. You have only one Teacher. So nobody should call another person, “Teacher”."
    },
    {
      "verse": "9",
      "text": "Also, do not call any other person in the world, “Father”. You have only one Father, and he is in heaven."
    },
    {
      "verse": "10",
      "text": "And do not call each other “Leader”. You have only one Leader. He is the Messiah that God has chosen."
    },
    {
      "verse": "11",
      "text": "The person among you who is most important will be your servant."
    },
    {
      "verse": "12",
      "text": "Some people lift themselves up to be important. But God will bring them down low. Other people are humble. God will lift up those people to a good place. ’"
    },
    {
      "verse": "13",
      "text": "Jesus spoke to the teachers of God's Law and the Pharisees. ‘It will be very bad for you, ’ he said. ‘You are hypocrites! You have stopped people who wanted to go into the kingdom of heaven. It is like you have shut the door so that they cannot go in. Then you yourselves do not even go in."
    },
    {
      "verse": "14",
      "text": "[It will be very bad for you, teachers of God's Law and Pharisees. You are hypocrites! You take things away from women after their husbands have died. You pray for a long time so that other people will praise you. God will punish you much more than other people. ]"
    },
    {
      "verse": "15",
      "text": "It will be very bad for you, teachers of God's Law and Pharisees. You are hypocrites! You travel far across land and sea. You do this to make one person believe what you believe. Then, when he does believe your ideas, he becomes worse than you are. He shows that he belongs to hell even more than you do."
    },
    {
      "verse": "16",
      "text": "It will be very bad for you, teachers. You cannot see what is true, but you show people which way to go. You say to people, “You may make a promise by the name of the temple. Then it is not a serious promise. You do not have to do it. But you may also make a promise by the gold things in the temple. Then it is a serious promise, and you must do it. ”"
    },
    {
      "verse": "17",
      "text": "This shows that you are fools. You do not understand what is true. Think about which of these is more important. Is it the gold things in the temple? Or is it the temple itself? It is the temple that makes the gold things special."
    },
    {
      "verse": "18",
      "text": "You also say to people, “You may make a promise by the altar in the temple. Then it is not a serious promise. You do not have to do it. But you may also make a promise by the gifts on that altar. Then it is a serious promise and you must do it. ”"
    },
    {
      "verse": "19",
      "text": "You are people who cannot understand what is true. Think about which of these things is more important. Is it the gifts on the altar? Or is it the altar itself? It is the altar that makes the gifts special."
    },
    {
      "verse": "20",
      "text": "Remember this: Somebody may make a promise by the name of the altar. Then he is making a promise by God's name. The altar as well as all the gifts on it are special to God."
    },
    {
      "verse": "21",
      "text": "Also, somebody may make a promise by the name of the temple. Then he is making a promise in the name of God, who lives there."
    },
    {
      "verse": "22",
      "text": "Or somebody may make a promise by heaven. Then he is making a promise by the place where God sits and rules. So he is making a promise by the name of God himself."
    },
    {
      "verse": "23",
      "text": "It will be very bad for you, teachers of God's Law and Pharisees. You are hypocrites! When you grow spices to cook with food, you give a tenth part of these small things to God. You are right to obey this rule. But you do not obey the more important parts of God's Law. You do not help people in a good way. You are not kind to them. You do not always do what God says is right. You should have done these important things as well as the other small things."
    },
    {
      "verse": "24",
      "text": "You are like blind people, but you show other people which way to go. You carefully take a small fly out of your water so that you do not drink it. But then you drink the large animal that is swimming in it!"
    },
    {
      "verse": "25",
      "text": "It will be very bad for you, teachers of God's Law and Pharisees. You are hypocrites! You always clean the outside of your cups and plates very carefully. You only clean the outside part that people can see. But on the inside, everything is still dirty. Inside you, your minds are full of bad thoughts. You want to have more things for yourself. You hurt other people to get what you want."
    },
    {
      "verse": "26",
      "text": "Pharisees, you do not see what is true! You must first clean the inside of the cup. Then the outside that people can see will also be clean."
    },
    {
      "verse": "27",
      "text": "It will be very bad for you, teachers of God's law and Pharisees. You are hypocrites! You are like a grave that has nice white paint on the outside and it looks beautiful. But on the inside it is full of bones and disgusting things."
    },
    {
      "verse": "28",
      "text": "You are the same as that. Other people look at you. They think that you are good and you obey God. But on the inside you are hypocrites. Your minds are full of many bad thoughts."
    },
    {
      "verse": "29",
      "text": "It will be very bad for you, teachers of God's Law and Pharisees. You are hypocrites! You build up the places where people have buried God's prophets. You make the places where they have buried good people to be beautiful."
    },
    {
      "verse": "30",
      "text": "You say, “Our ancestors killed God's prophets long ago. If we had lived at that time, we would not have helped our ancestors to do that. ”"
    },
    {
      "verse": "31",
      "text": "So you are speaking against yourselves. You show that you are the sons of those people who killed God's prophets."
    },
    {
      "verse": "32",
      "text": "Now you must finish the work that your ancestors began to do!"
    },
    {
      "verse": "33",
      "text": "You are like a family of dangerous snakes! You will not be able to run away. God will surely punish you, and he will send you to hell."
    },
    {
      "verse": "34",
      "text": "So listen to this. God says, “I will send prophets to you. I will also send to you people who know many things. And I will send people to teach you what is true. But you will kill some of these people. You will kill some of them on a cross. In the places where you meet to pray, you will hit some of them with whips. They will run from one town to another town, but you will follow them. ”"
    },
    {
      "verse": "35",
      "text": "Because of all this, God will punish you for all the good people that you and your ancestors have killed. Long ago, Abel was the first of those good people. You also killed Zechariah, the son of Berekiah. He died in the yard of the temple near the altar."
    },
    {
      "verse": "36",
      "text": "Yes, I tell you this: God will punish the people who are alive today for all those murders."
    },
    {
      "verse": "37",
      "text": "Jerusalem, Jerusalem! Your people have killed God's prophets. They have thrown stones to kill other people that God has sent to you. Many times, I have wanted to bring all of your people near to me. A female bird covers her babies with her body to make them safe. But you would not let me keep you from danger like that."
    },
    {
      "verse": "38",
      "text": "So listen! Your place will now become like a wilderness where nobody lives."
    },
    {
      "verse": "39",
      "text": "And I tell you this. You will not see me again until the day when you say, “May the Lord God bless the man who comes with his authority! ” ’"
    }
  ],
  "24": [
    {
      "verse": "1",
      "text": "Jesus left the temple. While he was leaving, his disciples came to him. They began to talk to him about the buildings of the temple."
    },
    {
      "verse": "2",
      "text": "So Jesus said to them, ‘Yes, you can see all these beautiful buildings now. But I tell you this: Enemies will completely destroy them. Not even one stone will remain on top of another stone. ’"
    },
    {
      "verse": "3",
      "text": "After that, Jesus was sitting on the Mount of Olives. While he was alone, his disciples came to him. They said to him, ‘Please tell us when all these things will happen. Also tell us what will show us that you will soon return? What will show us that the world will soon end? ’"
    },
    {
      "verse": "4",
      "text": "Jesus said, ‘You must be careful! Some people will tell you things that are not true. Do not believe them."
    },
    {
      "verse": "5",
      "text": "Many people will say that they have come on my behalf. They will say, “I am the Messiah. ” Many people will believe their false words."
    },
    {
      "verse": "6",
      "text": "You will hear about wars. You will hear reports about wars in other places. But you must not be afraid. Those things must happen first, but it is not yet the end of everything."
    },
    {
      "verse": "7",
      "text": "People in one country will attack the people in another country. Kings and their armies will fight against other kings and their armies. In some places, people will be hungry, with no food. The ground will shake in many different places."
    },
    {
      "verse": "8",
      "text": "All those things will be like the first pains that a mother has before her baby is born."
    },
    {
      "verse": "9",
      "text": "Then people will take hold of you and they will give you pain. They will even kill some of you. People in every country will hate you because you are my disciples."
    },
    {
      "verse": "10",
      "text": "At that time, many people who believe in me will stop believing. They will put some of my disciples in the power of their rulers. They will hate each other."
    },
    {
      "verse": "11",
      "text": "Also at that time, many people will say that they are prophets from God. Their message is false, but many people will believe them."
    },
    {
      "verse": "12",
      "text": "More and more people everywhere will be doing very bad things. Because of this, many people will no longer love each other in the way that they did before."
    },
    {
      "verse": "13",
      "text": "But God will save the person who remains strong until the end."
    },
    {
      "verse": "14",
      "text": "People will tell the good news about God's kingdom to people all over the world. People in every country will hear the true message from God. Then God will cause the world to come to an end."
    },
    {
      "verse": "15",
      "text": "Long ago, God's prophet Daniel wrote in the Bible about something that would happen. He said that one day people would put a disgusting thing that causes trouble in the temple. You will see it in the holy place. (When you read this, you must understand what it means. )"
    },
    {
      "verse": "16",
      "text": "At that time, people in Judea must run away to the hills to hide."
    },
    {
      "verse": "17",
      "text": "A person who is on the roof of his house must not go down into his house. He must not stop to get anything from his home to take with him."
    },
    {
      "verse": "18",
      "text": "People who are outside in their fields must not go back to their homes. They must not even go to fetch their coats."
    },
    {
      "verse": "19",
      "text": "That will be a bad time for women who are soon to have a baby! It will also be a bad time for those women who have little babies!"
    },
    {
      "verse": "20",
      "text": "You must pray to God about this time when you have to run away quickly. Pray that this time of trouble will not happen in winter. Pray that it will not happen on your day of rest."
    },
    {
      "verse": "21",
      "text": "Great troubles will happen to people at that time. Nothing as bad has ever happened before, since the beginning of the world. Nothing as bad will ever happen again."
    },
    {
      "verse": "22",
      "text": "God will cause those days of great trouble to be not so many. If he did not do that, there would be nobody still alive. But God will cause those days to come to an end. He will do that to help the people that he has chosen."
    },
    {
      "verse": "23",
      "text": "At that time, someone may say to you, “Look, here is the Messiah. ” Or they may say, “There he is! ” When they say that, do not believe them."
    },
    {
      "verse": "24",
      "text": "Some people will say to you, “I am the Messiah! ” Other people will say, “I am a prophet from God. ” But their words will be false. They will do strange and powerful things for people to see. If possible, they would even deceive the people that God has chosen."
    },
    {
      "verse": "25",
      "text": "So be careful! I have told you about these things before they happen."
    },
    {
      "verse": "26",
      "text": "Some people may say to you, “Look, the Messiah is out there in the wilderness. ” But do not go out to see who is there. Some people may say to you, “Look, the Messiah is hiding in that secret room. ” You must not believe these people."
    },
    {
      "verse": "27",
      "text": "Lightning shines quickly and it lights up the whole of the sky from one side to the other. It will be like that when the Son of Man returns."
    },
    {
      "verse": "28",
      "text": "If the dead body of an animal is lying somewhere, vultures will come together in that place."
    },
    {
      "verse": "29",
      "text": "Then after all these bad things have happened, “The sun will become dark. The moon will not shine any more. Stars will fall out of the sky. And the powerful things in the sky will shake. ” “The sun will become dark. The moon will not shine any more. Stars will fall out of the sky. And the powerful things in the sky will shake. ”"
    },
    {
      "verse": "30",
      "text": "Then people will see a powerful thing in the sky. This will show them that the Son of Man is coming. All the families of people in the world will cry because they are very sad. Then they will see the Son of Man. He will be riding on the clouds in the sky. He will have great power and bright glory."
    },
    {
      "verse": "31",
      "text": "People will hear the sound of a loud trumpet. The Son of Man will send out his angels. They will go in every direction. They will bring together all the people that God has chosen from every part of the earth and from every part of the sky. ’"
    },
    {
      "verse": "32",
      "text": "‘Here is a lesson for you to learn about the fig tree. When the new branches on the tree start to grow, the leaves appear. Then you know that the summer will come soon."
    },
    {
      "verse": "33",
      "text": "In the same way, you will see all these strange things happening. Then you will know that the Son of Man will come very soon. He will be like someone at the door who is ready to come in."
    },
    {
      "verse": "34",
      "text": "I tell you this: The people who are alive now will not all die until all these things happen."
    },
    {
      "verse": "35",
      "text": "One day, the earth and the sky will have an end. But my words will be there for ever. ’"
    },
    {
      "verse": "36",
      "text": "Jesus then said, ‘Nobody knows the day or the hour when all these things will happen. Only God the Father knows when they will happen. The angels who are in heaven do not know. Even the Son does not know."
    },
    {
      "verse": "37",
      "text": "Remember what happened when Noah was alive. It will be like that when the Son of Man returns to the earth."
    },
    {
      "verse": "38",
      "text": "In Noah's time, in the days before the flood, people were eating their meals every day. Men married women and women married men. They continued to do all these things until the day that Noah went into his big boat."
    },
    {
      "verse": "39",
      "text": "The people did not know what would happen. Then rain fell for a long time and all these people died in the deep water. When the Son of Man returns, it will happen quickly in the same way."
    },
    {
      "verse": "40",
      "text": "At that time, it will be like this: Two men will be working in a field. God will take one man away, but he will leave the other man behind."
    },
    {
      "verse": "41",
      "text": "Two women will be preparing food together in the same place. God will take one of them away, but he will leave the other woman behind."
    },
    {
      "verse": "42",
      "text": "So you must watch carefully! You do not know the day when your Master will come back."
    },
    {
      "verse": "43",
      "text": "You can be sure about this. The master of a house does not know at what time of night a man would come to rob him. If he knew the time, he would watch his house more carefully. He would not let the robber come into his house and take away his things."
    },
    {
      "verse": "44",
      "text": "So you must also be ready. The Son of Man will come at a time when you are not thinking about it. ’"
    },
    {
      "verse": "45",
      "text": "Jesus then said, ‘You should be like a wise servant. Be someone that the master can trust. The master will choose a man like that. He will say to him, “Rule over my house and all my other servants. Give everyone their food to eat at the right time. ”"
    },
    {
      "verse": "46",
      "text": "That servant will be very happy when his master comes home. His master will see that he has done everything well."
    },
    {
      "verse": "47",
      "text": "Yes, I tell you this: The master will give that servant authority to rule over everything in his house."
    },
    {
      "verse": "48",
      "text": "But another servant might be bad. He might say to himself, “My master will not come yet. ”"
    },
    {
      "verse": "49",
      "text": "Then he begins to hit the other servants. He eats too much and he drinks too much. He meets with other people who become drunk."
    },
    {
      "verse": "50",
      "text": "Then the master of that servant will come home and he will surprise the servant. He did not think that his master would come home on that day or at that time."
    },
    {
      "verse": "51",
      "text": "Then the master will punish him a lot. He will put the servant with those people who do not obey him. The people in that place will cry and they will bite their teeth together. ’"
    }
  ],
  "25": [
    {
      "verse": "1",
      "text": "Jesus said, ‘I will tell you another story to show what the kingdom of heaven is like. There were ten young women who were going to a marriage party. They took their lamps with them and they went to meet the man who was marrying a wife."
    },
    {
      "verse": "2",
      "text": "Five of these young women were silly. The other five young women were wise."
    },
    {
      "verse": "3",
      "text": "The silly women took their lamps with them, but they did not take any extra oil with them."
    },
    {
      "verse": "4",
      "text": "The five wise women took jars of oil with their lamps."
    },
    {
      "verse": "5",
      "text": "The man who was marrying a wife did not come for a long time. So all the young women became tired, and they went to sleep."
    },
    {
      "verse": "6",
      "text": "In the middle of the night, someone shouted out, “The man is coming! Come out to meet him! ”"
    },
    {
      "verse": "7",
      "text": "The ten young women woke up. Then they prepared their lamps to make them work well."
    },
    {
      "verse": "8",
      "text": "The five silly young women said to the other five young women, “Give us some of your oil, because our lamps are not giving much light. ”"
    },
    {
      "verse": "9",
      "text": "The wise women replied, “If we did that, then there would not be enough oil for all of us. You must go instead to the people who sell oil. You must buy some oil for yourselves. ”"
    },
    {
      "verse": "10",
      "text": "So these five women went to buy some oil. While they were away, the man arrived for the marriage party. The five wise women were ready. They went with him into the house for the party. Then the servants shut the door."
    },
    {
      "verse": "11",
      "text": "Later, the five silly women also came to the house. They said, “Sir, Sir, please open the door for us. ”"
    },
    {
      "verse": "12",
      "text": "But he replied, “I tell you, I do not know you. ” ’"
    },
    {
      "verse": "13",
      "text": "Then Jesus said to the people, ‘So you must watch carefully. You do not know on what day or at what time I will return. ’"
    },
    {
      "verse": "14",
      "text": "Jesus said, ‘The kingdom of heaven is also like a man who began a journey. Before the master went away, he told his servants to come to him. He said to them, “Take care of all my money and all my things for me. ”"
    },
    {
      "verse": "15",
      "text": "The master gave one servant 5, 000 gold coins. He gave another servant 2, 000 gold coins, and to another servant he gave 1, 000 gold coins. The master gave to each servant what he would be able to use well. Then he went away on his journey."
    },
    {
      "verse": "16",
      "text": "The servant who had received 5, 000 gold coins went out immediately. He bought and sold things with the money. When he did this, he got 5, 000 more gold coins."
    },
    {
      "verse": "17",
      "text": "The servant who had received 2, 000 gold coins did the same thing. This servant got 2, 000 more gold coins."
    },
    {
      "verse": "18",
      "text": "But the servant who had received only 1, 000 gold coins did something different. He went outside and he dug a hole in the ground. He buried the money that his master had given him."
    },
    {
      "verse": "19",
      "text": "After a long time, the master came home. He asked the servants to come to him. He wanted to know how much money they had now."
    },
    {
      "verse": "20",
      "text": "The servant who had received 5, 000 gold coins came to his master. The servant said, “Master, you gave me 5, 000 gold coins. Now I have an extra 5, 000 gold coins. ”"
    },
    {
      "verse": "21",
      "text": "The master said to this servant, “You are a good servant and you have done really well. You were careful with a small amount of money. Now I will give you authority over many more things. I am really happy about this and I want you to be happy with me. ”"
    },
    {
      "verse": "22",
      "text": "The servant who had received 2, 000 gold coins also came to his master. The servant said, “Master, you gave me 2, 000 gold coins. Now I have an extra 2, 000 gold coins. ”"
    },
    {
      "verse": "23",
      "text": "The master said to this servant, “You are a good servant and you have done really well. You were careful with a small amount of money. Now I will give you authority over many more things. I am really happy about this and I want you to be happy with me. ”"
    },
    {
      "verse": "24",
      "text": "The servant who had received 1, 000 gold coins then came to his master. The servant said, “Master, I know what you are like. You tell people what they should do all the time. You take food from fields where you did not put any seed in the ground. You get fruit from trees that you did not plant."
    },
    {
      "verse": "25",
      "text": "So I was afraid of you. I went and I buried your gold coins in the ground. Look! Here they are. You can have your money back again. ”"
    },
    {
      "verse": "26",
      "text": "The master said to him, “You are a bad and lazy servant. You know what I am like, do you? I get food from fields where I did not put any seeds. I get fruit from trees that I did not plant. You knew all that."
    },
    {
      "verse": "27",
      "text": "So you should have put the money into a bank. Then, when I came home, I could have received my money back from the bank, with extra money. ”"
    },
    {
      "verse": "28",
      "text": "Then the master said to his other servants, ��Take the 1, 000 gold coins from this bad servant. Give them to the man who now has 10, 000 coins."
    },
    {
      "verse": "29",
      "text": "Some people have received good things. They will all receive even more and have lots of good things. Some other people have nothing. Those people will lose even the little bit that they do have."
    },
    {
      "verse": "30",
      "text": "This servant cannot work for me any longer. Take him outside and throw him into a dark place. There, people will cry and they will bite their teeth together. ” ’"
    },
    {
      "verse": "31",
      "text": "Jesus said, ‘I, the Son of Man, will return one day. Then people will see that I am great and powerful. All God's angels will come with me. I will sit on my great seat as king."
    },
    {
      "verse": "32",
      "text": "People from all the countries in the world will come together in front of me. I will put them into two groups. I will do it in the same way that a shepherd puts his sheep and goats into two groups."
    },
    {
      "verse": "33",
      "text": "He puts the sheep on his right side and the goats on his left side."
    },
    {
      "verse": "34",
      "text": "The king will say to those people who are on his right side, “Come here. My Father has been good to you. He has prepared a place for you in his kingdom. That kingdom has been ready for you since the time that God made the world."
    },
    {
      "verse": "35",
      "text": "I was hungry and you gave me some food to eat. I was thirsty and you gave me some water to drink. I was visiting your town and you asked me to stay in your home."
    },
    {
      "verse": "36",
      "text": "I did not have enough clothes and you gave me some clothes to wear. I was ill and you took care of me. I was in prison and you came to visit me there. ”"
    },
    {
      "verse": "37",
      "text": "Then the people on the right side will say to the king, “Master, when did we see that you were hungry and give you some food? When did we see that you were thirsty and we gave you some water to drink?"
    },
    {
      "verse": "38",
      "text": "When did we ask you to stay in our home because you were alone? When did we give you some clothes to wear?"
    },
    {
      "verse": "39",
      "text": "When did we take care of you because you were ill? When did we come to visit you in prison? ”"
    },
    {
      "verse": "40",
      "text": "The king will answer them, “I tell you this: You did all these things to help other people. They were not important people, but they were my friends. When you helped them, then you also helped me. ”"
    },
    {
      "verse": "41",
      "text": "Then the king will say to those people who are at his left side, “Go away from me. God has decided to punish you. He has prepared a fire that will burn for ever. He has prepared it for Satan and his servants. You will also go into that fire."
    },
    {
      "verse": "42",
      "text": "I was hungry but you did not give me any food to eat. I was thirsty but you did not give me anything to drink."
    },
    {
      "verse": "43",
      "text": "I visited your town but you did not ask me to stay in your home. I did not have enough clothes but you did not give me anything to wear. I was ill but you did not take care of me. I was in prison but you did not come to visit me. ”"
    },
    {
      "verse": "44",
      "text": "Then these other people will say, “Master, when did we see you and you were hungry, or you were thirsty? When did we see you alone or without clothes? When did we see you and you were ill, or in prison? When did you need our help and we did not help you? ”"
    },
    {
      "verse": "45",
      "text": "Then the king will reply, “I tell you this: You did not help people who are my friends. They were not important people. But when you did not help them, you also did not help me. ”"
    },
    {
      "verse": "46",
      "text": "Then those people on the king's left side will go away to the place where God will punish them for ever. But the good people on the king's right side will live for ever with God. ’"
    }
  ],
  "26": [
    {
      "verse": "1",
      "text": "When Jesus finished saying all these things, he said to his disciples,"
    },
    {
      "verse": "2",
      "text": "‘You know that after two days it will be the time of the Passover festival. Then those people who are against me will put me into the power of the rulers. They will fix me, the Son of Man, to a cross to kill me. ’"
    },
    {
      "verse": "3",
      "text": "Then the leaders of the priests and the important Jews met together in the house of the most important priest. His name was Caiaphas."
    },
    {
      "verse": "4",
      "text": "They wanted to kill Jesus. But they wanted to take hold of him secretly. So they tried to decide how they could do that."
    },
    {
      "verse": "5",
      "text": "They said to each other, ‘We do not want to take hold of him during the Passover festival. If we do that, the people will be angry and they may fight against us. ’"
    },
    {
      "verse": "6",
      "text": "Then Jesus went to Bethany and he visited Simon at his house. At one time, Simon had had a bad disease of the skin."
    },
    {
      "verse": "7",
      "text": "While Jesus was eating a meal there, a woman came into the house. She brought a small stone jar with her. The jar contained expensive oil with a very nice smell. She poured the oil over Jesus' head while he sat there."
    },
    {
      "verse": "8",
      "text": "Jesus' disciples saw what the woman had done. They became angry and they said, ‘This woman should not have wasted the oil."
    },
    {
      "verse": "9",
      "text": "She could have sold it for a lot of money. Then she could have given the money to poor people. ’"
    },
    {
      "verse": "10",
      "text": "Jesus knew what his disciples were saying. So he said to them, ‘Do not cause trouble for her. She has done a good thing to me."
    },
    {
      "verse": "11",
      "text": "You will always have poor people with you. But you will not always have me with you."
    },
    {
      "verse": "12",
      "text": "She has poured oil over my body. So now I will be ready for people to bury me."
    },
    {
      "verse": "13",
      "text": "I tell you this: Everywhere in the world people will speak about this good news. At the same time, they will also tell people about the good thing that this woman has done. And so people will remember her. ’"
    },
    {
      "verse": "14",
      "text": "Judas Iscariot was one of Jesus' 12 apostles. He went to see the leaders of the priests"
    },
    {
      "verse": "15",
      "text": "and he asked them, ‘How much money will you give me if I help you to take hold of Jesus? ’ The priests gave Judas 30 silver coins."
    },
    {
      "verse": "16",
      "text": "Judas then waited for the right moment to help them to take hold of Jesus."
    },
    {
      "verse": "17",
      "text": "The first day of the festival when the Jews eat flat bread arrived. Jesus' disciples came to him and they asked him, ‘Where do you want us to prepare the Passover meal for you to eat? ’"
    },
    {
      "verse": "18",
      "text": "Jesus replied, ‘Go to a certain man in the city and say to him, “The teacher says: This is the moment that God has prepared for me. I will eat the Passover meal with my disciples in your house. ” ’"
    },
    {
      "verse": "19",
      "text": "So Jesus' disciples did what he had told them to do. They went and they prepared the Passover meal."
    },
    {
      "verse": "20",
      "text": "When it was evening, Jesus and the 12 apostles sat down to eat the Passover meal together."
    },
    {
      "verse": "21",
      "text": "While they were eating, Jesus said, ‘I tell you this: One of you will help the Jewish leaders to take hold of me. ’"
    },
    {
      "verse": "22",
      "text": "They were very sad about what Jesus had said. Each one of them said to Jesus, ‘Lord, surely you do not mean me, do you? ’"
    },
    {
      "verse": "23",
      "text": "Jesus said to them ‘The man who will give me to the rulers is eating from the same dish as I am."
    },
    {
      "verse": "24",
      "text": "The Son of Man must die in the way that the Bible says. But it will be very bad for the man who gives me to my enemies. It would be better for that man if he had not been born. ’"
    },
    {
      "verse": "25",
      "text": "Judas was the one who would give Jesus to the Jewish leaders. But he said to Jesus, ‘Teacher, surely you do not mean me, do you? ’ Jesus replied to him, ‘Yes, you have said it. ’"
    },
    {
      "verse": "26",
      "text": "While Jesus and his disciples were eating, he took a loaf of bread. He thanked God for it and then he broke the bread into pieces. He gave some of it to each of them. He said, ‘Take this bread and eat it. This is my body. ’"
    },
    {
      "verse": "27",
      "text": "Then Jesus took a cup. He thanked God for the wine in the cup. Then he gave it to them and he said, ‘All of you should drink some of this wine."
    },
    {
      "verse": "28",
      "text": "This is my blood that shows God's promise. When I die, my blood will pour out of my body. In that way God will forgive many people for the wrong things that they have done. That is the promise that God makes because of my death."
    },
    {
      "verse": "29",
      "text": "I tell you this. I will not drink wine again until I drink it with you in my Father's kingdom. Then it will be new wine. ’"
    },
    {
      "verse": "30",
      "text": "Then Jesus and his disciples sang a song to praise God. Then they went out to the Mount of Olives."
    },
    {
      "verse": "31",
      "text": "Then Jesus said to his disciples, ‘Tonight, all of you will turn away from me. It will happen in the way that the Bible says: God says, “I will kill the shepherd who leads the sheep. Then all the sheep will run away in different directions. ” ’ God says, “I will kill the shepherd who leads the sheep. Then all the sheep will run away in different directions. ” ’"
    },
    {
      "verse": "32",
      "text": "Jesus then said, ‘But after that happens, I will become alive again. Then I will go to Galilee, and you will meet me there. ’"
    },
    {
      "verse": "33",
      "text": "Peter said to Jesus, ‘Even if everyone else runs away, I will not leave you. ’"
    },
    {
      "verse": "34",
      "text": "Jesus replied to Peter, ‘I tell you this: Even tonight, you will say three times that you do not know me. This will happen before the cockerel sings early tomorrow morning. ’"
    },
    {
      "verse": "35",
      "text": "But Peter said to Jesus, ‘I will die with you if I need to. But I will never say that I do not know you. ’ All the other disciples said the same thing."
    },
    {
      "verse": "36",
      "text": "Then Jesus and his disciples arrived at a large garden called Gethsemane. Jesus said to the disciples, ‘Sit here while I go over there to pray. ’"
    },
    {
      "verse": "37",
      "text": "Then Jesus took Peter and Zebedee's two sons, James and John, with him. He became very sad and upset."
    },
    {
      "verse": "38",
      "text": "He said to them, ‘I am very sad. I feel as if I could die because I feel so sad. Wait here with me and stay awake. ’"
    },
    {
      "verse": "39",
      "text": "Jesus went a short way beyond them. He went down with his face on the ground. He prayed, ‘Father, if it is possible, please save me from this time of great pain. But Father, I do not ask you to do what I want. Do what you want to do. ’"
    },
    {
      "verse": "40",
      "text": "Jesus returned to the three disciples. Now they were sleeping. He said to Peter, ‘You men could not stay awake with me for even one hour!"
    },
    {
      "verse": "41",
      "text": "You must stay awake and pray. God can help you, so that you will not do something wrong. You really want to do the right thing, but your bodies are weak. ’"
    },
    {
      "verse": "42",
      "text": "Jesus went away a second time and he prayed, ‘My Father, if it is not possible to save me from this time of great pain, then I want to obey you. Do what you want for me. ’"
    },
    {
      "verse": "43",
      "text": "Then Jesus returned again to Peter, James and John. He saw that they were sleeping. They could not keep their eyes open."
    },
    {
      "verse": "44",
      "text": "So Jesus went away from them again and he prayed a third time. He said the same words to God."
    },
    {
      "verse": "45",
      "text": "When he returned to the disciples, he said, ‘You should not still be sleeping and resting. Look! The moment has arrived! Someone will now give me, the Son of Man, to my enemies."
    },
    {
      "verse": "46",
      "text": "Stand up, we will go now. Look! The man who will give me to my enemies is here. ’"
    },
    {
      "verse": "47",
      "text": "While Jesus was still speaking, Judas arrived. He was one of Jesus' 12 disciples. A crowd also came with him. They were carrying swords and heavy sticks. The leaders of the priests and the important Jews had sent these people with Judas."
    },
    {
      "verse": "48",
      "text": "Judas was ready to help the Jewish leaders to take hold of Jesus. Before this, he had told them, ‘I will kiss one of the men. You must take hold of that man. ’"
    },
    {
      "verse": "49",
      "text": "Now Judas went immediately to Jesus. He said, ‘Hello, Teacher. ’ Then he kissed Jesus in a friendly way."
    },
    {
      "verse": "50",
      "text": "Jesus said to Judas, ‘My friend, now do what you have come here to do. ’Then the crowd of men came up to Jesus. They took hold of him to lead him away."
    },
    {
      "verse": "51",
      "text": "Then one of Jesus' disciples took hold of his sword. He hit the servant of the leader of the priests with it and he cut off the servant's ear."
    },
    {
      "verse": "52",
      "text": "Then Jesus said to the disciple, ‘Put your sword back in its place. People who use a sword to kill others will themselves die in the same way. Someone will kill them with a sword."
    },
    {
      "verse": "53",
      "text": "You should know that I could ask my Father God to help me. He would immediately send more than 12 large groups of angels to fight for me."
    },
    {
      "verse": "54",
      "text": "They would save me. But then the things that God has said in the Bible about this would not happen. So it must happen in this way. ’"
    },
    {
      "verse": "55",
      "text": "At that time, Jesus said to the crowd, ‘You have come out here with swords and heavy sticks to take hold of me. Do you really believe that I am leading people to fight against our country's rulers? No! I was teaching people every day in the yard of the temple. But you did not try to take hold of me then. Then all of Jesus' disciples ran away and left him."
    },
    {
      "verse": "56",
      "text": "The prophets wrote long ago that all this would happen to me. Now it has become true. ’Then all of Jesus' disciples ran away and left him."
    },
    {
      "verse": "57",
      "text": "Then those men who had taken hold of Jesus took him to Caiaphas's house. Caiaphas was the most important priest. The teachers of God's Law and the important Jews were meeting there together with Caiaphas."
    },
    {
      "verse": "58",
      "text": "Peter followed Jesus into the yard of Caiaphas' house. But he did not go near Jesus. He sat down in the yard with the police who worked in the temple. He wanted to see what would happen."
    },
    {
      "verse": "59",
      "text": "The leaders of the priests and all the Jewish leaders wanted to punish Jesus with death. So they tried to find some people who would say things against Jesus that were not true."
    },
    {
      "verse": "60",
      "text": "Many people did come. And they said things against Jesus that were not true. But still the Jewish leaders could not find a reason to kill Jesus. Then two men stood up and they said,"
    },
    {
      "verse": "61",
      "text": "‘We heard this man say, “I can destroy the temple and in three days I can build it again. ” ’"
    },
    {
      "verse": "62",
      "text": "Then Caiaphas stood up. He said to Jesus, ‘You must reply now to what these men have said against you. Are the things that they say true? ’ So Caiaphas said to him, ‘I use the authority of the God who lives. You must promise to tell us what is true. Are you the Messiah? Are you the Son of God? ’"
    },
    {
      "verse": "63",
      "text": "But Jesus did not say anything. So Caiaphas said to him, ‘I use the authority of the God who lives. You must promise to tell us what is true. Are you the Messiah? Are you the Son of God? ’"
    },
    {
      "verse": "64",
      "text": "‘You have said it, ’ Jesus replied. ‘And I tell all of you, soon you will see the Son of Man. He will be sitting in the most important place at the right side of the Most Powerful God. You will also see him coming to earth. He will be riding on the clouds in the sky. ’"
    },
    {
      "verse": "65",
      "text": "Then Caiaphas tore his clothes to show that he was angry. He said, ‘Jesus has spoken bad words against God. We do not need anyone else to speak against him. You have heard him speak bad words against God. They replied, ‘He is guilty and he deserves to die. ’"
    },
    {
      "verse": "66",
      "text": "Do you think that he is guilty? ’They replied, ‘He is guilty and he deserves to die. ’"
    },
    {
      "verse": "67",
      "text": "Then some of them spat into Jesus' face. They also hit him with their fists."
    },
    {
      "verse": "68",
      "text": "When they hit him, they said, ‘Messiah! Show us that you are a prophet. Tell us who hit you! ’"
    },
    {
      "verse": "69",
      "text": "While all these things were happening, Peter was sitting outside in the yard. One of the girls who worked there went to him and she said, ‘You were also a friend of Jesus, the man from Galilee. ’"
    },
    {
      "verse": "70",
      "text": "Peter said in front of everyone who was there, ‘That is not true. I do not know what you are talking about. ’"
    },
    {
      "verse": "71",
      "text": "Peter then went out to the gate, and another servant girl saw him. This girl said to the people who were standing there, ‘This man was a friend of Jesus, the man from Nazareth. ’"
    },
    {
      "verse": "72",
      "text": "Peter answered again very strongly. He said, ‘I promise you, I really do not know that man! ’"
    },
    {
      "verse": "73",
      "text": "After a little time, other people who were standing at the gate spoke to Peter. They said, ‘We are sure that you too are one of that man's friends. We know this because you speak like people who live in Galilee. ’"
    },
    {
      "verse": "74",
      "text": "Peter said to them very strongly, ‘I tell you that I do not know that man. God will surely punish me if this is not true! ’Immediately after Peter said this, the cockerel sang."
    },
    {
      "verse": "75",
      "text": "Then Peter remembered that Jesus had said to him, ‘Tonight you will say three times that you do not know me. You will do it before the cockerel sings. ’ So Peter went out of the yard. He began to weep a lot because he was very upset."
    }
  ],
  "27": [
    {
      "verse": "1",
      "text": "Early the next morning, all the leaders of the priests and the important Jews met together. They decided how to make the Roman rulers kill Jesus."
    },
    {
      "verse": "2",
      "text": "They tied Jesus' hands and feet and then they took him to Pilate's house. They put him under the authority of Pilate, who was the Roman ruler."
    },
    {
      "verse": "3",
      "text": "Judas heard that the Jewish leaders wanted the Roman rulers to kill Jesus. Judas was the man who had helped Jesus' enemies to take hold of him. Now he was very sorry about what he had done. So he took back the 30 silver coins to the leaders of the priests and the important Jews. They said to Judas, ‘That is not important to us. That is your problem. ’"
    },
    {
      "verse": "4",
      "text": "He said to them, ‘I have done the wrong thing. I helped you to take hold of a man who has done nothing wrong. ’They said to Judas, ‘That is not important to us. That is your problem. ’"
    },
    {
      "verse": "5",
      "text": "So Judas took the money and he threw it down on the floor in the temple. Then he went away. He hung himself from a rope so that he died."
    },
    {
      "verse": "6",
      "text": "The leaders of the priests picked up the coins. They said, ‘We used this money to catch and kill a man. So it is against our Law to use this same money for the temple. ’"
    },
    {
      "verse": "7",
      "text": "They decided to use the money to buy a field. They wanted to use the field to bury foreign people who died in the city. The field had been called ‘The Pot-maker's Field’."
    },
    {
      "verse": "8",
      "text": "After this, it was called ‘The Field of Blood’. It is still called that even today."
    },
    {
      "verse": "9",
      "text": "So the words that the prophet Jeremiah wrote long ago now became true. He had said, ‘Then they took the 30 silver coins. It was the amount of money the people of Israel had agreed to pay for the man."
    },
    {
      "verse": "10",
      "text": "They used this money to buy the pot-maker's field. The Lord God had told me to do this. ’"
    },
    {
      "verse": "11",
      "text": "Now Jesus stood in front of the Roman ruler, Pilate. The ruler asked Jesus, ‘Are you the king of the Jews? ’Jesus replied, ‘You have said it. ’ Jesus replied, ‘You have said it. ’"
    },
    {
      "verse": "12",
      "text": "The leaders of the priests and the important Jews spoke against Jesus. They said that he had done many bad things. Jesus did not answer them."
    },
    {
      "verse": "13",
      "text": "So Pilate said to Jesus, ‘You hear what these men are saying against you. You should reply. ’"
    },
    {
      "verse": "14",
      "text": "But Jesus did not reply to what the men were saying against him, not even to one thing. Pilate was very surprised about this."
    },
    {
      "verse": "15",
      "text": "Each year, at the time for the Passover festival, the Roman ruler would let one person go free out of the prison. The people could choose which person should go free."
    },
    {
      "verse": "16",
      "text": "At that time, there was a man called Barabbas in prison. Everyone knew about the bad things that he had done."
    },
    {
      "verse": "17",
      "text": "When the crowd came together at Pilate's house, Pilate asked them, ‘Who do you want me to let go free? Should Barabbas go free? Or should it be Jesus, who is called the Messiah? ’"
    },
    {
      "verse": "18",
      "text": "Pilate knew why the Jewish leaders had brought Jesus to him. They were jealous because people liked Jesus so much."
    },
    {
      "verse": "19",
      "text": "Pilate was sitting on his special seat as a judge. Then his wife sent a message to him. She said, ‘Do not do anything to that man. He has done nothing wrong. Last night I had a dream about him. It gave me a lot of trouble in my mind. ’"
    },
    {
      "verse": "20",
      "text": "But the leaders of the priests and the important Jews talked to the crowds of people. They said, ‘You must ask Pilate to let Barabbas go free. Then he must tell the soldiers to kill Jesus. ’"
    },
    {
      "verse": "21",
      "text": "Pilate asked the people again, ‘Which of these two men should go free? ’ The people answered, ‘Barabbas. ’"
    },
    {
      "verse": "22",
      "text": "Then Pilate asked the people, ‘So what should I do with Jesus, who is called the Messiah? ’ The people all shouted, ‘Take him and kill him on a cross! ’"
    },
    {
      "verse": "23",
      "text": "So Pilate said, ‘Why should I kill him? What bad things has he done? ’But the people shouted even louder, ‘Kill him on a cross! ’ But the people shouted even louder, ‘Kill him on a cross! ’"
    },
    {
      "verse": "24",
      "text": "Then Pilate knew that he could not do anything to make them quiet. He thought that the people would start to fight his soldiers. So he took a dish of water and he washed his hands in front of the people. He said, ‘It is not because of me that this man will die. You are the people who have caused it to happen. ’"
    },
    {
      "verse": "25",
      "text": "All the people answered Pilate, ‘Yes, God should punish us and our children, if we have done the wrong thing. ’"
    },
    {
      "verse": "26",
      "text": "Then Pilate let Barabbas go free, as the crowd wanted. But he said to his soldiers, ‘Hit Jesus many times with a whip. Then take him and fix him to a cross to die. ’"
    },
    {
      "verse": "27",
      "text": "Then Pilate's soldiers took Jesus into the yard of the ruler's house. All the other soldiers in their group were there."
    },
    {
      "verse": "28",
      "text": "They removed Jesus' clothes from him. They put a dark red coat on him."
    },
    {
      "verse": "29",
      "text": "They used some branches with thorns to make a crown for him. Then they put it on his head. They put a long stick in his right hand. They went down on their knees in front of him. They laughed at him and they said, ‘Hello, King of the Jews, you are great! ’"
    },
    {
      "verse": "30",
      "text": "Then the soldiers spat into Jesus' face. They took the stick and they hit Jesus on his head with it many times."
    },
    {
      "verse": "31",
      "text": "After they had laughed at him, they took the special coat off him. They put his own clothes back on him. Then they took him out to the place where they would kill him on a cross."
    },
    {
      "verse": "32",
      "text": "When they were going to that place, they met a man called Simon. He came from the city of Cyrene. The Roman soldiers told Simon that he must carry Jesus' cross."
    },
    {
      "verse": "33",
      "text": "The soldiers took Jesus to the place that is called Golgotha. (Golgotha means the place of a skull. )"
    },
    {
      "verse": "34",
      "text": "They tried to give Jesus some wine to drink. They had mixed some medicine into the wine. Jesus tasted it, but he would not drink it."
    },
    {
      "verse": "35",
      "text": "Then the soldiers fixed Jesus onto the cross. They took his clothes for themselves. They played a game to find out who would receive each piece of his clothes."
    },
    {
      "verse": "36",
      "text": "Then the soldiers sat down and they watched Jesus carefully."
    },
    {
      "verse": "37",
      "text": "Above his head they fixed a notice. This showed the reason why they were killing him. It said, ‘This man is Jesus, the king of the Jews. ’"
    },
    {
      "verse": "38",
      "text": "Then the soldiers also fixed two robbers to crosses near to Jesus. One robber was at Jesus' right side, and one was at his left side."
    },
    {
      "verse": "39",
      "text": "The people who walked near there insulted Jesus. They laughed at him,"
    },
    {
      "verse": "40",
      "text": "and they said, ‘You said that you could destroy the temple and then build it again in three days. If you really are the Son of God, save yourself. Come down from the cross. ’"
    },
    {
      "verse": "41",
      "text": "The leaders of the priests and the teachers of God's Law and the important Jews also laughed at him."
    },
    {
      "verse": "42",
      "text": "They said, ‘This man saved other people, did he? But he cannot save his own life! He says that he is the king of Israel. So he should come down from the cross now. Then we will believe in him."
    },
    {
      "verse": "43",
      "text": "He says that he trusts in God. So if God wants him, God should save him now. He did say that he is the Son of God. ’"
    },
    {
      "verse": "44",
      "text": "Then the two robbers who were on the crosses next to Jesus also insulted him."
    },
    {
      "verse": "45",
      "text": "It was now midday. The whole country became dark for three hours."
    },
    {
      "verse": "46",
      "text": "At about three o'clock in the afternoon, Jesus shouted loudly, ‘Eli, Eli, lema sabachthani? ’ That means, ‘My God, my God, why have you left me alone? ’"
    },
    {
      "verse": "47",
      "text": "Some people who were standing there heard him. They said to each other, ‘He is shouting to Elijah. ’"
    },
    {
      "verse": "48",
      "text": "One of these people ran quickly and he brought a piece of cloth. He poured cheap wine on it, and he put it on the end of a stick. He lifted it up to Jesus so that he could drink the wine from it."
    },
    {
      "verse": "49",
      "text": "The other people said, ‘Wait! Now we will see if Elijah comes to save him. ’"
    },
    {
      "verse": "50",
      "text": "Then Jesus shouted again with a loud voice, and after that he died."
    },
    {
      "verse": "51",
      "text": "At that moment, the curtain inside the temple tore completely into two parts. It tore from the top down to the bottom. The ground shook and rocks broke into pieces."
    },
    {
      "verse": "52",
      "text": "Places in the ground where people had buried dead bodies opened up. Many of God's people who had died now became alive again."
    },
    {
      "verse": "53",
      "text": "After Jesus became alive again, those people came up out of those places. They went into God's city, Jerusalem. Many people saw them there."
    },
    {
      "verse": "54",
      "text": "The captain and his soldiers had been watching Jesus. They saw the ground shaking. They saw everything that had happened. They were very frightened and they said, ‘It must be true! This man really was the Son of God. ’"
    },
    {
      "verse": "55",
      "text": "There were also many women there. They were standing a long way away and they were watching these events. They had come with Jesus from Galilee to help him."
    },
    {
      "verse": "56",
      "text": "Mary from Magdala was there. Mary the mother of James and Joses, and Mary the mother of Zebedee's sons, were also there."
    },
    {
      "verse": "57",
      "text": "That evening a rich man who came from a town called Arimathea went to Pilate. The man's name was Joseph, and he had become a disciple of Jesus."
    },
    {
      "verse": "58",
      "text": "Joseph asked Pilate for the dead body of Jesus. Pilate told his soldiers to give Jesus' body to Joseph."
    },
    {
      "verse": "59",
      "text": "So Joseph took Jesus' body. He put a clean piece of linen cloth around it."
    },
    {
      "verse": "60",
      "text": "Then he put the body in a large hole in a rock. He had made the hole for his own body when he died. After he put Jesus' body there, he rolled a very big stone across the front of the hole to shut it. Then he went away."
    },
    {
      "verse": "61",
      "text": "Mary from Magdala and Mary the mother of James were there. They were sitting where they could see the hole in the rock where Joseph had put Jesus' body."
    },
    {
      "verse": "62",
      "text": "The next day was the Jewish day of rest. The leaders of the priests and the Pharisees met together with Pilate."
    },
    {
      "verse": "63",
      "text": "They said to him, ‘Sir, that man told lies. When he was still living, he said, “Three days after I die, I will become alive again. ” We know that is what he said."
    },
    {
      "verse": "64",
      "text": "So you should tell some soldiers to watch the place where Joseph put Jesus' body. They should watch there for the next three days. Then his disciples cannot come to take his body away. If they did that, then they could say to the people, “God has caused Jesus to become alive again. ” This will be worse than the lies that Jesus told when he was alive. ’"
    },
    {
      "verse": "65",
      "text": "Pilate said to them, ‘OK. You may take a group of soldiers to watch the place. Let them fix the rock well, so that nobody can open it. ’"
    },
    {
      "verse": "66",
      "text": "So the Jewish leaders and the soldiers went to the place where Joseph had put Jesus' body. They fixed the big stone that closed the front of the hole with a seal. Then they would know if someone had moved it. The soldiers stayed there to watch the place very carefully."
    }
  ],
  "28": [
    {
      "verse": "1",
      "text": "After the day of rest had finished, Mary from Magdala and Mary the mother of James got up early. It was dawn on the first day of the week. They went to the hole in the rock where Joseph had put the dead body of Jesus."
    },
    {
      "verse": "2",
      "text": "At that moment, the ground moved about very strongly. One of the Lord God's angels came from heaven. He went to the rock. He rolled the big stone away from the hole and then he sat on top of it."
    },
    {
      "verse": "3",
      "text": "He shone brightly like lightning. His clothes were very white like snow."
    },
    {
      "verse": "4",
      "text": "The soldiers who were carefully watching that place were very frightened. They suddenly fell down on the ground. Like dead men, they could not move."
    },
    {
      "verse": "5",
      "text": "Then the angel said to the women, ‘Do not be afraid. I know that you are looking for Jesus. The soldiers killed him on a cross."
    },
    {
      "verse": "6",
      "text": "But he is not here. He has become alive again. That is what he said would happen. Come here. You can see the place where he was lying."
    },
    {
      "verse": "7",
      "text": "Then you must go quickly to his disciples. Tell them, “Jesus is alive again, and he is going to Galilee. You must also go there and you will see him. ” That is the message that I have brought for you. ’"
    },
    {
      "verse": "8",
      "text": "So the women went away quickly from the hole in the rock. They were very frightened, but they were also very happy. They ran to tell the disciples the angel's message."
    },
    {
      "verse": "9",
      "text": "At that moment, Jesus met the two women and he said, ‘Hello. ’ They went near to him. They held on to his feet and they worshipped him."
    },
    {
      "verse": "10",
      "text": "Then Jesus said to them, ‘Do not be afraid. Go and tell my disciples to go to Galilee. They will see me there. ’"
    },
    {
      "verse": "11",
      "text": "The women went to tell the disciples Jesus' message. At the same time, some of the soldiers who had watched the rock also went into the city. The soldiers told the leaders of the priests everything that had happened at the rock."
    },
    {
      "verse": "12",
      "text": "The leaders of the priests and the important Jews met together. They decided what they should do now. They gave the soldiers a lot of money as a bribe."
    },
    {
      "verse": "13",
      "text": "They said to the soldiers, ‘When people ask you, you must say this: “Jesus' disciples came to the rock in the night and they took his body away. We were asleep when they did this. ”"
    },
    {
      "verse": "14",
      "text": "If the Roman ruler Pilate hears about this, we will explain things to him. Do not be afraid. He will not punish you. ’"
    },
    {
      "verse": "15",
      "text": "The soldiers took the money. They told people what the Jewish leaders told them to say. Many Jews heard the soldiers' story. Even today they still believe that it happened like that."
    },
    {
      "verse": "16",
      "text": "After this, the 11 disciples went to Galilee. They went to the mountain where Jesus had told them to go."
    },
    {
      "verse": "17",
      "text": "When they arrived at the place, they saw Jesus. Then they went down on their knees and they worshipped him. But some of the disciples were not sure that it really was Jesus."
    },
    {
      "verse": "18",
      "text": "Jesus went near to them and he said to them, ‘God has given me authority over everyone and everything. I have all authority in heaven and in this world."
    },
    {
      "verse": "19",
      "text": "So you must go to people in every country of the world. Teach them how to become my disciples. Baptize them by the authority of God the Father, his Son and the Holy Spirit."
    },
    {
      "verse": "20",
      "text": "Teach them to obey everything that I have taught you. You can be sure that I will be with you always. I will be with you until the end of time. ’"
    }
  ]
};