module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "In the beginning, the Word was already there. The Word was with God. The Word was God."
    },
    {
      "verse": "2",
      "text": "He was with God from the beginning."
    },
    {
      "verse": "3",
      "text": "God made all things through the Word. God did not make anything without him."
    },
    {
      "verse": "4",
      "text": "It is the Word who caused everything to live. Because of this, he has brought light to all people."
    },
    {
      "verse": "5",
      "text": "The light shines in the dark, and the dark cannot put out the light."
    },
    {
      "verse": "6",
      "text": "God sent a man to bring his message. His name was John."
    },
    {
      "verse": "7",
      "text": "He came to tell people about the light. God wanted everyone to believe in the one who is the light."
    },
    {
      "verse": "8",
      "text": "John himself was not that light. God sent him to tell people about the light."
    },
    {
      "verse": "9",
      "text": "The true light gives light to every person. That light was now coming into the world."
    },
    {
      "verse": "10",
      "text": "The Word was now in the world. God had made the world through him. But the people in the world did not know who he was."
    },
    {
      "verse": "11",
      "text": "He came to his own place, but his own people did not accept him."
    },
    {
      "verse": "12",
      "text": "Some people did accept him and they believed in him. He gave authority to those people to become God's children."
    },
    {
      "verse": "13",
      "text": "They did not become God's children in the usual human way. They were not born because some people wanted to have children. They were not born because of what any man decided. No! They were born from God."
    },
    {
      "verse": "14",
      "text": "The Word became a man. He lived among us. We saw his great glory. He has the glory of the Father's one true Son. He is full of God's grace and truth."
    },
    {
      "verse": "15",
      "text": "John told people about the Word. He shouted, ‘This is the man that I told you about. He comes after me. But he is greater than I am. He was already there before I was born. ’"
    },
    {
      "verse": "16",
      "text": "The Word is full of everything that we need. We have all received one good thing after another good thing."
    },
    {
      "verse": "17",
      "text": "God gave his Law to us through Moses. But Jesus Christ brought God's grace and his truth to us."
    },
    {
      "verse": "18",
      "text": "Nobody has ever seen God. But God's only Son has shown God to us. He is very near to the Father, and he himself is God."
    },
    {
      "verse": "19",
      "text": "The Jewish leaders sent priests and Levites from Jerusalem to ask John, ‘Who are you? ’"
    },
    {
      "verse": "20",
      "text": "John did not refuse to answer. He said, ‘I am not the Messiah. ’"
    },
    {
      "verse": "21",
      "text": "So they asked him, ‘So who are you? Are you Elijah? ’ John said, ‘No, I am not. ’ They asked, ‘Are you the Prophet? ’ John answered, ‘No. ’"
    },
    {
      "verse": "22",
      "text": "Then they said, ‘Tell us who you are. We must say something to the people who sent us. What do you say about yourself? ’ “The Lord will come soon. Make a straight path for him to follow. ” That is what the prophet Isaiah said a long time ago. ’"
    },
    {
      "verse": "23",
      "text": "He said, ‘I am the voice of somebody shouting in the wilderness:“The Lord will come soon. Make a straight path for him to follow. ”That is what the prophet Isaiah said a long time ago. ’"
    },
    {
      "verse": "24",
      "text": "The men who came to ask these questions were Pharisees."
    },
    {
      "verse": "25",
      "text": "They said to John, ‘You say that you are not the Messiah, nor Elijah, nor the Prophet. So why do you baptize people? ’"
    },
    {
      "verse": "26",
      "text": "John replied, ‘I baptize people with water. But there is someone here among you that you do not know."
    },
    {
      "verse": "27",
      "text": "He is the one who comes after me. I am not good enough even to undo his shoes for him. ’"
    },
    {
      "verse": "28",
      "text": "All these things happened at a place east from the Jordan River. It was a village called Bethany. John was baptizing people there."
    },
    {
      "verse": "29",
      "text": "The next day, John saw Jesus, who was coming towards him. John said, ‘Look! Here is the Lamb of God, who takes away the sin of people in the world."
    },
    {
      "verse": "30",
      "text": "This is the man that I told you about. I told you, “He comes after me, but he is greater than I am. He was already there before I was born. ”"
    },
    {
      "verse": "31",
      "text": "I did not know him. But I had to show Israel's people who he was. That is why I am baptizing people with water. ’"
    },
    {
      "verse": "32",
      "text": "Then John told them, ‘I saw God's Spirit come down from heaven. He came down like a dove and he stayed on Jesus."
    },
    {
      "verse": "33",
      "text": "I would not have known who Jesus was. But God had sent me to baptize people with water. And God told me, “You will see the Spirit come down. He will stay on someone. That is the person who will baptize people with my Holy Spirit. ”"
    },
    {
      "verse": "34",
      "text": "Now I have seen this. So I can tell you that this is God's Son. ’"
    },
    {
      "verse": "35",
      "text": "John was standing there again the next day, with two of his disciples."
    },
    {
      "verse": "36",
      "text": "He saw Jesus, who was walking past them. John said, ‘Look! Here is the Lamb of God. ’"
    },
    {
      "verse": "37",
      "text": "When the two disciples heard this, they followed Jesus."
    },
    {
      "verse": "38",
      "text": "Then Jesus turned round. He saw that they were following him. He asked them, ‘What do you want? ’ They said, ‘Rabbi (which means “Teacher”), where are you staying? ’"
    },
    {
      "verse": "39",
      "text": "Jesus replied, ‘Come with me and you will see. ’ So they went with him. They saw where he was staying. It was about four o'clock in the afternoon. And they stayed with him that day."
    },
    {
      "verse": "40",
      "text": "Andrew was one of the two disciples who had followed Jesus. They had heard what John had said about Jesus. Andrew was Simon Peter's brother."
    },
    {
      "verse": "41",
      "text": "The first thing that Andrew did was to find his brother, Simon. Andrew said to Simon, ‘We have found the Messiah. ’ (‘Messiah’ and ‘Christ’ mean the same. )"
    },
    {
      "verse": "42",
      "text": "Then he brought Simon to Jesus. Jesus looked at Simon and he said, ‘You are Simon, John's son. Your name will be Cephas. ’ This name is the same as Peter, which means ‘rock’."
    },
    {
      "verse": "43",
      "text": "The next day, Jesus decided to go to Galilee. He met Philip, and Jesus said to Philip, ‘Follow me. ’"
    },
    {
      "verse": "44",
      "text": "Philip, like Andrew and Peter, came from the town of Bethsaida."
    },
    {
      "verse": "45",
      "text": "Philip went to find Nathanael. He told Nathanael, ‘We have found the man that Moses wrote about in the book of God's Law. The prophets also wrote about him. He is Jesus, who is Joseph's son, from Nazareth. ’"
    },
    {
      "verse": "46",
      "text": "Nathanael said, ‘I did not think that anything good could come from Nazareth! ’ Philip replied, ‘Come and see. ’"
    },
    {
      "verse": "47",
      "text": "Jesus saw Nathanael, who was coming towards him. Jesus said, ‘Here is a completely honest man. That is what a person from Israel should really be like. ’"
    },
    {
      "verse": "48",
      "text": "Nathanael asked, ‘How do you know me? ’ Jesus answered, ‘I saw you before Philip asked you to come. I saw you when you were under the fig tree. ’"
    },
    {
      "verse": "49",
      "text": "Nathanael said, ‘Teacher, you are the Son of God. You are the King of Israel. ’"
    },
    {
      "verse": "50",
      "text": "Jesus said to him, ‘I told you that I saw you under the fig tree. Now you believe me because I told you that. But you will see much greater things than that. ’"
    },
    {
      "verse": "51",
      "text": "And Jesus said to him, ‘I tell you this: You will see heaven open. You will see God's angels. They will be going up and they will be coming down on the Son of Man. ’"
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Two days after that, there was a marriage party. It was in the town of Cana, in Galilee. Jesus' mother was there."
    },
    {
      "verse": "2",
      "text": "People had asked Jesus and his disciples to come to the party too."
    },
    {
      "verse": "3",
      "text": "When people had drunk all the wine, Jesus' mother said to him, ‘They have no more wine. ’"
    },
    {
      "verse": "4",
      "text": "Jesus replied, ‘Woman, why do you tell me this? It is not my time yet. ’"
    },
    {
      "verse": "5",
      "text": "His mother said to the servants, ‘Do whatever he tells you to do. ’"
    },
    {
      "verse": "6",
      "text": "There were six big pots there. People had used stone to make them. Each pot could contain about 100 litres of water. The water was there so that the Jews could wash themselves in the way that their special rules taught."
    },
    {
      "verse": "7",
      "text": "Jesus said to the servants, ‘Fill the pots with water. ’ So they filled the pots to the top."
    },
    {
      "verse": "8",
      "text": "Then he said, ‘Now take some of the water from the pots and give it to the master of the party. ’ So they did that."
    },
    {
      "verse": "9",
      "text": "The master of the party tasted the water. The water had now become wine! The master did not know where the wine had come from. But the servants who had given it to him knew about it. Then the master asked the new husband to come to him."
    },
    {
      "verse": "10",
      "text": "The master said to him, ‘Everyone else brings out the best wine first. When people have had plenty to drink, then they give people cheaper wine. But you are different. You have kept the best wine until now. ’"
    },
    {
      "verse": "11",
      "text": "Jesus did this first miracle at Cana, in Galilee. In this way, Jesus showed how great and powerful he was. And his disciples believed in him."
    },
    {
      "verse": "12",
      "text": "After this, Jesus went to a town called Capernaum. His mother, his brothers and his disciples went with him. They stayed there for a few days."
    },
    {
      "verse": "13",
      "text": "It was almost time for the Jewish Passover festival. So Jesus went to Jerusalem."
    },
    {
      "verse": "14",
      "text": "He went into the yard of the temple. There he found people who were selling cows, sheep and doves. Other people were sitting at tables to change coins for people."
    },
    {
      "verse": "15",
      "text": "So Jesus made a whip from some pieces of rope. Then he made all the people leave the temple quickly, with the sheep and the cows. He threw onto the ground all the coins of the men who changed money. He turned their tables over."
    },
    {
      "verse": "16",
      "text": "He said to the people who sold birds, ‘Take them out of here! Do not make my Father's house into a market! ’"
    },
    {
      "verse": "17",
      "text": "His disciples remembered what it says in the Bible: ‘My love for your house burns inside me like a fire. ’"
    },
    {
      "verse": "18",
      "text": "Then the Jews asked Jesus, ‘What is your authority to do this? Do a miracle to show us that you really do have authority. ’"
    },
    {
      "verse": "19",
      "text": "Jesus answered them, ‘If you destroy this house of God, I will build it up again in three days. ’"
    },
    {
      "verse": "20",
      "text": "The Jews replied, ‘People have worked for 46 years to build this house. But you say that you will build it again in three days! ’"
    },
    {
      "verse": "21",
      "text": "But the house that Jesus was speaking about was his own body."
    },
    {
      "verse": "22",
      "text": "The disciples remembered this when Jesus had become alive again after his death. They remembered that he had said this. Then they believed what the Bible taught. They also believed the words that Jesus had spoken."
    },
    {
      "verse": "23",
      "text": "While Jesus was in Jerusalem for the Passover festival, he did many miracles. Many people saw these miracles that showed he was from God. As a result, they believed in Jesus."
    },
    {
      "verse": "24",
      "text": "But Jesus himself did not trust the people. He knew what all people are really like."
    },
    {
      "verse": "25",
      "text": "He did not need anyone to tell him what people are like. He knew already what was really in each person."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "There was a Pharisee called Nicodemus. He was one of the Jewish leaders."
    },
    {
      "verse": "2",
      "text": "He came to speak with Jesus at night. He said to Jesus, ‘Teacher, we know that God has sent you to us. We have seen the miracles that you are doing. Nobody could do these things unless God was with him. ’"
    },
    {
      "verse": "3",
      "text": "Jesus replied, ‘I tell you this: Unless a person is born from above, they cannot understand the kingdom of God. ’"
    },
    {
      "verse": "4",
      "text": "Nicodemus asked, ‘How can a man be born when he is old? He cannot return into his mother's body. He cannot be born a second time. ’"
    },
    {
      "verse": "5",
      "text": "Jesus explained, ‘I tell you this: Unless a person is born by water and by God's Spirit, he cannot come into the kingdom of God."
    },
    {
      "verse": "6",
      "text": "People give birth to what is human. But God's Spirit gives birth to spirit."
    },
    {
      "verse": "7",
      "text": "I said to you, “You must be born from above. ” What I said should not surprise you."
    },
    {
      "verse": "8",
      "text": "When someone is born by God's Spirit, it is like the wind that blows. The wind blows wherever it chooses to blow. You can hear it. But you do not know where it came from or where it is going. ’"
    },
    {
      "verse": "9",
      "text": "Nicodemus asked, ‘How can this happen? ’"
    },
    {
      "verse": "10",
      "text": "Jesus replied, ‘You are an important teacher of people in Israel. You ought to understand these things!"
    },
    {
      "verse": "11",
      "text": "I tell you this: We speak about things that we know. We tell you about what we have seen. But even then, you people do not believe our message."
    },
    {
      "verse": "12",
      "text": "I have told you about things that happen in this world. And you do not believe me. But now I am telling you about things that happen in heaven. So I do not think that you will ever believe me about those things."
    },
    {
      "verse": "13",
      "text": "The Son of Man came down from heaven. Nobody else has gone up to heaven except him."
    },
    {
      "verse": "14",
      "text": "Long ago Moses lifted up the metal snake in the wilderness to save his people. In the same way, people must lift up the Son of Man on a cross."
    },
    {
      "verse": "15",
      "text": "As a result, everyone who believes him will be able to live for ever with God."
    },
    {
      "verse": "16",
      "text": "God loved the people in the world so much that he gave his one and only Son to save them. As a result, everyone who believes in the Son will not die. Instead, they will live for ever with God. ’"
    },
    {
      "verse": "17",
      "text": "God did not send his Son into the world because he wanted to punish people. He sent his Son to save the people in the world from punishment."
    },
    {
      "verse": "18",
      "text": "God will not punish anyone who believes in his Son. But if people refuse to believe in the Son, God has already decided that he must punish them. They have not believed in God's one and only Son."
    },
    {
      "verse": "19",
      "text": "God's Son has brought light into the world. But some people did not love the light. They loved the dark instead. That was because they were doing evil things. That is why God has decided to punish those people."
    },
    {
      "verse": "20",
      "text": "Everyone who does evil things hates the light. A person like that will not come to the light because he is afraid. He does not want the bad things that he has done to show clearly."
    },
    {
      "verse": "21",
      "text": "But anyone who does what is true will come to the light. The light will show clearly that he has been doing what is right. Everyone can see that he has been obeying God."
    },
    {
      "verse": "22",
      "text": "After this, Jesus and his disciples went to the country places in Judea. Jesus stayed there with his disciples for some time, and they baptized people there."
    },
    {
      "verse": "23",
      "text": "John was also baptizing people. He was at a place called Aenon, near Salim, because there was a lot of water there. People were coming to him and John was baptizing them."
    },
    {
      "verse": "24",
      "text": "(This happened before the rulers put John in prison. )"
    },
    {
      "verse": "25",
      "text": "John's disciples began to argue with a certain Jew about some Jewish rules. Those rules told people how they should wash properly."
    },
    {
      "verse": "26",
      "text": "The disciples then came to John. They said to him, ‘Teacher, remember the man, Jesus, that you spoke to us about. He was with you on the other side of the Jordan River. Now he is baptizing people and everyone is going to him. ’"
    },
    {
      "verse": "27",
      "text": "John replied, ‘A man can receive only what God gives to him, nothing else."
    },
    {
      "verse": "28",
      "text": "You yourselves will remember that I said, “I am not the Messiah, but God sent me to prepare things for the Messiah. ”"
    },
    {
      "verse": "29",
      "text": "When a man marries a wife, she belongs to him. The man's special friend listens carefully. He wants to know when the man will arrive. That friend is very happy when he hears the man's voice. I am like that friend, so I am completely happy now."
    },
    {
      "verse": "30",
      "text": "Jesus must become greater, but I must become less important."
    },
    {
      "verse": "31",
      "text": "The one who comes from above is greater than all things. A person who comes from the earth belongs to the earth. A person like that speaks only about things that belong to the earth. But the one who comes from heaven is greater than all things."
    },
    {
      "verse": "32",
      "text": "He tells people about the things that he has seen. He tells about what he has heard. But people do not believe his message."
    },
    {
      "verse": "33",
      "text": "Anyone who does believe his message agrees that God is true."
    },
    {
      "verse": "34",
      "text": "The one that God has sent speaks God's words. God has given his Spirit to fill that person completely."
    },
    {
      "verse": "35",
      "text": "The Father loves the Son. He has given his Son authority over all things."
    },
    {
      "verse": "36",
      "text": "Anyone who believes in the Son has life with God for ever. But anyone who refuses to obey the Son will never have life with God. God will continue to be angry with people like that. ’"
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "The Pharisees heard the news that many people were joining Jesus' group of disciples. They heard that Jesus was baptizing more disciples than John was baptizing."
    },
    {
      "verse": "2",
      "text": "But really Jesus himself did not baptize anyone. It was only Jesus' disciples who baptized people."
    },
    {
      "verse": "3",
      "text": "Jesus discovered what the Pharisees were thinking, so he left Judea. He returned to Galilee."
    },
    {
      "verse": "4",
      "text": "On his way, he had to go through Samaria."
    },
    {
      "verse": "5",
      "text": "He came to a town in Samaria called Sychar. It was near to the piece of land that Jacob had given to his son, Joseph, many years earlier."
    },
    {
      "verse": "9",
      "text": "The woman from Samaria said to him, ‘You are a Jew and I am a woman from Samaria. Why would you ask me to give you a drink? ’ (The Jews usually do not talk to people who come from Samaria. )"
    },
    {
      "verse": "10",
      "text": "Jesus answered the woman, ‘You do not know what God could give to you. I asked you to give a drink to me. But you do not know who I am. If you did know, you would have asked me to give a drink to you. Then I would have given to you water that gives life. ’"
    },
    {
      "verse": "11",
      "text": "The woman said, ‘Sir, you have no bucket, and the well is deep. Where can you get this water that gives life?"
    },
    {
      "verse": "12",
      "text": "Jacob, our ancestor, gave this well to us. He, his sons and his sheep, goats and cows all drank its water. Are you saying that you are greater than Jacob? ’"
    },
    {
      "verse": "13",
      "text": "Jesus answered, ‘Everyone who drinks water from this well will get thirsty again."
    },
    {
      "verse": "14",
      "text": "But I can give people a different kind of water. Everyone who drinks that kind of water will never get thirsty again. The water that I give them will become like a well inside them. That well will continue to provide water that gives them life for ever with God. ’"
    },
    {
      "verse": "15",
      "text": "The woman said to him, ‘Sir, give this water to me. Then I will never get thirsty again. And I will not have to continue to come here so that I can get water. ’"
    },
    {
      "verse": "16",
      "text": "Jesus said to her, ‘Go and fetch your husband. Then return here. ’"
    },
    {
      "verse": "17",
      "text": "The woman replied, ‘I have no husband. ’ Jesus said to her, ‘You are right when you say, “I have no husband. ”"
    },
    {
      "verse": "18",
      "text": "It is true that you have had five husbands. And now you live with a man who is not your husband. What you have said is completely true. ’"
    },
    {
      "verse": "19",
      "text": "The woman said to him, ‘Sir, I can see that you are a prophet."
    },
    {
      "verse": "20",
      "text": "Our ancestors worshipped God on this mountain. But you Jews say that Jerusalem is the right place to worship. ’"
    },
    {
      "verse": "21",
      "text": "Jesus said to her, ‘Believe me, woman. Soon you will not worship the Father either on this mountain or at Jerusalem."
    },
    {
      "verse": "22",
      "text": "You people from Samaria do not know the one that you worship. But we Jews do know him, because God's salvation comes from among the Jewish people."
    },
    {
      "verse": "23",
      "text": "But people will soon have a new way to worship the Father. Yes, that time has already come. Those people who really want to worship the Father will worship him in their spirits, in a true way. The Father looks for people who will worship him like that."
    },
    {
      "verse": "24",
      "text": "God is spirit. People who worship him must worship from their spirits in a true way. ’"
    },
    {
      "verse": "25",
      "text": "The woman said to Jesus, ‘I know that the Messiah will come. He is called Christ. When he comes, he will explain everything to us. ’"
    },
    {
      "verse": "26",
      "text": "Jesus said to her, ‘I, who am speaking to you, am he. ’"
    },
    {
      "verse": "27",
      "text": "At this moment, Jesus' disciples returned. They were surprised to see that Jesus was talking to a woman. But none of them asked him, ‘What do you want? ’ or, ‘Why are you talking to her? ’"
    },
    {
      "verse": "28",
      "text": "Then the woman left her water pot and she returned to the town. She said to the people there,"
    },
    {
      "verse": "29",
      "text": "‘Come and see a man who has told me everything about myself. He told me all the things that I have ever done! He must be the Messiah! ’"
    },
    {
      "verse": "30",
      "text": "So they left the town and they went to find Jesus."
    },
    {
      "verse": "31",
      "text": "While that was happening, the disciples said to Jesus, ‘Teacher, eat something. ’"
    },
    {
      "verse": "32",
      "text": "But he said to them, ‘I have food that I can eat. But you do not know about it. ’"
    },
    {
      "verse": "33",
      "text": "So the disciples asked each other, ‘Could someone have brought food to him? ’"
    },
    {
      "verse": "34",
      "text": "Jesus said to them, ‘My Father has sent me. I must do the things he wants me to do. I must finish the work that he has given to me to do. That is my food."
    },
    {
      "verse": "35",
      "text": "You often say, “It is still four more months until the plants in the farmers' fields will be ready for the harvest. ” But I say that you should open your eyes. Look at the fields. The plants are ready for the harvest now."
    },
    {
      "verse": "36",
      "text": "The workers are already bringing in the fruit and their master is paying them. As a result, people are receiving life for ever with God. So the person who plants the seeds will be very happy. And the person who brings in the fruit will also be very happy. Both of them will be happy together."
    },
    {
      "verse": "37",
      "text": "You also say, “One person plants the seeds and another person brings in the fruit. ” Now you can see that this is true."
    },
    {
      "verse": "38",
      "text": "I have sent you to bring people to me like a harvest of fruit. You did not do the work to prepare that fruit. Other people did that hard work. Now you have brought in the fruit that they worked for. That makes you happy. ’"
    },
    {
      "verse": "39",
      "text": "Many of the people who lived in that town in Samaria heard the woman's story. She had said to them, ‘He told me all the things that I have ever done! ’ Because of this, they believed in Jesus."
    },
    {
      "verse": "40",
      "text": "So when these people came to Jesus, they asked him to stay with them. So he stayed there for two days."
    },
    {
      "verse": "41",
      "text": "Many more people believed in Jesus when they listened to his own words."
    },
    {
      "verse": "42",
      "text": "The people said to the woman, ‘Now we believe in him because we ourselves have heard him. We do not believe only because of what you told us. He really is the man that God has sent to save the world. We know that now. ’"
    },
    {
      "verse": "43",
      "text": "After those two days in Samaria, Jesus left there and he went to Galilee."
    },
    {
      "verse": "44",
      "text": "Jesus himself had said earlier, ‘When a prophet of God visits his own town, the people there will not accept him. ’"
    },
    {
      "verse": "45",
      "text": "When he arrived in Galilee, the people there were happy to see him. They had been in Jerusalem at the Passover festival too. They had seen all the things that Jesus had done there."
    },
    {
      "verse": "46",
      "text": "Jesus visited Cana again. This was the town in Galilee where he had changed the water into wine. A certain man who was one of the king's officers was there. This officer had a son who was at his home in Capernaum. His son was very ill."
    },
    {
      "verse": "47",
      "text": "The officer had heard the news that Jesus had arrived in Galilee from Judea. So he went to Jesus and asked him to go to Capernaum. His son was dying. So he asked Jesus strongly to make his son well again."
    },
    {
      "verse": "48",
      "text": "Jesus said to him, ‘You people want me to do great miracles that will surprise you. Unless you see these great miracles, none of you will ever believe my message. ’"
    },
    {
      "verse": "49",
      "text": "The king's officer said to Jesus, ‘Sir, come with me now before my child dies. ’"
    },
    {
      "verse": "50",
      "text": "Jesus replied, ‘Go home. Your son will live. ’ The man believed what Jesus had said. He started to go home."
    },
    {
      "verse": "51",
      "text": "While he was on the way, his servants met him. They told him, ‘Your child is now well. He will live. ’"
    },
    {
      "verse": "52",
      "text": "He asked them, ‘At what time did he start to get well? ’ They told him, ‘It was yesterday afternoon, at one o'clock. Then his body was no longer hot. ’"
    },
    {
      "verse": "53",
      "text": "Then the father remembered. He knew it was the time when Jesus had said to him, ‘Your son will live. ’ So the man and all his family believed in Jesus."
    },
    {
      "verse": "54",
      "text": "This was the second miracle that Jesus did after he returned from Judea to Galilee."
    },
    {
      "verse": "6",
      "text": "Jacob's well was there. Jesus was tired after his journey and he sat down by the well. It was about midday."
    },
    {
      "verse": "7",
      "text": "His disciples had gone to buy food in the town. A woman from Samaria came to the well to get some water."
    },
    {
      "verse": "8",
      "text": "Jesus said to her, ‘Please give a drink to me. ’."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Some time after that, Jesus went to Jerusalem, because it was time for one of the Jewish festivals."
    },
    {
      "verse": "2",
      "text": "There is a pool near the Sheep Gate in Jerusalem. Its name in the Jewish language is Bethesda. Round the pool, there is a building with five places that have a roof over them."
    },
    {
      "verse": "3",
      "text": "A large number of sick people were lying in these places. Some of them were blind. Some of them could not walk properly. Some of them could not move their legs or their arms. [ They were waiting for when the water started to move."
    },
    {
      "verse": "4",
      "text": "An angel would go down into the pool at certain times and move the water about. When that happened, all the sick people tried to get into the pool. The first person who got into the water became well, whatever his illness was. ]"
    },
    {
      "verse": "5",
      "text": "years."
    },
    {
      "verse": "6",
      "text": "Jesus saw this man. He knew that the man had been ill like this for a very long time. So he asked the man, ‘Do you want to get well? ’"
    },
    {
      "verse": "7",
      "text": "The sick man said, ‘Sir, I do not have anyone who will help me. I need somebody who will put me into the pool. When the water starts to move, I try to get in. But someone else always gets in before me. ’"
    },
    {
      "verse": "8",
      "text": "Then Jesus said to him, ‘Stand up! Pick up your mat and walk. ’"
    },
    {
      "verse": "9",
      "text": "The man became well immediately. He picked up his mat and he walked. The day when this happened was a Jewish day of rest."
    },
    {
      "verse": "10",
      "text": "Because of this, the Jewish leaders spoke to the man that Jesus had made well. They said to him, ‘You must not carry your mat on our day of rest. You are not obeying the rules. ’"
    },
    {
      "verse": "11",
      "text": "The man replied, ‘The man who made me well said to me, “Pick up your mat and walk. ” ’"
    },
    {
      "verse": "12",
      "text": "So they asked him, ‘Who is this man? Who said to you, “Pick up your mat and walk”? ’"
    },
    {
      "verse": "13",
      "text": "The man did not know who had made him well. Jesus had gone away and joined the crowd that was there."
    },
    {
      "verse": "14",
      "text": "Some time after that, Jesus found the man in the temple. Jesus said to him, ‘See, you have become well. Stop doing wrong things. If you do not stop, something worse may happen to you. ’"
    },
    {
      "verse": "15",
      "text": "Then the man went to the Jewish leaders. He told them that it was Jesus who had made him well."
    },
    {
      "verse": "16",
      "text": "The Jewish leaders were angry because Jesus had made a man well on their day of rest. As a result, they began to cause a lot of trouble for Jesus."
    },
    {
      "verse": "17",
      "text": "But Jesus said to them, ‘My Father is still working, and I too must work. ’"
    },
    {
      "verse": "18",
      "text": "Because Jesus said this, the Jewish leaders became really angry. They wanted even more to kill him. Jesus not only worked on the day of rest. He was also calling God his own Father, so he was making himself equal with God."
    },
    {
      "verse": "19",
      "text": "Jesus answered them, ‘I tell you this: The Son can do nothing by himself. He sees what the Father does, and he can do only those same things. What the Father does, the Son also does."
    },
    {
      "verse": "20",
      "text": "The Father loves the Son. He shows the Son all the things that he himself does. And the Father will show the Son even greater things to do than these. Those greater things will surprise you even more than what you have already seen."
    },
    {
      "verse": "21",
      "text": "The Father raises dead people to make them alive again. In the same way, the Son gives life to whoever he chooses."
    },
    {
      "verse": "22",
      "text": "More than that, the Father does not judge anyone. He has given authority to the Son, so that the Son will judge all people."
    },
    {
      "verse": "23",
      "text": "Then all people will respect the Son as a great person. They will respect him in the way that they respect the Father. The Father sent the Son. So if people refuse to respect the Son, it shows that they do not respect the Father either."
    },
    {
      "verse": "24",
      "text": "I tell you this: Everyone who hears my message should believe in the Father who sent me. If they believe in me, they will have life for ever with God. God will not say that they are guilty. They are no longer under the power of death. Instead, they have life with God."
    },
    {
      "verse": "25",
      "text": "I tell you this: A time will soon come when those who are dead in their spirits will hear the voice of the Son of God. Yes, it is that time already. Those people who hear that message will receive true life."
    },
    {
      "verse": "26",
      "text": "The Father himself can give people life. In the same way, he has given authority to the Son to give people life."
    },
    {
      "verse": "27",
      "text": "The Father has also given authority to the Son to judge people. That is because I am the Son of Man."
    },
    {
      "verse": "28",
      "text": "Do not be surprised by this. There will be a time when all the dead people will hear the Son's voice."
    },
    {
      "verse": "29",
      "text": "They will come out from under the ground. Those people who have done good things will rise from death and they will live with God. Those people who have done evil things will also rise from death. But they will rise so that God can punish them as guilty people. ’"
    },
    {
      "verse": "30",
      "text": "Then Jesus said, ‘I can do nothing by myself. I hear what the Father says to me. Then, because of what he says, I judge people. So I judge in a way that is fair. I am not trying to do what I want for myself. The Father sent me, and I want to do what he wants."
    },
    {
      "verse": "31",
      "text": "If I say great things about myself, nobody would know that my words are true."
    },
    {
      "verse": "32",
      "text": "But there is someone else who speaks about me. I know that what he says about me is true."
    },
    {
      "verse": "33",
      "text": "You have sent your people to ask John about me. What he has told you about me is true."
    },
    {
      "verse": "34",
      "text": "I do not need any man to speak on my behalf. But I am telling you this to help you. Then God will be able to save you."
    },
    {
      "verse": "35",
      "text": "John was like a light that shone brightly. For a certain time, you enjoyed the light that he gave."
    },
    {
      "verse": "36",
      "text": "But it is not only John who shows who I am. There are other things that show it more strongly. My Father has given work to me so that I could finish it. These are the things that I do, and they show who I am. They show clearly that the Father has sent me."
    },
    {
      "verse": "37",
      "text": "Also, the Father himself has spoken about me. You have never heard his voice. And you have never seen his shape."
    },
    {
      "verse": "38",
      "text": "I am the one that he has sent. You do not receive his message because you do not believe in me."
    },
    {
      "verse": "39",
      "text": "You study carefully what the Bible teaches. You think that those books will give you life with God. And it is true, those books do speak about who I am."
    },
    {
      "verse": "40",
      "text": "But then you refuse to come to me so that you may have life with God!"
    },
    {
      "verse": "41",
      "text": "I do not think that it is important for people to praise me."
    },
    {
      "verse": "42",
      "text": "But I know what kind of people you are. I know that you do not really love God."
    },
    {
      "verse": "43",
      "text": "I have come with my Father's authority, but you do not accept me. But if someone else comes with his own authority, then you will accept him."
    },
    {
      "verse": "44",
      "text": "You like to praise each other. That makes you happy. But what about God himself? You do not try to do good things so that he will praise you. That is why you will never believe in me."
    },
    {
      "verse": "45",
      "text": "But I will not have to tell the Father that you are guilty. No, it is Moses who will do that. You think that Moses is the one who will show that you are right. But he is the one who will show that you are guilty."
    },
    {
      "verse": "46",
      "text": "Moses wrote about me. So, if you had really believed Moses, you would believe me."
    },
    {
      "verse": "47",
      "text": "But you do not believe what Moses wrote. So you will never believe what I say. ’"
    }
  ],
  "6": [
    {
      "verse": "1",
      "text": "Some time after that, Jesus went across Lake Galilee, which is also called Lake Tiberias."
    },
    {
      "verse": "2",
      "text": "A large crowd of people followed him, because of the miracles that he had done. They had seen him make sick people well."
    },
    {
      "verse": "3",
      "text": "Jesus went up a hill and he sat down there with his disciples."
    },
    {
      "verse": "4",
      "text": "It was nearly the time for the Jewish Passover Festival."
    },
    {
      "verse": "5",
      "text": "Jesus looked up. He saw a large crowd of people who were coming towards him. He said to Philip, ‘Where can we buy enough bread to feed all these people? ’"
    },
    {
      "verse": "6",
      "text": "Jesus himself already knew what he would do. But he asked Philip this question because he wanted to know what Philip would say."
    },
    {
      "verse": "7",
      "text": "Philip answered, ‘A man could work for eight months to get 200 silver coins. But he still would not have enough money to buy bread for all these people. There would not be enough bread for each person here to have even a little piece. ’"
    },
    {
      "verse": "8",
      "text": "Then Andrew, another one of Jesus' disciples, spoke. He was Simon Peter's brother."
    },
    {
      "verse": "9",
      "text": "He said to Jesus, ‘Here is a boy who has five small loaves and two fish. But that will certainly not be enough food for so many people. ’"
    },
    {
      "verse": "10",
      "text": "Jesus said, ‘Tell the people to sit down. ’ There was plenty of grass in that place, so the people sat down. There were about 5, 000 men in the crowd."
    },
    {
      "verse": "11",
      "text": "Jesus took the loaves of bread and he thanked God for them. Then he broke the loaves into pieces. He passed them to all the people who were sitting there. Everyone had as much bread as they wanted to eat. Jesus did the same with the fish."
    },
    {
      "verse": "12",
      "text": "When everyone had eaten enough food, Jesus said to his disciples, ‘Do not waste anything. Pick up all the little bits of food that people have not eaten. ’"
    },
    {
      "verse": "13",
      "text": "So the disciples picked up all the pieces. They filled 12 baskets with the bits of bread that the people had not eaten."
    },
    {
      "verse": "14",
      "text": "The people saw this miracle that Jesus did. So they began to talk about it. They said, ‘Certainly, this man is the Prophet who must come into the world. ’"
    },
    {
      "verse": "15",
      "text": "The people wanted to take hold of Jesus so that they could make him their king. But Jesus knew that they wanted to do this. So he went away to the hills again by himself."
    },
    {
      "verse": "16",
      "text": "When it was evening, Jesus' disciples went down to the lake."
    },
    {
      "verse": "17",
      "text": "They got into a boat and they started to sail towards Capernaum. It had become dark and Jesus still had not come to them."
    },
    {
      "verse": "18",
      "text": "A very strong wind was blowing and the waves became dangerous."
    },
    {
      "verse": "19",
      "text": "The disciples were trying to move the boat through the water. When they had gone about six kilometres they saw Jesus. He was walking on the water and coming near to the boat. They were very afraid."
    },
    {
      "verse": "20",
      "text": "But Jesus said to them, ‘It is I. Do not be afraid. ’"
    },
    {
      "verse": "21",
      "text": "So the disciples were happy to let Jesus get into the boat. Immediately, the boat came to the shore where they wanted to be."
    },
    {
      "verse": "22",
      "text": "The crowd of people had stayed on the other side of the lake. The next day, they saw that the only boat had gone. They knew that Jesus' disciples had taken it. They also knew that Jesus had not gone with his disciples."
    },
    {
      "verse": "23",
      "text": "Other boats from Tiberias then arrived near to the place where all the people were. They had eaten the bread there after the Lord Jesus had thanked God for it."
    },
    {
      "verse": "24",
      "text": "The crowd saw that neither Jesus nor his disciples were still there. So they got into the boats and they went to Capernaum. They went there to look for Jesus."
    },
    {
      "verse": "25",
      "text": "The people found Jesus on the other side of the lake. They asked him, ‘Teacher, when did you arrive here? ’"
    },
    {
      "verse": "26",
      "text": "Jesus answered, ‘I tell you this: You saw me do miracles that show God's power. But you are not looking for me because of that. No, you are looking for me because you ate the loaves. I gave you all the food that you needed."
    },
    {
      "verse": "27",
      "text": "Do not work only for that kind of food. It soon becomes spoiled. Instead, work to get the food that continues for ever. That kind of food gives you life with God. The Son of Man will give this food to you. God, the Father, has given the Son authority to do this. ’"
    },
    {
      "verse": "28",
      "text": "Then the people asked him, ‘How can we do the work that God wants us to do? ’"
    },
    {
      "verse": "29",
      "text": "Jesus answered, ‘You should believe in the one that God has sent to you. That is the work that God wants you to do. ’"
    },
    {
      "verse": "30",
      "text": "So then the people asked him, ‘What miracle will you do? Do one that shows that God has sent you. If we see that, we will believe in you. What will you do?"
    },
    {
      "verse": "31",
      "text": "Our ancestors ate manna in the wilderness. We know that it says in the Bible, “God gave bread to them from heaven for them to eat. ” ’"
    },
    {
      "verse": "32",
      "text": "Jesus said to them, ‘I tell you this: It was not Moses who gave bread to you from heaven. No. It is my Father who gives to you the true bread from heaven."
    },
    {
      "verse": "33",
      "text": "God's bread is the one who comes down from heaven. He is the one who gives life to people in the world. ’"
    },
    {
      "verse": "34",
      "text": "So they said to him, ‘Sir, please give this bread to us now and always. ’"
    },
    {
      "verse": "35",
      "text": "Then Jesus said to them, ‘I am the bread that gives life to people. Anyone who comes to me will never be hungry. Anyone who believes in me will never be thirsty."
    },
    {
      "verse": "36",
      "text": "You have seen me, but still you do not believe in me. I have told you that before."
    },
    {
      "verse": "37",
      "text": "Everyone that the Father gives to me will come to me. When anyone comes to me, I will never send that person away."
    },
    {
      "verse": "38",
      "text": "I have not come down from heaven to do what I myself choose to do. No, my Father has sent me. I have come to do what he wants me to do."
    },
    {
      "verse": "39",
      "text": "He has sent me. He does not want me to lose any of the people that he has given to me. Not even one of them. He wants me to raise all of them up to life on the last day."
    },
    {
      "verse": "40",
      "text": "These are the people who will have life for ever with God: everyone who sees the Son and believes in him. I will raise them all up on the last day. That is what my Father wants. ’"
    },
    {
      "verse": "41",
      "text": "Jesus had said, ‘I am the bread that came down from heaven. ’ When he said this, the Jewish leaders there did not like it. So they started to say bad things about Jesus."
    },
    {
      "verse": "42",
      "text": "They said, ‘This is Jesus, the son of Joseph. We know his father and his mother. He should not say that he came down from heaven. ’"
    },
    {
      "verse": "43",
      "text": "Jesus answered, ‘Stop saying these bad things about me to each other."
    },
    {
      "verse": "44",
      "text": "The Father has sent me. Nobody can come to me unless the Father brings them to me. I will raise those people up on the last day, so that they have life for ever."
    },
    {
      "verse": "45",
      "text": "The prophets wrote in the Bible, “God will teach all the people. ” Everyone who hears the Father's message and learns from him will come to me."
    },
    {
      "verse": "46",
      "text": "I came from God and I am the only one who has seen the Father. Nobody else has seen him."
    },
    {
      "verse": "47",
      "text": "I tell you this: The person who believes my message has life for ever."
    },
    {
      "verse": "48",
      "text": "I am the bread that causes you to live."
    },
    {
      "verse": "49",
      "text": "Your ancestors ate the manna in the wilderness, but they died."
    },
    {
      "verse": "50",
      "text": "This bread that comes down from heaven is different. Anyone who eats this bread will not die."
    },
    {
      "verse": "51",
      "text": "I am the bread that gives life to people. This bread came down from heaven. If anyone eats this bread, he will live for ever. The bread that I will give is my own body. I will give it so that all people in the world may have life with God. ’"
    },
    {
      "verse": "52",
      "text": "Then the Jewish leaders became angry and they argued with each other even more. They said, ‘This man cannot give his body to us so that we can eat it! ’"
    },
    {
      "verse": "53",
      "text": "Jesus said to them, ‘I tell you this: You must eat the body of the Son of Man and you must drink his blood. Unless you do those things, you do not have true life."
    },
    {
      "verse": "54",
      "text": "Every person needs to eat my body and they need to drink my blood. If they do those things, they have life for ever with God. I will raise them up on the last day."
    },
    {
      "verse": "55",
      "text": "My body is the true food and my blood is the true drink."
    },
    {
      "verse": "56",
      "text": "Anyone who eats my body and drinks my blood lives in me. And I live in them."
    },
    {
      "verse": "57",
      "text": "The Father, who has life, sent me. I live because of him. In the same way, anyone who takes me as their food will live because of me."
    },
    {
      "verse": "58",
      "text": "This is the bread that came down from heaven. It is not like the manna that your ancestors ate. They ate it but they died. But the person who eats this bread will live for ever. ’"
    },
    {
      "verse": "59",
      "text": "Jesus said these things while he was teaching in the Jewish meeting place at Capernaum."
    },
    {
      "verse": "60",
      "text": "Many of Jesus' disciples did not like these words. They said, ‘This thing that he teaches is too difficult. Nobody can agree with it! ’"
    },
    {
      "verse": "61",
      "text": "Jesus himself knew that the disciples did not like his message. He did not need anyone to tell him. He said to them, ‘This seems to make you angry."
    },
    {
      "verse": "62",
      "text": "Think about this: The Son of Man will go up again to the place where he was before. And you will see him go up. Will you agree to that?"
    },
    {
      "verse": "63",
      "text": "It is the Spirit that gives you life. People cannot do that. The words that I have spoken to you come from the Spirit. They give you life."
    },
    {
      "verse": "64",
      "text": "But some of you do not believe my message. ’Jesus had known from the beginning which of them would not believe in him. Also, he had always known who would sell him to his enemies."
    },
    {
      "verse": "65",
      "text": "Then Jesus said to them, ‘That is why I told you that only the Father can bring people to me. Nobody can come to me unless the Father makes them able to come. ’"
    },
    {
      "verse": "66",
      "text": "From that time, many of Jesus' disciples left him. They did not go with him any longer."
    },
    {
      "verse": "67",
      "text": "apostles, ‘Do you want to go away from me, too? ’"
    },
    {
      "verse": "68",
      "text": "Simon Peter answered him, ‘Lord, there is nobody else that we could go to. You speak the words that give us life for ever."
    },
    {
      "verse": "69",
      "text": "We believe that you are the Holy One that God has sent. We are sure about that. ’"
    },
    {
      "verse": "70",
      "text": "Jesus replied, ‘I have chosen the 12 of you. But one of you is a servant of Satan! ’"
    },
    {
      "verse": "71",
      "text": "He was speaking about Judas, the son of Simon Iscariot. Judas was one of the 12 apostles, but later he would sell Jesus to Jesus' enemies."
    }
  ],
  "7": [
    {
      "verse": "1",
      "text": "After this, Jesus visited many places in Galilee. He did not want to visit Judea because the Jewish leaders there wanted to kill him."
    },
    {
      "verse": "2",
      "text": "It was almost time for the Jewish Festival of Tabernacles."
    },
    {
      "verse": "3",
      "text": "So Jesus' brothers said to him, ‘You should leave this place and you should go to Judea. Then your disciples will see the great things that you do."
    },
    {
      "verse": "4",
      "text": "Nobody does things secretly if he wants everyone to know him. You are doing these things, so you should show yourself to everybody. ’"
    },
    {
      "verse": "5",
      "text": "Even his own brothers did not believe in him."
    },
    {
      "verse": "6",
      "text": "So Jesus said to them, ‘It is not the right time for me yet. For you, any time is right."
    },
    {
      "verse": "7",
      "text": "People who belong to this world cannot hate you. But they hate me. The things that they do are very bad. And I tell them that those things are wrong. That is why they hate me."
    },
    {
      "verse": "8",
      "text": "You should go to the festival. I will not go to it now, because it is not the right time for me yet. ’"
    },
    {
      "verse": "9",
      "text": "After Jesus said that, he stayed in Galilee."
    },
    {
      "verse": "10",
      "text": "Some time after his brothers had gone, Jesus also went to the festival. But he did not let other people know that he was going. Instead, he went secretly."
    },
    {
      "verse": "11",
      "text": "The Jewish leaders were looking for him at the festival. They asked, ‘Where is that man? ’"
    },
    {
      "verse": "12",
      "text": "People in the crowd were talking quietly to each other about Jesus. Some people said, ‘He is a good man. ’ But other people said, ‘No, he is telling the people things that are not true. ’"
    },
    {
      "verse": "13",
      "text": "But nobody spoke in public places about him, because they were afraid of the Jewish leaders."
    },
    {
      "verse": "14",
      "text": "In the middle of the time of the festival, Jesus went to the temple. He started to teach in the yard there."
    },
    {
      "verse": "15",
      "text": "The Jewish leaders were very surprised. They asked, ‘How does this man know so much? He has not learned in our schools. ’"
    },
    {
      "verse": "16",
      "text": "Jesus answered, ‘What I teach does not come from me. No, it comes from the one who sent me."
    },
    {
      "verse": "17",
      "text": "Anyone who chooses to do what God wants will know about my teaching. They will know whether it comes from God, or whether it comes from my own thoughts."
    },
    {
      "verse": "18",
      "text": "A person who teaches his own ideas wants people to think that he himself is great. But I want to show that the one who sent me is great. A person like that is honest and there is nothing false in him."
    },
    {
      "verse": "19",
      "text": "Moses gave God's Law to you. But not one of you obeys that Law. Why are you trying to kill me? ’"
    },
    {
      "verse": "20",
      "text": "The crowd answered, ‘You have a demon in you! Nobody is trying to kill you! ’"
    },
    {
      "verse": "21",
      "text": "Jesus replied, ‘I did one miracle on the day of rest, and all of you were surprised."
    },
    {
      "verse": "22",
      "text": "Moses gave you a law that you must circumcise your sons. Your ancestors taught that, even before Moses was born. So you will agree to circumcise a boy, even on the day of rest."
    },
    {
      "verse": "23",
      "text": "You will do that so that you obey Moses' law. So you should not be angry with me because I made a man completely well on the day of rest."
    },
    {
      "verse": "24",
      "text": "Do not quickly decide whether something is right or wrong just because of what you see. Instead, think about it carefully. Then you will judge in a right way. ’"
    },
    {
      "verse": "25",
      "text": "Some of the people in Jerusalem began to say, ‘This is the man that our leaders want to kill."
    },
    {
      "verse": "26",
      "text": "But look! He is speaking to the crowds, and the leaders are not saying anything against him! Perhaps they really think that he is the Messiah!"
    },
    {
      "verse": "27",
      "text": "But we know where this man came from. When the Messiah comes, nobody will know that. Nobody will know where he has come from. ’"
    },
    {
      "verse": "28",
      "text": "Jesus was still teaching in the yard of the temple. He shouted, ‘Yes, you say that you know me. And you know where I came from. But I have not come because I myself decided to come. He who sent me is true. You do not know him."
    },
    {
      "verse": "29",
      "text": "But I know him because I have come from him. He is the one who sent me. ’"
    },
    {
      "verse": "30",
      "text": "When they heard this, they tried to take hold of him. But nobody could put their hands on him, because it was not yet the right time."
    },
    {
      "verse": "31",
      "text": "But many people in the crowd believed in Jesus. They said, ‘This man has done so many miracles. Surely he is the Messiah! Nobody could do more miracles than he has done. ’"
    },
    {
      "verse": "32",
      "text": "The Pharisees heard what these people were saying quietly about Jesus. Then the leaders of the priests and the Pharisees sent some of their officers to take him away."
    },
    {
      "verse": "33",
      "text": "Jesus said, ‘I will be with you for only a short time. Then I will return to the one who sent me."
    },
    {
      "verse": "34",
      "text": "You will look for me, but you will not find me. You cannot go to the place where I will be. ’"
    },
    {
      "verse": "35",
      "text": "The Jewish leaders asked each other, ‘What is he trying to tell us? Where can he go so that we cannot find him? Perhaps he will go to our people who have gone away to live among the Greek people. Perhaps he will go to teach the Greek people."
    },
    {
      "verse": "36",
      "text": "He said, “You will look for me, but you will not find me. ” And he also said, “You cannot go to the place where I will be. ” What does he mean? ’"
    },
    {
      "verse": "37",
      "text": "The last day of the festival was the most important day. On that day, Jesus stood up and he spoke with a loud voice. He said, ‘If anyone is thirsty, he should come to me so that he may drink."
    },
    {
      "verse": "38",
      "text": "It says in the Bible, “God will cause streams of water to pour out from anyone who believes in me. Water that gives life will come out from inside that person. ” ’"
    },
    {
      "verse": "39",
      "text": "Jesus was speaking about God's Spirit, who would come to people some time after that. Those people who believed in Jesus would receive God's Spirit at that later time. But God had not yet given his Spirit to people, because he had not yet raised Jesus back up to heaven."
    },
    {
      "verse": "40",
      "text": "The people in the crowd heard Jesus say these words. Some of them said, ‘Surely this man must be the Prophet from God that we have been waiting for! ’"
    },
    {
      "verse": "41",
      "text": "Other people said, ‘This man is the Messiah. ’ But some other people said, ‘The Messiah will not come from Galilee!"
    },
    {
      "verse": "42",
      "text": "The Bible says that the Messiah will come from King David's family. He will come from Bethlehem, the town where David lived. ’"
    },
    {
      "verse": "43",
      "text": "In this way the people had different thoughts about Jesus."
    },
    {
      "verse": "44",
      "text": "Some people wanted to take hold of him. But nobody could put their hands on him to take him away."
    },
    {
      "verse": "45",
      "text": "The officers returned to the leaders of the priests and the Pharisees. The leaders asked their officers, ‘Why did you not bring Jesus here? ’"
    },
    {
      "verse": "46",
      "text": "The officers answered, ‘Nobody has ever spoken great things like this man speaks. ’"
    },
    {
      "verse": "47",
      "text": "The Pharisees replied, ‘He seems to have made you believe his lies!"
    },
    {
      "verse": "48",
      "text": "None of the Pharisees or our leaders believe in him."
    },
    {
      "verse": "49",
      "text": "But this crowd does not know what God's Law teaches. God will surely punish them. ’"
    },
    {
      "verse": "50",
      "text": "Nicodemus spoke to them. He himself was one of the Pharisees. He was the man who had gone to speak with Jesus before. He said,"
    },
    {
      "verse": "51",
      "text": "‘We must find out first what this man has done. Then we can decide if it is right to punish him. Our law says that we must listen to him first. ’"
    },
    {
      "verse": "52",
      "text": "They answered Nicodemus, ‘Perhaps you come from Galilee, as well as him! Study what the Bible teaches. You will learn that no prophet of God ever comes from Galilee. ’"
    },
    {
      "verse": "53",
      "text": "[Then everyone went to his own home. ]"
    }
  ],
  "8": [
    {
      "verse": "1",
      "text": "[But Jesus went to the hill which is called the Mount of Olives."
    },
    {
      "verse": "2",
      "text": "Early the next morning, Jesus returned to the temple in Jerusalem. All the people came to him. He sat down and he began to teach them."
    },
    {
      "verse": "3",
      "text": "The Pharisees and the teachers of God's Law brought a woman to him. They had found her with another man. She was having sex with a man who was not her husband. They made her stand in front of all the people there."
    },
    {
      "verse": "4",
      "text": "They said to Jesus, ‘Teacher, we found this woman. She was having sex with a man who was not her husband."
    },
    {
      "verse": "5",
      "text": "In God's Law Moses says that we should throw stones at this kind of woman, to kill her. What do you say about this? ’"
    },
    {
      "verse": "6",
      "text": "They asked this question for a reason. They wanted Jesus to say something wrong, so that they could punish him. But Jesus bent himself down. He started to write on the ground with his finger."
    },
    {
      "verse": "7",
      "text": "The Pharisees and the teachers of God's Law continued to ask Jesus questions. So he stood up and he said to them, ‘Any person among you who is not guilty of any sin may throw the first stone to kill her. ’"
    },
    {
      "verse": "8",
      "text": "Then he bent himself down again and he wrote on the ground."
    },
    {
      "verse": "9",
      "text": "When they heard what Jesus said, the people began to go away. They went one by one. The older people went first. After some time, only Jesus remained with the woman. She was still standing there."
    },
    {
      "verse": "10",
      "text": "Jesus stood up. He said to her, ‘Woman, where are they? Is there nobody still here who wants to punish you? ’"
    },
    {
      "verse": "11",
      "text": "She said, ‘There is nobody, sir. ’ So Jesus said, ‘I also do not want to punish you. Go away now and change the way you live. Do not do wrong things again. ’]"
    },
    {
      "verse": "12",
      "text": "Jesus spoke to the people again. He said, ‘I am the light of the world. Those people who become my disciples will never walk in the dark. No, they will have the light that gives life. ’"
    },
    {
      "verse": "13",
      "text": "The Pharisees began to argue with him. They said, ‘You are saying things about yourself. But there is nobody else to agree that these things are true. ’"
    },
    {
      "verse": "14",
      "text": "Jesus answered, ‘What I say is true. Even if I do speak about myself, my words are true. I know where I have come from. I also know where I will go. As for you, you do not know where I came from. You do not know where I will go."
    },
    {
      "verse": "15",
      "text": "You judge in the way that people think. I do not judge anyone."
    },
    {
      "verse": "16",
      "text": "But if I did judge anyone, I would decide correctly what is right. That is because I am not alone. The Father has sent me, and he is with me."
    },
    {
      "verse": "17",
      "text": "Your own Law says, “There must be two people to agree that something is true. ”"
    },
    {
      "verse": "18",
      "text": "I speak what is true about myself. The Father, who sent me, also speaks what is true about me. ’"
    },
    {
      "verse": "19",
      "text": "Then they asked him, ‘So where is your Father? ’ Jesus answered, ‘You do not know either me or my Father. If you really knew me, you would also know my Father. ’"
    },
    {
      "verse": "20",
      "text": "Jesus said all these words while he taught in the yard of the temple. He was near the place where they kept the gifts of money. But nobody took hold of him, because it was not the right time for that yet."
    },
    {
      "verse": "21",
      "text": "Jesus said to them again, ‘I will go away and you will look for me. But even when you die, God will still not have forgiven your sins. You cannot go where I will go. ’"
    },
    {
      "verse": "22",
      "text": "So the Jewish leaders said to each other, ‘Perhaps he means that he will kill himself. He says, “You cannot go where I will go. ” Perhaps that is why he says this. ’"
    },
    {
      "verse": "23",
      "text": "Jesus answered, ‘You belong to the things down here in the world. But I have come from above. You belong to this world, but I do not belong to this world."
    },
    {
      "verse": "24",
      "text": "I told you that when you die, God will not have forgiven you. You must believe that “I am who I am. ” If not, you will die and God will certainly not have forgiven you. ’"
    },
    {
      "verse": "25",
      "text": "Then the Jewish leaders asked Jesus, ‘So, who are you? ’ He answered, ‘I have told you who I am from the beginning."
    },
    {
      "verse": "26",
      "text": "I have many things I could say about you. I could show that you have done many wrong things. But the one who sent me speaks to me. I tell people only what I have heard him say to me. What he says is true. ’"
    },
    {
      "verse": "27",
      "text": "They did not understand that he was speaking to them about his Father."
    },
    {
      "verse": "28",
      "text": "So Jesus said to them, ‘You will lift up the Son of Man on a cross. Then you will know that “I am who I am”. And you will know that I do nothing by myself. I say only what the Father has taught me to say."
    },
    {
      "verse": "29",
      "text": "He who sent me is with me. I always do the things that make him happy. So he has never gone away and left me alone. ’"
    },
    {
      "verse": "30",
      "text": "Many people who heard Jesus say these things believed in him."
    },
    {
      "verse": "31",
      "text": "Then Jesus said to the Jews who now believed him, ‘Continue to obey the words that I have spoken to you. If you do that, you are really my disciples."
    },
    {
      "verse": "32",
      "text": "Then you will know what is true. And that will make you free. ’"
    },
    {
      "verse": "33",
      "text": "They answered him, ‘We are descendants of Abraham. We have never been anyone's slaves. But you say that we will become free. What do you mean? ’"
    },
    {
      "verse": "34",
      "text": "Jesus answered them, ‘I tell you this: Everyone who does wrong things is a slave to sin."
    },
    {
      "verse": "35",
      "text": "A slave does not belong to a family for ever. But a son does belong to a family for ever."
    },
    {
      "verse": "36",
      "text": "So, if the Son makes you free, you will really be free."
    },
    {
      "verse": "37",
      "text": "I know that you belong to Abraham's family. But you are looking for a way to kill me. That is because you have no place in yourselves for my words."
    },
    {
      "verse": "38",
      "text": "I speak about the things that my Father has shown me. You do the things that you have heard from your father. ’"
    },
    {
      "verse": "39",
      "text": "They answered, ‘Abraham is our father! ’ Jesus replied, ‘If you really belonged to Abraham's family, you would do the same kind of things that Abraham did. They said to Jesus, ‘God himself is our only Father, and we are his proper sons! ’"
    },
    {
      "verse": "40",
      "text": "I have told you the true message that I have heard from God. But you want to kill me. Abraham did not do anything like that!"
    },
    {
      "verse": "41",
      "text": "You do the same things that your own father does. ’They said to Jesus, ‘God himself is our only Father, and we are his proper sons! ’"
    },
    {
      "verse": "42",
      "text": "Jesus said to them, ‘If God was your Father, you would love me. I came from God and now I am here with you. I did not come on my own behalf, but God sent me."
    },
    {
      "verse": "43",
      "text": "Why do you not understand what I say? It is because you cannot really accept my message."
    },
    {
      "verse": "44",
      "text": "You belong to your father, the Devil, and you want to do the things that he wants. From the beginning, he has been someone who murders people. He refuses to accept the truth, because there is nothing true in him. When he tells lies, he is showing what he is really like. He always tells lies. He is the father of all lies."
    },
    {
      "verse": "45",
      "text": "As for me, I tell you what is true. And that is why you do not believe me."
    },
    {
      "verse": "46",
      "text": "None of you can show that I have done anything wrong. You should believe me, because I am telling you God's true message."
    },
    {
      "verse": "47",
      "text": "Someone who belongs to God accepts God's message. But you do not belong to God. That is why you do not accept his message. ’"
    },
    {
      "verse": "48",
      "text": "The Jews answered him, ‘What we say about you is right! You are from Samaria and you have a demon in you! ’"
    },
    {
      "verse": "49",
      "text": "Jesus replied, ‘There is no demon in me. I want people to know how great my Father is. But you want people to think bad things about me."
    },
    {
      "verse": "50",
      "text": "I myself do not want people to praise me. But there is someone who wants people to praise me. He is the one who decides if I am right."
    },
    {
      "verse": "51",
      "text": "I tell you this: Anyone who obeys my words will never die. ’"
    },
    {
      "verse": "52",
      "text": "The Jews said, ‘Now we know that a demon lives in you! Abraham and all the prophets died. But you say, “Anyone who obeys my words will never know death! ”"
    },
    {
      "verse": "53",
      "text": "You cannot be greater than our father Abraham, and he died! You cannot be greater than the prophets, and they all died! Who do you think that you are? ’"
    },
    {
      "verse": "54",
      "text": "Jesus replied, ‘If I myself wanted people to praise me, that would be worth nothing. But it is my Father who wants that. And you say that he is your God."
    },
    {
      "verse": "55",
      "text": "You have never known him, but I know him. I might say, “I do not know him. ” But then I would be telling a lie. So I would be like you. But I do know him, and I obey his words."
    },
    {
      "verse": "56",
      "text": "Your ancestor Abraham knew that I would come at some time. He was happy to know that he would see that time. He did see that time, and he was very happy. ’"
    },
    {
      "verse": "57",
      "text": "The Jews said, ‘You are not 50 years old yet. But you say that you have seen Abraham! ’"
    },
    {
      "verse": "58",
      "text": "Jesus said, ‘I tell you this: Before Abraham was even born, “I am”. ’"
    },
    {
      "verse": "59",
      "text": "Then they picked up stones. They wanted to throw them at him and kill him. But Jesus hid himself from them. He went away from the temple."
    }
  ],
  "9": [
    {
      "verse": "1",
      "text": "While Jesus was walking along, he saw a certain man. This man had been blind since he was born."
    },
    {
      "verse": "2",
      "text": "Jesus' disciples asked him, ‘Teacher, why was this man blind when he was born? Was it because he himself did something wrong? Or was it because his parents did something wrong? ’"
    },
    {
      "verse": "3",
      "text": "Jesus answered, ‘It was not because either this man or his parents did something wrong. It happened so that God could show his great work in this man."
    },
    {
      "verse": "4",
      "text": "While it is still day, we must continue to work. God has sent me and we must do his work. We must work now because it will be night soon. Then nobody can work."
    },
    {
      "verse": "5",
      "text": "While I am still here in the world, I am the world's light. ’"
    },
    {
      "verse": "6",
      "text": "When Jesus had finished speaking, he spat on the ground. He mixed it with dirt on the ground so that he made mud. Then he put some of the mud on the eyes of the blind man."
    },
    {
      "verse": "7",
      "text": "Jesus said to him, ‘Go and wash in the Siloam pool. ’ (The name Siloam means ‘Sent’. ) So the man went there and he washed himself. When he returned, now he could see."
    },
    {
      "verse": "8",
      "text": "People began to talk about him. Some of these people lived near him. Others had seen him when he was asking for money. They said, ‘This is the man who sat here. He asked people to give him money. Isn't that right? ’"
    },
    {
      "verse": "9",
      "text": "Some people said, ‘Yes, it is him. ’ But other people said, ‘No, it is someone who seems to be like him. ’ But the man himself said, ‘I am that man. ’"
    },
    {
      "verse": "10",
      "text": "They asked him, ‘How did your eyes now become able to see? ’"
    },
    {
      "verse": "11",
      "text": "He answered, ‘The man called Jesus made some mud. He put the mud on my eyes. Then he sent me to wash in the Siloam pool. So I went there and I washed. Then I could see. ’"
    },
    {
      "verse": "12",
      "text": "They asked him, ‘Where is this man? ’ He replied, ‘I do not know. ’"
    },
    {
      "verse": "13",
      "text": "The people brought the man who had been blind to the Pharisees."
    },
    {
      "verse": "14",
      "text": "It was a Jewish day of rest when Jesus had done this miracle. He had used mud to make the man's eyes able to see."
    },
    {
      "verse": "15",
      "text": "So the Pharisees asked the man again, ‘How did you become able to see? ’ The man replied, ‘Jesus put mud on my eyes. Then I washed, and now I can see. ’"
    },
    {
      "verse": "16",
      "text": "So some of the Pharisees said, ‘This man Jesus cannot have come from God. He does not obey the rules about our day of rest. ’ But other Pharisees said, ‘Nobody who is bad could do great things like this! ’ So they did not agree with each other."
    },
    {
      "verse": "17",
      "text": "The Pharisees spoke again to the man who had been blind. They said to him, ‘What do you yourself say about this man? It was your eyes he has now made able to see. ’ The man replied, ‘He is a prophet. ’"
    },
    {
      "verse": "18",
      "text": "The Jewish leaders still did not believe that the man had really been blind. They did not want to believe that he had now become able to see. So they told the man's parents to come to them."
    },
    {
      "verse": "19",
      "text": "They asked the parents, ‘Is this your son? You say, “When he was born, he was blind. ” But now he can see. How did this happen? ’"
    },
    {
      "verse": "20",
      "text": "The parents replied, ‘We know that this is our son. And when he was born, he was blind. We know that, too."
    },
    {
      "verse": "21",
      "text": "But we do not know how he can see now. We do not know who made his eyes able to see. Ask him. He is old enough to answer you for himself! ’"
    },
    {
      "verse": "22",
      "text": "The man's parents said these things because they were afraid of the Jewish leaders. The Jewish leaders did not want anyone to say that Jesus was the Messiah. They would not let anyone like that belong to their meeting places."
    },
    {
      "verse": "23",
      "text": "That is why the man's parents said, ‘Ask him. He is old enough. ’"
    },
    {
      "verse": "24",
      "text": "So the leaders again spoke to the man who had been blind. They said to him, ‘In front of God, promise that you will speak only true things. We know that this man Jesus does not obey God. ’"
    },
    {
      "verse": "25",
      "text": "The man replied, ‘I do not know whether he obeys God or not. But I do know one thing: I was blind and now I can see. ’"
    },
    {
      "verse": "26",
      "text": "Then they asked him, ‘What did he do to you? How did he make your eyes able to see? ’"
    },
    {
      "verse": "27",
      "text": "He answered them, ‘I have told you already and you would not listen. Why do you want to hear it again? Maybe you want to become his disciples too! ’"
    },
    {
      "verse": "28",
      "text": "Then the leaders were very angry with him. They shouted at him, ‘No, it is you! You are that man's disciple. But we are disciples of Moses."
    },
    {
      "verse": "29",
      "text": "We know that God spoke to Moses. But who is this man? We do not even know where he comes from. ’"
    },
    {
      "verse": "30",
      "text": "The man answered, ‘That is a very strange thing! You do not know where this man comes from. But he is the one who made my eyes able to see."
    },
    {
      "verse": "31",
      "text": "We know that God does not listen to people who do not obey him. But he does listen to good people who do what he wants them to do."
    },
    {
      "verse": "32",
      "text": "Nobody has ever made the eyes of a blind man able to see, if that man had been blind when he was born. Since the world began, that has never happened!"
    },
    {
      "verse": "33",
      "text": "So this man Jesus must have come from God. Unless he came from God, he could not do anything like that. ’"
    },
    {
      "verse": "34",
      "text": "The Jewish leaders answered him, ‘Since the day that you were born, you have never obeyed God's laws. You cannot teach us anything! ’ And they threw him out of the meeting place."
    },
    {
      "verse": "35",
      "text": "Jesus heard that the Jewish leaders had thrown the man out. So he went and he found the man. Jesus asked him, ‘Do you believe in the Son of Man? ’"
    },
    {
      "verse": "36",
      "text": "The man answered, ‘Sir, please tell me who he is. Then I can believe in him. ’"
    },
    {
      "verse": "37",
      "text": "Jesus said to him, ‘You have already seen him. It is me, the one who is talking to you now. ’"
    },
    {
      "verse": "38",
      "text": "Then the man said, ‘Lord, now I believe. ’ He bent down on his knees and he worshipped Jesus."
    },
    {
      "verse": "39",
      "text": "Then Jesus said, ‘I came into this world to judge people. Then people who know that they are blind will be able to see. And people who think they can see will become blind. ’"
    },
    {
      "verse": "40",
      "text": "Some of the Pharisees who were there with him heard this. They asked Jesus, ‘Do you mean that we are also blind? ’"
    },
    {
      "verse": "41",
      "text": "Jesus said to them, ‘If you were blind, God would not punish you for the wrong things you have done. But you say that you can see. You do wrong things with your eyes open, so God will punish you as guilty people. ’"
    }
  ],
  "10": [
    {
      "verse": "1",
      "text": "Jesus then said, ‘I tell you this: A shepherd keeps his sheep in a safe place with a wall round it. There is a gate into that safe place. Anyone who gets into that place by another way, not through the gate, is not the shepherd. That person is a robber. He comes to take away the sheep for himself."
    },
    {
      "verse": "2",
      "text": "But the shepherd goes in through the gate."
    },
    {
      "verse": "3",
      "text": "The person who watches the gate opens it for the shepherd. The sheep recognize the shepherd's voice. He calls each of his own sheep by their name and he leads them out."
    },
    {
      "verse": "4",
      "text": "When he has brought out all his own sheep, he goes in front of them. The sheep follow him because they know his voice."
    },
    {
      "verse": "5",
      "text": "They will not follow a stranger. They will run away from a stranger because they do not recognize his voice. ’"
    },
    {
      "verse": "6",
      "text": "Jesus told this story like a picture to teach the people. But they did not understand what he was saying to them."
    },
    {
      "verse": "7",
      "text": "So Jesus spoke again. He said, ‘I tell you this: I am like the gate for the sheep."
    },
    {
      "verse": "8",
      "text": "All other men who came before me were like robbers. But the sheep did not listen to them."
    },
    {
      "verse": "9",
      "text": "I am like the gate. Everyone who comes in through me will be safe. They will be free to come in and to go out. And they will find plenty of food."
    },
    {
      "verse": "10",
      "text": "The robber only wants to take away my sheep. He wants to kill them. He comes only to destroy them. But I have come so that they can have true life. And so that they can have everything that they need."
    },
    {
      "verse": "11",
      "text": "I am the good shepherd. The good shepherd would die so that he can save his sheep."
    },
    {
      "verse": "12",
      "text": "Another man may take care of sheep so that he gets money. But the sheep do not belong to him. A man like that is not the shepherd. If a wolf comes, a man like that runs away when he sees it. He leaves the sheep in danger. Then the wolf attacks the sheep. It causes them to run away in all directions."
    },
    {
      "verse": "13",
      "text": "That man runs away because the sheep do not belong to him. He does not think that the sheep are important."
    },
    {
      "verse": "14",
      "text": "I am the good shepherd. I know my own sheep, and they know me."
    },
    {
      "verse": "15",
      "text": "I know them in the same way that my Father knows me. And they know me in the same way that I know the Father. I will die so that I can save my sheep."
    },
    {
      "verse": "16",
      "text": "I also have other sheep, and I must bring them too. They do not belong to this group of sheep. But they also will listen to my voice. So all the sheep will become one group, and they will have one shepherd."
    },
    {
      "verse": "17",
      "text": "The Father loves me because I choose to die for my sheep. But after I give my life like that, I will become alive again."
    },
    {
      "verse": "18",
      "text": "Nobody can take my life away from me. Instead, I myself can choose to die. I have authority to do that. I also have authority to become alive again. My Father has said that I must do that. ’"
    },
    {
      "verse": "19",
      "text": "Again, the Jews could not agree about these things that Jesus said."
    },
    {
      "verse": "20",
      "text": "Many of them said, ‘He has a demon in him and he is crazy. You should not listen to him! ’"
    },
    {
      "verse": "21",
      "text": "But other people said, ‘A man with a demon in him could not teach like this! A demon could not make blind people able to see! ’"
    },
    {
      "verse": "22",
      "text": "It was the time for the Jewish Festival called Hanukkah. This happened in Jerusalem. It was winter."
    },
    {
      "verse": "23",
      "text": "Jesus was walking in the yard of the temple, under a place with a roof. The place was called Solomon's porch."
    },
    {
      "verse": "24",
      "text": "The Jewish leaders stood around him. They said to him, ‘We want to know who you are. When will you tell us? If you are the Messiah, tell us clearly. ’"
    },
    {
      "verse": "25",
      "text": "Jesus answered, ‘I have already told you, but you do not believe. The things that I do by my Father's authority show you who I am."
    },
    {
      "verse": "26",
      "text": "But you refuse to believe, because you are not my sheep."
    },
    {
      "verse": "27",
      "text": "My sheep recognize my voice. I know them and they follow me."
    },
    {
      "verse": "28",
      "text": "I give them life for ever with God. They will never die. Nobody can ever take them away from me."
    },
    {
      "verse": "29",
      "text": "My Father has given them to me. He is greater than all things. Nobody can ever take my sheep out of my Father's hand."
    },
    {
      "verse": "30",
      "text": "My Father and I are one. ’"
    },
    {
      "verse": "31",
      "text": "Then the Jewish leaders picked up stones again to throw at Jesus so that they could kill him."
    },
    {
      "verse": "32",
      "text": "Jesus said to them, ‘I have done many good things. The Father sent me to do them, and I have shown them to you. Which of those good things make you want to kill me with stones? ’"
    },
    {
      "verse": "33",
      "text": "The Jewish leaders answered, ‘We do not want to kill you because of any good things that you have done. We want to kill you because you are speaking against God. You are only a man, but you are saying that you are God. ’"
    },
    {
      "verse": "34",
      "text": "Jesus answered them, ‘It is written in your own books of God's Law that God said, “You are gods. ”"
    },
    {
      "verse": "35",
      "text": "God called the people to whom he spoke “gods”. And you know that the Bible always remains true."
    },
    {
      "verse": "36",
      "text": "So, when I said that I am God's Son, why am I wrong? The Father chose me for himself. And he sent me into the world. So you should not say that I am speaking bad things against God."
    },
    {
      "verse": "37",
      "text": "If I am not doing my Father's work, do not believe me."
    },
    {
      "verse": "38",
      "text": "But if I am doing his work, you should believe that work. Even if you do not believe me, you should believe the things that I do. Then you will know certainly that the Father is in me. And you will know that I am in the Father. ’"
    },
    {
      "verse": "39",
      "text": "Again, the Jewish leaders tried to take hold of Jesus. But he escaped from them."
    },
    {
      "verse": "40",
      "text": "After that, Jesus returned across the Jordan River. He went to the place where John had earlier baptized people. Jesus stayed there."
    },
    {
      "verse": "41",
      "text": "Many people came to him. They said to each other, ‘John did not do any miracles. But everything that he said about this man was true. ’"
    },
    {
      "verse": "42",
      "text": "So, in that place, many people believed in Jesus."
    }
  ],
  "11": [
    {
      "verse": "1",
      "text": "There was a certain man, who was called Lazarus. He lived at Bethany, the village where Mary and her sister Martha lived too. He became ill."
    },
    {
      "verse": "2",
      "text": "It was this Mary who had poured oil with a nice smell over the feet of the Lord Jesus. Then she had cleaned his feet with her hair. It was her brother Lazarus who was ill."
    },
    {
      "verse": "3",
      "text": "So the two sisters sent a message to Jesus to say, ‘Lord, the friend that you love is ill. ’"
    },
    {
      "verse": "4",
      "text": "Jesus heard the message. Then he said, ‘This illness will not finish with Lazarus's death. No, its purpose is to show how great God is. Because of this, people will see how great God's Son is. ’"
    },
    {
      "verse": "5",
      "text": "Jesus loved Martha and her sister, and their brother Lazarus, too."
    },
    {
      "verse": "6",
      "text": "He heard the news that Lazarus was ill. But then he stayed in the place where he was for two more days."
    },
    {
      "verse": "7",
      "text": "After that, Jesus said to his disciples, ‘We should return to Judea. ’"
    },
    {
      "verse": "8",
      "text": "The disciples said, ‘Teacher, only a short time ago, the Jews there tried to kill you with stones. You should not return there! ’"
    },
    {
      "verse": "9",
      "text": "Jesus answered, ‘You know that there are 12 hours in the day. Anyone who walks during the day will not fall down. He will not fall down because he sees this world's light."
    },
    {
      "verse": "10",
      "text": "But anyone who walks during the night will fall down. He will fall down because he has no light. ’"
    },
    {
      "verse": "11",
      "text": "After Jesus said that, he said to them, ‘Our friend Lazarus is sleeping. But I will go there to wake him up. ’"
    },
    {
      "verse": "12",
      "text": "So the disciples said to him, ‘If he is sleeping, Lord, he will get well again. ’"
    },
    {
      "verse": "13",
      "text": "The disciples thought that Jesus was talking about sleep as rest. But Jesus meant that Lazarus had died."
    },
    {
      "verse": "14",
      "text": "So then, Jesus told them clearly, ‘Lazarus is dead."
    },
    {
      "verse": "15",
      "text": "But I am happy that I was not there with him. I am happy about that because it will help you. Now you will believe in me. We must go to him now. ’"
    },
    {
      "verse": "16",
      "text": "Thomas, who was called Didymus, said to the other disciples, ‘We should go with our Teacher, so that we can die with him! ’"
    },
    {
      "verse": "17",
      "text": "Jesus arrived at Bethany. He discovered that Lazarus had already been in the grave for four days."
    },
    {
      "verse": "18",
      "text": "kilometres from Jerusalem."
    },
    {
      "verse": "19",
      "text": "Many Jews had come there to visit Martha and Mary. They wanted to help Martha and Mary because their brother had died."
    },
    {
      "verse": "20",
      "text": "Martha heard the news that Jesus was coming. So she went out to meet him. But Mary stayed in the house with the visitors."
    },
    {
      "verse": "21",
      "text": "Martha said to Jesus, ‘Lord, if you had been here, my brother would not have died."
    },
    {
      "verse": "22",
      "text": "But even now, I know that God will answer you. He will do whatever you ask him. ’"
    },
    {
      "verse": "23",
      "text": "Jesus told her, ‘Your brother will rise and become alive again. ’"
    },
    {
      "verse": "24",
      "text": "Martha replied, ‘I know that he will rise on the last day, to become alive again. ’"
    },
    {
      "verse": "25",
      "text": "Jesus said to her, ‘I have authority over death. I raise dead people, and I give people true life. Anyone who believes in me will live. Even if that person dies, he will continue to live."
    },
    {
      "verse": "26",
      "text": "People who believe in me while they are alive will never die. Do you believe that? ’"
    },
    {
      "verse": "27",
      "text": "Martha answered, ‘Yes, Lord, I believe that you are the Messiah. You are God's Son, the one that God promised to send into the world. ’"
    },
    {
      "verse": "28",
      "text": "After this, Martha went back to the house. She took Mary to speak to her on her own. Martha said to her, ‘The Teacher is here, and he is asking to meet you. ’"
    },
    {
      "verse": "29",
      "text": "When Mary heard this, she got up immediately. She went out to meet Jesus."
    },
    {
      "verse": "30",
      "text": "Jesus had not arrived in the village yet. He was still in the place where Martha had met him."
    },
    {
      "verse": "31",
      "text": "There were still Jews in the house who were with Mary to help her. They saw her get up quickly and go out. So they followed her. They thought that she was going to the place where they had put Lazarus's dead body. They thought that she wanted to go there to weep."
    },
    {
      "verse": "32",
      "text": "Mary arrived at the place where Jesus was. When she saw Jesus, she bent down low at his feet. She said, ‘Lord, if you had been here, my brother would not have died. ’"
    },
    {
      "verse": "33",
      "text": "Jesus saw that Mary was weeping. He saw that the Jews who had come with her were weeping too. When Jesus saw them, he felt very sad in his spirit. He was upset about Lazarus's death."
    },
    {
      "verse": "34",
      "text": "He asked them, ‘Where have you put his dead body? ’ They answered, ‘Come and see, Lord. ’"
    },
    {
      "verse": "35",
      "text": "Jesus wept."
    },
    {
      "verse": "36",
      "text": "Then the Jews said to each other, ‘See how much he loved Lazarus! ’"
    },
    {
      "verse": "37",
      "text": "But some of them said, ‘He opened the eyes of the blind man. So surely he would have been able to stop the death of Lazarus. ’"
    },
    {
      "verse": "38",
      "text": "Jesus arrived at the grave where they had put Lazarus's dead body. It was a cave. A large stone covered the front of the hole. Again, Jesus felt very upset."
    },
    {
      "verse": "39",
      "text": "He said, ‘Take the stone away. ’ Martha, the dead man's sister, said to Jesus, ‘But Lord, by now his dead body will have a bad smell. He has been dead for four days! ’"
    },
    {
      "verse": "40",
      "text": "Jesus said to her, ‘I told you already that you must believe in me. Then you will see how great and how powerful God is. ’"
    },
    {
      "verse": "41",
      "text": "So they moved the stone away. Jesus looked up towards the sky. He said, ‘Father, I thank you that you have listened to me."
    },
    {
      "verse": "42",
      "text": "I know that you listen to me always. But I said this to help all the people who are standing here. I want them to believe that you sent me. ’"
    },
    {
      "verse": "43",
      "text": "When Jesus had said this, he shouted with a loud voice, ‘Lazarus, come out! ’"
    },
    {
      "verse": "44",
      "text": "The dead man came out. There were pieces of cloth round his hands and round his feet. Another piece of cloth was round his face. Jesus said to them, ‘Undo the cloths and let him go. ’"
    },
    {
      "verse": "45",
      "text": "The Jews who had come to visit Mary saw this. They saw what Jesus did. So many of them believed in him."
    },
    {
      "verse": "46",
      "text": "But some of them went to the Pharisees. They told the Pharisees what Jesus had done."
    },
    {
      "verse": "47",
      "text": "Then the Pharisees and the leaders of the priests had a meeting with the group of Jewish leaders. They asked each other, ‘What will we do? This man is doing so many miracles."
    },
    {
      "verse": "48",
      "text": "If we let him do more things like this, everyone will believe in him. Then the Roman rulers will come and punish us. Their soldiers will destroy our temple and even destroy our whole country of Israel. ’"
    },
    {
      "verse": "49",
      "text": "One of the group was the leader of the priests that year. He was called Caiaphas. He said, ‘You do not understand the problem."
    },
    {
      "verse": "50",
      "text": "It is better that one man should die on behalf of our people. That is better than if all Israel's people should die. ’"
    },
    {
      "verse": "51",
      "text": "Caiaphas did not say this because he had thought it by himself. No, he was speaking as a prophet, because he was the leader of the priests that year. That is why he said that Jesus would die on behalf of Israel's people."
    },
    {
      "verse": "52",
      "text": "And Jesus would die not only for Israel's people. He would also die for all God's people who lived in many different places. He would bring them all together. They would become like one big family."
    },
    {
      "verse": "53",
      "text": "From that day, the Jewish leaders decided together how they could kill Jesus."
    },
    {
      "verse": "54",
      "text": "So Jesus stopped travelling about in Judea where everyone could see him. Instead, he went away from there to a town called Ephraim that was near to the wilderness. He stayed there with his disciples."
    },
    {
      "verse": "55",
      "text": "It was almost time for the Jewish Passover Festival to begin. Many people were going from their country places to Jerusalem. They were going there to make themselves clean in front of God before they went to the festival."
    },
    {
      "verse": "56",
      "text": "They were continuing to look for Jesus. While they stood in the yard of the temple, they spoke to each other about him. They asked each other, ‘Do you think that he will come to the festival or not? ’"
    },
    {
      "verse": "57",
      "text": "The leaders of the priests and the Pharisees had spoken to the people about Jesus. They had told them, ‘If anyone knows where Jesus is, you must tell us. ’ So then they could take hold of him to put him in a prison."
    }
  ],
  "12": [
    {
      "verse": "1",
      "text": "Six days before the Passover festival, Jesus went to Bethany, the village where Lazarus lived. He was the man who had been dead, but Jesus had raised him."
    },
    {
      "verse": "2",
      "text": "Some friends prepared a special meal there for Jesus. Martha gave out the food, and Lazarus sat among the visitors, with Jesus."
    },
    {
      "verse": "3",
      "text": "Then Mary brought a pound of very expensive oil that had a very nice smell. They used nard to make it. She poured it over Jesus' feet and then she made his feet dry again with her hair. The nice smell of the oil filled the whole house."
    },
    {
      "verse": "4",
      "text": "Judas Iscariot, one of Jesus' disciples, was there. He was the man who would sell Jesus to Jesus' enemies."
    },
    {
      "verse": "5",
      "text": "Judas said, ‘We could have sold this oil for 300 coins. That is as much money as someone would get for a year's work. Then we could have given that money to poor people. ’"
    },
    {
      "verse": "6",
      "text": "He did not say this because he really wanted to help the poor people. No, he said it because he wanted the money himself. He kept the bag of money and sometimes he took money from it for himself."
    },
    {
      "verse": "7",
      "text": "But Jesus said, ‘Do not stop her! She has kept this oil safe until now. She wanted it for the day when they will bury my dead body."
    },
    {
      "verse": "8",
      "text": "You will always have poor people with you. But you will not always have me with you. ’"
    },
    {
      "verse": "9",
      "text": "By this time, a large crowd of Jews had heard the news that Jesus was at Bethany. So they came there to see him. They came also to see Lazarus, because Jesus had made him alive again."
    },
    {
      "verse": "10",
      "text": "So the leaders of the priests decided to kill not only Jesus, but Lazarus too."
    },
    {
      "verse": "11",
      "text": "They wanted to do that because many Jews now refused to obey them. Instead, these Jews believed in Jesus because of what he had done for Lazarus."
    },
    {
      "verse": "12",
      "text": "The next day, a large crowd of people were in Jerusalem for the festival. They heard the news that Jesus was on the way there."
    },
    {
      "verse": "13",
      "text": "So they took branches from palm trees and they went out to meet Jesus. They were shouting, ‘We praise God! May the Lord God bless the king who comes with his authority. May he bless the king of Israel! ’"
    },
    {
      "verse": "14",
      "text": "Jesus found a young donkey, and he sat on it. This happened in the way that was written in the Bible long ago:"
    },
    {
      "verse": "15",
      "text": "‘Do not be afraid, you people in Zion. Look! Your king is coming. He is riding on a young donkey. ’ Look! Your king is coming. He is riding on a young donkey. ’"
    },
    {
      "verse": "16",
      "text": "Jesus' disciples did not understand all this at that time. They understood only after Jesus had returned to God in heaven. Then they remembered that someone had written these things about him in the Bible. And they remembered that these things had now really happened to him."
    },
    {
      "verse": "17",
      "text": "The crowd that had been with Jesus before at Bethany continued to tell people about Lazarus. They said, ‘Jesus told Lazarus that he should come out of the hole in the rock. He made Lazarus alive again after he had died and his body had been put in there. ’"
    },
    {
      "verse": "18",
      "text": "That is why many people came to meet Jesus. They had heard that he had done this miracle."
    },
    {
      "verse": "19",
      "text": "So the Pharisees said to each other, ‘This is not what we wanted. Look! All the people in the world have left us to go with him! ’"
    },
    {
      "verse": "20",
      "text": "There were some Greek people among the people at the festival. They also had come to worship God."
    },
    {
      "verse": "21",
      "text": "These Greek people came to Philip, who was from a town in Galilee called Bethsaida. They said to him, ‘Please sir, we want to meet Jesus. ’"
    },
    {
      "verse": "22",
      "text": "Philip went and he told Andrew this. Then Philip and Andrew went to Jesus and they told him."
    },
    {
      "verse": "23",
      "text": "Jesus said to them, ‘God will show how great the Son of Man is. It is now time for that to happen."
    },
    {
      "verse": "24",
      "text": "I tell you this: A seed of wheat continues to be only a single seed unless it falls into the ground. It must fall into the ground and then it must die. If it dies like that, it will grow to give a lot of seeds."
    },
    {
      "verse": "25",
      "text": "Anyone who loves his own life will lose it. But anyone who hates his life in this world will have true life for ever with God."
    },
    {
      "verse": "26",
      "text": "Anyone who wants to be my servant must follow me. Then he will be with me, where I am. My Father will praise anyone who is my servant."
    },
    {
      "verse": "27",
      "text": "Now I have trouble in my mind. What will I say? I might say, “Father, save me from this time of trouble! ” But this difficult time is the purpose for which I came to the world."
    },
    {
      "verse": "28",
      "text": "So I will say, “Father, show how great and how good you are. ” ’Then a voice spoke from heaven and said, ‘I have shown how great and how good I am. And I will do it again. ’"
    },
    {
      "verse": "29",
      "text": "The crowd of people who were standing there heard the sound of this voice. They said that it was like the noise of thunder in a storm. But other people said, ‘An angel spoke to him! ’"
    },
    {
      "verse": "30",
      "text": "Jesus said, ‘When this voice spoke, it was not so that it could help me. No, it spoke so that it could help you."
    },
    {
      "verse": "31",
      "text": "It is time now for God to judge the people in this world. Now he will throw out the ruler of this world."
    },
    {
      "verse": "32",
      "text": "But when people lift me up from the ground, then I will bring everyone to myself. ’"
    },
    {
      "verse": "33",
      "text": "Jesus said this to show in what way he would soon die."
    },
    {
      "verse": "34",
      "text": "The crowd said, ‘The Bible tells us that the Messiah will continue for ever. So why do you say, “People must lift up the Son of Man”? Who is this Son of Man? ’"
    },
    {
      "verse": "35",
      "text": "Jesus answered, ‘The light will be with you for only a short time longer. So continue to walk while you still have the light. Do that, so that the dark will not come over you. Anyone who walks in the dark does not know where they are going."
    },
    {
      "verse": "36",
      "text": "While you still have the light with you, believe in that light. So then you will become children of light. ’ When Jesus had said this, he went away. He hid himself from them."
    },
    {
      "verse": "37",
      "text": "Jesus had done many miracles that the people themselves had seen. But even then, they still did not believe in him. ‘Lord, has anyone believed our message? You have shown how powerful you are, but nobody has really understood. ’"
    },
    {
      "verse": "38",
      "text": "This showed that the prophet Isaiah had spoken true words when he said:‘Lord, has anyone believed our message? You have shown how powerful you are, but nobody has really understood. ’"
    },
    {
      "verse": "39",
      "text": "Isaiah spoke also about why the people could not believe. ‘God has made their eyes unable to see. He has closed their minds. So they cannot see with their eyes, and they cannot understand with their minds. They will not turn to me, so that I can make them well. ’"
    },
    {
      "verse": "40",
      "text": "He said:‘God has made their eyes unable to see. He has closed their minds. So they cannot see with their eyes, and they cannot understand with their minds. They will not turn to me, so that I can make them well. ’"
    },
    {
      "verse": "41",
      "text": "Long ago, Isaiah saw the great glory of Christ. That is why he said these things. He was speaking about Jesus."
    },
    {
      "verse": "42",
      "text": "But even at that time, many of the Jewish leaders did believe in Jesus. But they were afraid of the Pharisees. So they did not tell people that they believed. They were afraid that the Pharisees would send them away from their meeting places."
    },
    {
      "verse": "43",
      "text": "The Pharisees wanted other people to praise them, more than they wanted God to praise them."
    },
    {
      "verse": "44",
      "text": "Jesus said in a loud voice, ‘Anyone who believes in me does not believe only in me. That person believes also in the one who sent me."
    },
    {
      "verse": "45",
      "text": "Anyone who looks at me does not see only me. They see also him who sent me."
    },
    {
      "verse": "46",
      "text": "I have come into the world to be a light for people. Everyone who believes in me will not remain in the dark. That is why I came."
    },
    {
      "verse": "47",
      "text": "Not everyone who hears my words will obey them. I will not judge anyone who is like that. I did not come to judge the people in the world. I came to save them."
    },
    {
      "verse": "48",
      "text": "But there is something that will judge people who refuse to believe in me. Those are people who do not accept my message. The message that I have spoken will itself judge people like that on the last day."
    },
    {
      "verse": "49",
      "text": "The words that I have spoken did not come from me myself. They came from the Father, who sent me. He told me what message I must speak. He told me the words I must say."
    },
    {
      "verse": "50",
      "text": "The message that the Father has given me causes people to have life for ever. I know that. So I speak only those things that the Father has said to me. ’"
    }
  ],
  "13": [
    {
      "verse": "1",
      "text": "It was nearly time for the Passover Festival. Jesus knew that he would soon leave this world and to go to the Father. He had always loved those who were his own people in the world. He continued to love them to the end."
    },
    {
      "verse": "2",
      "text": "Jesus and his disciples were eating supper. The Devil had already put an idea into the mind of Judas Iscariot, Simon's son. The idea was to sell Jesus to his enemies."
    },
    {
      "verse": "3",
      "text": "Jesus knew that the Father had given him power over everything. He knew that he had come from God. And he knew that he would soon return to God."
    },
    {
      "verse": "4",
      "text": "So, during the meal, he stood up. He took off the coat that he wore over his other clothes. He tied a piece of cloth round himself."
    },
    {
      "verse": "5",
      "text": "Then he poured water into a bowl and he began to wash the disciples' feet. Jesus made their feet dry with the cloth that was round him."
    },
    {
      "verse": "6",
      "text": "Jesus came to Simon Peter. Peter asked him, ‘Lord, will you really wash my feet? ’"
    },
    {
      "verse": "7",
      "text": "Jesus answered him, ‘You do not understand now what I am doing. But you will understand in the future. ’"
    },
    {
      "verse": "8",
      "text": "Peter said, ‘No! You will never wash my feet! ’ Jesus answered, ‘If I do not wash you, you do not belong with me. ’"
    },
    {
      "verse": "9",
      "text": "Simon Peter replied, ‘So Lord, do not wash my feet only! Wash my hands and my head too! ’"
    },
    {
      "verse": "10",
      "text": "Jesus said, ‘A person who has washed his whole body is completely clean. He needs only to wash his feet. And all of you are clean, except one of you. ’"
    },
    {
      "verse": "11",
      "text": "Jesus knew already who would sell him to his enemies. That is why he said, ‘Not every one of you is clean. ’"
    },
    {
      "verse": "12",
      "text": "When he had finished washing the disciples' feet, Jesus put on his coat. He returned to his place at the meal. He asked them, ‘I want you to understand what I have just done for you."
    },
    {
      "verse": "13",
      "text": "You call me Teacher and Lord, and you are right. That is what I am."
    },
    {
      "verse": "14",
      "text": "I am your Teacher and your Lord, but I have washed your feet. So you also should wash each other's feet."
    },
    {
      "verse": "15",
      "text": "I have given you an example. You should do the same for others as I have done for you."
    },
    {
      "verse": "16",
      "text": "I tell you this: No servant is more important than his master is. No messenger is more important than the person who sent him with a message."
    },
    {
      "verse": "17",
      "text": "Now you understand these things. So you should do them, and God will bless you. ’"
    },
    {
      "verse": "18",
      "text": "Jesus then said, ‘I am not talking about all of you. I know the people that I have chosen. The Bible says, “Someone who ate food with me has turned against me. ”"
    },
    {
      "verse": "19",
      "text": "I am telling you this now, before it happens. So then, when it does happen, you will believe me. You will believe that “I am who I am”."
    },
    {
      "verse": "20",
      "text": "I tell you this: Anyone who accepts someone that I send to them is also accepting me. Anyone who accepts me is also accepting my Father God who sent me. ’"
    },
    {
      "verse": "21",
      "text": "After Jesus had said this, he felt very upset. He said to the disciples very seriously, ‘I tell you this: One of you will help my enemies to take hold of me. ’"
    },
    {
      "verse": "22",
      "text": "The disciples looked at each other. They did not know which of them Jesus was speaking about."
    },
    {
      "verse": "23",
      "text": "The disciple that Jesus loved was sitting very near to Jesus."
    },
    {
      "verse": "24",
      "text": "Simon Peter looked towards that disciple and said to him, ‘Ask Jesus who he is speaking about. ’"
    },
    {
      "verse": "25",
      "text": "So that disciple moved even nearer to Jesus and he asked, ‘Who is it, Lord? ’"
    },
    {
      "verse": "26",
      "text": "Jesus answered, ‘I will put a piece of bread in the dish of food. Then I will give the bread to him. That is the man. ’ So he put a piece of bread in the dish. Then he gave it to Judas, the son of Simon Iscariot."
    },
    {
      "verse": "27",
      "text": "When Judas had taken the bread, Satan came into him. Then Jesus said to Judas, ‘Do quickly what you want to do. ’"
    },
    {
      "verse": "28",
      "text": "None of the other disciples who were sitting at the meal understood this. They did not know why Jesus said this to Judas."
    },
    {
      "verse": "29",
      "text": "Judas kept the bag of money on behalf of the group of disciples. So some of them thought that Jesus had asked Judas to buy some things. Maybe he should buy what they needed for the festival. Or maybe he should go and give some money to the poor people."
    },
    {
      "verse": "30",
      "text": "Judas took the bread and he ate it. Then he went out immediately. By now it was night."
    },
    {
      "verse": "31",
      "text": "When Judas had left, Jesus said, ‘Now people will see how great the Son of Man is. Because of him, they will also see how great God is."
    },
    {
      "verse": "32",
      "text": "The Son will show how great God is. Then God will take the Son to himself and he will show how great the Son is. He will do that very soon."
    },
    {
      "verse": "33",
      "text": "My children, I will be with you for only a short time now. You will look for me. But I tell you now what I told the Jews. You cannot go where I am now going."
    },
    {
      "verse": "34",
      "text": "I give a new rule to you. Love each other. You must love each other as I have loved you."
    },
    {
      "verse": "35",
      "text": "In this way, everyone will know that you are my disciples. They will know it, if you really love each other. ’"
    },
    {
      "verse": "36",
      "text": "Simon Peter asked him, ‘Lord, where will you go? ’ Jesus replied, ‘You cannot follow now where I will go. But some time after this, you will follow. ’"
    },
    {
      "verse": "37",
      "text": "Peter said, ‘Lord, why can I not go with you now? I would even die for you. ’"
    },
    {
      "verse": "38",
      "text": "Jesus answered, ‘You say that you would die for me. But I tell you this: Soon you will say that you do not know me. Before the cockerel sings early tomorrow morning, you will say that three times. ’"
    }
  ],
  "14": [
    {
      "verse": "1",
      "text": "Jesus said to his disciples, ‘Do not be sad or afraid. Believe in God, and also believe in me."
    },
    {
      "verse": "2",
      "text": "There are many rooms in my Father's house. I will go now so that I can prepare a place for you there. If it was not true, I would not have told you this."
    },
    {
      "verse": "3",
      "text": "After I have prepared a place for you, I will return. Then I will take you so that you will be with me. You will be where I am."
    },
    {
      "verse": "4",
      "text": "You know the way to the place where I will go. ’"
    },
    {
      "verse": "5",
      "text": "Thomas said to him, ‘Lord, we do not know where you will go. So how can we know the way to get there? ’"
    },
    {
      "verse": "6",
      "text": "Jesus answered, ‘I am the way. I am the truth. I am the life. Nobody comes to the Father except by me."
    },
    {
      "verse": "7",
      "text": "If you really know me, you will also know my Father. From now on, you do know him and you have seen him. ’"
    },
    {
      "verse": "8",
      "text": "Philip said, ‘Lord, show the Father to us. That is all that we need. ’"
    },
    {
      "verse": "9",
      "text": "Jesus answered, ‘I have been with all of you for a long time. But still you do not seem to know me, Philip! Anyone who has seen me has seen the Father. So why do you say, “Show the Father to us”?"
    },
    {
      "verse": "10",
      "text": "I am in the Father and the Father is in me. You should believe that. The words that I say to you do not come from me myself. But the Father lives in me, and he is doing his work."
    },
    {
      "verse": "11",
      "text": "I am in the Father and the Father is in me. Believe me when I say that. You have seen the things that I have done. So, if you do not believe my words, believe because of my work."
    },
    {
      "verse": "12",
      "text": "I tell you this: Whoever believes in me will do the same things that I have been doing. Yes, he will do even greater things than these, because I will go to my Father."
    },
    {
      "verse": "13",
      "text": "Ask me to help you. If you ask anything in my name, I will do it for you. In that way, the Son will show everyone how great the Father is."
    },
    {
      "verse": "14",
      "text": "Yes, you should ask me for anything in my name. I will do it for you. ’"
    },
    {
      "verse": "15",
      "text": "Jesus then said, ‘If you love me, do what I have told you to do."
    },
    {
      "verse": "16",
      "text": "I will ask the Father to help you with this. He will send another Helper to be with you. That Helper will stay with you for ever."
    },
    {
      "verse": "17",
      "text": "He is God's Spirit and he shows you what is true. The people who belong to this world cannot receive him. That is because they cannot see him. They cannot know who he is. But you know him because he stays with you. And he will be in you."
    },
    {
      "verse": "18",
      "text": "I will not let you remain alone, like children without parents. I will come to you."
    },
    {
      "verse": "19",
      "text": "Soon, the people who belong to this world will not see me any more. But you will see me. Because I continue to live, you also will live."
    },
    {
      "verse": "20",
      "text": "On that day, you will know that I am in my Father. You will know that you are in me and I am in you."
    },
    {
      "verse": "21",
      "text": "Those people who obey my commands are the ones who really love me. They accept my words and they do what I say. My Father will love everyone who loves me. I also will love them and I will show myself to them. ’"
    },
    {
      "verse": "22",
      "text": "Then Judas (not Judas Iscariot) said, ‘Lord, why will you show yourself only to us? Why will you not show yourself also to the people who belong to this world? ’"
    },
    {
      "verse": "23",
      "text": "Jesus replied, ‘Everyone who loves me will obey my teaching. My Father will love them. And my Father and I will come to them and we will make our home with them."
    },
    {
      "verse": "24",
      "text": "Anyone who does not love me will not obey my message. These words that you hear are not my own. No, they come from the Father, who sent me."
    },
    {
      "verse": "25",
      "text": "I have said these things to you while I am still with you."
    },
    {
      "verse": "26",
      "text": "But the Father will send the Holy Spirit to be with you. He will be your Helper. He will come in my name, and he will teach you all things. He will help you to remember everything that I have told you."
    },
    {
      "verse": "27",
      "text": "I will go away but I will give you a gift of peace. It is mine to give and yours to keep. It is not like a gift that this world gives. Do not let yourselves be sad. Do not be afraid."
    },
    {
      "verse": "28",
      "text": "You heard me say to you, “I will go away, but I will return to you. ” If you loved me, you would be happy because of that. You would be happy because I will go to the Father. And he is greater than I am."
    },
    {
      "verse": "29",
      "text": "I have told you this now, before it happens. So then, when it does happen, you will believe."
    },
    {
      "verse": "30",
      "text": "I will not talk with you much more, because the ruler of this world will come soon. He has no power over me."
    },
    {
      "verse": "31",
      "text": "But the people who belong to this world must learn about me. They must know that I love the Father. I do everything that he tells me to do. I must show that to them. Now get up, we must go from here. ’"
    }
  ],
  "15": [
    {
      "verse": "1",
      "text": "Jesus said, ‘I am the true vine, and my Father is the gardener."
    },
    {
      "verse": "2",
      "text": "Some branches that are part of me may have no fruit on them. My Father completely removes all those branches. But other branches do have fruit. My Father cuts all those branches to make them better. Then they will be good and make more fruit."
    },
    {
      "verse": "3",
      "text": "The words that I have spoken to you have made you good already."
    },
    {
      "verse": "4",
      "text": "Continue to live in me, and I will continue to live in you. A branch cannot make fruit by itself. It can make fruit only if it continues to be part of the vine. You are like that. You cannot make fruit unless you continue to live in me."
    },
    {
      "verse": "5",
      "text": "I am the vine, and you are the branches. You must continue to live in me and I must continue to live in you. Only if you do that will you make plenty of fruit. That is because you can do nothing without me."
    },
    {
      "verse": "6",
      "text": "If anyone does not remain in me, that person is like a dead branch. The gardener will throw that branch away and it will die. People throw all those dead branches into the fire so that they burn."
    },
    {
      "verse": "7",
      "text": "You must remain in me, and my teaching must remain in you. Then you may ask for anything that you want. God will do it for you."
    },
    {
      "verse": "8",
      "text": "If you make plenty of fruit, that will give honour to my Father. You will show that you are truly my disciples."
    },
    {
      "verse": "9",
      "text": "I have loved you in the same way that the Father has loved me. Continue to live in a way that shows my love."
    },
    {
      "verse": "10",
      "text": "If you obey what I have told you, you will be living in my love. In the same way, I have obeyed what my Father has told me to do. In that way, I live in his love."
    },
    {
      "verse": "11",
      "text": "I want you to be completely happy, in the same way that I myself am happy. That is why I have told you these things."
    },
    {
      "verse": "12",
      "text": "This is the rule that I give to you: You must love each other, in the same way that I have loved you."
    },
    {
      "verse": "13",
      "text": "A person really loves his friends if he dies so that they can live. Nobody could love anyone more than that."
    },
    {
      "verse": "14",
      "text": "And you are my friends, if you obey my message."
    },
    {
      "verse": "15",
      "text": "A servant does not know what his master is doing. So I do not call you servants any more. No, I call you my friends. This is because I have told you everything that I have heard from my Father."
    },
    {
      "verse": "16",
      "text": "You did not choose me, but I chose you. I chose you to go and to make plenty of fruit. That kind of fruit will continue always. For that reason, the Father will help you with anything that you ask him. If you ask him in my name, he will do it for you."
    },
    {
      "verse": "17",
      "text": "This is what I tell you to do: You must love each other. ’"
    },
    {
      "verse": "18",
      "text": "‘The people who belong to this world may hate you. But remember this: They hated me before they hated you."
    },
    {
      "verse": "19",
      "text": "If you belonged to this world, this world's people would love you. They would love you because you would belong with them. But I chose you so that you would be separate from this world's people. You do not belong with them, so they hate you."
    },
    {
      "verse": "20",
      "text": "Remember what I told you: “No servant is more important than his master is. ” If they have caused trouble for me, they will also cause trouble for you. But if they have obeyed my message, they will also obey your message."
    },
    {
      "verse": "21",
      "text": "They will do all these things to you because you belong to me. They will do them because they do not know the one who sent me."
    },
    {
      "verse": "22",
      "text": "I have come and I have spoken my message to them. If I had not done that, they would not have been guilty of their sin. But now they cannot say, “We have not done anything wrong. ”"
    },
    {
      "verse": "23",
      "text": "Anyone who hates me also hates my Father."
    },
    {
      "verse": "24",
      "text": "When I was with them, I did many great things. Nobody else ever did things like that. If I had not done those great things among them, they would not have known what is wrong. But they have seen what I did. As a result, they have hated me, and they have hated my Father too."
    },
    {
      "verse": "25",
      "text": "Their book of God's Law says, “They hated me without any good reason. ” What that book already said long ago had to happen."
    },
    {
      "verse": "26",
      "text": "When I return to my Father, I will send the Helper to you. The Helper is God's Spirit who speaks only true things. He comes to you from the Father. I will send him to you and he will speak true things about me."
    },
    {
      "verse": "27",
      "text": "You also must speak to people about me, because you have been with me from the beginning. ’"
    }
  ],
  "16": [
    {
      "verse": "1",
      "text": "Jesus then said, ‘I have told you all these things, so that you will not turn away from God."
    },
    {
      "verse": "2",
      "text": "People will send you away from their meeting places. There will be a time when people will want to kill you. When they do this, they will even think that they are doing what God wants."
    },
    {
      "verse": "3",
      "text": "They will do these things to you because they have never known either the Father or me."
    },
    {
      "verse": "4",
      "text": "But I have told you this so that you will remember. When they begin to do these things, you will remember that I told you about them already. ’‘I did not tell you these things at the beginning, because I was with you."
    },
    {
      "verse": "5",
      "text": "But now I will go to the Father who sent me. But none of you asks me, “Where will you go? ”"
    },
    {
      "verse": "6",
      "text": "And now you are very sad, because I have told you these things."
    },
    {
      "verse": "7",
      "text": "But what I tell you is true. It will be better for you if I go away. Because, if I do not go away, the Helper will not come to you. But if I do go away, I will send him to you."
    },
    {
      "verse": "8",
      "text": "When he comes, he will show the people of this world what they are like. He will show clearly that they are wrong. They are wrong about what sin really is. They are wrong about who is right with God. They are wrong about how God judges people."
    },
    {
      "verse": "9",
      "text": "They are wrong about sin, because they do not believe in me."
    },
    {
      "verse": "10",
      "text": "They are wrong about who is right with God, because I will go to the Father. Then you will not see me again."
    },
    {
      "verse": "11",
      "text": "They are wrong about how God judges people, because God has already judged Satan, the ruler of this world."
    },
    {
      "verse": "12",
      "text": "I have many more things to tell you. But you are not strong enough to know them now."
    },
    {
      "verse": "13",
      "text": "But the Spirit will come. He is the one who shows people true things about God. When he comes, he will be a guide to you. He will help you to understand everything that is true. He will not speak on his own authority. He will tell you only what he hears from the Father. He will tell you about things that will happen after this time."
    },
    {
      "verse": "14",
      "text": "He will take my message and he will tell it to you. In that way, he will give me honour."
    },
    {
      "verse": "15",
      "text": "Everything that the Father has is mine. That is why I said, “The Spirit will take what is mine and then he will tell it to you. ” ’"
    },
    {
      "verse": "16",
      "text": "Jesus then said, ‘After a short time, you will not see me any more. But soon after that, you will see me again. ’"
    },
    {
      "verse": "17",
      "text": "Some of his disciples said to each other, ‘What does he mean? He says, “After a short time, you will not see me any more, but soon after that you will see me. ” He also says, “It is because I go to the Father. ”"
    },
    {
      "verse": "18",
      "text": "What does he mean when he says, “a short time”? We do not know what he is talking about! ’"
    },
    {
      "verse": "19",
      "text": "Jesus knew that they wanted to ask him about this. So he said to them, ‘I said, “After a short time, you will not see me. But soon after that, you will see me again. ” Perhaps you are asking each other about that."
    },
    {
      "verse": "20",
      "text": "I tell you this: You will be sad and you will cry. But the people who belong to this world will be happy. Yes, you will be sad. But soon after that, you will become happy instead."
    },
    {
      "verse": "21",
      "text": "It will be like this. When a woman is soon to give birth to a baby, she is sad. She knows that it will be painful. But after the baby is born, she is happy. She forgets her pain, because now she is so happy. She is happy because her child has been born into the world."
    },
    {
      "verse": "22",
      "text": "It is like that for you. You are sad now. But I will see you again, and then you will be happy. You will be really happy. Nobody will be able to take away your joy."
    },
    {
      "verse": "23",
      "text": "When that day arrives, you will not ask me for anything. I tell you this: The Father will help you with anything that you ask him for in my name."
    },
    {
      "verse": "24",
      "text": "Until now, you have not asked for anything in my name. Ask God, and you will receive what you ask for. Then you will be completely happy."
    },
    {
      "verse": "25",
      "text": "I have spoken to you with words and stories that are like pictures. But there will be a time when I will not speak like that any more. Instead, I will speak clearly to you about the Father."
    },
    {
      "verse": "26",
      "text": "When that day arrives, you yourselves will ask the Father in my name. I do not say that I will ask the Father on your behalf."
    },
    {
      "verse": "27",
      "text": "I will not need to do that, because the Father himself loves you. He loves you because you love me, and you have believed that I came from God."
    },
    {
      "verse": "28",
      "text": "Yes, I came from the Father, and I came into this world. Now I will leave this world and I will return to the Father. ’"
    },
    {
      "verse": "29",
      "text": "Jesus' disciples said to him, ‘Now you are speaking clearly. You are not speaking with words that are like pictures!"
    },
    {
      "verse": "30",
      "text": "Now we are sure that you know everything. You do not even need to ask people what they are thinking. Because of this, we believe that you came from God. ’"
    },
    {
      "verse": "31",
      "text": "Jesus answered them, ‘You say that you believe in me now."
    },
    {
      "verse": "32",
      "text": "But it will happen very soon that all of you will run away to your own homes. Yes, that time has already arrived. You will run away and leave me alone. But I will not really be alone, because the Father is always with me."
    },
    {
      "verse": "33",
      "text": "I have told you these things so that you will have peace. You will be like that because you live together with me. In this world, you will have trouble. But be brave! I have destroyed the power of this world. ’"
    }
  ],
  "17": [
    {
      "verse": "1",
      "text": "After Jesus said this, he looked up to heaven. He said, ‘Father, the time has now arrived. Show everyone how great your Son is. So then I, the Son, can show how great you are."
    },
    {
      "verse": "2",
      "text": "You gave me authority over all people. You did this so that I could give people life for ever. Those are the people that you gave to me."
    },
    {
      "verse": "3",
      "text": "What does it mean for people to live with you for ever? It means that they know you, the one who is the only true God. They also know me, Jesus Christ, the one that you have sent."
    },
    {
      "verse": "4",
      "text": "I have shown people here on the earth how great you are. In that way, I have finished the work that you gave to me to do."
    },
    {
      "verse": "5",
      "text": "So, Father, now that I return to you, show people how great I am. Before the world began, I had great glory with you. Show again that I am great like that. ’"
    },
    {
      "verse": "6",
      "text": "‘You gave some people to me who were from this world. I have shown them who you are. They were yours and you gave them to me. They have obeyed your message."
    },
    {
      "verse": "7",
      "text": "Everything that I have comes from you. Now they know that you gave me everything."
    },
    {
      "verse": "8",
      "text": "I gave to them the message that you gave to me. They accepted that message. They know certainly that I came from you. They believe that you sent me."
    },
    {
      "verse": "9",
      "text": "I pray for them. I am not praying for the people who belong to this world. No, I am praying for those people that you have given to me. I am praying for them because they are yours."
    },
    {
      "verse": "10",
      "text": "Everything that I have is yours. And everything that you have is mine. These people have shown how great I am."
    },
    {
      "verse": "11",
      "text": "I will not remain in the world any longer. I will return to you now. But they will still be here in the world. Holy Father, please keep them safe in your name. That is the powerful name that you gave to me. Then they can be united in the same way that you and I are united."
    },
    {
      "verse": "12",
      "text": "While I was with them, I kept them safe in the power of your name. That is the name that you gave to me. I kept them safe so that only one of them turned away from you. That was the man who had to become lost. The Bible already said that it would happen in that way."
    },
    {
      "verse": "13",
      "text": "Now, Father, I will come to you. I am saying these things while I am still in the world. Then these people, my disciples, can be completely happy. I want them to be completely happy in the same way that I am happy."
    },
    {
      "verse": "14",
      "text": "I have given your message to them. The world's people have hated them because they do not belong to the world. They do not belong to the world, in the same way that I do not belong to the world."
    },
    {
      "verse": "15",
      "text": "I am not asking that you will take them out of the world. But I ask you to keep them safe from the Devil."
    },
    {
      "verse": "16",
      "text": "They do not belong to the world, in the same way that I do not belong to the world."
    },
    {
      "verse": "17",
      "text": "Help them to belong completely to you, as they follow the truth. Your message is the truth."
    },
    {
      "verse": "18",
      "text": "I have sent them into the world, in the same way that you sent me into the world."
    },
    {
      "verse": "19",
      "text": "On their behalf I give myself to you, so that I belong completely to you. Then they also can completely belong to you, as they follow the truth. ’"
    },
    {
      "verse": "20",
      "text": "‘I do not pray only for these people, my disciples. I pray also for those people who will believe in me because of my disciples' message."
    },
    {
      "verse": "21",
      "text": "I pray that all of them will become united. You, Father, are in me and I am in you. I pray that they also will be united in us. Then the world's people will believe that you sent me."
    },
    {
      "verse": "22",
      "text": "I have given to them the same honour that you gave to me. Now they can be united in the same way that you and I are united."
    },
    {
      "verse": "23",
      "text": "I will be in them, and you will be in me, so that they can be completely united. As a result, the world's people will know that you sent me. They will also know that you love my own people as you love me."
    },
    {
      "verse": "24",
      "text": "Father, you have given these people to me. I want them to be with me where I am. Then they will see how great I am. You made me great because you loved me. You loved me even before the world began."
    },
    {
      "verse": "25",
      "text": "Father, you always do what is right. The world's people do not know you, but I know you. These disciples know that you have sent me."
    },
    {
      "verse": "26",
      "text": "I have shown them what you are like. And I will continue to show them what you are like. Then they will love other people, in the same way that you love me. And I myself will be in them. ’"
    }
  ],
  "18": [
    {
      "verse": "1",
      "text": "When Jesus had finished praying, he and his disciples went out. They went across the Kidron valley. On the other side, there was a garden. Jesus and his disciples went into it."
    },
    {
      "verse": "2",
      "text": "Judas, who sold Jesus to his enemies, knew the garden. He knew the place because Jesus and his disciples had met there often."
    },
    {
      "verse": "3",
      "text": "The leaders of the priests and the Pharisees sent a group of soldiers and some officers with Judas. He led these soldiers and officers to the garden. The soldiers had weapons and they carried lights."
    },
    {
      "verse": "4",
      "text": "Jesus knew everything that would soon happen to him. He went towards them and he asked them, ‘Who are you looking for? ’"
    },
    {
      "verse": "5",
      "text": "They answered, ‘Jesus, who comes from Nazareth. ’ Jesus said, ‘That is who I am. ’Judas, who sold Jesus to his enemies, was standing there with the soldiers."
    },
    {
      "verse": "6",
      "text": "When Jesus said the words, ‘I am, ’ the soldiers quickly moved away from him. They fell down to the ground."
    },
    {
      "verse": "7",
      "text": "So Jesus asked them again, ‘Who are you looking for? ’ They said, ‘Jesus, who comes from Nazareth. ’"
    },
    {
      "verse": "8",
      "text": "Jesus replied, ‘I have told you already, that is who I am. Since it is me that you are looking for, let these other men go. ’"
    },
    {
      "verse": "9",
      "text": "Jesus said this because earlier he had said, ‘I have lost none of those people that you gave to me. ’ This made what he had spoken earlier really happen."
    },
    {
      "verse": "10",
      "text": "Simon Peter had a sword. He took hold of it and he attacked the servant of the leader of the priests. He cut off the servant's right ear. The servant's name was Malchus."
    },
    {
      "verse": "11",
      "text": "Then Jesus said to Peter, ‘Put your sword away in its place! My Father has decided what great pain I must have. I will obey him completely. ’"
    },
    {
      "verse": "12",
      "text": "The group of soldiers, with their captain and the Jewish officers, took hold of Jesus. They tied him with ropes."
    },
    {
      "verse": "13",
      "text": "They led him first to Annas, who was the father of Caiaphas's wife. Caiaphas was the leader of the priests that year."
    },
    {
      "verse": "14",
      "text": "It was Caiaphas who had already spoken to the Jewish leaders. He had told them, ‘It is better that one man should die on behalf of the people. ’"
    },
    {
      "verse": "15",
      "text": "Simon Peter and another disciple followed Jesus. That other disciple and the leader of the priests knew each other. So that disciple went with Jesus into the yard of the house of the leader of the priests."
    },
    {
      "verse": "16",
      "text": "But Peter stayed outside by the gate. Then the other disciple went out again. He spoke to the girl who was watching at the gate. Then he brought Peter into the yard."
    },
    {
      "verse": "17",
      "text": "The girl who was at the gate asked Peter, ‘Are you another of this man's disciples? ’ Peter replied, ‘No, I am not! ’"
    },
    {
      "verse": "18",
      "text": "It was cold. So the servants and the officers had made a fire. They were standing around it to make themselves warm. Peter went to stand with them, so that he could make himself warm too."
    },
    {
      "verse": "19",
      "text": "The leader of the priests asked Jesus questions about his disciples. He also asked about what Jesus taught."
    },
    {
      "verse": "20",
      "text": "Jesus answered him, ‘I have always taught in the Jewish meeting places, or at the temple. Those are public places where all the Jews meet together. I have said nothing secretly."
    },
    {
      "verse": "21",
      "text": "So you do not need to ask me these questions. You can ask the people who heard me when I taught them. They know what I said. ’"
    },
    {
      "verse": "22",
      "text": "When Jesus said this, one of the soldiers hit him on the face. The soldier said, ‘You should not speak to the leader of the priests like that! ’"
    },
    {
      "verse": "23",
      "text": "Jesus replied, ‘If I said something wrong, tell us what it is. But if I said something that is true, you should not have hit me. ’"
    },
    {
      "verse": "24",
      "text": "Then Annas sent Jesus to Caiaphas, the leader of the priests. Jesus still had ropes tied round his arms."
    },
    {
      "verse": "25",
      "text": "Simon Peter was still standing there by the fire to make himself warm. The other people there said to him, ‘You must also be one of that man's disciples. ’ But Peter said, ‘No, I am not. ’"
    },
    {
      "verse": "26",
      "text": "One of the people there was a servant of the leader of the priests. He belonged to the same family as the man whose ear Peter had cut off. This servant said to Peter, ‘I am sure that I saw you in the garden with Jesus. ’"
    },
    {
      "verse": "27",
      "text": "Again, Peter said, ‘No, that is not true. ’ Immediately a cockerel sang."
    },
    {
      "verse": "28",
      "text": "The Jewish leaders took Jesus from Caiaphas's house to the Roman ruler's big house. It was early in the morning. The Jewish leaders wanted to follow the Jewish rules so that they could eat the Passover meal. They did not go into the ruler's house, because it would have made them unclean."
    },
    {
      "verse": "29",
      "text": "So Pilate, the Roman ruler, went outside to meet them. He asked them, ‘What wrong thing do you say that this man has done? ’"
    },
    {
      "verse": "30",
      "text": "They replied, ‘We would not have brought him to you if he had done nothing wrong. ’"
    },
    {
      "verse": "31",
      "text": "Pilate said to them, ‘You yourselves take him away. You should judge him by your own laws. ’ The Jewish leaders replied, ‘We do not have authority to kill anyone when they have done something bad. ’"
    },
    {
      "verse": "32",
      "text": "Jesus had already told people how he would die. These things happened to make his words become true."
    },
    {
      "verse": "33",
      "text": "Pilate went back inside his palace. He told Jesus to come and stand in front of him. He asked Jesus, ‘Are you the king of the Jews? ’"
    },
    {
      "verse": "34",
      "text": "Jesus said, ‘Is that your own idea, or have other people spoken to you about me? ’"
    },
    {
      "verse": "35",
      "text": "Pilate replied, ‘I am not a Jew, am I? It was your own people and the leaders of your priests who brought you to me. What have you done? ’"
    },
    {
      "verse": "36",
      "text": "Jesus said, ‘My kingdom does not belong to this world. If it did, my disciples would have fought for me. They would have fought so that the Jewish leaders could not take hold of me. No, my kingdom belongs to another place. ’"
    },
    {
      "verse": "37",
      "text": "Pilate said to him, ‘So that means you really are a king! ’Jesus answered, ‘You have said that I am a king! I was born for this reason: I came into the world to tell people the truth about God. Everyone who believes the truth listens to my message. ’"
    },
    {
      "verse": "38",
      "text": "Pilate said, ‘I do not know what truth is. ’When Pilate had said that, he went outside again to the Jewish people there. He said to them, ‘I do not see that this man is guilty of anything wrong. I have no reason to punish him."
    },
    {
      "verse": "39",
      "text": "But every year we do something for you Jews. We let one man go free from the prison at the time of your Passover festival. Do you want me to let the king of the Jews go free? ’"
    },
    {
      "verse": "40",
      "text": "They shouted their answer, ‘No, we do not want him! Let Barabbas go free! ’ (Barabbas was a man who had attacked people and robbed them. )"
    }
  ],
  "19": [
    {
      "verse": "1",
      "text": "Then Pilate told the soldiers to take Jesus outside. He told them to hit Jesus many times with a whip."
    },
    {
      "verse": "2",
      "text": "The soldiers used some branches with thorns to make a crown for Jesus. They put it on his head. Then put a dark red coat on him too. They did all this as if he was a king."
    },
    {
      "verse": "3",
      "text": "They came to him many times and they were saying to him, ‘Hello, King of the Jews, you are great! ’ At the same time they slapped his face with their hands."
    },
    {
      "verse": "4",
      "text": "Pilate went outside once more. He said to the crowd, ‘Listen to me. I will bring Jesus out here to you. You should know this: I do not say that this man is guilty of anything wrong. I have no reason to punish him. ’"
    },
    {
      "verse": "5",
      "text": "Then Jesus came out. He was still wearing the hat of thorns on his head and the dark red coat. Pilate said to them, ‘Look. Here is the man! ’"
    },
    {
      "verse": "6",
      "text": "When the leaders of the priests and their officers saw Jesus, they shouted, ‘Kill him! Kill him on a cross! ’ Pilate said to them, ‘Take him for yourselves and kill him on a cross. I can find no reason why I should punish him. ’"
    },
    {
      "verse": "7",
      "text": "The Jews answered, ‘We have a law which says that he must die. He must die because he said, “I am the Son of God. ” ’"
    },
    {
      "verse": "8",
      "text": "When Pilate heard that, he was even more afraid."
    },
    {
      "verse": "9",
      "text": "He went back into the house. He asked Jesus, ‘Where are you really from? ’ But Jesus did not answer him."
    },
    {
      "verse": "10",
      "text": "Pilate said to him, ‘Are you refusing to speak to me? Remember that I have authority. I can let you go free, or I can let them kill you on a cross. ’"
    },
    {
      "verse": "11",
      "text": "Jesus answered, ‘You could have no power against me unless God had given it to you. So the man who sold me to you has done a worse thing than you have done. ’"
    },
    {
      "verse": "12",
      "text": "From that moment, Pilate tried to let Jesus go free. But the Jewish leaders shouted back, ‘If you let him go, you are not Caesar's friend. Nobody should say that he himself is a king. That shows that he is against Caesar! ’"
    },
    {
      "verse": "13",
      "text": "When Pilate heard those words, he brought Jesus outside. Pilate sat down on a special seat for the judge. The seat was in a place called ‘Gabbatha’ in the Jewish language. There were large flat stones there, which covered the ground."
    },
    {
      "verse": "14",
      "text": "It was about noon on the day when they prepared the Passover meal. Pilate said to the Jews, ‘Here is your king! ’"
    },
    {
      "verse": "15",
      "text": "But they shouted, ‘Take him away! Take him away! Kill him on a cross! ’ Pilate asked them, ‘Do you want me to kill your king on a cross? ’ The leaders of the priests answered, ‘Caesar is the only ruler that we call king. ’"
    },
    {
      "verse": "16",
      "text": "Then Pilate gave Jesus to them, so that they could kill him on a cross. The soldiers took hold of Jesus."
    },
    {
      "verse": "17",
      "text": "He was carrying the cross on which they would kill him. He went out to the place called ‘The Place of the Skull’. This place is called ‘Golgotha’ in the Jewish language."
    },
    {
      "verse": "18",
      "text": "When they arrived there, the soldiers fixed Jesus to the cross. They put two other men on crosses near to him. They were on each side of him and Jesus was between them."
    },
    {
      "verse": "19",
      "text": "Pilate wrote a notice. Then the soldiers put it on the cross. It said: ‘Jesus from Nazareth, the King of the Jews’."
    },
    {
      "verse": "20",
      "text": "The place where they put Jesus on the cross was near to the city. So many of the Jews read this notice. They could read it because Pilate had written the words in three languages. He had written it in the Jewish language and in the languages of the Roman people and the Greek people."
    },
    {
      "verse": "21",
      "text": "The leaders of the Jewish priests said to Pilate, ‘Do not write, “The King of the Jews”. Instead, write, “This man said that he is the King of the Jews. ” ’"
    },
    {
      "verse": "22",
      "text": "Pilate answered, ‘I will not change what I have written. ’"
    },
    {
      "verse": "23",
      "text": "After the soldiers had put Jesus on the cross, they took his clothes. They made them into four parts, one part for each soldier. They also took his long shirt, which was one single piece of cloth. ‘Each of them took some of my clothes. They played a game with dice to win what I was wearing. ’ And that is what the soldiers did."
    },
    {
      "verse": "24",
      "text": "So they said to each other, ‘We will not tear it. Instead, we will play a game with dice. The person who wins the game will have the shirt. ’ This happened in the way that the Bible had already said:‘Each of them took some of my clothes. They played a game with dice to win what I was wearing. ’And that is what the soldiers did."
    },
    {
      "verse": "25",
      "text": "Some women stood near to Jesus while he was on the cross. They were his mother, his mother's sister, Mary the wife of Cleopas, and Mary from Magdala."
    },
    {
      "verse": "26",
      "text": "Jesus saw his mother there. He also saw the disciple that he loved. That disciple was standing there, near Jesus' mother. So Jesus said to his mother, ‘Woman, look! There is your son. ’"
    },
    {
      "verse": "27",
      "text": "Then he said to the disciple, ‘Look! There is your mother. ’ From that time, the disciple took Jesus' mother to live in his own home."
    },
    {
      "verse": "28",
      "text": "After this, Jesus knew that everything was now finished. Then he said, ‘I am thirsty. ’ He said this so that things would happen in the way the Bible already said."
    },
    {
      "verse": "29",
      "text": "There was a pot full of cheap wine there. So someone put a piece of cloth into the wine. They fixed the cloth to the end of a branch. The branch was from a plant called hyssop. Then they lifted the cloth up to Jesus' mouth."
    },
    {
      "verse": "30",
      "text": "Jesus drank the wine. Then he said, ‘Everything is finished. ’ He bent his head down and he let his spirit go."
    },
    {
      "verse": "31",
      "text": "It was the day when the Jews prepare everything for their day of rest. The next day was the day for the Passover meal, so it was a very important day. The Jews did not want the men's bodies to stay on the crosses during that day of rest. So they asked Pilate to tell the soldiers to break the legs of those men. Then they could take the dead bodies down from the crosses."
    },
    {
      "verse": "32",
      "text": "So the soldiers went there. They broke the legs of the two men who were on the crosses next to Jesus. ‘Nobody will break any of his bones. ’"
    },
    {
      "verse": "33",
      "text": "Then they went to Jesus. They saw that he was dead already. So they did not break his legs."
    },
    {
      "verse": "34",
      "text": "But one of the soldiers put a spear into Jesus' side. Immediately, blood and water came out of his body."
    },
    {
      "verse": "35",
      "text": "The man who saw these things has spoken about them. What he says is true. He knows that it really happened. He is telling you the truth so that you can believe."
    },
    {
      "verse": "36",
      "text": "The Bible already said how it would happen. It says:‘Nobody will break any of his bones. ’"
    },
    {
      "verse": "37",
      "text": "In another place, the Bible says:‘People will push a spear into that man's body, and then they will look at him. ’And that is how it really happened. ‘People will push a spear into that man's body, and then they will look at him. ’ And that is how it really happened."
    },
    {
      "verse": "38",
      "text": "There was a man called Joseph who came from the town of Arimathea. He was one of Jesus' disciples, but he was afraid of the Jewish leaders. So he had not told people that he was a disciple of Jesus. Joseph went to Pilate and asked if he could take Jesus' dead body away. Pilate agreed. So Joseph went there and he took the body away."
    },
    {
      "verse": "39",
      "text": "Nicodemus went with Joseph. He was the man who had visited Jesus at night. Nicodemus brought about 33 kilograms of spices called myrrh and aloes."
    },
    {
      "verse": "40",
      "text": "The two men covered Jesus' dead body with these spices. And they tied long pieces of linen cloth around it many times. That is how the Jewish people prepare a dead body before they bury it."
    },
    {
      "verse": "41",
      "text": "There was a garden near the place where they had killed Jesus on the cross. In that garden there was a place where they could put the bodies of dead people. It was a new hole in the rock, where nobody had ever put a dead body before."
    },
    {
      "verse": "42",
      "text": "The next day was the Jewish day of rest. So they put Jesus in that hole in the rock, because it was near."
    }
  ],
  "20": [
    {
      "verse": "1",
      "text": "Early on the first day of the week, Mary from Magdala went to the hole in the rock. It was still dark. She saw that someone had removed the big stone from the front of the hole."
    },
    {
      "verse": "2",
      "text": "So she ran to where Simon Peter was. He was with the other disciple, the one that Jesus loved. She said to them, ‘Somebody has taken the Lord's body out of the hole. We do not know where they have put him! ’"
    },
    {
      "verse": "3",
      "text": "So Peter and the other disciple started to go to the place where Jesus' body had been."
    },
    {
      "verse": "4",
      "text": "Both of them were running. But the other disciple ran faster than Peter ran. So he reached the hole first."
    },
    {
      "verse": "5",
      "text": "He bent himself down and he looked inside the hole. He saw the pieces of linen cloth that were lying there. But he did not go in."
    },
    {
      "verse": "6",
      "text": "Simon Peter had run behind the other disciple. When he arrived, he went into the hole. He saw the pieces of cloth that were lying there."
    },
    {
      "verse": "7",
      "text": "Also, he saw the piece of cloth that had been around Jesus' head. This was not in the same place as the long pieces of linen cloth. Someone had put it carefully in a separate place."
    },
    {
      "verse": "8",
      "text": "The other disciple had reached the place first, and now he also went inside. He saw and he believed."
    },
    {
      "verse": "9",
      "text": "They still did not understand what the Bible already said. It said that Jesus had to become alive again after he had died."
    },
    {
      "verse": "10",
      "text": "Then the disciples returned to the place where they were staying."
    },
    {
      "verse": "11",
      "text": "But Mary stood outside the hole in the rock. She was crying. While she cried, she bent herself down to look inside the hole."
    },
    {
      "verse": "12",
      "text": "She saw two angels there. They were wearing white clothes. They were sitting where Jesus' dead body had been. One angel was sitting where Jesus' head had been. The other angel was sitting where his feet had been."
    },
    {
      "verse": "13",
      "text": "They asked her, ‘Woman, why are you crying? ’ She replied, ‘They have taken away my Lord. I do not know where they have put him. ’"
    },
    {
      "verse": "14",
      "text": "When she had said this, she turned round. She saw a man who was standing there. It was Jesus, but she did not recognize him."
    },
    {
      "verse": "15",
      "text": "Jesus said to her, ‘Woman, why are you crying? Who are you looking for? ’ Mary thought that he was the gardener. So she said, ‘Sir, if you have carried him away somewhere, please tell me. Tell me where you have put him. Then I will go and I will take him away. ’"
    },
    {
      "verse": "16",
      "text": "Jesus said to her, ‘Mary. ’ She turned towards him and she said in the Jewish language, ‘Rabboni! ’ (This means ‘Teacher’. )"
    },
    {
      "verse": "17",
      "text": "Jesus said, ‘Do not hold on to me because I have not gone up to the Father yet. But go to my brothers, the disciples. Tell them, “Now I will go up to my Father. He is also your Father. He is my God, and he is your God. ” ’"
    },
    {
      "verse": "18",
      "text": "Mary from Magdala took this message to the disciples. She went to them and she said, ‘I have seen the Lord! ’ Then she told them the things that Jesus had said to her."
    },
    {
      "verse": "19",
      "text": "On the evening of that same day, the first day of the week, the disciples were meeting together. They had locked the doors of the room because they were afraid of the Jewish leaders. Then Jesus came and he stood among them. He said to them, ‘Peace be with you. ’"
    },
    {
      "verse": "20",
      "text": "After he had said this, he showed them his hands and his side. The disciples were very, very happy when they saw the Lord."
    },
    {
      "verse": "21",
      "text": "Jesus said again, ‘Peace be with you. As the Father has sent me, in the same way I am now sending you. ’"
    },
    {
      "verse": "22",
      "text": "When he had said this, he breathed on them. He said, ‘Receive God's Holy Spirit."
    },
    {
      "verse": "23",
      "text": "If you forgive a person's sins, God will forgive them too. If you do not forgive them, God will not forgive them. ’"
    },
    {
      "verse": "24",
      "text": "disciples was called Thomas. (He was also called ‘the Twin’. ) He was not with the other disciples when Jesus came to them."
    },
    {
      "verse": "25",
      "text": "So the other disciples told him, ‘We have seen the Lord. ’ But Thomas said to them, ‘I will never believe that he is alive again unless I myself see him. I want to see the marks of the nails in his hands. I want to touch where the nails were with my finger. I want to put my hand into his side where the spear went in. If I cannot do that, I will not believe. ’"
    },
    {
      "verse": "26",
      "text": "Eight days after that, the disciples were in the house again. This time Thomas was with them. They had locked the door. But Jesus came and he stood among them. He said to them, ‘Peace be with you. ’"
    },
    {
      "verse": "27",
      "text": "Then he said to Thomas, ‘Put your finger in here. Look at my hands. Put your hand here, in my side. Do not refuse to believe what is true. Now, believe. ’"
    },
    {
      "verse": "28",
      "text": "Thomas answered him, ‘My Lord, and my God! ’"
    },
    {
      "verse": "29",
      "text": "Jesus said to him, ‘You believe because you have seen me. Other people have not seen me, but they do believe in me. God is really happy with those people. ’"
    },
    {
      "verse": "30",
      "text": "Jesus did many other miracles while the disciples were with him. I have not written about all of them in this book."
    },
    {
      "verse": "31",
      "text": "But I have written about these things, so that you will be able to believe the truth. You will believe that Jesus is the Messiah, the Son of God. Because you believe in him, you will have life with God."
    }
  ],
  "21": [
    {
      "verse": "1",
      "text": "After that, Jesus showed himself to the disciples again when they were by Lake Tiberias. This is how it happened."
    },
    {
      "verse": "2",
      "text": "Simon Peter, Thomas the Twin and Nathanael were together. (Nathanael came from Cana in Galilee. ) The sons of Zebedee (James and John) and two other disciples were also there."
    },
    {
      "verse": "3",
      "text": "Simon Peter said to the other disciples, ‘I will now go and catch fish. ’ They replied, ‘We will come with you. ’ So they went out and they got into the boat. But they caught nothing during that night."
    },
    {
      "verse": "4",
      "text": "Early in the morning, Jesus was standing on the shore of the lake. But the disciples did not know that it was Jesus who stood there."
    },
    {
      "verse": "5",
      "text": "Then Jesus asked them, ‘Friends, have you caught any fish? ’ They answered, ‘No! ’"
    },
    {
      "verse": "6",
      "text": "He said, ‘Throw your net out on the right side of the boat. If you do that, you will catch some fish. ’ So they threw the net out into the water. Then they caught so many fish that they could not pull the net back into the boat."
    },
    {
      "verse": "7",
      "text": "The disciple that Jesus loved said to Peter, ‘It is the Lord! ’ When Simon Peter heard him say, ‘It is the Lord, ’ he put on his coat. (He had been wearing only a few clothes. ) Then he jumped into the water."
    },
    {
      "verse": "8",
      "text": "The other disciples followed him in the boat. They pulled the net that was full of fish behind them. They were not far from the shore. It was about 100 metres away."
    },
    {
      "verse": "9",
      "text": "When they came to the shore, they saw that someone had lit a fire. Some fish were cooking on it. There was some bread there, too."
    },
    {
      "verse": "10",
      "text": "Jesus said to them, ‘Bring here some of the fish that you have just caught. ’"
    },
    {
      "verse": "11",
      "text": "Simon Peter got back into the boat and he pulled the net onto the shore. It was full of 153 big fish. There were so many fish, but the net had not broken."
    },
    {
      "verse": "12",
      "text": "Jesus said to them, ‘Come here and eat breakfast. ’ None of the disciples was brave enough to ask him, ‘Who are you? ’ They knew that it was the Lord."
    },
    {
      "verse": "13",
      "text": "So Jesus took the bread and he gave it to them. Then he did the same with the fish."
    },
    {
      "verse": "14",
      "text": "After Jesus died and became alive again, this was now the third time that he showed himself to his disciples."
    },
    {
      "verse": "15",
      "text": "When they had finished eating, Jesus spoke to Simon Peter. He said, ‘Simon, son of John, do you love me more than these other disciples love me? ’ Peter answered, ‘Yes Lord, you know that I love you. ’ Jesus said to him, ‘Feed my lambs. ’"
    },
    {
      "verse": "16",
      "text": "Jesus asked him a second time, ‘Simon, son of John, do you love me? ’ Peter answered, ‘Yes Lord, you know that I love you. ’ Jesus said to him, ‘Take care of my sheep. ’"
    },
    {
      "verse": "17",
      "text": "Jesus asked him a third time, ‘Simon, son of John, do you love me? ’ Peter was sad because Jesus asked him a third time, ‘Do you love me? ’ So he said to Jesus, ‘Lord, you know everything. You know that I really love you! ’ Jesus said to him, ‘Take care of my sheep."
    },
    {
      "verse": "18",
      "text": "I tell you this: When you were young, you put on your own clothes. Then you went to any place that you wanted to visit. But when you are old, it will be different. You will hold out your arms and someone else will tie your clothes for you. Then they will take you to a place where you do not want to go. ’"
    },
    {
      "verse": "19",
      "text": "When Jesus said this, he was showing how Peter would die. His death would give honour to God. Then Jesus said to Peter, ‘Follow me. ’"
    },
    {
      "verse": "20",
      "text": "Peter turned round and he saw the disciple that Jesus loved. He was the man who had been very near to Jesus at the supper. He had asked Jesus, ‘Lord, who will sell you to your enemies? ’ Now this disciple was following behind them."
    },
    {
      "verse": "21",
      "text": "When Peter saw him, he asked Jesus, ‘Lord, what will happen to him? ’"
    },
    {
      "verse": "22",
      "text": "Jesus answered him, ‘Perhaps I might want him to live until I return to this earth. But that should not matter to you. You must follow me! ’"
    },
    {
      "verse": "23",
      "text": "At that time, people began to talk about these words that Jesus had said. Some disciples thought that Jesus meant that this disciple would not die. But Jesus did not say, ‘He will not die. ’ Instead, he said to Peter, ‘Perhaps I might want him to live until I return to this earth. But that should not matter to you. ’"
    },
    {
      "verse": "24",
      "text": "I am the disciple who saw these things. I am the one who wrote them down. We all know that what I have written about them is true."
    },
    {
      "verse": "25",
      "text": "Jesus also did many other things. If people wrote about all those things, there would be very many books. I do not think that the whole world would have enough room for all those books."
    }
  ]
};