module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter is from Paul, Silas and Timothy. We are writing to the people of the church in Thessalonica. You belong to God our Father, and to the Lord Jesus Christ. We are writing to the people of the church in Thessalonica. You belong to God our Father, and to the Lord Jesus Christ."
    },
    {
      "verse": "2",
      "text": "We pray that God, the Father, and the Lord Jesus Christ will continue to help you. We pray that they will give you peace in your minds."
    },
    {
      "verse": "3",
      "text": "Our Christian friends, we ought always to thank God because of you. It is right that we do this, because you are learning to trust Christ more and more. All of you are also loving each other more and more."
    },
    {
      "verse": "4",
      "text": "As a result, we are proud to tell believers in other churches about you. We tell them how you continue to trust God in your many troubles. You are patient and brave, even when people cause you to have much pain."
    },
    {
      "verse": "5",
      "text": "This shows us that God judges people in a way that is right. Now you are receiving much trouble because you belong to God's kingdom. This shows that God accepts you as the people that he rules."
    },
    {
      "verse": "6",
      "text": "God will punish those people who are causing trouble for you. He will cause trouble for them. That is right and fair."
    },
    {
      "verse": "7",
      "text": "God will also do what is right and fair for you. You have troubles now. But one day God will cause you to have rest, together with us. That will happen when the Lord Jesus comes down from heaven. He will come with his powerful angels,"
    },
    {
      "verse": "8",
      "text": "and with a very hot fire. He will punish those people who do not know God. Yes, he will punish those people who do not obey the good news about our Lord Jesus."
    },
    {
      "verse": "9",
      "text": "Their punishment will continue for ever, as God destroys them. He will keep them away from the Lord. They will never see the Lord, or his great power."
    },
    {
      "verse": "10",
      "text": "This will happen when Jesus comes on that special day. His own people will praise him for the great things that he has done for them. All of us who are believers will be surprised when we see his great power. This includes you, because you believed our message about the Lord Jesus."
    },
    {
      "verse": "11",
      "text": "So we always pray for you. Our God has chosen you to be his own people. We pray that he will help you, so that you continue to please him. We also pray that God will work powerfully in you. Then you will be able to do every good thing that you want to do. You will do the things that you want to do because you trust God."
    },
    {
      "verse": "12",
      "text": "As a result, people will praise our Lord Jesus because of how you live. You also will receive praise, because you belong to Jesus. All this is possible because our God and the Lord Jesus Christ are very kind."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "Our Christian friends, we must explain something now about the time when our Lord Jesus Christ will return. That is the time when he will bring us all together to be with him."
    },
    {
      "verse": "2",
      "text": "Please do not become easily confused about this. Do not let yourselves become afraid because of false messages about the Lord's return. Some people are telling you that the great day of the Lord's return has already happened. Some of these people say that God's Spirit has shown them a message like that. Other people might say that the message came from us. Or they might say that we wrote it in a letter."
    },
    {
      "verse": "3",
      "text": "Do not let anyone deceive you like that in any way. That day will not happen until certain other things have happened. Before that day, there will be a time when many people will turn against God. Also, the man who is completely against God will appear. God will surely destroy him in the end."
    },
    {
      "verse": "4",
      "text": "This man will be God's great enemy. He will say that he is greater than everything that people call their gods. He will say that he is greater than everything that people worship. As a result, he will even go into the temple. He will sit down there like a king. He will tell everyone that he himself is God."
    },
    {
      "verse": "5",
      "text": "I told you these things when I was with you. I am sure that you remember that."
    },
    {
      "verse": "6",
      "text": "Something makes it impossible for this man to come now. And you know what it is. But this man will appear at the proper time."
    },
    {
      "verse": "7",
      "text": "His power is already working secretly to turn people against God. But there is someone who makes it impossible for him to work freely. That person will continue to make it impossible, until God takes that person away."
    },
    {
      "verse": "8",
      "text": "Then the man who is against God will appear. But the Lord Jesus will come, and he will kill that man. Jesus will blow him away with breath from his mouth. When Jesus appears with great power, that enemy of God will be there no longer!"
    },
    {
      "verse": "9",
      "text": "When the enemy of God appears, he will be doing Satan's work. Satan will give him the power to do great things and miracles that are false."
    },
    {
      "verse": "10",
      "text": "He will do all kinds of bad things that deceive people. The people that he deceives are people that God will destroy. Those people believe false things because they have refused to accept God's true message. If they had loved that true message, God would have saved them."
    },
    {
      "verse": "11",
      "text": "For this reason, God causes their minds to accept something that is wrong. They believe a false message."
    },
    {
      "verse": "12",
      "text": "As a result, God will punish all of them. They have refused to believe what is true. Instead, they have enjoyed doing very bad things."
    },
    {
      "verse": "13",
      "text": "We always thank God for you, our Christian friends that the Lord loves. We ought to thank God, because he has chosen to save you. God chose you to belong to him, as some of the first people that he would save. You believed God's true message. And God's Spirit makes you separate from things that are bad."
    },
    {
      "verse": "14",
      "text": "We told you God's good news. That is how God called you to come to him. He saved you so that you would join with our Lord Jesus Christ in heaven."
    },
    {
      "verse": "15",
      "text": "Because of that, our Christian friends, you must continue to trust Christ. Continue to believe the true things that we taught you. Those are the things that we told you when we were with you. We also wrote about them in our letter to you."
    },
    {
      "verse": "16",
      "text": "We ask our Lord Jesus Christ himself, and God, our Father, to help you. God has shown that he loves us very much. He has helped us to be brave and strong for all time. We continue to hope for the good things that will come. Yes, God has been very kind to us!"
    },
    {
      "verse": "17",
      "text": "We pray that he will continue to help you and make you strong. Then you will always be able to do good things and to say good things."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "Now, friends, we ask you to pray for us. Pray that more and more people will soon hear the Lord's message. Pray that people will receive the message well and accept it as true. That is how you received it."
    },
    {
      "verse": "2",
      "text": "Pray also that God will not let bad people cause trouble for us. Not everyone believes the message about our Lord."
    },
    {
      "verse": "3",
      "text": "But the Lord always does what he has promised. So he will help you to be strong inside yourselves. He will keep you safe when Satan attacks you."
    },
    {
      "verse": "4",
      "text": "Because you belong to the Lord, he makes us sure about you. We know that you are doing the things that we tell you to do. And we know that you will continue to do those things."
    },
    {
      "verse": "5",
      "text": "We pray that the Lord will lead you in your thoughts. Then you will understand God's love better and better. And you will be patient and strong, as Christ is."
    },
    {
      "verse": "6",
      "text": "Our friends, you must stay away from every believer who is living in a lazy way. We tell you this with the authority that the Lord Jesus Christ gives to us. Lazy people like that are not living in the way that we taught you."
    },
    {
      "verse": "7",
      "text": "You yourselves know that you ought to copy our example. You know that we were not lazy when we lived among you."
    },
    {
      "verse": "8",
      "text": "We always paid for the food that anyone gave to us. We worked hard all the time, during the day and at night. We did that so that we would not make trouble for any of you."
    },
    {
      "verse": "9",
      "text": "We could have told you to give us what we needed. We have authority to do that. But we wanted to show you how to live properly. Then you could copy our example."
    },
    {
      "verse": "10",
      "text": "Even when we were there with you, we told you this rule: ‘If anyone refuses to work, you should not give food to him. ’"
    },
    {
      "verse": "11",
      "text": "We say this because someone has told us news about you. They have told us that some people among you are living in a lazy way. Those people do not work at their own jobs. Instead, they cause trouble to other people who are working."
    },
    {
      "verse": "12",
      "text": "We have something to say to people who are lazy like that. We warn them with the authority that the Lord Jesus Christ gives to us. They must stop causing trouble. They must work properly, so that they get their own food to eat."
    },
    {
      "verse": "13",
      "text": "But you must never stop doing what is right, our Christian friends, even when it causes trouble for you."
    },
    {
      "verse": "14",
      "text": "Maybe someone among you will not obey the message that we have written in this letter. Make sure that everyone knows about someone like that. Do not be friends with him, so that he may become ashamed."
    },
    {
      "verse": "15",
      "text": "But remember that he is a believer, as you are. So warn him carefully."
    },
    {
      "verse": "16",
      "text": "The Lord helps us to have peace in our minds. I pray that the Lord himself will give that peace to you at all times, whatever happens. I pray that the Lord will be with all of you."
    },
    {
      "verse": "17",
      "text": "I, Paul, am writing these words at the end of my letter with my own hand. I say ‘hello’ to you. That is how I write in every letter that comes from me."
    },
    {
      "verse": "18",
      "text": "I pray that our Lord Jesus Christ will continue to be very kind to all of you."
    }
  ]
};