module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter is from me, Paul. God chose me to be an apostle of Christ Jesus. Our friend Timothy is here with me while I write."
    },
    {
      "verse": "2",
      "text": "We are writing to you, God's own people who live in Colossae. You are like brothers and sisters to us because you continue to believe in Christ. I pray that God, our Father, will continue to help you. I pray that he will give you peace in your minds. I pray that God, our Father, will continue to help you. I pray that he will give you peace in your minds."
    },
    {
      "verse": "3",
      "text": "We always thank God, the Father of our Lord Jesus Christ, when we pray for you."
    },
    {
      "verse": "4",
      "text": "We thank God because people have told us good things about you. You continue to trust Christ Jesus. You also love all God's people."
    },
    {
      "verse": "5",
      "text": "You live like that because you hope to receive good things from God. You know that God has prepared those good things for you. He is keeping them safe in heaven. You learned that when people first told you God's true message, his good news."
    },
    {
      "verse": "6",
      "text": "You have heard this good news, like people all over the world have heard it. It has caused good results among you since the time when you heard it first. At that time, you understood the true message about how kind God really is. As a result, God is blessing you more and more, like he blesses his people everywhere."
    },
    {
      "verse": "7",
      "text": "It was our good friend Epaphras who first told you this good news. Like us, he is Christ's servant. He serves Christ on our behalf."
    },
    {
      "verse": "8",
      "text": "He has told us about the love that God's Spirit has given to you."
    },
    {
      "verse": "9",
      "text": "Because of all that, we have not stopped praying for you, ever since the day that we heard about you. We ask God that his Spirit will make you truly wise. He will help you to know clearly what he wants you to do. You will understand his true message."
    },
    {
      "verse": "10",
      "text": "Then you will be able to live in a way that the Lord wants you to live. Everything that you do will please him. We pray that all these good things will have good results. We pray that you will know God better and better."
    },
    {
      "verse": "11",
      "text": "God rules from heaven with great power. We pray that he will make you strong with every kind of strength. Then, when troubles come, you can still be patient and strong."
    },
    {
      "verse": "12",
      "text": "You will be able to thank God, our Father, and be happy. God has prepared good things for his people to receive in heaven. Because God has included you among his people, you will also share those good things in the kingdom of light."
    },
    {
      "verse": "13",
      "text": "God has saved us from the dark kingdom where Satan rules. He has brought us into the kingdom of his Son, whom he loves."
    },
    {
      "verse": "14",
      "text": "God's Son, Jesus, paid the price for our sins and made us free. Yes, God has forgiven us."
    },
    {
      "verse": "15",
      "text": "We cannot see God. But Jesus Christ shows us completely who God is. Even before God made anything, Jesus was already there as God's Son who rules everything."
    },
    {
      "verse": "16",
      "text": "When God created everything, it was his Son who did it. His Son made everything that is on earth and in heaven. He created everything that we can see, as well as the things that we cannot see. He made rulers and leaders. He made everything that has power and authority. God gave his Son the authority to create everything, so that his Son would receive praise."
    },
    {
      "verse": "17",
      "text": "God's Son was there before anything else was there. And now he causes everything to continue in its proper place."
    },
    {
      "verse": "18",
      "text": "The church is like Christ's body and he is its head. He is where it all begins. As God's special Son, he was the first person who became alive again after death. As a result, Christ is first and most important in all things."
    },
    {
      "verse": "19",
      "text": "God chose to put his nature in Christ completely."
    },
    {
      "verse": "20",
      "text": "He decided that Christ would die on the cross as a sacrifice. In that way, God would bring all things back to himself. Then everything could live in peace with God. That includes everything on the earth and everything in heaven."
    },
    {
      "verse": "21",
      "text": "As for you, you were far away from God at one time. You thought bad things and you did bad things. As a result, you were God's enemies."
    },
    {
      "verse": "22",
      "text": "But now you have become God's friends. This happened because Christ's human body died on the cross. As a result, God has brought you to himself. As you stand in front of him, you are completely good and clean inside. He sees nothing in you that is bad."
    },
    {
      "verse": "23",
      "text": "But you must continue to believe God's true message. Do not turn away from it. Continue to trust God, as you did when you first heard the good news. People have told this good news to everyone all over the world. And God has chosen me, Paul, as his servant to tell this good news."
    },
    {
      "verse": "24",
      "text": "At this time, I am suffering on your behalf, but I am still happy. Christ himself suffered on behalf of his people, the church. Now, while I live in my human body, I also suffer. I continue to receive the pain that Christ received, so that it may be complete. In that way, I help the church, which is like Christ's own body."
    },
    {
      "verse": "25",
      "text": "I have become God's servant, so that I can help the church. God chose me to do that. He chose me to explain his message to you completely."
    },
    {
      "verse": "26",
      "text": "That message is a secret that God hid from everyone before now. He hid it from all the people who lived in past times. But now he has shown this secret to his people."
    },
    {
      "verse": "27",
      "text": "God wanted them to understand how great this secret is. It shows that God will bless people who live in all countries of the world. This secret message is that Christ lives in you. And because of that, you know that you will live with God in heaven one day."
    },
    {
      "verse": "28",
      "text": "That is why we tell everyone the message about Christ. God helps us to be very wise as we warn people and we teach them. We want every person who belongs to Christ to become complete, as God sees them."
    },
    {
      "verse": "29",
      "text": "That is why I work very hard. Christ works powerfully in me to make me strong for this difficult work."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "I want you to know that I am doing a difficult work on your behalf. I am also working to help the people at Laodicea and other people who have never met me."
    },
    {
      "verse": "2",
      "text": "I want all the believers to become strong in their spirits. I want them to help each other because they love one another. Then God will bless them very much, because they understand God's secret message very well. They will be completely sure of it. And they will know Christ himself, who is God's secret."
    },
    {
      "verse": "3",
      "text": "Christ is the one who holds everything that makes people wise. He helps people to know the true message that God had hidden."
    },
    {
      "verse": "4",
      "text": "I am telling you these things so that false teachers will not deceive you. They may teach ideas that seem good, but do not listen to them."
    },
    {
      "verse": "5",
      "text": "My body is not there with you, but I think about you a lot. I hear that you are living and working well together. I also hear that you continue to trust Christ strongly. That makes me very happy."
    },
    {
      "verse": "6",
      "text": "You have accepted Christ Jesus as your Lord. So remember that you belong to him as you live your lives."
    },
    {
      "verse": "7",
      "text": "Get your strength from Christ himself, so that you become stronger and stronger. Continue to believe the true message that we taught you. And thank God very much for everything."
    },
    {
      "verse": "8",
      "text": "Be careful that you do not believe any false teachers. The ideas that they teach may seem clever. But they really want to deceive you. They are ideas that have come from the human minds of our ancestors. Or ideas that come from spirits that belong to this world. They are not the true message about Christ."
    },
    {
      "verse": "9",
      "text": "The whole nature of God himself lives in Christ, in his human body."
    },
    {
      "verse": "10",
      "text": "And because you are united with Christ, you are now complete. He is the one who rules over everything that has power or authority."
    },
    {
      "verse": "11",
      "text": "Also, because you are united with Christ, you truly belong to God's people. No person has circumcised you to show this. It is like Christ himself has circumcised you, to show that you belong to God. It is like he has cut off your old nature which made you do bad things."
    },
    {
      "verse": "12",
      "text": "When they baptized you, it was like God buried you with Christ. And God also raised you to a new life with Christ. You believed that God has great power to do that. You believed that God raised Jesus to life after he died. Because you believed, God raised you to have a new life."
    },
    {
      "verse": "13",
      "text": "At one time, you were dead in your spirits, because of the wrong things that you did. God had not cut off your old nature. You did not belong to his people. But now God has caused you to become alive with Christ. He has forgiven us for all the wrong things that we have done."
    },
    {
      "verse": "14",
      "text": "We are guilty of many wrong things that are against God's laws. But Christ died on the cross on our behalf. He paid the debt of our sins. It is like he has destroyed the list of all the debts that we should pay to God."
    },
    {
      "verse": "15",
      "text": "On the cross, Christ took away the power of the bad spirits that have authority to rule people. He showed clearly that he himself has won against them. Now everyone can see that those bad spirits have no power."
    },
    {
      "verse": "16",
      "text": "Some people may tell you that it is wrong for you to eat or to drink certain things. Or they make rules about special festival days, about new moons, or about the Jewish days for rest. Do not agree with people like that."
    },
    {
      "verse": "17",
      "text": "Rules like that are only like shadows of real things that would happen later. But now we have what is real, Christ himself!"
    },
    {
      "verse": "18",
      "text": "Some people may tell you that you must always serve other people like a slave. They may tell you that you must worship angels. Do not let those people speak bad things against you. They like to talk a lot about the special things that God has shown them. They think that they are very clever. But their ideas only come from human minds."
    },
    {
      "verse": "19",
      "text": "False teachers like that do not receive their message from Christ. As God's people, we are like a body and Christ is like our head. He is the one who causes the whole body to be strong. He helps us to work well together, like the different parts of a body. Then we can all grow properly, because it is God who is helping us to grow."
    },
    {
      "verse": "20",
      "text": "Remember that your old nature has died with Christ. So the powerful spirits that rule this world no longer have any authority over you. You do not need to serve them, because you do not belong to this world now. You do not need to obey their rules."
    },
    {
      "verse": "21",
      "text": "They teach, ‘Do not touch things like that! ’ Or, ‘Do not eat that kind of food! �� Or, ‘Keep away from that thing! ’"
    },
    {
      "verse": "22",
      "text": "Rules like that are only about things that spoil when you use them. They are rules that come from human ideas."
    },
    {
      "verse": "23",
      "text": "They teach you ideas about what you must do to worship God. They teach you to serve other people like a slave. They say that you must hurt yourself. You must show that you control your body. Rules like that may seem to be wise, but really they are not worth anything. They cannot stop our weak human nature from doing the bad things that we want to do."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "God has raised you with Christ to a new life. So you should want more and more the things that belong to heaven. That is where Christ is now. He sits there at God's right side."
    },
    {
      "verse": "2",
      "text": "So think about the good things that are there in heaven above. Do not think only about things that are on the earth."
    },
    {
      "verse": "3",
      "text": "Remember that your old nature has died. God is keeping your new life safe with Christ."
    },
    {
      "verse": "4",
      "text": "You have that new life because you belong to Christ. One day, Christ will show himself clearly to everyone. Then everyone will see that you are with him. They will see that you also are great, like he is."
    },
    {
      "verse": "5",
      "text": "Your old nature likes to do bad things that belong to this earth. But your old nature is dead, so do not do these bad things any more. Do not have sex with someone that you are not married to. Do not think bad, disgusting thoughts. Do not want to have sex in a wrong way. Do not want to do any kinds of bad things. Do not want to have many things for yourselves. That shows that you worship those things as your idol."
    },
    {
      "verse": "6",
      "text": "God will certainly punish people who do those kinds of bad things."
    },
    {
      "verse": "7",
      "text": "At one time, you lived like that. You did those kinds of bad things."
    },
    {
      "verse": "8",
      "text": "But now you must refuse to do all kinds of things like that. Do not become angry with people or shout at them. Do not do anything or say anything that will hurt other people. Do not speak any bad or disgusting words."
    },
    {
      "verse": "9",
      "text": "Do not deceive each other with lies. Remember that you have taken off your old nature, like an old coat. As a result, you can stop doing all the bad things that you liked to do before."
    },
    {
      "verse": "10",
      "text": "Now you have received a new nature. It is God who made it for you so that you can become more and more like him. You will learn to know him better and better."
    },
    {
      "verse": "11",
      "text": "People have this new nature only because they belong to Christ. That is the important thing. Jews are not different from Gentiles. It does not matter whether someone has circumcised you or not. It does not matter which country you come from or how clever you are. It does not matter whether you are a slave or a free person. Christ is all that matters. He lives in every believer."
    },
    {
      "verse": "12",
      "text": "God has chosen you to be his own special people. You belong to him and he loves you very much. So this is how you should live: Be kind to other people and help them. Do not think that you are better than other people. Instead, respect them and be patient with them."
    },
    {
      "verse": "13",
      "text": "Do not become angry with each other. If you think that someone has done something wrong against you, forgive them. Remember that the Lord has forgiven you. So you should also forgive other people."
    },
    {
      "verse": "14",
      "text": "And you must also love each other. That is the most important thing that you should do. Love holds all these good things completely together."
    },
    {
      "verse": "15",
      "text": "Christ has given you peace in your minds. So let that peace rule your thoughts. God has chosen you to be like one body, as his people. So he wants you to live together in peace. Thank God for everything that he gives to you."
    },
    {
      "verse": "16",
      "text": "Let Christ's message always be in your thoughts, with all the good things that it brings. Use that message to teach and to warn each other. Be very wise as you do that. And also sing all kinds of spiritual songs to praise God. Sing psalms and Christian songs. As you sing, thank God from inside yourselves."
    },
    {
      "verse": "17",
      "text": "Show that you belong to the Lord Jesus with everything that you do and with everything that you say. Always thank God the Father in the way that you serve Jesus."
    },
    {
      "verse": "18",
      "text": "Wives, obey your husbands. That is the right thing to do, because you belong to the Lord."
    },
    {
      "verse": "19",
      "text": "Husbands, love your wives. Do not bring trouble to them."
    },
    {
      "verse": "20",
      "text": "Children, always obey your parents. That pleases the Lord."
    },
    {
      "verse": "21",
      "text": "Fathers, do not cause your children to be upset. If you do, they might think that they never do anything that is good."
    },
    {
      "verse": "22",
      "text": "Slaves, always obey your human masters. Do not do good work only when they can see you. Some people only work to make other people like them. Instead, serve your masters well because you want to. That will show that you respect the Lord as your master."
    },
    {
      "verse": "23",
      "text": "Whatever things you are doing, do them well. Remember that you are serving the Lord. You are not only serving people."
    },
    {
      "verse": "24",
      "text": "You know that you will receive the good things that the Lord has promised to his people. He will give you what is right for you. The Lord Jesus Christ is the master that you serve."
    },
    {
      "verse": "25",
      "text": "Remember that God will punish anyone who does wrong things. He always judges people correctly, whoever they are."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Masters, be fair to your servants. Give them what is right. Remember that you also serve a master, and he is in heaven."
    },
    {
      "verse": "2",
      "text": "Continue to pray seriously. Stay awake, like people who watch carefully. And remember to thank God."
    },
    {
      "verse": "3",
      "text": "Also pray for us. Ask God to make it possible for us to tell people his message. We want people to understand the message about Christ that was a secret before. I am now in a prison because I taught people those things."
    },
    {
      "verse": "4",
      "text": "Pray that I will be able to tell people this message clearly. That is what I should do."
    },
    {
      "verse": "5",
      "text": "When you are with people who do not believe in Christ, be careful how you live. Use every chance to do good things."
    },
    {
      "verse": "6",
      "text": "When you speak to people, always speak kind words. Say things that will help them. Then, when someone asks you a question, you will know how to reply."
    },
    {
      "verse": "7",
      "text": "Our Christian friend, Tychicus, will tell you all the news about me. He works hard to serve the Lord. Like me, he is the Lord's servant."
    },
    {
      "verse": "8",
      "text": "I want him to tell you what is happening to us, so that you will feel stronger. That is the reason why I am sending him to you."
    },
    {
      "verse": "9",
      "text": "Onesimus will travel with him. As you know, he is one of your own people. He is a good Christian friend who serves Christ well. Onesimus and Tychicus will tell you everything that is happening here."
    },
    {
      "verse": "10",
      "text": "Aristarchus is also here with me in the prison. He says ‘hello’ to you. Barnabas's cousin, Mark also says ‘hello’ to you. I have already told you about him. So, if he comes to you, be kind to him."
    },
    {
      "verse": "11",
      "text": "Jesus, who is also called Justus, says ‘hello’ to you, too. These three men are the only Jewish believers who are serving God with me. We work together to bring people into the kingdom of God. These men have helped me to be strong."
    },
    {
      "verse": "12",
      "text": "Epaphras says ‘hello’ to you. He is also one of your people, and he is Jesus Christ's servant. He always prays very strongly for you. He prays that you will continue to grow as believers. He prays that you will completely understand everything that God wants you to do."
    },
    {
      "verse": "13",
      "text": "I can tell you this about Epaphras: He has worked very hard for you, and also for the people at Laodicea and at Hierapolis."
    },
    {
      "verse": "14",
      "text": "Our good friend Luke, the doctor, says ‘hello’ to you. Demas also says ‘hello’."
    },
    {
      "verse": "15",
      "text": "Say ‘hello’ for me to all the believers at Laodicea. Also say ‘hello’ to Nympha and to the group of believers that meet in her house."
    },
    {
      "verse": "16",
      "text": "After someone has read this letter to all of you, send it to the believers at Laodicea. Tell them to read it aloud to the church there. You must also read my letter that the believers at Laodicea will send to you."
    },
    {
      "verse": "17",
      "text": "Say to Archippus, ‘As you serve the Lord, be careful to finish the work that he gave you to do. ’"
    },
    {
      "verse": "18",
      "text": "I, Paul, am writing these words at the end of this letter with my own hand. Remember to pray for me while I am in prison. I pray that God will continue to be very kind to you."
    }
  ]
};