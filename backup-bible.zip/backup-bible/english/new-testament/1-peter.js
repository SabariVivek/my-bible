module.exports = {
  "1": [
    {
      "verse": "1",
      "text": "This letter is from me, Peter. I am an apostle of Jesus Christ. I am writing to you, God's own people that he has chosen. You are now living in many different places, in the regions called Pontus, Galatia, Cappadocia, Asia and Bithynia. You are living in these foreign places as strangers."
    },
    {
      "verse": "2",
      "text": "God, the Father, already decided that you should be his people. God's Spirit has made you special people who would obey Jesus Christ. God chose you so that Jesus Christ's blood would make you really clean. I pray that God will help you and give you peace in your minds more and more. I pray that God will help you and give you peace in your minds more and more."
    },
    {
      "verse": "3",
      "text": "We praise God, who is the Father of our Lord Jesus Christ! He is very kind to us, so that he has given us new life. This is possible because God raised Jesus Christ to new life after his death. Now, as we live, we are sure that we will receive good things from God."
    },
    {
      "verse": "4",
      "text": "We wait to receive all the good things that he has prepared for us. Nobody can ever destroy those things. Nothing can spoil them. They will never become old or less beautiful. God is keeping those things in heaven for you."
    },
    {
      "verse": "5",
      "text": "God is using his great power to keep you safe, because you trust him. He will continue to keep you safe until the last day, when Christ will return. Then you will know that God has saved you completely from sin and from death."
    },
    {
      "verse": "6",
      "text": "All this causes you to be very happy, even when you have troubles. For a short time now, different kinds of troubles may make you sad."
    },
    {
      "verse": "7",
      "text": "The purpose of these troubles is to show whether you really trust God. When you believe in Jesus, that is more valuable even than gold. People put gold into a hot fire to see if it is really good. And even gold will come to an end one day. But if you continue to trust God in your troubles, he will be very happy. On the day when Jesus Christ returns and appears to everyone, God will praise you. He will say that you have done well. That will be great!"
    },
    {
      "verse": "8",
      "text": "You have never seen Jesus, but still you love him. You do not see him now, but you believe in him. As a result, you are very happy. There are no words to describe how happy you are."
    },
    {
      "verse": "9",
      "text": "You are happy now because God is saving you from sin. You believe in Jesus, and you know that God saves you because of that."
    },
    {
      "verse": "10",
      "text": "A long time ago, God's prophets spoke about this. They said that God would be very kind to you, his people. They studied carefully to learn how God would save people."
    },
    {
      "verse": "11",
      "text": "They wanted to know when God's special Messiah would come and who he would be. Christ's Spirit showed those prophets that the Messiah would receive much trouble and pain. After that, God would show how great the Messiah is."
    },
    {
      "verse": "12",
      "text": "God showed his prophets that his messages about these things were not really to help them. Instead, God sent his message to the prophets to help you. That message is the good news about Jesus Christ which you have now heard. God sent his Holy Spirit from heaven to help people to tell the good news to you. Even the angels would like to understand more about these things."
    },
    {
      "verse": "13",
      "text": "So now, prepare your minds, so that you are ready to live in a good way. Think clearly about how God helps you. Always remember that God will be very kind to you when Jesus Christ comes again."
    },
    {
      "verse": "14",
      "text": "Obey God, like good children who obey their father. Before you knew the true message about Christ, you very much wanted to do bad things. But now you should not agree to live in that bad way."
    },
    {
      "verse": "15",
      "text": "God has chosen you to be his own people. He is completely good. So you must be completely good too, in the way that you live."
    },
    {
      "verse": "16",
      "text": "In the Bible God says this: ‘You must be completely good, because I am completely good. ’"
    },
    {
      "verse": "17",
      "text": "God knows what each person has done, and he judges each one for those things. He is always fair when he decides about people. He is never kinder to one person than he is to another person. When you pray to God, you call him ‘Father’. So then, always respect him, while you live as strangers here in the world."
    },
    {
      "verse": "18",
      "text": "Your ancestors lived in a way that did not make them really happy. That is the way that you learned to live as well. But now God has saved you from that way of life. You know that he has bought you for himself. He did not buy you with things that do not continue for ever, like silver or gold."
    },
    {
      "verse": "19",
      "text": "Instead, he bought you with the very valuable blood of Christ, who died as a sacrifice for our sins. He died like a lamb that is completely good and has nothing wrong with it."
    },
    {
      "verse": "20",
      "text": "Before the world began, God had already chosen Christ. But now, during these last days of the world, God has shown Christ to people. God did that so that he could help you."
    },
    {
      "verse": "21",
      "text": "Yes, it is because of Christ that you now believe in God. God raised Christ, so that he became alive again after his death. He did that to show everyone that Christ is great. That is why you believe in God. You trust him that he will do good things for you."
    },
    {
      "verse": "22",
      "text": "You have obeyed God's true message. As a result, you have become clean inside, and now you can really love other believers. So continue to love each other very well, with honest thoughts. ‘All people are like grass. They may seem beautiful for a short time, like flowers that grow in the fields. But grass soon becomes dry and it dies. Flowers soon fall to the ground."
    },
    {
      "verse": "23",
      "text": "You now have a new life! It is not like a human life that quickly comes to an end. It is a new life that will never spoil. You received it because you believed God's message. That message continues for ever and it does not change."
    },
    {
      "verse": "24",
      "text": "The Bible says:‘All people are like grass. They may seem beautiful for a short time, like flowers that grow in the fields. But grass soon becomes dry and it dies. Flowers soon fall to the ground."
    },
    {
      "verse": "25",
      "text": "But the Lord God's message will continue for ever. ’That message is the good news about Jesus Christ, which people have taught you."
    }
  ],
  "2": [
    {
      "verse": "1",
      "text": "So you must refuse to do any evil things. Do not tell lies to deceive people. Do not be hypocrites. Do not be jealous of other people. Do not say bad things against other people."
    },
    {
      "verse": "2",
      "text": "Instead, you should want to learn about God more and more. New babies always want their mothers' milk, which makes them grow strong. God's true message is like good food that will make you strong in your spirits. Then you will continue to grow as believers so that God saves you."
    },
    {
      "verse": "3",
      "text": "Do this, because you have already begun to know how kind the Lord is to you."
    },
    {
      "verse": "4",
      "text": "So come to the Lord Jesus. He is like a big stone that a builder uses to build a house. But he is alive. People decided that he was not important. So they refused him. But God had chosen him. To God, Jesus is very valuable."
    },
    {
      "verse": "5",
      "text": "You yourselves are also like stones that are alive. God is using you, like stones, to build a house where his Spirit lives. You will serve him like his special priests who offer sacrifices to him. God will be happy with the spiritual offerings that you give to him, because you belong to Jesus Christ."
    },
    {
      "verse": "6",
      "text": "In the Bible, God says this:‘Look, I have chosen a stone that is very valuable. I have chosen this stone as the most important stone, for the corner of my house in Zion. Anyone who believes in him will never be disappointed. ’ ‘Look, I have chosen a stone that is very valuable. I have chosen this stone as the most important stone, for the corner of my house in Zion. Anyone who believes in him will never be disappointed. ’"
    },
    {
      "verse": "7",
      "text": "This stone is very valuable to you who believe in Jesus. But the Bible says this about people who do not believe in him:‘The builders refused to use a certain stone. They thought that it had no value. But now that stone has become the most important stone at the corner of the building. ’ ‘The builders refused to use a certain stone. They thought that it had no value. But now that stone has become the most important stone at the corner of the building. ’"
    },
    {
      "verse": "8",
      "text": "The Bible also says this:‘This stone will cause people to fall to the ground. It is a rock that will make them fall down. ’They fall down like that because they refuse to obey God's message. God already decided that this would happen to them. ‘This stone will cause people to fall to the ground. It is a rock that will make them fall down. ’ They fall down like that because they refuse to obey God's message. God already decided that this would happen to them."
    },
    {
      "verse": "9",
      "text": "But you are not like that. You are a special group of people that God has chosen. You serve God like priests who serve a King. You are his own holy people who belong to him. He has taken you out of the dark place of sin, and he has brought you into his great light. He has done all this so that you can tell people how great he is."
    },
    {
      "verse": "10",
      "text": "In past times, you were not people who knew God. But now you are God's people. In past times, God did not forgive you. But now he has been very kind to you and he has forgiven you."
    },
    {
      "verse": "11",
      "text": "My friends, remember that you are really strangers in this world. You do not belong here. So I am telling you not to do the bad things that your bodies may want to do. Those bad things fight against what is good for your soul."
    },
    {
      "verse": "12",
      "text": "You are living among people who do not know God. So be very careful that you always live in a good way. Sometimes these people may wrongly say that you do bad things. But if you continue to live in a good way, they will see that you really do good things. As a result, on the day when God comes as judge, they will give honour to him."
    },
    {
      "verse": "13",
      "text": "Obey all people who have authority in this world. Obey them, because you are servants of the Lord Jesus. First of all, obey the king, who rules everyone."
    },
    {
      "verse": "14",
      "text": "Also obey the officers that serve the king. He has sent them to punish people who do bad things. And they praise people who do good things."
    },
    {
      "verse": "15",
      "text": "God wants you to do only what is good. Then silly people will not be able to say bad things against you. Those people do not really know what is true."
    },
    {
      "verse": "16",
      "text": "You are free people. But you are servants of God. So do not think, ‘Because I am free, I can do any bad thing that I want to do. ’"
    },
    {
      "verse": "17",
      "text": "Respect all people. Love the believers as you would love your family. Obey God as your master. Respect the king."
    },
    {
      "verse": "18",
      "text": "You who are slaves must obey your masters. Always respect them. Do that to every kind of master. Obey those who are good and kind. But also obey masters who are not fair to you. ‘He never did anything that was wrong. He never said anything that was not true. ’"
    },
    {
      "verse": "19",
      "text": "This makes God happy. Maybe your master will punish you when you have done nothing wrong. If you know that you are serving God, continue to be patient and brave."
    },
    {
      "verse": "20",
      "text": "But if you do something wrong, then your master ought to punish you. That is only fair. Even if you are brave when he is cruel to you, nobody should praise you for that. But your master may punish you even when you have done good things. Then God will be happy if you are patient and brave."
    },
    {
      "verse": "21",
      "text": "When God chose you to be his servants, he wanted you to be brave like that. Christ had trouble and pain on your behalf. He has shown you how you should live when trouble comes."
    },
    {
      "verse": "22",
      "text": "The Bible says this:‘He never did anything that was wrong. He never said anything that was not true. ’"
    },
    {
      "verse": "23",
      "text": "People insulted Christ, but he did not say any bad thing to answer them. People caused him to have trouble, but he never tried to hurt them in return. Instead, Christ trusted God to help him. He knew that God always judges people fairly."
    },
    {
      "verse": "24",
      "text": "When Christ died on the cross, he carried our sins in his own body. He took this punishment so that sin would no longer rule over us. Instead, we can now do the right things that God wants us to do. Because people hurt Christ's body, you have now become well."
    },
    {
      "verse": "25",
      "text": "Before, you were like sheep that were going the wrong way. But now you have turned round and come to Christ. He is your Shepherd, and he keeps you completely safe."
    }
  ],
  "3": [
    {
      "verse": "1",
      "text": "I need to speak to you wives. You should each respect the authority of your own husband. Even if your husband does not believe God's message about Jesus Christ, you should still respect him. If you do that, he may then turn to God and believe his message. You will not need to tell him what is true. He will see the good way that you live."
    },
    {
      "verse": "2",
      "text": "He will see that you obey God and that you do things that are completely good."
    },
    {
      "verse": "3",
      "text": "Think about what makes you beautiful. The way that you prepare your hair does not really make you beautiful. Gold things or beautiful clothes do not make you beautiful."
    },
    {
      "verse": "4",
      "text": "Do not just think about your body, but think about what you are really like inside yourself. Be patient and do not become angry easily. Then you will always continue to be beautiful. If you are beautiful in your spirit, God likes that very much."
    },
    {
      "verse": "5",
      "text": "That was how holy women made themselves beautiful many years ago. They trusted God that he would help them. They respected the authority of their husbands."
    },
    {
      "verse": "6",
      "text": "Sarah was a woman like that. She obeyed her husband, Abraham. She called him, ‘My master’. So you wives also should do what is right. Do not let anything make you afraid. Then you will be like true daughters of Sarah."
    },
    {
      "verse": "7",
      "text": "You husbands must also respect your wives. Be kind to your wife and help her. Remember that she is not as strong as you are. Because God is very kind, she has received his gift of true life, as you have. So you should respect her. Then God will answer you when you pray to him."
    },
    {
      "verse": "8",
      "text": "Now I want to say this to you before I finish my letter. All of you should agree with each other in what you think. You should try to understand how other people are feeling. Love each other as brothers and sisters. Be kind to each other. Do not think that you are more important than other people. ‘Do you want to enjoy your life? Do you want to be happy? Then you must be careful not to say evil things. Do not tell any lies."
    },
    {
      "verse": "9",
      "text": "If people do bad things to you, do not do anything bad to them in return. If people insult you, do not insult them in return. Instead, pray that God will bless those people. That is what God wants you to do. Then you will receive the gift of God's blessing."
    },
    {
      "verse": "10",
      "text": "The Bible says this:‘Do you want to enjoy your life? Do you want to be happy? Then you must be careful not to say evil things. Do not tell any lies."
    },
    {
      "verse": "11",
      "text": "Stop doing evil things. Instead, do things that are good. Try to be friends with people. Help people to live in peace with each other. Instead, do things that are good. Try to be friends with people. Help people to live in peace with each other."
    },
    {
      "verse": "12",
      "text": "Remember that the Lord God sees what everyone does. He takes care of people who do what is right. When they pray, he listens to them. But the Lord God turns against people who do evil things. ’ He takes care of people who do what is right. When they pray, he listens to them. But the Lord God turns against people who do evil things. ’"
    },
    {
      "verse": "13",
      "text": "If you always try to do good things, then nobody should hurt you."
    },
    {
      "verse": "14",
      "text": "But somebody might give you trouble, even when you do what is right. If that happens, God will bless you. So do not be afraid of what people may do to you. Do not worry about it."
    },
    {
      "verse": "15",
      "text": "Instead, always remember that Christ is your Lord. Let him rule how you live. People may ask you, ‘Why do you trust God to help you? ’ You must always be ready to answer them about that."
    },
    {
      "verse": "16",
      "text": "But when you tell them, be kind and polite. Do only what you know is right. Then those people will see that you live in a good way because you believe in Christ. When they say bad things against you they will become ashamed."
    },
    {
      "verse": "17",
      "text": "Sometimes God may let you have trouble and pain even when you have done good things. But that is better than if you have trouble and pain because you have done bad things."
    },
    {
      "verse": "18",
      "text": "Christ himself always did what was right. But he received pain on behalf of people who do what is wrong. He died once to take away all those wrong things. He did that to bring you near to God. People killed Christ's body, but God's Spirit made him alive again."
    },
    {
      "verse": "19",
      "text": "Like this, he went to the spirits who were in prison. He told them God's true message."
    },
    {
      "verse": "20",
      "text": "Those were the spirits of people who had refused to obey God long ago. At that time God waited patiently for them to turn to him while Noah was building a large ship. But only a few people agreed to go into that ship. God saved only eight people when the ship sailed on the deep water."
    },
    {
      "verse": "21",
      "text": "That shows how God now saves you. It is like a picture of baptism. The water of baptism does not wash dirt from a person's body. Instead, it shows that a person has decided to obey God. He is choosing to do what is right. That saves you, because Jesus Christ became alive again after his death."
    },
    {
      "verse": "22",
      "text": "After that, Jesus went into heaven. Now he is sitting at God's right side. He rules over angels and over everything that has authority and power."
    }
  ],
  "4": [
    {
      "verse": "1",
      "text": "Christ had trouble and pain while he lived in his human body. So you should prepare yourselves to have trouble and pain too. Think about it in the same way that Christ did. If someone has trouble and pain in his body, he stops doing wrong things."
    },
    {
      "verse": "2",
      "text": "As a result, that person will want to do what God wants him to do. In his life in this world, he will not want to do the bad things that people think are good."
    },
    {
      "verse": "3",
      "text": "You have already had enough time in your life to do bad things. Those are the kinds of things that people who do not know God like to do. You did many evil things that your bodies wanted to do. You had sex in a wrong way. You often became drunk. You went to wild parties where you drank too much alcohol. You also worshipped useless idols."
    },
    {
      "verse": "4",
      "text": "But now you no longer live in the same wicked way as those people do. They continue to enjoy those wrong things all the time. But you do not join with them. So they insult you."
    },
    {
      "verse": "5",
      "text": "But those people will have to explain to God what they have done. He is ready to judge every person, whether they are alive now or they have already died."
    },
    {
      "verse": "6",
      "text": "That is why even dead people needed to hear the good news about Christ. Their bodies had to die, as all people must die. But they heard the good news so that their spirits could live, as God wants them to live."
    },
    {
      "verse": "7",
      "text": "All things in this world will soon come to an end. So you must think clearly. Then you will be able to pray in a serious way."
    },
    {
      "verse": "8",
      "text": "Continue to love each other very much. That is more important than anything else. If you love people, you will forgive them for any wrong things that they have done."
    },
    {
      "verse": "9",
      "text": "Always be happy to have other believers as visitors in your homes."
    },
    {
      "verse": "10",
      "text": "God has helped each of you in a certain way. Think carefully about how to use that gift from God well. Remember that God has given many different gifts to his people so that they can help each other."
    },
    {
      "verse": "11",
      "text": "Has God helped you to speak well? Then speak God's messages to people. Or has God helped you to serve other people? Then let God make you strong to do that. Do everything so that people will praise God. They will say that God is great, because of Jesus Christ. He is the one who has all authority and power for ever. Everyone should praise him! Amen! This is true!"
    },
    {
      "verse": "12",
      "text": "My friends, I know that people are causing you to have bad trouble. It is like a fire that is burning you. Do not be surprised about that. These things are happening to you, to show whether you really trust God. Do not think that something strange is happening to you."
    },
    {
      "verse": "13",
      "text": "Instead, be happy when you have trouble. Remember that Christ also received much trouble and pain. If you have trouble like he did, then you will be happy when he returns. At that time, everyone will see how great Christ really is. Then you will be very happy with a great joy."
    },
    {
      "verse": "14",
      "text": "People may insult you because you belong to Christ. But God will bless you when that happens. It shows that the Holy Spirit is with you. He is God's great Spirit."
    },
    {
      "verse": "15",
      "text": "Do not murder anyone. Do not rob anyone. Do not do evil things. Do not try to cause trouble for other people. If you do those things, you deserve to have trouble."
    },
    {
      "verse": "16",
      "text": "But if you receive trouble because you are a Christian, do not be ashamed about that. Instead, you should praise God that you belong to Christ."
    },
    {
      "verse": "17",
      "text": "The time has come when God will start to judge people. He will first judge the people who belong to him. If he will start with his own people, what will happen to other people? They have refused to obey God's good news, so it will surely be very bad for them. ‘When God saves righteous people, that is a difficult thing. It will surely be much worse for people who turn away from God and who do bad things. ’"
    },
    {
      "verse": "18",
      "text": "The Bible says:‘When God saves righteous people, that is a difficult thing. It will surely be much worse for people who turn away from God and who do bad things. ’"
    },
    {
      "verse": "19",
      "text": "So remember this. If you receive trouble because that is what God wants, you should continue to trust him. God made you and he always does what he has promised. So you should continue to do what is good."
    }
  ],
  "5": [
    {
      "verse": "1",
      "text": "Now I want to say something to you who are leaders of the groups of believers. Like you, I am also a leader. I myself saw how people caused Christ to have great pain so that he died. One day people will see how great he really is. Then I will be among those people who join with him in heaven. So I say this to you who are leaders:"
    },
    {
      "verse": "2",
      "text": "Watch over the group of believers that God has given to you. Be like a shepherd that takes care of his sheep. Lead them well because you want to do it. Do not do it just because you have to do it. Do it in the way that God wants for you. Do not be a leader because you want to receive money for yourself. Instead, do it because you want to help people."
    },
    {
      "verse": "3",
      "text": "God has given you a group of believers to take care of them. Do not try to rule over them with power. Instead, show them how to live in a good way, so that they can copy you."
    },
    {
      "verse": "4",
      "text": "Then our master, Christ, will give you a beautiful crown when he appears. That is a great gift that will never become old or less beautiful. He is the great Shepherd who takes care of us."
    },
    {
      "verse": "5",
      "text": "I want to say the same thing to you who are young men. You must respect the authority of the leaders. All of you who are believers must respect one another. Do not think that you are more important than other people. The Bible says:‘God is against proud people. But he is kind to humble people. ’ ‘God is against proud people. But he is kind to humble people. ’"
    },
    {
      "verse": "6",
      "text": "Remember that God is strong and powerful. So be humble in front of him. Then he will lift you up to a good place at the right time."
    },
    {
      "verse": "7",
      "text": "If you have any kind of trouble in your mind, give it to God. God has promised to take care of you."
    },
    {
      "verse": "8",
      "text": "Think seriously about how you live. Watch carefully for danger. Remember that the Devil is your enemy. He wants to hurt you. He walks about like a hungry lion. He is looking for someone to kill and then eat them!"
    },
    {
      "verse": "9",
      "text": "But you must be strong to fight against him. Trust God completely. Remember this: Believers all over the world are having the same kind of trouble."
    },
    {
      "verse": "10",
      "text": "Yes, you will have trouble like this for a short time. But after that, God will make everything right. He is completely kind and he will always help you. Because you belong to Christ, God has chosen you to live with him in heaven for ever. You will join him in that beautiful place. Then God will make you well again. He will make you strong in your spirits. You will be able to stand strongly."
    },
    {
      "verse": "11",
      "text": "Yes, God rules with power for ever! Amen! This is true!"
    },
    {
      "verse": "12",
      "text": "Silas has helped me to write this short letter to you. I know that he continues to trust Christ well. I have written to you because I want you to be strong. I have told you how God is kind to us and he helps us. This is God's true message to you. So continue to believe it and be strong."
    },
    {
      "verse": "13",
      "text": "The believers here in Babylon say ‘hello’ to you. God has chosen them as his people, together with you. Mark, who is like my son, also says ‘hello’ to you. I pray for all of you who belong to Christ. I pray that God will give you peace in your minds."
    },
    {
      "verse": "14",
      "text": "When you meet, kiss each other as Christian brothers and sisters. I pray for all of you who belong to Christ. I pray that God will give you peace in your minds."
    }
  ]
};